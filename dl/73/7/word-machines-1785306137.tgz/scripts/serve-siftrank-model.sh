#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-$ROOT_DIR/.venv/bin/python}"
VLLM_BIN="${VLLM_BIN:-$ROOT_DIR/.venv/bin/vllm}"

CUDA_HOME="${CUDA_HOME:-/usr/local/cuda-13.0}"

MODEL="${MODEL:-WeiboAI/VibeThinker-3B}"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8000}"

OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output}"
LOG_DIR="${LOG_DIR:-$OUTPUT_DIR/logs}"

RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
SERVER_LOG="${SERVER_LOG:-$LOG_DIR/vllm-siftrank-$RUN_ID.log}"
SIFTRANK_TRACE="${SIFTRANK_TRACE:-$LOG_DIR/vllm-siftrank-$RUN_ID.trace.jsonl}"

PLUGIN_NAME="${PLUGIN_NAME:-siftrank_endpoint}"
PLUGIN_ENTRYPOINT="${PLUGIN_ENTRYPOINT:-vllm_siftrank.plugin:SiftRankEndpointPlugin}"
LOGITS_PROCESSOR="${LOGITS_PROCESSOR:-vllm_siftrank.logits_processor:SiftRankLogitsProcessor}"
EXPECTED_PROTOCOL="${EXPECTED_PROTOCOL:-final-ranking-v4.9}"

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

timestamp() {
    date --iso-8601=seconds
}

if [[ ! -x "$PYTHON_BIN" ]]; then
    die "Python not found at $PYTHON_BIN"
fi

if [[ ! -x "$VLLM_BIN" ]]; then
    die "vLLM not found at $VLLM_BIN"
fi

if [[ ! -x "$CUDA_HOME/bin/nvcc" ]]; then
    die "CUDA compiler not found at $CUDA_HOME/bin/nvcc"
fi

nvcc_release="$(
    "$CUDA_HOME/bin/nvcc" --version |
        sed -nE 's/.*release ([0-9]+\.[0-9]+).*/\1/p' |
        head -n 1
)"

if [[ "$nvcc_release" != 13.* ]]; then
    die "expected CUDA 13 nvcc, found ${nvcc_release:-unknown}"
fi

metadata="$(
    PLUGIN_NAME="$PLUGIN_NAME" \
    PLUGIN_ENTRYPOINT="$PLUGIN_ENTRYPOINT" \
    EXPECTED_PROTOCOL="$EXPECTED_PROTOCOL" \
    "$PYTHON_BIN" - <<'PY'
import importlib.metadata as md
import os
import sys

plugin_name = os.environ["PLUGIN_NAME"]
expected_entrypoint = os.environ["PLUGIN_ENTRYPOINT"]
expected_protocol = os.environ["EXPECTED_PROTOCOL"]

try:
    import vllm
    from vllm.plugins import load_endpoint_plugins  # noqa: F401
    from vllm_siftrank.protocol import PROTOCOL_VERSION
    from vllm_siftrank.logits_processor import SiftRankLogitsProcessor  # noqa: F401
except Exception as exc:
    print(f"SiftRank/vLLM environment unavailable: {exc}", file=sys.stderr)
    raise SystemExit(1)

entrypoints = {
    ep.name: ep.value
    for ep in md.entry_points(group="vllm.endpoint_plugins")
}

actual_entrypoint = entrypoints.get(plugin_name)
if actual_entrypoint != expected_entrypoint:
    print(
        f"expected endpoint plugin {plugin_name!r} -> "
        f"{expected_entrypoint!r}, found {actual_entrypoint!r}",
        file=sys.stderr,
    )
    raise SystemExit(1)

if PROTOCOL_VERSION != expected_protocol:
    print(
        f"expected SiftRank protocol {expected_protocol!r}, "
        f"found {PROTOCOL_VERSION!r}",
        file=sys.stderr,
    )
    raise SystemExit(1)

flashinfer_python = md.version("flashinfer-python")
flashinfer_cubin = md.version("flashinfer-cubin")
if flashinfer_python != flashinfer_cubin:
    print(
        "flashinfer version mismatch: "
        f"flashinfer-python={flashinfer_python}, "
        f"flashinfer-cubin={flashinfer_cubin}",
        file=sys.stderr,
    )
    raise SystemExit(1)

print(vllm.__version__)
print(flashinfer_python)
print(PROTOCOL_VERSION)
PY
)" || die "vLLM/plugin environment validation failed"

VLLM_VERSION="$(sed -n '1p' <<<"$metadata")"
FLASHINFER_VERSION="$(sed -n '2p' <<<"$metadata")"
PROTOCOL_VERSION="$(sed -n '3p' <<<"$metadata")"

mkdir -p "$LOG_DIR"
touch "$SERVER_LOG" "$SIFTRANK_TRACE"

cd "$ROOT_DIR"

export CUDA_HOME
export PATH="$CUDA_HOME/bin:$PATH"

# Explicitly allow only the SiftRank endpoint plugin.
export VLLM_PLUGINS="$PLUGIN_NAME"

# FlashInfer's top-k/top-p sampler previously failed to compile on this host.
# This keeps FlashAttention/model inference enabled while using vLLM's sampler.
export VLLM_USE_FLASHINFER_SAMPLER=0

# The endpoint uses thinking_token_budget. Model Runner V2 does not support it.
export VLLM_USE_V2_MODEL_RUNNER=0

# Read by the SiftRank endpoint plugin.
export SIFTRANK_ENDPOINT_TRACE="$SIFTRANK_TRACE"

# Everything emitted after this point is shown and retained.
exec > >(tee -a "$SERVER_LOG") 2>&1

cat <<EOF2
vLLM SiftRank v4.9 server launch
Started: $(timestamp)
Run ID: $RUN_ID
Repository: $ROOT_DIR
Model: $MODEL
Address: http://$HOST:$PORT
Protocol: $PROTOCOL_VERSION
CUDA_HOME: $CUDA_HOME
nvcc: $CUDA_HOME/bin/nvcc
nvcc release: $nvcc_release
Python: $PYTHON_BIN
vLLM: $VLLM_BIN
vLLM version: $VLLM_VERSION
FlashInfer version: $FLASHINFER_VERSION
Endpoint plugin: $PLUGIN_NAME
Plugin entry point: $PLUGIN_ENTRYPOINT
Logits processor: $LOGITS_PROCESSOR
Server log: $SERVER_LOG
Endpoint trace: $SIFTRANK_TRACE

Engine settings:
  max model length: 16384
  GPU memory utilization: 0.92
  max sequences: 1000
  max batched tokens: 32768
  prefix caching: enabled
  model runner V2: disabled

Default sampling:
  temperature: 0.0
  top_p: 1.0
  top_k: -1
  max_new_tokens: 16384

FlashInfer sampler:
  disabled
EOF2

# Use the project venv binary explicitly. Do not rely on a globally installed
# `vllm` command or the caller's PATH.
#
# The endpoint keeps structured SCORES and ORDER artifacts inside <think> and
# terminates with the ordinary </think> marker. The server derives the public
# final ranking deterministically from the constrained ORDER array.
exec "$VLLM_BIN" serve "$MODEL" \
    --host "$HOST" \
    --port "$PORT" \
    --dtype auto \
    --max-model-len 16384 \
    --gpu-memory-utilization 0.92 \
    --max-num-seqs 1000 \
    --max-num-batched-tokens 32768 \
    --enable-prefix-caching \
    --chat-template-content-format string \
    --logits-processors "$LOGITS_PROCESSOR" \
    --generation-config vllm \
    --override-generation-config \
    '{"temperature":0.0,"top_p":1.0,"top_k":-1,"max_new_tokens":16384}' \
    --reasoning-parser qwen3 \
    "$@"
