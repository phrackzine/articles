#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures as cf
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from transformers import AutoTokenizer


VERDICTS = [
    "VALID_UAF",
    "LIKELY_UAF",
    "UNCERTAIN",
    "LIKELY_FALSE_POSITIVE",
    "FALSE_POSITIVE",
]

POSITIVE_VERDICTS = {
    "VALID_UAF",
    "LIKELY_UAF",
}

NEGATIVE_VERDICTS = {
    "LIKELY_FALSE_POSITIVE",
    "FALSE_POSITIVE",
}

ORDERINGS = [
    "FREE_BEFORE_USE",
    "USE_BEFORE_FREE",
    "UNKNOWN",
]

OBJECT_RELATIONSHIPS = [
    "SAME_OBJECT",
    "ALIAS",
    "FIELD_OR_SUBOBJECT",
    "OWNER_OR_CONTAINER",
    "REACHABLE_DEPENDENT_STATE",
    "UNRELATED",
    "UNKNOWN",
]

PATH_FEASIBILITY = ["YES", "NO", "UNKNOWN"]

DISQUALIFIERS = [
    "NONE",
    "FREE_NOT_LIFETIME_ENDING",
    "USE_NOT_MEANINGFUL",
    "DIFFERENT_OBJECT",
    "NO_COMMON_PATH",
    "USE_BEFORE_FREE",
    "REINITIALIZED_BEFORE_USE",
    "INSUFFICIENT_EVIDENCE",
    "OTHER_CONCRETE_CONTRADICTION",
]

ANALYSIS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "free_is_lifetime_ending": {"type": "boolean"},
        "use_is_meaningful": {"type": "boolean"},
        "freed_object": {"type": "string"},
        "used_object": {"type": "string"},
        "affected_object": {"type": "string"},
        "object_relationship": {
            "type": "string",
            "enum": OBJECT_RELATIONSHIPS,
        },
        "same_path": {
            "type": "string",
            "enum": PATH_FEASIBILITY,
        },
        "ordering": {
            "type": "string",
            "enum": ORDERINGS,
        },
        "intervening_reassignment": {
            "type": "string",
            "enum": PATH_FEASIBILITY,
        },
        "disqualifier": {
            "type": "string",
            "enum": DISQUALIFIERS,
        },
        "disqualifier_evidence": {"type": "string"},
        "verdict": {
            "type": "string",
            "enum": VERDICTS,
        },
        "confidence": {
            "type": "number",
            "minimum": 0.0,
            "maximum": 1.0,
        },
        "path_summary": {"type": "string"},
        "rationale": {"type": "string"},
    },
    "required": [
        "free_is_lifetime_ending",
        "use_is_meaningful",
        "freed_object",
        "used_object",
        "affected_object",
        "object_relationship",
        "same_path",
        "ordering",
        "intervening_reassignment",
        "disqualifier",
        "disqualifier_evidence",
        "verdict",
        "confidence",
        "path_summary",
        "rationale",
    ],
    "additionalProperties": False,
}


class HTTPRequestError(RuntimeError):
    def __init__(self, status: int, body: str):
        self.status = status
        self.body = body
        super().__init__(f"HTTP {status}: {body}")


def load_json(path: str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_existing_successes(path: str) -> set[str]:
    output = Path(path)
    if not output.exists():
        return set()

    successes: set[str] = set()
    with output.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue

            analysis = row.get("analysis") or {}
            if (
                row.get("ok") is True
                and row.get("analysis_id")
                and analysis.get("verdict") in VERDICTS
                and analysis.get("ordering") in ORDERINGS
            ):
                successes.add(row["analysis_id"])

    return successes


def function_name(obj: dict[str, Any]) -> str | None:
    value = obj.get("function")
    if isinstance(value, dict):
        name = value.get("name")
        return str(name) if name else None
    if value is None:
        return None
    return str(value)


def extract_line_number(line: str) -> int | None:
    match = re.match(r"^\s*(\d+)\s", line)
    return int(match.group(1)) if match else None


def line_excerpt(
    definition: str,
    target_line: int,
    before: int = 6,
    after: int = 12,
) -> str:
    lines = definition.splitlines()
    parsed = [(extract_line_number(line), line) for line in lines]

    index = next(
        (
            i
            for i, (number, _) in enumerate(parsed)
            if number == target_line
        ),
        None,
    )
    if index is None:
        return ""

    start = max(0, index - before)
    end = min(len(lines), index + after + 1)
    return "\n".join(lines[start:end])


def find_callsite(
    caller: dict[str, Any],
    callee: dict[str, Any],
    before: int = 8,
    after: int = 16,
) -> dict[str, Any]:
    caller_definition = caller.get("definition") or ""
    callee_name = callee.get("name") or ""

    if not caller_definition or not callee_name:
        return {
            "caller": caller.get("name"),
            "callee": callee.get("name"),
            "found": False,
            "reason": "missing caller definition or callee name",
        }

    pattern = re.compile(
        r"\b" + re.escape(str(callee_name)) + r"\s*\("
    )
    lines = caller_definition.splitlines()

    for index, line in enumerate(lines):
        if not pattern.search(line):
            continue

        start = max(0, index - before)
        end = min(len(lines), index + after + 1)
        return {
            "caller": caller.get("name"),
            "callee": callee.get("name"),
            "found": True,
            "line": extract_line_number(line),
            "text": line,
            "excerpt": "\n".join(lines[start:end]),
        }

    return {
        "caller": caller.get("name"),
        "callee": callee.get("name"),
        "found": False,
        "reason": (
            f"no direct textual call to {callee_name} "
            f"found in {caller.get('name')}"
        ),
    }


def build_ordering_witness(
    candidate: dict[str, Any],
) -> dict[str, Any]:
    call_chain = candidate.get("call_chain") or []
    free = candidate.get("free") or {}
    use = candidate.get("use") or {}

    edges = [
        find_callsite(caller, callee)
        for caller, callee in zip(
            call_chain,
            call_chain[1:],
        )
    ]

    free_function = function_name(free)
    use_function = function_name(use)
    free_line = int(free.get("line") or 0)
    use_line = int(use.get("line") or 0)

    free_excerpt = ""
    use_excerpt = ""

    for function in call_chain:
        if function.get("name") == free_function:
            free_excerpt = line_excerpt(
                function.get("definition") or "",
                free_line,
            )
        if function.get("name") == use_function:
            use_excerpt = line_excerpt(
                function.get("definition") or "",
                use_line,
            )

    return {
        "relation": candidate.get("relation"),
        "edges": edges,
        "free_excerpt": free_excerpt,
        "use_excerpt": use_excerpt,
    }


def xml_attr(value: Any) -> str:
    if value is None:
        return ""
    return html.escape(str(value), quote=True)


def cdata(value: Any) -> str:
    text = "" if value is None else str(value)
    return "<![CDATA[" + text.replace(
        "]]>",
        "]]]]><![CDATA[>",
    ) + "]]>"


def render_ordering_evidence(
    witness: dict[str, Any],
) -> str:
    parts = [
        (
            '<ordering_evidence relation="'
            + xml_attr(witness.get("relation"))
            + '">'
        ),
        "  <call_edges>",
    ]

    edges = witness.get("edges") or []
    if edges:
        for edge in edges:
            attributes = [
                f'caller="{xml_attr(edge.get("caller"))}"',
                f'callee="{xml_attr(edge.get("callee"))}"',
                (
                    'found="true"'
                    if edge.get("found")
                    else 'found="false"'
                ),
            ]
            if edge.get("line") is not None:
                attributes.append(
                    f'callsite_line="{xml_attr(edge.get("line"))}"'
                )

            parts.append(
                "    <call_edge "
                + " ".join(attributes)
                + ">"
            )
            if edge.get("found"):
                parts.extend(
                    [
                        "      <callsite_excerpt>",
                        "        " + cdata(edge.get("excerpt") or ""),
                        "      </callsite_excerpt>",
                    ]
                )
            else:
                parts.extend(
                    [
                        "      <not_found_reason>",
                        "        " + cdata(edge.get("reason") or ""),
                        "      </not_found_reason>",
                    ]
                )
            parts.append("    </call_edge>")
    else:
        parts.append(
            "    <call_edges_unavailable "
            'reason="no adjacent call-chain edges" />'
        )

    parts.append("  </call_edges>")

    if witness.get("free_excerpt"):
        parts.extend(
            [
                "  <free_execution_excerpt>",
                "    " + cdata(witness["free_excerpt"]),
                "  </free_execution_excerpt>",
            ]
        )

    if witness.get("use_excerpt"):
        parts.extend(
            [
                "  <use_execution_excerpt>",
                "    " + cdata(witness["use_excerpt"]),
                "  </use_execution_excerpt>",
            ]
        )

    parts.append("</ordering_evidence>")
    return "\n".join(parts)


def render_call_chain(
    call_chain: list[dict[str, Any]],
) -> str:
    parts = ["<call_chain>"]
    for index, function in enumerate(call_chain):
        parts.append(
            "  <function_ref "
            f'index="{index}" '
            f'name="{xml_attr(function.get("name"))}" '
            f'file="{xml_attr(function.get("file"))}" '
            f'start_line="{xml_attr(function.get("start_line"))}" '
            f'end_line="{xml_attr(function.get("end_line"))}" '
            f'signature="{xml_attr(function.get("signature"))}" />'
        )
    parts.append("</call_chain>")
    return "\n".join(parts)


def render_full_definitions(
    call_chain: list[dict[str, Any]],
) -> str:
    rendered = ["<function_definitions>"]
    seen: set[Any] = set()

    for function in call_chain:
        key = function.get("id") or (
            function.get("file"),
            function.get("start_line"),
            function.get("name"),
        )
        if key in seen:
            continue
        seen.add(key)

        rendered.extend(
            [
                (
                    "  <function_definition "
                    f'name="{xml_attr(function.get("name"))}" '
                    f'signature="{xml_attr(function.get("signature"))}" '
                    f'file="{xml_attr(function.get("file"))}" '
                    f'start_line="{xml_attr(function.get("start_line"))}" '
                    f'end_line="{xml_attr(function.get("end_line"))}">'
                ),
                "    <code>",
                "      " + cdata(function.get("definition", "")),
                "    </code>",
                "  </function_definition>",
            ]
        )

    rendered.append("</function_definitions>")
    return "\n".join(rendered)


def render_candidate_role(
    tag: str,
    candidate: dict[str, Any],
) -> str:
    return "\n".join(
        [
            (
                f'<{tag} '
                f'id="{xml_attr(candidate.get("id"))}" '
                f'function="{xml_attr(function_name(candidate))}" '
                f'file="{xml_attr(candidate.get("file"))}" '
                f'line="{xml_attr(candidate.get("line"))}">'
            ),
            "  <target>",
            "    " + cdata(candidate.get("target", "")),
            "  </target>",
            "  <local_window>",
            "    " + cdata(candidate.get("window", "")),
            "  </local_window>",
            f"</{tag}>",
        ]
    )


def render_candidate(
    candidate: dict[str, Any],
    instructions: str,
    mode: str,
    correction: str | None = None,
) -> str:
    call_chain = candidate.get("call_chain") or []
    evidence = render_ordering_evidence(
        build_ordering_witness(candidate)
    )

    free = candidate["free"]
    use = candidate["use"]

    if mode == "full":
        context = "\n".join(
            [
                '<context mode="full">',
                render_full_definitions(call_chain),
                "</context>",
            ]
        )
    elif mode == "focused":
        context = "\n".join(
            [
                '<context mode="focused">',
                "  <notice>",
                "    " + cdata(
                    "Complete function bodies were omitted because they "
                    "did not fit the configured model context. Use only "
                    "the supplied call-site evidence, FREE/USE execution "
                    "excerpts, local windows, relation, and call-chain "
                    "metadata. Choose UNKNOWN or UNCERTAIN when this "
                    "evidence is insufficient."
                ),
                "  </notice>",
                "</context>",
            ]
        )
    else:
        raise ValueError(f"unknown render mode: {mode}")

    correction_xml = ""
    if correction:
        correction_xml = "\n".join(
            [
                "<retry_correction>",
                "  " + cdata(
                    "The previous final JSON was invalid or internally "
                    "inconsistent. Re-evaluate the candidate and return a "
                    "semantically consistent JSON object satisfying every "
                    "field.\n\n" + correction
                ),
                "</retry_correction>",
            ]
        )

    candidate_xml = "\n".join(
        part
        for part in [
            (
                '<uaf_candidate '
                f'id="{xml_attr(candidate.get("analysis_id"))}" '
                f'relation="{xml_attr(candidate.get("relation"))}" '
                f'render_mode="{xml_attr(mode)}">'
            ),
            render_call_chain(call_chain),
            render_candidate_role("free_candidate", free),
            render_candidate_role("use_candidate", use),
            evidence,
            context,
            correction_xml,
            "</uaf_candidate>",
        ]
        if part
    )

    return (
        instructions.rstrip()
        + "\n\n"
        + "Analyze only the following XML candidate evidence.\n\n"
        + candidate_xml
        + "\n"
    )


def normalize_evidence_text(value: Any) -> str:
    text = "" if value is None else str(value)
    return re.sub(r"\s+", " ", text).strip()


def candidate_evidence_fragments(
    candidate: dict[str, Any],
) -> list[str]:
    fragments: list[str] = []

    for role in ("free", "use"):
        item = candidate.get(role) or {}
        for field in (
            "id",
            "file",
            "target",
            "window",
        ):
            value = item.get(field)
            if value is not None:
                fragments.append(str(value))

        name = function_name(item)
        if name:
            fragments.append(name)

    for function in candidate.get("call_chain") or []:
        for field in (
            "name",
            "file",
            "signature",
            "definition",
        ):
            value = function.get(field)
            if value is not None:
                fragments.append(str(value))

    witness = build_ordering_witness(candidate)
    for edge in witness.get("edges") or []:
        for field in (
            "caller",
            "callee",
            "text",
            "excerpt",
            "reason",
        ):
            value = edge.get(field)
            if value is not None:
                fragments.append(str(value))

    for field in ("free_excerpt", "use_excerpt"):
        value = witness.get(field)
        if value:
            fragments.append(str(value))

    return fragments


def evidence_is_grounded(
    evidence: str,
    candidate: dict[str, Any],
) -> bool:
    normalized = normalize_evidence_text(evidence)
    if not normalized:
        return False

    return any(
        normalized in normalize_evidence_text(fragment)
        for fragment in candidate_evidence_fragments(candidate)
    )


def target_has_explicit_pointee_use(target: str) -> bool:
    # These are deliberately conservative, syntax-local checks. They catch
    # unambiguous field dereferences and array/subscript uses without trying
    # to implement a C parser in the validator.
    if "->" in target:
        return True

    return bool(
        re.search(
            r"\b[A-Za-z_]\w*(?:\s*(?:->|\.)\s*[A-Za-z_]\w*)*\s*\[",
            target,
        )
    )


def load_tokenizer(name_or_path: str) -> Any:
    return AutoTokenizer.from_pretrained(name_or_path)


def count_chat_tokens(
    tokenizer: Any,
    content: str,
) -> int:
    formatted = tokenizer.apply_chat_template(
        [{"role": "user", "content": content}],
        tokenize=False,
        add_generation_prompt=True,
    )
    encoded = tokenizer(
        formatted,
        add_special_tokens=False,
        truncation=False,
        return_attention_mask=False,
    )
    return len(encoded["input_ids"])


def prepare_request_text(
    *,
    candidate: dict[str, Any],
    instructions: str,
    tokenizer: Any,
    max_model_len: int,
    requested_max_tokens: int,
    context_margin: int,
    min_output_tokens: int,
    correction: str | None = None,
    preferred_mode: str | None = None,
) -> tuple[str, int, int, str]:
    modes = ["full", "focused"]
    if preferred_mode in modes:
        modes.remove(preferred_mode)
        modes.insert(0, preferred_mode)

    measurements: list[str] = []

    for mode in modes:
        prompt = render_candidate(
            candidate,
            instructions,
            mode=mode,
            correction=correction,
        )
        prompt_tokens = count_chat_tokens(
            tokenizer,
            prompt,
        )
        available_output = (
            max_model_len
            - prompt_tokens
            - context_margin
        )
        request_max_tokens = min(
            requested_max_tokens,
            available_output,
        )

        measurements.append(
            f"{mode}: prompt={prompt_tokens}, "
            f"available_output={available_output}"
        )

        if request_max_tokens >= min_output_tokens:
            return (
                prompt,
                prompt_tokens,
                request_max_tokens,
                mode,
            )

    raise ValueError(
        "candidate cannot fit with the minimum output allowance; "
        + "; ".join(measurements)
    )


def post_chat(
    base_url: str,
    api_key: str,
    payload: dict[str, Any],
    timeout: int,
) -> dict[str, Any]:
    request = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=timeout,
        ) as response:
            body = response.read().decode(
                "utf-8",
                errors="replace",
            )
            return json.loads(body)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode(
            "utf-8",
            errors="replace",
        )
        raise HTTPRequestError(
            exc.code,
            body,
        ) from exc


def extract_json_object(content: str) -> dict[str, Any]:
    text = content.strip()

    # Compatibility fallback if the server was launched
    # without a reasoning parser.
    if "</think>" in text:
        text = text.rsplit("</think>", 1)[1].strip()

    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        value = json.loads(text[start : end + 1])

    if not isinstance(value, dict):
        raise ValueError(
            "final response is not a JSON object"
        )

    return value


def validate_analysis(
    analysis: dict[str, Any],
    candidate: dict[str, Any],
) -> list[str]:
    errors: list[str] = []

    for field in ANALYSIS_SCHEMA["required"]:
        if field not in analysis:
            errors.append(
                f"missing required field {field}"
            )

    ordering = analysis.get("ordering")
    verdict = analysis.get("verdict")
    relationship = analysis.get(
        "object_relationship"
    )
    same_path = analysis.get("same_path")
    reassignment = analysis.get(
        "intervening_reassignment"
    )
    disqualifier = analysis.get("disqualifier")
    disqualifier_evidence = analysis.get(
        "disqualifier_evidence"
    )
    free_is_real = analysis.get(
        "free_is_lifetime_ending"
    )
    use_is_meaningful = analysis.get(
        "use_is_meaningful"
    )

    use_target = str(
        (candidate.get("use") or {}).get("target")
        or ""
    )
    explicit_pointee_use = (
        target_has_explicit_pointee_use(use_target)
    )

    if ordering not in ORDERINGS:
        errors.append(
            f"invalid ordering {ordering!r}"
        )
    if verdict not in VERDICTS:
        errors.append(
            f"invalid verdict {verdict!r}"
        )
    if relationship not in OBJECT_RELATIONSHIPS:
        errors.append(
            "invalid object_relationship "
            f"{relationship!r}"
        )
    if same_path not in PATH_FEASIBILITY:
        errors.append(
            f"invalid same_path {same_path!r}"
        )
    if reassignment not in PATH_FEASIBILITY:
        errors.append(
            "invalid intervening_reassignment "
            f"{reassignment!r}"
        )
    if disqualifier not in DISQUALIFIERS:
        errors.append(
            f"invalid disqualifier {disqualifier!r}"
        )
    if not isinstance(free_is_real, bool):
        errors.append(
            "free_is_lifetime_ending must be boolean"
        )
    if not isinstance(use_is_meaningful, bool):
        errors.append(
            "use_is_meaningful must be boolean"
        )

    confidence = analysis.get("confidence")
    if not isinstance(confidence, (int, float)):
        errors.append(
            "confidence must be numeric"
        )
    elif not 0.0 <= float(confidence) <= 1.0:
        errors.append(
            "confidence must be between 0.0 and 1.0"
        )

    for field in (
        "freed_object",
        "used_object",
        "affected_object",
        "disqualifier_evidence",
        "path_summary",
        "rationale",
    ):
        value = analysis.get(field)
        if (
            not isinstance(value, str)
            or not value.strip()
        ):
            errors.append(
                f"{field} must be a non-empty string"
            )

    evidence_text = (
        disqualifier_evidence.strip().lower()
        if isinstance(disqualifier_evidence, str)
        else ""
    )

    if disqualifier == "NONE":
        if evidence_text not in {"none", "n/a", "not applicable"}:
            errors.append(
                "disqualifier=NONE requires "
                "disqualifier_evidence='none'"
            )
    elif evidence_text in {"", "none", "n/a", "not applicable"}:
        errors.append(
            f"{disqualifier} requires concrete "
            "disqualifier_evidence"
        )
    elif isinstance(disqualifier_evidence, str):
        if any(
            marker in disqualifier_evidence
            for marker in (
                "<![CDATA[",
                "<target",
                "</target",
                "<local_window",
                "</local_window",
            )
        ):
            errors.append(
                "disqualifier_evidence must be source evidence, "
                "not XML markup"
            )
        if "..." in disqualifier_evidence or "…" in disqualifier_evidence:
            errors.append(
                "disqualifier_evidence must not contain ellipses"
            )
        if len(normalize_evidence_text(disqualifier_evidence)) > 500:
            errors.append(
                "disqualifier_evidence must be a short excerpt"
            )
        if not evidence_is_grounded(
            disqualifier_evidence,
            candidate,
        ):
            errors.append(
                "disqualifier_evidence must be an exact excerpt "
                "from the supplied candidate evidence"
            )

    if explicit_pointee_use and use_is_meaningful is False:
        errors.append(
            "use_is_meaningful=false contradicts an explicit "
            "pointer-field or subscript access in the highlighted USE"
        )

    if (
        explicit_pointee_use
        and disqualifier == "USE_NOT_MEANINGFUL"
    ):
        errors.append(
            "USE_NOT_MEANINGFUL cannot disqualify a highlighted "
            "USE that explicitly dereferences or indexes an object"
        )

    positive = verdict in POSITIVE_VERDICTS
    negative = verdict in NEGATIVE_VERDICTS

    if positive and free_is_real is not True:
        errors.append(
            f"{verdict} requires "
            "free_is_lifetime_ending=true"
        )
    if positive and use_is_meaningful is not True:
        errors.append(
            f"{verdict} requires use_is_meaningful=true"
        )
    if positive and same_path != "YES":
        errors.append(
            f"{verdict} requires same_path=YES"
        )
    if positive and ordering != "FREE_BEFORE_USE":
        errors.append(
            f"{verdict} requires "
            "ordering=FREE_BEFORE_USE"
        )
    if positive and relationship in {
        "UNRELATED",
        "UNKNOWN",
        None,
    }:
        errors.append(
            f"{verdict} requires a concrete "
            "object relationship"
        )
    if positive and disqualifier != "NONE":
        errors.append(
            f"{verdict} requires disqualifier=NONE"
        )
    if verdict == "VALID_UAF" and reassignment != "NO":
        errors.append(
            "VALID_UAF requires "
            "intervening_reassignment=NO"
        )
    if verdict == "LIKELY_UAF" and reassignment == "YES":
        errors.append(
            "LIKELY_UAF is incompatible with an explicit "
            "intervening reassignment"
        )

    if negative and disqualifier in {
        "NONE",
        "INSUFFICIENT_EVIDENCE",
        None,
    }:
        errors.append(
            f"{verdict} requires a concrete disqualifier"
        )

    if verdict == "UNCERTAIN" and disqualifier != "INSUFFICIENT_EVIDENCE":
        errors.append(
            "UNCERTAIN requires "
            "disqualifier=INSUFFICIENT_EVIDENCE"
        )

    if (
        disqualifier == "FREE_NOT_LIFETIME_ENDING"
        and free_is_real is not False
    ):
        errors.append(
            "FREE_NOT_LIFETIME_ENDING requires "
            "free_is_lifetime_ending=false"
        )
    if disqualifier == "USE_NOT_MEANINGFUL" and use_is_meaningful is not False:
        errors.append(
            "USE_NOT_MEANINGFUL requires "
            "use_is_meaningful=false"
        )
    if disqualifier == "DIFFERENT_OBJECT" and relationship != "UNRELATED":
        errors.append(
            "DIFFERENT_OBJECT requires "
            "object_relationship=UNRELATED"
        )
    if disqualifier == "NO_COMMON_PATH" and same_path != "NO":
        errors.append(
            "NO_COMMON_PATH requires same_path=NO"
        )
    if disqualifier == "USE_BEFORE_FREE" and ordering != "USE_BEFORE_FREE":
        errors.append(
            "USE_BEFORE_FREE disqualifier requires "
            "ordering=USE_BEFORE_FREE"
        )
    if disqualifier == "REINITIALIZED_BEFORE_USE":
        if reassignment != "YES":
            errors.append(
                "REINITIALIZED_BEFORE_USE requires "
                "intervening_reassignment=YES"
            )
        if relationship != "UNRELATED":
            errors.append(
                "REINITIALIZED_BEFORE_USE requires the "
                "freed and used lifetimes to be UNRELATED"
            )
    if disqualifier == "INSUFFICIENT_EVIDENCE" and verdict != "UNCERTAIN":
        errors.append(
            "INSUFFICIENT_EVIDENCE requires verdict=UNCERTAIN"
        )

    if (
        ordering == "USE_BEFORE_FREE"
        and verdict in POSITIVE_VERDICTS
    ):
        errors.append(
            "USE_BEFORE_FREE is incompatible "
            "with a positive UAF verdict"
        )

    return errors


def selection_metadata(
    candidate: dict[str, Any],
) -> dict[str, Any]:
    fields = (
        "siftrank_rank",
        "siftrank_rounds",
        "siftrank_score",
        "siftrank_first_ttest",
        "siftrank_last_ttest",
    )
    return {
        field: candidate.get(field)
        for field in fields
        if field in candidate
    }


def build_payload(
    *,
    args: argparse.Namespace,
    prompt: str,
    request_max_tokens: int,
) -> tuple[dict[str, Any], int | None]:
    payload: dict[str, Any] = {
        "model": args.model,
        "messages": [
            {
                "role": "user",
                "content": prompt,
            }
        ],
        "temperature": args.temperature,
        "max_tokens": request_max_tokens,
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": (
                    "uaf_free_before_use_analysis_v3"
                ),
                "schema": ANALYSIS_SCHEMA,
            },
        },
    }

    if args.top_p is not None:
        payload["top_p"] = args.top_p
    if args.top_k is not None:
        payload["top_k"] = args.top_k

    effective_thinking_budget: int | None = None
    if args.thinking_token_budget is not None:
        maximum_thinking = (
            request_max_tokens
            - args.final_token_reserve
        )
        if maximum_thinking > 0:
            effective_thinking_budget = min(
                args.thinking_token_budget,
                maximum_thinking,
            )
            payload["thinking_token_budget"] = (
                effective_thinking_budget
            )

    return payload, effective_thinking_budget


def is_retryable_http(status: int) -> bool:
    return (
        status in {408, 409, 425, 429}
        or status >= 500
    )


def analyze_one(
    task: tuple[
        int,
        int,
        dict[str, Any],
        argparse.Namespace,
        str,
        Any,
    ],
) -> dict[str, Any]:
    (
        index,
        total,
        candidate,
        args,
        instructions,
        tokenizer,
    ) = task

    started = time.time()
    preferred_mode: str | None = None
    correction: str | None = None

    last_error: str | None = None
    last_error_type: str | None = None
    last_content: str | None = None
    last_reasoning: str | None = None
    last_analysis: dict[str, Any] | None = None
    last_validation_errors: list[str] = []
    last_request_metadata: dict[str, Any] | None = None
    attempts = 0

    for attempt in range(
        args.retries + 1
    ):
        attempts = attempt + 1

        try:
            (
                prompt,
                prompt_tokens,
                request_max_tokens,
                render_mode,
            ) = prepare_request_text(
                candidate=candidate,
                instructions=instructions,
                tokenizer=tokenizer,
                max_model_len=args.max_model_len,
                requested_max_tokens=args.max_tokens,
                context_margin=args.context_margin,
                min_output_tokens=(
                    args.min_output_tokens
                ),
                correction=correction,
                preferred_mode=preferred_mode,
            )
            preferred_mode = render_mode

            (
                payload,
                effective_thinking_budget,
            ) = build_payload(
                args=args,
                prompt=prompt,
                request_max_tokens=(
                    request_max_tokens
                ),
            )

            last_request_metadata = {
                "render_mode": render_mode,
                "prompt_tokens_local": (
                    prompt_tokens
                ),
                "max_tokens": request_max_tokens,
                "thinking_token_budget": (
                    effective_thinking_budget
                ),
                "max_model_len": (
                    args.max_model_len
                ),
                "context_margin": (
                    args.context_margin
                ),
                "candidate_format": "xml-v1",
                "analysis_schema": "uaf-v3",
            }

        except Exception as exc:
            last_error_type = (
                "prompt_preparation"
            )
            last_error = repr(exc)
            break

        try:
            response = post_chat(
                args.base_url,
                args.api_key,
                payload,
                args.timeout,
            )

            message = response["choices"][0][
                "message"
            ]
            content = (
                message.get("content") or ""
            )
            reasoning = (
                message.get("reasoning")
                or message.get(
                    "reasoning_content"
                )
            )

            last_content = content
            last_reasoning = reasoning

            try:
                analysis = extract_json_object(
                    content
                )
            except Exception as exc:
                last_analysis = None
                last_validation_errors = [
                    (
                        "final content was not "
                        "a valid JSON object"
                    )
                ]
                last_error_type = "output_parse"
                last_error = repr(exc)
            else:
                validation_errors = (
                    validate_analysis(
                        analysis,
                        candidate,
                    )
                )
                last_analysis = analysis
                last_validation_errors = (
                    validation_errors
                )

                if not validation_errors:
                    return {
                        "ok": True,
                        "index": index,
                        "total": total,
                        "analysis_id": (
                            candidate.get(
                                "analysis_id"
                            )
                        ),
                        "selection": (
                            selection_metadata(
                                candidate
                            )
                        ),
                        "relation": (
                            candidate.get(
                                "relation"
                            )
                        ),
                        "call_chain": (
                            candidate.get(
                                "call_chain"
                            )
                        ),
                        "free": candidate.get(
                            "free"
                        ),
                        "use": candidate.get(
                            "use"
                        ),
                        "analysis": analysis,
                        "reasoning": reasoning,
                        "raw_response": content,
                        "request": (
                            last_request_metadata
                        ),
                        "usage": (
                            response.get("usage")
                            or {}
                        ),
                        "validation_errors": [],
                        "error_type": None,
                        "error": None,
                        "elapsed_seconds": round(
                            time.time() - started,
                            3,
                        ),
                        "attempts": attempts,
                    }

                last_error_type = (
                    "semantic_validation"
                )
                last_error = "; ".join(
                    validation_errors
                )

            if attempt < args.retries:
                details = (
                    last_validation_errors
                    or [
                        last_error
                        or "unknown output error"
                    ]
                )
                correction = (
                    "The previous final JSON "
                    "was invalid or internally "
                    "inconsistent:\n- "
                    + "\n- ".join(details)
                )
                continue

        except HTTPRequestError as exc:
            last_error_type = (
                "http_retryable"
                if is_retryable_http(
                    exc.status
                )
                else "http_nonretryable"
            )
            last_error = str(exc)

            if (
                attempt < args.retries
                and is_retryable_http(
                    exc.status
                )
            ):
                time.sleep(
                    min(
                        10,
                        1 + attempt * 2,
                    )
                )
                continue
            break

        except Exception as exc:
            last_error_type = "transport"
            last_error = repr(exc)

            if attempt < args.retries:
                time.sleep(
                    min(
                        10,
                        1 + attempt * 2,
                    )
                )
                continue
            break

    return {
        "ok": False,
        "index": index,
        "total": total,
        "analysis_id": candidate.get(
            "analysis_id"
        ),
        "selection": selection_metadata(
            candidate
        ),
        "relation": candidate.get(
            "relation"
        ),
        "call_chain": candidate.get(
            "call_chain"
        ),
        "free": candidate.get("free"),
        "use": candidate.get("use"),
        "analysis": last_analysis,
        "reasoning": last_reasoning,
        "raw_response": last_content,
        "request": last_request_metadata,
        "validation_errors": (
            last_validation_errors
        ),
        "error_type": last_error_type,
        "error": last_error,
        "elapsed_seconds": round(
            time.time() - started,
            3,
        ),
        "attempts": attempts,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        required=True,
    )
    parser.add_argument(
        "--prompt",
        required=True,
    )
    parser.add_argument(
        "--output",
        required=True,
    )
    parser.add_argument(
        "--base-url",
        default="http://localhost:8000/v1",
    )
    parser.add_argument(
        "--model",
        default="WeiboAI/VibeThinker-3B",
    )
    parser.add_argument(
        "--tokenizer",
        default=None,
        help=(
            "Tokenizer name/path; "
            "defaults to --model."
        ),
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get(
            "OPENAI_API_KEY",
            "dummy",
        ),
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=20,
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=25000,
    )
    parser.add_argument(
        "--thinking-token-budget",
        type=int,
        default=22000,
    )
    parser.add_argument(
        "--final-token-reserve",
        type=int,
        default=1536,
    )
    parser.add_argument(
        "--max-model-len",
        type=int,
        default=65536,
    )
    parser.add_argument(
        "--context-margin",
        type=int,
        default=512,
    )
    parser.add_argument(
        "--min-output-tokens",
        type=int,
        default=4096,
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=2400,
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=2,
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=0.95,
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=-1,
    )
    parser.add_argument(
        "--append",
        action="store_true",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
    )
    parser.add_argument(
        "--no-fsync",
        action="store_true",
    )
    args = parser.parse_args()

    candidates = load_json(args.input)
    instructions = Path(
        args.prompt
    ).read_text(
        encoding="utf-8"
    )

    if not isinstance(
        candidates,
        list,
    ):
        raise SystemExit(
            "--input must contain "
            "a JSON array"
        )

    tokenizer = load_tokenizer(
        args.tokenizer
        or args.model
    )

    existing = (
        load_existing_successes(
            args.output
        )
        if args.skip_existing
        else set()
    )
    pending = [
        candidate
        for candidate in candidates
        if candidate.get(
            "analysis_id"
        )
        not in existing
    ]

    total = len(pending)
    tasks = [
        (
            index + 1,
            total,
            candidate,
            args,
            instructions,
            tokenizer,
        )
        for index, candidate
        in enumerate(pending)
    ]

    mode = (
        "a"
        if args.append
        else "w"
    )

    with open(
        args.output,
        mode,
        encoding="utf-8",
    ) as output_handle:
        with cf.ThreadPoolExecutor(
            max_workers=args.concurrency
        ) as executor:
            futures = [
                executor.submit(
                    analyze_one,
                    task,
                )
                for task in tasks
            ]

            completed = 0
            for future in cf.as_completed(
                futures
            ):
                completed += 1
                result = future.result()

                output_handle.write(
                    json.dumps(
                        result,
                        separators=(",", ":"),
                    )
                    + "\n"
                )
                output_handle.flush()
                if not args.no_fsync:
                    os.fsync(
                        output_handle.fileno()
                    )

                status = (
                    "ok"
                    if result.get("ok")
                    else "ERR"
                )
                analysis = (
                    result.get("analysis")
                    or {}
                )
                request = (
                    result.get("request")
                    or {}
                )

                print(
                    f"{status} "
                    f"{completed}/{total} "
                    f"{result.get('analysis_id')} "
                    f"ordering="
                    f"{analysis.get('ordering') or '-'} "
                    f"verdict="
                    f"{analysis.get('verdict') or '-'} "
                    f"mode="
                    f"{request.get('render_mode') or '-'} "
                    f"prompt="
                    f"{request.get('prompt_tokens_local') or '-'} "
                    f"max_out="
                    f"{request.get('max_tokens') or '-'} "
                    f"think="
                    f"{request.get('thinking_token_budget') or '-'} "
                    f"error="
                    f"{result.get('error_type') or '-'} "
                    f"elapsed="
                    f"{result.get('elapsed_seconds')}s "
                    f"attempts="
                    f"{result.get('attempts')}",
                    file=sys.stderr,
                    flush=True,
                )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

