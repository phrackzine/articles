#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="$ROOT_DIR/.venv/bin/python"

MODEL="${MODEL:-WeiboAI/VibeThinker-3B}"
BASE_URL="${BASE_URL:-http://localhost:8000/v1}"

ROUND="${ROUND:-5}"
INPUT="${INPUT:-$ROOT_DIR/output/ksmbd-uaf-round${ROUND}-analysis-input.json}"
PROMPT="${PROMPT:-$ROOT_DIR/prompts/uaf-reachability-analysis.txt}"

RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output/uaf-vibethinker-runs}"
OUTPUT="${OUTPUT:-$OUTPUT_DIR/run-$RUN_ID.jsonl}"

CONCURRENCY="${CONCURRENCY:-20}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-65536}"
MAX_TOKENS="${MAX_TOKENS:-25000}"
THINKING_TOKEN_BUDGET="${THINKING_TOKEN_BUDGET:-22000}"
FINAL_TOKEN_RESERVE="${FINAL_TOKEN_RESERVE:-1536}"
CONTEXT_MARGIN="${CONTEXT_MARGIN:-512}"
MIN_OUTPUT_TOKENS="${MIN_OUTPUT_TOKENS:-4096}"
TIMEOUT="${TIMEOUT:-2400}"
RETRIES="${RETRIES:-10}"

TEMPERATURE="${TEMPERATURE:-1.0}"
TOP_P="${TOP_P:-0.95}"
TOP_K="${TOP_K:--1}"
RESUME="${RESUME:-0}"

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

[[ -x "$PYTHON_BIN" ]] || die "Python not found at $PYTHON_BIN"
[[ -f "$INPUT" ]] || die "analysis input not found: $INPUT"
[[ -f "$PROMPT" ]] || die "analysis prompt not found: $PROMPT"

mkdir -p "$OUTPUT_DIR"

resume_args=()
if [[ "$RESUME" == "1" ]]; then
    resume_args+=(--append --skip-existing)
fi

cat <<EOF
UAF analysis run
Model: $MODEL
Base URL: $BASE_URL
Input: $INPUT
Prompt: $PROMPT
Output: $OUTPUT
Concurrency: $CONCURRENCY
Max model length: $MAX_MODEL_LEN
Max output tokens: $MAX_TOKENS
Thinking token budget: $THINKING_TOKEN_BUDGET
Final token reserve: $FINAL_TOKEN_RESERVE
Context margin: $CONTEXT_MARGIN
Minimum output tokens: $MIN_OUTPUT_TOKENS
Retries: $RETRIES
Resume: $RESUME
EOF

exec "$PYTHON_BIN" \
    "$ROOT_DIR/scripts/analyze_uaf_candidates.py" \
    --base-url "$BASE_URL" \
    --model "$MODEL" \
    --input "$INPUT" \
    --prompt "$PROMPT" \
    --output "$OUTPUT" \
    --concurrency "$CONCURRENCY" \
    --max-model-len "$MAX_MODEL_LEN" \
    --max-tokens "$MAX_TOKENS" \
    --thinking-token-budget "$THINKING_TOKEN_BUDGET" \
    --final-token-reserve "$FINAL_TOKEN_RESERVE" \
    --context-margin "$CONTEXT_MARGIN" \
    --min-output-tokens "$MIN_OUTPUT_TOKENS" \
    --timeout "$TIMEOUT" \
    --retries "$RETRIES" \
    --temperature "$TEMPERATURE" \
    --top-p "$TOP_P" \
    --top-k "$TOP_K" \
    "${resume_args[@]}" \
    "$@"
