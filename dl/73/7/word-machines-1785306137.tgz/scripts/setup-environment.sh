#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

BIN_DIR="$ROOT_DIR/bin"
VENV_DIR="$ROOT_DIR/.venv"

SLICE_DIR="$ROOT_DIR/slice"
SIFTRANK_DIR="$ROOT_DIR/siftrank"
SIFTRANK_CLIENT_DIR="$SIFTRANK_DIR/client"
SIFTRANK_SERVER_DIR="$SIFTRANK_DIR/server"

VLLM_DIR="${VLLM_DIR:-$ROOT_DIR/vllm-main}"
VLLM_REPOSITORY="${VLLM_REPOSITORY:-https://github.com/vllm-project/vllm.git}"
VLLM_COMMIT="${VLLM_COMMIT:-ace9fda495bc9a132584e054cc909d504164141f}"

PYTHON_VERSION="${PYTHON_VERSION:-3.12.12}"

TORCH_BACKEND="${TORCH_BACKEND:-cu130}"
TORCH_VERSION="${TORCH_VERSION:-2.11.0+cu130}"
TORCH_CUDA_VERSION="${TORCH_CUDA_VERSION:-13.0}"

TRANSFORMERS_VERSION="${TRANSFORMERS_VERSION:-5.14.1}"
FLASHINFER_VERSION="${FLASHINFER_VERSION:-0.6.13}"

VLLM_PRECOMPILED_WHEEL_VARIANT="${VLLM_PRECOMPILED_WHEEL_VARIANT:-cu130}"
EXPECTED_VLLM_VERSION="${EXPECTED_VLLM_VERSION:-0.23.1rc1.dev1275+gace9fda49.precompiled}"

EXPECTED_SIFTRANK_VERSION="${EXPECTED_SIFTRANK_VERSION:-0.12.2}"
EXPECTED_PROTOCOL="${EXPECTED_PROTOCOL:-final-ranking-v4.9}"

PLUGIN_NAME="${PLUGIN_NAME:-siftrank_endpoint}"
PLUGIN_ENTRYPOINT="${PLUGIN_ENTRYPOINT:-vllm_siftrank.plugin:SiftRankEndpointPlugin}"

CUDA_HOME="${CUDA_HOME:-/usr/local/cuda-13.0}"

RESET_VENV="${RESET_VENV:-0}"
RUN_TESTS="${RUN_TESTS:-1}"
VERIFY_GPU="${VERIFY_GPU:-1}"

PYTHON_BIN="$VENV_DIR/bin/python"
VLLM_BIN="$VENV_DIR/bin/vllm"

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 ||
        die "required command not found: $1"
}

require_directory() {
    [[ -d "$1" ]] ||
        die "required directory not found: $1"
}

require_file() {
    [[ -f "$1" ]] ||
        die "required file not found: $1"
}

require_executable() {
    [[ -x "$1" ]] ||
        die "required executable not found: $1"
}

build_go_binary() {
    local name="$1"
    local source_dir="$2"
    local package="$3"
    local output="$4"

    require_file "$source_dir/go.mod"

    printf 'Building %s...\n' "$name"

    (
        cd "$source_dir"
        go build \
            -trimpath \
            -o "$output" \
            "$package"
    )

    printf 'Built %s\n' "$output"
}

ensure_vllm_checkout() {
    if [[ ! -e "$VLLM_DIR" ]]; then
        printf 'Cloning vLLM into %s...\n' "$VLLM_DIR"
        git clone "$VLLM_REPOSITORY" "$VLLM_DIR"
    fi

    [[ -d "$VLLM_DIR/.git" ]] ||
        die "vLLM directory is not a Git checkout: $VLLM_DIR"

    local actual_remote
    actual_remote="$(
        git -C "$VLLM_DIR" remote get-url origin
    )"

    [[ "$actual_remote" == "$VLLM_REPOSITORY" ]] ||
        die "unexpected vLLM origin: $actual_remote"

    if [[ -n "$(git -C "$VLLM_DIR" status --porcelain)" ]]; then
        die "vLLM checkout has uncommitted or untracked changes: $VLLM_DIR"
    fi

    local actual_commit
    actual_commit="$(
        git -C "$VLLM_DIR" rev-parse HEAD
    )"

    if [[ "$actual_commit" != "$VLLM_COMMIT" ]]; then
        printf 'Checking out vLLM commit %s...\n' "$VLLM_COMMIT"

        git -C "$VLLM_DIR" fetch origin "$VLLM_COMMIT"
        git -C "$VLLM_DIR" checkout --detach "$VLLM_COMMIT"
    fi

    actual_commit="$(
        git -C "$VLLM_DIR" rev-parse HEAD
    )"

    [[ "$actual_commit" == "$VLLM_COMMIT" ]] ||
        die "expected vLLM commit $VLLM_COMMIT, found $actual_commit"

    if [[ -n "$(git -C "$VLLM_DIR" status --porcelain)" ]]; then
        die "vLLM checkout is dirty after checkout: $VLLM_DIR"
    fi

    printf 'vLLM checkout: %s\n' "$actual_commit"
}

prepare_virtual_environment() {
    printf 'Preparing Python environment...\n'

    if [[ "$RESET_VENV" == "1" && -e "$VENV_DIR" ]]; then
        printf 'Removing existing virtual environment: %s\n' "$VENV_DIR"
        rm -rf "$VENV_DIR"
    fi

    if [[ ! -x "$PYTHON_BIN" ]]; then
        uv venv \
            --python "$PYTHON_VERSION" \
            "$VENV_DIR"
    else
        printf 'Reusing existing virtual environment: %s\n' "$VENV_DIR"

        local actual_python_version
        actual_python_version="$(
            "$PYTHON_BIN" -c \
                'import platform; print(platform.python_version())'
        )"

        [[ "$actual_python_version" == "$PYTHON_VERSION" ]] ||
            die \
                "existing environment uses Python $actual_python_version; " \
                "expected $PYTHON_VERSION. Re-run with RESET_VENV=1"
    fi
}

install_python_environment() {
    printf 'Installing editable vLLM and pinned runtime packages...\n'
    printf 'This may download a large precompiled vLLM wheel.\n'

    # The precompiled vLLM package declares flashinfer-python==0.6.14.
    # Install vLLM and its normal dependency set first, then replace the
    # FlashInfer packages with the matched 0.6.13 pair known to work here.
    VLLM_USE_PRECOMPILED=1 \
        VLLM_PRECOMPILED_WHEEL_COMMIT="$VLLM_COMMIT" \
        VLLM_PRECOMPILED_WHEEL_VARIANT="$VLLM_PRECOMPILED_WHEEL_VARIANT" \
        uv pip install \
        --python "$PYTHON_BIN" \
        --torch-backend "$TORCH_BACKEND" \
        --prerelease=allow \
        --editable "$VLLM_DIR" \
        "torch==$TORCH_VERSION" \
        "transformers==$TRANSFORMERS_VERSION"

    printf 'Applying known-good FlashInfer %s override...\n' \
        "$FLASHINFER_VERSION"

    # Keep flashinfer-python and flashinfer-cubin on exactly the same version.
    # --no-deps prevents flashinfer-python from pulling the incompatible cubin
    # package selected by its normal dependency metadata.
    uv pip install \
        --python "$PYTHON_BIN" \
        --reinstall \
        --no-deps \
        "flashinfer-python==$FLASHINFER_VERSION" \
        "flashinfer-cubin==$FLASHINFER_VERSION"

    printf 'Installing bundled SiftRank endpoint plugin...\n'

    uv pip install \
        --python "$PYTHON_BIN" \
        --reinstall \
        --no-deps \
        --editable "$SIFTRANK_SERVER_DIR"

    if [[ "$RUN_TESTS" == "1" ]]; then
        printf 'Installing Python test dependency...\n'

        uv pip install \
            --python "$PYTHON_BIN" \
            'pytest>=8,<9'
    fi
}

test_go_projects() {
    if [[ "$RUN_TESTS" != "1" ]]; then
        return
    fi

    printf 'Testing Slice...\n'
    (
        cd "$SLICE_DIR"
        go test ./...
        go vet ./...
    )

    printf 'Testing SiftRank client...\n'
    (
        cd "$SIFTRANK_CLIENT_DIR"
        go test ./...
        go vet ./...
    )
}

test_python_project() {
    if [[ "$RUN_TESTS" != "1" ]]; then
        return
    fi

    printf 'Testing SiftRank endpoint package...\n'

    "$PYTHON_BIN" -m pytest \
        -q \
        "$SIFTRANK_SERVER_DIR/tests"

    printf 'Checking Python analysis script...\n'

    "$PYTHON_BIN" -m py_compile \
        "$ROOT_DIR/scripts/analyze_uaf_candidates.py"
}

check_shell_scripts() {
    printf 'Checking shell-script syntax...\n'

    local script
    while IFS= read -r -d '' script; do
        bash -n "$script"
    done < <(
        find "$ROOT_DIR/scripts" \
            -maxdepth 1 \
            -type f \
            -name '*.sh' \
            -print0
    )
}

verify_installation() {
    printf 'Verifying installation...\n'

    require_executable "$BIN_DIR/slice"
    require_executable "$BIN_DIR/siftrank"
    require_executable "$PYTHON_BIN"
    require_executable "$VLLM_BIN"

    "$BIN_DIR/slice" --help >/dev/null 2>&1
    "$BIN_DIR/siftrank" --help >/dev/null 2>&1

    # Do not invoke `vllm --version` here. The vLLM CLI initializes device
    # configuration even for version output. The Python verification below checks
    # the distribution version, imported version, and editable source location.

    VLLM_DIR="$VLLM_DIR" \
        SIFTRANK_SERVER_DIR="$SIFTRANK_SERVER_DIR" \
        EXPECTED_VLLM_VERSION="$EXPECTED_VLLM_VERSION" \
        EXPECTED_SIFTRANK_VERSION="$EXPECTED_SIFTRANK_VERSION" \
        EXPECTED_PROTOCOL="$EXPECTED_PROTOCOL" \
        EXPECTED_TORCH_VERSION="$TORCH_VERSION" \
        EXPECTED_TORCH_CUDA_VERSION="$TORCH_CUDA_VERSION" \
        EXPECTED_TRANSFORMERS_VERSION="$TRANSFORMERS_VERSION" \
        EXPECTED_FLASHINFER_VERSION="$FLASHINFER_VERSION" \
        PLUGIN_NAME="$PLUGIN_NAME" \
        PLUGIN_ENTRYPOINT="$PLUGIN_ENTRYPOINT" \
        VERIFY_GPU="$VERIFY_GPU" \
        "$PYTHON_BIN" - <<'PY'
from __future__ import annotations

import importlib.metadata as md
import json
import os
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

import torch
import transformers
import vllm
import vllm_siftrank

from vllm_siftrank.logits_processor import SiftRankLogitsProcessor
from vllm_siftrank.plugin import SiftRankEndpointPlugin
from vllm_siftrank.protocol import PROTOCOL_VERSION


def fail(message: str) -> None:
    print(f"error: {message}", file=sys.stderr)
    raise SystemExit(1)


def require_equal(name: str, actual: str, expected: str) -> None:
    if actual != expected:
        fail(f"{name}: expected {expected!r}, found {actual!r}")


def require_module_under(
    name: str,
    module_file: str | None,
    expected_root: Path,
) -> Path:
    if not module_file:
        fail(f"{name} does not expose __file__")

    actual = Path(module_file).resolve()
    expected_root = expected_root.resolve()

    if actual != expected_root and expected_root not in actual.parents:
        fail(
            f"{name} loaded from {actual}; "
            f"expected beneath {expected_root}"
        )

    return actual


def editable_source(package: str) -> Path:
    dist = md.distribution(package)
    raw = dist.read_text("direct_url.json")

    if not raw:
        fail(f"{package} has no direct_url.json metadata")

    data = json.loads(raw)

    if not data.get("dir_info", {}).get("editable"):
        fail(f"{package} is not installed editable")

    parsed = urlparse(data["url"])

    if parsed.scheme != "file":
        fail(
            f"{package} editable source is not a file URL: "
            f"{data['url']}"
        )

    return Path(unquote(parsed.path)).resolve()


expected_vllm_root = Path(os.environ["VLLM_DIR"]).resolve()
expected_siftrank_root = Path(
    os.environ["SIFTRANK_SERVER_DIR"]
).resolve()

expected_vllm_version = os.environ["EXPECTED_VLLM_VERSION"]
expected_vllm_module_version = expected_vllm_version.removesuffix(
    ".precompiled"
)
expected_siftrank_version = os.environ[
    "EXPECTED_SIFTRANK_VERSION"
]
expected_protocol = os.environ["EXPECTED_PROTOCOL"]
expected_torch_version = os.environ["EXPECTED_TORCH_VERSION"]
expected_torch_cuda = os.environ[
    "EXPECTED_TORCH_CUDA_VERSION"
]
expected_transformers = os.environ[
    "EXPECTED_TRANSFORMERS_VERSION"
]
expected_flashinfer = os.environ[
    "EXPECTED_FLASHINFER_VERSION"
]

plugin_name = os.environ["PLUGIN_NAME"]
expected_entrypoint = os.environ["PLUGIN_ENTRYPOINT"]
verify_gpu = os.environ["VERIFY_GPU"] == "1"

vllm_dist_version = md.version("vllm")
siftrank_dist_version = md.version(
    "vllm-siftrank-endpoint"
)
flashinfer_python = md.version("flashinfer-python")
flashinfer_cubin = md.version("flashinfer-cubin")

require_equal(
    "vLLM distribution version",
    vllm_dist_version,
    expected_vllm_version,
)
require_equal(
    "vLLM module version",
    vllm.__version__,
    expected_vllm_module_version,
)
require_equal(
    "Torch version",
    torch.__version__,
    expected_torch_version,
)
require_equal(
    "Torch CUDA version",
    str(torch.version.cuda),
    expected_torch_cuda,
)
require_equal(
    "Transformers version",
    transformers.__version__,
    expected_transformers,
)
require_equal(
    "flashinfer-python version",
    flashinfer_python,
    expected_flashinfer,
)
require_equal(
    "flashinfer-cubin version",
    flashinfer_cubin,
    expected_flashinfer,
)
require_equal(
    "SiftRank distribution version",
    siftrank_dist_version,
    expected_siftrank_version,
)
require_equal(
    "SiftRank module version",
    vllm_siftrank.__version__,
    expected_siftrank_version,
)
require_equal(
    "SiftRank protocol",
    PROTOCOL_VERSION,
    expected_protocol,
)

vllm_module = require_module_under(
    "vllm",
    vllm.__file__,
    expected_vllm_root,
)
siftrank_module = require_module_under(
    "vllm_siftrank",
    vllm_siftrank.__file__,
    expected_siftrank_root,
)

vllm_editable = editable_source("vllm")
siftrank_editable = editable_source(
    "vllm-siftrank-endpoint"
)

if vllm_editable != expected_vllm_root:
    fail(
        f"vLLM editable source is {vllm_editable}; "
        f"expected {expected_vllm_root}"
    )

if siftrank_editable != expected_siftrank_root:
    fail(
        f"SiftRank editable source is {siftrank_editable}; "
        f"expected {expected_siftrank_root}"
    )

entrypoints = {
    ep.name: ep.value
    for ep in md.entry_points(
        group="vllm.endpoint_plugins"
    )
}

actual_entrypoint = entrypoints.get(plugin_name)

if actual_entrypoint != expected_entrypoint:
    fail(
        f"expected endpoint plugin {plugin_name!r} -> "
        f"{expected_entrypoint!r}, "
        f"found {actual_entrypoint!r}"
    )

if verify_gpu and not torch.cuda.is_available():
    fail("torch.cuda.is_available() returned false")

device_name = (
    torch.cuda.get_device_name(0)
    if torch.cuda.is_available()
    else "not available"
)

print(f"Python:                {sys.version.split()[0]}")
print(f"Torch:                 {torch.__version__}")
print(f"Torch CUDA:            {torch.version.cuda}")
print(f"CUDA device:           {device_name}")
print(f"Transformers:          {transformers.__version__}")
print(f"FlashInfer:            {flashinfer_python}")
print(f"vLLM:                  {vllm_dist_version}")
print(f"vLLM module:           {vllm_module}")
print(f"vLLM editable source:  {vllm_editable}")
print(f"SiftRank distribution: {siftrank_dist_version}")
print(f"SiftRank module:       {siftrank_module}")
print(f"SiftRank source:       {siftrank_editable}")
print(f"SiftRank protocol:     {PROTOCOL_VERSION}")
print(
    f"Endpoint plugin:       "
    f"{plugin_name} -> {actual_entrypoint}"
)
PY
}

print_summary() {
    local actual_python_version
    local actual_vllm_commit

    actual_python_version="$(
        "$PYTHON_BIN" -c \
            'import platform; print(platform.python_version())'
    )"

    actual_vllm_commit="$(
        git -C "$VLLM_DIR" rev-parse HEAD
    )"

    printf '\nSetup complete.\n'
    printf 'Repository: %s\n' "$ROOT_DIR"
    printf 'Slice:      %s\n' "$BIN_DIR/slice"
    printf 'SiftRank:   %s\n' "$BIN_DIR/siftrank"
    printf 'Python:     %s (%s)\n' \
        "$PYTHON_BIN" \
        "$actual_python_version"
    printf 'vLLM:       %s\n' "$VLLM_BIN"
    printf 'vLLM source:%s\n' " $VLLM_DIR"
    printf 'vLLM commit:%s\n' " $actual_vllm_commit"

    printf '\nRun sequence:\n'
    printf '  1. ./scripts/serve-siftrank-model.sh\n'
    printf '  2. ./scripts/run-ksmbd-uaf-ranking-pipeline.sh\n'
    printf '  3. ./scripts/prepare-uaf-analysis-candidates.sh\n'
    printf '  4. Stop the SiftRank server\n'
    printf '  5. ./scripts/serve-uaf-analysis-model.sh\n'
    printf '  6. ./scripts/run-uaf-deep-analysis.sh\n'
}

require_command git
require_command go
require_command uv

require_directory "$SLICE_DIR"
require_directory "$SIFTRANK_CLIENT_DIR"
require_directory "$SIFTRANK_SERVER_DIR"

require_file "$SLICE_DIR/go.mod"
require_file "$SIFTRANK_CLIENT_DIR/go.mod"
require_file "$SIFTRANK_SERVER_DIR/pyproject.toml"

[[ -x "$CUDA_HOME/bin/nvcc" ]] ||
    die "CUDA compiler not found at $CUDA_HOME/bin/nvcc"

nvcc_release="$(
    "$CUDA_HOME/bin/nvcc" --version |
        sed -nE \
            's/.*release ([0-9]+\.[0-9]+).*/\1/p' |
        head -n 1
)"

[[ "$nvcc_release" == 13.* ]] ||
    die \
        "expected CUDA 13 nvcc, found " \
        "${nvcc_release:-unknown}"

export CUDA_HOME
export PATH="$CUDA_HOME/bin:$PATH"

mkdir -p "$BIN_DIR"

ensure_vllm_checkout
prepare_virtual_environment
test_go_projects

build_go_binary \
    "Slice" \
    "$SLICE_DIR" \
    "./cmd/slice" \
    "$BIN_DIR/slice"

build_go_binary \
    "SiftRank" \
    "$SIFTRANK_CLIENT_DIR" \
    "./cmd/siftrank" \
    "$BIN_DIR/siftrank"

install_python_environment
test_python_project
check_shell_scripts
verify_installation
print_summary
