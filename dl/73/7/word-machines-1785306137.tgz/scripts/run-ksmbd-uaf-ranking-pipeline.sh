#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SLICE_BIN="${SLICE_BIN:-$ROOT_DIR/bin/slice}"
SIFTRANK_BIN="${SIFTRANK_BIN:-$ROOT_DIR/bin/siftrank}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output}"
LOG_DIR="${LOG_DIR:-$OUTPUT_DIR/logs}"
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
RUN_LOG="$LOG_DIR/run-$RUN_ID.log"

BASE_URL="${BASE_URL:-http://127.0.0.1:8000}"
TEMPERATURE="${TEMPERATURE:-0.0}"
ENDPOINT_MAX_RETRIES="${ENDPOINT_MAX_RETRIES:-1}"
P_VALUE="${P_VALUE:-0.0001}"
CALL_DEPTH="${CALL_DEPTH:-1}"

SOURCE_BATCH_SIZE="${SOURCE_BATCH_SIZE:-5}"
SOURCE_CONCURRENCY="${SOURCE_CONCURRENCY:-100}"
SOURCE_TRIALS="${SOURCE_TRIALS:-10}"
SOURCE_REASONING_BUDGETS="${SOURCE_REASONING_BUDGETS:-1000}"

PAIR_BATCH_SIZE="${PAIR_BATCH_SIZE:-5}"
PAIR_CONCURRENCY="${PAIR_CONCURRENCY:-100}"
PAIR_TRIALS="${PAIR_TRIALS:-10}"
PAIR_REASONING_BUDGETS="${PAIR_REASONING_BUDGETS:-1000,2000,3000,4000,5000,6000,7000,8000,9000,10000}"
PAIR_WATCH_ALPHA="${PAIR_WATCH_ALPHA:-0.05}"
PAIR_CARRY_ALPHA="${PAIR_CARRY_ALPHA:-0.5}"

# Capacity-based selection is the default. Set ANALYSIS_ROUND to override it.
ANALYSIS_BUDGET="${ANALYSIS_BUDGET:-200}"
ANALYSIS_ROUND="${ANALYSIS_ROUND:-0}"

KNOWN_FREE_ID="${KNOWN_FREE_ID:-smb2pdu.c:1606}"
KNOWN_USE_ID="${KNOWN_USE_ID:-smb2pdu.c:1910}"

FREE_PROMPT="${FREE_PROMPT:-$ROOT_DIR/prompts/rank-free.txt}"
USE_PROMPT="${USE_PROMPT:-$ROOT_DIR/prompts/rank-use.txt}"
PAIR_PROMPT="${PAIR_PROMPT:-$ROOT_DIR/prompts/rank-reachable-uaf-pairs.txt}"
LINE_TEMPLATE="${LINE_TEMPLATE:-$ROOT_DIR/templates/line-code-only.tpl}"
PAIR_TEMPLATE="${PAIR_TEMPLATE:-$ROOT_DIR/templates/free-use-pair.tpl}"

LINES_FILE="$OUTPUT_DIR/ksmbd-lines.json"
FREE_RANKING_FILE="$OUTPUT_DIR/ksmbd-free.json"
USE_RANKING_FILE="$OUTPUT_DIR/ksmbd-use.json"
FREE_CANDIDATES_FILE="$OUTPUT_DIR/ksmbd-free-p0001.jsonl"
USE_CANDIDATES_FILE="$OUTPUT_DIR/ksmbd-use-p0001.jsonl"
RELATED_FILE="$OUTPUT_DIR/ksmbd-free-use-p0001-d1-chain.jsonl"
PAIRS_FILE="$OUTPUT_DIR/ksmbd-free-use-p0001-d1-pairs.json"
RANKED_PAIRS_FILE="$OUTPUT_DIR/ksmbd-ranked-pairs.json"
FINAL_INPUT_FILE="$OUTPUT_DIR/ksmbd-uaf-final-analysis-input.json"

FREE_TRACE="$LOG_DIR/siftrank-free-$RUN_ID.trace.jsonl"
USE_TRACE="$LOG_DIR/siftrank-use-$RUN_ID.trace.jsonl"
PAIR_TRACE="$LOG_DIR/siftrank-pairs-$RUN_ID.trace.jsonl"
SLICE_LINES_STDOUT_LOG="$LOG_DIR/slice-lines-$RUN_ID.stdout.jsonl"
SLICE_LINES_STDERR_LOG="$LOG_DIR/slice-lines-$RUN_ID.stderr.log"
SLICE_RELATE_STDOUT_LOG="$LOG_DIR/slice-relate-$RUN_ID.stdout.log"
SLICE_RELATE_STDERR_LOG="$LOG_DIR/slice-relate-$RUN_ID.stderr.log"

die() { printf 'error: %s\n' "$*" >&2; exit 1; }
timestamp() { date --iso-8601=seconds; }

require_command() { command -v "$1" >/dev/null 2>&1 || die "required command not found: $1"; }
require_file() { [[ -f "$1" ]] || die "required file not found: $1"; }
require_executable() { [[ -x "$1" ]] || die "required executable not found: $1"; }

detect_source_dir() {
    local candidate
    if [[ -n "${SOURCE_DIR:-}" ]]; then printf '%s\n' "$SOURCE_DIR"; return; fi
    for candidate in \
        "$ROOT_DIR/linux-v6.15-rc2-fs-smb-server" \
        "$ROOT_DIR/linux/fs/smb/server" \
        "$ROOT_DIR/smb/server"; do
        [[ -d "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    return 1
}

run_if_missing() {
    local output="$1" description="$2"
    shift 2
    if [[ -s "$output" ]]; then
        printf '\n==> SKIP: %s\nReusing: %s\n' "$description" "$output"
        return
    fi
    printf '\n==> START: %s\nStarted: %s\n' "$description" "$(timestamp)"
    "$@"
    [[ -s "$output" ]] || die "$description did not produce $output"
    printf 'Completed: %s\nProduced: %s\n' "$(timestamp)" "$output"
}

check_server() {
    local health
    health="$(curl --fail --silent --show-error --max-time 10 "${BASE_URL%/}/v1/siftrank/health")" ||
        die "SiftRank endpoint is unavailable"
    jq . <<<"$health" >"$LOG_DIR/siftrank-health-$RUN_ID.json"
    jq -e '.ok == true and .protocol_version == "final-ranking-v4.9"' >/dev/null <<<"$health" ||
        die "endpoint is not running final-ranking-v4.9"
}

extract_lines() {
    local tmp="$LINES_FILE.tmp"
    rm -f "$tmp" "$SLICE_LINES_STDOUT_LOG" "$SLICE_LINES_STDERR_LOG"
    "$SLICE_BIN" lines --source "$SOURCE_DIR" --ext .c \
        2> >(tee "$SLICE_LINES_STDERR_LOG" >&2) |
        tee "$SLICE_LINES_STDOUT_LOG" | jq -s . >"$tmp"
    jq -e 'type == "array" and length > 0' "$tmp" >/dev/null || die "no source lines"
    mv "$tmp" "$LINES_FILE"
}

rank_source() {
    local prompt="$1" output="$2" trace="$3"
    rm -f "$trace"
    "$SIFTRANK_BIN" \
        --base-url "$BASE_URL" --file "$LINES_FILE" --json \
        --prompt "@$prompt" --template "@$LINE_TEMPLATE" --key-template '{{.id}}' \
        --batch-size "$SOURCE_BATCH_SIZE" --concurrency "$SOURCE_CONCURRENCY" \
        --min-trials "$SOURCE_TRIALS" --max-trials "$SOURCE_TRIALS" --max-rounds 1 \
        --reasoning-token-budgets "$SOURCE_REASONING_BUDGETS" \
        --temperature "$TEMPERATURE" --endpoint-max-retries "$ENDPOINT_MAX_RETRIES" \
        --request-timeout 0 --trace "$trace" --output "$output"
}

filter_candidates() {
    local role="$1" input="$2" output="$3" tmp="$output.tmp"
    jq -c --arg role "$role" --argjson alpha "$P_VALUE" '
      .ranking[]
      | select(.first_ttest.test == "one_sample_student_t")
      | select(.first_ttest.alternative == "less")
      | select(.first_ttest.t < 0 and .first_ttest.p <= $alpha)
      | .document + {
          role: $role,
          rank: .rank,
          rounds: .rounds,
          score: .score,
          first_score: .first_ttest.mean,
          first_ttest: .first_ttest
        }
    ' "$input" >"$tmp"
    [[ -s "$tmp" ]] || die "no $role candidates survived p <= $P_VALUE"
    mv "$tmp" "$output"
}

check_known_targets() {
    local free_present use_present
    free_present="$(jq -s --arg id "$KNOWN_FREE_ID" 'any(.[]; .id == $id)' "$FREE_CANDIDATES_FILE")"
    use_present="$(jq -s --arg id "$KNOWN_USE_ID" 'any(.[]; .id == $id)' "$USE_CANDIDATES_FILE")"
    printf '\nKnown-positive sanity check:\n  free %s: %s\n  use  %s: %s\n' \
        "$KNOWN_FREE_ID" "$free_present" "$KNOWN_USE_ID" "$use_present"
}

relate_candidates() {
    rm -f "$SLICE_RELATE_STDOUT_LOG" "$SLICE_RELATE_STDERR_LOG"
    "$SLICE_BIN" relate \
        --source "$SOURCE_DIR" \
        --left "$FREE_CANDIDATES_FILE" --left-role free \
        --right "$USE_CANDIDATES_FILE" --right-role use \
        --call-depth "$CALL_DEPTH" --include-call-chain --include-defs \
        --output "$RELATED_FILE" \
        > >(tee "$SLICE_RELATE_STDOUT_LOG") \
        2> >(tee "$SLICE_RELATE_STDERR_LOG" >&2)
}

build_pair_documents() {
    local tmp="$PAIRS_FILE.tmp"
    jq -s '
      map({
        relation,
        call_chain: ((.call_chain // []) | map({id,name,file,start_line,end_line,signature})),
        free: {
          id: .left.id, file: .left.file, line: .left.line,
          function: .left.function.name, target: .left.target,
          rank: .left.rank, rounds: .left.rounds, score: .left.score,
          p: (.left.first_ttest.p // null)
        },
        use: {
          id: .right.id, file: .right.file, line: .right.line,
          function: .right.function.name, target: .right.target,
          rank: .right.rank, rounds: .right.rounds, score: .right.score,
          p: (.right.first_ttest.p // null)
        }
      })
    ' "$RELATED_FILE" >"$tmp"
    jq -e 'type == "array" and length > 0' "$tmp" >/dev/null || die "no pair documents"
    mv "$tmp" "$PAIRS_FILE"
}

rank_pairs() {
    local frontier_args=()
    if (( ANALYSIS_ROUND > 0 )); then
        frontier_args+=(--analysis-round "$ANALYSIS_ROUND")
    elif (( ANALYSIS_BUDGET > 0 )); then
        frontier_args+=(--analysis-budget "$ANALYSIS_BUDGET")
    fi
    rm -f "$PAIR_TRACE"
    "$SIFTRANK_BIN" \
        --base-url "$BASE_URL" --file "$PAIRS_FILE" --json \
        --prompt "@$PAIR_PROMPT" --template "@$PAIR_TEMPLATE" \
        --key-template '{{.free.id}}::{{.use.id}}' \
        --batch-size "$PAIR_BATCH_SIZE" --concurrency "$PAIR_CONCURRENCY" \
        --min-trials "$PAIR_TRIALS" --max-trials "$PAIR_TRIALS" \
        --watch-alpha "$PAIR_WATCH_ALPHA" --continue-alpha "$P_VALUE" \
        --carry-alpha "$PAIR_CARRY_ALPHA" \
        --reasoning-token-budgets "$PAIR_REASONING_BUDGETS" \
        --temperature "$TEMPERATURE" --endpoint-max-retries "$ENDPOINT_MAX_RETRIES" \
        --request-timeout 0 --trace "$PAIR_TRACE" --output "$RANKED_PAIRS_FILE" \
        "${frontier_args[@]}"
}

build_final_analysis_input() {
    local tmp="$FINAL_INPUT_FILE.tmp"
    if [[ "$(jq -r '(.analysis_frontier.method == "capacity") and (.analysis_frontier.capacity_met != true)' "$RANKED_PAIRS_FILE")" == true ]]; then
        die "no round entrant cohort fit ANALYSIS_BUDGET=$ANALYSIS_BUDGET; increase the budget or set ANALYSIS_ROUND explicitly"
    fi
    jq -s --slurpfile ranked "$RANKED_PAIRS_FILE" '
      ($ranked[0].analysis_candidates // error("ranking has no analysis_candidates")) as $selected
      | ($selected | map(.document.free.id + "\t" + .document.use.id)) as $keys
      | map(select((.left.id + "\t" + .right.id) as $key | $keys | index($key)))
      | to_entries
      | map(.value as $record | {
          analysis_id: ("uaf_pair_" + ((.key + 1) | tostring)),
          relation: $record.relation,
          call_chain: ($record.call_chain // []),
          free: $record.left,
          use: $record.right
        })
    ' "$RELATED_FILE" >"$tmp"
    jq -e 'type == "array" and length > 0' "$tmp" >/dev/null || die "empty final analysis input"
    mv "$tmp" "$FINAL_INPUT_FILE"
}

print_summary() {
    printf '\n============================================================\nPipeline complete\n'
    jq '{
      protocol_version,
      statistics_version,
      analysis_frontier,
      source_population: (.round_summaries[0].population),
      final_round: (.round_summaries | map(.round) | max),
      analysis_candidates: (.analysis_candidates | length),
      reasoning_terminations: .diagnostics.reasoning_terminations,
      quality_flag_count: .diagnostics.quality_flag_count
    }' "$RANKED_PAIRS_FILE"
    printf 'Final analysis input: %s\n' "$FINAL_INPUT_FILE"
}

if [[ "${RESET_RUN:-0}" == 1 ]]; then rm -rf "$OUTPUT_DIR"; fi
mkdir -p "$OUTPUT_DIR" "$LOG_DIR"
touch "$RUN_LOG"
exec > >(tee -a "$RUN_LOG") 2>&1

for command in jq curl tee sha256sum; do require_command "$command"; done
SOURCE_DIR="$(detect_source_dir)" || die "could not detect source directory; set SOURCE_DIR"
require_executable "$SLICE_BIN"
require_executable "$SIFTRANK_BIN"
for file in "$FREE_PROMPT" "$USE_PROMPT" "$PAIR_PROMPT" "$LINE_TEMPLATE" "$PAIR_TEMPLATE"; do require_file "$file"; done

printf 'Run ID: %s\nStarted: %s\nSource: %s\n' "$RUN_ID" "$(timestamp)" "$SOURCE_DIR"
printf 'SiftRank SHA-256: %s\n' "$(sha256sum "$SIFTRANK_BIN" | awk '{print $1}')"
printf 'Free prompt SHA-256: %s\n' "$(sha256sum "$FREE_PROMPT" | awk '{print $1}')"
printf 'Use prompt SHA-256: %s\n' "$(sha256sum "$USE_PROMPT" | awk '{print $1}')"
printf 'Pair prompt SHA-256: %s\n' "$(sha256sum "$PAIR_PROMPT" | awk '{print $1}')"
printf 'Line template SHA-256: %s\n' "$(sha256sum "$LINE_TEMPLATE" | awk '{print $1}')"
printf 'Pair template SHA-256: %s\n' "$(sha256sum "$PAIR_TEMPLATE" | awk '{print $1}')"
printf 'Temperature: %s\nAnalysis budget: %s\nAnalysis round: %s\n' "$TEMPERATURE" "$ANALYSIS_BUDGET" "$ANALYSIS_ROUND"

check_server
run_if_missing "$LINES_FILE" "Extracting source lines" extract_lines
run_if_missing "$FREE_RANKING_FILE" "Ranking FREE candidates" rank_source "$FREE_PROMPT" "$FREE_RANKING_FILE" "$FREE_TRACE"
run_if_missing "$USE_RANKING_FILE" "Ranking USE candidates" rank_source "$USE_PROMPT" "$USE_RANKING_FILE" "$USE_TRACE"
run_if_missing "$FREE_CANDIDATES_FILE" "Filtering FREE candidates" filter_candidates free "$FREE_RANKING_FILE" "$FREE_CANDIDATES_FILE"
run_if_missing "$USE_CANDIDATES_FILE" "Filtering USE candidates" filter_candidates use "$USE_RANKING_FILE" "$USE_CANDIDATES_FILE"
check_known_targets
run_if_missing "$RELATED_FILE" "Relating FREE and USE candidates" relate_candidates
run_if_missing "$PAIRS_FILE" "Building pair documents" build_pair_documents
run_if_missing "$RANKED_PAIRS_FILE" "Ranking related pairs" rank_pairs
run_if_missing "$FINAL_INPUT_FILE" "Building final analysis input" build_final_analysis_input
print_summary
