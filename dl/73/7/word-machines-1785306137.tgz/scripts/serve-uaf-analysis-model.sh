#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="$ROOT_DIR/.venv/bin/python"
VLLM_BIN="$ROOT_DIR/.venv/bin/vllm"

CUDA_HOME="${CUDA_HOME:-/usr/local/cuda-13.0}"

MODEL="${MODEL:-WeiboAI/VibeThinker-3B}"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8000}"

OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output}"
LOG_DIR="${LOG_DIR:-$OUTPUT_DIR/logs}"

RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
SERVER_LOG="${SERVER_LOG:-$LOG_DIR/vllm-uaf-analysis-$RUN_ID.log}"

MAX_MODEL_LEN="${MAX_MODEL_LEN:-65536}"
GPU_MEMORY_UTILIZATION="${GPU_MEMORY_UTILIZATION:-0.92}"
MAX_NUM_SEQS="${MAX_NUM_SEQS:-100}"
MAX_NUM_BATCHED_TOKENS="${MAX_NUM_BATCHED_TOKENS:-32768}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-32768}"

TEMPERATURE="${TEMPERATURE:-1.0}"
TOP_P="${TOP_P:-0.95}"
TOP_K="${TOP_K:--1}"

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

timestamp() {
    date --iso-8601=seconds
}

[[ -x "$PYTHON_BIN" ]] || die "Python not found at $PYTHON_BIN"
[[ -x "$VLLM_BIN" ]] || die "vLLM not found at $VLLM_BIN"
[[ -x "$CUDA_HOME/bin/nvcc" ]] ||
    die "CUDA compiler not found at $CUDA_HOME/bin/nvcc"

nvcc_release="$(
    "$CUDA_HOME/bin/nvcc" --version |
        sed -nE 's/.*release ([0-9]+\.[0-9]+).*/\1/p' |
        head -n 1
)"

[[ "$nvcc_release" == 13.* ]] ||
    die "expected CUDA 13 nvcc, found ${nvcc_release:-unknown}"

metadata="$(
    "$PYTHON_BIN" - <<'PY'
import importlib.metadata as md
import sys

try:
    import vllm
except Exception as exc:
    print(f"vLLM import failed: {exc}", file=sys.stderr)
    raise SystemExit(1)

flashinfer_python = md.version("flashinfer-python")
flashinfer_cubin = md.version("flashinfer-cubin")

if flashinfer_python != flashinfer_cubin:
    print(
        "flashinfer version mismatch: "
        f"flashinfer-python={flashinfer_python}, "
        f"flashinfer-cubin={flashinfer_cubin}",
        file=sys.stderr,
    )
    raise SystemExit(1)

print(vllm.__version__)
print(vllm.__file__)
print(flashinfer_python)
PY
)" || die "vLLM environment validation failed"

VLLM_VERSION="$(sed -n '1p' <<<"$metadata")"
VLLM_SOURCE="$(sed -n '2p' <<<"$metadata")"
FLASHINFER_VERSION="$(sed -n '3p' <<<"$metadata")"

mkdir -p "$LOG_DIR"
touch "$SERVER_LOG"

cd "$ROOT_DIR"

export CUDA_HOME
export PATH="$CUDA_HOME/bin:$PATH"
export VLLM_PLUGINS=""
export VLLM_USE_FLASHINFER_SAMPLER=0
export VLLM_USE_V2_MODEL_RUNNER=0
unset SIFTRANK_ENDPOINT_TRACE

generation_config="$(
    printf \
        '{"temperature":%s,"top_p":%s,"top_k":%s,"max_new_tokens":%s}' \
        "$TEMPERATURE" "$TOP_P" "$TOP_K" "$MAX_NEW_TOKENS"
)"

exec > >(tee -a "$SERVER_LOG") 2>&1

cat <<EOF
vLLM UAF analysis server launch
Started: $(timestamp)
Run ID: $RUN_ID
Repository: $ROOT_DIR
Model: $MODEL
Address: http://$HOST:$PORT
CUDA_HOME: $CUDA_HOME
nvcc release: $nvcc_release
Python: $PYTHON_BIN
vLLM: $VLLM_BIN
vLLM version: $VLLM_VERSION
vLLM source: $VLLM_SOURCE
FlashInfer version: $FLASHINFER_VERSION
Server log: $SERVER_LOG

Engine settings:
  max model length: $MAX_MODEL_LEN
  GPU memory utilization: $GPU_MEMORY_UTILIZATION
  max sequences: $MAX_NUM_SEQS
  max batched tokens: $MAX_NUM_BATCHED_TOKENS
  prefix caching: enabled
  model runner V2: disabled

Default sampling:
  temperature: $TEMPERATURE
  top_p: $TOP_P
  top_k: $TOP_K
  max_new_tokens: $MAX_NEW_TOKENS

Plugins:
  disabled

Reasoning parser:
  qwen3

Structured final output:
  JSON schema supplied by each analysis request

FlashInfer sampler:
  disabled
EOF

exec "$VLLM_BIN" serve "$MODEL" \
    --host "$HOST" \
    --port "$PORT" \
    --dtype auto \
    --max-model-len "$MAX_MODEL_LEN" \
    --gpu-memory-utilization "$GPU_MEMORY_UTILIZATION" \
    --max-num-seqs "$MAX_NUM_SEQS" \
    --max-num-batched-tokens "$MAX_NUM_BATCHED_TOKENS" \
    --enable-prefix-caching \
    --generation-config vllm \
    --override-generation-config "$generation_config" \
    --reasoning-parser qwen3 \
    "$@"
