#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ROUND="${ROUND:-5}"
RANKED="${RANKED:-$ROOT_DIR/output/ksmbd-ranked-pairs.json}"
RELATIONS="${RELATIONS:-$ROOT_DIR/output/ksmbd-free-use-p0001-d1-chain.jsonl}"
OUTPUT="${OUTPUT:-$ROOT_DIR/output/ksmbd-uaf-round${ROUND}-analysis-input.json}"

die() {
    printf 'error: %s\n' "$*" >&2
    exit 1
}

[[ -f "$RANKED" ]] || die "ranked output not found: $RANKED"
[[ -f "$RELATIONS" ]] || die "relation records not found: $RELATIONS"

mkdir -p "$(dirname "$OUTPUT")"

jq -s \
    --slurpfile ranked "$RANKED" \
    --argjson round "$ROUND" '
  (
    reduce .[] as $relation (
      {};
      .[$relation.left.id + "\t" + $relation.right.id] = $relation
    )
  ) as $relations_by_key
  | [
      $ranked[0].ranking[]
      | select(.rounds >= $round)
      | . as $ranked_item
      | (
          $ranked_item.document.free.id
          + "\t"
          + $ranked_item.document.use.id
        ) as $pair_key
      | $relations_by_key[$pair_key] as $relation
      | select($relation != null)
      | {
          analysis_id: (
            "uaf_pair_r"
            + ($round | tostring)
            + "_"
            + $ranked_item.key
          ),
          siftrank_rank: $ranked_item.rank,
          siftrank_rounds: $ranked_item.rounds,
          siftrank_score: $ranked_item.score,
          siftrank_first_ttest: $ranked_item.first_ttest,
          siftrank_last_ttest: $ranked_item.ttest,
          relation: $relation.relation,
          call_chain: ($relation.call_chain // []),
          free: $relation.left,
          use: $relation.right
        }
    ]
  | sort_by(.siftrank_rank)
' "$RELATIONS" >"$OUTPUT"

expected="$(
    jq --argjson round "$ROUND" \
        '[.ranking[] | select(.rounds >= $round)] | length' \
        "$RANKED"
)"
actual="$(jq length "$OUTPUT")"

printf 'Round: %s\n' "$ROUND"
printf 'Expected selected pairs: %s\n' "$expected"
printf 'Prepared analysis pairs: %s\n' "$actual"
printf 'Output: %s\n' "$OUTPUT"

[[ "$expected" -eq "$actual" ]] ||
    die "join lost $((expected - actual)) selected pair(s)"

missing_definitions="$(
    jq '[.[] | .call_chain[]? | select((.definition // "") == "")] | length' \
       "$OUTPUT"
)"
printf 'Call-chain entries missing definitions: %s\n' "$missing_definitions"
