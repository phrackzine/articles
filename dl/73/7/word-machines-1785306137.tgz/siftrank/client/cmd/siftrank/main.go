package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/noperator/siftrank-vllm/internal/rank"
)

func main() {
	var (
		baseURL        = flag.String("base-url", "http://127.0.0.1:8000", "vLLM server base URL")
		filePath       = flag.String("file", "", "input file")
		promptArg      = flag.String("prompt", "", "ranking prompt or @path")
		templateArg    = flag.String("template", "", "Go template or @path for the model-visible value")
		keyTemplateArg = flag.String("key-template", "", "optional Go template or @path for persistent item identity")
		jsonInput      = flag.Bool("json", false, "input is a JSON array")
		batchSize      = flag.Int("batch-size", 5, "items per endpoint request (2-10)")
		concurrency    = flag.Int("concurrency", 32, "concurrent batch requests")
		minTrials      = flag.Int("min-trials", 3, "minimum completed trials per round")
		maxTrials      = flag.Int("max-trials", 10, "maximum completed trials per round")
		stableTrials   = flag.Int("stable-trials", 3, "consecutive unchanged significant-set sizes needed to stop a round")
		watchAlpha     = flag.Float64("watch-alpha", 0.05, "alpha used for within-round significant-set size")
		continueAlpha  = flag.Float64("continue-alpha", 0.0001, "strict alpha: stop refinement when no item is significant")
		carryAlpha     = flag.Float64("carry-alpha", 0.5, "alpha used to choose items carried into the next round")
		maxRounds      = flag.Int("max-rounds", 0, "maximum refinement rounds; 0 means unlimited")
		budgetsArg     = flag.String("reasoning-token-budgets", "1000", "comma-separated per-round thinking budgets; last repeats")
		maxRetries     = flag.Int("endpoint-max-retries", 2, "server-side malformed/ungrounded-ranking retries")
		temperature    = flag.Float64("temperature", 0, "server generation temperature")
		seed           = flag.Int64("seed", rank.DefaultSeed(), "random seed")
		timeout        = flag.Duration("request-timeout", 0, "HTTP request timeout; 0 disables")
		tracePath      = flag.String("trace", "", "client JSONL trace path")
		analysisBudget = flag.Int("analysis-budget", 0, "choose earliest round whose entrants fit this capacity")
		analysisRound  = flag.Int("analysis-round", 0, "explicit final-analysis entrant round; mutually exclusive with --analysis-budget")
		outputPath     = flag.String("output", "-", "output JSON path or - for stdout")
	)
	flag.Parse()

	if *filePath == "" || *promptArg == "" {
		fmt.Fprintln(os.Stderr, "error: --file and --prompt are required")
		os.Exit(2)
	}
	prompt, err := rank.ReadValue(*promptArg)
	fatalIf(err)
	templateText := ""
	if *templateArg != "" {
		templateText, err = rank.ReadValue(*templateArg)
		fatalIf(err)
	}
	keyTemplateText := ""
	if *keyTemplateArg != "" {
		keyTemplateText, err = rank.ReadValue(*keyTemplateArg)
		fatalIf(err)
	}
	input, err := os.Open(*filePath)
	fatalIf(err)
	documents, err := rank.LoadDocuments(input, *jsonInput, templateText, keyTemplateText)
	_ = input.Close()
	fatalIf(err)
	budgets, err := rank.ParseBudgets(*budgetsArg)
	fatalIf(err)

	client := rank.NewClient(*baseURL, durationOrZero(*timeout))
	runner, err := rank.NewRunner(rank.Config{
		BatchSize: *batchSize, Concurrency: *concurrency,
		MinTrials: *minTrials, MaxTrials: *maxTrials, StableTrials: *stableTrials,
		WatchAlpha: *watchAlpha, ContinueAlpha: *continueAlpha, CarryAlpha: *carryAlpha,
		MaxRounds: *maxRounds, ReasoningBudgets: budgets,
		EndpointMaxRetries: *maxRetries, Temperature: *temperature,
		Seed: *seed, TracePath: *tracePath,
		AnalysisBudget: *analysisBudget, AnalysisRound: *analysisRound,
	}, client)
	fatalIf(err)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	output, err := runner.Run(ctx, documents, prompt)
	fatalIf(err)
	fatalIf(rank.WriteOutput(*outputPath, output))
}

func durationOrZero(value time.Duration) time.Duration { return value }

func fatalIf(err error) {
	if err == nil {
		return
	}
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
	os.Exit(1)
}
