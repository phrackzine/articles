package rank

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

type Document struct {
	Key        string
	Value      string
	Data       any
	InputIndex int
}

type Config struct {
	BatchSize          int     `json:"batch_size"`
	Concurrency        int     `json:"concurrency"`
	MinTrials          int     `json:"min_trials"`
	MaxTrials          int     `json:"max_trials"`
	StableTrials       int     `json:"stable_trials"`
	WatchAlpha         float64 `json:"watch_alpha"`
	ContinueAlpha      float64 `json:"continue_alpha"`
	CarryAlpha         float64 `json:"carry_alpha"`
	MaxRounds          int     `json:"max_rounds"`
	ReasoningBudgets   []int   `json:"reasoning_budgets"`
	EndpointMaxRetries int     `json:"endpoint_max_retries"`
	Temperature        float64 `json:"temperature"`
	Seed               int64   `json:"seed"`
	TracePath          string  `json:"trace_path,omitempty"`
	AnalysisBudget     int     `json:"analysis_budget,omitempty"`
	AnalysisRound      int     `json:"analysis_round,omitempty"`
}

type RoundDocumentStats struct {
	Round           int       `json:"round"`
	Population      int       `json:"population"`
	TargetBatchSize int       `json:"target_batch_size"`
	ReasoningBudget int       `json:"reasoning_budget"`
	Stats           RankStats `json:"stats"`
}

type RankedDocument struct {
	Rank               int                  `json:"rank"`
	Key                string               `json:"key"`
	Value              string               `json:"value"`
	Document           any                  `json:"document"`
	Score              float64              `json:"score"`
	Rounds             int                  `json:"rounds"`
	LastCompletedRound int                  `json:"last_completed_round"`
	EliminationReason  string               `json:"elimination_reason"`
	InputIndex         int                  `json:"input_index"`
	FirstTTest         RankStats            `json:"first_ttest"`
	TTest              RankStats            `json:"ttest"`
	RoundStats         []RoundDocumentStats `json:"round_stats"`
}

type RoundSummary struct {
	Round            int      `json:"round"`
	Population       int      `json:"population"`
	TargetBatchSize  int      `json:"target_batch_size"`
	ActualBatchSizes []int    `json:"actual_batch_sizes"`
	ReasoningBudget  int      `json:"reasoning_budget"`
	CompletedTrials  int      `json:"completed_trials"`
	SigNegativeSizes []int    `json:"sig_negative_sizes"`
	ContinueCount    int      `json:"continue_count"`
	CarryCount       int      `json:"carry_count"`
	CarriedKeys      []string `json:"carried_keys,omitempty"`
	MedianOneCount   int      `json:"median_one_count"`
	MedianOneKeys    []string `json:"median_one_keys,omitempty"`
	StopReason       string   `json:"stop_reason,omitempty"`
}

type AnalysisFrontier struct {
	Method         string `json:"method"`
	Budget         int    `json:"budget,omitempty"`
	RequestedRound int    `json:"requested_round,omitempty"`
	Round          int    `json:"round"`
	CandidateCount int    `json:"candidate_count"`
	CapacityMet    bool   `json:"capacity_met"`
}

type Usage struct {
	Requests        int `json:"requests"`
	PromptTokens    int `json:"prompt_tokens"`
	OutputTokens    int `json:"output_tokens"`
	ReasoningTokens int `json:"reasoning_tokens"`
	TotalTokens     int `json:"total_tokens"`
}

type DiagnosticSummary struct {
	ReasoningTerminations map[string]int `json:"reasoning_terminations"`
	QualityFlagCount      int            `json:"quality_flag_count"`
}

type Output struct {
	ProtocolVersion    string            `json:"protocol_version"`
	PluginVersion      string            `json:"plugin_version"`
	Model              string            `json:"model"`
	StatisticsVersion  string            `json:"statistics_version"`
	PromptSHA256       string            `json:"prompt_sha256"`
	Config             Config            `json:"config"`
	Usage              Usage             `json:"usage"`
	Diagnostics        DiagnosticSummary `json:"diagnostics"`
	Rounds             []RoundSummary    `json:"round_summaries"`
	AnalysisFrontier   *AnalysisFrontier `json:"analysis_frontier,omitempty"`
	AnalysisCandidates []*RankedDocument `json:"analysis_candidates,omitempty"`
	Ranking            []*RankedDocument `json:"ranking"`
}

type roundObservation struct {
	Round           int
	Population      int
	TargetBatchSize int
	ReasoningBudget int
	Stats           RankStats
}

type Runner struct {
	cfg           Config
	client        *Client
	rng           *rand.Rand
	traceMu       sync.Mutex
	statsMu       sync.Mutex
	roundData     map[string][]roundObservation
	rounds        []RoundSummary
	usage         Usage
	protocol      string
	pluginVersion string
	model         string
	diagnostics   DiagnosticSummary
	elimination   map[string]string
}

func NewRunner(cfg Config, client *Client) (*Runner, error) {
	if cfg.BatchSize < 2 || cfg.BatchSize > 10 {
		return nil, fmt.Errorf("batch-size must be between 2 and 10")
	}
	if cfg.Concurrency < 1 || cfg.MinTrials < 2 || cfg.MaxTrials < cfg.MinTrials || cfg.StableTrials < 1 {
		return nil, fmt.Errorf("concurrency must be positive and trials must satisfy 2 <= min <= max")
	}
	if cfg.MaxRounds < 0 {
		return nil, fmt.Errorf("max-rounds cannot be negative")
	}
	if cfg.EndpointMaxRetries < 0 || cfg.EndpointMaxRetries > 5 {
		return nil, fmt.Errorf("endpoint-max-retries must be between 0 and 5")
	}
	if cfg.Temperature < 0 || cfg.Temperature > 2 {
		return nil, fmt.Errorf("temperature must be between 0 and 2")
	}
	if cfg.AnalysisBudget < 0 || cfg.AnalysisRound < 0 {
		return nil, fmt.Errorf("analysis-budget and analysis-round cannot be negative")
	}
	if cfg.AnalysisBudget > 0 && cfg.AnalysisRound > 0 {
		return nil, fmt.Errorf("analysis-budget and analysis-round are mutually exclusive")
	}
	for name, alpha := range map[string]float64{
		"watch-alpha": cfg.WatchAlpha, "continue-alpha": cfg.ContinueAlpha, "carry-alpha": cfg.CarryAlpha,
	} {
		if alpha <= 0 || alpha >= 1 {
			return nil, fmt.Errorf("%s must be between 0 and 1", name)
		}
	}
	if cfg.ContinueAlpha > cfg.CarryAlpha {
		return nil, fmt.Errorf("continue-alpha should be no larger than carry-alpha")
	}
	if len(cfg.ReasoningBudgets) == 0 {
		cfg.ReasoningBudgets = []int{1000}
	}
	for _, budget := range cfg.ReasoningBudgets {
		if budget < 1 {
			return nil, fmt.Errorf("reasoning token budgets must be positive")
		}
	}
	return &Runner{
		cfg:         cfg,
		client:      client,
		rng:         rand.New(rand.NewSource(cfg.Seed)),
		roundData:   make(map[string][]roundObservation),
		diagnostics: DiagnosticSummary{ReasoningTerminations: make(map[string]int)},
		elimination: make(map[string]string),
	}, nil
}

func (r *Runner) Run(ctx context.Context, documents []Document, prompt string) (*Output, error) {
	if len(documents) < 2 {
		return nil, fmt.Errorf("need at least two documents")
	}
	ordered, err := r.rankRound(ctx, documents, prompt, 1)
	if err != nil {
		return nil, err
	}
	result := make([]*RankedDocument, 0, len(ordered))
	for index, document := range ordered {
		observations := r.roundData[document.Key]
		if len(observations) == 0 {
			return nil, fmt.Errorf("document %q has no completed round statistics", document.Key)
		}
		first := observations[0]
		current := observations[len(observations)-1]
		roundStats := make([]RoundDocumentStats, 0, len(observations))
		for _, observation := range observations {
			roundStats = append(roundStats, RoundDocumentStats{
				Round: observation.Round, Population: observation.Population,
				TargetBatchSize: observation.TargetBatchSize,
				ReasoningBudget: observation.ReasoningBudget, Stats: observation.Stats,
			})
		}
		result = append(result, &RankedDocument{
			Rank: index + 1, Key: document.Key, Value: document.Value,
			Document: document.Data, Score: current.Stats.Mean,
			Rounds: current.Round, LastCompletedRound: current.Round,
			EliminationReason: r.elimination[document.Key], InputIndex: document.InputIndex,
			FirstTTest: first.Stats, TTest: current.Stats, RoundStats: roundStats,
		})
	}

	frontier, candidates, err := selectAnalysisFrontier(result, r.rounds, r.cfg)
	if err != nil {
		return nil, err
	}
	promptDigest := sha256.Sum256([]byte(prompt))
	return &Output{
		ProtocolVersion: r.protocol, PluginVersion: r.pluginVersion, Model: r.model, StatisticsVersion: StatisticsVersion,
		PromptSHA256: hex.EncodeToString(promptDigest[:]), Config: r.cfg,
		Usage: r.usage, Diagnostics: r.diagnostics, Rounds: r.rounds,
		AnalysisFrontier: frontier, AnalysisCandidates: candidates, Ranking: result,
	}, nil
}

func (r *Runner) rankRound(ctx context.Context, documents []Document, prompt string, round int) ([]Document, error) {
	if len(documents) < 2 {
		return documents, nil
	}
	targetBatchSize := min(r.cfg.BatchSize, len(documents))
	scores := make(map[string][]RankObservation, len(documents))
	kHistory := make([]int, 0, r.cfg.MaxTrials)
	completedTrials := 0
	actualBatchSizeSet := make(map[int]bool)
	reasoningBudget := budgetForRound(round, r.cfg.ReasoningBudgets)

	for trial := 1; trial <= r.cfg.MaxTrials; trial++ {
		shuffled := append([]Document(nil), documents...)
		r.rng.Shuffle(len(shuffled), func(i, j int) { shuffled[i], shuffled[j] = shuffled[j], shuffled[i] })
		batches := makeBalancedBatches(shuffled, targetBatchSize)
		if len(batches) == 0 {
			return nil, fmt.Errorf("round %d produced no rankable batches", round)
		}
		for _, batch := range batches {
			actualBatchSizeSet[len(batch)] = true
		}

		type batchResult struct {
			batch     int
			documents []Document
			response  EndpointResponse
			err       error
		}
		jobs := make(chan int)
		results := make(chan batchResult, len(batches))
		workers := min(r.cfg.Concurrency, len(batches))
		var wait sync.WaitGroup
		for worker := 0; worker < workers; worker++ {
			wait.Add(1)
			go func() {
				defer wait.Done()
				for batchIndex := range jobs {
					batch := batches[batchIndex]
					items := make([]EndpointItem, len(batch))
					for index, document := range batch {
						items[index] = EndpointItem{Key: document.Key, Text: document.Value}
					}
					requestID := fmt.Sprintf("round%d:trial%d:batch%d", round, trial, batchIndex+1)
					response, err := r.client.Rank(ctx, EndpointRequest{
						Prompt: prompt, Items: items, RequestID: requestID,
						ReasoningTokenBudget: reasoningBudget,
						MaxRetries:           r.cfg.EndpointMaxRetries,
						Temperature:          r.cfg.Temperature,
						Seed:                 r.cfg.Seed + int64(round*1_000_000+trial*10_000+batchIndex),
						IncludeDiagnostics:   r.cfg.TracePath != "",
					})
					results <- batchResult{batch: batchIndex + 1, documents: batch, response: response, err: err}
				}
			}()
		}
		go func() {
			for index := range batches {
				jobs <- index
			}
			close(jobs)
			wait.Wait()
			close(results)
		}()

		trialScores := make(map[string][]RankObservation)
		for result := range results {
			if result.err != nil {
				return nil, fmt.Errorf("round %d trial %d batch %d: %w", round, trial, result.batch, result.err)
			}
			if err := r.observeEndpointResponse(result.response); err != nil {
				return nil, fmt.Errorf("round %d trial %d batch %d: %w", round, trial, result.batch, err)
			}
			r.addUsage(result.response.Usage)
			for _, ranked := range result.response.Ranking {
				trialScores[ranked.Key] = append(trialScores[ranked.Key], RankObservation{
					Position: ranked.Rank, BatchSize: len(result.documents),
				})
			}
			if err := r.writeTrace(map[string]any{
				"type": "siftrank_batch", "round": round, "trial": trial, "batch": result.batch,
				"items": result.documents, "response": result.response,
			}); err != nil {
				return nil, err
			}
		}
		for key, observations := range trialScores {
			scores[key] = append(scores[key], observations...)
		}
		completedTrials++
		stats := computeTTests(scores, r.cfg.WatchAlpha)
		k := countSigNegative(stats)
		kHistory = append(kHistory, k)
		if err := r.writeTrace(map[string]any{
			"type": "siftrank_trial", "statistics_version": StatisticsVersion,
			"round": round, "trial": trial, "sig_negative_size": k, "ttest": stats,
		}); err != nil {
			return nil, err
		}
		if completedTrials >= r.cfg.MinTrials && allDocumentsObservedAtLeast(documents, scores, 2) && stableTail(kHistory, r.cfg.StableTrials) {
			break
		}
	}

	if missing := documentsBelowExposure(documents, scores, 2); len(missing) > 0 {
		return nil, fmt.Errorf(
			"round %d ended before every item had two observations; increase max-trials (items: %s)",
			round, strings.Join(missing, ", "),
		)
	}

	watchStats := computeTTests(scores, r.cfg.WatchAlpha)
	continueStats := computeTTests(scores, r.cfg.ContinueAlpha)
	carryStats := computeTTests(scores, r.cfg.CarryAlpha)
	continueSet := sigNegativeSet(continueStats)
	carrySet := sigNegativeSet(carryStats)

	current := append([]Document(nil), documents...)
	sort.SliceStable(current, func(i, j int) bool {
		left := watchStats[current[i].Key]
		right := watchStats[current[j].Key]
		if left.Mean == right.Mean {
			return current[i].InputIndex < current[j].InputIndex
		}
		return left.Mean < right.Mean
	})
	for _, document := range current {
		r.roundData[document.Key] = append(r.roundData[document.Key], roundObservation{
			Round: round, Population: len(documents), TargetBatchSize: targetBatchSize,
			ReasoningBudget: reasoningBudget, Stats: carryStats[document.Key],
		})
	}

	actualBatchSizes := make([]int, 0, len(actualBatchSizeSet))
	for size := range actualBatchSizeSet {
		actualBatchSizes = append(actualBatchSizes, size)
	}
	sort.Ints(actualBatchSizes)
	summary := RoundSummary{
		Round: round, Population: len(documents), TargetBatchSize: targetBatchSize,
		ActualBatchSizes: actualBatchSizes, ReasoningBudget: reasoningBudget,
		CompletedTrials: completedTrials, SigNegativeSizes: append([]int(nil), kHistory...),
		ContinueCount: len(continueSet), CarryCount: len(carrySet),
	}
	for _, document := range current {
		if carrySet[document.Key] {
			summary.CarriedKeys = append(summary.CarriedKeys, document.Key)
		}
		if carryStats[document.Key].Median == 1 {
			summary.MedianOneKeys = append(summary.MedianOneKeys, document.Key)
		}
	}
	summary.MedianOneCount = len(summary.MedianOneKeys)

	stopReason := ""
	switch {
	case len(continueSet) == 0:
		stopReason = "no_continue_signal"
	case len(carrySet) < 2:
		stopReason = "carry_set_too_small"
	case len(carrySet) == len(documents):
		stopReason = "carry_set_unchanged"
	case r.cfg.MaxRounds > 0 && round >= r.cfg.MaxRounds:
		stopReason = "max_rounds"
	}
	summary.StopReason = stopReason
	r.rounds = append(r.rounds, summary)

	if stopReason != "" {
		for _, document := range current {
			if r.elimination[document.Key] == "" {
				r.elimination[document.Key] = stopReason
			}
		}
		return current, nil
	}

	carry := make([]Document, 0, len(carrySet))
	bottom := make([]Document, 0, len(current)-len(carrySet))
	for _, document := range current {
		if carrySet[document.Key] {
			carry = append(carry, document)
		} else {
			bottom = append(bottom, document)
			r.elimination[document.Key] = fmt.Sprintf("not_carried_after_round_%d", round)
		}
	}
	refined, err := r.rankRound(ctx, carry, prompt, round+1)
	if err != nil {
		return nil, err
	}
	return append(refined, bottom...), nil
}

func makeBalancedBatches(documents []Document, maximumSize int) [][]Document {
	if len(documents) < 2 || maximumSize < 2 {
		return nil
	}
	batchCount := (len(documents) + maximumSize - 1) / maximumSize
	baseSize := len(documents) / batchCount
	extra := len(documents) % batchCount
	batches := make([][]Document, 0, batchCount)
	cursor := 0
	for index := 0; index < batchCount; index++ {
		size := baseSize
		if index < extra {
			size++
		}
		end := cursor + size
		if size < 2 || end > len(documents) {
			return nil
		}
		batches = append(batches, documents[cursor:end])
		cursor = end
	}
	return batches
}

func selectAnalysisFrontier(
	ranking []*RankedDocument,
	rounds []RoundSummary,
	cfg Config,
) (*AnalysisFrontier, []*RankedDocument, error) {
	if cfg.AnalysisBudget == 0 && cfg.AnalysisRound == 0 {
		return nil, nil, nil
	}
	if len(rounds) == 0 {
		return nil, nil, fmt.Errorf("cannot select analysis frontier without rounds")
	}
	selectedRound := 0
	method := ""
	if cfg.AnalysisRound > 0 {
		method = "explicit_round"
		selectedRound = cfg.AnalysisRound
		found := false
		for _, summary := range rounds {
			if summary.Round == selectedRound {
				found = true
				break
			}
		}
		if !found {
			return nil, nil, fmt.Errorf("analysis-round %d was not reached", selectedRound)
		}
	} else {
		method = "capacity"
		for _, summary := range rounds {
			if summary.Population <= cfg.AnalysisBudget {
				selectedRound = summary.Round
				break
			}
		}
		if selectedRound == 0 {
			selectedRound = rounds[len(rounds)-1].Round
		}
	}

	candidates := make([]*RankedDocument, 0)
	for _, document := range ranking {
		if document.LastCompletedRound >= selectedRound {
			candidates = append(candidates, document)
		}
	}
	capacityMet := cfg.AnalysisBudget == 0 || len(candidates) <= cfg.AnalysisBudget
	frontier := &AnalysisFrontier{
		Method: method, Budget: cfg.AnalysisBudget, RequestedRound: cfg.AnalysisRound,
		Round: selectedRound, CandidateCount: len(candidates), CapacityMet: capacityMet,
	}
	return frontier, candidates, nil
}

func countSigNegative(stats map[string]RankStats) int {
	count := 0
	for _, stat := range stats {
		if stat.SigNegative {
			count++
		}
	}
	return count
}

func sigNegativeSet(stats map[string]RankStats) map[string]bool {
	result := make(map[string]bool)
	for key, stat := range stats {
		if stat.SigNegative {
			result[key] = true
		}
	}
	return result
}

func stableTail(values []int, count int) bool {
	if len(values) < count {
		return false
	}
	expected := values[len(values)-1]
	for _, value := range values[len(values)-count:] {
		if value != expected {
			return false
		}
	}
	return true
}

func allDocumentsObservedAtLeast(documents []Document, scores map[string][]RankObservation, count int) bool {
	return len(documentsBelowExposure(documents, scores, count)) == 0
}

func documentsBelowExposure(documents []Document, scores map[string][]RankObservation, count int) []string {
	missing := make([]string, 0)
	for _, document := range documents {
		if len(scores[document.Key]) < count {
			missing = append(missing, document.Key)
		}
	}
	return missing
}

func budgetForRound(round int, budgets []int) int {
	index := round - 1
	if index < len(budgets) {
		return budgets[index]
	}
	return budgets[len(budgets)-1]
}

func (r *Runner) observeEndpointResponse(response EndpointResponse) error {
	r.statsMu.Lock()
	defer r.statsMu.Unlock()
	if r.protocol == "" {
		r.protocol = response.ProtocolVersion
		r.pluginVersion = response.PluginVersion
		r.model = response.Model
	} else if r.protocol != response.ProtocolVersion {
		return fmt.Errorf("endpoint protocol changed during run: %q -> %q", r.protocol, response.ProtocolVersion)
	}
	if r.pluginVersion != response.PluginVersion {
		return fmt.Errorf("endpoint plugin version changed during run: %q -> %q", r.pluginVersion, response.PluginVersion)
	}
	if r.model != response.Model {
		return fmt.Errorf("endpoint model changed during run: %q -> %q", r.model, response.Model)
	}
	if response.ReasoningTermination != "" {
		r.diagnostics.ReasoningTerminations[response.ReasoningTermination]++
	}
	r.diagnostics.QualityFlagCount += len(response.QualityFlags)
	return nil
}

func (r *Runner) addUsage(usage EndpointUsage) {
	r.statsMu.Lock()
	defer r.statsMu.Unlock()
	r.usage.Requests++
	r.usage.PromptTokens += usage.PromptTokens
	r.usage.OutputTokens += usage.OutputTokens
	r.usage.ReasoningTokens += usage.ReasoningTokens
	r.usage.TotalTokens += usage.TotalTokens
}

func (r *Runner) writeTrace(record any) error {
	if r.cfg.TracePath == "" {
		return nil
	}
	encoded, err := json.Marshal(record)
	if err != nil {
		return fmt.Errorf("encode trace: %w", err)
	}
	r.traceMu.Lock()
	defer r.traceMu.Unlock()
	if directory := filepath.Dir(r.cfg.TracePath); directory != "." {
		if err := os.MkdirAll(directory, 0o755); err != nil {
			return fmt.Errorf("create trace directory: %w", err)
		}
	}
	file, err := os.OpenFile(r.cfg.TracePath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return fmt.Errorf("open trace: %w", err)
	}
	defer file.Close()
	if _, err := file.Write(append(encoded, '\n')); err != nil {
		return fmt.Errorf("write trace: %w", err)
	}
	return nil
}
