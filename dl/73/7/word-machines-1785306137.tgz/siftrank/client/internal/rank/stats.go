package rank

import (
	"math"
	"sort"
)

const StatisticsVersion = "student-t-one-sided-v2"

type RankObservation struct {
	Position  int `json:"position"`
	BatchSize int `json:"batch_size"`
}

// RankStats uses a one-sample, lower-tailed Student t-test. Each observation is
// centered by the random expected rank for its actual batch size:
//
//	difference_i = position_i - (batch_size_i + 1) / 2
//
// H0: E[difference] = 0.  H1: E[difference] < 0.
type RankStats struct {
	Test              string  `json:"test"`
	Alternative       string  `json:"alternative"`
	DF                int     `json:"df"`
	N                 int     `json:"n"`
	Positions         []int   `json:"positions"`
	BatchSizes        []int   `json:"batch_sizes"`
	Mean              float64 `json:"mean"`
	NullMean          float64 `json:"null_mean"`
	MeanDifference    float64 `json:"mean_difference"`
	Std               float64 `json:"std"`
	PositionStd       float64 `json:"position_std"`
	Median            float64 `json:"median"`
	Worst             int     `json:"worst"`
	Q80               int     `json:"q80"`
	Top1              int     `json:"top1"`
	Top2              int     `json:"top2"`
	Top3              int     `json:"top3"`
	Top1Rate          float64 `json:"top1_rate"`
	Top2Rate          float64 `json:"top2_rate"`
	Top3Rate          float64 `json:"top3_rate"`
	UpperTrim20Mean   float64 `json:"upper_trim20_mean"`
	UpperWinsor20Mean float64 `json:"upper_winsor20_mean"`
	Wilson95Lower     float64 `json:"wilson95_lower"`
	BinomialPTop1     float64 `json:"binomial_p_top1"`
	BinomialBH_QTop1  float64 `json:"binomial_bh_q_top1"`
	T                 float64 `json:"t"`
	P                 float64 `json:"p"`
	BH_Q              float64 `json:"bh_q"`
	SigNegative       bool    `json:"sig_negative"`
}

// TTest is retained as a source-compatible alias.
type TTest = RankStats

func computeTTests(scores map[string][]RankObservation, alpha float64) map[string]RankStats {
	result := make(map[string]RankStats, len(scores))
	for key, observations := range scores {
		stat := RankStats{
			Test:             "one_sample_student_t",
			Alternative:      "less",
			N:                len(observations),
			P:                1,
			BH_Q:             1,
			BinomialPTop1:    1,
			BinomialBH_QTop1: 1,
		}
		if len(observations) == 0 {
			result[key] = stat
			continue
		}

		positions := make([]int, len(observations))
		ordered := make([]int, len(observations))
		differences := make([]float64, len(observations))
		top1Probabilities := make([]float64, len(observations))
		for index, observation := range observations {
			position := observation.Position
			batchSize := observation.BatchSize
			positions[index] = position
			ordered[index] = position
			stat.BatchSizes = append(stat.BatchSizes, batchSize)
			stat.Mean += float64(position)
			nullMean := (float64(batchSize) + 1) / 2
			stat.NullMean += nullMean
			differences[index] = float64(position) - nullMean
			top1Probabilities[index] = 1 / float64(batchSize)
			if position <= 1 {
				stat.Top1++
			}
			if position <= 2 {
				stat.Top2++
			}
			if position <= 3 {
				stat.Top3++
			}
		}
		stat.Positions = positions
		stat.Mean /= float64(stat.N)
		stat.NullMean /= float64(stat.N)
		stat.MeanDifference = meanFloat64(differences)
		stat.Top1Rate = float64(stat.Top1) / float64(stat.N)
		stat.Top2Rate = float64(stat.Top2) / float64(stat.N)
		stat.Top3Rate = float64(stat.Top3) / float64(stat.N)
		stat.PositionStd = sampleStdInts(positions)

		sort.Ints(ordered)
		stat.Median = medianInts(ordered)
		stat.Worst = ordered[len(ordered)-1]
		stat.Q80 = nearestRankQuantile(ordered, 0.80)
		stat.UpperTrim20Mean = upperTrimmedMean(ordered, 0.20)
		stat.UpperWinsor20Mean = upperWinsorizedMean(ordered, 0.20)
		stat.Wilson95Lower = wilsonLower(stat.Top1, stat.N, 1.959963984540054)
		stat.BinomialPTop1 = poissonBinomialUpperTail(top1Probabilities, stat.Top1)

		if stat.N < 2 {
			result[key] = stat
			continue
		}
		stat.DF = stat.N - 1
		stat.Std = sampleStdFloat64(differences)
		if stat.Std == 0 {
			switch {
			case stat.MeanDifference < 0:
				stat.T, stat.P, stat.SigNegative = -math.MaxFloat64, 0, true
			case stat.MeanDifference > 0:
				stat.T, stat.P = math.MaxFloat64, 1
			default:
				// The statistic is undefined when every observation equals the
				// null exactly. Conservatively retain the null.
				stat.T, stat.P = 0, 1
			}
			result[key] = stat
			continue
		}
		stat.T = stat.MeanDifference / (stat.Std / math.Sqrt(float64(stat.N)))
		stat.P = studentTLowerTail(stat.T, stat.DF)
		stat.SigNegative = stat.T < 0 && stat.P < alpha
		result[key] = stat
	}

	applyBH(result, func(stat RankStats) float64 { return stat.P }, func(stat *RankStats, q float64) { stat.BH_Q = q })
	applyBH(result, func(stat RankStats) float64 { return stat.BinomialPTop1 }, func(stat *RankStats, q float64) { stat.BinomialBH_QTop1 = q })
	return result
}

func studentTLowerTail(t float64, degreesOfFreedom int) float64 {
	if degreesOfFreedom <= 0 || math.IsNaN(t) {
		return 1
	}
	if math.IsInf(t, -1) || t <= -math.MaxFloat64/2 {
		return 0
	}
	if math.IsInf(t, 1) || t >= math.MaxFloat64/2 {
		return 1
	}
	if t == 0 {
		return 0.5
	}
	df := float64(degreesOfFreedom)
	x := df / (df + t*t)
	ib := regularizedIncompleteBeta(x, df/2, 0.5)
	if t < 0 {
		return clampProbability(0.5 * ib)
	}
	return clampProbability(1 - 0.5*ib)
}

func regularizedIncompleteBeta(x, a, b float64) float64 {
	if x <= 0 {
		return 0
	}
	if x >= 1 {
		return 1
	}
	logGammaAB, _ := math.Lgamma(a + b)
	logGammaA, _ := math.Lgamma(a)
	logGammaB, _ := math.Lgamma(b)
	front := math.Exp(logGammaAB - logGammaA - logGammaB + a*math.Log(x) + b*math.Log1p(-x))
	if x < (a+1)/(a+b+2) {
		return clampProbability(front * betaContinuedFraction(a, b, x) / a)
	}
	return clampProbability(1 - front*betaContinuedFraction(b, a, 1-x)/b)
}

func betaContinuedFraction(a, b, x float64) float64 {
	const (
		maxIterations = 200
		epsilon       = 3e-14
		fpMin         = 1e-300
	)
	qab := a + b
	qap := a + 1
	qam := a - 1
	c := 1.0
	d := 1 - qab*x/qap
	if math.Abs(d) < fpMin {
		d = fpMin
	}
	d = 1 / d
	h := d
	for m := 1; m <= maxIterations; m++ {
		m2 := 2 * m
		aa := float64(m) * (b - float64(m)) * x / ((qam + float64(m2)) * (a + float64(m2)))
		d = 1 + aa*d
		if math.Abs(d) < fpMin {
			d = fpMin
		}
		c = 1 + aa/c
		if math.Abs(c) < fpMin {
			c = fpMin
		}
		d = 1 / d
		h *= d * c

		aa = -(a + float64(m)) * (qab + float64(m)) * x / ((a + float64(m2)) * (qap + float64(m2)))
		d = 1 + aa*d
		if math.Abs(d) < fpMin {
			d = fpMin
		}
		c = 1 + aa/c
		if math.Abs(c) < fpMin {
			c = fpMin
		}
		d = 1 / d
		delta := d * c
		h *= delta
		if math.Abs(delta-1) < epsilon {
			break
		}
	}
	return h
}

func clampProbability(value float64) float64 {
	if value < 0 {
		return 0
	}
	if value > 1 {
		return 1
	}
	return value
}

func meanFloat64(values []float64) float64 {
	var total float64
	for _, value := range values {
		total += value
	}
	return total / float64(len(values))
}

func sampleStdFloat64(values []float64) float64 {
	if len(values) < 2 {
		return 0
	}
	mean := meanFloat64(values)
	var total float64
	for _, value := range values {
		difference := value - mean
		total += difference * difference
	}
	return math.Sqrt(total / float64(len(values)-1))
}

func sampleStdInts(values []int) float64 {
	converted := make([]float64, len(values))
	for index, value := range values {
		converted[index] = float64(value)
	}
	return sampleStdFloat64(converted)
}

func medianInts(ordered []int) float64 {
	middle := len(ordered) / 2
	if len(ordered)%2 == 1 {
		return float64(ordered[middle])
	}
	return float64(ordered[middle-1]+ordered[middle]) / 2
}

func nearestRankQuantile(ordered []int, q float64) int {
	index := int(math.Ceil(q*float64(len(ordered)))) - 1
	if index < 0 {
		index = 0
	}
	if index >= len(ordered) {
		index = len(ordered) - 1
	}
	return ordered[index]
}

func upperTrimmedMean(ordered []int, proportion float64) float64 {
	drop := int(math.Floor(proportion * float64(len(ordered))))
	keep := len(ordered) - drop
	if keep < 1 {
		keep = 1
	}
	var total int
	for _, value := range ordered[:keep] {
		total += value
	}
	return float64(total) / float64(keep)
}

func upperWinsorizedMean(ordered []int, proportion float64) float64 {
	capCount := int(math.Floor(proportion * float64(len(ordered))))
	if capCount == 0 {
		var total int
		for _, value := range ordered {
			total += value
		}
		return float64(total) / float64(len(ordered))
	}
	capIndex := len(ordered) - capCount - 1
	if capIndex < 0 {
		capIndex = 0
	}
	capValue := ordered[capIndex]
	var total int
	for index, value := range ordered {
		if index > capIndex {
			value = capValue
		}
		total += value
	}
	return float64(total) / float64(len(ordered))
}

func wilsonLower(successes, n int, z float64) float64 {
	if n == 0 {
		return 0
	}
	p := float64(successes) / float64(n)
	z2 := z * z
	denominator := 1 + z2/float64(n)
	center := p + z2/(2*float64(n))
	radius := z * math.Sqrt(p*(1-p)/float64(n)+z2/(4*float64(n*n)))
	value := (center - radius) / denominator
	if value < 0 {
		return 0
	}
	return value
}

func poissonBinomialUpperTail(probabilities []float64, successes int) float64 {
	n := len(probabilities)
	if successes <= 0 {
		return 1
	}
	if successes > n {
		return 0
	}
	dp := make([]float64, n+1)
	dp[0] = 1
	for index, probability := range probabilities {
		for count := index + 1; count >= 1; count-- {
			dp[count] = dp[count]*(1-probability) + dp[count-1]*probability
		}
		dp[0] *= 1 - probability
	}
	var total float64
	for count := successes; count <= n; count++ {
		total += dp[count]
	}
	return clampProbability(total)
}

func applyBH(
	stats map[string]RankStats,
	pvalue func(RankStats) float64,
	setQ func(*RankStats, float64),
) {
	type entry struct {
		key string
		p   float64
	}
	entries := make([]entry, 0, len(stats))
	for key, stat := range stats {
		entries = append(entries, entry{key: key, p: pvalue(stat)})
	}
	sort.Slice(entries, func(i, j int) bool {
		if entries[i].p == entries[j].p {
			return entries[i].key < entries[j].key
		}
		return entries[i].p < entries[j].p
	})
	running := 1.0
	m := len(entries)
	for index := m - 1; index >= 0; index-- {
		rank := index + 1
		candidate := entries[index].p * float64(m) / float64(rank)
		if candidate < running {
			running = candidate
		}
		if running > 1 {
			running = 1
		}
		stat := stats[entries[index].key]
		setQ(&stat, running)
		stats[entries[index].key] = stat
	}
}
