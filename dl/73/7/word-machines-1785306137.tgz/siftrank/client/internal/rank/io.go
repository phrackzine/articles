package rank

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"text/template"
	"time"
)

// LoadDocuments keeps identity separate from the rendered ranking value.
// Duplicate rendered values are allowed. Persistent keys must be unique.
//
// keyTemplateText is optional for source compatibility. For JSON input the
// default key is the object's string "id" field when present; otherwise it is a
// deterministic hash of the complete input object plus its input index. For
// text input the default key is a deterministic hash of the original line plus
// its input index. Including the index intentionally preserves duplicate input
// records as distinct documents.
func LoadDocuments(
	reader io.Reader,
	isJSON bool,
	templateText string,
	keyTemplateText ...string,
) ([]Document, error) {
	keyTemplate := ""
	if len(keyTemplateText) > 0 {
		keyTemplate = keyTemplateText[0]
	}
	if len(keyTemplateText) > 1 {
		return nil, errors.New("at most one key template may be supplied")
	}

	valueTemplate, err := parseTemplate("value", templateText)
	if err != nil {
		return nil, err
	}
	identityTemplate, err := parseTemplate("key", keyTemplate)
	if err != nil {
		return nil, err
	}

	if !isJSON {
		scanner := bufio.NewScanner(reader)
		scanner.Buffer(make([]byte, 64<<10), 16<<20)
		var documents []Document
		for scanner.Scan() {
			line := strings.TrimRight(scanner.Text(), "\r")
			if strings.TrimSpace(line) == "" {
				continue
			}
			index := len(documents)
			data := map[string]any{"Data": line, "InputIndex": index}
			value := line
			if valueTemplate != nil {
				value, err = executeTemplate(valueTemplate, data)
				if err != nil {
					return nil, fmt.Errorf("render text item %d: %w", index, err)
				}
			}
			key := ""
			if identityTemplate != nil {
				key, err = executeTemplate(identityTemplate, data)
				if err != nil {
					return nil, fmt.Errorf("render text key %d: %w", index, err)
				}
			}
			if strings.TrimSpace(key) == "" {
				key = stableInputKey(index, []byte(line))
			}
			documents = append(documents, Document{
				Key: key, Value: value, Data: line, InputIndex: index,
			})
		}
		if err := scanner.Err(); err != nil {
			return nil, err
		}
		if err := validateUniqueKeys(documents); err != nil {
			return nil, err
		}
		return documents, nil
	}

	var raw []json.RawMessage
	decoder := json.NewDecoder(reader)
	if err := decoder.Decode(&raw); err != nil {
		return nil, fmt.Errorf("decode JSON array: %w", err)
	}
	documents := make([]Document, 0, len(raw))
	for index, message := range raw {
		var data any
		if err := json.Unmarshal(message, &data); err != nil {
			return nil, fmt.Errorf("decode item %d: %w", index, err)
		}
		value := string(message)
		if valueTemplate != nil {
			value, err = executeTemplate(valueTemplate, data)
			if err != nil {
				return nil, fmt.Errorf("render item %d: %w", index, err)
			}
		} else if object, ok := data.(map[string]any); ok {
			if candidate, ok := object["value"].(string); ok && candidate != "" {
				value = candidate
			}
		}

		key := ""
		if identityTemplate != nil {
			key, err = executeTemplate(identityTemplate, data)
			if err != nil {
				return nil, fmt.Errorf("render key %d: %w", index, err)
			}
		} else if object, ok := data.(map[string]any); ok {
			if id, ok := object["id"].(string); ok {
				key = id
			}
		}
		if strings.TrimSpace(key) == "" {
			canonical, err := json.Marshal(data)
			if err != nil {
				return nil, fmt.Errorf("canonicalize item %d: %w", index, err)
			}
			key = stableInputKey(index, canonical)
		}
		documents = append(documents, Document{
			Key: key, Value: value, Data: data, InputIndex: index,
		})
	}
	if err := validateUniqueKeys(documents); err != nil {
		return nil, err
	}
	return documents, nil
}

func parseTemplate(name, source string) (*template.Template, error) {
	if source == "" {
		return nil, nil
	}
	parsed, err := template.New(name).Option("missingkey=error").Parse(source)
	if err != nil {
		return nil, fmt.Errorf("parse %s template: %w", name, err)
	}
	return parsed, nil
}

func executeTemplate(tmpl *template.Template, data any) (string, error) {
	var output bytes.Buffer
	if err := tmpl.Execute(&output, data); err != nil {
		return "", err
	}
	return output.String(), nil
}

func stableInputKey(index int, identity []byte) string {
	digest := sha256.New()
	_, _ = fmt.Fprintf(digest, "%d\x00", index)
	_, _ = digest.Write(identity)
	return hex.EncodeToString(digest.Sum(nil)[:8])
}

func validateUniqueKeys(documents []Document) error {
	seen := make(map[string]int, len(documents))
	for _, document := range documents {
		key := strings.TrimSpace(document.Key)
		if key == "" {
			return fmt.Errorf("input item %d has an empty persistent key", document.InputIndex)
		}
		if previous, exists := seen[key]; exists {
			return fmt.Errorf(
				"duplicate persistent key %q at input indexes %d and %d; "+
					"use --key-template to choose a unique identity",
				key, previous, document.InputIndex,
			)
		}
		seen[key] = document.InputIndex
	}
	return nil
}

func ParseBudgets(value string) ([]int, error) {
	parts := strings.Split(value, ",")
	budgets := make([]int, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		var budget int
		if _, err := fmt.Sscanf(part, "%d", &budget); err != nil || budget < 1 {
			return nil, fmt.Errorf("invalid reasoning budget %q", part)
		}
		budgets = append(budgets, budget)
	}
	if len(budgets) == 0 {
		return nil, errors.New("at least one reasoning budget is required")
	}
	return budgets, nil
}

func ReadValue(value string) (string, error) {
	if !strings.HasPrefix(value, "@") {
		return value, nil
	}
	content, err := os.ReadFile(strings.TrimPrefix(value, "@"))
	if err != nil {
		return "", err
	}
	return string(content), nil
}

func WriteOutput(path string, output *Output) error {
	encoded, err := json.MarshalIndent(output, "", "  ")
	if err != nil {
		return err
	}
	if path == "" || path == "-" {
		_, err = os.Stdout.Write(append(encoded, '\n'))
		return err
	}
	if directory := filepath.Dir(path); directory != "." {
		if err := os.MkdirAll(directory, 0o755); err != nil {
			return err
		}
	}
	return os.WriteFile(path, append(encoded, '\n'), 0o600)
}

func DefaultSeed() int64 { return time.Now().UnixNano() }
