package rank

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

type EndpointItem struct {
	Key  string `json:"key"`
	Text string `json:"text"`
}

type EndpointRequest struct {
	Prompt                      string         `json:"prompt"`
	Items                       []EndpointItem `json:"items"`
	RequestID                   string         `json:"request_id"`
	ReasoningTokenBudget        int            `json:"reasoning_token_budget"`
	MinimumReasoningTokenBudget int            `json:"minimum_reasoning_token_budget,omitempty"`
	MaxRetries                  int            `json:"max_retries"`
	Temperature                 float64        `json:"temperature"`
	Seed                        int64          `json:"seed"`
	IncludeDiagnostics          bool           `json:"include_diagnostics"`
}

type EndpointUsage struct {
	PromptTokens    int `json:"prompt_tokens"`
	OutputTokens    int `json:"output_tokens"`
	ReasoningTokens int `json:"reasoning_tokens"`
	TotalTokens     int `json:"total_tokens"`
}

type EndpointRankedItem struct {
	Rank  int    `json:"rank"`
	Key   string `json:"key"`
	Score int    `json:"score"`
}

type EndpointResponse struct {
	ProtocolVersion      string               `json:"protocol_version"`
	PluginVersion        string               `json:"plugin_version"`
	RequestID            string               `json:"request_id"`
	Model                string               `json:"model"`
	PromptSHA256         string               `json:"prompt_sha256"`
	Ranking              []EndpointRankedItem `json:"ranking"`
	Usage                EndpointUsage        `json:"usage"`
	ReasoningTermination string               `json:"reasoning_termination"`
	QualityFlags         []map[string]any     `json:"quality_flags"`
	Reasoning            string               `json:"reasoning"`
	RawOutput            string               `json:"raw_output"`
	DecisionScores       map[string]int       `json:"decision_scores"`
	LabelToKey           map[string]string    `json:"label_to_key"`
	Attempts             any                  `json:"attempts,omitempty"`
}

type Client struct {
	endpoint string
	http     *http.Client
}

func NewClient(baseURL string, timeout time.Duration) *Client {
	baseURL = strings.TrimRight(baseURL, "/")
	endpoint := baseURL + "/v1/siftrank"
	if strings.HasSuffix(baseURL, "/v1") {
		endpoint = baseURL + "/siftrank"
	}
	return &Client{
		endpoint: endpoint,
		http:     &http.Client{Timeout: timeout},
	}
}

func (c *Client) Rank(ctx context.Context, request EndpointRequest) (EndpointResponse, error) {
	payload, err := json.Marshal(request)
	if err != nil {
		return EndpointResponse{}, fmt.Errorf("encode request: %w", err)
	}
	httpRequest, err := http.NewRequestWithContext(ctx, http.MethodPost, c.endpoint, bytes.NewReader(payload))
	if err != nil {
		return EndpointResponse{}, fmt.Errorf("build request: %w", err)
	}
	httpRequest.Header.Set("Content-Type", "application/json")

	response, err := c.http.Do(httpRequest)
	if err != nil {
		return EndpointResponse{}, fmt.Errorf("POST %s: %w", c.endpoint, err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, 32<<20))
	if err != nil {
		return EndpointResponse{}, fmt.Errorf("read response: %w", err)
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return EndpointResponse{}, fmt.Errorf("endpoint returned %s: %s", response.Status, strings.TrimSpace(string(body)))
	}

	var decoded EndpointResponse
	if err := json.Unmarshal(body, &decoded); err != nil {
		return EndpointResponse{}, fmt.Errorf("decode response: %w", err)
	}
	if decoded.ProtocolVersion == "" {
		return EndpointResponse{}, fmt.Errorf("endpoint response is missing protocol_version")
	}
	if len(decoded.Ranking) != len(request.Items) {
		return EndpointResponse{}, fmt.Errorf("endpoint returned %d ranks for %d items", len(decoded.Ranking), len(request.Items))
	}
	seen := make(map[string]bool, len(decoded.Ranking))
	allowed := make(map[string]bool, len(request.Items))
	for _, item := range request.Items {
		allowed[item.Key] = true
	}
	for index, item := range decoded.Ranking {
		if item.Rank != index+1 {
			return EndpointResponse{}, fmt.Errorf("endpoint rank sequence is invalid at index %d: got %d", index, item.Rank)
		}
		if !allowed[item.Key] {
			return EndpointResponse{}, fmt.Errorf("endpoint returned unknown key %q", item.Key)
		}
		if seen[item.Key] {
			return EndpointResponse{}, fmt.Errorf("endpoint returned duplicate key %q", item.Key)
		}
		if item.Score < 0 || item.Score > 3 {
			return EndpointResponse{}, fmt.Errorf("endpoint returned invalid assessment score %d for %q", item.Score, item.Key)
		}
		seen[item.Key] = true
	}
	return decoded, nil
}
