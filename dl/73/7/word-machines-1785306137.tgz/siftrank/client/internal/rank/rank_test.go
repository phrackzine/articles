package rank

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestLoadJSONAllowsDuplicateRenderedValues(t *testing.T) {
	input := `[ {"id":"a","line":"return 0;"}, {"id":"b","line":"return 0;"} ]`
	documents, err := LoadDocuments(strings.NewReader(input), true, `{{.line}}`, `{{.id}}`)
	if err != nil {
		t.Fatal(err)
	}
	if documents[0].Value != documents[1].Value {
		t.Fatalf("expected duplicate rendered values: %#v", documents)
	}
	if documents[0].Key == documents[1].Key {
		t.Fatalf("expected distinct persistent keys: %#v", documents)
	}
}

func TestDefaultIdentityKeepsDuplicateObjectsDistinct(t *testing.T) {
	input := `[ {"line":"return 0;"}, {"line":"return 0;"} ]`
	documents, err := LoadDocuments(strings.NewReader(input), true, `{{.line}}`)
	if err != nil {
		t.Fatal(err)
	}
	if documents[0].Key == documents[1].Key {
		t.Fatal("input index must keep duplicate objects distinct")
	}
}

func TestDuplicateKeyTemplateFails(t *testing.T) {
	input := `[ {"line":"a"}, {"line":"b"} ]`
	_, err := LoadDocuments(strings.NewReader(input), true, `{{.line}}`, `same`)
	if err == nil || !strings.Contains(err.Error(), "duplicate persistent key") {
		t.Fatalf("expected duplicate-key error, got %v", err)
	}
}

func TestOneSidedStudentTAgainstActualBatchMidpoint(t *testing.T) {
	stats := computeTTests(map[string][]RankObservation{
		"good": {
			{Position: 1, BatchSize: 5},
			{Position: 1, BatchSize: 5},
			{Position: 1, BatchSize: 5},
		},
		"null": {
			{Position: 2, BatchSize: 3},
			{Position: 3, BatchSize: 5},
			{Position: 2, BatchSize: 3},
		},
	}, 0.05)
	if !stats["good"].SigNegative {
		t.Fatal("expected good item to reject the random-midpoint null")
	}
	if stats["null"].SigNegative {
		t.Fatal("expected actual-batch midpoints to remain null")
	}
	if stats["good"].Test != "one_sample_student_t" || stats["good"].Alternative != "less" {
		t.Fatalf("unexpected test metadata: %#v", stats["good"])
	}
}

func TestZeroVarianceStatsMarshal(t *testing.T) {
	stats := computeTTests(map[string][]RankObservation{
		"best": {
			{Position: 1, BatchSize: 5},
			{Position: 1, BatchSize: 5},
		},
	}, 0.05)
	if _, err := json.Marshal(stats["best"]); err != nil {
		t.Fatalf("zero-variance statistic must be JSON-safe: %v", err)
	}
}

func TestBalancedBatchesIncludeEveryItem(t *testing.T) {
	documents := make([]Document, 12)
	for index := range documents {
		documents[index].Key = string(rune('a' + index))
	}
	batches := makeBalancedBatches(documents, 5)
	seen := 0
	for _, batch := range batches {
		if len(batch) < 2 || len(batch) > 5 {
			t.Fatalf("bad batch size %d", len(batch))
		}
		seen += len(batch)
	}
	if seen != len(documents) {
		t.Fatalf("observed %d of %d documents", seen, len(documents))
	}
}
