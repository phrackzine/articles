module github.com/noperator/siftrank-vllm

go 1.23
