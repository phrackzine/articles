from __future__ import annotations

import importlib.util
import sys
import types

if importlib.util.find_spec("vllm") is None:
    vllm = types.ModuleType("vllm")
    vllm.SamplingParams = object
    sys.modules["vllm"] = vllm

    v1 = types.ModuleType("vllm.v1")
    sample = types.ModuleType("vllm.v1.sample")
    lp = types.ModuleType("vllm.v1.sample.logits_processor")
    lp.AdapterLogitsProcessor = object
    lp.RequestLogitsProcessor = object
    sys.modules["vllm.v1"] = v1
    sys.modules["vllm.v1.sample"] = sample
    sys.modules["vllm.v1.sample.logits_processor"] = lp

from vllm_siftrank.logits_processor import (
    _AssessmentScoreRequestLogitsProcessor,
    _OrderRequestLogitsProcessor,
    _find_subsequence_crossing_or_after,
    _fixed_order_state,
    _order_state,
    _score_state,
    _text_order_state,
)


def enc(value: str) -> list[int]:
    return list(value.encode("utf-8"))


def test_score_state_forces_fixed_labels_and_allows_repeated_scores():
    payload = enc('"a":3,"b":3}\n</think>')
    state = _score_state(
        payload,
        label_prefixes=[enc('"a":'), enc(',"b":')],
        score_sequences=[enc("0"), enc("1"), enc("2"), enc("3")],
        final_suffix=enc("}\n</think>"),
    )
    assert state.valid
    assert state.complete
    assert state.consumed == len(payload)


def test_order_state_requires_complete_unique_permutation():
    payload = enc('"c","b","a"]\n</think>')
    state = _order_state(
        payload,
        label_sequences=[enc('"a"'), enc('"b"'), enc('"c"')],
        separator=enc(","),
        final_suffix=enc("]\n</think>"),
    )
    assert state.valid
    assert state.complete


def test_order_state_rejects_duplicate_label():
    payload = enc('"a","a","c"]\n</think>')
    state = _order_state(
        payload,
        label_sequences=[enc('"a"'), enc('"b"'), enc('"c"')],
        separator=enc(","),
        final_suffix=enc("]\n</think>"),
    )
    assert not state.valid


def allowed_tokens(processor, generated):
    import torch

    logits = torch.zeros(128)
    masked = processor(generated, logits)
    return torch.isfinite(masked).nonzero().flatten().tolist()


def make_assessment_processor():
    return _AssessmentScoreRequestLogitsProcessor(
        min_reasoning_tokens=1,
        max_reasoning_tokens=20,
        ready_sequences=[[82, 83]],
        ready_trigger=[82, 83],
        budget_handoff=[80, 81],
        scores_prefix=[90, 91],
        score_label_prefixes=[[10], [11]],
        score_sequences=[[20], [21], [22], [23]],
        score_suffix=[30],
        forbidden_reasoning_sequences=[[71]],
        eos_token_id=99,
    )


def make_order_processor():
    return _OrderRequestLogitsProcessor(
        min_reasoning_tokens=1,
        max_reasoning_tokens=20,
        commit_sequences=[[82, 83]],
        commit_trigger=[82, 83],
        budget_handoff=[80, 81],
        text_order_prefix=[86, 87],
        text_label_sequences=[[10], [11]],
        text_position_separators=[[12]],
        order_ready=[84, 85],
        order_prefix=[90, 91],
        json_label_sequences=[[20], [21]],
        separator=[13],
        order_suffix=[14, 30],
        forbidden_reasoning_sequences=[[71], [84, 85], [86, 87]],
        eos_token_id=99,
    )

def test_assessment_processor_allows_natural_reasoning_then_forces_scores():
    processor = make_assessment_processor()
    assert allowed_tokens(processor, [50, 82, 83]) == [90]
    assert allowed_tokens(processor, [50, 82, 83, 90]) == [91]
    assert allowed_tokens(processor, [50, 82, 83, 90, 91]) == [10]
    assert allowed_tokens(processor, [50, 82, 83, 90, 91, 10]) == [20, 21, 22, 23]


def test_text_order_state_requires_complete_unique_numbered_permutation():
    state = _text_order_state(
        [10, 12, 11],
        label_sequences=[[10], [11]],
        position_separators=[[12]],
    )
    assert state.valid
    assert state.complete
    assert state.chosen_indices == (0, 1)


def test_fixed_order_state_repeats_precommitted_sequence():
    state = _fixed_order_state(
        [21, 13, 20, 14, 30],
        ordered_label_sequences=[[21], [20]],
        separator=[13],
        final_suffix=[14, 30],
    )
    assert state.valid
    assert state.complete


def test_order_processor_constrains_complete_numbered_order_first():
    processor = make_order_processor()
    assert allowed_tokens(processor, [50, 82, 83]) == [86]
    assert allowed_tokens(processor, [50, 82, 83, 86]) == [87]
    assert allowed_tokens(processor, [50, 82, 83, 86, 87]) == [10, 11]
    assert allowed_tokens(processor, [50, 82, 83, 86, 87, 10]) == [12]
    assert allowed_tokens(processor, [50, 82, 83, 86, 87, 10, 12]) == [11]


def test_order_processor_forces_json_to_copy_numbered_order():
    processor = make_order_processor()
    committed = [50, 82, 83, 86, 87, 11, 12, 10]
    assert allowed_tokens(processor, committed) == [84]
    assert allowed_tokens(processor, committed + [84]) == [85]
    assert allowed_tokens(processor, committed + [84, 85]) == [90]
    assert allowed_tokens(processor, committed + [84, 85, 90]) == [91]
    assert allowed_tokens(processor, committed + [84, 85, 90, 91]) == [21]
    assert allowed_tokens(processor, committed + [84, 85, 90, 91, 21]) == [13]
    assert allowed_tokens(
        processor, committed + [84, 85, 90, 91, 21, 13]
    ) == [20]


def test_natural_eos_redirects_to_ready_trigger():
    import torch

    processor = make_order_processor()
    logits = torch.zeros(128)
    logits[99] = 5.0
    masked = processor([50], logits)
    assert torch.isfinite(masked[82])
    assert not torch.isfinite(masked[99])


def test_phase_literal_search_allows_leading_token_overlap():
    values = [1, 2, 3, 4]
    assert _find_subsequence_crossing_or_after(values, [2, 3], 2) == 1


def test_early_ready_to_order_is_redirected_to_final_order_commit():
    import torch

    processor = make_order_processor()
    logits = torch.zeros(128)
    # The model has begun the forbidden READY_TO_ORDER sequence [84, 85].
    logits[85] = 5.0
    masked = processor([50, 84], logits)
    assert torch.isfinite(masked[82])
    assert not torch.isfinite(masked[85])


def test_early_final_order_is_redirected_to_commit_handoff():
    import torch

    processor = make_order_processor()
    logits = torch.zeros(128)
    # The model has begun the forbidden FINAL_ORDER sequence [86, 87].
    logits[87] = 5.0
    masked = processor([50, 86], logits)
    assert torch.isfinite(masked[82])
    assert not torch.isfinite(masked[87])


def test_second_final_order_prefix_is_rejected_after_commitment_started():
    processor = make_order_processor()
    generated = [50, 82, 83, 86, 87, 10, 86, 87]
    assert allowed_tokens(processor, generated) == [99]


def test_commit_handoff_and_final_order_prefix_can_share_boundary_token():
    processor = make_order_processor()
    # The final token of READY_TO_COMMIT also acts as the first token of the
    # server-forced FINAL_ORDER prefix. The crossing search must not restart it.
    processor.text_order_prefix = [83, 86]
    assert allowed_tokens(processor, [50, 82, 83]) == [86]
    assert allowed_tokens(processor, [50, 82, 83, 86]) == [10, 11]
