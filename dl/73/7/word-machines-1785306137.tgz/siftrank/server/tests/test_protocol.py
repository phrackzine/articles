import pytest

from vllm_siftrank.protocol import (
    ASSESSMENT_BUDGET_HANDOFF,
    ORDER_COMMIT_READY_MARKER,
    ORDER_PREFIX,
    RANKING_BUDGET_HANDOFF,
    TEXT_ORDER_MARKER,
    SCORES_PREFIX,
    LabeledItem,
    RankingEntry,
    apply_score_tier_fallback,
    assemble_decision,
    build_assessment_prompt,
    build_assessment_prefill,
    build_comparison_prefill,
    build_comparison_prompt,
    entries_from_order,
    final_marker_count,
    order_marker_count,
    parse_order,
    parse_scores,
    parse_text_order,
    randomize_labeled_items,
    reasoning_end_index,
    render_items,
    score_marker_count,
)


def assessment_output(scores: dict[str, int]) -> str:
    body = ",".join(f'"{label}":{score}' for label, score in scores.items())
    return f"<think>\nindependent analysis\nREADY_TO_SCORE\nSCORES={{{body}}}\n</think>"


def order_output(order: list[str]) -> str:
    numbered = "\n".join(
        f"{index}. {label}" for index, label in enumerate(order, start=1)
    )
    body = ",".join(f'"{label}"' for label in order)
    return (
        f"<think>\ncomparison\n{TEXT_ORDER_MARKER}\n{numbered}"
        f"\nREADY_TO_ORDER\nORDER=[{body}]\n</think>"
    )


def test_assessment_prompt_uses_xml_cdata_and_defers_ranking():
    items = [
        LabeledItem("kob", "a", "if (x < 3 && y > 1) free(x);"),
        LabeledItem("nef", "b", "return 0;"),
    ]
    prompt = build_assessment_prompt("Rank free sites.", items)
    assert '<item label="kob">' in prompt
    assert "<![CDATA[if (x < 3 && y > 1) free(x);]]>" in prompt
    assert "READY_TO_SCORE" in prompt
    assert "A score is not a rank" in prompt
    assert "Do not assign or reserve rank positions" in prompt
    assert "state = READY" not in prompt
    assert "spin_unlock" not in prompt
    assert "kfree(ptr)" not in prompt
    assessment_prefill = build_assessment_prefill()
    comparison_prefill = build_comparison_prefill()
    assert assessment_prefill.startswith("<think>\nI understand the criteria")
    assert "will not restate the instructions" in assessment_prefill
    assert "Direct assessments:" in assessment_prefill
    assert comparison_prefill.startswith("<think>\nI understand the criteria")
    assert "will not restate the instructions" in comparison_prefill
    assert "constrained numbered ranking" in comparison_prefill
    assert "Direct comparison:" in comparison_prefill


def test_comparison_prompt_commits_complete_numbered_order_then_copy():
    prompt = build_comparison_prompt(["kob", "nef"])
    assert "complete independent assessments" in prompt
    assert ORDER_COMMIT_READY_MARKER in prompt
    assert "Do not emit FINAL_ORDER yourself" in prompt
    assert "server will append" in prompt
    assert "do not state a complete ordered label" in prompt
    assert "list in the prose" in prompt
    assert "FINAL_ORDER:" in prompt
    assert "1. <best label>" in prompt
    assert "2. <worst label>" in prompt
    assert "READY_TO_ORDER" in prompt
    assert "ORDER array" in prompt
    assert "sole model ranking" in prompt
    assert "decision." in prompt
    assert "repeats the" in prompt
    assert "numbered label sequence exactly" in prompt
    assert "Use scores as evidence, not as hard ordering constraints" in prompt
    assert "may rank above a higher-scored candidate" in prompt
    assert "Do not write a separate numbered order" not in prompt


def test_assignment_and_presentation_permutations_are_independent():
    items = [("a", "A"), ("b", "B"), ("c", "C"), ("d", "D"), ("e", "E")]
    labels = ["kob", "nef", "gim", "naw", "lij"]

    first = randomize_labeled_items(
        items, labels, assignment_seed=7, presentation_seed=11
    )
    second = randomize_labeled_items(
        items, labels, assignment_seed=7, presentation_seed=12
    )

    assert {item.label: item.key for item in first} == {
        item.label: item.key for item in second
    }
    assert [item.label for item in first] != [item.label for item in second]
    assert [item.label for item in first] != labels


def test_randomization_is_reproducible():
    items = [("a", "A"), ("b", "B"), ("c", "C")]
    labels = ["kob", "nef", "gim"]
    first = randomize_labeled_items(
        items, labels, assignment_seed=17, presentation_seed=23
    )
    second = randomize_labeled_items(
        items, labels, assignment_seed=17, presentation_seed=23
    )
    assert first == second


def test_prompts_preserve_caller_supplied_presentation_order():
    items = [
        LabeledItem("gim", "c", "third"),
        LabeledItem("kob", "a", "first"),
        LabeledItem("nef", "b", "second"),
    ]
    assessment = build_assessment_prompt("Rank by the supplied criterion.", items)
    assert assessment.index('<item label="gim">') < assessment.index('<item label="kob">')
    assert assessment.index('<item label="kob">') < assessment.index('<item label="nef">')
    assert "For each exact label (gim, kob, nef)" in assessment

    comparison = build_comparison_prompt(["gim", "kob", "nef"])
    assert "Required labels: gim, kob, nef" in comparison


def test_generic_protocol_does_not_inject_domain_calibration():
    prompt = build_assessment_prompt(
        "Rank the items by relevance to the supplied criterion.",
        [LabeledItem("kob", "a", "opaque item")],
    )
    assert "object-lifetime-release" not in prompt
    assert "kfree" not in prompt
    assert "use-after-free" not in prompt


def test_cdata_safely_splits_terminator():
    rendered = render_items([LabeledItem("kob", "a", "left ]]> right")])
    assert "]]]]><![CDATA[>" in rendered


def test_parse_server_constrained_scores():
    scores = parse_scores(assessment_output({"kob": 3, "nef": 0}), ["kob", "nef"])
    assert scores == {"kob": 3, "nef": 0}


def test_parse_complete_numbered_order():
    output = order_output(["nef", "kob"])
    assert parse_text_order(output, ["kob", "nef"]) == ["nef", "kob"]


def test_rejects_restarted_final_order_from_trace_pattern():
    output = (
        "<think>\ncomparison\n"
        "FINAL_ORDER:\n1. gim\n"
        "FINAL_ORDER:\n1. nef\n2. lij\n3. gim\n4. naw\n5. kob\n"
        "READY_TO_ORDER\nORDER=[\"nef\",\"lij\",\"gim\",\"naw\",\"kob\"]\n"
        "</think>"
    )
    with pytest.raises(ValueError, match="multiple FINAL_ORDER markers"):
        parse_text_order(output, ["nef", "lij", "gim", "naw", "kob"])


def test_numbered_and_json_orders_match_in_valid_output():
    output = order_output(["kob", "nef"])
    assert parse_text_order(output, ["kob", "nef"]) == parse_order(
        output, ["kob", "nef"]
    )


def test_parse_authoritative_order_and_assemble_decision():
    scores = {"kob": 3, "nef": 0}
    order = parse_order(order_output(["kob", "nef"]), ["kob", "nef"])
    entries = entries_from_order(order)
    decision = assemble_decision(entries, scores, ["kob", "nef"])
    assert decision.order == ["kob", "nef"]
    assert decision.scores == scores
    assert decision.conflicts == []


def test_order_can_override_scores_and_reports_conflict():
    scores = {"kob": 0, "nef": 3}
    entries = entries_from_order(["kob", "nef"])
    decision = assemble_decision(entries, scores, ["kob", "nef"])
    assert len(decision.conflicts) == 1


def test_rejects_invalid_score():
    with pytest.raises(ValueError, match="between 0 and 3"):
        parse_scores(assessment_output({"kob": 4, "nef": 0}), ["kob", "nef"])


def test_rejects_duplicate_order_label():
    with pytest.raises(ValueError, match="duplicate labels"):
        parse_order(order_output(["kob", "kob"]), ["kob", "nef"])


def test_rejects_incomplete_order():
    with pytest.raises(ValueError, match="length"):
        parse_order(order_output(["kob"]), ["kob", "nef"])


def test_last_server_markers_are_authoritative():
    assessment = (
        'SCORES={"kob":0,"nef":3}\n'
        + assessment_output({"kob": 3, "nef": 0})
    )
    ordering = 'ORDER=["nef","kob"]\n' + order_output(["kob", "nef"])
    assert score_marker_count(assessment) == 2
    assert order_marker_count(ordering) == 2
    assert parse_scores(assessment, ["kob", "nef"])["kob"] == 3
    assert parse_order(ordering, ["kob", "nef"])[0] == "kob"
    assert final_marker_count(ordering) == 0


def test_score_tier_fallback_preserves_model_order_inside_ties():
    labels = ["a", "b", "c", "d"]
    scores = {"a": 1, "b": 3, "c": 3, "d": 0}
    entries = {
        "a": RankingEntry(rank=1),
        "b": RankingEntry(rank=4),
        "c": RankingEntry(rank=2),
        "d": RankingEntry(rank=3),
    }
    repaired = apply_score_tier_fallback(entries, scores, labels)
    order = sorted(labels, key=lambda label: repaired[label].rank)
    assert order == ["c", "b", "a", "d"]


def test_budget_bridges_do_not_embed_structured_prefixes():
    assert SCORES_PREFIX.strip() not in ASSESSMENT_BUDGET_HANDOFF
    assert ORDER_PREFIX.strip() not in RANKING_BUDGET_HANDOFF


def test_assessment_reasoning_boundary_can_equal_ready_marker():
    output = "analysis\nREADY_TO_SCORE\nSCORES={}"
    ready_start = output.index("READY_TO_SCORE")
    assert reasoning_end_index(
        output,
        ready_start=ready_start,
        ready_marker="READY_TO_SCORE",
        reasoning_end_marker="READY_TO_SCORE",
    ) == ready_start


def test_comparison_reasoning_boundary_precedes_numbered_commitment():
    output = (
        "comparison\nFINAL_ORDER:\n1. kob\n2. nef\n"
        "READY_TO_ORDER\nORDER=[\"kob\",\"nef\"]"
    )
    ready_start = output.index("READY_TO_ORDER")
    assert reasoning_end_index(
        output,
        ready_start=ready_start,
        ready_marker="READY_TO_ORDER",
        reasoning_end_marker="FINAL_ORDER:",
    ) == output.index("FINAL_ORDER:")


def test_comparison_reasoning_boundary_rejects_restarted_commitment():
    output = (
        "comparison\nFINAL_ORDER:\n1. gim\n"
        "FINAL_ORDER:\n1. kob\n2. nef\n"
        "READY_TO_ORDER\nORDER=[\"kob\",\"nef\"]"
    )
    ready_start = output.index("READY_TO_ORDER")
    with pytest.raises(ValueError, match="multiple FINAL_ORDER: markers"):
        reasoning_end_index(
            output,
            ready_start=ready_start,
            ready_marker="READY_TO_ORDER",
            reasoning_end_marker="FINAL_ORDER:",
        )
