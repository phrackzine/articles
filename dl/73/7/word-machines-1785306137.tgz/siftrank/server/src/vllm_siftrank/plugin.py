from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import threading
import time
import traceback
from argparse import Namespace
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field, model_validator
from starlette.datastructures import State
from transformers import AutoTokenizer

from vllm.engine.protocol import EngineClient
from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
from vllm.utils import random_uuid

from . import __version__
from .protocol import (
    ASSESSMENT_BUDGET_HANDOFF,
    ASSESSMENT_BUDGET_HANDOFF_SENTENCE,
    FINAL_MARKER,
    ORDER_COMMIT_READY_MARKER,
    ORDER_COMMIT_READY_TRIGGER,
    ORDER_MARKER,
    ORDER_PREFIX,
    ORDER_READY_MARKER,
    ORDER_READY_TRIGGER,
    ORDER_SEPARATOR,
    ORDER_SUFFIX,
    TEXT_ORDER_MARKER,
    TEXT_ORDER_TRIGGER,
    FINAL_SUFFIX,
    LABEL_POOL,
    PROTOCOL_VERSION,
    RANKING_BUDGET_HANDOFF,
    RANKING_BUDGET_HANDOFF_SENTENCE,
    SCORE_READY_MARKER,
    SCORE_READY_TRIGGER,
    SCORES_MARKER,
    SCORES_PREFIX,
    SCORES_SUFFIX,
    LabeledItem,
    apply_score_tier_fallback,
    assemble_decision,
    build_assessment_prompt,
    build_assessment_prefill,
    build_comparison_prefill,
    build_comparison_prompt,
    extract_reasoning_before_marker,
    final_marker_count,
    label_json_literal,
    entries_from_order,
    order_marker_count,
    parse_order,
    parse_scores,
    parse_text_order,
    randomize_labeled_items,
    reasoning_end_index,
    score_marker_count,
)

_TRACE_LOCK = threading.Lock()
_LOG = logging.getLogger("vllm_siftrank")
_ASSESSMENT_LOGITS_MODE = "assessment_scores_v4_9"
_ORDERING_LOGITS_MODE = "numbered_order_commit_v4_9"


class RankItem(BaseModel):
    key: str = Field(min_length=1)
    text: str


class RankRequest(BaseModel):
    prompt: str = Field(min_length=1)
    items: list[RankItem] = Field(min_length=2, max_length=len(LABEL_POOL))
    request_id: str = Field(default_factory=lambda: f"siftrank-{random_uuid()}")
    reasoning_token_budget: int = Field(default=1000, ge=1, le=32768)
    minimum_reasoning_token_budget: int | None = Field(default=None, ge=1, le=32768)
    max_retries: int = Field(default=2, ge=0, le=5)
    temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    top_p: float | None = Field(default=None, gt=0.0, le=1.0)
    top_k: int | None = None
    seed: int | None = None
    include_diagnostics: bool = True

    # Accepted but ignored for compatibility with older callers.
    selection_reasoning_token_budget: int | None = Field(default=None, ge=1, le=2048)
    analysis_line_max_chars: int | None = Field(default=None, ge=32, le=2048)
    soft_reasoning_token_budget: int | None = Field(default=None, ge=1, le=32768)

    @model_validator(mode="after")
    def validate_request(self) -> "RankRequest":
        keys = [item.key for item in self.items]
        if len(set(keys)) != len(keys):
            raise ValueError("item keys must be unique")
        if (
            self.minimum_reasoning_token_budget is not None
            and self.minimum_reasoning_token_budget > self.reasoning_token_budget
        ):
            raise ValueError(
                "minimum_reasoning_token_budget must not exceed reasoning_token_budget"
            )
        return self


class TokenUsage(BaseModel):
    prompt_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    total_tokens: int = 0


class RankedItem(BaseModel):
    rank: int
    key: str
    score: int


class GenerationDiagnostic(BaseModel):
    phase: str
    request_id: str
    messages: list[dict[str, str]]
    assistant_prefill: str
    generated_text: str
    full_output: str
    finish_reason: str | None = None
    structured_output: dict[str, Any] | None = None
    termination: str
    usage: TokenUsage


class AttemptDiagnostic(BaseModel):
    attempt: int
    labels: list[str]
    label_to_key: dict[str, str]
    selected_labels: list[str] = Field(default_factory=list)
    assessments: dict[str, dict[str, Any]] = Field(default_factory=dict)
    decision_scores: dict[str, int] = Field(default_factory=dict)
    final_ranking: dict[str, dict[str, int]] = Field(default_factory=dict)
    reasoning: str | None = None
    reasoning_termination: str | None = None
    assessment_termination: str | None = None
    comparison_termination: str | None = None
    quality_flags: list[dict[str, Any]] = Field(default_factory=list)
    generations: list[GenerationDiagnostic] = Field(default_factory=list)
    error: str | None = None


class RankResponse(BaseModel):
    protocol_version: str
    plugin_version: str
    request_id: str
    model: str
    prompt_sha256: str
    ranking: list[RankedItem]
    usage: TokenUsage
    reasoning_termination: str
    assessment_termination: str
    comparison_termination: str
    quality_flags: list[dict[str, Any]] = Field(default_factory=list)
    reasoning: str | None = None
    raw_output: str | None = None
    decision_scores: dict[str, int] | None = None
    label_to_key: dict[str, str]
    attempts: list[AttemptDiagnostic] | None = None


class _GenerationResult:
    def __init__(
        self,
        *,
        text: str,
        full_output: str,
        finish_reason: str | None,
        usage: TokenUsage,
        termination: str,
        diagnostic: GenerationDiagnostic,
    ) -> None:
        self.text = text
        self.full_output = full_output
        self.finish_reason = finish_reason
        self.usage = usage
        self.termination = termination
        self.diagnostic = diagnostic


class SiftRankHandler:
    def __init__(self, engine_client: EngineClient, state: State, args: Namespace):
        self.engine_client = engine_client
        self.online_renderer = state.online_renderer
        self.model_config = engine_client.model_config
        self.default_sampling_params = self.model_config.get_diff_sampling_param() or {}
        tokenizer_name = str(
            getattr(self.model_config, "tokenizer", self.model_config.model)
        )
        self.tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_name,
            trust_remote_code=bool(
                getattr(self.model_config, "trust_remote_code", False)
            ),
        )
        if self.tokenizer.eos_token_id is None:
            raise RuntimeError("SiftRank requires a tokenizer EOS token id")
        self.eos_token_id = int(self.tokenizer.eos_token_id)

        self.score_ready_trigger_ids = self._encode_required(SCORE_READY_TRIGGER)
        self.score_ready_token_sequences = self._unique_token_sequences(
            [
                SCORE_READY_MARKER,
                "\n" + SCORE_READY_MARKER,
                SCORE_READY_MARKER + "\n",
                SCORE_READY_TRIGGER,
            ]
        )
        self.assessment_budget_handoff_ids = self._encode_required(
            ASSESSMENT_BUDGET_HANDOFF
        )
        self.scores_prefix_ids = self._encode_required(SCORES_PREFIX)
        self.score_token_sequences = [
            self._encode_required(str(score)) for score in range(4)
        ]
        self.scores_suffix_ids = self._encode_required(SCORES_SUFFIX)

        self.order_commit_ready_trigger_ids = self._encode_required(
            ORDER_COMMIT_READY_TRIGGER
        )
        self.order_commit_ready_token_sequences = self._unique_token_sequences(
            [
                ORDER_COMMIT_READY_MARKER,
                "\n" + ORDER_COMMIT_READY_MARKER,
                ORDER_COMMIT_READY_MARKER + "\n",
                ORDER_COMMIT_READY_TRIGGER,
            ]
        )
        self.text_order_prefix_ids = self._encode_required(TEXT_ORDER_TRIGGER)
        self.order_ready_ids = self._encode_required(ORDER_READY_TRIGGER)
        self.ranking_budget_handoff_ids = self._encode_required(
            RANKING_BUDGET_HANDOFF
        )
        self.order_prefix_ids = self._encode_required(ORDER_PREFIX)
        self.separator_ids = self._encode_required(ORDER_SEPARATOR)
        self.order_suffix_ids = self._encode_required(ORDER_SUFFIX)
        self.text_label_token_sequences = {
            label: self._encode_required(label) for label in LABEL_POOL
        }
        self.json_label_token_sequences = {
            label: self._encode_required(label_json_literal(label))
            for label in LABEL_POOL
        }
        self.forbidden_reasoning_sequences = [self._encode_required("</think>")]
        self.comparison_forbidden_reasoning_sequences = self._unique_token_sequences(
            [
                "</think>",
                TEXT_ORDER_MARKER,
                "\n" + TEXT_ORDER_MARKER,
                TEXT_ORDER_TRIGGER,
                ORDER_READY_TRIGGER,
                ORDER_READY_MARKER,
                "\n" + ORDER_READY_MARKER,
                ORDER_MARKER,
                "\n" + ORDER_MARKER,
                ORDER_PREFIX,
                FINAL_MARKER,
                "\n" + FINAL_MARKER,
            ]
        )
        self._validate_nonprefix_sequences(
            list(self.text_label_token_sequences.values()), "text label"
        )
        self._validate_nonprefix_sequences(
            list(self.json_label_token_sequences.values()), "JSON label"
        )
        self._validate_nonprefix_sequences(self.score_token_sequences, "score")

        served = getattr(args, "served_model_name", None)
        if served:
            self.model_name = served[0] if isinstance(served, list) else str(served)
        else:
            self.model_name = str(getattr(args, "model", self.model_config.model))
        self.trace_path = os.environ.get("SIFTRANK_ENDPOINT_TRACE")
        self.debug_path = os.environ.get("SIFTRANK_ENDPOINT_DEBUG")
        if not self.debug_path and self.trace_path:
            self.debug_path = f"{self.trace_path}.debug.jsonl"
        self._debug_event(
            "handler_initialized",
            model_name=self.model_name,
            trace_path=self.trace_path,
            debug_path=self.debug_path,
            default_sampling_params=self.default_sampling_params,
        )

    def _encode_required(self, text: str) -> list[int]:
        token_ids = self.tokenizer.encode(text, add_special_tokens=False)
        if not token_ids:
            raise RuntimeError(
                f"required SiftRank literal tokenized to empty: {text!r}"
            )
        return [int(token_id) for token_id in token_ids]

    def _unique_token_sequences(self, texts: list[str]) -> list[list[int]]:
        result: list[list[int]] = []
        seen: set[tuple[int, ...]] = set()
        for text in texts:
            sequence = self._encode_required(text)
            key = tuple(sequence)
            if key in seen:
                continue
            seen.add(key)
            result.append(sequence)
        return result

    @staticmethod
    def _validate_nonprefix_sequences(sequences: list[list[int]], name: str) -> None:
        for index, left in enumerate(sequences):
            for other_index, right in enumerate(sequences):
                if index == other_index:
                    continue
                if len(left) <= len(right) and right[: len(left)] == left:
                    raise RuntimeError(f"{name} token sequence prefixes another {name}")

    @staticmethod
    def _split_reasoning_budget(total: int) -> tuple[int, int]:
        if total <= 2:
            return max(1, total), max(1, total)
        assessment = max(1, int(round(total * 0.60)))
        comparison = max(1, total - assessment)
        return assessment, comparison

    @staticmethod
    def _split_minimum_budget(
        requested: int | None,
        assessment_max: int,
        comparison_max: int,
    ) -> tuple[int, int]:
        if requested is None:
            return min(64, assessment_max), min(48, comparison_max)
        assessment = max(1, int(round(requested * 0.60)))
        comparison = max(1, requested - assessment)
        return min(assessment, assessment_max), min(comparison, comparison_max)

    def _score_label_prefixes(self, labels: list[str]) -> list[list[int]]:
        result: list[list[int]] = []
        for index, label in enumerate(labels):
            literal = ("" if index == 0 else ",") + label_json_literal(label) + ":"
            result.append(self._encode_required(literal))
        return result

    async def rank(self, body: RankRequest) -> RankResponse:
        self._debug_event("request_received", request=body.model_dump())
        aggregate = TokenUsage()
        attempts: list[AttemptDiagnostic] = []
        base_seed = (
            body.seed
            if body.seed is not None
            else random.SystemRandom().randrange(-(2**63), 2**63 - 100)
        )

        for attempt_index in range(body.max_retries + 1):
            # Use independent deterministic permutations for candidate-to-label
            # assignment and label presentation. This prevents a fixed rendered
            # label order from becoming a default ranking when evidence is weak.
            attempt_seed = self._derived_seed(base_seed, attempt_index * 4)
            assessment_seed = self._derived_seed(attempt_seed, 2)
            comparison_seed = self._derived_seed(attempt_seed, 3)

            assignment_labels = list(LABEL_POOL[: len(body.items)])
            labeled_items = randomize_labeled_items(
                ((item.key, item.text) for item in body.items),
                assignment_labels,
                assignment_seed=attempt_seed,
                presentation_seed=self._derived_seed(attempt_seed, 1),
            )
            labels = [item.label for item in labeled_items]
            label_to_key = {item.label: item.key for item in labeled_items}
            attempt = AttemptDiagnostic(
                attempt=attempt_index + 1,
                labels=labels,
                label_to_key=label_to_key,
            )
            attempts.append(attempt)

            try:
                retry_note = None
                if attempt_index > 0:
                    retry_note = (
                        "The previous two-pass attempt failed to produce a valid "
                        "server-constrained score record or complete ORDER. Recheck "
                        "every label-to-item binding and keep scores absolute."
                    )

                assessment_prompt = build_assessment_prompt(
                    body.prompt,
                    labeled_items,
                    retry_note=retry_note,
                )
                assessment = await self._generate_assessment(
                    body=body,
                    prompt=assessment_prompt,
                    labels=labels,
                    seed=assessment_seed,
                    attempt_number=attempt.attempt,
                )
                attempt.generations.append(assessment.diagnostic)
                self._add_usage(aggregate, assessment.usage)
                if assessment.finish_reason != "stop":
                    raise ValueError(
                        "assessment generation ended with "
                        f"finish_reason={assessment.finish_reason!r}"
                    )
                scores = parse_scores(assessment.full_output, labels)

                comparison = await self._generate_comparison(
                    body=body,
                    assessment_prompt=assessment_prompt,
                    assessment_output=assessment.full_output,
                    labels=labels,
                    seed=comparison_seed,
                    attempt_number=attempt.attempt,
                )
                attempt.generations.append(comparison.diagnostic)
                self._add_usage(aggregate, comparison.usage)
                if comparison.finish_reason != "stop":
                    raise ValueError(
                        "comparison generation ended with "
                        f"finish_reason={comparison.finish_reason!r}"
                    )

                text_order = parse_text_order(comparison.full_output, labels)
                model_order = parse_order(comparison.full_output, labels)
                if model_order != text_order:
                    raise ValueError(
                        "machine-readable ORDER does not match the constrained "
                        "FINAL_ORDER numbered commitment"
                    )
                entries = entries_from_order(text_order)
                assessment_term = assessment.termination
                comparison_term = comparison.termination
                if comparison_term == "budget":
                    entries = apply_score_tier_fallback(entries, scores, labels)
                decision = assemble_decision(entries, scores, labels)

                quality_flags: list[dict[str, Any]] = [
                    conflict.as_dict() for conflict in decision.conflicts
                ]
                if assessment_term == "budget":
                    quality_flags.append(
                        {
                            "type": "reasoning_budget_exhausted",
                            "phase": "assessment",
                        }
                    )
                if comparison_term == "budget":
                    fallback_order = list(decision.order)
                    quality_flags.append(
                        {
                            "type": "reasoning_budget_exhausted",
                            "phase": "comparison",
                        }
                    )
                    quality_flags.append(
                        {
                            "type": "comparison_budget_score_tier_fallback",
                            "model_order": model_order,
                            "fallback_order": fallback_order,
                        }
                    )
                assessment_score_markers = score_marker_count(assessment.full_output)
                if assessment_score_markers > 1:
                    quality_flags.append(
                        {
                            "type": "premature_score_marker",
                            "count": assessment_score_markers - 1,
                        }
                    )
                assessment_final_markers = final_marker_count(assessment.full_output)
                if assessment_final_markers:
                    quality_flags.append(
                        {
                            "type": "premature_final_marker_in_assessment",
                            "count": assessment_final_markers,
                        }
                    )
                comparison_order_markers = order_marker_count(comparison.full_output)
                if comparison_order_markers > 1:
                    quality_flags.append(
                        {
                            "type": "premature_order_marker",
                            "count": comparison_order_markers - 1,
                        }
                    )
                comparison_final_markers = final_marker_count(comparison.full_output)
                if comparison_final_markers:
                    quality_flags.append(
                        {
                            "type": "premature_final_marker",
                            "count": comparison_final_markers,
                        }
                    )

                assessment_reasoning = extract_reasoning_before_marker(
                    assessment.full_output,
                    marker=SCORES_MARKER,
                    budget_sentence=ASSESSMENT_BUDGET_HANDOFF_SENTENCE,
                )
                comparison_reasoning = extract_reasoning_before_marker(
                    comparison.full_output,
                    marker=ORDER_MARKER,
                    budget_sentence=RANKING_BUDGET_HANDOFF_SENTENCE,
                )
                reasoning = (
                    "ASSESSMENT PASS\n"
                    + assessment_reasoning
                    + "\n\nCOMPARISON PASS\n"
                    + comparison_reasoning
                )
                termination = (
                    "budget"
                    if assessment_term == "budget" or comparison_term == "budget"
                    else "natural"
                )

                attempt.selected_labels = decision.order
                attempt.assessments = {
                    label: decision.assessments[label].as_dict() for label in labels
                }
                attempt.decision_scores = decision.scores
                attempt.final_ranking = {
                    label: {"rank": decision.entries[label].rank} for label in labels
                }
                attempt.reasoning = reasoning
                attempt.reasoning_termination = termination
                attempt.assessment_termination = assessment_term
                attempt.comparison_termination = comparison_term
                attempt.quality_flags = quality_flags
                self._write_trace(body, attempt)

                ranking = [
                    RankedItem(
                        rank=decision.entries[label].rank,
                        key=label_to_key[label],
                        score=decision.scores[label],
                    )
                    for label in decision.order
                ]
                prompt_digest = hashlib.sha256(body.prompt.encode("utf-8")).hexdigest()
                raw_output = (
                    "=== ASSESSMENT PASS ===\n"
                    + assessment.full_output
                    + "\n=== COMPARISON PASS ===\n"
                    + comparison.full_output
                )
                return RankResponse(
                    protocol_version=PROTOCOL_VERSION,
                    plugin_version=__version__,
                    request_id=body.request_id,
                    model=self.model_name,
                    prompt_sha256=prompt_digest,
                    ranking=ranking,
                    usage=aggregate,
                    reasoning_termination=termination,
                    assessment_termination=assessment_term,
                    comparison_termination=comparison_term,
                    quality_flags=quality_flags,
                    reasoning=reasoning if body.include_diagnostics else None,
                    raw_output=raw_output if body.include_diagnostics else None,
                    decision_scores=(decision.scores if body.include_diagnostics else None),
                    label_to_key=label_to_key,
                    attempts=attempts if body.include_diagnostics else None,
                )
            except Exception as exc:
                attempt.error = str(exc)
                self._debug_event(
                    "attempt_failed",
                    request_id=body.request_id,
                    attempt=attempt.attempt,
                    error_type=type(exc).__name__,
                    error=str(exc),
                    traceback=traceback.format_exc(),
                )
                self._write_trace(body, attempt)

        raise HTTPException(
            status_code=422,
            detail=json.dumps(
                {
                    "message": "SiftRank failed to construct a complete ranking",
                    "request_id": body.request_id,
                    "errors": [attempt.error for attempt in attempts],
                },
                ensure_ascii=False,
            ),
        )

    async def _generate_assessment(
        self,
        *,
        body: RankRequest,
        prompt: str,
        labels: list[str],
        seed: int,
        attempt_number: int,
    ) -> _GenerationResult:
        assessment_budget, comparison_budget = self._split_reasoning_budget(
            body.reasoning_token_budget
        )
        assessment_min, _ = self._split_minimum_budget(
            body.minimum_reasoning_token_budget,
            assessment_budget,
            comparison_budget,
        )
        prefill = build_assessment_prefill()
        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": prefill},
        ]
        score_label_prefixes = self._score_label_prefixes(labels)
        structure_tokens = (
            len(self.assessment_budget_handoff_ids)
            + len(self.score_ready_trigger_ids)
            + len(self.scores_prefix_ids)
            + sum(len(prefix) for prefix in score_label_prefixes)
            + len(labels) * max(len(sequence) for sequence in self.score_token_sequences)
            + len(self.scores_suffix_ids)
            + 2
        )
        custom_xargs = {
            "siftrank_mode": _ASSESSMENT_LOGITS_MODE,
            "siftrank_min_reasoning_tokens": assessment_min,
            "siftrank_max_reasoning_tokens": assessment_budget,
            "siftrank_ready_token_sequences": self.score_ready_token_sequences,
            "siftrank_ready_trigger_ids": self.score_ready_trigger_ids,
            "siftrank_budget_handoff_ids": self.assessment_budget_handoff_ids,
            "siftrank_scores_prefix_ids": self.scores_prefix_ids,
            "siftrank_score_label_prefix_ids": score_label_prefixes,
            "siftrank_score_token_sequences": self.score_token_sequences,
            "siftrank_score_suffix_ids": self.scores_suffix_ids,
            "siftrank_forbidden_reasoning_sequences": self.forbidden_reasoning_sequences,
            "siftrank_eos_token_id": self.eos_token_id,
        }
        return await self._generate_chat(
            body=body,
            messages=messages,
            assistant_prefill=prefill,
            request_id=f"{body.request_id}:a{attempt_number}:assessment",
            seed=seed,
            max_tokens=assessment_budget + structure_tokens,
            custom_xargs=custom_xargs,
            terminal_marker=SCORES_MARKER,
            ready_marker=SCORE_READY_MARKER,
            reasoning_end_marker=SCORE_READY_MARKER,
            budget_sentence=ASSESSMENT_BUDGET_HANDOFF_SENTENCE,
            phase="assessment",
        )

    async def _generate_comparison(
        self,
        *,
        body: RankRequest,
        assessment_prompt: str,
        assessment_output: str,
        labels: list[str],
        seed: int,
        attempt_number: int,
    ) -> _GenerationResult:
        assessment_budget, comparison_budget = self._split_reasoning_budget(
            body.reasoning_token_budget
        )
        _, comparison_min = self._split_minimum_budget(
            body.minimum_reasoning_token_budget,
            assessment_budget,
            comparison_budget,
        )
        prefill = build_comparison_prefill()
        messages = [
            {"role": "user", "content": assessment_prompt},
            {"role": "assistant", "content": assessment_output},
            {"role": "user", "content": build_comparison_prompt(labels)},
            {"role": "assistant", "content": prefill},
        ]
        text_label_sequences = [
            self.text_label_token_sequences[label] for label in labels
        ]
        json_label_sequences = [
            self.json_label_token_sequences[label] for label in labels
        ]
        text_position_separators = [
            self._encode_required(f"\n{position}. ")
            for position in range(2, len(labels) + 1)
        ]
        max_text_label_tokens = max(len(sequence) for sequence in text_label_sequences)
        max_json_label_tokens = max(len(sequence) for sequence in json_label_sequences)
        structure_tokens = (
            len(self.ranking_budget_handoff_ids)
            + max(
                len(sequence)
                for sequence in self.order_commit_ready_token_sequences
            )
            + len(self.text_order_prefix_ids)
            + len(labels) * max_text_label_tokens
            + sum(len(separator) for separator in text_position_separators)
            + len(self.order_ready_ids)
            + len(self.order_prefix_ids)
            + len(labels) * max_json_label_tokens
            + (len(labels) - 1) * len(self.separator_ids)
            + len(self.order_suffix_ids)
            + 4
        )
        custom_xargs = {
            "siftrank_mode": _ORDERING_LOGITS_MODE,
            "siftrank_min_reasoning_tokens": comparison_min,
            "siftrank_max_reasoning_tokens": comparison_budget,
            # The model hands off with READY_TO_COMMIT. FINAL_ORDER is entirely
            # server-forced after that distinct boundary, so a naturally started
            # numbered ranking can never be silently restarted.
            "siftrank_ready_token_sequences": (
                self.order_commit_ready_token_sequences
            ),
            "siftrank_ready_trigger_ids": self.order_commit_ready_trigger_ids,
            "siftrank_budget_handoff_ids": self.ranking_budget_handoff_ids,
            "siftrank_text_order_prefix_ids": self.text_order_prefix_ids,
            "siftrank_text_label_token_sequences": text_label_sequences,
            "siftrank_text_position_separator_ids": text_position_separators,
            "siftrank_order_ready_ids": self.order_ready_ids,
            "siftrank_order_prefix_ids": self.order_prefix_ids,
            "siftrank_json_label_token_sequences": json_label_sequences,
            "siftrank_separator_ids": self.separator_ids,
            "siftrank_order_suffix_ids": self.order_suffix_ids,
            "siftrank_forbidden_reasoning_sequences": (
                self.comparison_forbidden_reasoning_sequences
            ),
            "siftrank_eos_token_id": self.eos_token_id,
        }
        return await self._generate_chat(
            body=body,
            messages=messages,
            assistant_prefill=prefill,
            request_id=f"{body.request_id}:a{attempt_number}:comparison",
            seed=seed,
            max_tokens=comparison_budget + structure_tokens,
            custom_xargs=custom_xargs,
            terminal_marker=ORDER_MARKER,
            ready_marker=ORDER_READY_MARKER,
            reasoning_end_marker=TEXT_ORDER_MARKER,
            budget_sentence=RANKING_BUDGET_HANDOFF_SENTENCE,
            phase="comparison",
        )

    async def _generate_chat(
        self,
        *,
        body: RankRequest,
        messages: list[dict[str, str]],
        assistant_prefill: str,
        request_id: str,
        seed: int,
        max_tokens: int,
        custom_xargs: dict[str, Any],
        terminal_marker: str,
        ready_marker: str,
        reasoning_end_marker: str,
        budget_sentence: str,
        phase: str,
    ) -> _GenerationResult:
        kwargs: dict[str, Any] = {
            "model": self.model_name,
            "messages": messages,
            "request_id": request_id,
            "seed": seed,
            "max_completion_tokens": max_tokens,
            "temperature": body.temperature,
            "add_generation_prompt": False,
            "continue_final_message": True,
        }
        if body.top_p is not None:
            kwargs["top_p"] = body.top_p
        if body.top_k is not None:
            kwargs["top_k"] = body.top_k

        chat_request = ChatCompletionRequest(**kwargs)
        rendered = await self.online_renderer.render_chat(chat_request)
        if not isinstance(rendered, tuple):
            message = getattr(rendered, "message", repr(rendered))
            raise RuntimeError(f"prompt rendering failed: {message}")
        _, engine_inputs = rendered
        if len(engine_inputs) != 1:
            raise RuntimeError(f"expected one engine input, got {len(engine_inputs)}")

        sampling_params = chat_request.to_sampling_params(
            max_tokens=max_tokens,
            default_sampling_params=self.default_sampling_params,
        )
        merged_extra_args = dict(getattr(sampling_params, "extra_args", None) or {})
        merged_extra_args.update(custom_xargs)
        sampling_params.extra_args = merged_extra_args

        final_output = None
        async for output in self.engine_client.generate(
            engine_inputs[0], sampling_params, request_id
        ):
            final_output = output
        if final_output is None or not final_output.outputs:
            raise RuntimeError("vLLM returned no generation output")

        completion = final_output.outputs[0]
        text = completion.text or ""
        full_output = assistant_prefill + text
        prompt_tokens = len(final_output.prompt_token_ids or [])
        output_tokens = len(completion.token_ids or [])
        token_ids = [int(token_id) for token_id in (completion.token_ids or [])]
        terminal_start = text.rfind(terminal_marker)
        if terminal_start < 0:
            self._debug_event(
                "generation_missing_terminal_marker",
                request_id=request_id,
                phase=phase,
                terminal_marker=terminal_marker,
                finish_reason=completion.finish_reason,
                output_tokens=output_tokens,
                generated_text_tail=text[-2000:],
                token_ids_tail=token_ids[-128:],
                sampling_extra_args=custom_xargs,
            )
            raise RuntimeError(
                f"generated output does not contain {terminal_marker}; "
                f"finish_reason={completion.finish_reason!r}, "
                f"output_tokens={output_tokens}"
            )

        ready_start = text.rfind(ready_marker, 0, terminal_start)
        if ready_start < 0:
            raise RuntimeError(
                f"generated output does not contain {ready_marker} before "
                f"{terminal_marker}"
            )
        try:
            reasoning_end = reasoning_end_index(
                text,
                ready_start=ready_start,
                ready_marker=ready_marker,
                reasoning_end_marker=reasoning_end_marker,
            )
        except ValueError as exc:
            raise RuntimeError(str(exc)) from exc
        reasoning_tokens = len(
            self.tokenizer.encode(
                text[:reasoning_end],
                add_special_tokens=False,
            )
        )
        reasoning_limit = int(custom_xargs["siftrank_max_reasoning_tokens"])
        termination = (
            "budget"
            if budget_sentence in text or reasoning_tokens >= reasoning_limit
            else "natural"
        )
        usage = TokenUsage(
            prompt_tokens=prompt_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=prompt_tokens + output_tokens,
        )
        diagnostic = GenerationDiagnostic(
            phase=phase,
            request_id=request_id,
            messages=messages,
            assistant_prefill=assistant_prefill,
            generated_text=text,
            full_output=full_output,
            finish_reason=completion.finish_reason,
            structured_output={"custom_logits_processor": custom_xargs},
            termination=termination,
            usage=usage,
        )
        return _GenerationResult(
            text=text,
            full_output=full_output,
            finish_reason=completion.finish_reason,
            usage=usage,
            termination=termination,
            diagnostic=diagnostic,
        )

    def _debug_event(self, event: str, **fields: Any) -> None:
        record = {
            "type": "siftrank_endpoint_debug",
            "event": event,
            "timestamp": time.time(),
            "protocol_version": PROTOCOL_VERSION,
            **fields,
        }
        try:
            _LOG.info(
                "siftrank debug %s",
                json.dumps(record, ensure_ascii=False, default=repr),
            )
            if not self.debug_path:
                return
            path = Path(self.debug_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with _TRACE_LOCK:
                with path.open("a", encoding="utf-8") as output:
                    output.write(
                        json.dumps(record, ensure_ascii=False, default=repr) + "\n"
                    )
        except Exception:
            _LOG.exception("failed to write SiftRank debug event %s", event)

    @staticmethod
    def _derived_seed(base: int, offset: int) -> int:
        return ((base + offset + 2**63) % (2**64)) - 2**63

    @staticmethod
    def _add_usage(total: TokenUsage, value: TokenUsage) -> None:
        total.prompt_tokens += value.prompt_tokens
        total.output_tokens += value.output_tokens
        total.reasoning_tokens += value.reasoning_tokens
        total.total_tokens += value.total_tokens

    def _write_trace(self, body: RankRequest, attempt: AttemptDiagnostic) -> None:
        if not self.trace_path:
            return
        record = {
            "type": "siftrank_endpoint_attempt",
            "timestamp": time.time(),
            "protocol_version": PROTOCOL_VERSION,
            "request": body.model_dump(),
            "attempt": attempt.model_dump(),
        }
        path = Path(self.trace_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with _TRACE_LOCK:
            with path.open("a", encoding="utf-8") as output:
                output.write(json.dumps(record, ensure_ascii=False) + "\n")


class SiftRankEndpointPlugin:
    name = "siftrank"
    required_tasks = ("generate",)

    def attach_router(self, app: FastAPI) -> None:
        @app.get("/v1/siftrank/health")
        async def health(raw_request: Request) -> dict[str, Any]:
            handler = getattr(raw_request.app.state, "siftrank_handler", None)
            return {
                "ok": handler is not None,
                "plugin": self.name,
                "protocol_version": PROTOCOL_VERSION,
                "plugin_version": __version__,
                "model": handler.model_name if handler is not None else None,
                "item_format": "xml-cdata",
                "reasoning_protocol": "two-pass-score-then-numbered-order-copy",
                "logits_processor": (
                    "vllm_siftrank.logits_processor:SiftRankLogitsProcessor"
                ),
            }

        @app.post("/v1/siftrank", response_model=RankResponse)
        async def rank(body: RankRequest, raw_request: Request) -> RankResponse:
            handler = getattr(raw_request.app.state, "siftrank_handler", None)
            if handler is None:
                raise HTTPException(
                    status_code=503, detail="SiftRank engine is unavailable"
                )
            try:
                return await handler.rank(body)
            except HTTPException:
                raise
            except Exception as exc:
                handler._debug_event(
                    "route_failed",
                    request_id=body.request_id,
                    error_type=type(exc).__name__,
                    error=str(exc),
                    traceback=traceback.format_exc(),
                )
                _LOG.exception("SiftRank route failed request_id=%s", body.request_id)
                raise HTTPException(
                    status_code=500,
                    detail=json.dumps(
                        {
                            "message": "SiftRank endpoint implementation failure",
                            "request_id": body.request_id,
                        },
                        ensure_ascii=False,
                    ),
                ) from exc

    async def init_state(
        self,
        engine_client: EngineClient | None,
        state: State,
        args: Namespace,
    ) -> None:
        state.siftrank_handler = (
            SiftRankHandler(engine_client, state, args)
            if engine_client is not None
            else None
        )
