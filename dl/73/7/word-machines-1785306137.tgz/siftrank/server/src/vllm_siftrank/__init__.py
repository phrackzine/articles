"""vLLM SiftRank endpoint plugin."""

__all__ = ["__version__"]
__version__ = "0.12.2"
