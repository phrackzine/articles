from __future__ import annotations

import json
import random
from dataclasses import dataclass
from typing import Any, Iterable

PROTOCOL_VERSION = "final-ranking-v4.9"

LABEL_POOL: tuple[str, ...] = (
    "kob",
    "nef",
    "gim",
    "naw",
    "lij",
    "yup",
    "zaj",
    "rex",
    "pog",
    "hic",
)

SCORE_MIN = 0
SCORE_MAX = 3

SCORE_READY_MARKER = "READY_TO_SCORE"
SCORE_READY_TRIGGER = "\nREADY_TO_SCORE"
SCORES_MARKER = "SCORES="
SCORES_PREFIX = "\nSCORES={"
SCORES_SUFFIX = "}\n</think>"
ASSESSMENT_BUDGET_HANDOFF_SENTENCE = (
    "Assessment budget reached. Use the analysis above to assign the absolute "
    "scores now."
)
ASSESSMENT_BUDGET_HANDOFF = "\n...\n" + ASSESSMENT_BUDGET_HANDOFF_SENTENCE

TEXT_ORDER_MARKER = "FINAL_ORDER:"
TEXT_ORDER_TRIGGER = "\nFINAL_ORDER:\n1. "
ORDER_COMMIT_READY_MARKER = "READY_TO_COMMIT"
ORDER_COMMIT_READY_TRIGGER = "\nREADY_TO_COMMIT"
ORDER_READY_MARKER = "READY_TO_ORDER"
ORDER_READY_TRIGGER = "\nREADY_TO_ORDER"
ORDER_MARKER = "ORDER="
ORDER_PREFIX = "\nORDER=["
ORDER_SEPARATOR = ","
ORDER_SUFFIX = "]\n</think>"
RANKING_BUDGET_HANDOFF_SENTENCE = (
    "Comparison budget reached. Use the completed assessments and comparison "
    "above to choose the complete order now."
)
RANKING_BUDGET_HANDOFF = "\n...\n" + RANKING_BUDGET_HANDOFF_SENTENCE

# Retained for parsing older trace artifacts only. v4.9 model output uses a
# constrained FINAL_ORDER numbered commitment followed by a mechanically copied ORDER=.
FINAL_MARKER = "FINAL_RANKING="
FINAL_SUFFIX = "\n</think>"


@dataclass(frozen=True)
class LabeledItem:
    label: str
    key: str
    text: str


@dataclass(frozen=True)
class Assessment:
    score: int
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {"score": self.score, "reason": self.reason}


@dataclass(frozen=True)
class RankingEntry:
    rank: int


@dataclass(frozen=True)
class RankScoreConflict:
    higher_ranked_label: str
    higher_rank: int
    higher_score: int
    lower_ranked_label: str
    lower_rank: int
    lower_score: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "rank_score_conflict",
            "higher_ranked_label": self.higher_ranked_label,
            "higher_rank": self.higher_rank,
            "higher_score": self.higher_score,
            "lower_ranked_label": self.lower_ranked_label,
            "lower_rank": self.lower_rank,
            "lower_score": self.lower_score,
        }


@dataclass(frozen=True)
class DecisionOutput:
    entries: dict[str, RankingEntry]
    order: list[str]
    assessments: dict[str, Assessment]
    scores: dict[str, int]
    conflicts: list[RankScoreConflict]


class _DuplicateKeyError(ValueError):
    pass


def _cdata(value: str) -> str:
    """Return a lossless XML CDATA representation of opaque item text."""
    return "<![CDATA[" + value.replace("]]>", "]]]]><![CDATA[>") + "]]>"


def randomize_labeled_items(
    items: Iterable[tuple[str, str]],
    labels: Iterable[str],
    *,
    assignment_seed: int,
    presentation_seed: int,
) -> list[LabeledItem]:
    """Assign items to labels and independently randomize rendered label order."""
    item_pairs = list(items)
    label_list = list(labels)
    if len(item_pairs) != len(label_list):
        raise ValueError("item and label counts must match")
    if len(set(label_list)) != len(label_list):
        raise ValueError("labels must be unique")

    assignment_rng = random.Random(assignment_seed)
    assignment_rng.shuffle(item_pairs)
    assigned = {
        label: LabeledItem(label=label, key=key, text=text)
        for label, (key, text) in zip(label_list, item_pairs)
    }

    presentation_labels = list(label_list)
    random.Random(presentation_seed).shuffle(presentation_labels)
    return [assigned[label] for label in presentation_labels]


def render_items(items: Iterable[LabeledItem]) -> str:
    rendered: list[str] = ["<items>"]
    for item in items:
        rendered.extend(
            [
                f'  <item label="{item.label}">',
                "    <content>",
                "      " + _cdata(item.text),
                "    </content>",
                "  </item>",
            ]
        )
    rendered.append("</items>")
    return "\n".join(rendered)



def build_assessment_prompt(
    criterion: str,
    items: Iterable[LabeledItem],
    *,
    retry_note: str | None = None,
) -> str:
    items = list(items)
    labels = [item.label for item in items]
    labels_csv = ", ".join(labels)
    retry = ""
    if retry_note:
        retry = f"\nRetry correction:\n- {retry_note.strip()}\n"

    return f"""{criterion.strip()}

Internal SiftRank assessment contract:

- The labels are random bookkeeping symbols with no semantic or ordinal meaning.
- The XML <item> element is the authoritative label-to-content binding. Keep each
  label attached to the content inside its own <item>; never transfer, duplicate,
  combine, or invent evidence across labels.
- Judge only the exact supplied item content. Do not use label spelling, item
  order, persistent keys, filenames, paths, or line numbers as evidence unless
  the task criterion explicitly says that metadata is relevant.
- Assess every item independently before making any comparative ranking decision.
{retry}
For each exact label ({labels_csv}), reason about the item and assign an ABSOLUTE
0-3 evidence-strength score:

  0 = no relevant evidence or wrong category
  1 = weak, indirect, or ambiguous evidence
  2 = clear direct evidence
  3 = unmistakable, high-confidence direct evidence

Multiple items may receive the same score, including 3. A score is not a rank.
Score only evidence for the exact task criterion; generic activity is not evidence.
Do not assign or reserve rank positions in this assessment pass. Do not call an
item best, worst, first, second, or otherwise compare its placement with another
item. You may write natural prose and inspect the candidates in any order, but
make sure every exact label has been considered before finishing.

When all independent assessments are complete, emit exactly:

{SCORE_READY_MARKER}

Do not emit SCORES or FINAL_RANKING yourself. The server will append the one
machine-readable score record after READY_TO_SCORE. Do not close the thinking
block; the server will close it.

Items:

{render_items(items)}
"""


def build_comparison_prompt(labels: Iterable[str]) -> str:
    labels = list(labels)
    labels_csv = ", ".join(labels)
    n = len(labels)
    return f"""Now perform the comparison phase using the complete independent assessments
and the server-authored SCORES record above.

- Required labels: {labels_csv}
- A SCORE is a preliminary absolute assessment; a RANK is the final relative
  placement in this batch.
- Compare all candidates only now, after the assessment pass has completed.
- Rank 1 is best and rank {n} is worst.
- Use every rank from 1 through {n} exactly once.
- Use scores as evidence, not as hard ordering constraints. The comparison may
  override a mistaken score when the original task criterion and completed
  reasoning support a different order.
- A lower-scored candidate may rank above a higher-scored candidate. When that
  happens, briefly explain the correction in the comparative reasoning.
- Keep every label attached to its original XML item content.

Write concise comparative reasoning, but do not state a complete ordered label
list in the prose. When the order is settled, emit a line containing exactly:

{ORDER_COMMIT_READY_MARKER}

Do not emit FINAL_ORDER yourself. After the marker, the server will append and
constrain one complete numbered ranking using every required label exactly once,
in this exact form:

{TEXT_ORDER_MARKER}
1. <best label>
2. <next label>
...
{n}. <worst label>

At each constrained position, choose the label for that rank. Do not omit a
position, use placeholders, or revise the sequence after starting this numbered
ranking. This complete numbered ranking is your sole model ranking decision.

Immediately after the complete numbered ranking, emit exactly:

{ORDER_READY_MARKER}

The server will then append one machine-readable ORDER array that repeats the
numbered label sequence exactly. Do not make a new ranking decision while
producing ORDER. Before READY_TO_COMMIT, do not emit FINAL_ORDER, READY_TO_ORDER,
ORDER, or FINAL_RANKING. Do not emit any prose after the constrained ORDER. Do
not close the thinking block; the server will close it.
"""


def build_assessment_prefill() -> str:
    return (
        "<think>\n"
        "I understand the criteria and will not restate the instructions. "
        "I will inspect each item directly, keep every label bound to its exact "
        "content, and complete all independent assessments before scoring.\n\n"
        "Direct assessments:\n"
    )


def build_comparison_prefill() -> str:
    return (
        "<think>\n"
        "I understand the criteria and will not restate the instructions. "
        "I will compare the items directly, keep every label bound to its exact "
        "content, treat preliminary scores as advisory evidence, and signal when "
        "I am ready for one constrained numbered ranking and its machine-readable "
        "ORDER copy.\n\n"
        "Direct comparison:\n"
    )


def label_json_literal(label: str) -> str:
    return json.dumps(label, ensure_ascii=False, separators=(",", ":"))


def _object_pairs_no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateKeyError(f"duplicate JSON object key {key!r}")
        result[key] = value
    return result


def marker_count(output: str, marker: str) -> int:
    return output.count(marker)


def final_marker_count(output: str) -> int:
    return marker_count(output, FINAL_MARKER)


def score_marker_count(output: str) -> int:
    return marker_count(output, SCORES_MARKER)


def _raw_decode_last_object(
    output: str,
    *,
    marker: str,
    trailing_suffix: str,
    object_name: str,
) -> dict[str, Any]:
    marker_index = output.rfind(marker)
    if marker_index < 0:
        raise ValueError(f"output does not contain {object_name}")
    payload = output[marker_index + len(marker) :].lstrip()
    decoder = json.JSONDecoder(object_pairs_hook=_object_pairs_no_duplicates)
    try:
        decoded, end = decoder.raw_decode(payload)
    except (_DuplicateKeyError, json.JSONDecodeError) as exc:
        raise ValueError(f"{object_name} JSON is invalid: {exc}") from exc

    trailing = payload[end:]
    if trailing.startswith(trailing_suffix):
        trailing = trailing[len(trailing_suffix) :]
    if trailing.strip():
        raise ValueError(f"unexpected material after {object_name}: {trailing!r}")
    if not isinstance(decoded, dict):
        raise ValueError(f"{object_name} must be a JSON object")
    return decoded


def parse_scores(output: str, labels: list[str]) -> dict[str, int]:
    decoded = _raw_decode_last_object(
        output,
        marker=SCORES_MARKER,
        trailing_suffix="\n</think>",
        object_name="SCORES",
    )
    expected = set(labels)
    actual = set(decoded)
    if actual != expected:
        missing = sorted(expected - actual)
        unknown = sorted(actual - expected)
        raise ValueError(
            f"SCORES labels are incomplete; missing={missing}, unknown={unknown}"
        )

    scores: dict[str, int] = {}
    for label in labels:
        score = decoded[label]
        if isinstance(score, bool) or not isinstance(score, int):
            raise ValueError(f"score for {label!r} must be an integer")
        if not SCORE_MIN <= score <= SCORE_MAX:
            raise ValueError(
                f"score for {label!r} must be between {SCORE_MIN} and {SCORE_MAX}"
            )
        scores[label] = score
    return scores


def parse_order(output: str, labels: list[str]) -> list[str]:
    marker_index = output.rfind(ORDER_MARKER)
    if marker_index < 0:
        raise ValueError("output does not contain ORDER")
    payload = output[marker_index + len(ORDER_MARKER) :].lstrip()
    decoder = json.JSONDecoder()
    try:
        decoded, end = decoder.raw_decode(payload)
    except json.JSONDecodeError as exc:
        raise ValueError(f"ORDER JSON is invalid: {exc}") from exc

    trailing = payload[end:]
    if trailing.startswith("\n</think>"):
        trailing = trailing[len("\n</think>") :]
    if trailing.strip():
        raise ValueError(f"unexpected material after ORDER: {trailing!r}")
    if not isinstance(decoded, list):
        raise ValueError("ORDER must be a JSON array")
    if any(not isinstance(label, str) for label in decoded):
        raise ValueError("ORDER entries must be strings")
    if len(decoded) != len(labels):
        raise ValueError(
            f"ORDER length is {len(decoded)}; expected {len(labels)}"
        )
    if len(set(decoded)) != len(decoded):
        raise ValueError("ORDER contains duplicate labels")
    expected = set(labels)
    actual = set(decoded)
    if actual != expected:
        missing = sorted(expected - actual)
        unknown = sorted(actual - expected)
        raise ValueError(
            f"ORDER labels are incomplete; missing={missing}, unknown={unknown}"
        )
    return list(decoded)



def parse_text_order(output: str, labels: list[str]) -> list[str]:
    marker_count = output.count(TEXT_ORDER_MARKER)
    if marker_count == 0:
        raise ValueError("output does not contain FINAL_ORDER")
    if marker_count > 1:
        raise ValueError(
            f"output contains multiple FINAL_ORDER markers: {marker_count}"
        )
    marker_index = output.index(TEXT_ORDER_MARKER)
    payload = output[marker_index + len(TEXT_ORDER_MARKER) :]
    ready_index = payload.find("\n" + ORDER_READY_MARKER)
    if ready_index < 0:
        raise ValueError("FINAL_ORDER is not followed by READY_TO_ORDER")
    numbered = payload[:ready_index].strip("\n")
    lines = numbered.splitlines()
    if len(lines) != len(labels):
        raise ValueError(
            f"FINAL_ORDER length is {len(lines)}; expected {len(labels)}"
        )

    order: list[str] = []
    for index, line in enumerate(lines, start=1):
        prefix = f"{index}. "
        if not line.startswith(prefix):
            raise ValueError(
                f"FINAL_ORDER line {index} must start with {prefix!r}"
            )
        label = line[len(prefix) :].strip()
        if not label:
            raise ValueError(f"FINAL_ORDER line {index} has no label")
        order.append(label)

    if len(set(order)) != len(order):
        raise ValueError("FINAL_ORDER contains duplicate labels")
    expected = set(labels)
    actual = set(order)
    if actual != expected:
        missing = sorted(expected - actual)
        unknown = sorted(actual - expected)
        raise ValueError(
            f"FINAL_ORDER labels are incomplete; missing={missing}, unknown={unknown}"
        )
    return order

def entries_from_order(order: list[str]) -> dict[str, RankingEntry]:
    return {
        label: RankingEntry(rank=index + 1)
        for index, label in enumerate(order)
    }


def order_marker_count(output: str) -> int:
    return marker_count(output, ORDER_MARKER)


def parse_final_ranking(output: str, labels: list[str]) -> dict[str, RankingEntry]:
    decoded = _raw_decode_last_object(
        output,
        marker=FINAL_MARKER,
        trailing_suffix=FINAL_SUFFIX,
        object_name="FINAL_RANKING",
    )
    expected = set(labels)
    actual = set(decoded)
    if actual != expected:
        missing = sorted(expected - actual)
        unknown = sorted(actual - expected)
        raise ValueError(
            f"FINAL_RANKING labels are incomplete; missing={missing}, unknown={unknown}"
        )

    entries: dict[str, RankingEntry] = {}
    seen_ranks: set[int] = set()
    for label in labels:
        value = decoded[label]
        if not isinstance(value, dict):
            raise ValueError(f"FINAL_RANKING entry for {label!r} must be an object")
        if set(value) != {"rank"}:
            raise ValueError(
                f"FINAL_RANKING entry for {label!r} must contain only rank"
            )
        rank = value["rank"]
        if isinstance(rank, bool) or not isinstance(rank, int):
            raise ValueError(f"rank for {label!r} must be an integer")
        if not 1 <= rank <= len(labels):
            raise ValueError(f"rank for {label!r} must be between 1 and {len(labels)}")
        if rank in seen_ranks:
            raise ValueError(f"FINAL_RANKING contains duplicate rank {rank}")
        seen_ranks.add(rank)
        entries[label] = RankingEntry(rank=rank)

    expected_ranks = set(range(1, len(labels) + 1))
    if seen_ranks != expected_ranks:
        raise ValueError(
            f"FINAL_RANKING rank set is incomplete; got={sorted(seen_ranks)}"
        )
    return entries


def apply_score_tier_fallback(
    entries: dict[str, RankingEntry],
    scores: dict[str, int],
    labels: list[str],
) -> dict[str, RankingEntry]:
    """Use descending score tiers, preserving model order within equal scores.

    This is only intended for a comparison phase that reaches its reasoning
    budget before finishing. Natural comparison completions remain fully free to
    override preliminary scores.
    """
    model_order = sorted(labels, key=lambda label: entries[label].rank)
    model_position = {label: index for index, label in enumerate(model_order)}
    fallback_order = sorted(
        labels,
        key=lambda label: (-scores[label], model_position[label]),
    )
    return {
        label: RankingEntry(rank=index + 1)
        for index, label in enumerate(fallback_order)
    }


def assemble_decision(
    entries: dict[str, RankingEntry],
    scores: dict[str, int],
    labels: list[str],
) -> DecisionOutput:
    order = sorted(labels, key=lambda label: entries[label].rank)
    assessments = {
        label: Assessment(score=scores[label], reason="") for label in labels
    }

    conflicts: list[RankScoreConflict] = []
    for higher_index, higher_label in enumerate(order):
        higher_rank = entries[higher_label].rank
        higher_score = scores[higher_label]
        for lower_label in order[higher_index + 1 :]:
            lower_rank = entries[lower_label].rank
            lower_score = scores[lower_label]
            if higher_score < lower_score:
                conflicts.append(
                    RankScoreConflict(
                        higher_ranked_label=higher_label,
                        higher_rank=higher_rank,
                        higher_score=higher_score,
                        lower_ranked_label=lower_label,
                        lower_rank=lower_rank,
                        lower_score=lower_score,
                    )
                )

    return DecisionOutput(
        entries=entries,
        order=order,
        assessments=assessments,
        scores=dict(scores),
        conflicts=conflicts,
    )




def reasoning_end_index(
    output: str,
    *,
    ready_start: int,
    ready_marker: str,
    reasoning_end_marker: str,
) -> int:
    """Return the end offset of free-form reasoning before a handoff.

    Assessment uses READY_TO_SCORE as both the handoff marker and the reasoning
    boundary. Comparison uses FINAL_ORDER as an earlier boundary so the numbered
    commitment is not counted as free-form comparison reasoning.
    """
    if reasoning_end_marker == ready_marker:
        return ready_start
    prefix = output[:ready_start]
    marker_count = prefix.count(reasoning_end_marker)
    if marker_count == 0:
        raise ValueError(
            f"generated output does not contain {reasoning_end_marker} "
            f"before {ready_marker}"
        )
    if marker_count > 1:
        raise ValueError(
            f"generated output contains multiple {reasoning_end_marker} markers "
            f"before {ready_marker}: {marker_count}"
        )
    return prefix.index(reasoning_end_marker)

def extract_reasoning_before_marker(
    completion: str,
    *,
    marker: str,
    budget_sentence: str,
) -> str:
    marker_index = completion.rfind(marker)
    if marker_index < 0:
        raise ValueError(f"completion does not contain {marker}")
    reasoning = completion[:marker_index]
    bridge_index = reasoning.rfind("\n...\n" + budget_sentence)
    if bridge_index >= 0:
        reasoning = reasoning[:bridge_index]
    reasoning = reasoning.strip()
    if reasoning.startswith("<think>"):
        reasoning = reasoning[len("<think>") :].lstrip()
    return reasoning


def assessment_termination(output: str) -> str:
    return (
        "budget"
        if ASSESSMENT_BUDGET_HANDOFF_SENTENCE in output
        else "natural"
    )


def ranking_termination(output: str) -> str:
    return "budget" if RANKING_BUDGET_HANDOFF_SENTENCE in output else "natural"
