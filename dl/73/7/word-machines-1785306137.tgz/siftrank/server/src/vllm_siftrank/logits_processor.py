from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import torch

from vllm import SamplingParams
from vllm.v1.sample.logits_processor import AdapterLogitsProcessor, RequestLogitsProcessor

_MODE_KEY = "siftrank_mode"
_ASSESSMENT_MODE = "assessment_scores_v4_9"
_ORDERING_MODE = "numbered_order_commit_v4_9"


def _is_int_list(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, int) for item in value)


def _is_int_list_list(value: Any) -> bool:
    return isinstance(value, list) and all(_is_int_list(item) and item for item in value)


def _force_only(
    logits: torch.Tensor,
    token_ids: Iterable[int],
    *,
    fallback_token_id: int,
) -> torch.Tensor:
    """Mask to a safe non-empty set without raising inside EngineCore."""
    vocab_size = int(logits.shape[-1])
    allowed = sorted(
        {
            int(token_id)
            for token_id in token_ids
            if isinstance(token_id, int) and 0 <= int(token_id) < vocab_size
        }
    )
    if not allowed and 0 <= fallback_token_id < vocab_size:
        allowed = [fallback_token_id]
    if not allowed:
        return logits

    kept = logits[allowed].clone()
    logits.fill_(float("-inf"))
    logits[allowed] = kept
    return logits


def _starts_with(values: list[int], prefix: list[int]) -> bool:
    return len(values) >= len(prefix) and values[: len(prefix)] == prefix


def _prefix_compatible(values: list[int], sequence: list[int]) -> bool:
    shared = min(len(values), len(sequence))
    return values[:shared] == sequence[:shared]


def _suffix_prefix_length(values: list[int], sequence: list[int]) -> int:
    if len(sequence) <= 1:
        return 0
    maximum = min(len(values), len(sequence) - 1)
    for length in range(maximum, 0, -1):
        if values[-length:] == sequence[:length]:
            return length
    return 0


def _find_subsequence(values: list[int], sequence: list[int], start: int = 0) -> int | None:
    if not sequence:
        return None
    last = len(values) - len(sequence)
    for index in range(max(0, start), last + 1):
        if values[index : index + len(sequence)] == sequence:
            return index
    return None


def _find_subsequence_crossing_or_after(
    values: list[int], sequence: list[int], boundary: int
) -> int | None:
    """Find a literal whose token span extends beyond a phase boundary.

    Leading-newline literals may share a token with the preceding sentinel.
    Searching only from ``boundary`` would miss that valid overlap and can cause
    the forced literal to restart forever.
    """
    if not sequence:
        return None
    start = max(0, boundary - len(sequence) + 1)
    last = len(values) - len(sequence)
    for index in range(start, last + 1):
        if index + len(sequence) <= boundary:
            continue
        if values[index : index + len(sequence)] == sequence:
            return index
    return None


def _find_last_subsequence(
    values: list[int], sequence: list[int], start: int = 0
) -> int | None:
    if not sequence:
        return None
    for index in range(len(values) - len(sequence), max(-1, start - 1), -1):
        if values[index : index + len(sequence)] == sequence:
            return index
    return None


def _find_last_any_subsequence(
    values: list[int], sequences: list[list[int]], start: int = 0
) -> tuple[int, int] | None:
    best: tuple[int, int] | None = None
    for sequence in sequences:
        index = _find_last_subsequence(values, sequence, start)
        if index is None:
            continue
        end = index + len(sequence)
        if best is None or end > best[1]:
            best = (index, end)
    return best


def _validate_no_prefix_conflicts(sequences: list[list[int]], name: str) -> None:
    for index, left in enumerate(sequences):
        for other_index, right in enumerate(sequences):
            if index == other_index:
                continue
            if len(left) <= len(right) and right[: len(left)] == left:
                raise ValueError(f"{name} token sequence prefixes another {name}")


@dataclass(frozen=True)
class _ChoiceState:
    valid: bool
    chosen_index: int | None
    consumed: int
    next_token_ids: list[int] | None


def _choice_state(
    payload: list[int],
    sequences: list[list[int]],
    eligible_indices: list[int],
) -> _ChoiceState:
    completed = [
        index for index in eligible_indices if _starts_with(payload, sequences[index])
    ]
    if completed:
        if len(completed) != 1:
            return _ChoiceState(False, None, 0, None)
        index = completed[0]
        return _ChoiceState(True, index, len(sequences[index]), None)

    candidates = [
        index
        for index in eligible_indices
        if _prefix_compatible(payload, sequences[index])
    ]
    if not candidates:
        return _ChoiceState(False, None, 0, None)
    if any(len(payload) >= len(sequences[index]) for index in candidates):
        return _ChoiceState(False, None, 0, None)
    return _ChoiceState(
        True,
        None,
        0,
        sorted({sequences[index][len(payload)] for index in candidates}),
    )


def _consume_literal(
    payload: list[int],
    cursor: int,
    literal: list[int],
) -> tuple[bool, int, list[int] | None]:
    fragment = payload[cursor:]
    if len(fragment) < len(literal):
        if fragment != literal[: len(fragment)]:
            return False, cursor, None
        return True, cursor, [literal[len(fragment)]]
    if not _starts_with(fragment, literal):
        return False, cursor, None
    return True, cursor + len(literal), None


@dataclass(frozen=True)
class _StructuredState:
    valid: bool
    complete: bool
    consumed: int
    next_token_ids: list[int] | None


def _score_state(
    payload: list[int],
    *,
    label_prefixes: list[list[int]],
    score_sequences: list[list[int]],
    final_suffix: list[int],
) -> _StructuredState:
    cursor = 0
    for prefix in label_prefixes:
        valid, cursor_after, next_ids = _consume_literal(payload, cursor, prefix)
        if not valid:
            return _StructuredState(False, False, cursor, None)
        if next_ids is not None:
            return _StructuredState(True, False, cursor, next_ids)
        cursor = cursor_after

        choice = _choice_state(
            payload[cursor:], score_sequences, list(range(len(score_sequences)))
        )
        if not choice.valid:
            return _StructuredState(False, False, cursor, None)
        if choice.chosen_index is None:
            return _StructuredState(True, False, cursor, choice.next_token_ids)
        cursor += choice.consumed

    valid, cursor_after, next_ids = _consume_literal(payload, cursor, final_suffix)
    if not valid:
        return _StructuredState(False, False, cursor, None)
    if next_ids is not None:
        return _StructuredState(True, False, cursor, next_ids)
    return _StructuredState(True, True, cursor_after, None)


def _order_state(
    payload: list[int],
    *,
    label_sequences: list[list[int]],
    separator: list[int],
    final_suffix: list[int],
) -> _StructuredState:
    remaining_labels = list(range(len(label_sequences)))
    cursor = 0

    for position in range(len(label_sequences)):
        choice = _choice_state(
            payload[cursor:], label_sequences, remaining_labels
        )
        if not choice.valid:
            return _StructuredState(False, False, cursor, None)
        if choice.chosen_index is None:
            return _StructuredState(True, False, cursor, choice.next_token_ids)
        chosen_label = choice.chosen_index
        cursor += choice.consumed
        remaining_labels.remove(chosen_label)

        if position + 1 < len(label_sequences):
            valid, cursor_after, next_ids = _consume_literal(
                payload, cursor, separator
            )
            if not valid:
                return _StructuredState(False, False, cursor, None)
            if next_ids is not None:
                return _StructuredState(True, False, cursor, next_ids)
            cursor = cursor_after

    valid, cursor_after, next_ids = _consume_literal(
        payload, cursor, final_suffix
    )
    if not valid:
        return _StructuredState(False, False, cursor, None)
    if next_ids is not None:
        return _StructuredState(True, False, cursor, next_ids)
    return _StructuredState(True, True, cursor_after, None)


@dataclass(frozen=True)
class _TextOrderState:
    valid: bool
    complete: bool
    consumed: int
    next_token_ids: list[int] | None
    chosen_indices: tuple[int, ...]


def _text_order_state(
    payload: list[int],
    *,
    label_sequences: list[list[int]],
    position_separators: list[list[int]],
) -> _TextOrderState:
    if len(position_separators) != max(0, len(label_sequences) - 1):
        return _TextOrderState(False, False, 0, None, ())

    remaining_labels = list(range(len(label_sequences)))
    chosen: list[int] = []
    cursor = 0

    for position in range(len(label_sequences)):
        choice = _choice_state(payload[cursor:], label_sequences, remaining_labels)
        if not choice.valid:
            return _TextOrderState(False, False, cursor, None, tuple(chosen))
        if choice.chosen_index is None:
            return _TextOrderState(
                True, False, cursor, choice.next_token_ids, tuple(chosen)
            )

        chosen_label = choice.chosen_index
        chosen.append(chosen_label)
        cursor += choice.consumed
        remaining_labels.remove(chosen_label)

        if position + 1 < len(label_sequences):
            valid, cursor_after, next_ids = _consume_literal(
                payload, cursor, position_separators[position]
            )
            if not valid:
                return _TextOrderState(
                    False, False, cursor, None, tuple(chosen)
                )
            if next_ids is not None:
                return _TextOrderState(
                    True, False, cursor, next_ids, tuple(chosen)
                )
            cursor = cursor_after

    return _TextOrderState(True, True, cursor, None, tuple(chosen))


def _fixed_order_state(
    payload: list[int],
    *,
    ordered_label_sequences: list[list[int]],
    separator: list[int],
    final_suffix: list[int],
) -> _StructuredState:
    cursor = 0
    for position, label_sequence in enumerate(ordered_label_sequences):
        valid, cursor_after, next_ids = _consume_literal(
            payload, cursor, label_sequence
        )
        if not valid:
            return _StructuredState(False, False, cursor, None)
        if next_ids is not None:
            return _StructuredState(True, False, cursor, next_ids)
        cursor = cursor_after

        if position + 1 < len(ordered_label_sequences):
            valid, cursor_after, next_ids = _consume_literal(
                payload, cursor, separator
            )
            if not valid:
                return _StructuredState(False, False, cursor, None)
            if next_ids is not None:
                return _StructuredState(True, False, cursor, next_ids)
            cursor = cursor_after

    valid, cursor_after, next_ids = _consume_literal(
        payload, cursor, final_suffix
    )
    if not valid:
        return _StructuredState(False, False, cursor, None)
    if next_ids is not None:
        return _StructuredState(True, False, cursor, next_ids)
    return _StructuredState(True, True, cursor_after, None)


class _NaturalHandoffMixin:
    eos_token_id: int
    ready_trigger: list[int]
    ready_sequences: list[list[int]]
    budget_handoff: list[int]
    forbidden_reasoning_sequences: list[list[int]]
    min_reasoning_tokens: int
    max_reasoning_tokens: int

    def _force(self, logits: torch.Tensor, token_ids: Iterable[int]) -> torch.Tensor:
        return _force_only(logits, token_ids, fallback_token_id=self.eos_token_id)

    def _block_sequence_completions(
        self,
        generated: list[int],
        logits: torch.Tensor,
        sequences: list[list[int]],
    ) -> None:
        for sequence in sequences:
            if len(sequence) == 1:
                token_id = sequence[0]
                if 0 <= token_id < logits.shape[-1]:
                    logits[token_id] = float("-inf")
                continue
            progress = _suffix_prefix_length(generated, sequence)
            if progress == len(sequence) - 1:
                token_id = sequence[progress]
                if 0 <= token_id < logits.shape[-1]:
                    logits[token_id] = float("-inf")

    def _force_literal_progress(
        self,
        generated: list[int],
        logits: torch.Tensor,
        literal: list[int],
    ) -> torch.Tensor:
        progress = _suffix_prefix_length(generated, literal)
        return self._force(logits, [literal[progress]])

    def _redirect_natural_stop(
        self,
        generated: list[int],
        logits: torch.Tensor,
    ) -> torch.Tensor:
        start_token = self.ready_trigger[0]
        if 0 <= self.eos_token_id < logits.shape[-1]:
            logits[start_token] = torch.maximum(
                logits[start_token], logits[self.eos_token_id]
            )
            logits[self.eos_token_id] = float("-inf")

        for sequence in self.forbidden_reasoning_sequences:
            if len(sequence) == 1:
                token_id = sequence[0]
                if 0 <= token_id < logits.shape[-1]:
                    logits[start_token] = torch.maximum(
                        logits[start_token], logits[token_id]
                    )
                    logits[token_id] = float("-inf")
                continue
            progress = _suffix_prefix_length(generated, sequence)
            if progress == len(sequence) - 1:
                token_id = sequence[progress]
                if 0 <= token_id < logits.shape[-1]:
                    logits[start_token] = torch.maximum(
                        logits[start_token], logits[token_id]
                    )
                    logits[token_id] = float("-inf")
        return logits

    def _ready_or_reason(
        self,
        generated: list[int],
        logits: torch.Tensor,
    ) -> tuple[tuple[int, int] | None, torch.Tensor | None]:
        ready = _find_last_any_subsequence(generated, self.ready_sequences, start=0)
        if ready is not None:
            return ready, None

        ready_progress = _suffix_prefix_length(generated, self.ready_trigger)
        if ready_progress > 0:
            return None, self._force(logits, [self.ready_trigger[ready_progress]])

        if len(generated) < self.min_reasoning_tokens:
            if 0 <= self.eos_token_id < logits.shape[-1]:
                logits[self.eos_token_id] = float("-inf")
            self._block_sequence_completions(
                generated,
                logits,
                self.ready_sequences + self.forbidden_reasoning_sequences,
            )
            return None, logits

        if len(generated) >= self.max_reasoning_tokens:
            bridge_start = _find_subsequence_crossing_or_after(
                generated, self.budget_handoff, self.max_reasoning_tokens
            )
            if bridge_start is None:
                return None, self._force_literal_progress(
                    generated, logits, self.budget_handoff
                )
            return None, self._force_literal_progress(
                generated, logits, self.ready_trigger
            )

        return None, self._redirect_natural_stop(generated, logits)


class _AssessmentScoreRequestLogitsProcessor(_NaturalHandoffMixin):
    def __init__(
        self,
        *,
        min_reasoning_tokens: int,
        max_reasoning_tokens: int,
        ready_sequences: list[list[int]],
        ready_trigger: list[int],
        budget_handoff: list[int],
        scores_prefix: list[int],
        score_label_prefixes: list[list[int]],
        score_sequences: list[list[int]],
        score_suffix: list[int],
        forbidden_reasoning_sequences: list[list[int]],
        eos_token_id: int,
    ) -> None:
        if min_reasoning_tokens < 1:
            raise ValueError("minimum reasoning tokens must be positive")
        if max_reasoning_tokens < min_reasoning_tokens:
            raise ValueError("maximum reasoning tokens must be >= minimum")
        if not ready_sequences or not ready_trigger or not budget_handoff:
            raise ValueError("assessment handoff token sequences must not be empty")
        if not scores_prefix or not score_label_prefixes or not score_sequences:
            raise ValueError("assessment score structure must not be empty")
        if not score_suffix:
            raise ValueError("assessment score suffix must not be empty")
        _validate_no_prefix_conflicts(score_sequences, "score")

        self.min_reasoning_tokens = min_reasoning_tokens
        self.max_reasoning_tokens = max_reasoning_tokens
        self.ready_sequences = ready_sequences
        self.ready_trigger = ready_trigger
        self.budget_handoff = budget_handoff
        self.scores_prefix = scores_prefix
        self.score_label_prefixes = score_label_prefixes
        self.score_sequences = score_sequences
        self.score_suffix = score_suffix
        self.forbidden_reasoning_sequences = forbidden_reasoning_sequences
        self.eos_token_id = eos_token_id

    def __call__(self, output_ids: list[int], logits: torch.Tensor) -> torch.Tensor:
        try:
            return self._apply(list(output_ids), logits)
        except Exception:
            return self._force(logits, [self.eos_token_id])

    def _apply(self, generated: list[int], logits: torch.Tensor) -> torch.Tensor:
        if generated and generated[-1] == self.eos_token_id:
            return self._force(logits, [self.eos_token_id])

        ready, action = self._ready_or_reason(generated, logits)
        if action is not None:
            return action
        assert ready is not None
        ready_end = ready[1]

        scores_start = _find_subsequence_crossing_or_after(
            generated, self.scores_prefix, ready_end
        )
        if scores_start is None:
            return self._force_literal_progress(generated, logits, self.scores_prefix)

        payload = generated[scores_start + len(self.scores_prefix) :]
        state = _score_state(
            payload,
            label_prefixes=self.score_label_prefixes,
            score_sequences=self.score_sequences,
            final_suffix=self.score_suffix,
        )
        if not state.valid:
            return self._force(logits, [self.eos_token_id])
        if not state.complete:
            return self._force(logits, state.next_token_ids or [self.eos_token_id])
        return self._force(logits, [self.eos_token_id])


class _OrderRequestLogitsProcessor(_NaturalHandoffMixin):
    def __init__(
        self,
        *,
        min_reasoning_tokens: int,
        max_reasoning_tokens: int,
        commit_sequences: list[list[int]],
        commit_trigger: list[int],
        budget_handoff: list[int],
        text_order_prefix: list[int],
        text_label_sequences: list[list[int]],
        text_position_separators: list[list[int]],
        order_ready: list[int],
        order_prefix: list[int],
        json_label_sequences: list[list[int]],
        separator: list[int],
        order_suffix: list[int],
        forbidden_reasoning_sequences: list[list[int]],
        eos_token_id: int,
    ) -> None:
        if min_reasoning_tokens < 1:
            raise ValueError("minimum reasoning tokens must be positive")
        if max_reasoning_tokens < min_reasoning_tokens:
            raise ValueError("maximum reasoning tokens must be >= minimum")
        literals = (
            commit_trigger,
            budget_handoff,
            text_order_prefix,
            order_ready,
            order_prefix,
            separator,
            order_suffix,
        )
        if any(not literal for literal in literals):
            raise ValueError("ordering forced literals must not be empty")
        if not commit_sequences or not text_label_sequences or not json_label_sequences:
            raise ValueError("ordering requires commit and label token sequences")
        if len(text_label_sequences) != len(json_label_sequences):
            raise ValueError("text and JSON label sequence counts must match")
        if len(text_position_separators) != max(0, len(text_label_sequences) - 1):
            raise ValueError("numbered-order separators do not match label count")
        _validate_no_prefix_conflicts(text_label_sequences, "text label")
        _validate_no_prefix_conflicts(json_label_sequences, "JSON label")

        self.min_reasoning_tokens = min_reasoning_tokens
        self.max_reasoning_tokens = max_reasoning_tokens
        # The model emits a distinct READY_TO_COMMIT handoff. FINAL_ORDER itself
        # is server-forced after that boundary so a naturally started first line
        # can never be mistaken for the authoritative numbered commitment.
        self.ready_sequences = commit_sequences
        self.ready_trigger = commit_trigger
        self.budget_handoff = budget_handoff
        self.text_order_prefix = text_order_prefix
        self.text_label_sequences = text_label_sequences
        self.text_position_separators = text_position_separators
        self.order_ready = order_ready
        self.order_prefix = order_prefix
        self.json_label_sequences = json_label_sequences
        self.separator = separator
        self.order_suffix = order_suffix
        self.forbidden_reasoning_sequences = forbidden_reasoning_sequences
        self.eos_token_id = eos_token_id

    def __call__(self, output_ids: list[int], logits: torch.Tensor) -> torch.Tensor:
        try:
            return self._apply(list(output_ids), logits)
        except Exception:
            return self._force(logits, [self.eos_token_id])

    def _apply(self, generated: list[int], logits: torch.Tensor) -> torch.Tensor:
        if generated and generated[-1] == self.eos_token_id:
            return self._force(logits, [self.eos_token_id])

        commit, action = self._ready_or_reason(generated, logits)
        if action is not None:
            return action
        assert commit is not None
        commit_end = commit[1]

        text_order_start = _find_subsequence_crossing_or_after(
            generated, self.text_order_prefix, commit_end
        )
        if text_order_start is None:
            return self._force_literal_progress(
                generated, logits, self.text_order_prefix
            )
        text_order_end = text_order_start + len(self.text_order_prefix)

        text_payload = generated[text_order_end:]
        text_state = _text_order_state(
            text_payload,
            label_sequences=self.text_label_sequences,
            position_separators=self.text_position_separators,
        )
        if not text_state.valid:
            return self._force(logits, [self.eos_token_id])
        if not text_state.complete:
            return self._force(
                logits, text_state.next_token_ids or [self.eos_token_id]
            )

        text_end = text_order_end + text_state.consumed
        ready_start = _find_subsequence_crossing_or_after(
            generated, self.order_ready, text_end
        )
        if ready_start is None:
            return self._force_literal_progress(generated, logits, self.order_ready)
        ready_end = ready_start + len(self.order_ready)

        order_start = _find_subsequence_crossing_or_after(
            generated, self.order_prefix, ready_end
        )
        if order_start is None:
            return self._force_literal_progress(generated, logits, self.order_prefix)

        chosen_json_sequences = [
            self.json_label_sequences[index]
            for index in text_state.chosen_indices
        ]
        payload = generated[order_start + len(self.order_prefix) :]
        state = _fixed_order_state(
            payload,
            ordered_label_sequences=chosen_json_sequences,
            separator=self.separator,
            final_suffix=self.order_suffix,
        )
        if not state.valid:
            return self._force(logits, [self.eos_token_id])
        if not state.complete:
            return self._force(logits, state.next_token_ids or [self.eos_token_id])
        return self._force(logits, [self.eos_token_id])


class SiftRankLogitsProcessor(AdapterLogitsProcessor):
    """Crash-safe two-pass decoder with constrained scores and one authoritative order."""

    @classmethod
    def validate_params(cls, params: SamplingParams) -> None:
        args = params.extra_args or {}
        mode = args.get(_MODE_KEY)
        if mode not in {_ASSESSMENT_MODE, _ORDERING_MODE}:
            return

        common = {
            "siftrank_min_reasoning_tokens",
            "siftrank_max_reasoning_tokens",
            "siftrank_ready_token_sequences",
            "siftrank_ready_trigger_ids",
            "siftrank_budget_handoff_ids",
            "siftrank_forbidden_reasoning_sequences",
            "siftrank_eos_token_id",
        }
        assessment = {
            "siftrank_scores_prefix_ids",
            "siftrank_score_label_prefix_ids",
            "siftrank_score_token_sequences",
            "siftrank_score_suffix_ids",
        }
        ordering = {
            "siftrank_text_order_prefix_ids",
            "siftrank_text_label_token_sequences",
            "siftrank_text_position_separator_ids",
            "siftrank_order_ready_ids",
            "siftrank_order_prefix_ids",
            "siftrank_json_label_token_sequences",
            "siftrank_separator_ids",
            "siftrank_order_suffix_ids",
        }
        required = common | (assessment if mode == _ASSESSMENT_MODE else ordering)
        missing = sorted(required - set(args))
        if missing:
            raise ValueError(f"missing SiftRank logits-processor arguments: {missing}")

        for name in (
            "siftrank_min_reasoning_tokens",
            "siftrank_max_reasoning_tokens",
            "siftrank_eos_token_id",
        ):
            if not isinstance(args[name], int):
                raise ValueError(f"{name} must be an integer")
        for name in (
            "siftrank_ready_trigger_ids",
            "siftrank_budget_handoff_ids",
        ):
            if not _is_int_list(args[name]) or not args[name]:
                raise ValueError(f"{name} must be a non-empty list of integers")
        for name in (
            "siftrank_ready_token_sequences",
            "siftrank_forbidden_reasoning_sequences",
        ):
            if not _is_int_list_list(args[name]):
                raise ValueError(f"{name} must contain non-empty integer lists")

        if mode == _ASSESSMENT_MODE:
            for name in (
                "siftrank_scores_prefix_ids",
                "siftrank_score_suffix_ids",
            ):
                if not _is_int_list(args[name]) or not args[name]:
                    raise ValueError(f"{name} must be a non-empty list of integers")
            for name in (
                "siftrank_score_label_prefix_ids",
                "siftrank_score_token_sequences",
            ):
                if not _is_int_list_list(args[name]):
                    raise ValueError(f"{name} must contain non-empty integer lists")
        else:
            for name in (
                "siftrank_text_order_prefix_ids",
                "siftrank_order_ready_ids",
                "siftrank_order_prefix_ids",
                "siftrank_separator_ids",
                "siftrank_order_suffix_ids",
            ):
                if not _is_int_list(args[name]) or not args[name]:
                    raise ValueError(f"{name} must be a non-empty list of integers")
            for name in (
                "siftrank_text_label_token_sequences",
                "siftrank_json_label_token_sequences",
            ):
                if not _is_int_list_list(args[name]):
                    raise ValueError(f"{name} must contain non-empty integer lists")
            separators = args["siftrank_text_position_separator_ids"]
            if not isinstance(separators, list) or not all(
                _is_int_list(item) and item for item in separators
            ):
                raise ValueError(
                    "siftrank_text_position_separator_ids must contain "
                    "non-empty integer lists"
                )

    def is_argmax_invariant(self) -> bool:
        return False

    def new_req_logits_processor(
        self,
        params: SamplingParams,
    ) -> RequestLogitsProcessor | None:
        args = params.extra_args or {}
        mode = args.get(_MODE_KEY)
        if mode == _ASSESSMENT_MODE:
            return _AssessmentScoreRequestLogitsProcessor(
                min_reasoning_tokens=args["siftrank_min_reasoning_tokens"],
                max_reasoning_tokens=args["siftrank_max_reasoning_tokens"],
                ready_sequences=args["siftrank_ready_token_sequences"],
                ready_trigger=args["siftrank_ready_trigger_ids"],
                budget_handoff=args["siftrank_budget_handoff_ids"],
                scores_prefix=args["siftrank_scores_prefix_ids"],
                score_label_prefixes=args["siftrank_score_label_prefix_ids"],
                score_sequences=args["siftrank_score_token_sequences"],
                score_suffix=args["siftrank_score_suffix_ids"],
                forbidden_reasoning_sequences=args[
                    "siftrank_forbidden_reasoning_sequences"
                ],
                eos_token_id=args["siftrank_eos_token_id"],
            )
        if mode == _ORDERING_MODE:
            return _OrderRequestLogitsProcessor(
                min_reasoning_tokens=args["siftrank_min_reasoning_tokens"],
                max_reasoning_tokens=args["siftrank_max_reasoning_tokens"],
                commit_sequences=args["siftrank_ready_token_sequences"],
                commit_trigger=args["siftrank_ready_trigger_ids"],
                budget_handoff=args["siftrank_budget_handoff_ids"],
                text_order_prefix=args["siftrank_text_order_prefix_ids"],
                text_label_sequences=args[
                    "siftrank_text_label_token_sequences"
                ],
                text_position_separators=args[
                    "siftrank_text_position_separator_ids"
                ],
                order_ready=args["siftrank_order_ready_ids"],
                order_prefix=args["siftrank_order_prefix_ids"],
                json_label_sequences=args[
                    "siftrank_json_label_token_sequences"
                ],
                separator=args["siftrank_separator_ids"],
                order_suffix=args["siftrank_order_suffix_ids"],
                forbidden_reasoning_sequences=args[
                    "siftrank_forbidden_reasoning_sequences"
                ],
                eos_token_id=args["siftrank_eos_token_id"],
            )
        return None
