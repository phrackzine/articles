FREE function: {{.free.function}}
FREE code:
{{.free.target}}

USE function: {{.use.function}}
USE code:
{{.use.target}}
