# Word Machines for Weird Machines

An archive of the experimental code for my Phrack 73 submission. - @noperator

## Description

This code centers around using a 3B-parameter small language model to reproduce
discovery of CVE-2025-37778, a use-after-free in the SMB server of Linux kernel
v6.15-rc2. My goal here is to see what we can learn when we *really push* the
semantic reasoning capability of a small model.

Aside from the model itself, 90% of the heavy lifting here is done by SiftRank,
a document ranking algorithm that I developed and continue to iterate on.
Rather than leaning on an external SAST engine like CodeQL, I use SiftRank to
channel an SLM's semantic reasoning capability toward the code qualities I'm
looking for. The remaining 10% is done by Slice, another tool I've developed;
it's basically a glorified wrapper around Tree-sitter that lets me build a
lightweight call graph over source code and query it however I want. Both of
these tools are already on GitHub, but the packaged versions here are a bit
different.

SiftRank was totally rewritten (with assistance from gpt-5.6-sol-xhigh) for a
vLLM-specific implementation. The idea I tested here was to shift more logic
*inside* the inference engine, which ends up being much more efficient. For
example, SiftRank usually just expects an OpenAI-compatible API whose
constrained decoding knobs are pretty limited; e.g., you can't force a model to
return unique values, or return a complete set of predetermined values. By
operating inside vLLM's inference layer, we have a much higher degree of
control over masking logits, enforcing arbitrary schema, and even steering
reasoning effort mid-generation. I think this is a game-changing feature for
tightly harnessing small models.

Slice comparitively has a just few added features: namely, two subcommands
(`lines` and `relate`) for extracting line-level data from source code and then
determining call-chain relationships between arbitrary lines.

The whole flow is:
- extract source code lines
- rank them for "free"- and "use"-like qualities
- filter high-ranking "free" and "use" candidates for valid call relationships
- rank the resulting free-use candidate pairs by object similarity
- analyze the high-ranking free-use candidate pairs for actual reachability

The term "high-ranking" deserves some discussion since it implies a threshold
between high- and low-ranking candidates. Rather than picking a naive top-k
(e.g., top 100 ranked items), I use SiftRank to run a one-sample, one-sided
t-test on each item's accumulated rank observations against the null mean
(i.e., expected rank under random placement). A candidate whose mean rank is
significantly "below" the null (i.e., toward #1) at some p-value is one that
the SLM consistently ranks near the top of its batches. For ranking the initial
19.4k source lines, I filter for a p-value of 0.0001; this yields 121 free-like
lines and 680 use-like lines (a 99%+ reduction of the corpus--pretty good). For
ranking the resulting free-use candidate pairs, I allow SiftRank to rank across
multiple rounds and only consider candidates that survive at least 5 rounds;
this reduces 1.2k pairs to just 59 UAF candidates (95% reduction) that enter
final analysis. There's no single "right" answer when drawing the cutoff line,
and it largely depends on your own resource constraints and review budget. I'm
drawn to using a statistically principled threshold and the t-test fits that
pretty well.

So far, I've focused mostly on getting a small model to coherently reason over
the ranked candidates. There's still plenty of work to do on optimizing for
speed. On my single RTX 3090, this whole pipeline took a few hours to run. That
said, my GPU KV cache usage only hovered around 23%; this would indicate that
there's an opportunity to significantly increase concurrency before we saturate
the KV cache and vLLM's scheduler has to start queueing requests. I'd like to
explore ways of increasing prefill/decode speed, fully utilizing KV cache and
GPU compute, etc. Another benefit of using small models for this problem is
that it opens greater possibilities for horizontal scaling (vs. larger models
that require large contiguous blocks of VRAM).

For model selection, I chose VibeThinker-3B for its demonstrated reasoning
capability, but none of this code is particularly tailored to that model. Any
Qwen-like model should be able to drop in with minimal (or perhaps zero)
adjustments to the pipeline. At the moment, I'm particularly interested in
testing the 1-bit and ternary quants of Bonsai 27B, based on the currently
best-in-class Qwen3.6 27B.

Here's how the codebase is organized:

```
.
├── scripts/  # All described below.
│   ├── setup-environment.sh 
│   ├── serve-siftrank-model.sh
│   ├── run-ksmbd-uaf-ranking-pipeline.sh
│   ├── prepare-uaf-analysis-candidates.sh
│   ├── serve-uaf-analysis-model.sh
│   ├── run-uaf-deep-analysis.sh
│   └── analyze_uaf_candidates.py
├── siftrank/    # vLLM-native SiftRank algorithm implementation.
│   ├── client/  # CLI side.
│   └── server/  # vLLM side.
├── slice/       # Slightly modified Slice (compared to GitHub).
├── prompts/     # Prompts for UAF stuff.
├── templates/   # Go templates for extracting lines of code, etc.
└── linux-v6.15-rc2-fs-smb-server/  # Snapshot of CVE-2025-37778 in ksmbd.
```

## Getting started

### Prerequisites

You'll need a Linux host and working CUDA stack. Here's my tested
configuration:
- Ubuntu 24.04 x86-64
- NVIDIA GeForce RTX 3090 with 24 GB VRAM
- NVIDIA driver 595.84
- CUDA 13.0 toolkit

### Install

Run `scripts/setup-environment.sh` which will install:
- Pinned vLLM + various Python deps
- SiftRank vLLM endpoint
- SiftRank and Slice binaries

### Usage

This runs in two main phases: ranking and analysis. Each phase needs its own
specific vLLM configuration. This is all handled by the scripts below.

#### Ranking

- `scripts/serve-siftrank-model.sh` to start vLLM.
- `scripts/run-ksmbd-uaf-ranking-pipeline.sh` to find UAF candidates.
- `scripts/prepare-uaf-analysis-candidates.sh` to prepare for analysis.

#### Analysis

Stop the vLLM server from the last phase. Then:

- `scripts/serve-uaf-analysis-model.sh` to start VLLM.
- `scripts/run-uaf-deep-analysis.sh` to analyze UAF candidates.

### Troubleshooting

The pipeline logs extensively to `output/logs/`, so if something looks off,
check the files here first.

## Back matter

### Acknowledgements

Thanks to Sean Heelan (@seanhn) for CVE-2025-37778. I've gotten *way too much*
mileage out of this bug for benchmarking porpoises. Also to Richard Johnson
(@richinseattle) for encouraging me to submit to Phrack.

### See also

- https://sean.heelan.io/2025/05/22/how-i-used-o3-to-find-cve-2025-37899-a-remote-zeroday-vulnerability-in-the-linux-kernels-smb-implementation/
- https://github.com/noperator/slice
- https://github.com/noperator/siftrank
