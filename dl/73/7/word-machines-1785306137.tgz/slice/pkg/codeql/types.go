package codeql

import "github.com/noperator/slice/pkg/analysis"

type CodeQLResult struct {
	ObjName               string `json:"object"`
	FreeFunctionName      string `json:"free_func"`
	FreeFunctionFile      string `json:"free_file"`
	FreeFunctionDefLine   int    `json:"free_func_def_ln"`
	FreeLine              int    `json:"free_ln"`
	UseFunctionName       string `json:"use_func"`
	UseFunctionFile       string `json:"use_file"`
	UseFunctionDefLine    int    `json:"use_func_def_ln"`
	UseLine               int    `json:"use_ln"`
}

// SinkResult represents a single unsafe property access sink from CodeQL
type SinkResult struct {
	SinkFunc     string `json:"sink_func"`
	SinkFile     string `json:"sink_file"`
	SinkFuncDefLine int `json:"sink_func_def_ln"`
	SinkLine     int    `json:"sink_ln"`
	Object       string `json:"object"`
	Key          string `json:"key"`
}

// SinkFinding represents a sink with its reverse call chains and indicators
type SinkFinding struct {
	Sink       SinkResult                    `json:"sink"`
	CallChains []analysis.ReverseCallChain   `json:"call_chains"`
	Indicators *analysis.ChainIndicators     `json:"indicators,omitempty"`
	BestChain  *analysis.ReverseCallChain    `json:"best_chain,omitempty"` // Highest-scoring chain
}

type FunctionCode struct {
	DefinitionWithLineNumbers string `json:"def"`
	Snippet                  string `json:"snippet"`
}

type SourceCode struct {
	FreeFunction          FunctionCode   `json:"free_func"`
	UseFunction           FunctionCode   `json:"use_func"`
	IntermediateFunctions []FunctionCode `json:"inter_funcs"`
}

type Finding struct {
	CodeQLResult   CodeQLResult              `json:"codeql_result"`
	SourceCode     SourceCode                `json:"source_code"`
	CallValidation *analysis.CallValidation  `json:"call_validation,omitempty"`
}

