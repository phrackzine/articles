package codeql

import (
	"bufio"
	"fmt"
	"log/slog"
	"math/rand"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/noperator/slice/pkg/analysis"
	"github.com/noperator/slice/pkg/logging"
	"github.com/noperator/slice/pkg/parser"
)

// symbolCacheEntry stores a cached symbol lookup result
type symbolCacheEntry struct {
	symbol *parser.Symbol
	err    error
}

// funcCodeCacheEntry stores a cached function code lookup result
type funcCodeCacheEntry struct {
	code FunctionCode
	err  error
}

// QueryEnricher handles enriching CodeQL results with source code context
type QueryEnricher struct {
	sourceDir string
	logger    *slog.Logger
	// Cache for all symbol lookups (both success and failure) to avoid repeated disk reads
	symbolCache sync.Map // key: "file:line:name" -> *symbolCacheEntry
	// Cache for function code lookups by name to avoid repeated searches
	funcCodeCache sync.Map // key: funcName -> *funcCodeCacheEntry
}

// NewQueryEnricher creates a new query enricher
func NewQueryEnricher(sourceDir string) *QueryEnricher {
	return &QueryEnricher{
		sourceDir: sourceDir,
		logger:    logging.NewLoggerFromEnv(),
	}
}

// cacheKey generates a cache key for symbol lookup
func (e *QueryEnricher) cacheKey(file string, line int, name string) string {
	return fmt.Sprintf("%s:%d:%s", file, line, name)
}

// getCachedSymbol looks up a symbol, using cache if available
func (e *QueryEnricher) getCachedSymbol(file string, line int, name string) (*parser.Symbol, error) {
	key := e.cacheKey(file, line, name)

	// Check cache first
	if cached, found := e.symbolCache.Load(key); found {
		entry := cached.(*symbolCacheEntry)
		return entry.symbol, entry.err
	}

	// Not in cache, do the lookup
	symbol, err := parser.FindSymbolByLocation(e.sourceDir, file, line, name)

	// Cache the result (both success and failure)
	e.symbolCache.Store(key, &symbolCacheEntry{
		symbol: symbol,
		err:    err,
	})

	return symbol, err
}

// EnrichResults enriches CodeQL results with source code and validation using parallel processing
func (e *QueryEnricher) EnrichResults(results []CodeQLResult, callGraph *analysis.CallGraph, validateCalls bool, callDepth int, concurrency int) ([]Finding, error) {
	// Use atomic counters for thread-safe statistics
	var validationStats struct {
		total   atomic.Int32
		valid   atomic.Int32
		invalid atomic.Int32
	}

	// Determine number of workers
	numWorkers := concurrency
	if numWorkers <= 0 {
		// Auto-detect based on CPU cores if not specified
		numWorkers = runtime.NumCPU()
		if numWorkers > 16 {
			numWorkers = 16
		}
	}
	e.logger.Info("processing results in parallel",
		"component", "codeql",
		"workers", numWorkers,
		"total_results", len(results))

	// Create channels for work distribution
	type workItem struct {
		index  int
		result CodeQLResult
	}
	
	type workResult struct {
		index   int
		finding *Finding // nil if invalid/filtered
		err     error
	}

	workChan := make(chan workItem, len(results))
	resultChan := make(chan workResult, len(results))

	// Create wait group for workers
	var wg sync.WaitGroup

	// Start worker goroutines
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			
			for item := range workChan {
				// Log when starting enrichment for this result
				e.logger.Info("starting enrichment",
					"component", "codeql",
					"worker", workerID,
					"result_index", item.index+1,
					"total", len(results),
					"free_func", item.result.FreeFunctionName,
					"use_func", item.result.UseFunctionName)

				// Process each result
				finding, err := e.enrichWithSourceCode(item.result)
				if err != nil {
					e.logger.Warn("failed to enrich result with source code",
						"component", "codeql",
						"worker", workerID,
						"result_index", item.index+1,
						"error", err)
					// Still include the result but with empty source code
					finding = Finding{
						CodeQLResult: item.result,
						SourceCode:   SourceCode{},
					}
				}

				// Perform call chain validation if enabled
				includeResult := true
				if validateCalls && callGraph != nil {
					// Use callDepth for search, but default to 10 if -1 (no limit for filtering)
					searchDepth := callDepth
					if searchDepth < 0 {
						searchDepth = 10
					}
					validation := callGraph.ValidateCallRelationship(item.result.FreeFunctionName, item.result.UseFunctionName, searchDepth)
					finding.CallValidation = validation
					
					validationStats.total.Add(1)
					if validation.IsValid {
						// Apply call depth filtering if specified (when callDepth >= 0)
						if callDepth >= 0 && validation.MaxDepth > callDepth {
							validationStats.invalid.Add(1)
							includeResult = false
						} else {
							validationStats.valid.Add(1)

							// Populate intermediate functions from call chain IDs (using full function IDs for accurate lookup)
							intermediateFuncIDs := e.extractIntermediateFunctionIDs(validation.CallChainIDs)
							for _, funcID := range intermediateFuncIDs {
								// Try to find the function definition by ID
								funcCode, err := e.findFunctionByID(funcID)
								if err != nil {
									e.logger.Debug("could not find intermediate function",
										"component", "codeql",
										"worker", workerID,
										"function_id", funcID,
										"error", err)
									// Add empty function code as placeholder
									finding.SourceCode.IntermediateFunctions = append(finding.SourceCode.IntermediateFunctions,
										FunctionCode{
											DefinitionWithLineNumbers: fmt.Sprintf("// Function %s not found", funcID),
											Snippet:                   "",
										})
								} else {
									finding.SourceCode.IntermediateFunctions = append(finding.SourceCode.IntermediateFunctions, funcCode)
								}
							}
						}
					} else {
						validationStats.invalid.Add(1)
						includeResult = false
					}
				}
				
				// Send result
				if includeResult {
					resultChan <- workResult{
						index:   item.index,
						finding: &finding,
						err:     nil,
					}
				} else {
					resultChan <- workResult{
						index:   item.index,
						finding: nil,
						err:     nil,
					}
				}
				
				// Log progress periodically at INFO level every 100 results
				if (item.index+1)%100 == 0 {
					e.logger.Info("enrichment progress",
						"component", "codeql",
						"processed", item.index+1,
						"total", len(results),
						"percent_complete", fmt.Sprintf("%.1f%%", 100.0*float64(item.index+1)/float64(len(results))))
				}
			}
		}(w)
	}

	// Build work items and shuffle to spread out identical function pairs
	// This reduces thundering herd on cache misses when multiple workers
	// hit the same uncached pair simultaneously
	workItems := make([]workItem, len(results))
	for i, result := range results {
		workItems[i] = workItem{index: i, result: result}
	}
	rand.Shuffle(len(workItems), func(i, j int) {
		workItems[i], workItems[j] = workItems[j], workItems[i]
	})

	// Send shuffled work items to workers
	for _, item := range workItems {
		workChan <- item
	}
	close(workChan)

	// Wait for all workers to complete
	go func() {
		wg.Wait()
		close(resultChan)
	}()

	// Collect results (maintaining order)
	findingsMap := make(map[int]*Finding)
	for result := range resultChan {
		if result.finding != nil {
			findingsMap[result.index] = result.finding
		}
	}

	// Build ordered results slice
	var enrichedResults []Finding
	for i := 0; i < len(results); i++ {
		if finding, exists := findingsMap[i]; exists {
			enrichedResults = append(enrichedResults, *finding)
		}
	}

	// Print validation statistics
	if validateCalls {
		total := validationStats.total.Load()
		valid := validationStats.valid.Load()
		invalid := validationStats.invalid.Load()
		
		validationRate := 0.0
		if total > 0 {
			validationRate = float64(valid) / float64(total) * 100
		}
		e.logger.Info("call chain validation statistics",
			"component", "codeql",
			"total_findings", total,
			"valid_relationships", valid,
			"invalid_relationships", invalid,
			"validation_rate_percent", validationRate)
	}

	return enrichedResults, nil
}

// enrichWithSourceCode enriches a CodeQL result with source code context
func (e *QueryEnricher) enrichWithSourceCode(result CodeQLResult) (Finding, error) {
	// Find functions using cached lookup (name, file, line)
	freeFunc, err := e.getCachedSymbol(result.FreeFunctionFile, result.FreeFunctionDefLine, result.FreeFunctionName)
	if err != nil {
		return Finding{}, fmt.Errorf("failed to find free function %s at %s:%d: %w",
			result.FreeFunctionName, result.FreeFunctionFile, result.FreeFunctionDefLine, err)
	}

	useFunc, err := e.getCachedSymbol(result.UseFunctionFile, result.UseFunctionDefLine, result.UseFunctionName)
	if err != nil {
		return Finding{}, fmt.Errorf("failed to find use function %s at %s:%d: %w",
			result.UseFunctionName, result.UseFunctionFile, result.UseFunctionDefLine, err)
	}
	
	// Get specific line snippets
	freeSnippet, err := e.getLineFromFile(filepath.Join(e.sourceDir, result.FreeFunctionFile), result.FreeLine)
	if err != nil {
		freeSnippet = fmt.Sprintf("// Could not retrieve line %d: %v", result.FreeLine, err)
	}
	
	useSnippet, err := e.getLineFromFile(filepath.Join(e.sourceDir, result.UseFunctionFile), result.UseLine)
	if err != nil {
		useSnippet = fmt.Sprintf("// Could not retrieve line %d: %v", result.UseLine, err)
	}
	
	// Create the finding (without call chain - that's in call_validation now)
	finding := Finding{
		CodeQLResult: result,
		SourceCode: SourceCode{
			FreeFunction: FunctionCode{
				DefinitionWithLineNumbers: freeFunc.DefinitionWithLineNumbers,
				Snippet:                  freeSnippet,
			},
			UseFunction: FunctionCode{
				DefinitionWithLineNumbers: useFunc.DefinitionWithLineNumbers,
				Snippet:                  useSnippet,
			},
			IntermediateFunctions: []FunctionCode{}, // Will be populated after validation
		},
	}
	
	return finding, nil
}

// getLineFromFile retrieves a specific line from a file
func (e *QueryEnricher) getLineFromFile(filePath string, lineNum int) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()
	
	scanner := bufio.NewScanner(file)
	currentLine := 1
	
	for scanner.Scan() {
		if currentLine == lineNum {
			return strings.TrimSpace(scanner.Text()), nil
		}
		currentLine++
	}
	
	if err := scanner.Err(); err != nil {
		return "", err
	}
	
	return "", fmt.Errorf("line %d not found in file %s", lineNum, filePath)
}

// extractIntermediateFunctionIDs finds function IDs that appear in call chain IDs between source and target functions
// It uses CallChainIDs which contain full function IDs (lang:file:line:name) for accurate lookup
func (e *QueryEnricher) extractIntermediateFunctionIDs(callChainIDs [][]string) []string {
	if len(callChainIDs) == 0 {
		return nil
	}

	intermediateMap := make(map[string]bool)

	for _, chain := range callChainIDs {
		// Skip first (source) and last (target) functions in each chain
		for i := 1; i < len(chain)-1; i++ {
			intermediateMap[chain[i]] = true
		}
	}

	// Convert map to slice
	var intermediates []string
	for funcID := range intermediateMap {
		intermediates = append(intermediates, funcID)
	}

	return intermediates
}

// findFunctionByID searches for a function definition by its full ID (lang:file:line:name) with caching
func (e *QueryEnricher) findFunctionByID(funcID string) (FunctionCode, error) {
	// Check cache first
	if cached, found := e.funcCodeCache.Load(funcID); found {
		entry := cached.(*funcCodeCacheEntry)
		return entry.code, entry.err
	}

	// Use FindFunctionByID for exact lookup by ID
	symbol, err := parser.FindFunctionByID(e.sourceDir, funcID)
	if err != nil {
		// Cache the failure
		e.funcCodeCache.Store(funcID, &funcCodeCacheEntry{
			code: FunctionCode{},
			err:  err,
		})
		return FunctionCode{}, err
	}

	code := FunctionCode{
		DefinitionWithLineNumbers: symbol.DefinitionWithLineNumbers,
		Snippet:                   "", // We don't have a specific line for intermediate functions
	}
	// Cache the success
	e.funcCodeCache.Store(funcID, &funcCodeCacheEntry{
		code: code,
		err:  nil,
	})
	return code, nil
}