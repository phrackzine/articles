package analysis

import (
	"regexp"
	"strings"

	"github.com/noperator/slice/pkg/parser"
)

// IndicatorMatch represents a match of a network indicator pattern
type IndicatorMatch struct {
	Pattern    string `json:"pattern"`
	Location   string `json:"location"` // "name", "params", "body", "file_path"
	Confidence string `json:"confidence"` // "HIGH", "MEDIUM", "LOW"
}

// FunctionIndicators contains all indicator matches for a single function
type FunctionIndicators struct {
	FunctionID   string            `json:"function_id"`
	FunctionName string            `json:"function_name"`
	File         string            `json:"file"`
	Matches      []IndicatorMatch  `json:"matches"`
	Score        int               `json:"score"`
	Confidence   string            `json:"confidence"` // Overall: "HIGH", "MEDIUM", "LOW"
}

// ChainIndicators contains indicators for an entire call chain
type ChainIndicators struct {
	Functions        []FunctionIndicators `json:"functions"`
	TotalScore       int                  `json:"total_score"`
	OverallConfidence string              `json:"overall_confidence"`
	Reasoning        string               `json:"reasoning"`
}

// High confidence patterns - strong indicators of network/deserialization input
var highConfidencePatterns = []struct {
	pattern string
	score   int
}{
	{"decode", 10},
	{"parse", 8},
	{"deserialize", 10},
	{"unmarshal", 10},
	{"FormData", 8},
	{"body", 6},
	{"request", 6},
	{"req", 4},
	{"POST", 6},
	{"multipart", 8},
	{"revive", 8},
	{"unpack", 8},
	{"inflate", 6},
	{"fromJSON", 8},
	{"receive", 6},
}

// Medium confidence patterns - may indicate network input
var mediumConfidencePatterns = []struct {
	pattern string
	score   int
}{
	{"data", 3},
	{"input", 3},
	{"payload", 4},
	{"stream", 3},
	{"Buffer", 3},
	{"blob", 3},
	{"fetch", 4},
	{"load", 2},
	{"read", 2},
	{"response", 3},
	{"message", 2},
}

// File path patterns - indicate server-side or API code
var filePathPatterns = []struct {
	pattern string
	score   int
}{
	{"server", 4},
	{"api", 4},
	{"route", 3},
	{"handler", 3},
	{"controller", 3},
	{"endpoint", 3},
	{"middleware", 2},
}

// SearchIndicators searches for network indicators in a function
func SearchIndicators(symbol *parser.Symbol) FunctionIndicators {
	result := FunctionIndicators{
		FunctionID:   symbol.ID,
		FunctionName: symbol.Name,
		File:         symbol.Filename,
		Matches:      []IndicatorMatch{},
		Score:        0,
	}

	// Search function name
	nameLower := strings.ToLower(symbol.Name)
	for _, p := range highConfidencePatterns {
		if strings.Contains(nameLower, strings.ToLower(p.pattern)) {
			result.Matches = append(result.Matches, IndicatorMatch{
				Pattern:    p.pattern,
				Location:   "name",
				Confidence: "HIGH",
			})
			result.Score += p.score
		}
	}
	for _, p := range mediumConfidencePatterns {
		if strings.Contains(nameLower, strings.ToLower(p.pattern)) {
			result.Matches = append(result.Matches, IndicatorMatch{
				Pattern:    p.pattern,
				Location:   "name",
				Confidence: "MEDIUM",
			})
			result.Score += p.score
		}
	}

	// Search parameters
	for _, param := range symbol.Params {
		paramLower := strings.ToLower(param.Name)
		for _, p := range highConfidencePatterns {
			if strings.Contains(paramLower, strings.ToLower(p.pattern)) {
				result.Matches = append(result.Matches, IndicatorMatch{
					Pattern:    p.pattern,
					Location:   "params",
					Confidence: "HIGH",
				})
				result.Score += p.score
			}
		}
		for _, p := range mediumConfidencePatterns {
			if strings.Contains(paramLower, strings.ToLower(p.pattern)) {
				result.Matches = append(result.Matches, IndicatorMatch{
					Pattern:    p.pattern,
					Location:   "params",
					Confidence: "MEDIUM",
				})
				result.Score += p.score
			}
		}
	}

	// Search function body (limited - just signature and first few lines for perf)
	bodyLower := strings.ToLower(symbol.Signature)
	if len(symbol.Definition) > 0 {
		// Take first 500 chars of definition for body search
		bodyContent := symbol.Definition
		if len(bodyContent) > 500 {
			bodyContent = bodyContent[:500]
		}
		bodyLower += " " + strings.ToLower(bodyContent)
	}

	for _, p := range highConfidencePatterns {
		if strings.Contains(bodyLower, strings.ToLower(p.pattern)) {
			// Check if already matched in name/params
			alreadyMatched := false
			for _, m := range result.Matches {
				if m.Pattern == p.pattern && (m.Location == "name" || m.Location == "params") {
					alreadyMatched = true
					break
				}
			}
			if !alreadyMatched {
				result.Matches = append(result.Matches, IndicatorMatch{
					Pattern:    p.pattern,
					Location:   "body",
					Confidence: "HIGH",
				})
				result.Score += p.score / 2 // Lower score for body matches
			}
		}
	}

	// Search file path
	pathLower := strings.ToLower(symbol.Filename)
	for _, p := range filePathPatterns {
		if strings.Contains(pathLower, strings.ToLower(p.pattern)) {
			result.Matches = append(result.Matches, IndicatorMatch{
				Pattern:    p.pattern,
				Location:   "file_path",
				Confidence: "MEDIUM",
			})
			result.Score += p.score
		}
	}

	// Determine overall confidence
	if result.Score >= 15 {
		result.Confidence = "HIGH"
	} else if result.Score >= 8 {
		result.Confidence = "MEDIUM"
	} else {
		result.Confidence = "LOW"
	}

	return result
}

// SearchChainIndicators searches for network indicators in all functions of a call chain
func SearchChainIndicators(cg *CallGraph, chain ReverseCallChain) ChainIndicators {
	result := ChainIndicators{
		Functions:  make([]FunctionIndicators, 0, len(chain.ChainIDs)),
		TotalScore: 0,
	}

	var highConfidenceReasons []string

	for _, funcID := range chain.ChainIDs {
		symbol := cg.GetSymbol(funcID)
		if symbol == nil {
			continue
		}

		funcIndicators := SearchIndicators(symbol)
		result.Functions = append(result.Functions, funcIndicators)
		result.TotalScore += funcIndicators.Score

		// Track high confidence reasons
		if funcIndicators.Confidence == "HIGH" {
			for _, m := range funcIndicators.Matches {
				if m.Confidence == "HIGH" && (m.Location == "name" || m.Location == "params") {
					highConfidenceReasons = append(highConfidenceReasons,
						funcIndicators.FunctionName+" has '"+m.Pattern+"' in "+m.Location)
				}
			}
		}
	}

	// Determine overall confidence
	if result.TotalScore >= 20 {
		result.OverallConfidence = "HIGH"
	} else if result.TotalScore >= 10 {
		result.OverallConfidence = "MEDIUM"
	} else {
		result.OverallConfidence = "LOW"
	}

	// Build reasoning
	if len(highConfidenceReasons) > 0 {
		result.Reasoning = strings.Join(highConfidenceReasons, "; ")
	} else if result.TotalScore > 0 {
		result.Reasoning = "Some network-related patterns found in call chain"
	} else {
		result.Reasoning = "No strong network indicators found"
	}

	return result
}

// ExtractParams extracts parameter names from a function signature
// Simple regex-based extraction for common patterns
func ExtractParams(signature string) []string {
	// Match patterns like: function foo(a, b, c) or (a, b, c) =>
	re := regexp.MustCompile(`\(([^)]*)\)`)
	match := re.FindStringSubmatch(signature)
	if len(match) < 2 {
		return nil
	}

	paramsStr := match[1]
	if paramsStr == "" {
		return nil
	}

	// Split by comma and clean up
	parts := strings.Split(paramsStr, ",")
	var params []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		// Remove type annotations (TypeScript)
		if colonIdx := strings.Index(p, ":"); colonIdx > 0 {
			p = strings.TrimSpace(p[:colonIdx])
		}
		// Remove default values
		if eqIdx := strings.Index(p, "="); eqIdx > 0 {
			p = strings.TrimSpace(p[:eqIdx])
		}
		if p != "" {
			params = append(params, p)
		}
	}

	return params
}
