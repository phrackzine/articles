package analysis

import (
	"fmt"
	"sort"
	"strings"
	"sync"

	"github.com/dominikbraun/graph"
	"github.com/noperator/slice/pkg/parser"
)

// CallGraph represents function call relationships using a graph library
type CallGraph struct {
	g                 graph.Graph[string, string] // Directed graph of function IDs
	symbols           map[string]*parser.Symbol   // Map ID -> Symbol for looking up symbol data
	functions         map[string][]string         // Map function name -> list of function IDs
	byLang            map[string][]string         // Map language -> list of function IDs
	byFile            map[string][]string         // Map file path -> list of function IDs
	pathCache         sync.Map                    // Cache for path lookups (thread-safe)
	reachabilityCache sync.Map                    // Cache for AnalyzeReachability results: "src:target:depth" -> *ReachabilityAnalysis
	importResolver    *parser.ImportResolver      // Optional import resolver for cross-file analysis
}

// FunctionLocation represents a specific function definition with its location
type FunctionLocation struct {
	ID       string `json:"id"`       // Full ID: lang:file:line:name
	Name     string `json:"name"`     // Function name only
	File     string `json:"file"`     // File path
	Line     int    `json:"line"`     // Line number
	Language string `json:"language"` // Language (js, ts, etc.)
}

// CommonCallerPathIDs contains one common caller witness and the two branch paths.
type CommonCallerPathIDs struct {
	CallerID  string
	LeftPath  []string
	RightPath []string
}

// ReachabilityAnalysis contains the results of analyzing reachability between two functions
// JSON tags maintain backward compatibility with existing code expecting these field names
type ReachabilityAnalysis struct {
	IsValid       bool       `json:"valid"`
	Reason        string     `json:"reason"`
	CallChains    [][]string `json:"chains,omitempty"`
	CommonCallers []string   `json:"common_callers,omitempty"`
	Details       string     `json:"details,omitempty"`
	MinDepth      int        `json:"min_depth,omitempty"`
	MaxDepth      int        `json:"max_depth,omitempty"`

	// New fields for disambiguation - track which specific function definitions were validated
	CallChainIDs    [][]string         `json:"chain_ids,omitempty"`        // Full function IDs for each chain
	SourceFunctions []FunctionLocation `json:"source_functions,omitempty"` // All source function definitions that participate
	TargetFunctions []FunctionLocation `json:"target_functions,omitempty"` // All target function definitions that participate
	ValidatedPairs  [][2]string        `json:"validated_pairs,omitempty"`  // Pairs of [sourceID, targetID] that have valid paths
}

// BuildCallGraph creates a call graph from parsed symbols (functions, methods, etc.)
func BuildCallGraph(symbols []parser.Symbol) *CallGraph {
	return BuildCallGraphWithImports(symbols, nil)
}

// BuildCallGraphWithImports creates a call graph with optional import resolution
// When importResolver is provided, it will follow imports across files to find
// the actual function definitions for better cross-file call chain analysis
func BuildCallGraphWithImports(symbols []parser.Symbol, importResolver *parser.ImportResolver) *CallGraph {
	// Create directed graph with string hash
	g := graph.New(graph.StringHash, graph.Directed())

	cg := &CallGraph{
		g:              g,
		symbols:        make(map[string]*parser.Symbol),
		functions:      make(map[string][]string),
		byLang:         make(map[string][]string),
		byFile:         make(map[string][]string),
		importResolver: importResolver,
	}

	// Add all symbols as vertices and index by language and file
	for i := range symbols {
		symbol := &symbols[i]
		_ = g.AddVertex(symbol.ID)
		cg.symbols[symbol.ID] = symbol
		cg.functions[symbol.Name] = append(cg.functions[symbol.Name], symbol.ID)
		cg.byLang[symbol.Lang] = append(cg.byLang[symbol.Lang], symbol.ID)
		cg.byFile[symbol.Filename] = append(cg.byFile[symbol.Filename], symbol.ID)
	}

	// Add edges for function calls with language-scoped resolution
	for _, caller := range symbols {
		for _, callee := range caller.Callees {
			calleeIDs := cg.resolveCallee(callee.Name, caller.Filename, caller.Lang)

			// Add edges to all matching callees
			for _, calleeID := range calleeIDs {
				_ = g.AddEdge(caller.ID, calleeID)
			}
		}
	}

	return cg
}

// resolveCallee resolves a callee name to function IDs, considering imports
func (cg *CallGraph) resolveCallee(calleeName, callerFile, callerLang string) []string {
	// First, try to resolve via import if we have an import resolver
	if cg.importResolver != nil && (callerLang == parser.LangTS || callerLang == parser.LangJS) {
		resolvedFile, originalName, found := cg.importResolver.ResolveFunction(calleeName, callerFile)
		if found {
			// Find the function in the resolved file with the original name
			calleeIDs := cg.findInFile(originalName, resolvedFile, callerLang)
			if len(calleeIDs) > 0 {
				return calleeIDs
			}
		}
	}

	// Fall back to language-scoped name lookup
	return cg.findInLanguage(calleeName, callerLang)
}

// findInFile finds all function IDs with the given name in a specific file
func (cg *CallGraph) findInFile(name, filePath, lang string) []string {
	var result []string

	// Get all IDs for functions in this file
	candidateIDs := cg.byFile[filePath]

	// Filter to those matching name and language
	for _, id := range candidateIDs {
		if symbol := cg.symbols[id]; symbol != nil && symbol.Name == name && symbol.Lang == lang {
			result = append(result, id)
		}
	}

	return result
}

// findInLanguage finds all function IDs with the given name in the specified language
func (cg *CallGraph) findInLanguage(name, lang string) []string {
	var result []string

	// Get all IDs for functions with this name
	candidateIDs := cg.functions[name]

	// Filter to only those in the specified language by checking the symbol's Lang field
	for _, id := range candidateIDs {
		if symbol := cg.symbols[id]; symbol != nil && symbol.Lang == lang {
			result = append(result, id)
		}
	}

	return result
}

// AnalyzeReachability analyzes the reachability relationship between two functions
// This is the main entry point for interprocedural analysis
func (cg *CallGraph) AnalyzeReachability(sourceFuncName, targetFuncName string, maxDepth int) *ReachabilityAnalysis {
	// Check cache first
	cacheKey := fmt.Sprintf("%s:%s:%d", sourceFuncName, targetFuncName, maxDepth)
	if cached, found := cg.reachabilityCache.Load(cacheKey); found {
		return cached.(*ReachabilityAnalysis)
	}

	// Get all function IDs for the given names
	sourceIDs := cg.functions[sourceFuncName]
	targetIDs := cg.functions[targetFuncName]

	// Handle missing functions
	if len(sourceIDs) == 0 {
		return &ReachabilityAnalysis{
			IsValid: false,
			Reason:  "Free function not found in call graph",
			Details: fmt.Sprintf("Function '%s' was not found in the parsed codebase", sourceFuncName),
		}
	}

	if len(targetIDs) == 0 {
		return &ReachabilityAnalysis{
			IsValid: false,
			Reason:  "Use function not found in call graph",
			Details: fmt.Sprintf("Function '%s' was not found in the parsed codebase", targetFuncName),
		}
	}

	// Analyze all combinations of source and target IDs
	analyzer := &reachabilityAnalyzer{
		graph:          cg.g,
		symbols:        cg.symbols,
		maxDepth:       maxDepth,
		sourceFuncName: sourceFuncName,
		targetFuncName: targetFuncName,
	}

	// Check all combinations (handles multiple functions with same name)
	// Don't early exit - we want to find ALL valid pairs for disambiguation
	for _, sourceID := range sourceIDs {
		for _, targetID := range targetIDs {
			analyzer.analyzePair(sourceID, targetID)
		}
	}

	result := analyzer.buildResult(cg.symbols, sourceIDs, targetIDs)

	// Cache the result for future lookups
	cg.reachabilityCache.Store(cacheKey, result)

	return result
}

// reachabilityAnalyzer accumulates analysis results
type reachabilityAnalyzer struct {
	graph          graph.Graph[string, string]
	symbols        map[string]*parser.Symbol // Reference to symbol map for lookups
	maxDepth       int
	sourceFuncName string
	targetFuncName string

	// Results
	foundRelationship bool
	relationshipType  RelationshipType
	allPaths          [][]string  // Paths with function names (for backward compatibility)
	allPathIDs        [][]string  // Paths with full function IDs (for disambiguation)
	validatedPairs    [][2]string // Pairs of [sourceID, targetID] that have valid paths
	commonCallers     map[string]bool
}

// RelationshipType represents the type of relationship between functions
type RelationshipType int

const (
	NoRelationship RelationshipType = iota
	SameFunction
	ForwardReachable  // source -> target
	BackwardReachable // target -> source
	CommonAncestor    // both reachable from common caller
)

func (ra *reachabilityAnalyzer) analyzePair(sourceID, targetID string) {
	// Case 1: Same function
	if sourceID == targetID {
		ra.foundRelationship = true
		ra.relationshipType = SameFunction
		ra.allPaths = append(ra.allPaths, []string{extractFunctionName(sourceID)})
		ra.allPathIDs = append(ra.allPathIDs, []string{sourceID})
		ra.validatedPairs = append(ra.validatedPairs, [2]string{sourceID, targetID})
		return
	}

	// Case 2: Forward reachability (source -> target)
	if names, ids := ra.findPathsWithIDs(sourceID, targetID); len(names) > 0 {
		ra.foundRelationship = true
		ra.relationshipType = ForwardReachable
		ra.addPathsWithIDs(names, ids)
		ra.validatedPairs = append(ra.validatedPairs, [2]string{sourceID, targetID})
		return
	}

	// Case 3: Backward reachability (target -> source)
	if names, ids := ra.findPathsWithIDs(targetID, sourceID); len(names) > 0 {
		ra.foundRelationship = true
		ra.relationshipType = BackwardReachable
		ra.addPathsWithIDs(names, ids)
		ra.validatedPairs = append(ra.validatedPairs, [2]string{sourceID, targetID})
		return
	}

	// Case 4: Common ancestor (both reachable from same caller)
	if callers := ra.findCommonAncestors(sourceID, targetID); len(callers) > 0 {
		ra.foundRelationship = true
		ra.relationshipType = CommonAncestor

		// Add sample paths from first common caller
		if len(callers) > 0 {
			firstCaller := callers[0]
			names1, ids1 := ra.findPathsWithIDs(firstCaller, sourceID)
			names2, ids2 := ra.findPathsWithIDs(firstCaller, targetID)
			ra.addPathsWithIDs(names1, ids1)
			ra.addPathsWithIDs(names2, ids2)
		}
		ra.validatedPairs = append(ra.validatedPairs, [2]string{sourceID, targetID})

		// Store common callers
		if ra.commonCallers == nil {
			ra.commonCallers = make(map[string]bool)
		}
		for _, caller := range callers {
			ra.commonCallers[extractFunctionName(caller)] = true
		}
	}
}

func (ra *reachabilityAnalyzer) findPaths(from, to string) [][]string {
	names, _ := ra.findPathsWithIDs(from, to)
	return names
}

// findPathsWithIDs returns both function names and full IDs for the paths found
func (ra *reachabilityAnalyzer) findPathsWithIDs(from, to string) ([][]string, [][]string) {
	// Use a simpler depth limit for path finding to avoid explosion
	searchDepth := ra.maxDepth
	if searchDepth > 10 {
		searchDepth = 10
	}

	// First check if there's any path at all using shortest path (faster)
	shortestPath, err := graph.ShortestPath(ra.graph, from, to)
	if err != nil || shortestPath == nil {
		return nil, nil
	}

	// If shortest path exceeds depth, no valid paths exist
	if len(shortestPath)-1 > searchDepth {
		return nil, nil
	}

	// For performance, just return the shortest path converted to names
	// This is much faster than AllPathsBetween for large graphs
	var names []string
	var ids []string
	for _, id := range shortestPath {
		names = append(names, extractFunctionName(id))
		ids = append(ids, id)
	}

	return [][]string{names}, [][]string{ids}
}

// addPathsWithIDs adds paths (both names and IDs) to the accumulated results
func (ra *reachabilityAnalyzer) addPathsWithIDs(namePaths [][]string, idPaths [][]string) {
	for i, path := range namePaths {
		if len(ra.allPaths) >= 10 { // Global limit on total paths
			break
		}
		ra.allPaths = append(ra.allPaths, path)
		if i < len(idPaths) {
			ra.allPathIDs = append(ra.allPathIDs, idPaths[i])
		}
	}
}

// HasPathCached checks if there's a path using BFS with caching
func (cg *CallGraph) HasPathCached(from, to string, maxDepth int) bool {
	if from == to {
		return true
	}

	// Check cache first
	cacheKey := fmt.Sprintf("%s\x00%d", from, maxDepth)
	if cached, exists := cg.pathCache.Load(cacheKey); exists {
		reachableSet := cached.(map[string]bool)
		_, found := reachableSet[to]
		return found
	}

	// Compute reachability from 'from' using BFS up to maxDepth
	reachableSet := make(map[string]bool)
	visited := make(map[string]bool)
	queue := []struct {
		node  string
		depth int
	}{{from, 0}}

	adjMap, err := cg.g.AdjacencyMap()
	if err != nil {
		return false
	}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		if visited[current.node] {
			continue
		}
		visited[current.node] = true
		reachableSet[current.node] = true

		if current.depth >= maxDepth {
			continue
		}

		// Get neighbors
		if neighbors, exists := adjMap[current.node]; exists {
			for neighbor := range neighbors {
				if !visited[neighbor] {
					queue = append(queue, struct {
						node  string
						depth int
					}{neighbor, current.depth + 1})
				}
			}
		}
	}

	// Store in cache
	cg.pathCache.Store(cacheKey, reachableSet)

	return reachableSet[to]
}

// FunctionIDs returns all function IDs known to the call graph.
func (cg *CallGraph) FunctionIDs() []string {
	ids := make([]string, 0, len(cg.symbols))
	for id := range cg.symbols {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	return ids
}

// FindPathIDs returns one shortest directed path between two function IDs.
func (cg *CallGraph) FindPathIDs(from, to string, maxDepth int) []string {
	if from == to {
		return []string{from}
	}
	if maxDepth < 0 {
		maxDepth = 10
	}

	adjMap, err := cg.g.AdjacencyMap()
	if err != nil {
		return nil
	}

	type pathState struct {
		node string
		path []string
	}
	queue := []pathState{{node: from, path: []string{from}}}
	visited := map[string]bool{from: true}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		depth := len(current.path) - 1
		if depth >= maxDepth {
			continue
		}

		neighbors := make([]string, 0, len(adjMap[current.node]))
		for neighbor := range adjMap[current.node] {
			neighbors = append(neighbors, neighbor)
		}
		sort.Strings(neighbors)

		for _, neighbor := range neighbors {
			if visited[neighbor] {
				continue
			}
			nextPath := append(append([]string{}, current.path...), neighbor)
			if neighbor == to {
				return nextPath
			}
			visited[neighbor] = true
			queue = append(queue, pathState{node: neighbor, path: nextPath})
		}
	}

	return nil
}

// FindCommonCallerPathIDs returns one common-caller witness for two endpoint functions.
func (cg *CallGraph) FindCommonCallerPathIDs(leftID, rightID string, maxDepth int) *CommonCallerPathIDs {
	if leftID == rightID {
		return nil
	}
	if maxDepth < 0 {
		maxDepth = 10
	}

	var best *CommonCallerPathIDs
	bestTotal := 0
	for _, callerID := range cg.FunctionIDs() {
		if callerID == leftID || callerID == rightID {
			continue
		}
		leftPath := cg.FindPathIDs(callerID, leftID, maxDepth)
		if leftPath == nil {
			continue
		}
		rightPath := cg.FindPathIDs(callerID, rightID, maxDepth)
		if rightPath == nil {
			continue
		}

		total := len(leftPath) + len(rightPath)
		if best == nil || total < bestTotal {
			best = &CommonCallerPathIDs{
				CallerID:  callerID,
				LeftPath:  leftPath,
				RightPath: rightPath,
			}
			bestTotal = total
		}
	}

	return best
}

// CheckReachabilityFast is an optimized version for bulk checking
// It only returns true/false, not the full path details
func (cg *CallGraph) CheckReachabilityFast(sourceFuncName, targetFuncName string, maxDepth int) bool {
	// Get all function IDs for the given names
	sourceIDs := cg.functions[sourceFuncName]
	targetIDs := cg.functions[targetFuncName]

	// If either function doesn't exist, no reachability
	if len(sourceIDs) == 0 || len(targetIDs) == 0 {
		return false
	}

	// Check all combinations
	for _, sourceID := range sourceIDs {
		for _, targetID := range targetIDs {
			// Same function
			if sourceID == targetID {
				return true
			}
			// Forward path
			if cg.HasPathCached(sourceID, targetID, maxDepth) {
				return true
			}
			// Reverse path
			if cg.HasPathCached(targetID, sourceID, maxDepth) {
				return true
			}
		}
	}

	return false
}

func (ra *reachabilityAnalyzer) findCommonAncestors(sourceID, targetID string) []string {
	// Disabled for performance - common ancestor search is too expensive
	// The majority of validations work with direct/reverse paths
	// This accounts for the difference: 217 valid vs 241 valid (original)
	return nil
}

func (ra *reachabilityAnalyzer) addPaths(paths [][]string) {
	for _, path := range paths {
		if len(ra.allPaths) >= 10 { // Global limit on total paths
			break
		}
		ra.allPaths = append(ra.allPaths, path)
	}
}

func (ra *reachabilityAnalyzer) buildResult(symbols map[string]*parser.Symbol, sourceIDs, targetIDs []string) *ReachabilityAnalysis {
	if !ra.foundRelationship {
		return &ReachabilityAnalysis{
			IsValid: false,
			Reason:  "No reachability relationship found between functions",
			Details: fmt.Sprintf("No direct calls, reverse calls, or common callers found between %s and %s within depth %d",
				ra.sourceFuncName, ra.targetFuncName, ra.maxDepth),
		}
	}

	// Build relationship description
	var relationship, details string
	switch ra.relationshipType {
	case SameFunction:
		relationship = "Functions are the same"
		details = fmt.Sprintf("Both operations occur in the same function: %s", ra.sourceFuncName)
	case ForwardReachable:
		relationship = "Source function can reach target function"
		if len(ra.allPaths) > 0 && len(ra.allPaths[0]) == 2 {
			details = fmt.Sprintf("Direct call: %s calls %s", ra.sourceFuncName, ra.targetFuncName)
		} else {
			details = fmt.Sprintf("Call chain: %s → %s", ra.sourceFuncName, ra.targetFuncName)
		}
	case BackwardReachable:
		relationship = "Target function can reach source function"
		if len(ra.allPaths) > 0 && len(ra.allPaths[0]) == 2 {
			details = fmt.Sprintf("Reverse call: %s calls %s", ra.targetFuncName, ra.sourceFuncName)
		} else {
			details = fmt.Sprintf("Reverse call chain: %s → %s", ra.targetFuncName, ra.sourceFuncName)
		}
	case CommonAncestor:
		relationship = "Functions have common caller"
		callerCount := len(ra.commonCallers)
		if callerCount == 1 {
			var callerName string
			for name := range ra.commonCallers {
				callerName = name
				break
			}
			details = fmt.Sprintf("Common caller: %s calls both %s and %s",
				callerName, ra.sourceFuncName, ra.targetFuncName)
		} else {
			details = fmt.Sprintf("Found %d common callers that reach both functions", callerCount)
		}
	}

	// Convert common callers map to list
	var callerList []string
	for caller := range ra.commonCallers {
		callerList = append(callerList, caller)
		if len(callerList) >= 10 {
			break
		}
	}

	// Calculate depth metrics
	minDepth, maxDepth := calculatePathDepths(ra.allPaths)

	// Deduplicate paths
	uniquePaths := deduplicatePaths(ra.allPaths)
	uniquePathIDs := deduplicatePaths(ra.allPathIDs)

	// Build FunctionLocation for validated source and target functions
	validatedSourceIDs := make(map[string]bool)
	validatedTargetIDs := make(map[string]bool)
	for _, pair := range ra.validatedPairs {
		validatedSourceIDs[pair[0]] = true
		validatedTargetIDs[pair[1]] = true
	}

	var sourceFunctions []FunctionLocation
	for _, id := range sourceIDs {
		if validatedSourceIDs[id] {
			if loc := idToFunctionLocation(id, symbols); loc != nil {
				sourceFunctions = append(sourceFunctions, *loc)
			}
		}
	}

	var targetFunctions []FunctionLocation
	for _, id := range targetIDs {
		if validatedTargetIDs[id] {
			if loc := idToFunctionLocation(id, symbols); loc != nil {
				targetFunctions = append(targetFunctions, *loc)
			}
		}
	}

	return &ReachabilityAnalysis{
		IsValid:         true,
		Reason:          relationship,
		CallChains:      uniquePaths,
		CommonCallers:   callerList,
		Details:         details,
		MinDepth:        minDepth,
		MaxDepth:        maxDepth,
		CallChainIDs:    uniquePathIDs,
		SourceFunctions: sourceFunctions,
		TargetFunctions: targetFunctions,
		ValidatedPairs:  ra.validatedPairs,
	}
}

// Helper functions

func extractFunctionName(funcID string) string {
	// Function ID format: lang:file:line:function_name
	parts := strings.Split(funcID, ":")
	if len(parts) >= 4 {
		return parts[3]
	}
	return funcID
}

// idToFunctionLocation converts a function ID to a FunctionLocation struct
// ID format: lang:file:line:function_name
func idToFunctionLocation(id string, symbols map[string]*parser.Symbol) *FunctionLocation {
	// First try to look up in symbols map for accurate info
	if symbol, exists := symbols[id]; exists {
		return &FunctionLocation{
			ID:       id,
			Name:     symbol.Name,
			File:     symbol.Filename,
			Line:     symbol.StartLine,
			Language: symbol.Lang,
		}
	}

	// Fall back to parsing the ID
	parts := strings.Split(id, ":")
	if len(parts) < 4 {
		return nil
	}

	line := 0
	if len(parts) >= 3 {
		fmt.Sscanf(parts[2], "%d", &line)
	}

	return &FunctionLocation{
		ID:       id,
		Name:     parts[3],
		File:     parts[1],
		Line:     line,
		Language: parts[0],
	}
}

func calculatePathDepths(paths [][]string) (min, max int) {
	if len(paths) == 0 {
		return 0, 0
	}

	min = len(paths[0]) - 1
	max = min

	for _, path := range paths[1:] {
		depth := len(path) - 1
		if depth < min {
			min = depth
		}
		if depth > max {
			max = depth
		}
	}

	// Handle paths that represent common ancestors (two separate paths)
	// In this case, we want the sum of depths
	if len(paths) >= 2 {
		// Check if we have paths to different endpoints (common ancestor case)
		lastFunc1 := paths[0][len(paths[0])-1]
		for _, path := range paths[1:] {
			lastFunc2 := path[len(path)-1]
			if lastFunc1 != lastFunc2 {
				// This looks like common ancestor paths
				// Sum the depths for total reachability distance
				totalDepth := (len(paths[0]) - 1) + (len(path) - 1)
				if totalDepth > max {
					max = totalDepth
				}
			}
		}
	}

	return min, max
}

func deduplicatePaths(paths [][]string) [][]string {
	seen := make(map[string]bool)
	var result [][]string

	for _, path := range paths {
		key := strings.Join(path, "->")
		if !seen[key] {
			seen[key] = true
			result = append(result, path)
		}
	}

	return result
}

// Legacy compatibility - maintain old function name for backward compatibility
// This wraps the new generic AnalyzeReachability function
func (cg *CallGraph) ValidateCallRelationship(freeFuncName, useFuncName string, maxDepth int) *CallValidation {
	analysis := cg.AnalyzeReachability(freeFuncName, useFuncName, maxDepth)

	// Convert to old struct type (CallValidation is just an alias)
	return (*CallValidation)(analysis)
}

// CallValidation is an alias for backward compatibility
type CallValidation = ReachabilityAnalysis

// Legacy methods for backward compatibility

// HasPath checks if there's a path from 'from' function to 'to' function within maxDepth
func (cg *CallGraph) HasPath(from, to string, maxDepth int) bool {
	if from == to {
		return true
	}

	// Use graph library to check if path exists
	path, err := graph.ShortestPath(cg.g, from, to)
	if err != nil || path == nil {
		return false
	}

	// Check if path length is within maxDepth
	return len(path)-1 <= maxDepth
}

// FindCallChains finds all call chains from 'from' to 'to' within maxDepth
func (cg *CallGraph) FindCallChains(from, to string, maxDepth int) [][]string {
	if from == to {
		return [][]string{{from}}
	}

	// For performance, just use shortest path instead of all paths
	shortestPath, err := graph.ShortestPath(cg.g, from, to)
	if err != nil || shortestPath == nil {
		return nil
	}

	// Check depth
	if len(shortestPath) > maxDepth {
		return nil
	}

	return [][]string{shortestPath}
}

// AreConnected checks if two functions are connected in either direction
func (cg *CallGraph) AreConnected(func1, func2 string, maxDepth int) bool {
	// Check if func1 can reach func2
	if cg.HasPath(func1, func2, maxDepth) {
		return true
	}
	// Check if func2 can reach func1
	if cg.HasPath(func2, func1, maxDepth) {
		return true
	}
	// Check if they have a common caller
	return cg.haveCommonCaller(func1, func2, maxDepth)
}

// haveCommonCaller checks if two functions have a common caller within maxDepth
func (cg *CallGraph) haveCommonCaller(func1, func2 string, maxDepth int) bool {
	// Use a conservative depth for common caller detection
	searchDepth := maxDepth
	if searchDepth > 3 {
		searchDepth = 3
	}

	// Get all vertices in the graph
	adjMap, err := cg.g.AdjacencyMap()
	if err != nil {
		return false
	}

	// Check each vertex to see if it can reach both functions
	for vertex := range adjMap {
		// Skip if this is one of our target functions
		if vertex == func1 || vertex == func2 {
			continue
		}

		// Check reachability to both functions
		canReachFunc1 := cg.HasPath(vertex, func1, searchDepth)
		canReachFunc2 := cg.HasPath(vertex, func2, searchDepth)

		if canReachFunc1 && canReachFunc2 {
			return true
		}
	}

	return false
}

// deduplicateChains removes duplicate call chains from the slice (legacy function)
func deduplicateChains(chains [][]string) [][]string {
	return deduplicatePaths(chains)
}

// ReverseCallChain represents a single call chain leading TO a sink function
type ReverseCallChain struct {
	Chain      []FunctionLocation `json:"chain"`       // Functions in order: [entry_point, ..., sink]
	ChainIDs   []string           `json:"chain_ids"`   // Full function IDs
	ChainNames []string           `json:"chain_names"` // Function names only
	Length     int                `json:"length"`      // Number of hops (len(chain) - 1)
}

// FindReverseCallChains finds all unique call chains that lead TO a target function
// This traverses the call graph in reverse (finding callers) up to maxDepth
// Returns maximal chains only (no chain is a suffix of another)
func (cg *CallGraph) FindReverseCallChains(targetFuncName string, targetFile string, targetLine int, maxDepth int) []ReverseCallChain {
	// Find the specific target function by file and line
	targetID := cg.findFunctionByLocation(targetFuncName, targetFile, targetLine)
	if targetID == "" {
		// Fall back to name-only lookup if exact match not found
		targetIDs := cg.functions[targetFuncName]
		if len(targetIDs) == 0 {
			return nil
		}
		targetID = targetIDs[0]
	}

	// Build reverse adjacency map (who calls each function)
	reverseAdj := cg.buildReverseAdjacency()

	// BFS/DFS to find all paths to target
	var allChains [][]string
	visited := make(map[string]bool)

	var findPaths func(current string, path []string, depth int)
	findPaths = func(current string, path []string, depth int) {
		if depth > maxDepth {
			return
		}

		// Get callers of current function
		callers := reverseAdj[current]
		if len(callers) == 0 {
			// This is an entry point - save the path
			if len(path) > 1 { // Only save if there's at least one hop
				// Reverse path so it goes entry_point -> ... -> sink
				reversed := make([]string, len(path))
				for i, id := range path {
					reversed[len(path)-1-i] = id
				}
				allChains = append(allChains, reversed)
			}
			return
		}

		for _, callerID := range callers {
			if visited[callerID] {
				continue // Avoid cycles
			}
			visited[callerID] = true
			newPath := append([]string{}, path...)
			newPath = append(newPath, callerID)
			findPaths(callerID, newPath, depth+1)
			visited[callerID] = false
		}

		// Also save current path if it's at max depth
		if depth == maxDepth && len(path) > 1 {
			reversed := make([]string, len(path))
			for i, id := range path {
				reversed[len(path)-1-i] = id
			}
			allChains = append(allChains, reversed)
		}
	}

	// Start from target
	visited[targetID] = true
	findPaths(targetID, []string{targetID}, 0)

	// Filter to maximal chains only
	maximalChains := filterMaximalChains(allChains)

	// Convert to ReverseCallChain structs
	var result []ReverseCallChain
	for _, chainIDs := range maximalChains {
		chain := ReverseCallChain{
			ChainIDs:   chainIDs,
			ChainNames: make([]string, len(chainIDs)),
			Chain:      make([]FunctionLocation, len(chainIDs)),
			Length:     len(chainIDs) - 1,
		}
		for i, id := range chainIDs {
			chain.ChainNames[i] = extractFunctionName(id)
			if loc := idToFunctionLocation(id, cg.symbols); loc != nil {
				chain.Chain[i] = *loc
			}
		}
		result = append(result, chain)
	}

	return result
}

// findFunctionByLocation finds a function ID by name, file, and line
func (cg *CallGraph) findFunctionByLocation(name, file string, line int) string {
	candidateIDs := cg.functions[name]
	for _, id := range candidateIDs {
		if symbol := cg.symbols[id]; symbol != nil {
			// Check if file matches (may need to handle relative vs absolute paths)
			if strings.HasSuffix(symbol.Filename, file) && symbol.StartLine == line {
				return id
			}
		}
	}
	return ""
}

// buildReverseAdjacency builds a map of function -> list of callers
func (cg *CallGraph) buildReverseAdjacency() map[string][]string {
	reverseAdj := make(map[string][]string)

	adjMap, err := cg.g.AdjacencyMap()
	if err != nil {
		return reverseAdj
	}

	// For each function and its callees, add reverse edge
	for caller, callees := range adjMap {
		for callee := range callees {
			reverseAdj[callee] = append(reverseAdj[callee], caller)
		}
	}

	return reverseAdj
}

// filterMaximalChains removes chains that are suffixes of other chains
// A chain is maximal if no other chain ends with the same sequence
func filterMaximalChains(chains [][]string) [][]string {
	if len(chains) == 0 {
		return chains
	}

	// Sort by length descending - process longer chains first
	sorted := make([][]string, len(chains))
	copy(sorted, chains)
	for i := 0; i < len(sorted)-1; i++ {
		for j := i + 1; j < len(sorted); j++ {
			if len(sorted[j]) > len(sorted[i]) {
				sorted[i], sorted[j] = sorted[j], sorted[i]
			}
		}
	}

	var maximal [][]string
	for _, chain := range sorted {
		isSubchain := false
		for _, existing := range maximal {
			if isSuffix(chain, existing) {
				isSubchain = true
				break
			}
		}
		if !isSubchain {
			maximal = append(maximal, chain)
		}
	}

	return maximal
}

// isSuffix checks if 'short' is a suffix of 'long'
func isSuffix(short, long []string) bool {
	if len(short) > len(long) {
		return false
	}
	offset := len(long) - len(short)
	for i := 0; i < len(short); i++ {
		if short[i] != long[offset+i] {
			return false
		}
	}
	return true
}

// GetSymbol returns the symbol for a given function ID
func (cg *CallGraph) GetSymbol(funcID string) *parser.Symbol {
	return cg.symbols[funcID]
}

// GetFunctionIDs returns all function IDs for a given function name
func (cg *CallGraph) GetFunctionIDs(funcName string) []string {
	return cg.functions[funcName]
}
