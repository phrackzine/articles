package parser

import (
	"os"
	"path/filepath"
	"strings"
	"sync"

	sitter "github.com/tree-sitter/go-tree-sitter"
	tree_sitter_typescript "github.com/tree-sitter/tree-sitter-typescript/bindings/go"
)

// Import represents a single import from a source file
type Import struct {
	LocalName    string // The name used in this file (e.g., "decodeActionImpl")
	OriginalName string // The name exported from the source (e.g., "decodeAction")
	SourcePath   string // The import path (e.g., "react-server/src/ReactFlightActionServer")
	SourceFile   string // The file this import comes from
	IsTypeImport bool   // True if this is a type-only import (Flow/TypeScript)
}

// ImportMap holds all imports for a file, keyed by local name
type ImportMap map[string]*Import

// ImportResolver resolves imports across files in a project
type ImportResolver struct {
	projectRoot string
	fileImports map[string]ImportMap // file path -> ImportMap
	mu          sync.RWMutex
}

// NewImportResolver creates a new import resolver for a project
func NewImportResolver(projectRoot string) *ImportResolver {
	return &ImportResolver{
		projectRoot: projectRoot,
		fileImports: make(map[string]ImportMap),
	}
}

// GetImports returns the imports for a file, parsing if needed
func (ir *ImportResolver) GetImports(filePath string) (ImportMap, error) {
	ir.mu.RLock()
	if imports, exists := ir.fileImports[filePath]; exists {
		ir.mu.RUnlock()
		return imports, nil
	}
	ir.mu.RUnlock()

	// Parse the file for imports
	imports, err := ir.parseFileImports(filePath)
	if err != nil {
		return nil, err
	}

	ir.mu.Lock()
	ir.fileImports[filePath] = imports
	ir.mu.Unlock()

	return imports, nil
}

// ResolveImportPath resolves an import path to an actual file path
// Returns empty string if resolution fails
func (ir *ImportResolver) ResolveImportPath(importPath string, currentFile string) string {
	// Handle relative imports
	if strings.HasPrefix(importPath, "./") || strings.HasPrefix(importPath, "../") {
		currentDir := filepath.Dir(currentFile)
		resolved := filepath.Join(currentDir, importPath)
		return ir.tryResolveFile(resolved)
	}

	// Handle absolute/package imports by searching in project root
	// For React monorepo, package names like "react-server/src/..." map to directories
	resolved := filepath.Join(ir.projectRoot, importPath)
	if result := ir.tryResolveFile(resolved); result != "" {
		return result
	}

	// Try treating first component as package directory
	// e.g., "react-server/src/ReactFlightServer" -> projectRoot/react-server/src/ReactFlightServer.js
	parts := strings.SplitN(importPath, "/", 2)
	if len(parts) == 2 {
		// Try direct mapping
		resolved := filepath.Join(ir.projectRoot, parts[0], parts[1])
		if result := ir.tryResolveFile(resolved); result != "" {
			return result
		}
	}

	return ""
}

// tryResolveFile attempts to resolve a path to an actual file with common extensions
func (ir *ImportResolver) tryResolveFile(basePath string) string {
	extensions := []string{"", ".js", ".jsx", ".ts", ".tsx", ".mjs"}

	for _, ext := range extensions {
		fullPath := basePath + ext
		if _, err := os.Stat(fullPath); err == nil {
			return fullPath
		}
	}

	// Try index files
	indexNames := []string{"index.js", "index.jsx", "index.ts", "index.tsx"}
	for _, idx := range indexNames {
		fullPath := filepath.Join(basePath, idx)
		if _, err := os.Stat(fullPath); err == nil {
			return fullPath
		}
	}

	return ""
}

// parseFileImports parses a TypeScript/JavaScript file and extracts import information
func (ir *ImportResolver) parseFileImports(filePath string) (ImportMap, error) {
	content, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	// Strip Flow types if needed (same as in typescript_parser.go)
	ext := strings.ToLower(filepath.Ext(filePath))
	if (ext == ".js" || ext == ".mjs" || ext == ".jsx") && hasFlowPragma(content) {
		stripped, err := stripFlowTypes(content)
		if err == nil {
			content = stripped
		}
	}

	parser := sitter.NewParser()

	var language *sitter.Language
	if shouldUseTSX(filePath) {
		language = sitter.NewLanguage(tree_sitter_typescript.LanguageTSX())
	} else {
		language = sitter.NewLanguage(tree_sitter_typescript.LanguageTypescript())
	}

	if err := parser.SetLanguage(language); err != nil {
		return nil, err
	}

	tree := parser.Parse(content, nil)
	if tree == nil {
		return nil, nil
	}

	imports := make(ImportMap)
	root := tree.RootNode()

	// Find all import statements
	for i := uint(0); i < root.ChildCount(); i++ {
		child := root.Child(i)
		if child.Kind() == "import_statement" {
			ir.extractImports(child, content, filePath, imports)
		}
	}

	return imports, nil
}

// extractImports extracts import information from an import_statement node
func (ir *ImportResolver) extractImports(node *sitter.Node, content []byte, currentFile string, imports ImportMap) {
	// Check if this is a type-only import (Flow: "import type", TypeScript: "import type")
	isTypeImport := false
	nodeText := getNodeText(node, content)
	if strings.Contains(nodeText, "import type") {
		isTypeImport = true
	}

	// Find the source (the string at the end of the import)
	var sourcePath string
	for i := uint(0); i < node.ChildCount(); i++ {
		child := node.Child(i)
		if child.Kind() == "string" {
			// Remove quotes from the string
			sourcePath = strings.Trim(getNodeText(child, content), "\"'")
			break
		}
	}

	if sourcePath == "" {
		return
	}

	// Find import clause (the part between "import" and "from")
	for i := uint(0); i < node.ChildCount(); i++ {
		child := node.Child(i)
		if child.Kind() == "import_clause" {
			ir.extractImportClause(child, content, sourcePath, currentFile, isTypeImport, imports)
		}
	}
}

// extractImportClause extracts named imports from an import clause
func (ir *ImportResolver) extractImportClause(node *sitter.Node, content []byte, sourcePath, currentFile string, isTypeImport bool, imports ImportMap) {
	for i := uint(0); i < node.ChildCount(); i++ {
		child := node.Child(i)

		switch child.Kind() {
		case "named_imports":
			// Handle: import { foo, bar as baz } from 'source'
			ir.extractNamedImports(child, content, sourcePath, currentFile, isTypeImport, imports)

		case "identifier":
			// Handle: import foo from 'source' (default import)
			localName := getNodeText(child, content)
			imports[localName] = &Import{
				LocalName:    localName,
				OriginalName: "default",
				SourcePath:   sourcePath,
				SourceFile:   currentFile,
				IsTypeImport: isTypeImport,
			}

		case "namespace_import":
			// Handle: import * as foo from 'source'
			// Find the identifier after "as"
			for j := uint(0); j < child.ChildCount(); j++ {
				subChild := child.Child(j)
				if subChild.Kind() == "identifier" {
					localName := getNodeText(subChild, content)
					imports[localName] = &Import{
						LocalName:    localName,
						OriginalName: "*",
						SourcePath:   sourcePath,
						SourceFile:   currentFile,
						IsTypeImport: isTypeImport,
					}
					break
				}
			}
		}
	}
}

// extractNamedImports extracts individual named imports from a named_imports node
func (ir *ImportResolver) extractNamedImports(node *sitter.Node, content []byte, sourcePath, currentFile string, isTypeImport bool, imports ImportMap) {
	for i := uint(0); i < node.ChildCount(); i++ {
		child := node.Child(i)
		if child.Kind() == "import_specifier" {
			// Can be either "foo" or "foo as bar"
			var originalName, localName string

			for j := uint(0); j < child.ChildCount(); j++ {
				specChild := child.Child(j)
				if specChild.Kind() == "identifier" {
					name := getNodeText(specChild, content)
					if originalName == "" {
						originalName = name
						localName = name // Default: same name
					} else {
						// This is the "as" alias
						localName = name
					}
				}
			}

			if localName != "" {
				imports[localName] = &Import{
					LocalName:    localName,
					OriginalName: originalName,
					SourcePath:   sourcePath,
					SourceFile:   currentFile,
					IsTypeImport: isTypeImport,
				}
			}
		}
	}
}

// IsImported checks if a function name is imported in the given file
func (ir *ImportResolver) IsImported(funcName string, filePath string) (*Import, bool) {
	imports, err := ir.GetImports(filePath)
	if err != nil || imports == nil {
		return nil, false
	}

	imp, exists := imports[funcName]
	return imp, exists
}

// ResolveFunction resolves an imported function to its actual definition location
// Returns (resolvedFilePath, originalFunctionName, found)
func (ir *ImportResolver) ResolveFunction(funcName string, filePath string) (string, string, bool) {
	imp, isImported := ir.IsImported(funcName, filePath)
	if !isImported {
		return "", "", false
	}

	// Skip type imports
	if imp.IsTypeImport {
		return "", "", false
	}

	// Resolve the import path to an actual file
	resolvedFile := ir.ResolveImportPath(imp.SourcePath, filePath)
	if resolvedFile == "" {
		return "", "", false
	}

	return resolvedFile, imp.OriginalName, true
}
