package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/noperator/slice/pkg/analysis"
	"github.com/noperator/slice/pkg/logging"
	"github.com/noperator/slice/pkg/parser"
	"github.com/spf13/cobra"
)

var (
	relateSourceDir   string
	relateLeftFile    string
	relateLeftRole    string
	relateRightFile   string
	relateRightRole   string
	relateMinRounds   int
	relateCallDepth   int
	relateOutputFile  string
	relateIncludeDefs bool

	relateIncludeCallChain    bool
	relateIncludeCommonCaller bool
)

var relateLogger *slog.Logger

type RelateCandidate struct {
	Role string `json:"role,omitempty"`

	ID     string `json:"id,omitempty"`
	File   string `json:"file"`
	Line   int    `json:"line"`
	Target string `json:"target,omitempty"`
	Window string `json:"window,omitempty"`

	Rank        int         `json:"rank,omitempty"`
	Rounds      int         `json:"rounds,omitempty"`
	Score       float64     `json:"score,omitempty"`
	RoundScores interface{} `json:"round_scores,omitempty"`
	FirstTTest  interface{} `json:"first_ttest,omitempty"`

	Function *RelateFunction `json:"function,omitempty"`
}

type RelateFunction struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	File       string `json:"file"`
	StartLine  int    `json:"start_line"`
	EndLine    int    `json:"end_line"`
	Signature  string `json:"signature,omitempty"`
	Definition string `json:"definition,omitempty"`
}

type relatePairOutput struct {
	LeftRole       string           `json:"left_role"`
	RightRole      string           `json:"right_role"`
	Relation       string           `json:"relation"`
	CallDepthLimit int              `json:"call_depth_limit"`
	CallChain      []RelateFunction `json:"call_chain,omitempty"`
	CommonCaller   *RelateFunction  `json:"common_caller,omitempty"`
	LeftCallChain  []RelateFunction `json:"left_call_chain,omitempty"`
	RightCallChain []RelateFunction `json:"right_call_chain,omitempty"`
	Left           RelateCandidate  `json:"left"`
	Right          RelateCandidate  `json:"right"`
}

type relateLoadResult struct {
	Candidates  []RelateCandidate
	Loaded      int
	AfterFilter int
}

var relateCmd = &cobra.Command{
	Use:   "relate",
	Short: "Relate two sets of line-level candidates using Slice's parsed symbols and call graph.",
	Long:  "Relate two sets of line-level candidates using Slice's parsed symbols and call graph.",
	RunE: func(cmd *cobra.Command, args []string) error {
		relateLogger = logging.NewLoggerFromEnv()

		if relateSourceDir == "" {
			return fmt.Errorf("source directory is required (use --source)")
		}
		if relateLeftFile == "" {
			return fmt.Errorf("left candidate file is required (use --left)")
		}
		if relateRightFile == "" {
			return fmt.Errorf("right candidate file is required (use --right)")
		}
		if relateCallDepth < 0 {
			relateCallDepth = 10
		}

		leftLoaded, err := loadRelateCandidates(relateLeftFile, relateLeftRole, relateMinRounds)
		if err != nil {
			return fmt.Errorf("failed to load left candidates: %w", err)
		}
		relateLogger.Info("loaded left candidates",
			"component", "relate",
			"file", relateLeftFile,
			"loaded", leftLoaded.Loaded,
			"after_filter", leftLoaded.AfterFilter)

		rightLoaded, err := loadRelateCandidates(relateRightFile, relateRightRole, relateMinRounds)
		if err != nil {
			return fmt.Errorf("failed to load right candidates: %w", err)
		}
		relateLogger.Info("loaded right candidates",
			"component", "relate",
			"file", relateRightFile,
			"loaded", rightLoaded.Loaded,
			"after_filter", rightLoaded.AfterFilter)

		analysisResult, err := parser.GetCachedAnalysisResult(relateSourceDir)
		if err != nil {
			return fmt.Errorf("failed to parse source code: %w", err)
		}

		callGraph := analysis.BuildCallGraph(analysisResult.Symbols)
		symbolsByID := make(map[string]parser.Symbol, len(analysisResult.Symbols))
		for _, symbol := range analysisResult.Symbols {
			symbolsByID[symbol.ID] = symbol
		}
		relateLogger.Info("built call graph",
			"component", "relate",
			"symbols", len(analysisResult.Symbols))

		leftResolved, unresolvedLeft := resolveRelateCandidates(leftLoaded.Candidates, analysisResult.Symbols, relateIncludeDefs, relateLogger)
		relateLogger.Info("resolved left candidates",
			"component", "relate",
			"resolved", len(leftResolved),
			"unresolved", unresolvedLeft)

		rightResolved, unresolvedRight := resolveRelateCandidates(rightLoaded.Candidates, analysisResult.Symbols, relateIncludeDefs, relateLogger)
		relateLogger.Info("resolved right candidates",
			"component", "relate",
			"resolved", len(rightResolved),
			"unresolved", unresolvedRight)

		var output io.Writer = os.Stdout
		var outputFile *os.File
		if relateOutputFile != "" {
			outputFile, err = os.Create(relateOutputFile)
			if err != nil {
				return fmt.Errorf("failed to create output file %s: %w", relateOutputFile, err)
			}
			defer outputFile.Close()
			output = outputFile
		}

		pairsConsidered, pairsEmitted, err := writeRelatePairs(
			output,
			leftResolved,
			rightResolved,
			callGraph,
			relateCallDepth,
			relateLeftRole,
			relateRightRole,
			symbolsByID,
			relateIncludeDefs,
			relateIncludeCallChain,
			relateIncludeCommonCaller,
		)
		if err != nil {
			return err
		}

		relateLogger.Info("relation filtering complete",
			"component", "relate",
			"left_loaded", leftLoaded.Loaded,
			"right_loaded", rightLoaded.Loaded,
			"left_after_filter", leftLoaded.AfterFilter,
			"right_after_filter", rightLoaded.AfterFilter,
			"left_resolved", len(leftResolved),
			"right_resolved", len(rightResolved),
			"pairs_considered", pairsConsidered,
			"pairs_emitted", pairsEmitted,
			"unresolved_left", unresolvedLeft,
			"unresolved_right", unresolvedRight,
			"call_depth", relateCallDepth)

		return nil
	},
}

func loadRelateCandidates(filename, role string, minRounds int) (relateLoadResult, error) {
	reader, err := openRelateInput(filename)
	if err != nil {
		return relateLoadResult{}, err
	}
	defer reader.Close()

	data, err := io.ReadAll(reader)
	if err != nil {
		return relateLoadResult{}, err
	}

	if result, ok, err := loadSiftRankRelateCandidates(data, role, minRounds); ok || err != nil {
		return result, err
	}

	return loadJSONLRelateCandidates(data, role, minRounds)
}

func openRelateInput(filename string) (io.ReadCloser, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}

	if !strings.HasSuffix(filename, ".gz") {
		return file, nil
	}

	gzipReader, err := gzip.NewReader(file)
	if err != nil {
		file.Close()
		return nil, err
	}

	return &compoundReadCloser{Reader: gzipReader, closers: []io.Closer{gzipReader, file}}, nil
}

type compoundReadCloser struct {
	io.Reader
	closers []io.Closer
}

func (c *compoundReadCloser) Close() error {
	var firstErr error
	for _, closer := range c.closers {
		if err := closer.Close(); err != nil && firstErr == nil {
			firstErr = err
		}
	}
	return firstErr
}

func loadSiftRankRelateCandidates(data []byte, role string, minRounds int) (relateLoadResult, bool, error) {
	var payload map[string]interface{}
	if err := decodeRelateJSON(data, &payload); err != nil {
		return relateLoadResult{}, false, nil
	}

	rawRanking, hasRanking := payload["ranking"]
	if !hasRanking {
		return relateLoadResult{}, false, nil
	}

	ranking, ok := rawRanking.([]interface{})
	if !ok {
		return relateLoadResult{}, true, fmt.Errorf("ranking must be an array")
	}

	result := relateLoadResult{Loaded: len(ranking)}
	for i, rawRecord := range ranking {
		record, ok := rawRecord.(map[string]interface{})
		if !ok {
			return relateLoadResult{}, true, fmt.Errorf("ranking[%d] must be an object", i)
		}

		rawDocument, ok := record["document"]
		if !ok {
			return relateLoadResult{}, true, fmt.Errorf("ranking[%d].document is required", i)
		}
		document, ok := rawDocument.(map[string]interface{})
		if !ok {
			return relateLoadResult{}, true, fmt.Errorf("ranking[%d].document must be an object", i)
		}

		candidate, _, err := relateCandidateFromMap(document, role)
		if err != nil {
			return relateLoadResult{}, true, fmt.Errorf("ranking[%d].document: %w", i, err)
		}

		if rank, ok := intFromMap(record, "rank"); ok {
			candidate.Rank = rank
		}
		if rounds, ok := intFromMap(record, "rounds"); ok {
			candidate.Rounds = rounds
		}
		if score, ok := floatFromMap(record, "score"); ok {
			candidate.Score = score
		}
		if roundScores, ok := record["round_scores"]; ok {
			candidate.RoundScores = roundScores
		}
		if firstTTest, ok := record["first_ttest"]; ok {
			candidate.FirstTTest = firstTTest
		}

		if candidate.Rounds < minRounds {
			continue
		}
		result.Candidates = append(result.Candidates, candidate)
	}
	result.AfterFilter = len(result.Candidates)

	return result, true, nil
}

func loadJSONLRelateCandidates(data []byte, role string, minRounds int) (relateLoadResult, error) {
	var result relateLoadResult
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 0, 64*1024), 10*1024*1024)

	lineNumber := 0
	for scanner.Scan() {
		lineNumber++
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var record map[string]interface{}
		if err := decodeRelateJSON([]byte(line), &record); err != nil {
			return relateLoadResult{}, fmt.Errorf("line %d: %w", lineNumber, err)
		}

		result.Loaded++
		candidate, hasRounds, err := relateCandidateFromMap(record, role)
		if err != nil {
			return relateLoadResult{}, fmt.Errorf("line %d: %w", lineNumber, err)
		}
		if minRounds > 0 && hasRounds && candidate.Rounds < minRounds {
			continue
		}
		result.Candidates = append(result.Candidates, candidate)
	}
	if err := scanner.Err(); err != nil {
		return relateLoadResult{}, err
	}

	result.AfterFilter = len(result.Candidates)
	return result, nil
}

func decodeRelateJSON(data []byte, v interface{}) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.UseNumber()
	return decoder.Decode(v)
}

func relateCandidateFromMap(record map[string]interface{}, role string) (RelateCandidate, bool, error) {
	file, ok := stringFromMap(record, "file")
	if !ok || file == "" {
		return RelateCandidate{}, false, fmt.Errorf("file is required")
	}

	line, ok := intFromMap(record, "line")
	if !ok || line <= 0 {
		return RelateCandidate{}, false, fmt.Errorf("line must be a positive integer")
	}

	candidate := RelateCandidate{
		Role: role,
		File: file,
		Line: line,
	}

	if id, ok := stringFromMap(record, "id"); ok {
		candidate.ID = id
	}
	if target, ok := stringFromMap(record, "target"); ok {
		candidate.Target = target
	}
	if window, ok := stringFromMap(record, "window"); ok {
		candidate.Window = window
	}
	if rank, ok := intFromMap(record, "rank"); ok {
		candidate.Rank = rank
	}
	rounds, hasRounds := intFromMap(record, "rounds")
	if hasRounds {
		candidate.Rounds = rounds
	}
	if score, ok := floatFromMap(record, "score"); ok {
		candidate.Score = score
	}
	if roundScores, ok := record["round_scores"]; ok {
		candidate.RoundScores = roundScores
	}
	if firstTTest, ok := record["first_ttest"]; ok {
		candidate.FirstTTest = firstTTest
	}

	return candidate, hasRounds, nil
}

func stringFromMap(record map[string]interface{}, key string) (string, bool) {
	value, ok := record[key]
	if !ok || value == nil {
		return "", false
	}
	text, ok := value.(string)
	return text, ok
}

func intFromMap(record map[string]interface{}, key string) (int, bool) {
	value, ok := record[key]
	if !ok || value == nil {
		return 0, false
	}
	switch v := value.(type) {
	case json.Number:
		if n, err := v.Int64(); err == nil {
			return int(n), true
		}
		if f, err := v.Float64(); err == nil {
			return int(f), true
		}
	case float64:
		return int(v), true
	case int:
		return v, true
	case int64:
		return int(v), true
	}
	return 0, false
}

func floatFromMap(record map[string]interface{}, key string) (float64, bool) {
	value, ok := record[key]
	if !ok || value == nil {
		return 0, false
	}
	switch v := value.(type) {
	case json.Number:
		f, err := v.Float64()
		return f, err == nil
	case float64:
		return v, true
	case int:
		return float64(v), true
	case int64:
		return float64(v), true
	}
	return 0, false
}

func resolveRelateCandidates(candidates []RelateCandidate, symbols []parser.Symbol, includeDefs bool, logger *slog.Logger) ([]RelateCandidate, int) {
	resolved := make([]RelateCandidate, 0, len(candidates))
	unresolved := 0

	for _, candidate := range candidates {
		function := resolveRelateFunction(candidate, symbols, includeDefs)
		if function == nil {
			unresolved++
			if logger != nil {
				logger.Debug("candidate did not resolve to function",
					"component", "relate",
					"role", candidate.Role,
					"id", candidate.ID,
					"file", candidate.File,
					"line", candidate.Line)
			}
			continue
		}
		candidate.Function = function
		resolved = append(resolved, candidate)
	}

	return resolved, unresolved
}

func resolveRelateFunction(candidate RelateCandidate, symbols []parser.Symbol, includeDefs bool) *RelateFunction {
	bestIndex := -1
	bestSpan := 0

	for i := range symbols {
		symbol := symbols[i]
		if !isRelateFunctionSymbol(symbol) {
			continue
		}
		if !relateFilesMatch(symbol.Filename, candidate.File) {
			continue
		}
		if symbol.StartLine > candidate.Line || symbol.EndLine < candidate.Line {
			continue
		}

		span := symbol.EndLine - symbol.StartLine
		if bestIndex == -1 || span < bestSpan {
			bestIndex = i
			bestSpan = span
		}
	}

	if bestIndex == -1 {
		return nil
	}
	return relateFunctionFromSymbol(symbols[bestIndex], includeDefs)
}

func isRelateFunctionSymbol(symbol parser.Symbol) bool {
	return symbol.Kind == "" || symbol.Kind == "function" || symbol.Kind == "method"
}

func relateFilesMatch(symbolFile, candidateFile string) bool {
	symbolFile = normalizeRelatePath(symbolFile)
	candidateFile = normalizeRelatePath(candidateFile)
	if symbolFile == "" || candidateFile == "" {
		return false
	}
	return symbolFile == candidateFile ||
		strings.HasSuffix(symbolFile, candidateFile) ||
		strings.HasSuffix(candidateFile, symbolFile)
}

func normalizeRelatePath(path string) string {
	path = strings.TrimSpace(path)
	if path == "" {
		return ""
	}
	return filepath.ToSlash(filepath.Clean(path))
}

func relateFunctionFromSymbol(symbol parser.Symbol, includeDefs bool) *RelateFunction {
	function := &RelateFunction{
		ID:        symbol.ID,
		Name:      symbol.Name,
		File:      symbol.Filename,
		StartLine: symbol.StartLine,
		EndLine:   symbol.EndLine,
		Signature: symbol.Signature,
	}
	if includeDefs {
		function.Definition = symbol.DefinitionWithLineNumbers
	}
	return function
}

type relatePathCacheEntry struct {
	path []string
}

func writeRelatePairs(
	writer io.Writer,
	leftCandidates, rightCandidates []RelateCandidate,
	callGraph *analysis.CallGraph,
	callDepth int,
	leftRole, rightRole string,
	symbolsByID map[string]parser.Symbol,
	includeDefs bool,
	includeCallChain bool,
	includeCommonCaller bool,
) (int64, int64, error) {
	encoder := json.NewEncoder(writer)
	relationCache := make(map[string]string)
	pathCache := make(map[string]relatePathCacheEntry)
	commonCallerCache := make(map[string]*analysis.CommonCallerPathIDs)

	var pairsConsidered int64
	var pairsEmitted int64

	for _, left := range leftCandidates {
		if left.Function == nil {
			continue
		}
		for _, right := range rightCandidates {
			if right.Function == nil {
				continue
			}

			pairsConsidered++
			relation, ok := relateFunctionPair(callGraph, left.Function.ID, right.Function.ID, callDepth, relationCache)
			if ok {
				output := relatePairOutput{
					LeftRole:       leftRole,
					RightRole:      rightRole,
					Relation:       relation,
					CallDepthLimit: callDepth,
					Left:           left,
					Right:          right,
				}
				if includeCallChain {
					output.CallChain = relateCallChainForRelation(callGraph, relation, left.Function.ID, right.Function.ID, callDepth, symbolsByID, includeDefs, pathCache)
				}
				if err := encoder.Encode(output); err != nil {
					return pairsConsidered, pairsEmitted, fmt.Errorf("failed to encode related pair: %w", err)
				}
				pairsEmitted++
				continue
			}

			if includeCommonCaller {
				commonCaller := cachedRelateCommonCaller(callGraph, left.Function.ID, right.Function.ID, callDepth, commonCallerCache)
				if commonCaller == nil {
					continue
				}

				output := relatePairOutput{
					LeftRole:       leftRole,
					RightRole:      rightRole,
					Relation:       "common_caller",
					CallDepthLimit: callDepth,
					CommonCaller:   relateFunctionForID(commonCaller.CallerID, symbolsByID, includeDefs),
					LeftCallChain:  relateFunctionsFromPathIDs(commonCaller.LeftPath, symbolsByID, includeDefs),
					RightCallChain: relateFunctionsFromPathIDs(commonCaller.RightPath, symbolsByID, includeDefs),
					Left:           left,
					Right:          right,
				}
				if err := encoder.Encode(output); err != nil {
					return pairsConsidered, pairsEmitted, fmt.Errorf("failed to encode related pair: %w", err)
				}
				pairsEmitted++
			}
		}
	}

	return pairsConsidered, pairsEmitted, nil
}

func relateCallChainForRelation(
	callGraph *analysis.CallGraph,
	relation string,
	leftFunctionID string,
	rightFunctionID string,
	callDepth int,
	symbolsByID map[string]parser.Symbol,
	includeDefs bool,
	pathCache map[string]relatePathCacheEntry,
) []RelateFunction {
	switch relation {
	case "same_function":
		return relateFunctionsFromPathIDs([]string{leftFunctionID}, symbolsByID, includeDefs)
	case "left_reaches_right":
		return relateFunctionsFromPathIDs(cachedRelatePathIDs(callGraph, leftFunctionID, rightFunctionID, callDepth, pathCache), symbolsByID, includeDefs)
	case "right_reaches_left":
		return relateFunctionsFromPathIDs(cachedRelatePathIDs(callGraph, rightFunctionID, leftFunctionID, callDepth, pathCache), symbolsByID, includeDefs)
	default:
		return nil
	}
}

func cachedRelatePathIDs(callGraph *analysis.CallGraph, from, to string, callDepth int, cache map[string]relatePathCacheEntry) []string {
	key := from + "\x00" + to + "\x00" + strconv.Itoa(callDepth)
	if cached, ok := cache[key]; ok {
		return cached.path
	}
	path := callGraph.FindPathIDs(from, to, callDepth)
	cache[key] = relatePathCacheEntry{path: path}
	return path
}

func cachedRelateCommonCaller(callGraph *analysis.CallGraph, leftID, rightID string, callDepth int, cache map[string]*analysis.CommonCallerPathIDs) *analysis.CommonCallerPathIDs {
	key := leftID + "\x00" + rightID + "\x00" + strconv.Itoa(callDepth)
	if cached, ok := cache[key]; ok {
		return cached
	}
	commonCaller := callGraph.FindCommonCallerPathIDs(leftID, rightID, callDepth)
	cache[key] = commonCaller
	return commonCaller
}

func relateFunctionForID(id string, symbolsByID map[string]parser.Symbol, includeDefs bool) *RelateFunction {
	symbol, ok := symbolsByID[id]
	if !ok {
		return nil
	}
	return relateFunctionFromSymbol(symbol, includeDefs)
}

func relateFunctionsFromPathIDs(pathIDs []string, symbolsByID map[string]parser.Symbol, includeDefs bool) []RelateFunction {
	functions := make([]RelateFunction, 0, len(pathIDs))
	for _, id := range pathIDs {
		function := relateFunctionForID(id, symbolsByID, includeDefs)
		if function == nil {
			continue
		}
		functions = append(functions, *function)
	}
	return functions
}

func relateFunctionPair(callGraph *analysis.CallGraph, leftFunctionID, rightFunctionID string, callDepth int, relationCache map[string]string) (string, bool) {
	key := leftFunctionID + "\x00" + rightFunctionID + "\x00" + strconv.Itoa(callDepth)
	if relation, ok := relationCache[key]; ok {
		return relation, relation != ""
	}

	relation := ""
	switch {
	case leftFunctionID == rightFunctionID:
		relation = "same_function"
	case callGraph.HasPathCached(leftFunctionID, rightFunctionID, callDepth):
		relation = "left_reaches_right"
	case callGraph.HasPathCached(rightFunctionID, leftFunctionID, callDepth):
		relation = "right_reaches_left"
	}

	relationCache[key] = relation
	return relation, relation != ""
}

func init() {
	relateCmd.Flags().StringVarP(&relateSourceDir, "source", "s", "", "Source directory to parse (required)")
	relateCmd.Flags().StringVar(&relateLeftFile, "left", "", "Left candidate file (required)")
	relateCmd.Flags().StringVar(&relateLeftRole, "left-role", "left", "Label for left candidates")
	relateCmd.Flags().StringVar(&relateRightFile, "right", "", "Right candidate file (required)")
	relateCmd.Flags().StringVar(&relateRightRole, "right-role", "right", "Label for right candidates")
	relateCmd.Flags().IntVar(&relateMinRounds, "min-rounds", 0, "Keep only SiftRank records with rounds >= this value")
	relateCmd.Flags().IntVarP(&relateCallDepth, "call-depth", "c", 3, "Maximum call relationship depth")
	relateCmd.Flags().StringVarP(&relateOutputFile, "output", "o", "", "Output JSONL file (default: stdout)")
	relateCmd.Flags().BoolVar(&relateIncludeDefs, "include-defs", false, "Include enclosing function definitions in output")
	relateCmd.Flags().BoolVar(&relateIncludeCallChain, "include-call-chain", false, "Include one ordered call-chain witness for each directed related pair")
	relateCmd.Flags().BoolVar(&relateIncludeCommonCaller, "include-common-caller", false, "Also emit common-caller relationships with branch call chains")

	_ = relateCmd.MarkFlagRequired("source")
	_ = relateCmd.MarkFlagRequired("left")
	_ = relateCmd.MarkFlagRequired("right")

	rootCmd.AddCommand(relateCmd)
}
