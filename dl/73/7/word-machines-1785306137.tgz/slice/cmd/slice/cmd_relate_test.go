package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/noperator/slice/pkg/analysis"
	"github.com/noperator/slice/pkg/parser"
)

func TestLoadSiftRankRelateCandidates(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "siftrank.json")
	input := []byte(`{
		"ranking": [
			{
				"rank": 1,
				"rounds": 1,
				"score": 0.2,
				"first_ttest": {"p": 0.5},
				"document": {"id": "foo.c:12", "file": "foo.c", "line": 12, "target": "skip();"}
			},
			{
				"rank": 2,
				"rounds": 3,
				"score": 2.4,
				"round_scores": {"overall": 0.42},
				"first_ttest": {"p": 0.006, "t": -2.74},
				"document": {"id": "foo.c:15", "file": "foo.c", "line": 15, "target": "keep();", "window": "14  before\n15> keep();\n16  after"}
			}
		]
	}`)
	if err := os.WriteFile(path, input, 0o600); err != nil {
		t.Fatal(err)
	}

	result, err := loadRelateCandidates(path, "free", 2)
	if err != nil {
		t.Fatal(err)
	}
	if result.Loaded != 2 {
		t.Fatalf("Loaded = %d, want 2", result.Loaded)
	}
	if result.AfterFilter != 1 {
		t.Fatalf("AfterFilter = %d, want 1", result.AfterFilter)
	}

	candidate := result.Candidates[0]
	if candidate.Role != "free" || candidate.ID != "foo.c:15" || candidate.File != "foo.c" || candidate.Line != 15 {
		t.Fatalf("unexpected candidate: %+v", candidate)
	}
	if candidate.Rank != 2 || candidate.Rounds != 3 || candidate.Score != 2.4 {
		t.Fatalf("metadata not preserved: %+v", candidate)
	}
	if candidate.FirstTTest == nil {
		t.Fatal("FirstTTest was not preserved")
	}
	if candidate.Window != "14  before\n15> keep();\n16  after" {
		t.Fatalf("Window = %q, want preserved window", candidate.Window)
	}
}

func TestLoadJSONLRelateCandidates(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "candidates.jsonl.gz")

	var compressed bytes.Buffer
	gzipWriter := gzip.NewWriter(&compressed)
	_, _ = gzipWriter.Write([]byte(`{"file":"foo.c","line":10,"id":"foo.c:10","rounds":1}` + "\n"))
	_, _ = gzipWriter.Write([]byte(`{"file":"bar.c","line":20,"target":"use();","window":"19  before\n20> use();\n21  after"}` + "\n"))
	if err := gzipWriter.Close(); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, compressed.Bytes(), 0o600); err != nil {
		t.Fatal(err)
	}

	result, err := loadRelateCandidates(path, "use", 2)
	if err != nil {
		t.Fatal(err)
	}
	if result.Loaded != 2 || result.AfterFilter != 1 {
		t.Fatalf("loaded/filter counts = %d/%d, want 2/1", result.Loaded, result.AfterFilter)
	}

	candidate := result.Candidates[0]
	if candidate.Role != "use" || candidate.File != "bar.c" || candidate.Line != 20 || candidate.Target != "use();" {
		t.Fatalf("unexpected candidate: %+v", candidate)
	}
	if candidate.Window != "19  before\n20> use();\n21  after" {
		t.Fatalf("Window = %q, want preserved window", candidate.Window)
	}
}

func TestResolveRelateFunction(t *testing.T) {
	symbols := []parser.Symbol{
		{
			ID:        "c:/repo/src/foo.c:10:a",
			Lang:      parser.LangC,
			Kind:      "function",
			Filename:  "/repo/src/foo.c",
			StartLine: 10,
			EndLine:   20,
			Name:      "a",
		},
		{
			ID:        "c:/repo/src/foo.c:30:b",
			Lang:      parser.LangC,
			Kind:      "function",
			Filename:  "/repo/src/foo.c",
			StartLine: 30,
			EndLine:   40,
			Name:      "b",
		},
	}

	tests := []struct {
		name string
		file string
		line int
		want string
	}{
		{name: "a", file: "foo.c", line: 15, want: "a"},
		{name: "b", file: "src/foo.c", line: 35, want: "b"},
		{name: "none", file: "foo.c", line: 25, want: ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := resolveRelateFunction(RelateCandidate{File: tt.file, Line: tt.line}, symbols, false)
			if tt.want == "" {
				if got != nil {
					t.Fatalf("got %s, want nil", got.Name)
				}
				return
			}
			if got == nil || got.Name != tt.want {
				t.Fatalf("got %+v, want %s", got, tt.want)
			}
		})
	}
}

func TestRelateFunctionPair(t *testing.T) {
	symbols := []parser.Symbol{
		{
			ID:            "c:test.c:1:a",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "a",
			QualifiedName: "a",
			Filename:      "test.c",
			StartLine:     1,
			EndLine:       5,
			Callees:       []parser.Callee{{Name: "b", Line: 2}},
		},
		{
			ID:            "c:test.c:10:b",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "b",
			QualifiedName: "b",
			Filename:      "test.c",
			StartLine:     10,
			EndLine:       15,
			Callees:       []parser.Callee{{Name: "c", Line: 11}},
		},
		{
			ID:            "c:test.c:20:c",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "c",
			QualifiedName: "c",
			Filename:      "test.c",
			StartLine:     20,
			EndLine:       25,
		},
		{
			ID:            "c:test.c:30:x",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "x",
			QualifiedName: "x",
			Filename:      "test.c",
			StartLine:     30,
			EndLine:       35,
		},
	}
	callGraph := analysis.BuildCallGraph(symbols)

	tests := []struct {
		name       string
		leftID     string
		rightID    string
		depth      int
		wantOK     bool
		wantRelate string
	}{
		{name: "a to b", leftID: "c:test.c:1:a", rightID: "c:test.c:10:b", depth: 1, wantOK: true, wantRelate: "left_reaches_right"},
		{name: "b to a", leftID: "c:test.c:10:b", rightID: "c:test.c:1:a", depth: 1, wantOK: true, wantRelate: "right_reaches_left"},
		{name: "a to c depth 2", leftID: "c:test.c:1:a", rightID: "c:test.c:20:c", depth: 2, wantOK: true, wantRelate: "left_reaches_right"},
		{name: "a to c depth 1", leftID: "c:test.c:1:a", rightID: "c:test.c:20:c", depth: 1, wantOK: false},
		{name: "same function", leftID: "c:test.c:1:a", rightID: "c:test.c:1:a", depth: 1, wantOK: true, wantRelate: "same_function"},
		{name: "isolated", leftID: "c:test.c:1:a", rightID: "c:test.c:30:x", depth: 3, wantOK: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cache := make(map[string]string)
			got, ok := relateFunctionPair(callGraph, tt.leftID, tt.rightID, tt.depth, cache)
			if ok != tt.wantOK {
				t.Fatalf("ok = %v, want %v", ok, tt.wantOK)
			}
			if got != tt.wantRelate {
				t.Fatalf("relation = %q, want %q", got, tt.wantRelate)
			}
		})
	}
}

func TestWriteRelatePairs(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{
		Role:     "left",
		File:     "test.c",
		Line:     1,
		Window:   "1> left();",
		Function: &RelateFunction{ID: "c:test.c:1:a", Name: "a"},
	}}
	right := []RelateCandidate{{
		Role:     "right",
		File:     "test.c",
		Line:     10,
		Window:   "10> right();",
		Function: &RelateFunction{ID: "c:test.c:10:b", Name: "b"},
	}}

	var out bytes.Buffer
	considered, emitted, err := writeRelatePairs(&out, left, right, callGraph, 1, "left", "right", symbolsByID(symbols), false, false, false)
	if err != nil {
		t.Fatal(err)
	}
	if considered != 1 || emitted != 1 {
		t.Fatalf("counts = %d/%d, want 1/1", considered, emitted)
	}

	var decoded relatePairOutput
	if err := json.Unmarshal(bytes.TrimSpace(out.Bytes()), &decoded); err != nil {
		t.Fatal(err)
	}
	if decoded.Relation != "left_reaches_right" || decoded.LeftRole != "left" || decoded.RightRole != "right" {
		t.Fatalf("unexpected output: %+v", decoded)
	}
	if decoded.Left.Window != "1> left();" || decoded.Right.Window != "10> right();" {
		t.Fatalf("candidate windows were not preserved in relate output: left=%q right=%q", decoded.Left.Window, decoded.Right.Window)
	}

	var raw map[string]interface{}
	if err := json.Unmarshal(bytes.TrimSpace(out.Bytes()), &raw); err != nil {
		t.Fatal(err)
	}
	if _, ok := raw["call_chain"]; ok {
		t.Fatal("call_chain should be omitted by default")
	}
}

func TestWriteRelatePairsWithDirectCallChain(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:1:a", Name: "a"}}}
	right := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:10:b", Name: "b"}}}

	decoded := writeOneRelatePairForTest(t, left, right, callGraph, 1, symbols, true, false)
	if decoded.Relation != "left_reaches_right" {
		t.Fatalf("Relation = %q, want left_reaches_right", decoded.Relation)
	}
	assertChainNames(t, decoded.CallChain, []string{"a", "b"})
}

func TestWriteRelatePairsWithReverseCallChain(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:10:b", Name: "b"}}}
	right := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:1:a", Name: "a"}}}

	decoded := writeOneRelatePairForTest(t, left, right, callGraph, 1, symbols, true, false)
	if decoded.Relation != "right_reaches_left" {
		t.Fatalf("Relation = %q, want right_reaches_left", decoded.Relation)
	}
	assertChainNames(t, decoded.CallChain, []string{"a", "b"})
}

func TestWriteRelatePairsWithSameFunctionCallChain(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:1:a", Name: "a"}}}
	right := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:1:a", Name: "a"}}}

	decoded := writeOneRelatePairForTest(t, left, right, callGraph, 1, symbols, true, false)
	if decoded.Relation != "same_function" {
		t.Fatalf("Relation = %q, want same_function", decoded.Relation)
	}
	assertChainNames(t, decoded.CallChain, []string{"a"})
}

func TestWriteRelatePairsCommonCallerDisabled(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:20:left_child", Name: "left_child"}}}
	right := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:30:right_child", Name: "right_child"}}}

	var out bytes.Buffer
	considered, emitted, err := writeRelatePairs(&out, left, right, callGraph, 1, "left", "right", symbolsByID(symbols), false, true, false)
	if err != nil {
		t.Fatal(err)
	}
	if considered != 1 || emitted != 0 {
		t.Fatalf("counts = %d/%d, want 1/0", considered, emitted)
	}
	if out.Len() != 0 {
		t.Fatalf("unexpected output: %s", out.String())
	}
}

func TestWriteRelatePairsCommonCallerEnabled(t *testing.T) {
	symbols := relateOutputTestSymbols()
	callGraph := analysis.BuildCallGraph(symbols)
	left := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:20:left_child", Name: "left_child"}}}
	right := []RelateCandidate{{Function: &RelateFunction{ID: "c:test.c:30:right_child", Name: "right_child"}}}

	decoded := writeOneRelatePairForTest(t, left, right, callGraph, 1, symbols, false, true)
	if decoded.Relation != "common_caller" {
		t.Fatalf("Relation = %q, want common_caller", decoded.Relation)
	}
	if decoded.CommonCaller == nil || decoded.CommonCaller.Name != "root" {
		t.Fatalf("CommonCaller = %+v, want root", decoded.CommonCaller)
	}
	assertChainNames(t, decoded.LeftCallChain, []string{"root", "left_child"})
	assertChainNames(t, decoded.RightCallChain, []string{"root", "right_child"})
}

func writeOneRelatePairForTest(
	t *testing.T,
	left []RelateCandidate,
	right []RelateCandidate,
	callGraph *analysis.CallGraph,
	callDepth int,
	symbols []parser.Symbol,
	includeCallChain bool,
	includeCommonCaller bool,
) relatePairOutput {
	t.Helper()

	var out bytes.Buffer
	considered, emitted, err := writeRelatePairs(&out, left, right, callGraph, callDepth, "left", "right", symbolsByID(symbols), false, includeCallChain, includeCommonCaller)
	if err != nil {
		t.Fatal(err)
	}
	if considered != 1 || emitted != 1 {
		t.Fatalf("counts = %d/%d, want 1/1", considered, emitted)
	}

	var decoded relatePairOutput
	if err := json.Unmarshal(bytes.TrimSpace(out.Bytes()), &decoded); err != nil {
		t.Fatal(err)
	}
	return decoded
}

func assertChainNames(t *testing.T, got []RelateFunction, want []string) {
	t.Helper()

	if len(got) != len(want) {
		t.Fatalf("chain length = %d, want %d: %+v", len(got), len(want), got)
	}
	for i := range want {
		if got[i].Name != want[i] {
			t.Fatalf("chain[%d] = %q, want %q: %+v", i, got[i].Name, want[i], got)
		}
	}
}

func symbolsByID(symbols []parser.Symbol) map[string]parser.Symbol {
	result := make(map[string]parser.Symbol, len(symbols))
	for _, symbol := range symbols {
		result[symbol.ID] = symbol
	}
	return result
}

func relateOutputTestSymbols() []parser.Symbol {
	return []parser.Symbol{
		{
			ID:            "c:test.c:1:a",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "a",
			QualifiedName: "a",
			Filename:      "test.c",
			StartLine:     1,
			EndLine:       5,
			Callees:       []parser.Callee{{Name: "b", Line: 2}},
		},
		{
			ID:            "c:test.c:10:b",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "b",
			QualifiedName: "b",
			Filename:      "test.c",
			StartLine:     10,
			EndLine:       15,
		},
		{
			ID:            "c:test.c:20:left_child",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "left_child",
			QualifiedName: "left_child",
			Filename:      "test.c",
			StartLine:     20,
			EndLine:       25,
		},
		{
			ID:            "c:test.c:30:right_child",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "right_child",
			QualifiedName: "right_child",
			Filename:      "test.c",
			StartLine:     30,
			EndLine:       35,
		},
		{
			ID:            "c:test.c:40:root",
			Lang:          parser.LangC,
			Kind:          "function",
			Name:          "root",
			QualifiedName: "root",
			Filename:      "test.c",
			StartLine:     40,
			EndLine:       50,
			Callees: []parser.Callee{
				{Name: "left_child", Line: 41},
				{Name: "right_child", Line: 42},
			},
		},
	}
}
