package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"runtime"
	"strconv"
	"sync"

	"github.com/spf13/cobra"
	"github.com/noperator/slice/pkg/analysis"
	"github.com/noperator/slice/pkg/codeql"
	"github.com/noperator/slice/pkg/logging"
	"github.com/noperator/slice/pkg/parser"
)

var (
	sinksDatabase      string
	sinksQueryFile     string
	sinksCodeqlBin     string
	sinksSourceDir     string
	sinksCallDepth     int
	sinksConcurrency   int
	sinksMinConfidence string
	sinksOutput        string // Output file for JSONL results
	// Save/load options for caching intermediate results
	sinksSaveSinks     string
	sinksLoadSinks     string
	sinksSaveCallgraph string
	sinksLoadCallgraph string
)

var sinksLogger *slog.Logger

var sinksCmd = &cobra.Command{
	Use:   "sinks",
	Short: "Find sinks and build reverse call chains with network indicators",
	Long: `Find unsafe property access sinks using CodeQL, then build reverse call chains
to identify potential entry points. Each finding is annotated with network indicators
to help prioritize results by likelihood of network input.

Output is streamed as JSONL (one JSON object per line) to stdout as findings are processed.

Example:
  slice sinks -q ./spec/prototype-pollution/sinks-only.ql -d ./mydb -s ./src`,
	RunE: func(cmd *cobra.Command, args []string) error {
		sinksLogger = logging.NewLoggerFromEnv()

		// Validate required flags based on load options
		if sinksLoadSinks == "" {
			if sinksDatabase == "" {
				return fmt.Errorf("database path is required when not using --load-sinks (use --database)")
			}
			if sinksQueryFile == "" {
				return fmt.Errorf("query file is required when not using --load-sinks (use --query)")
			}
		}
		if sinksLoadCallgraph == "" && sinksSourceDir == "" {
			return fmt.Errorf("source directory is required when not using --load-callgraph (use --source)")
		}

		return runSinksCommand()
	},
}

func runSinksCommand() error {
	var sinkResults []codeql.SinkResult
	var err error

	// Step 1: Get sink results (either from CodeQL or from saved file)
	if sinksLoadSinks != "" {
		// Load sinks from CSV file
		sinksLogger.Info("loading sinks from file",
			"component", "sinks",
			"file", sinksLoadSinks)
		sinkResults, err = loadSinksFromCSV(sinksLoadSinks)
		if err != nil {
			return fmt.Errorf("failed to load sinks from %s: %w", sinksLoadSinks, err)
		}
		sinksLogger.Info("loaded sinks",
			"component", "sinks",
			"count", len(sinkResults))
	} else {
		// Run CodeQL query
		executor, err := codeql.NewExecutor(sinksCodeqlBin)
		if err != nil {
			return fmt.Errorf("failed to initialize CodeQL executor: %w", err)
		}

		if err := executor.CheckCodeQLAvailable(); err != nil {
			return fmt.Errorf("CodeQL not available: %w", err)
		}

		sinksLogger.Info("running codeql sink query",
			"component", "sinks",
			"query_file", sinksQueryFile,
			"database", sinksDatabase)

		sinkResults, err = executor.RunSinkQuery(sinksDatabase, sinksQueryFile)
		if err != nil {
			return fmt.Errorf("failed to run CodeQL query: %w", err)
		}

		sinksLogger.Info("codeql query complete",
			"component", "sinks",
			"sinks_found", len(sinkResults))

		// Save sinks to CSV if requested
		if sinksSaveSinks != "" {
			if err := saveSinksToCSV(sinkResults, sinksSaveSinks); err != nil {
				sinksLogger.Warn("failed to save sinks to file",
					"component", "sinks",
					"file", sinksSaveSinks,
					"error", err)
			} else {
				sinksLogger.Info("saved sinks to file",
					"component", "sinks",
					"file", sinksSaveSinks,
					"count", len(sinkResults))
			}
		}
	}

	if len(sinkResults) == 0 {
		sinksLogger.Info("no sinks found", "component", "sinks")
		return nil
	}

	// Step 2: Build or load call graph
	var callGraph *analysis.CallGraph
	var symbols []parser.Symbol

	if sinksLoadCallgraph != "" {
		// Load call graph from JSON file
		sinksLogger.Info("loading call graph from file",
			"component", "sinks",
			"file", sinksLoadCallgraph)
		symbols, err = loadSymbolsFromJSON(sinksLoadCallgraph)
		if err != nil {
			return fmt.Errorf("failed to load call graph from %s: %w", sinksLoadCallgraph, err)
		}
		callGraph = analysis.BuildCallGraph(symbols)
		sinksLogger.Info("loaded call graph",
			"component", "sinks",
			"symbols", len(symbols))
	} else {
		// Parse source code and build call graph
		sinksLogger.Info("building call graph",
			"component", "sinks",
			"source_directory", sinksSourceDir)

		analysisResult, err := parser.GetCachedAnalysisResult(sinksSourceDir)
		if err != nil {
			return fmt.Errorf("failed to parse source code: %w", err)
		}
		symbols = analysisResult.Symbols
		callGraph = analysis.BuildCallGraph(symbols)

		sinksLogger.Info("call graph built",
			"component", "sinks",
			"symbols", len(symbols))

		// Save call graph if requested
		if sinksSaveCallgraph != "" {
			if err := saveSymbolsToJSON(symbols, sinksSaveCallgraph); err != nil {
				sinksLogger.Warn("failed to save call graph to file",
					"component", "sinks",
					"file", sinksSaveCallgraph,
					"error", err)
			} else {
				sinksLogger.Info("saved call graph to file",
					"component", "sinks",
					"file", sinksSaveCallgraph,
					"symbols", len(symbols))
			}
		}
	}

	// Deduplicate sinks by function (same function may have multiple property accesses)
	uniqueSinks := deduplicateSinks(sinkResults)
	sinksLogger.Info("deduplicated sinks",
		"component", "sinks",
		"original", len(sinkResults),
		"unique", len(uniqueSinks))

	// Determine concurrency
	numWorkers := sinksConcurrency
	if numWorkers <= 0 {
		numWorkers = runtime.NumCPU()
		if numWorkers > 8 {
			numWorkers = 8
		}
	}

	// Process sinks in parallel, stream output as JSONL
	sinksLogger.Info("processing sinks",
		"component", "sinks",
		"workers", numWorkers,
		"call_depth", sinksCallDepth)

	// Create work channel
	type workItem struct {
		index int
		sink  codeql.SinkResult
	}

	workChan := make(chan workItem, len(uniqueSinks))

	// Set up output destination (file or stdout)
	var outputWriter *os.File
	if sinksOutput != "" {
		var err error
		outputWriter, err = os.Create(sinksOutput)
		if err != nil {
			return fmt.Errorf("failed to create output file %s: %w", sinksOutput, err)
		}
		defer outputWriter.Close()
		sinksLogger.Info("writing results to file",
			"component", "sinks",
			"file", sinksOutput)
	} else {
		outputWriter = os.Stdout
	}

	// Use mutex for thread-safe output writing
	var outputMutex sync.Mutex
	var wg sync.WaitGroup

	// Stats
	var processedCount, outputCount int
	var statsMutex sync.Mutex

	// Start workers
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()

			for item := range workChan {
				// Find reverse call chains
				chains := callGraph.FindReverseCallChains(
					item.sink.SinkFunc,
					item.sink.SinkFile,
					item.sink.SinkFuncDefLine,
					sinksCallDepth,
				)

				// Search for indicators in chains and find best chain
				var bestChain *analysis.ReverseCallChain
				var bestIndicators *analysis.ChainIndicators
				bestScore := 0

				for i := range chains {
					indicators := analysis.SearchChainIndicators(callGraph, chains[i])
					if indicators.TotalScore > bestScore {
						bestScore = indicators.TotalScore
						chainCopy := chains[i]
						bestChain = &chainCopy
						bestIndicators = &indicators
					}
				}

				// Filter by confidence if specified
				if sinksMinConfidence != "" && bestIndicators != nil {
					if sinksMinConfidence == "HIGH" && bestIndicators.OverallConfidence != "HIGH" {
						statsMutex.Lock()
						processedCount++
						statsMutex.Unlock()
						continue
					}
					if sinksMinConfidence == "MEDIUM" && bestIndicators.OverallConfidence == "LOW" {
						statsMutex.Lock()
						processedCount++
						statsMutex.Unlock()
						continue
					}
				}

				// Build finding
				finding := codeql.SinkFinding{
					Sink:       item.sink,
					CallChains: chains,
					BestChain:  bestChain,
					Indicators: bestIndicators,
				}

				// Output as JSONL (thread-safe)
				jsonBytes, err := json.Marshal(finding)
				if err != nil {
					sinksLogger.Warn("failed to marshal finding",
						"component", "sinks",
						"error", err)
					continue
				}

				outputMutex.Lock()
				fmt.Fprintln(outputWriter, string(jsonBytes))
				outputMutex.Unlock()

				statsMutex.Lock()
				processedCount++
				outputCount++
				statsMutex.Unlock()

				// Progress logging
				statsMutex.Lock()
				if processedCount%100 == 0 {
					sinksLogger.Info("progress",
						"component", "sinks",
						"processed", processedCount,
						"total", len(uniqueSinks),
						"output", outputCount)
				}
				statsMutex.Unlock()
			}
		}(w)
	}

	// Send work items
	for i, sink := range uniqueSinks {
		workChan <- workItem{index: i, sink: sink}
	}
	close(workChan)

	// Wait for completion
	wg.Wait()

	sinksLogger.Info("processing complete",
		"component", "sinks",
		"total_sinks", len(uniqueSinks),
		"findings_output", outputCount)

	return nil
}

// deduplicateSinks removes duplicate sinks (same function, file, line)
func deduplicateSinks(sinks []codeql.SinkResult) []codeql.SinkResult {
	seen := make(map[string]bool)
	var unique []codeql.SinkResult

	for _, sink := range sinks {
		key := fmt.Sprintf("%s:%s:%d", sink.SinkFunc, sink.SinkFile, sink.SinkFuncDefLine)
		if !seen[key] {
			seen[key] = true
			unique = append(unique, sink)
		}
	}

	return unique
}

// saveSinksToCSV saves sink results to a CSV file
func saveSinksToCSV(sinks []codeql.SinkResult, filename string) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	// Write header
	header := []string{"sink_func", "sink_file", "sink_func_def_ln", "sink_ln", "object", "key"}
	if err := writer.Write(header); err != nil {
		return err
	}

	// Write rows
	for _, sink := range sinks {
		row := []string{
			sink.SinkFunc,
			sink.SinkFile,
			strconv.Itoa(sink.SinkFuncDefLine),
			strconv.Itoa(sink.SinkLine),
			sink.Object,
			sink.Key,
		}
		if err := writer.Write(row); err != nil {
			return err
		}
	}

	return nil
}

// loadSinksFromCSV loads sink results from a CSV file
func loadSinksFromCSV(filename string) ([]codeql.SinkResult, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}

	if len(records) < 2 {
		return []codeql.SinkResult{}, nil
	}

	// Skip header row
	var sinks []codeql.SinkResult
	for i := 1; i < len(records); i++ {
		record := records[i]
		if len(record) < 6 {
			continue
		}

		sinkFuncDefLine, _ := strconv.Atoi(record[2])
		sinkLine, _ := strconv.Atoi(record[3])

		sink := codeql.SinkResult{
			SinkFunc:        record[0],
			SinkFile:        record[1],
			SinkFuncDefLine: sinkFuncDefLine,
			SinkLine:        sinkLine,
			Object:          record[4],
			Key:             record[5],
		}
		sinks = append(sinks, sink)
	}

	return sinks, nil
}

// saveSymbolsToJSON saves symbols to a JSON file for call graph reconstruction
func saveSymbolsToJSON(symbols []parser.Symbol, filename string) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	return encoder.Encode(symbols)
}

// loadSymbolsFromJSON loads symbols from a JSON file
func loadSymbolsFromJSON(filename string) ([]parser.Symbol, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var symbols []parser.Symbol
	decoder := json.NewDecoder(file)
	if err := decoder.Decode(&symbols); err != nil {
		return nil, err
	}

	return symbols, nil
}

func init() {
	sinksCmd.Flags().StringVarP(&sinksDatabase, "database", "d", "", "Path to CodeQL database (required when not using --load-sinks)")
	sinksCmd.Flags().StringVarP(&sinksQueryFile, "query", "q", "", "Path to CodeQL sink query file (.ql) (required when not using --load-sinks)")
	sinksCmd.Flags().StringVarP(&sinksSourceDir, "source", "s", "", "Path to source code directory (required when not using --load-callgraph)")
	sinksCmd.Flags().StringVarP(&sinksCodeqlBin, "codeql-bin", "b", "", "Path to CodeQL CLI binary (default: resolve from PATH)")
	sinksCmd.Flags().IntVarP(&sinksCallDepth, "call-depth", "c", 15, "Maximum call chain depth for reverse traversal")
	sinksCmd.Flags().IntVarP(&sinksConcurrency, "concurrency", "j", 0, "Number of concurrent workers (0 = auto-detect based on CPU cores)")
	sinksCmd.Flags().StringVar(&sinksMinConfidence, "min-confidence", "", "Minimum confidence level to output (HIGH, MEDIUM, or empty for all)")
	sinksCmd.Flags().StringVarP(&sinksOutput, "output", "o", "", "Output file for JSONL results (default: stdout)")

	// Save/load flags for caching
	sinksCmd.Flags().StringVar(&sinksSaveSinks, "save-sinks", "", "Save CodeQL sink results to CSV file")
	sinksCmd.Flags().StringVar(&sinksLoadSinks, "load-sinks", "", "Load sink results from CSV file (skip CodeQL query)")
	sinksCmd.Flags().StringVar(&sinksSaveCallgraph, "save-callgraph", "", "Save call graph symbols to JSON file")
	sinksCmd.Flags().StringVar(&sinksLoadCallgraph, "load-callgraph", "", "Load call graph symbols from JSON file (skip parsing)")

	rootCmd.AddCommand(sinksCmd)
}
