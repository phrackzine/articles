package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/spf13/cobra"
)

var (
	linesSource string
	linesRadius int
	linesExt    string
)

type lineRecord struct {
	ID     string `json:"id"`
	File   string `json:"file"`
	Line   int    `json:"line"`
	Target string `json:"target"`
	Window string `json:"window"`
}

var linesCmd = &cobra.Command{
	Use:   "lines",
	Short: "Emit JSONL line-window documents from source files",
	Long: `Recursively walks a source directory and emits one JSON object per rankable
source line. Each object includes the target line, real source line number,
relative file path, and a small surrounding context window.`,
	RunE: func(cmd *cobra.Command, args []string) error {
		if linesSource == "" {
			return fmt.Errorf("source directory is required (use --source)")
		}
		if linesRadius < 0 {
			return fmt.Errorf("radius must be >= 0")
		}

		info, err := os.Stat(linesSource)
		if err != nil {
			return fmt.Errorf("failed to stat source directory: %w", err)
		}
		if !info.IsDir() {
			return fmt.Errorf("source must be a directory: %s", linesSource)
		}

		exts, err := parseLineExtensions(linesExt)
		if err != nil {
			return err
		}

		files, err := collectLineFiles(linesSource, exts)
		if err != nil {
			return err
		}

		encoder := json.NewEncoder(os.Stdout)
		for _, file := range files {
			if err := emitLineRecords(encoder, linesSource, file, linesRadius); err != nil {
				return err
			}
		}

		return nil
	},
}

func parseLineExtensions(raw string) (map[string]struct{}, error) {
	exts := make(map[string]struct{})
	for _, part := range strings.Split(raw, ",") {
		ext := strings.TrimSpace(part)
		if ext == "" {
			continue
		}
		if !strings.HasPrefix(ext, ".") {
			ext = "." + ext
		}
		exts[ext] = struct{}{}
	}
	if len(exts) == 0 {
		return nil, fmt.Errorf("ext must include at least one extension")
	}
	return exts, nil
}

func collectLineFiles(source string, exts map[string]struct{}) ([]string, error) {
	var files []string
	if err := filepath.WalkDir(source, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() || !d.Type().IsRegular() {
			return nil
		}
		if _, ok := exts[filepath.Ext(path)]; !ok {
			return nil
		}
		rel, err := filepath.Rel(source, path)
		if err != nil {
			return err
		}
		files = append(files, filepath.ToSlash(rel))
		return nil
	}); err != nil {
		return nil, fmt.Errorf("failed to walk source directory: %w", err)
	}
	sort.Strings(files)
	return files, nil
}

func emitLineRecords(encoder *json.Encoder, source, relFile string, radius int) error {
	path := filepath.Join(source, filepath.FromSlash(relFile))
	data, err := os.ReadFile(path)
	if err != nil {
		return fmt.Errorf("failed to read %s: %w", relFile, err)
	}

	lines := splitSourceLines(data)
	for i, line := range lines {
		lineNumber := i + 1
		if skipLine(line) {
			continue
		}

		record := lineRecord{
			ID:     fmt.Sprintf("%s:%d", relFile, lineNumber),
			File:   relFile,
			Line:   lineNumber,
			Target: line,
			Window: renderLineWindow(lines, i, radius),
		}
		if err := encoder.Encode(record); err != nil {
			return fmt.Errorf("failed to encode record %s: %w", record.ID, err)
		}
	}

	return nil
}

func splitSourceLines(data []byte) []string {
	if len(data) == 0 {
		return nil
	}

	lines := strings.Split(string(data), "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	for i := range lines {
		lines[i] = strings.TrimSuffix(lines[i], "\r")
	}
	return lines
}

func skipLine(line string) bool {
	trimmed := strings.TrimSpace(line)
	if trimmed == "" {
		return true
	}
	switch trimmed {
	case "{", "}", "};", ";":
		return true
	}
	if strings.HasPrefix(trimmed, "//") {
		return true
	}
	return strings.HasPrefix(trimmed, "/*") && strings.HasSuffix(trimmed, "*/")
}

func renderLineWindow(lines []string, targetIndex, radius int) string {
	start := targetIndex - radius
	if start < 0 {
		start = 0
	}
	end := targetIndex + radius + 1
	if end > len(lines) {
		end = len(lines)
	}

	width := len(fmt.Sprintf("%d", end))
	var builder strings.Builder
	for i := start; i < end; i++ {
		if i > start {
			builder.WriteByte('\n')
		}
		marker := " "
		if i == targetIndex {
			marker = ">"
		}
		fmt.Fprintf(&builder, "%*d%s %s", width, i+1, marker, lines[i])
	}
	return builder.String()
}

func init() {
	linesCmd.Flags().StringVarP(&linesSource, "source", "s", "", "Source directory (required)")
	linesCmd.Flags().IntVarP(&linesRadius, "radius", "r", 3, "Number of context lines before and after target line")
	linesCmd.Flags().StringVar(&linesExt, "ext", ".c,.h", "Comma-separated file extensions to include")
	_ = linesCmd.MarkFlagRequired("source")

	rootCmd.AddCommand(linesCmd)
}
