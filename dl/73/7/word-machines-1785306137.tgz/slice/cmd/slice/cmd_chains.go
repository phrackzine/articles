package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"

	"github.com/spf13/cobra"
	"github.com/noperator/slice/pkg/analysis"
	"github.com/noperator/slice/pkg/codeql"
	"github.com/noperator/slice/pkg/logging"
	"github.com/noperator/slice/pkg/parser"
)

var (
	chainsLoadSinks      string
	chainsLoadCallgraph  string
	chainsCallDepth      int
	chainsConcurrency    int
	chainsOutput         string
	chainsFilter         bool   // Enable filtering by patterns
	chainsFilterPatterns string // Comma-separated regex patterns (overrides defaults)
)

// Default network indicator patterns
var defaultFilterPatterns = []string{
	"body",
	"decod",
	"deserializ",
	`\bform[^a]`,  // form but not format (formdata, forms, etc. ok)
	"input",
	"multi.?part",
	"pars",
	"payload",
	"unmarshal",
}

var chainsLogger *slog.Logger

// PatternMatch represents a single match of a pattern in a function definition
type PatternMatch struct {
	Term  string `json:"term"`
	Match string `json:"match"`
}

// ChainFunction represents a function in a call chain with its definition
type ChainFunction struct {
	Name       string         `json:"name"`
	File       string         `json:"file"`
	StartLine  int            `json:"start_line"`
	EndLine    int            `json:"end_line"`
	Definition string         `json:"definition"`
	Matches    []PatternMatch `json:"matches,omitempty"`
}

// SinkInstance represents a single sink occurrence (object, key, line, snippet)
type SinkInstance struct {
	Line    int    `json:"line"`
	Object  string `json:"object"`
	Key     string `json:"key"`
	Snippet string `json:"snippet,omitempty"`
}

// SinkInfo contains the function-level sink info plus all instances
type SinkInfo struct {
	SinkFunc    string         `json:"sink_func"`
	SinkFile    string         `json:"sink_file"`
	SinkFuncDef int            `json:"sink_func_def"`
	Sinks       []SinkInstance `json:"sinks"`
}

// ChainOutput is a single call chain (array of functions from caller to sink)
type ChainOutput struct {
	Sink  SinkInfo        `json:"sink"`
	Chain []ChainFunction `json:"chain"`
}

var chainsCmd = &cobra.Command{
	Use:   "chains",
	Short: "Build reverse call chains from sinks with function definitions",
	Long: `For each sink from CodeQL results, find all call chains that terminate at that sink.
Output each chain as JSONL - one line per chain, containing an ordered array of functions
from the outermost caller down to the sink function.

Each function includes file, name, line numbers, and the full definition text.

With --filter, chains are trimmed to start at the first function matching network indicator
patterns. Each function includes a 'matches' array showing which patterns matched and the
matching lines from the definition.

Example:
  slice chains --load-sinks ./sinks.csv --load-callgraph ./callgraph.json -o chains.jsonl
  slice chains --load-sinks ./sinks.csv --load-callgraph ./callgraph.json --filter -o filtered.jsonl`,
	RunE: func(cmd *cobra.Command, args []string) error {
		chainsLogger = logging.NewLoggerFromEnv()

		if chainsLoadSinks == "" {
			return fmt.Errorf("--load-sinks is required")
		}
		if chainsLoadCallgraph == "" {
			return fmt.Errorf("--load-callgraph is required")
		}

		return runChainsCommand()
	},
}

// findMatches searches a definition (with line numbers) for pattern matches and returns them
func findMatches(definitionWithLineNumbers string, patterns []*regexp.Regexp, patternNames []string) []PatternMatch {
	var matches []PatternMatch
	lines := strings.Split(definitionWithLineNumbers, "\n")

	for i, pattern := range patterns {
		for _, line := range lines {
			if pattern.MatchString(strings.ToLower(line)) {
				// Keep the full line including line number prefix
				matches = append(matches, PatternMatch{
					Term:  patternNames[i],
					Match: line,
				})
			}
		}
	}

	return matches
}

func runChainsCommand() error {
	// Load sinks from CSV
	chainsLogger.Info("loading sinks from file",
		"component", "chains",
		"file", chainsLoadSinks)
	sinkResults, err := loadChainsFromCSV(chainsLoadSinks)
	if err != nil {
		return fmt.Errorf("failed to load sinks: %w", err)
	}
	chainsLogger.Info("loaded sinks",
		"component", "chains",
		"count", len(sinkResults))

	if len(sinkResults) == 0 {
		chainsLogger.Info("no sinks found", "component", "chains")
		return nil
	}

	// Load call graph
	chainsLogger.Info("loading call graph from file",
		"component", "chains",
		"file", chainsLoadCallgraph)
	symbols, err := loadChainsSymbolsFromJSON(chainsLoadCallgraph)
	if err != nil {
		return fmt.Errorf("failed to load call graph: %w", err)
	}
	callGraph := analysis.BuildCallGraph(symbols)
	chainsLogger.Info("loaded call graph",
		"component", "chains",
		"symbols", len(symbols))

	// Build symbol lookup map for getting definitions
	symbolMap := make(map[string]*parser.Symbol)
	for i := range symbols {
		key := fmt.Sprintf("%s:%s:%d", symbols[i].Name, symbols[i].Filename, symbols[i].StartLine)
		symbolMap[key] = &symbols[i]
	}

	// Compile filter patterns if filtering is enabled
	var patterns []*regexp.Regexp
	var patternNames []string
	if chainsFilter {
		if chainsFilterPatterns != "" {
			patternNames = strings.Split(chainsFilterPatterns, ",")
		} else {
			patternNames = defaultFilterPatterns
		}

		for _, p := range patternNames {
			p = strings.TrimSpace(p)
			re, err := regexp.Compile("(?i)" + p) // case-insensitive
			if err != nil {
				return fmt.Errorf("invalid pattern %q: %w", p, err)
			}
			patterns = append(patterns, re)
		}
		chainsLogger.Info("filtering enabled",
			"component", "chains",
			"patterns", len(patterns))
	}

	// Group sinks by function (sink_func:sink_file:sink_func_def_line)
	// and collect all sink instances for each function
	type sinkGroup struct {
		SinkFunc    string
		SinkFile    string
		SinkFuncDef int
		Instances   []SinkInstance
	}
	sinkGroups := make(map[string]*sinkGroup)
	for _, sink := range sinkResults {
		key := fmt.Sprintf("%s:%s:%d", sink.SinkFunc, sink.SinkFile, sink.SinkFuncDefLine)
		if _, exists := sinkGroups[key]; !exists {
			sinkGroups[key] = &sinkGroup{
				SinkFunc:    sink.SinkFunc,
				SinkFile:    sink.SinkFile,
				SinkFuncDef: sink.SinkFuncDefLine,
				Instances:   []SinkInstance{},
			}
		}
		sinkGroups[key].Instances = append(sinkGroups[key].Instances, SinkInstance{
			Line:   sink.SinkLine,
			Object: sink.Object,
			Key:    sink.Key,
		})
	}
	chainsLogger.Info("grouped sinks by function",
		"component", "chains",
		"original", len(sinkResults),
		"unique_functions", len(sinkGroups))

	// Set up output
	var outputWriter *os.File
	if chainsOutput != "" {
		outputWriter, err = os.Create(chainsOutput)
		if err != nil {
			return fmt.Errorf("failed to create output file: %w", err)
		}
		defer outputWriter.Close()
		chainsLogger.Info("writing to file", "component", "chains", "file", chainsOutput)
	} else {
		outputWriter = os.Stdout
	}

	// Determine concurrency
	numWorkers := chainsConcurrency
	if numWorkers <= 0 {
		numWorkers = runtime.NumCPU()
		if numWorkers > 8 {
			numWorkers = 8
		}
	}

	chainsLogger.Info("processing sinks",
		"component", "chains",
		"workers", numWorkers,
		"call_depth", chainsCallDepth,
		"filter", chainsFilter)

	// Work channel
	type workItem struct {
		group *sinkGroup
	}
	workChan := make(chan workItem, len(sinkGroups))

	// Collect unique outputs (deduplicate by JSON string)
	seenOutputs := make(map[string]bool)
	var outputMutex sync.Mutex
	var wg sync.WaitGroup
	var processedCount, chainCount, filteredCount, duplicateCount int
	var statsMutex sync.Mutex

	// Start workers
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			for item := range workChan {
				group := item.group

				// Find reverse call chains to this sink function
				chains := callGraph.FindReverseCallChains(
					group.SinkFunc,
					group.SinkFile,
					group.SinkFuncDef,
					chainsCallDepth,
				)

				// For each chain, build the output with function definitions
				for _, chain := range chains {
					chainFuncs := make([]ChainFunction, 0, len(chain.Chain))

					for _, loc := range chain.Chain {
						// Look up symbol to get definition
						key := fmt.Sprintf("%s:%s:%d", loc.Name, loc.File, loc.Line)
						sym := symbolMap[key]

						cf := ChainFunction{
							Name:      loc.Name,
							File:      loc.File,
							StartLine: loc.Line,
						}

						if sym != nil {
							cf.Definition = sym.DefinitionWithLineNumbers
							cf.EndLine = sym.EndLine

							// Find matches if filtering is enabled (match on definition with line numbers)
							if chainsFilter {
								cf.Matches = findMatches(sym.DefinitionWithLineNumbers, patterns, patternNames)
							}
						}

						chainFuncs = append(chainFuncs, cf)
					}

					// If filtering, trim chain to start at first matching function
					if chainsFilter {
						startIdx := -1
						for i, cf := range chainFuncs {
							if len(cf.Matches) > 0 {
								startIdx = i
								break
							}
						}

						// Skip this chain if no matches found
						if startIdx == -1 {
							statsMutex.Lock()
							filteredCount++
							statsMutex.Unlock()
							continue
						}

						// Trim chain to start at first match
						chainFuncs = chainFuncs[startIdx:]
					}

					output := ChainOutput{
						Sink: SinkInfo{
							SinkFunc:    group.SinkFunc,
							SinkFile:    group.SinkFile,
							SinkFuncDef: group.SinkFuncDef,
							Sinks:       group.Instances,
						},
						Chain: chainFuncs,
					}

					jsonBytes, err := json.Marshal(output)
					if err != nil {
						continue
					}

					jsonStr := string(jsonBytes)

					outputMutex.Lock()
					if !seenOutputs[jsonStr] {
						seenOutputs[jsonStr] = true
						fmt.Fprintln(outputWriter, jsonStr)
						statsMutex.Lock()
						chainCount++
						statsMutex.Unlock()
					} else {
						statsMutex.Lock()
						duplicateCount++
						statsMutex.Unlock()
					}
					outputMutex.Unlock()
				}

				statsMutex.Lock()
				processedCount++
				if processedCount%100 == 0 {
					chainsLogger.Info("progress",
						"component", "chains",
						"sinks_processed", processedCount,
						"total_sinks", len(sinkGroups),
						"chains_output", chainCount,
						"duplicates_skipped", duplicateCount,
						"filtered_out", filteredCount)
				}
				statsMutex.Unlock()
			}
		}()
	}

	// Send work
	for _, group := range sinkGroups {
		workChan <- workItem{group: group}
	}
	close(workChan)

	wg.Wait()

	chainsLogger.Info("complete",
		"component", "chains",
		"sinks_processed", processedCount,
		"chains_output", chainCount,
		"duplicates_skipped", duplicateCount,
		"filtered_out", filteredCount)

	return nil
}

func loadChainsFromCSV(filename string) ([]codeql.SinkResult, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}

	if len(records) < 2 {
		return []codeql.SinkResult{}, nil
	}

	var sinks []codeql.SinkResult
	for i := 1; i < len(records); i++ {
		record := records[i]
		if len(record) < 6 {
			continue
		}

		sinkFuncDefLine, _ := strconv.Atoi(record[2])
		sinkLine, _ := strconv.Atoi(record[3])

		sink := codeql.SinkResult{
			SinkFunc:        record[0],
			SinkFile:        record[1],
			SinkFuncDefLine: sinkFuncDefLine,
			SinkLine:        sinkLine,
			Object:          record[4],
			Key:             record[5],
		}
		sinks = append(sinks, sink)
	}

	return sinks, nil
}

func loadChainsSymbolsFromJSON(filename string) ([]parser.Symbol, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var symbols []parser.Symbol
	decoder := json.NewDecoder(file)
	if err := decoder.Decode(&symbols); err != nil {
		return nil, err
	}

	return symbols, nil
}

func init() {
	chainsCmd.Flags().StringVar(&chainsLoadSinks, "load-sinks", "", "Load sink results from CSV file (required)")
	chainsCmd.Flags().StringVar(&chainsLoadCallgraph, "load-callgraph", "", "Load call graph from JSON file (required)")
	chainsCmd.Flags().IntVarP(&chainsCallDepth, "call-depth", "c", 10, "Maximum call chain depth")
	chainsCmd.Flags().IntVarP(&chainsConcurrency, "concurrency", "j", 0, "Number of workers (0 = auto)")
	chainsCmd.Flags().StringVarP(&chainsOutput, "output", "o", "", "Output file (default: stdout)")
	chainsCmd.Flags().BoolVar(&chainsFilter, "filter", false, "Filter chains by network indicator patterns")
	chainsCmd.Flags().StringVar(&chainsFilterPatterns, "patterns", "", "Comma-separated regex patterns (default: built-in network indicators)")

	rootCmd.AddCommand(chainsCmd)
}
