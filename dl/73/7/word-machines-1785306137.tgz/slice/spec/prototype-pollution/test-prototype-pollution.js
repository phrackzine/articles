/**
 * Test cases for prototype pollution CodeQL query
 *
 * Run with:
 *   codeql database create test-db --language=javascript --source-root=spec/prototype-pollution
 *   codeql query run spec/prototype-pollution/query.ql --database=test-db
 */

// =============================================================================
// SHOULD FIND (Vulnerable patterns)
// =============================================================================

// Test case 1: Basic JSON.parse to bracket access
function vulnerableBasic(userInput) {
  const parsed = JSON.parse(userInput);  // Deserialization source
  const obj = getObject();
  return obj[parsed.key];  // Unsafe property access - NO hasOwnProperty check
}

// Test case 2: React-like pattern - nested index access
const NAME = 2;
function requireModule(metadata) {
  const moduleExports = require(metadata.id);
  return moduleExports[metadata[NAME]];  // Vulnerable - matches CVE-2025-55182 pattern
}

// Test case 3: Decode function to bracket access
function vulnerableDecode(data) {
  const decoded = decodePayload(data);  // Matches decode* pattern
  const target = {};
  return target[decoded.prop];  // Unsafe access
}

// Test case 4: Parse function to bracket access
function vulnerableParse(input) {
  const result = parseMessage(input);  // Matches parse* pattern
  const config = getConfig();
  return config[result.name];  // Unsafe access
}

// Test case 5: Deserialize function
function vulnerableDeserialize(buffer) {
  const obj = deserializeData(buffer);
  const registry = getRegistry();
  return registry[obj.key];  // Unsafe access
}

// Test case 6: Chained property access leading to bracket notation
function vulnerableChained(userInput) {
  const parsed = JSON.parse(userInput);
  const obj = getObject();
  const key = parsed.nested.deep.value;
  return obj[key];  // Taint should flow through property chain
}

// =============================================================================
// SHOULD NOT FIND (Safe patterns)
// =============================================================================

// Test case 7: Safe - has hasOwnProperty check
function safeWithHasOwn(userInput) {
  const parsed = JSON.parse(userInput);
  const obj = getObject();

  if (Object.prototype.hasOwnProperty.call(obj, parsed.key)) {
    return obj[parsed.key];
  }
  return undefined;
}

// Test case 8: Safe - has Object.hasOwn check
function safeWithObjectHasOwn(userInput) {
  const parsed = JSON.parse(userInput);
  const obj = getObject();

  if (Object.hasOwn(obj, parsed.key)) {
    return obj[parsed.key];
  }
  return undefined;
}

// Test case 9: Safe - literal key
function safeLiteralAccess(userInput) {
  const parsed = JSON.parse(userInput);
  const obj = getObject();
  return obj["safeKey"];  // Safe - literal key, not user-controlled
}

// Test case 10: Safe - numeric literal index
function safeNumericAccess(userInput) {
  const parsed = JSON.parse(userInput);
  const arr = getArray();
  return arr[0];  // Safe - numeric literal
}

// Test case 11: Safe - checked against specific value (barrier)
function safeWithValueCheck(userInput) {
  const parsed = JSON.parse(userInput);
  const obj = getObject();

  // Check against '*' is a barrier in React pattern
  if (parsed.key === '*') {
    return obj;
  }
  if (parsed.key === '') {
    return obj.default;
  }
  return obj[parsed.key];  // Still unsafe if not covered by checks above
}

// =============================================================================
// EDGE CASES
// =============================================================================

// Test case 12: Multiple nested accesses (React pattern simulation)
const ID = 0;
const CHUNKS = 1;
function resolveClientReference(bundlerConfig, metadata) {
  if (bundlerConfig) {
    const moduleExports = bundlerConfig[metadata[ID]];  // First access
    let resolvedModuleData = moduleExports && moduleExports[metadata[NAME]];  // Second access - VULNERABLE
    // ...
    return resolvedModuleData;
  }
  return metadata;
}

// Test case 13: FormData source
function vulnerableFormData(request) {
  const formData = new FormData(request.body);
  const obj = getObject();
  const key = formData.get('key');
  return obj[key];  // Vulnerable - FormData is a source
}

// Stub functions for testing
function getObject() { return {}; }
function getArray() { return []; }
function getConfig() { return {}; }
function getRegistry() { return {}; }
function decodePayload(d) { return d; }
function parseMessage(m) { return m; }
function deserializeData(b) { return b; }
