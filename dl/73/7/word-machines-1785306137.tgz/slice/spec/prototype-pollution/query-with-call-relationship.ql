/**
 * @name Prototype Pollution Detection (with call relationship)
 * @description Detects deserialization sources and unsafe property access sinks that could lead to prototype pollution
 * @kind problem
 * @id js/prototype-pollution
 * @tags security
 * @problem.severity warning
 */

import javascript

//-----------------------------------------------------------------------------
// SOURCES - Deserialization / Network Input
//-----------------------------------------------------------------------------

/**
 * Deserialization and parsing function calls that produce user-controlled data
 * Broadly matches anything that looks like it could deserialize or receive network data
 */
class DeserializationSource extends Expr {
  DeserializationSource() {
    // JSON.parse()
    exists(MethodCallExpr mce |
      mce = this and
      mce.getMethodName() = "parse" and
      mce.getReceiver().(VarAccess).getName() = "JSON"
    )
    or
    // Function calls matching deserialization/parsing patterns
    exists(CallExpr call |
      call = this and
      call.getCalleeName().regexpMatch(".*([Pp]arse|[Dd]ecode|[Dd]eserialize|[Rr]evive|[Uu]npack|[Uu]nmarshal|[Ii]nflate|[Ff]romJSON|[Rr]ead[A-Z].*|[Ll]oad[A-Z].*|[Ff]etch|[Rr]eceive|[Gg]et[A-Z].*[Dd]ata|createResponse|getRoot|resolveField).*")
    )
    or
    // FormData - common source in web apps
    exists(NewExpr ne |
      ne = this and
      ne.getCalleeName() = "FormData"
    )
    or
    // Request body / params access patterns
    exists(PropAccess pa |
      pa = this and
      pa.getPropertyName().regexpMatch("body|params|query|data|payload|content|formData|json")
    )
  }
}

//-----------------------------------------------------------------------------
// SINKS - Unsafe Property Access
//-----------------------------------------------------------------------------

/**
 * Check if a property access is guarded by hasOwnProperty or Object.hasOwn
 */
predicate hasPropertyCheck(IndexExpr access) {
  exists(MethodCallExpr check, IfStmt ifStmt |
    (
      // obj.hasOwnProperty(key)
      check.getMethodName() = "hasOwnProperty"
      or
      // Object.hasOwn(obj, key)
      check.getMethodName() = "hasOwn"
      or
      // Object.prototype.hasOwnProperty.call(obj, key)
      (check.getMethodName() = "call" and
       check.getReceiver().(PropAccess).getPropertyName() = "hasOwnProperty")
    ) and
    // The check is in an if condition that guards the access
    ifStmt.getCondition().getAChildExpr*() = check and
    ifStmt.getThen().getAChildExpr*() = access
  )
}

/**
 * Unsafe property access using bracket notation with dynamic key
 * Pattern: obj[key] where key is not a literal and not guarded by hasOwnProperty
 */
class UnsafePropertyAccess extends IndexExpr {
  UnsafePropertyAccess() {
    // Key is not a string/number literal (dynamic)
    not this.getPropertyNameExpr() instanceof StringLiteral and
    not this.getPropertyNameExpr() instanceof NumberLiteral and
    // No hasOwnProperty check guarding this access
    not hasPropertyCheck(this)
  }
}

//-----------------------------------------------------------------------------
// CALL RELATIONSHIP
//-----------------------------------------------------------------------------

/**
 * Direct call: function f1 contains a call to function f2
 */
predicate directlyCallsFunction(Function caller, Function callee) {
  exists(CallExpr call |
    call.getEnclosingFunction() = caller and
    call.getCallee().(Function) = callee
  )
  or
  exists(CallExpr call, VarAccess va |
    call.getEnclosingFunction() = caller and
    call.getCallee() = va and
    va.getVariable().getAnAssignedExpr().(Function) = callee
  )
}

/**
 * Transitive call relationship (up to 5 hops to catch longer chains like React CVE)
 */
predicate callsTransitive(Function f1, Function f2) {
  directlyCallsFunction(f1, f2)
  or
  exists(Function mid |
    directlyCallsFunction(f1, mid) and
    directlyCallsFunction(mid, f2)
  )
  or
  exists(Function mid1, Function mid2 |
    directlyCallsFunction(f1, mid1) and
    directlyCallsFunction(mid1, mid2) and
    directlyCallsFunction(mid2, f2)
  )
  or
  exists(Function mid1, Function mid2, Function mid3 |
    directlyCallsFunction(f1, mid1) and
    directlyCallsFunction(mid1, mid2) and
    directlyCallsFunction(mid2, mid3) and
    directlyCallsFunction(mid3, f2)
  )
  or
  exists(Function mid1, Function mid2, Function mid3, Function mid4 |
    directlyCallsFunction(f1, mid1) and
    directlyCallsFunction(mid1, mid2) and
    directlyCallsFunction(mid2, mid3) and
    directlyCallsFunction(mid3, mid4) and
    directlyCallsFunction(mid4, f2)
  )
}

/**
 * Check if two functions are related through calls
 * Example: func1() calls func2(), or both are called by a common parent
 */
predicate functionsRelated(Function f1, Function f2) {
  // Same function
  f1 = f2
  or
  // f1 can reach f2 through calls
  callsTransitive(f1, f2)
  or
  // f2 can reach f1 through calls
  callsTransitive(f2, f1)
  or
  // Share a common caller (siblings in call graph)
  exists(Function parent |
    callsTransitive(parent, f1) and callsTransitive(parent, f2)
  )
}

//-----------------------------------------------------------------------------
// HELPER FUNCTIONS
//-----------------------------------------------------------------------------

string getObjectName(IndexExpr ie) {
  result = ie.getBase().toString()
}

string getFunctionName(Function f) {
  if exists(f.getName()) and f.getName() != ""
  then result = f.getName()
  else result = "<anonymous>"
}

/**
 * Extract the top-level package name from a path
 * e.g., "react-server-dom-webpack/src/server/Foo.js" -> "react-server-dom-webpack"
 */
string getPackageName(File f) {
  exists(string path | path = f.getRelativePath() |
    // Get the first path component (package name)
    result = path.regexpCapture("^([^/]+)/.*", 1)
  )
}

//-----------------------------------------------------------------------------
// MAIN QUERY - Find source/sink pairs with call relationship
//-----------------------------------------------------------------------------

from DeserializationSource source, UnsafePropertyAccess access,
     Function deserFunc, Function accessFunc,
     string objName,
     string dfName, string dfFile, int dfDefLine, int deserLine,
     string afName, string afFile, int afDefLine, int accessLine
where
  // Get functions containing source and sink
  deserFunc = source.getEnclosingFunction() and
  accessFunc = access.getEnclosingFunction() and

  // Functions must be related through calls
  functionsRelated(deserFunc, accessFunc) and

  // Constraint: same package OR both in react-server-dom-* packages
  // This allows cross-file patterns within related code
  (
    // Same package
    getPackageName(deserFunc.getFile()) = getPackageName(accessFunc.getFile())
    or
    // Both in react-server-dom-* packages (they're related)
    getPackageName(deserFunc.getFile()).matches("react-server-dom-%") and
    getPackageName(accessFunc.getFile()).matches("react-server-dom-%")
    or
    // Same file (always include)
    deserFunc.getFile() = accessFunc.getFile()
  ) and

  // Get source (deserialization) details
  dfName = getFunctionName(deserFunc) and
  dfFile = deserFunc.getFile().getRelativePath() and
  dfDefLine = deserFunc.getLocation().getStartLine() and
  deserLine = source.getLocation().getStartLine() and

  // Get sink (property access) details
  objName = getObjectName(access) and
  afName = getFunctionName(accessFunc) and
  afFile = accessFunc.getFile().getRelativePath() and
  afDefLine = accessFunc.getLocation().getStartLine() and
  accessLine = access.getLocation().getStartLine()

select access, "Potential prototype pollution: " + objName + "[...] with dynamic key",
       objName as object,
       dfName as deser_func,
       dfFile as deser_file,
       dfDefLine as deser_func_def_ln,
       deserLine as deser_ln,
       afName as access_func,
       afFile as access_file,
       afDefLine as access_func_def_ln,
       accessLine as access_ln
