/**
 * @name Prototype Pollution Detection
 * @description Detects deserialization sources and unsafe property access sinks that could lead to prototype pollution
 * @kind problem
 * @id js/prototype-pollution
 * @tags security
 * @problem.severity warning
 */

import javascript

//-----------------------------------------------------------------------------
// SOURCES - Deserialization / Network Input
//-----------------------------------------------------------------------------

/**
 * Deserialization and parsing function calls that produce user-controlled data
 * Broadly matches anything that looks like it could deserialize or receive network data
 */
class DeserializationSource extends Expr {
  DeserializationSource() {
    // JSON.parse()
    exists(MethodCallExpr mce |
      mce = this and
      mce.getMethodName() = "parse" and
      mce.getReceiver().(VarAccess).getName() = "JSON"
    )
    or
    // Function calls matching deserialization/parsing patterns
    exists(CallExpr call |
      call = this and
      call.getCalleeName().regexpMatch(".*([Pp]arse|[Dd]ecode|[Dd]eserialize|[Rr]evive|[Uu]npack|[Uu]nmarshal|[Ii]nflate|[Ff]romJSON|[Rr]ead[A-Z].*|[Ll]oad[A-Z].*|[Ff]etch|[Rr]eceive|[Gg]et[A-Z].*[Dd]ata|createResponse|getRoot|resolveField).*")
    )
    or
    // FormData - common source in web apps
    exists(NewExpr ne |
      ne = this and
      ne.getCalleeName() = "FormData"
    )
    or
    // Request body / params access patterns
    exists(PropAccess pa |
      pa = this and
      pa.getPropertyName().regexpMatch("body|params|query|data|payload|content|formData|json")
    )
  }
}

//-----------------------------------------------------------------------------
// SINKS - Unsafe Property Access
//-----------------------------------------------------------------------------

/**
 * Check if a property access is guarded by hasOwnProperty or Object.hasOwn
 */
predicate hasPropertyCheck(IndexExpr access) {
  exists(MethodCallExpr check, IfStmt ifStmt |
    (
      // obj.hasOwnProperty(key)
      check.getMethodName() = "hasOwnProperty"
      or
      // Object.hasOwn(obj, key)
      check.getMethodName() = "hasOwn"
      or
      // Object.prototype.hasOwnProperty.call(obj, key)
      (check.getMethodName() = "call" and
       check.getReceiver().(PropAccess).getPropertyName() = "hasOwnProperty")
    ) and
    // The check is in an if condition that guards the access
    ifStmt.getCondition().getAChildExpr*() = check and
    ifStmt.getThen().getAChildExpr*() = access
  )
}

/**
 * Unsafe property access using bracket notation with dynamic key
 * Pattern: obj[key] where key is not a literal and not guarded by hasOwnProperty
 */
class UnsafePropertyAccess extends IndexExpr {
  UnsafePropertyAccess() {
    // Key is not a string/number literal (dynamic)
    not this.getPropertyNameExpr() instanceof StringLiteral and
    not this.getPropertyNameExpr() instanceof NumberLiteral and
    // No hasOwnProperty check guarding this access
    not hasPropertyCheck(this)
  }
}


//-----------------------------------------------------------------------------
// HELPER FUNCTIONS
//-----------------------------------------------------------------------------

string getObjectName(IndexExpr ie) {
  result = ie.getBase().toString()
}

string getFunctionName(Function f) {
  if exists(f.getName()) and f.getName() != ""
  then result = f.getName()
  else result = "<anonymous>"
}

/**
 * Extract the top-level package name from a path
 * e.g., "react-server-dom-webpack/src/server/Foo.js" -> "react-server-dom-webpack"
 */
string getPackageName(File f) {
  exists(string path | path = f.getRelativePath() |
    // Get the first path component (package name)
    result = path.regexpCapture("^([^/]+)/.*", 1)
  )
}

//-----------------------------------------------------------------------------
// MAIN QUERY - Find source/sink pairs in same or related packages
// AI triage will validate actual data flow between source and sink
//-----------------------------------------------------------------------------

from DeserializationSource source, UnsafePropertyAccess access,
     Function deserFunc, Function accessFunc,
     string objName,
     string dfName, string dfFile, int dfDefLine, int deserLine,
     string afName, string afFile, int afDefLine, int accessLine
where
  // Get functions containing source and sink
  deserFunc = source.getEnclosingFunction() and
  accessFunc = access.getEnclosingFunction() and

  // Exclude test files - they add noise and slow down enrichment
  not deserFunc.getFile().getRelativePath().matches("%__tests__%") and
  not accessFunc.getFile().getRelativePath().matches("%__tests__%") and
  not deserFunc.getFile().getRelativePath().matches("%-test.js") and
  not accessFunc.getFile().getRelativePath().matches("%-test.js") and

  // Exclude same-function pairs (recursive calls) - not useful for prototype pollution
  not (dfName = afName and dfFile = afFile) and

  // Exclude specific slow/noisy functions from react-devtools
  not dfName = "_handleMouseMove" and
  not afName = "_handleMouseMove" and

  // Constraint: same package OR both in react-server-dom-* packages
  // This allows cross-file patterns within related code
  (
    // Same package
    getPackageName(deserFunc.getFile()) = getPackageName(accessFunc.getFile())
    or
    // Both in react-server-dom-* packages (they're related)
    getPackageName(deserFunc.getFile()).matches("react-server-dom-%") and
    getPackageName(accessFunc.getFile()).matches("react-server-dom-%")
    or
    // Same file (always include)
    deserFunc.getFile() = accessFunc.getFile()
  ) and

  // Get source (deserialization) details
  dfName = getFunctionName(deserFunc) and
  dfFile = deserFunc.getFile().getRelativePath() and
  dfDefLine = deserFunc.getLocation().getStartLine() and
  deserLine = source.getLocation().getStartLine() and

  // Get sink (property access) details
  objName = getObjectName(access) and
  afName = getFunctionName(accessFunc) and
  afFile = accessFunc.getFile().getRelativePath() and
  afDefLine = accessFunc.getLocation().getStartLine() and
  accessLine = access.getLocation().getStartLine()

select access, "Potential prototype pollution: " + objName + "[...] with dynamic key",
       objName as object,
       dfName as free_func,
       dfFile as free_file,
       dfDefLine as free_func_def_ln,
       deserLine as free_ln,
       afName as use_func,
       afFile as use_file,
       afDefLine as use_func_def_ln,
       accessLine as use_ln
