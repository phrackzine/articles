/**
 * @name Prototype Pollution Sinks
 * @description Finds unsafe property access patterns that could be prototype pollution sinks
 * @kind problem
 * @id js/prototype-pollution-sinks
 * @tags security
 * @problem.severity warning
 */

import javascript

//-----------------------------------------------------------------------------
// SINKS - Unsafe Property Access (bracket notation with dynamic key)
//-----------------------------------------------------------------------------

/**
 * Check if a property access is guarded by hasOwnProperty or Object.hasOwn
 */
predicate hasPropertyCheck(IndexExpr access) {
  exists(MethodCallExpr check, IfStmt ifStmt |
    (
      // obj.hasOwnProperty(key)
      check.getMethodName() = "hasOwnProperty"
      or
      // Object.hasOwn(obj, key)
      check.getMethodName() = "hasOwn"
      or
      // Object.prototype.hasOwnProperty.call(obj, key)
      (check.getMethodName() = "call" and
       check.getReceiver().(PropAccess).getPropertyName() = "hasOwnProperty")
    ) and
    // The check is in an if condition that guards the access
    ifStmt.getCondition().getAChildExpr*() = check and
    ifStmt.getThen().getAChildExpr*() = access
  )
}

/**
 * Unsafe property access using bracket notation with dynamic key
 * Pattern: obj[key] where key is not a literal and not guarded by hasOwnProperty
 */
class UnsafePropertyAccess extends IndexExpr {
  UnsafePropertyAccess() {
    // Key is not a string/number literal (dynamic)
    not this.getPropertyNameExpr() instanceof StringLiteral and
    not this.getPropertyNameExpr() instanceof NumberLiteral and
    // No hasOwnProperty check guarding this access
    not hasPropertyCheck(this)
  }
}

//-----------------------------------------------------------------------------
// HELPER FUNCTIONS
//-----------------------------------------------------------------------------

string getObjectName(IndexExpr ie) {
  result = ie.getBase().toString()
}

string getKeyName(IndexExpr ie) {
  result = ie.getPropertyNameExpr().toString()
}

string getFunctionName(Function f) {
  if exists(f.getName()) and f.getName() != ""
  then result = f.getName()
  else result = "<anonymous>"
}

//-----------------------------------------------------------------------------
// MAIN QUERY - Find all sink locations
//-----------------------------------------------------------------------------

from UnsafePropertyAccess access, Function accessFunc,
     string funcName, string funcFile, int funcDefLine, int accessLine,
     string objName, string keyName
where
  // Get function containing the sink
  accessFunc = access.getEnclosingFunction() and

  // Exclude test files
  not accessFunc.getFile().getRelativePath().matches("%__tests__%") and
  not accessFunc.getFile().getRelativePath().matches("%-test.js") and
  not accessFunc.getFile().getRelativePath().matches("%test%") and

  // Get sink details
  funcName = getFunctionName(accessFunc) and
  funcFile = accessFunc.getFile().getRelativePath() and
  funcDefLine = accessFunc.getLocation().getStartLine() and
  accessLine = access.getLocation().getStartLine() and
  objName = getObjectName(access) and
  keyName = getKeyName(access)

select access, "Unsafe property access: " + objName + "[" + keyName + "]",
       funcName as sink_func,
       funcFile as sink_file,
       funcDefLine as sink_func_def_ln,
       accessLine as sink_ln,
       objName as object,
       keyName as key
