"""Linux-specific end-to-end tests for the Mystique compiler pipeline."""
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import (
    ALL_FLAGS,
    IR_FLAGS,
    X86_FLAGS,
    compile_backend,
    compile_mc,
    run_loader,
    sha256,
)

pytestmark = [
    pytest.mark.linux,
    pytest.mark.skipif(sys.platform != "linux", reason="Linux only"),
]

ROOT = Path(__file__).parent.parent.parent
BACKEND_DIR = ROOT / "compiler" / "backend"
LOADERS_DIR = ROOT / "compiler" / "loaders"
BUNDLES_DIR = ROOT / "bundles"
TESTS_DIR = ROOT / "tests"

BACKEND_EXE = BACKEND_DIR / "backend_mystc"
LOADER_EXE = LOADERS_DIR / "loader_linux"
TEST_MC = TESTS_DIR / "programs" / "test_linux.mc"


def test_compile_and_run(tmp_path):
    """Full pipeline: compile test_linux.mc and run via loader, expect exit 42."""
    mcb = tmp_path / "test_linux.mcb"
    bin_ = tmp_path / "test_linux.bin"

    compile_mc(TEST_MC, mcb)
    compile_backend(BACKEND_EXE, mcb, bin_)
    rc = run_loader(LOADER_EXE, bin_)
    assert rc == 42, f"Expected exit 42, got {rc}"


def test_polymorphism(tmp_path):
    """Compile at seeds 1001-1005 with unfold+poly; all exit 42, all SHA256 unique."""
    mcb = tmp_path / "test_linux.mcb"
    compile_mc(TEST_MC, mcb)

    flags = ["--ir-unfold", "--x86-poly-instrs"]
    hashes = []
    for seed in range(1001, 1006):
        bin_ = tmp_path / f"test_linux_{seed}.bin"
        compile_backend(BACKEND_EXE, mcb, bin_, seed=seed, flags=flags)
        rc = run_loader(LOADER_EXE, bin_)
        assert rc == 42, f"Seed {seed}: expected exit 42, got {rc}"
        hashes.append(sha256(bin_))

    assert len(set(hashes)) == 5, f"Expected 5 unique hashes, got {len(set(hashes))}"


def test_all_ir_transforms(tmp_path):
    """Compile with all IR transform flags, expect exit 42."""
    mcb = tmp_path / "test_linux.mcb"
    bin_ = tmp_path / "test_linux.bin"

    compile_mc(TEST_MC, mcb)
    compile_backend(BACKEND_EXE, mcb, bin_, flags=IR_FLAGS)
    rc = run_loader(LOADER_EXE, bin_)
    assert rc == 42, f"Expected exit 42, got {rc}"


def test_all_x86_transforms(tmp_path):
    """Compile with all x86 transform flags, expect exit 42."""
    mcb = tmp_path / "test_linux.mcb"
    bin_ = tmp_path / "test_linux.bin"

    compile_mc(TEST_MC, mcb)
    compile_backend(BACKEND_EXE, mcb, bin_, flags=X86_FLAGS)
    rc = run_loader(LOADER_EXE, bin_)
    assert rc == 42, f"Expected exit 42, got {rc}"


def test_all_transforms_combined(tmp_path):
    """Compile with all IR + x86 transform flags, expect exit 42."""
    mcb = tmp_path / "test_linux.mcb"
    bin_ = tmp_path / "test_linux.bin"

    compile_mc(TEST_MC, mcb)
    compile_backend(BACKEND_EXE, mcb, bin_, flags=ALL_FLAGS)
    rc = run_loader(LOADER_EXE, bin_)
    assert rc == 42, f"Expected exit 42, got {rc}"


def test_elf_output(tmp_path):
    """Backend --elf-standalone produces a file with ELF magic bytes."""
    mcb = tmp_path / "test_linux.mcb"
    elf = tmp_path / "test_linux.elf"

    compile_mc(TEST_MC, mcb)
    cmd = [
        str(BACKEND_EXE), str(mcb),
        "--elf-standalone", str(elf),
        "--seed", "1001",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert r.returncode == 0, f"Backend --elf-standalone failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"
    assert elf.exists(), "ELF output file was not created"
    magic = elf.read_bytes()[:4]
    assert magic == b"\x7fELF", f"Expected ELF magic, got {magic!r}"


def test_elf_is_executable(tmp_path):
    """ELF binary runs directly and exits 42."""
    mcb = tmp_path / "test_linux.mcb"
    elf = tmp_path / "test_linux.elf"

    compile_mc(TEST_MC, mcb)
    cmd = [
        str(BACKEND_EXE), str(mcb),
        "--elf-standalone", str(elf),
        "--seed", "1001",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert r.returncode == 0, f"Backend --elf-standalone failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"

    # Make executable and run
    elf.chmod(0o755)
    r = subprocess.run([str(elf)], capture_output=True, text=True, timeout=30)
    assert r.returncode == 42, f"ELF run: expected exit 42, got {r.returncode}"


def test_multiple_seeds_all_transforms(tmp_path):
    """Seeds 1001-1003, all transforms, all exit 42."""
    mcb = tmp_path / "test_linux.mcb"
    compile_mc(TEST_MC, mcb)

    for seed in range(1001, 1004):
        bin_ = tmp_path / f"test_linux_{seed}.bin"
        compile_backend(BACKEND_EXE, mcb, bin_, seed=seed, flags=ALL_FLAGS)
        rc = run_loader(LOADER_EXE, bin_)
        assert rc == 42, f"Seed {seed}: expected exit 42, got {rc}"
