"""E2E test fixtures and helpers."""
import hashlib
import shutil
import subprocess
import sys
import os
from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent.parent
COMPILER_DIR = ROOT / "compiler"
BACKEND_DIR = COMPILER_DIR / "backend"
LOADERS_DIR = COMPILER_DIR / "loaders"
BUNDLES_DIR = ROOT / "bundles"
EXAMPLES_DIR = ROOT / "docs" / "examples"
TESTS_DIR = ROOT / "tests"
PROGRAMS_DIR = TESTS_DIR / "programs"
VICTIMS_DIR = TESTS_DIR / "victims"

IS_WINDOWS = sys.platform == "win32"

BACKEND_EXE = BACKEND_DIR / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")
BACKEND_MCB = BACKEND_DIR / "backend_mystc.mcb"
BACKEND_BIN = BACKEND_DIR / "backend_mystc.bin"
LOADER_EXE = LOADERS_DIR / ("loader_win32.exe" if IS_WINDOWS else "loader_linux")
RECOMP_MCB = BUNDLES_DIR / "recompilers" / ("recomp_pe.mcb" if IS_WINDOWS else "recomp_elf.mcb")

if IS_WINDOWS:
    STRESS_MC = PROGRAMS_DIR / "compiler_stress.mc"
    EXTERN_MC = PROGRAMS_DIR / "extern_stress_win32.mc"
    PAYLOAD_MC = EXAMPLES_DIR / "fibonacci_payload_win32.mc"
else:
    STRESS_MC = PROGRAMS_DIR / "test_linux.mc"
    EXTERN_MC = PROGRAMS_DIR / "extern_stress_linux.mc"
    PAYLOAD_MC = EXAMPLES_DIR / "fibonacci_payload_linux.mc"

IR_FLAGS = [
    "--ir-obfuscate-names", "--ir-unfold", "--ir-substitute", "--ir-deadcode",
    "--ir-nops", "--ir-reorder-instrs", "--ir-reorder-locals", "--ir-reorder-blocks",
    "--ir-reorder-funcs",
]

X86_FLAGS = [
    "--x86-poly-instrs", "--x86-dead-code", "--x86-opaque", "--x86-junk-funcs",
    "--x86-harmless-calls", "--x86-shuffle-funcs",
]

ALL_FLAGS = IR_FLAGS + X86_FLAGS

STRESS_MODES = {
    "no_transforms":       [],
    "all_ir":              IR_FLAGS,
    "all_x86":             X86_FLAGS,
    "all_ir_all_x86":      ALL_FLAGS,
    "ir_obfuscate_names":  ["--ir-obfuscate-names"],
    "ir_unfold":           ["--ir-unfold"],
    "ir_substitute":       ["--ir-substitute"],
    "ir_deadcode":         ["--ir-deadcode"],
    "ir_nops":             ["--ir-nops"],
    "ir_reorder_instrs":   ["--ir-reorder-instrs"],
    "ir_reorder_locals":   ["--ir-reorder-locals"],
    "ir_reorder_blocks":   ["--ir-reorder-blocks"],
    "ir_reorder_funcs":    ["--ir-reorder-funcs"],
    "x86_poly_instrs":     ["--x86-poly-instrs"],
    "x86_dead_code":       ["--x86-dead-code"],
    "x86_opaque":          ["--x86-opaque"],
    "x86_junk_funcs":      ["--x86-junk-funcs"],
    "x86_harmless_calls":  ["--x86-harmless-calls"],
    "x86_shuffle_funcs":   ["--x86-shuffle-funcs"],
    "x86_junk_and_shuffle":["--x86-junk-funcs", "--x86-shuffle-funcs"],
    "x86_dead_and_opaque": ["--x86-dead-code", "--x86-opaque"],
}

SEEDS = list(range(1001, 1011))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compile_mc(source_path, mcb_path, defines=None):
    """Frontend: .mc -> .mcb bytecode."""
    cmd = [sys.executable, "-m", "compiler.frontend.mystcc",
           str(source_path), "-o", str(mcb_path)]
    # Auto-detect platform define if none specified
    if defines is None:
        defines = ["WIN32"] if sys.platform == "win32" else ["LINUX"]
    for d in defines:
        cmd.append(f"-D{d}")
    r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Frontend failed on {source_path}:\n{r.stderr}")
    return mcb_path


def compile_backend(backend_exe, mcb, bin_out, seed=1001, flags=None):
    """Backend: .mcb -> .bin PIC shellcode."""
    cmd = [str(backend_exe), str(mcb), "--pic", str(bin_out),
           "--seed", str(seed)]
    if flags:
        cmd.extend(flags)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(
            f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}")
    return bin_out


def run_loader(loader_exe, bin_path, timeout=30):
    """Run the loader on a .bin file, return exit code."""
    r = subprocess.run(
        [str(loader_exe), str(bin_path)],
        capture_output=True, text=True, timeout=timeout
    )
    return r.returncode


def ensure_built():
    """Check that all required binaries exist."""
    missing = []
    for p in [BACKEND_EXE, LOADER_EXE]:
        if not p.exists():
            missing.append(p.name)
    if missing:
        pytest.skip(f"Missing binaries: {', '.join(missing)} -- run 'python build.py build' first")


@pytest.fixture(scope="session")
def backend_exe():
    assert BACKEND_EXE.exists(), f"Backend not found -- run 'python build.py build'"
    return BACKEND_EXE


@pytest.fixture(scope="session")
def loader_exe():
    assert LOADER_EXE.exists(), f"Loader not found -- run 'python build.py build'"
    return LOADER_EXE


@pytest.fixture(scope="session")
def stress_mcb(tmp_path_factory):
    """Compile the platform stress test .mc -> .mcb."""
    ensure_built()
    if not STRESS_MC.exists():
        pytest.skip(f"Stress test not found: {STRESS_MC}")
    d = tmp_path_factory.mktemp("stress_mcb")
    mcb = d / "stress.mcb"
    compile_mc(STRESS_MC, mcb)
    return mcb


@pytest.fixture(scope="session")
def extern_mcb(tmp_path_factory):
    """Compile the platform extern stress test .mc -> .mcb."""
    ensure_built()
    if not EXTERN_MC.exists():
        pytest.skip(f"Extern stress test not found: {EXTERN_MC}")
    d = tmp_path_factory.mktemp("extern_mcb")
    mcb = d / "extern_stress.mcb"
    compile_mc(EXTERN_MC, mcb)
    return mcb


@pytest.fixture(scope="session")
def payload_mcb(tmp_path_factory):
    """Compile the platform payload .mc -> .mcb (for gen tests)."""
    ensure_built()
    if not PAYLOAD_MC.exists():
        pytest.skip(f"Payload not found: {PAYLOAD_MC}")
    d = tmp_path_factory.mktemp("payload_mcb")
    mcb = d / "payload.mcb"
    compile_mc(PAYLOAD_MC, mcb)
    return mcb
