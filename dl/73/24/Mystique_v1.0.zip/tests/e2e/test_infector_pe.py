"""Simple PE infector tests.

Builds infector_pe as a standalone PE that infects another PE by
appending code+preloader to .text and data+blobs+imports to .data, then
shifting section VAs and patching .reloc entries. No scattering, no LDE.

Targets victim_*.exe (built by tests/victims/build_all.bat). The infected
binary runs the infector's main() first (which prints usage when no
--infect argument is given), then jumps to the victim's original entry —
so the victim's banner appears later in stdout, not at offset 0.
"""
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_EXE, BUNDLES_DIR, VICTIMS_DIR

INFECTOR_MCB = BUNDLES_DIR / "infectors" / "infector_pe.mcb"
VICTIM_EXE   = VICTIMS_DIR / "victim_sort.exe"
VICTIM2_EXE  = VICTIMS_DIR / "victim_string.exe"

pytestmark = [
    pytest.mark.infector_pe,
    pytest.mark.skipif(sys.platform != "win32", reason="PE infector requires Windows"),
]


def _skip_if_unprepared():
    if not BACKEND_EXE.exists():
        pytest.skip(f"Backend not built: {BACKEND_EXE.name}")
    if not INFECTOR_MCB.exists():
        pytest.skip(f"Infector .mcb not built: {INFECTOR_MCB.name} -- run 'python build.py build'")
    if not VICTIM_EXE.exists():
        pytest.skip(f"Victim PE not built: {VICTIM_EXE.name} -- run tests/victims/build_all.bat")


@pytest.fixture(scope="module")
def infector_pe(tmp_path_factory):
    """Build the standalone infector_pe binary once per module."""
    _skip_if_unprepared()
    d = tmp_path_factory.mktemp("infector_pe")
    exe = d / "infector_pe.exe"
    cmd = [str(BACKEND_EXE), str(INFECTOR_MCB),
           "--pe-standalone", str(exe),
           "--seed", "1001"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}\n{r.stdout}"
    assert exe.exists() and exe.stat().st_size > 100_000
    return exe


def _run(argv, timeout=120):
    return subprocess.run([str(a) for a in argv], capture_output=True,
                          text=True, timeout=timeout,
                          encoding="latin-1", errors="replace")


class TestInfectorPe:
    def test_infect_succeeds(self, infector_pe, tmp_path):
        """Gen0 infector reports successful infection (size grows, header line printed)."""
        target = tmp_path / "victim_target.exe"
        shutil.copy(VICTIM_EXE, target)
        size_before = target.stat().st_size

        r = _run([infector_pe, "--infect", target])
        assert "Infected:" in r.stdout, f"no Infected: marker:\n{r.stdout}\n{r.stderr}"

        size_after = target.stat().st_size
        assert size_after > size_before, \
            f"infected file did not grow: {size_before} -> {size_after}"

    def test_infected_runs_and_preserves_victim(self, infector_pe, tmp_path):
        """Infected binary still produces the victim's original output."""
        target = tmp_path / "victim_runs.exe"
        shutil.copy(VICTIM_EXE, target)

        r0 = _run([target], timeout=30)
        assert r0.returncode == 0
        assert "victim_sort.c test suite" in r0.stdout

        r1 = _run([infector_pe, "--infect", target])
        assert "Infected:" in r1.stdout

        # Infected runs the infector's main() first (prints usage when no --infect),
        # then jumps to the victim's original entry — banner appears later.
        r2 = _run([target], timeout=30)
        assert r2.returncode == 0, \
            f"infected exited rc={hex(r2.returncode & 0xFFFFFFFF)}"
        assert "victim_sort.c test suite" in r2.stdout, \
            "victim's original output not preserved"

    def test_self_replicate_two_gens(self, infector_pe, tmp_path):
        """Infected binary (gen1) can infect another victim (gen2)."""
        v1 = tmp_path / "v1.exe"
        v2 = tmp_path / "v2.exe"
        shutil.copy(VICTIM_EXE, v1)
        shutil.copy(VICTIM2_EXE, v2)

        # gen0 → gen1
        r = _run([infector_pe, "--infect", v1])
        assert "Infected:" in r.stdout

        # gen1 → gen2: invoked with --infect, the bundle entry calls main() which
        # infects v2, then control returns to v1's victim entry.
        size_before = v2.stat().st_size
        r = _run([v1, "--infect", v2], timeout=180)
        size_after = v2.stat().st_size
        assert size_after > size_before, \
            f"gen1 → gen2 infection did not grow file:\nstdout:\n{r.stdout}"
        assert "Infected:" in r.stdout

        # gen2 runs and shows victim_string's banner
        r = _run([v2], timeout=30)
        assert r.returncode == 0
        assert "victim_string.c test suite" in r.stdout


# =============================================================================
# Payload-bearing PE infector tests
#
# Builds infector_pe with --payload <fib.mcb>; the embedded payload runs
# (compiled to PIC, loaded RWX) once on each invocation that takes the
# --infect path, before the actual infection logic. Payload bytes
# propagate to gen1 so the same payload runs again from infected hosts.
# =============================================================================

@pytest.fixture(scope="module")
def infector_pe_with_payload(tmp_path_factory):
    """Build a Gen0 infector_pe with the fibonacci payload embedded.

    Uses the bundle carrier form: positional .mcb is the user payload, the
    infector_pe.mcb is loaded automatically from --bundles-dir.
    """
    _skip_if_unprepared()
    from tests.e2e.conftest import compile_mc, PAYLOAD_MC
    if not PAYLOAD_MC.exists():
        pytest.skip(f"Payload source missing: {PAYLOAD_MC}")
    d = tmp_path_factory.mktemp("infector_pe_pay")
    pay_mcb = d / "fib_payload.mcb"
    compile_mc(PAYLOAD_MC, pay_mcb)
    exe = d / "infector_pe.exe"
    cmd = [str(BACKEND_EXE), str(pay_mcb),
           "--infector-pe", str(exe),
           "--bundles-dir", str(BUNDLES_DIR),
           "--seed", "1001"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}\n{r.stdout}"
    assert exe.exists() and exe.stat().st_size > 100_000
    return exe


class TestInfectorPePayload:
    def test_gen0_runs_payload(self, infector_pe_with_payload, tmp_path):
        """Payload runs (Fibonacci PASS) before gen0 infects victim."""
        target = tmp_path / "victim_target.exe"
        shutil.copy(VICTIM_EXE, target)

        r = _run([infector_pe_with_payload, "--infect", target])
        assert "Fibonacci payload" in r.stdout, \
            f"payload did not run on gen0:\n{r.stdout}"
        assert "PASS" in r.stdout, \
            f"payload did not PASS on gen0:\n{r.stdout}"
        assert "Infected:" in r.stdout, \
            f"infection did not complete after payload:\n{r.stdout}"

    def test_gen1_carries_payload(self, infector_pe_with_payload, tmp_path):
        """Payload bytes propagate to gen1; running gen1 with --infect re-runs payload."""
        v1 = tmp_path / "v1.exe"
        v2 = tmp_path / "v2.exe"
        shutil.copy(VICTIM_EXE, v1)
        shutil.copy(VICTIM2_EXE, v2)

        # gen0 → gen1
        r = _run([infector_pe_with_payload, "--infect", v1])
        assert "PASS" in r.stdout

        # gen1 → gen2: payload should run again from inside v1
        r = _run([v1, "--infect", v2], timeout=180)
        assert "PASS" in r.stdout, \
            f"payload did not propagate / run on gen1:\n{r.stdout}"
