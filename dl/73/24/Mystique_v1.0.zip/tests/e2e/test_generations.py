"""Multi-generational compilation chain tests.

Each generation applies --transform-ir to produce a new .mcb, compiles it
to .bin, and runs the result.  This validates that the polymorphic pipeline
is stable across multiple self-transformation passes.
"""
import subprocess

import pytest

from tests.e2e.conftest import (
    ALL_FLAGS, IS_WINDOWS,
    compile_backend, run_loader, sha256,
)

IR_TRANSFORM_FLAGS = [
    "--ir-unfold", "--ir-substitute", "--ir-nops", "--ir-reorder-instrs",
    "--ir-reorder-locals", "--ir-reorder-blocks", "--ir-reorder-funcs",
]


def transform_ir(backend_exe, mcb_in, mcb_out, seed, flags):
    """Run the backend's --transform-ir pass to produce a new .mcb."""
    cmd = [str(backend_exe), str(mcb_in), "--transform-ir", str(mcb_out),
           "--seed", str(seed)] + flags
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert r.returncode == 0, f"transform-ir failed: {r.stderr}"
    return mcb_out


@pytest.mark.recompilation
def test_6_generation_chain(backend_exe, loader_exe, stress_mcb, tmp_path):
    """Run a 6-generation transform-compile-run chain.

    Each generation transforms the previous .mcb with a distinct seed,
    compiles to .bin, and verifies the binary runs correctly.  All 6 bins
    must have different SHA256 hashes (polymorphism) and the last bin must
    not exceed 5x the size of the first (no size explosion).
    """
    expected_rc = 0 if IS_WINDOWS else 42
    num_generations = 6
    base_seed = 5000
    current_mcb = stress_mcb
    hashes = []
    sizes = []

    for gen in range(1, num_generations + 1):
        seed = base_seed + gen
        next_mcb = tmp_path / f"gen{gen}.mcb"
        bin_path = tmp_path / f"gen{gen}.bin"

        # Transform IR to produce next generation .mcb
        transform_ir(backend_exe, current_mcb, next_mcb, seed=seed,
                      flags=IR_TRANSFORM_FLAGS)

        # Compile to .bin with all flags
        compile_backend(backend_exe, next_mcb, bin_path, seed=seed,
                        flags=ALL_FLAGS)

        # Run and verify
        rc = run_loader(loader_exe, bin_path)
        assert rc == expected_rc, (
            f"gen{gen}: exit={rc} expected={expected_rc}")

        hashes.append(sha256(bin_path))
        sizes.append(bin_path.stat().st_size)
        current_mcb = next_mcb

    # All 6 bins must be polymorphically distinct
    assert len(set(hashes)) == num_generations, (
        f"Expected {num_generations} unique hashes, got {len(set(hashes))}: {hashes}")

    # No size explosion
    assert sizes[-1] < 5 * sizes[0], (
        f"Size explosion: gen1={sizes[0]} gen6={sizes[-1]} "
        f"(ratio {sizes[-1] / sizes[0]:.1f}x)")


@pytest.mark.recompilation
def test_3_generation_chain_incrementing_seeds(backend_exe, loader_exe,
                                                stress_mcb, tmp_path):
    """3-generation chain with seeds 1001, 1002, 1003."""
    expected_rc = 0 if IS_WINDOWS else 42
    seeds = [1001, 1002, 1003]
    current_mcb = stress_mcb
    hashes = []

    for gen, seed in enumerate(seeds, start=1):
        next_mcb = tmp_path / f"incr_gen{gen}.mcb"
        bin_path = tmp_path / f"incr_gen{gen}.bin"

        transform_ir(backend_exe, current_mcb, next_mcb, seed=seed,
                      flags=IR_TRANSFORM_FLAGS)

        compile_backend(backend_exe, next_mcb, bin_path, seed=seed,
                        flags=ALL_FLAGS)

        rc = run_loader(loader_exe, bin_path)
        assert rc == expected_rc, (
            f"gen{gen} seed={seed}: exit={rc} expected={expected_rc}")

        hashes.append(sha256(bin_path))
        current_mcb = next_mcb

    assert len(set(hashes)) == len(seeds), (
        f"Expected {len(seeds)} unique hashes, got {len(set(hashes))}")


@pytest.mark.recompilation
def test_mcb_valid_after_transform(backend_exe, stress_mcb, tmp_path):
    """After a single --transform-ir pass the output .mcb starts with the
    MCBN magic header and has non-zero size."""
    out_mcb = tmp_path / "transformed.mcb"
    transform_ir(backend_exe, stress_mcb, out_mcb, seed=2001,
                  flags=IR_TRANSFORM_FLAGS)

    data = out_mcb.read_bytes()
    assert len(data) > 0, "Transformed .mcb is empty"
    assert data[:4] == b"MCBN", (
        f"Bad magic: expected b'MCBN', got {data[:4]!r}")
