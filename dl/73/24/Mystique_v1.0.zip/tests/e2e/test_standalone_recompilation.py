"""End-to-end tests for self-recompiling standalone PE and ELF."""
import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_EXE, BACKEND_MCB, ensure_built, sha256

IS_WINDOWS = sys.platform == "win32"
IS_LINUX   = sys.platform == "linux"

BUNDLES_DIR = ROOT / "bundles"
RECOMP_PE_MCB = BUNDLES_DIR / "recompilers" / "recomp_pe.mcb"
RECOMP_ELF_MCB = BUNDLES_DIR / "recompilers" / "recomp_elf.mcb"


def has_wsl():
    """Check if WSL is available."""
    if not IS_WINDOWS:
        return False
    try:
        r = subprocess.run(["wsl", "--list", "--quiet"], capture_output=True, timeout=5)
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def build_srpe(output, seed=1001, payload_mcb=None):
    """Build a Gen0 self-recompiling standalone PE.

    With no payload: uses the legacy `--pe-standalone <recomp.mcb>` form.
    With a payload: uses the modern `--recompiler-pe` carrier flag, where
    the positional arg becomes the embedded user payload and the carrier
    .mcb is loaded from --bundles-dir.
    """
    ensure_built()
    if payload_mcb is None:
        mcb = RECOMP_PE_MCB if RECOMP_PE_MCB.exists() else BACKEND_MCB
        cmd = [str(BACKEND_EXE), str(mcb),
               "--pe-standalone", str(output),
               "--seed", str(seed)]
    else:
        cmd = [str(BACKEND_EXE), str(payload_mcb),
               "--recompiler-pe", str(output),
               "--bundles-dir", str(BUNDLES_DIR),
               "--seed", str(seed)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"Gen0 PE build failed:\n{r.stderr}"
    assert Path(output).exists()


def build_sref(output, seed=1001, payload_mcb=None):
    """Build a Gen0 self-recompiling standalone ELF.

    See build_srpe for the no-payload vs with-payload command shapes.
    """
    ensure_built()
    if payload_mcb is None:
        mcb = RECOMP_ELF_MCB if RECOMP_ELF_MCB.exists() else BACKEND_MCB
        cmd = [str(BACKEND_EXE), str(mcb),
               "--elf-standalone", str(output),
               "--seed", str(seed)]
    else:
        cmd = [str(BACKEND_EXE), str(payload_mcb),
               "--recompiler-elf", str(output),
               "--bundles-dir", str(BUNDLES_DIR),
               "--seed", str(seed)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"Gen0 ELF build failed:\n{r.stderr}"
    assert Path(output).exists()


def run_pe(exe, timeout=120):
    """Run a PE and return (returncode, stdout, stderr)."""
    r = subprocess.run([str(exe)], capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout, r.stderr


def _to_wsl_path(p):
    """Windows path → /mnt/<drive> path. No-op on Linux."""
    s = str(p).replace("\\", "/")
    if IS_LINUX:
        return s
    if len(s) >= 2 and s[1] == ":":
        return f"/mnt/{s[0].lower()}{s[2:]}"
    return s


def _bash(cmd, timeout=120):
    """Run a bash command: native on Linux, via `wsl bash -c` on Windows."""
    argv = (["wsl", "bash", "-c", cmd] if IS_WINDOWS else ["bash", "-c", cmd])
    return subprocess.run(
        argv, capture_output=True, text=True, timeout=timeout,
    )


def run_elf(elf_path, timeout=120):
    """Run an ELF (native on Linux, via WSL on Windows) and return (returncode, stdout).

    The ELF is staged into a fresh /tmp workdir and executed with that as cwd
    so any side-effect files (e.g. recompiler `a.out`) stay isolated and don't
    pollute the project root."""
    pid = os.getpid()
    tmp = f"/tmp/mystique_test_{pid}"
    workdir = f"/tmp/mystique_test_wd_{pid}"
    src = _to_wsl_path(elf_path)
    r = _bash(
        f"mkdir -p '{workdir}' && cp '{src}' '{tmp}' && chmod +x '{tmp}' "
        f"&& cd '{workdir}' && '{tmp}'; echo RC=$?; "
        f"cd / && rm -rf '{workdir}' '{tmp}'",
        timeout=timeout,
    )
    lines = r.stdout.strip().split("\n")
    rc_line = [l for l in lines if l.startswith("RC=")]
    rc = int(rc_line[0].split("=")[1]) if rc_line else -1
    output = "\n".join(l for l in lines if not l.startswith("RC="))
    return rc, output


# Back-compat alias — old name referenced in case anything imports it
run_elf_wsl = run_elf


# =============================================================================
# PE Self-Recompilation Tests
# =============================================================================

@pytest.mark.e2e
@pytest.mark.skipif(not IS_WINDOWS, reason="PE requires Windows")
class TestPeStandaloneRecompilation:
    """Self-recompiling standalone PE chain tests."""

    def test_gen0_runs(self, tmp_path):
        """Gen0 PE runs and produces Gen1."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0)
        rc, out, err = run_pe(gen0)
        assert rc == 0, f"Gen0 failed (rc={rc}):\n{out}\n{err}"
        gen1 = tmp_path / "gen0_new.exe"
        assert gen1.exists(), "Gen0 did not produce gen1"
        assert gen1.stat().st_size > 100000, "Gen1 too small"

    def test_gen1_runs(self, tmp_path):
        """Gen1 PE runs and produces Gen2."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0)
        run_pe(gen0)
        gen1 = tmp_path / "gen0_new.exe"
        rc, out, err = run_pe(gen1)
        assert rc == 0, f"Gen1 failed (rc={rc}):\n{out}\n{err}"

    def test_three_generation_chain(self, tmp_path):
        """Gen0 -> Gen1 -> Gen2 -> Gen3, all succeed."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0)

        current = gen0
        for gen in range(3):
            rc, out, err = run_pe(current)
            assert rc == 0, f"Gen{gen} failed (rc={rc}):\n{out}\n{err}"
            next_exe = Path(str(current).replace(".exe", "_new.exe"))
            assert next_exe.exists(), f"Gen{gen} did not produce next gen"
            current = next_exe

    def test_polymorphism(self, tmp_path):
        """Each generation has different bytes."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0)

        hashes = [sha256(gen0)]
        current = gen0
        for _ in range(3):
            run_pe(current)
            next_exe = Path(str(current).replace(".exe", "_new.exe"))
            if next_exe.exists():
                hashes.append(sha256(next_exe))
                current = next_exe

        unique = len(set(hashes))
        assert unique >= 3, f"Expected >= 3 unique hashes, got {unique}: {hashes}"

    def test_gen1_valid_pe_structure(self, tmp_path):
        """Gen1 has valid PE structure (MZ, sections, imports)."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0)
        run_pe(gen0)
        gen1 = tmp_path / "gen0_new.exe"
        data = gen1.read_bytes()

        import struct
        assert data[:2] == b"MZ"
        pe_off = struct.unpack_from("<I", data, 0x3C)[0]
        assert data[pe_off:pe_off + 4] == b"PE\x00\x00"
        num_sec = struct.unpack_from("<H", data, pe_off + 6)[0]
        assert num_sec == 3


# =============================================================================
# ELF Self-Recompilation Tests
# =============================================================================

@pytest.mark.e2e
@pytest.mark.skipif(not (IS_LINUX or (IS_WINDOWS and has_wsl())),
                    reason="ELF tests require Linux or Windows+WSL")
class TestElfStandaloneRecompilation:
    """Self-recompiling standalone ELF chain tests (native on Linux, WSL on Windows)."""

    def test_gen0_runs(self, tmp_path):
        """Gen0 ELF runs and produces Gen1."""
        gen0 = tmp_path / "gen0_elf"
        build_sref(gen0)
        rc, out = run_elf(gen0)
        assert rc == 0, f"Gen0 ELF failed (rc={rc}):\n{out}"

    def test_gen0_produces_output(self, tmp_path):
        """Gen0 ELF produces a.out in current directory."""
        gen0 = tmp_path / "gen0_elf"
        build_sref(gen0)
        src = _to_wsl_path(gen0)
        r = _bash(
            f"cd /tmp && cp '{src}' gen0_elf && chmod +x gen0_elf && ./gen0_elf && ls -la a.out 2>&1",
            timeout=120,
        )
        assert "a.out" in r.stdout, f"Gen0 did not produce a.out:\n{r.stdout}"

    def test_elf_valid_structure(self, tmp_path):
        """Gen0 ELF has valid ELF32 structure."""
        gen0 = tmp_path / "gen0_elf"
        build_sref(gen0)
        data = gen0.read_bytes()

        import struct
        assert data[:4] == b"\x7fELF"
        assert data[4] == 1  # ELF32
        e_type = struct.unpack_from("<H", data, 16)[0]
        assert e_type == 2  # ET_EXEC
        e_machine = struct.unpack_from("<H", data, 18)[0]
        assert e_machine == 3  # EM_386


# =============================================================================
# Payload-bearing Recompiler Tests
#
# Verify that the recompiler standalone (PE/ELF) carries a user payload,
# runs it before mutate+recompile, and propagates the payload bytes into
# Gen1 so it runs again next generation.
# =============================================================================

@pytest.mark.e2e
@pytest.mark.skipif(not IS_WINDOWS, reason="PE requires Windows")
class TestPeStandaloneRecompilationWithPayload:
    """Self-recompiling standalone PE carrying a user payload."""

    def test_gen0_runs_payload(self, tmp_path, payload_mcb):
        """Gen0 PE compiles+runs the embedded payload before recompiling itself."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0, payload_mcb=payload_mcb)
        rc, out, err = run_pe(gen0)
        assert rc == 0, f"Gen0 failed (rc={rc}):\n{out}\n{err}"
        assert "Fibonacci payload" in out, \
            f"payload did not run on gen0:\n{out}"
        assert "PASS" in out, f"payload did not PASS on gen0:\n{out}"

    def test_gen1_carries_payload(self, tmp_path, payload_mcb):
        """Payload bytes propagate through one generation; gen1 runs the payload."""
        gen0 = tmp_path / "gen0.exe"
        build_srpe(gen0, payload_mcb=payload_mcb)
        rc, _, _ = run_pe(gen0)
        assert rc == 0
        gen1 = tmp_path / "gen0_new.exe"
        assert gen1.exists()
        rc, out, err = run_pe(gen1)
        assert rc == 0, f"Gen1 failed (rc={rc}):\n{out}\n{err}"
        assert "PASS" in out, \
            f"payload did not propagate / run on gen1:\n{out}"


@pytest.fixture(scope="session")
def linux_payload_mcb(tmp_path_factory):
    """Compile the *Linux* fibonacci payload to .mcb regardless of host OS.

    The session-scoped `payload_mcb` fixture in conftest auto-picks the
    platform's payload — on Windows that's the Win32 one, which doesn't
    work as a payload embedded in an ELF binary (kernel32.dll externs).
    ELF recompiler tests need the libc-extern variant explicitly.
    """
    from tests.e2e.conftest import compile_mc, EXAMPLES_DIR, ensure_built
    ensure_built()
    src = EXAMPLES_DIR / "fibonacci_payload_linux.mc"
    if not src.exists():
        pytest.skip(f"Linux payload missing: {src}")
    d = tmp_path_factory.mktemp("linux_payload_mcb")
    mcb = d / "fib_payload_linux.mcb"
    compile_mc(src, mcb, defines=["LINUX"])
    return mcb


@pytest.mark.e2e
@pytest.mark.skipif(not (IS_LINUX or (IS_WINDOWS and has_wsl())),
                    reason="ELF tests require Linux or Windows+WSL")
class TestElfStandaloneRecompilationWithPayload:
    """Self-recompiling standalone ELF carrying a user payload."""

    def test_gen0_runs_payload(self, tmp_path, linux_payload_mcb):
        """Gen0 ELF compiles+runs the embedded payload before recompiling itself."""
        gen0 = tmp_path / "gen0_elf"
        build_sref(gen0, payload_mcb=linux_payload_mcb)
        rc, out = run_elf(gen0)
        assert rc == 0, f"Gen0 ELF failed (rc={rc}):\n{out}"
        assert "Fibonacci payload" in out, \
            f"payload did not run on gen0:\n{out}"
        assert "PASS" in out, f"payload did not PASS on gen0:\n{out}"

    def test_gen1_carries_payload(self, tmp_path, linux_payload_mcb):
        """Payload bytes propagate through one generation; gen1 runs the payload."""
        gen0 = tmp_path / "gen0_elf"
        build_sref(gen0, payload_mcb=linux_payload_mcb)
        # Run gen0 in /tmp so the produced a.out lands there; copy it back.
        pid = os.getpid()
        tmp = f"/tmp/mystique_payload_gen_{pid}"
        src = _to_wsl_path(gen0)
        r = _bash(
            f"rm -rf {tmp} && mkdir -p {tmp} && cp '{src}' {tmp}/g0 "
            f"&& chmod +x {tmp}/g0 && cd {tmp} && ./g0 && ls -la a.out 2>&1; echo RC=$?",
            timeout=180,
        )
        assert "a.out" in r.stdout, f"gen0 did not produce a.out:\n{r.stdout}"
        # Run a.out (gen1) and check payload re-runs there.
        r = _bash(
            f"cd {tmp} && chmod +x a.out && ./a.out 2>&1; echo RC=$?; rm -rf {tmp}",
            timeout=180,
        )
        assert "PASS" in r.stdout, \
            f"payload did not propagate / run on gen1:\n{r.stdout}"


# =============================================================================
# Cross-format Tests
# =============================================================================

@pytest.mark.e2e
class TestStandaloneFormats:
    """Tests that verify both PE and ELF standalone output formats."""

    @pytest.mark.skipif(not IS_WINDOWS, reason="PE execution requires Windows")
    def test_pe_standalone_still_works(self, tmp_path):
        """Basic --pe-standalone still produces working executables."""
        from tests.e2e.conftest import compile_mc, PROGRAMS_DIR
        mcb = compile_mc(PROGRAMS_DIR / "compiler_stress.mc", tmp_path / "cs.mcb")
        pe = tmp_path / "cs.exe"
        r = subprocess.run(
            [str(BACKEND_EXE), str(mcb), "--pe-standalone", str(pe), "--seed", "1001"],
            capture_output=True, text=True,
        )
        assert r.returncode == 0
        r2 = subprocess.run([str(pe)], capture_output=True, text=True, timeout=30)
        assert r2.returncode == 0
        assert "Total errors: 0" in r2.stdout

    def test_elf_standalone_valid(self, tmp_path):
        """Basic --elf-standalone produces valid ELF (magic check — no execution)."""
        from tests.e2e.conftest import compile_mc, PROGRAMS_DIR
        mcb = compile_mc(PROGRAMS_DIR / "test_linux.mc", tmp_path / "tl.mcb")
        elf = tmp_path / "tl_elf"
        r = subprocess.run(
            [str(BACKEND_EXE), str(mcb), "--elf-standalone", str(elf), "--seed", "1001"],
            capture_output=True, text=True,
        )
        assert r.returncode == 0
        data = elf.read_bytes()
        assert data[:4] == b"\x7fELF"
