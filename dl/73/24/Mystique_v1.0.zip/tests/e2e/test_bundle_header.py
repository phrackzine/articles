"""Verify the C backend emits a valid BundleHeader in standalone PE/ELF output.

Locates the header by its META magic, parses descriptors, and sanity-checks
the descriptor layout (kinds, sizes, offsets sum to payload_size).
"""
import struct
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_EXE, BUNDLES_DIR

pytestmark = pytest.mark.e2e

META_MAGIC = 0x4154454D   # "META" little-endian
META_VERSION = 1

BC_CARRIER = 1
BC_ENTRY   = 2
BC_ENGINE  = 3
BC_PAYLOAD = 4
BC_GENOME  = 5


def _find_pe_data_section(buf):
    """Return (file_offset, virtual_addr, size) of the .data section in a PE."""
    pe_off = struct.unpack_from("<I", buf, 0x3C)[0]
    num_sec = struct.unpack_from("<H", buf, pe_off + 6)[0]
    opt_size = struct.unpack_from("<H", buf, pe_off + 20)[0]
    sec_base = pe_off + 24 + opt_size
    for si in range(num_sec):
        sh = sec_base + si * 40
        name = bytes(buf[sh:sh + 8]).rstrip(b"\0")
        if name == b".data":
            vsize = struct.unpack_from("<I", buf, sh + 8)[0]
            rva   = struct.unpack_from("<I", buf, sh + 12)[0]
            rsize = struct.unpack_from("<I", buf, sh + 16)[0]
            raw   = struct.unpack_from("<I", buf, sh + 20)[0]
            return raw, rva, max(vsize, rsize)
    raise AssertionError(".data section not found")


def _find_elf_data_segment(buf):
    """Return (file_offset, vaddr, size) of the RW PT_LOAD segment."""
    ph_off = struct.unpack_from("<I", buf, 28)[0]
    ph_num = struct.unpack_from("<H", buf, 44)[0]
    for i in range(ph_num):
        ph = ph_off + i * 32
        p_type = struct.unpack_from("<I", buf, ph + 0)[0]
        p_offset = struct.unpack_from("<I", buf, ph + 4)[0]
        p_vaddr = struct.unpack_from("<I", buf, ph + 8)[0]
        p_filesz = struct.unpack_from("<I", buf, ph + 16)[0]
        p_flags = struct.unpack_from("<I", buf, ph + 24)[0]
        if p_type == 1 and (p_flags & 2) and not (p_flags & 1):
            return p_offset, p_vaddr, p_filesz
    raise AssertionError("RW PT_LOAD segment not found")


def _scan_for_meta(buf, off, size):
    """Find a *valid* BundleHeader within [off, off+size).

    The META magic byte sequence also appears in `.data` as the init value
    of the `META_MAGIC` int constant (the literal 0x4154454D stored at the
    global's slot). To skip that decoy, probe-validate each match: check
    version + header_size consistency before accepting.
    """
    magic = struct.pack("<I", META_MAGIC)
    end = off + size
    i = off
    while i < end - 32:
        if buf[i:i + 4] == magic:
            version = struct.unpack_from("<I", buf, i + 4)[0]
            header_size = struct.unpack_from("<I", buf, i + 8)[0]
            n_desc = struct.unpack_from("<I", buf, i + 12)[0]
            if (version == META_VERSION
                and 1 <= n_desc <= 16
                and header_size == 32 + n_desc * 16):
                return i
        i += 1   # header offset isn't guaranteed int-aligned in dual-write
    return -1


def _parse_header(buf, hdr_off):
    """Parse a 32-byte BundleHeader + descriptor table. Returns a dict."""
    magic, version, header_size, n_desc, base_addr, payload_size, key, flags = \
        struct.unpack_from("<8I", buf, hdr_off)
    assert magic == META_MAGIC, f"bad magic 0x{magic:08x}"
    assert version == META_VERSION, f"bad version {version}"
    assert header_size == 32 + n_desc * 16, \
        f"header_size {header_size} != 32 + {n_desc}*16"
    descriptors = []
    for di in range(n_desc):
        d_off = hdr_off + 32 + di * 16
        kind, offset, size, dflags = struct.unpack_from("<4I", buf, d_off)
        descriptors.append({"kind": kind, "offset": offset, "size": size, "flags": dflags})
    return {
        "magic": magic, "version": version, "header_size": header_size,
        "n_descriptors": n_desc, "base_addr": base_addr,
        "payload_size": payload_size, "key": key, "flags_reserved": flags,
        "descriptors": descriptors,
    }


def _kinds_of(parsed):
    return {d["kind"] for d in parsed["descriptors"]}


@pytest.mark.skipif(sys.platform != "win32", reason="recompiler-pe is Win32-only")
def test_recompiler_pe_emits_valid_bundle_header(tmp_path):
    out = tmp_path / "recomp_gen0.exe"
    cmd = [str(BACKEND_EXE), "--recompiler-pe", str(out),
           "--bundles-dir", str(BUNDLES_DIR), "--seed", "42"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}"
    assert out.exists()

    buf = out.read_bytes()
    data_raw, data_rva, data_size = _find_pe_data_section(buf)
    hdr_off = _scan_for_meta(buf, data_raw, data_size)
    assert hdr_off >= 0, "BundleHeader magic not found in .data"

    parsed = _parse_header(buf, hdr_off)
    # Recompiler bundle = [carrier | (optional payload) | genome]
    kinds = _kinds_of(parsed)
    assert BC_CARRIER in kinds, f"missing BC_CARRIER, got {kinds}"
    assert BC_GENOME in kinds, f"missing BC_GENOME, got {kinds}"
    # No engine in a recompiler bundle
    assert BC_ENGINE not in kinds, f"unexpected BC_ENGINE in recompiler bundle"

    # All descriptor sizes must be positive
    for d in parsed["descriptors"]:
        assert d["size"] > 0, f"descriptor {d} has zero size"

    # payload_size matches sum of descriptor sizes
    total = sum(d["size"] for d in parsed["descriptors"])
    assert parsed["payload_size"] == total, \
        f"payload_size {parsed['payload_size']} != sum {total}"

    # base_addr is post-patched; non-zero for a bundle binary
    assert parsed["base_addr"] != 0, "base_addr not post-patched"


@pytest.mark.skipif(sys.platform != "win32", reason="integrator-pe is Win32-only")
def test_integrator_pe_emits_entry_engine_descriptors(tmp_path):
    out = tmp_path / "integrator_gen0.exe"
    cmd = [str(BACKEND_EXE), "--integrator-pe", str(out),
           "--bundles-dir", str(BUNDLES_DIR), "--seed", "42"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}"
    assert out.exists()

    buf = out.read_bytes()
    data_raw, data_rva, data_size = _find_pe_data_section(buf)
    hdr_off = _scan_for_meta(buf, data_raw, data_size)
    assert hdr_off >= 0, "BundleHeader magic not found in .data"

    parsed = _parse_header(buf, hdr_off)
    kinds = _kinds_of(parsed)
    # Integrator bundle = [entry | engine | (optional payload) | genome]
    assert BC_ENTRY in kinds, f"missing BC_ENTRY, got {kinds}"
    assert BC_ENGINE in kinds, f"missing BC_ENGINE, got {kinds}"
    assert BC_GENOME in kinds, f"missing BC_GENOME, got {kinds}"
    # No CARRIER in a 4-component integrator bundle
    assert BC_CARRIER not in kinds, f"unexpected BC_CARRIER in integrator bundle"


def test_descriptor_offsets_are_monotonic(tmp_path):
    """Components are laid out contiguously starting at base_addr — offsets
    must be monotonically non-decreasing and equal to the cumulative sum
    of preceding component sizes."""
    if sys.platform == "win32":
        out = tmp_path / "x.exe"
        flag = "--recompiler-pe"
    else:
        out = tmp_path / "x"
        flag = "--recompiler-elf"
    cmd = [str(BACKEND_EXE), flag, str(out),
           "--bundles-dir", str(BUNDLES_DIR), "--seed", "13"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}"

    buf = out.read_bytes()
    if sys.platform == "win32":
        data_raw, data_rva, data_size = _find_pe_data_section(buf)
    else:
        data_raw, data_rva, data_size = _find_elf_data_segment(buf)
    hdr_off = _scan_for_meta(buf, data_raw, data_size)
    assert hdr_off >= 0
    parsed = _parse_header(buf, hdr_off)

    running = 0
    for d in parsed["descriptors"]:
        assert d["offset"] == running, \
            f"descriptor {d} offset != running sum {running}"
        running += d["size"]
