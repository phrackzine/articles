"""LacriMystique ELF infection tests (pytest).

Tests standalone infection of PIE ELF victims, multi-generation
self-recompilation, and polymorphism. On Linux runs directly; on
Windows calls `wsl bash -c` for each step.
"""
import hashlib
import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_DIR, BUNDLES_DIR, BACKEND_EXE

IS_WINDOWS = sys.platform == "win32"
IS_LINUX   = sys.platform == "linux"

LACRI_MCB = BUNDLES_DIR / "integrators" / "lacriMystique" / "lacrimystique.mcb"
ENTRY_ELF_MCB = BUNDLES_DIR / "integrators" / "lacriMystique" / "integrator_entry_elf.mcb"
VICTIMS_DIR = ROOT / "tests" / "victims"

VICTIM_SOURCES = [
    "victim_sort.c", "victim_math.c", "victim_crypto.c",
    "victim_string.c", "victim_state.c", "victim_graph.c",
    "victim_matrix.c", "victim_tree.c", "victim_compress.c",
]

pytestmark = [
    pytest.mark.lacrimystique,
    pytest.mark.skipif(not (IS_WINDOWS or IS_LINUX),
                       reason="LacriMystique requires Linux or Windows+WSL"),
]


def _skip_if_missing():
    missing = []
    if not BACKEND_EXE.exists():
        missing.append(BACKEND_EXE.name)
    if not LACRI_MCB.exists():
        missing.append(LACRI_MCB.name)
    if not ENTRY_ELF_MCB.exists():
        missing.append(ENTRY_ELF_MCB.name)
    if missing:
        pytest.skip(f"Missing: {', '.join(missing)}")


def _wsl(cmd, timeout=120):
    """Run a shell command. On Windows wraps with `wsl bash -c`; on Linux
    runs `bash -c` directly. Paths inside `cmd` must already be valid for
    the target shell (use _to_wsl_path to translate from Windows paths).
    """
    argv = (["wsl", "bash", "-c", cmd] if IS_WINDOWS else ["bash", "-c", cmd])
    return subprocess.run(
        argv,
        capture_output=True, text=True, timeout=timeout,
        encoding="latin-1", errors="replace",
    )


def _has_wsl_gcc32():
    """Check if the target shell has gcc with 32-bit support (compile+link of
    a tiny program, not just `-c`, since we also need 32-bit libc/crt)."""
    probe = "echo 'int main(){return 0;}' | gcc -m32 -x c -o /dev/null - 2>/dev/null; echo RC=$?"
    r = _wsl(probe, timeout=15)
    return "RC=0" in r.stdout


def _victims_ready():
    """All listed victims have precompiled .elf32 binaries present."""
    return all((VICTIMS_DIR / f"{src.replace('.c', '')}.elf32").exists()
               for src in VICTIM_SOURCES)


def _need_compile_capability():
    """Skip helper: if any precompiled ELF is missing, we need gcc -m32."""
    if _victims_ready():
        return  # all precompiled, gcc not needed
    if not _has_wsl_gcc32():
        pytest.skip("Precompiled victim_*.elf32 missing and WSL gcc -m32 not available")


def _to_wsl_path(path):
    """Convert a Windows path to a WSL /mnt path. On Linux returns the path
    unchanged (it's already native)."""
    p = str(path).replace("\\", "/")
    if IS_LINUX:
        return p
    if len(p) >= 2 and p[1] == ":":
        return f"/mnt/{p[0].lower()}{p[2:]}"
    return p


def _build_elf_standalone(tmp_path, seed=42, payload_mcb=None):
    """Build lacrimystique standalone ELF via C backend (bundle architecture)."""
    elf = tmp_path / "lacrimystique.elf"
    cmd = [str(BACKEND_EXE), str(ENTRY_ELF_MCB),
           "--elf-standalone", str(elf),
           "--engine", str(LACRI_MCB),
           "--seed", str(seed)]
    if payload_mcb:
        cmd += ["--payload", str(payload_mcb)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"Build failed:\n{r.stderr}"
    assert elf.exists() and elf.stat().st_size > 100000
    return elf


def _setup_wsl(tmp_path, wsl_dir, seed=42, payload_mcb=None):
    """Build lacrimystique ELF and copy to WSL temp dir."""
    elf = _build_elf_standalone(tmp_path, seed=seed, payload_mcb=payload_mcb)
    _wsl(f"rm -rf {wsl_dir} && mkdir -p {wsl_dir}")
    wsl_elf = f"{wsl_dir}/lacrimystique"
    _wsl(f"cp {_to_wsl_path(elf)} {wsl_elf} && chmod +x {wsl_elf}")
    return wsl_elf


def _compile_victim(wsl_dir, victim_c):
    """Provision a victim ELF in wsl_dir. Prefers the precompiled .elf32 next
    to the .c source (built by tests/victims/build_all.sh); falls back to
    invoking gcc if the precompiled one is missing.
    Returns WSL path."""
    stem = victim_c.replace(".c", "")
    out = f"{wsl_dir}/{stem}"
    precompiled = VICTIMS_DIR / f"{stem}.elf32"
    if precompiled.exists():
        _wsl(f"cp {_to_wsl_path(precompiled)} {out} && chmod +x {out}")
    else:
        src = _to_wsl_path(VICTIMS_DIR / victim_c)
        _wsl(f"gcc -m32 -pie -fpie -O2 -Wl,--hash-style=sysv -z lazy -o {out} {src} 2>/dev/null")
    return out


def _count_lines(wsl_path, timeout=30):
    """Run a WSL binary and count output lines."""
    r = _wsl(f"{wsl_path} 2>&1", timeout=timeout)
    if not r.stdout.strip():
        return 0
    return len(r.stdout.strip().split("\n"))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestInfectsAllVictims:
    """Gen0 standalone infects each victim, engine + victim output preserved."""

    def setup_method(self):
        _skip_if_missing()
        _need_compile_capability()

    @pytest.mark.parametrize("victim_c", VICTIM_SOURCES)
    def test_infect_victim(self, tmp_path, victim_c):
        wsl_dir = f"/tmp/lacri_{victim_c.replace('.c', '')}" + os.environ.get("LACRI_TEST_SUFFIX", "")
        wsl_elf = _setup_wsl(tmp_path, wsl_dir)

        victim = _compile_victim(wsl_dir, victim_c)
        orig_lines = _count_lines(victim)
        assert orig_lines > 0, f"Original {victim_c} produced no output"

        # Infect
        r = _wsl(f"{wsl_elf} --infect {victim} 2>&1", timeout=180)
        assert "Infected:" in r.stdout, f"Infection failed:\n{r.stdout}"

        # Run infected — expect engine(2) + victim(orig) output
        r = _wsl(f"{victim} 2>&1", timeout=30)
        inf_lines = len(r.stdout.strip().split("\n")) if r.stdout.strip() else 0
        assert inf_lines >= orig_lines + 2, \
            f"{victim_c}: expected >= {orig_lines + 2} lines, got {inf_lines}"

        _wsl(f"rm -rf {wsl_dir}")


class TestThreeGenerationChain:
    """Infected binary can recompile itself and infect another victim."""

    def setup_method(self):
        _skip_if_missing()
        _need_compile_capability()

    def test_three_gen_chain(self, tmp_path):
        wsl_dir = "/tmp/lacri_3gen" + os.environ.get("LACRI_TEST_SUFFIX", "")
        wsl_elf = _setup_wsl(tmp_path, wsl_dir)

        # Compile 3 victims
        for i in range(1, 4):
            _compile_victim(wsl_dir, "victim_sort.c")
            _wsl(f"cp {wsl_dir}/victim_sort {wsl_dir}/v{i}")

        # Gen0 -> v1
        r = _wsl(f"{wsl_elf} --infect {wsl_dir}/v1 2>&1", timeout=180)
        assert "Infected:" in r.stdout
        v1_lines = _count_lines(f"{wsl_dir}/v1")
        assert v1_lines >= 91, f"Gen0 v1: expected >= 91, got {v1_lines}"

        # Gen1: v1 -> v2
        _wsl(f"{wsl_dir}/v1 --infect {wsl_dir}/v2 2>&1; true", timeout=180)
        v2_lines = _count_lines(f"{wsl_dir}/v2")
        assert v2_lines >= 91, f"Gen1 v2: expected >= 91, got {v2_lines}"

        # Gen2: v2 -> v3
        _wsl(f"{wsl_dir}/v2 --infect {wsl_dir}/v3 2>&1; true", timeout=180)
        v3_lines = _count_lines(f"{wsl_dir}/v3")
        assert v3_lines >= 91, f"Gen2 v3: expected >= 91, got {v3_lines}"

        _wsl(f"rm -rf {wsl_dir}")


class TestPolymorphism:
    """Genome mutation produces different binary content across generations."""

    def setup_method(self):
        _skip_if_missing()
        _need_compile_capability()

    def test_genome_mutation_changes_binary(self, tmp_path):
        """Gen0→v1 and Gen1:v1→v2 produce different .text content (genome mutation)."""
        wsl_dir = "/tmp/lacri_poly" + os.environ.get("LACRI_TEST_SUFFIX", "")
        wsl_elf = _setup_wsl(tmp_path, wsl_dir)

        _compile_victim(wsl_dir, "victim_sort.c")
        _wsl(f"cp {wsl_dir}/victim_sort {wsl_dir}/v1")
        _wsl(f"cp {wsl_dir}/victim_sort {wsl_dir}/v2")

        # Gen0 -> v1
        r = _wsl(f"{wsl_elf} --infect {wsl_dir}/v1 2>&1", timeout=180)
        assert "Infected:" in r.stdout

        # Gen1: v1 -> v2 (genome mutated → different binary)
        _wsl(f"{wsl_dir}/v1 --infect {wsl_dir}/v2 2>&1; true", timeout=180)

        # Both should work
        v1_lines = _count_lines(f"{wsl_dir}/v1")
        v2_lines = _count_lines(f"{wsl_dir}/v2")
        assert v1_lines >= 91, f"v1: expected >= 91, got {v1_lines}"
        assert v2_lines >= 91, f"v2: expected >= 91, got {v2_lines}"

        # Binary content should differ (genome mutation → different transforms)
        r1 = _wsl(f"md5sum {wsl_dir}/v1 {wsl_dir}/v2")
        hashes = [line.split()[0] for line in r1.stdout.strip().split("\n") if line.strip()]
        assert len(hashes) == 2 and hashes[0] != hashes[1], \
            f"Expected different binaries across generations, got same hash"

        _wsl(f"rm -rf {wsl_dir}")


class TestVictimChain:
    """Chain infection: each infected ELF infects the next diverse victim."""

    def setup_method(self):
        _skip_if_missing()
        _need_compile_capability()

    def test_victim_chain(self, tmp_path):
        wsl_dir = "/tmp/lacri_chain" + os.environ.get("LACRI_TEST_SUFFIX", "")
        wsl_elf = _setup_wsl(tmp_path, wsl_dir)

        chain = ["victim_sort.c", "victim_math.c", "victim_crypto.c",
                 "victim_tree.c", "victim_string.c"]
        prev_elf = wsl_elf
        passed = 0

        for victim_c in chain:
            victim = _compile_victim(wsl_dir, victim_c)
            orig_lines = _count_lines(victim)
            assert orig_lines > 0, f"{victim_c} produced no output"

            r = _wsl(f"{prev_elf} --infect {victim} 2>&1; true", timeout=180)
            inf_lines = _count_lines(victim)
            if inf_lines >= orig_lines:
                passed += 1
                prev_elf = victim
            else:
                break

        assert passed >= 3, f"Only {passed}/5 chain links succeeded (first fail: {r.stdout[:200] if r else 'N/A'})"
        _wsl(f"rm -rf {wsl_dir}")


PAYLOAD_LINUX_MC = ROOT / "docs" / "examples" / "fibonacci_payload_linux.mc"
PAYLOAD_EXPECTED = "Checksum: 17710"


class TestPayloadChain:
    """Payload propagation: fibonacci payload embedded in bundle, chained through victims."""

    def setup_method(self):
        _skip_if_missing()
        _need_compile_capability()

    @staticmethod
    def _compile_payload_mcb(tmp_path):
        mcb = tmp_path / "payload_linux.mcb"
        r = subprocess.run(
            [sys.executable, "-m", "compiler.frontend.mystcc",
             str(PAYLOAD_LINUX_MC), "-o", str(mcb), "-DLINUX"],
            capture_output=True, timeout=60, cwd=str(ROOT),
        )
        assert r.returncode == 0, f"Payload frontend failed:\n{r.stderr}"
        assert mcb.exists()
        return mcb

    def test_payload_through_three_victims(self, tmp_path):
        if not PAYLOAD_LINUX_MC.exists():
            pytest.skip("Linux payload source not found")

        payload_mcb = self._compile_payload_mcb(tmp_path)
        wsl_dir = "/tmp/lacri_payload" + os.environ.get("LACRI_TEST_SUFFIX", "")
        wsl_elf = _setup_wsl(tmp_path, wsl_dir, payload_mcb=payload_mcb)

        chain = ["victim_sort.c", "victim_math.c", "victim_crypto.c"]
        prev_elf = wsl_elf
        passed = 0
        last_out = ""

        for victim_c in chain:
            victim = _compile_victim(wsl_dir, victim_c)
            _wsl(f"{prev_elf} --infect {victim} 2>&1; true", timeout=180)
            r = _wsl(f"{victim} 2>&1", timeout=30)
            last_out = r.stdout
            if PAYLOAD_EXPECTED in r.stdout:
                passed += 1
                prev_elf = victim
            else:
                break

        _wsl(f"rm -rf {wsl_dir}")
        assert passed >= 2, \
            f"Only {passed}/3 payload chain links succeeded (last output: {last_out[:300]})"
