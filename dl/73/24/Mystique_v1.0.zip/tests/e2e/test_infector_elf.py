"""Simple ELF infector tests.

Builds infector_elf as a standalone PIE-free 32-bit ELF, infects a
non-PIE victim, verifies infection markers + execution. The infector
appends a payload via PT_NOTE→PT_LOAD conversion (no scattering, no LDE).

Requires WSL/Linux + gcc -m32. The infector itself does not load PIE
victims (its loader expects a fixed-VA classical layout); tests build a
purpose-built non-PIE victim per session.
"""
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import ROOT, BACKEND_EXE, BUNDLES_DIR, VICTIMS_DIR

IS_WINDOWS = sys.platform == "win32"
IS_LINUX   = sys.platform == "linux"

INFECTOR_MCB = BUNDLES_DIR / "infectors" / "infector_elf.mcb"

pytestmark = [
    pytest.mark.infector_elf,
    pytest.mark.skipif(not (IS_WINDOWS or IS_LINUX),
                       reason="infector_elf requires Linux or Windows+WSL"),
]


def _shell(cmd, timeout=120):
    argv = (["wsl", "bash", "-c", cmd] if IS_WINDOWS else ["bash", "-c", cmd])
    return subprocess.run(argv, capture_output=True, text=True,
                          timeout=timeout, encoding="latin-1", errors="replace")


def _to_target_path(p):
    """Translate a Windows path to a WSL /mnt path; on Linux pass through."""
    s = str(p).replace("\\", "/")
    if IS_LINUX:
        return s
    if len(s) >= 2 and s[1] == ":":
        return f"/mnt/{s[0].lower()}{s[2:]}"
    return s


def _has_gcc32():
    r = _shell("echo 'int main(){return 0;}' | gcc -m32 -no-pie -x c -o /dev/null - 2>/dev/null; echo RC=$?",
               timeout=15)
    return "RC=0" in r.stdout


def _skip_if_unprepared():
    if not BACKEND_EXE.exists():
        pytest.skip(f"Backend not built: {BACKEND_EXE.name}")
    if not INFECTOR_MCB.exists():
        pytest.skip(f"Infector .mcb not built: {INFECTOR_MCB.name} -- run 'python build.py build'")
    if not _has_gcc32():
        pytest.skip("gcc -m32 -no-pie not available")


@pytest.fixture(scope="module")
def infector_elf(tmp_path_factory):
    """Build the standalone infector_elf binary once per module."""
    _skip_if_unprepared()
    d = tmp_path_factory.mktemp("infector_elf")
    elf = d / "infector_elf"
    cmd = [str(BACKEND_EXE), str(INFECTOR_MCB),
           "--elf-standalone", str(elf),
           "--seed", "1001"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}\n{r.stdout}"
    assert elf.exists() and elf.stat().st_size > 100_000
    return elf


def _stage_target(target_dir, infector_elf):
    """Set up a clean working dir in WSL/Linux with the infector + a non-PIE victim built fresh."""
    _shell(f"rm -rf {target_dir} && mkdir -p {target_dir}")
    target_inf = f"{target_dir}/infector_elf"
    _shell(f"cp {_to_target_path(infector_elf)} {target_inf} && chmod +x {target_inf}")

    # Compile a non-PIE victim per the infector's expectations
    src = _to_target_path(VICTIMS_DIR / "victim_sort.c")
    target_victim = f"{target_dir}/victim"
    r = _shell(f"gcc -m32 -no-pie -O2 -o {target_victim} {src} 2>/dev/null")
    assert r.returncode == 0, "victim compile failed"
    _shell(f"chmod +x {target_victim}")
    return target_inf, target_victim


def _victim_output_lines(path):
    r = _shell(f"{path} 2>&1", timeout=30)
    return r.stdout.strip().split("\n") if r.stdout.strip() else []


class TestInfectorElf:
    def test_infect_succeeds(self, infector_elf):
        """Gen0 infector reports successful infection (size grows, header line printed)."""
        d = "/tmp/inf_elf_succeeds"
        inf, victim = _stage_target(d, infector_elf)
        size_before = int(_shell(f"stat -c %s {victim}").stdout.strip())

        r = _shell(f"{inf} --infect {victim} 2>&1", timeout=120)
        assert "Infected:" in r.stdout, f"no Infected: marker:\n{r.stdout}"

        size_after = int(_shell(f"stat -c %s {victim}").stdout.strip())
        assert size_after > size_before, "infected file did not grow"
        _shell(f"rm -rf {d}")

    def test_infected_runs_and_preserves_victim(self, infector_elf):
        """Infected binary still produces the victim's original output."""
        d = "/tmp/inf_elf_runs"
        inf, victim = _stage_target(d, infector_elf)

        before = _victim_output_lines(victim)
        assert before, "original victim produced no output"

        r = _shell(f"{inf} --infect {victim} 2>&1", timeout=120)
        assert "Infected:" in r.stdout

        after = _victim_output_lines(victim)
        # Infected binary may print an infector banner before victim output;
        # require all original lines to appear (in order) somewhere.
        assert "=== victim_sort.c test suite ===" in "\n".join(after), \
            "victim's original output not preserved post-infection"
        assert len(after) >= len(before), \
            f"infected output truncated: orig={len(before)} infected={len(after)}"
        _shell(f"rm -rf {d}")

    def test_self_replicate_two_gens(self, infector_elf):
        """Infected binary (gen1) can infect another victim (gen2), gen2 still runs."""
        d = "/tmp/inf_elf_2gen"
        inf, victim = _stage_target(d, infector_elf)

        # gen0 → gen1
        r = _shell(f"{inf} --infect {victim} 2>&1", timeout=120)
        assert "Infected:" in r.stdout

        # Make a fresh second victim and have gen1 infect it
        src = _to_target_path(VICTIMS_DIR / "victim_string.c")
        victim2 = f"{d}/victim2"
        r = _shell(f"gcc -m32 -no-pie -O2 -o {victim2} {src} 2>/dev/null")
        assert r.returncode == 0

        size_before = int(_shell(f"stat -c %s {victim2}").stdout.strip())
        r = _shell(f"{victim} --infect {victim2} 2>&1", timeout=180)
        size_after = int(_shell(f"stat -c %s {victim2}").stdout.strip())
        assert size_after > size_before, \
            f"gen1 → gen2 infection did not grow file:\nstdout:\n{r.stdout}"

        # gen2 still runs and shows the victim_string banner
        r = _shell(f"{victim2} 2>&1", timeout=30)
        assert "victim_string.c test suite" in r.stdout, \
            f"gen2 did not preserve victim_string output:\n{r.stdout}"
        _shell(f"rm -rf {d}")


# =============================================================================
# Payload-bearing ELF infector tests
#
# Builds infector_elf with the fibonacci payload via the bundle carrier
# form (`<payload.mcb> --infector-elf <out>`). The embedded payload is
# compiled+run once on each invocation that takes the --infect path.
# Payload bytes propagate to gen1 so the same payload runs from infected
# hosts as well.
# =============================================================================

@pytest.fixture(scope="module")
def infector_elf_with_payload(tmp_path_factory):
    """Build a Gen0 infector_elf with the fibonacci payload embedded."""
    _skip_if_unprepared()
    from tests.e2e.conftest import compile_mc, EXAMPLES_DIR
    PAYLOAD_MC = EXAMPLES_DIR / "fibonacci_payload_linux.mc"
    if not PAYLOAD_MC.exists():
        pytest.skip(f"Payload source missing: {PAYLOAD_MC}")
    d = tmp_path_factory.mktemp("infector_elf_pay")
    pay_mcb = d / "fib_payload.mcb"
    compile_mc(PAYLOAD_MC, pay_mcb, defines=["LINUX"])
    elf = d / "infector_elf"
    cmd = [str(BACKEND_EXE), str(pay_mcb),
           "--infector-elf", str(elf),
           "--bundles-dir", str(BUNDLES_DIR),
           "--seed", "1001"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"build failed:\n{r.stderr}\n{r.stdout}"
    assert elf.exists() and elf.stat().st_size > 100_000
    return elf


class TestInfectorElfPayload:
    def test_gen0_runs_payload(self, infector_elf_with_payload):
        """Payload runs (Fibonacci PASS) before gen0 infects victim."""
        d = "/tmp/inf_elf_pay_gen0"
        inf, victim = _stage_target(d, infector_elf_with_payload)

        r = _shell(f"{inf} --infect {victim} 2>&1", timeout=120)
        assert "Fibonacci payload" in r.stdout, \
            f"payload did not run on gen0:\n{r.stdout}"
        assert "PASS" in r.stdout, \
            f"payload did not PASS on gen0:\n{r.stdout}"
        assert "Infected:" in r.stdout, \
            f"infection did not complete after payload:\n{r.stdout}"
        _shell(f"rm -rf {d}")

    def test_gen1_carries_payload(self, infector_elf_with_payload):
        """Payload bytes propagate to gen1 so it runs again from infected host."""
        d = "/tmp/inf_elf_pay_gen1"
        inf, victim = _stage_target(d, infector_elf_with_payload)

        # gen0 → gen1
        r = _shell(f"{inf} --infect {victim} 2>&1", timeout=120)
        assert "PASS" in r.stdout

        # Build a fresh victim2 and have gen1 (the infected first victim) infect it.
        src = _to_target_path(VICTIMS_DIR / "victim_string.c")
        victim2 = f"{d}/victim2"
        r = _shell(f"gcc -m32 -no-pie -O2 -o {victim2} {src} 2>/dev/null")
        assert r.returncode == 0
        r = _shell(f"{victim} --infect {victim2} 2>&1", timeout=240)
        assert "PASS" in r.stdout, \
            f"payload did not propagate / run on gen1:\n{r.stdout}"
        _shell(f"rm -rf {d}")
