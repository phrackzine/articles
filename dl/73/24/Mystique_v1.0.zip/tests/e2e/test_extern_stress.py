"""Extern stress test — exercises DLL/libc extern resolution with transforms.

Compiles extern_stress_{win32,linux}.mc through the full pipeline and verifies
all extern calls resolve correctly under various transform combinations.
"""
import sys

import pytest

from tests.e2e.conftest import (
    ALL_FLAGS, IR_FLAGS, X86_FLAGS, IS_WINDOWS,
    compile_backend, run_loader,
)

pytestmark = pytest.mark.e2e

SEEDS = [1001, 1002, 1003]

MODES = {
    "no_transforms":  [],
    "all_ir":         IR_FLAGS,
    "all_x86":        X86_FLAGS,
    "all_ir_all_x86": ALL_FLAGS,
}


@pytest.mark.parametrize("mode_name,flags", MODES.items(), ids=MODES.keys())
@pytest.mark.parametrize("seed", SEEDS)
def test_extern_stress(backend_exe, loader_exe, extern_mcb, tmp_path, mode_name, flags, seed):
    """Compile extern_stress with given transforms and verify exit 0."""
    bin_path = tmp_path / f"extern_{mode_name}_{seed}.bin"
    compile_backend(backend_exe, extern_mcb, bin_path, seed=seed, flags=flags)
    rc = run_loader(loader_exe, bin_path)
    assert rc == 0, f"extern_stress mode={mode_name} seed={seed}: exit={rc} expected=0"
