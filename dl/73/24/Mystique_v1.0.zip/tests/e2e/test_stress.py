"""Stress test — 21 modes x 10 seeds = 210 tests."""
import pytest

from tests.e2e.conftest import (
    STRESS_MODES, SEEDS, IS_WINDOWS,
    compile_backend, run_loader, sha256,
)


@pytest.mark.e2e
@pytest.mark.parametrize("mode_name,flags", STRESS_MODES.items(), ids=STRESS_MODES.keys())
@pytest.mark.parametrize("seed", SEEDS)
def test_stress(backend_exe, loader_exe, stress_mcb, tmp_path, mode_name, flags, seed):
    bin_path = tmp_path / f"stress_{mode_name}_{seed}.bin"
    compile_backend(backend_exe, stress_mcb, bin_path, seed=seed, flags=flags)
    rc = run_loader(loader_exe, bin_path)
    expected = 0 if IS_WINDOWS else 42
    assert rc == expected, f"mode={mode_name} seed={seed}: exit={rc} expected={expected}"


# Modes that don't reliably affect the PIC byte output:
# ir_obfuscate_names renames non-extern symbols (user function/variable names),
# but PIC output embeds only extern names in extern_info and never user names
# in code/data. So the PIC bytes are invariant under obfuscate_names for any
# program without stringified references to user symbols.
_POLY_EXEMPT = {"ir_obfuscate_names"}


@pytest.mark.e2e
@pytest.mark.parametrize("mode_name,flags",
    [(k, v) for k, v in STRESS_MODES.items() if v and k not in _POLY_EXEMPT],
    ids=[k for k, v in STRESS_MODES.items() if v and k not in _POLY_EXEMPT])
def test_polymorphism_uniqueness(backend_exe, stress_mcb, tmp_path, mode_name, flags):
    hashes = set()
    for seed in range(1001, 1006):
        bin_path = tmp_path / f"poly_{mode_name}_{seed}.bin"
        compile_backend(backend_exe, stress_mcb, bin_path, seed=seed, flags=flags)
        hashes.add(sha256(bin_path))
    assert len(hashes) > 1, f"Mode {mode_name}: all seeds produced identical binaries"
