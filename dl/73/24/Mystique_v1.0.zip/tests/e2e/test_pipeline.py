"""End-to-end tests for the full .mc -> .mcb -> .bin -> loader pipeline."""
import pytest

from tests.e2e.conftest import ALL_FLAGS, EXAMPLES_DIR, compile_mc, compile_backend, run_loader


EXAMPLE_PROGRAMS = [
    ("simple_test.mc", 23),
    ("factorial.mc", 120),
    ("globals.mc", 50),
    ("linked_list.mc", 60),
]


@pytest.mark.e2e
@pytest.mark.parametrize("mc_name,expected_exit", EXAMPLE_PROGRAMS,
                         ids=[p[0].replace(".mc", "") for p in EXAMPLE_PROGRAMS])
def test_full_pipeline(backend_exe, loader_exe, tmp_path, mc_name, expected_exit):
    """Compile .mc -> .mcb -> .bin (no transforms), run via loader, check exit code."""
    mc = EXAMPLES_DIR / mc_name
    mcb = tmp_path / mc_name.replace(".mc", ".mcb")
    bin_ = tmp_path / mc_name.replace(".mc", ".bin")

    compile_mc(mc, mcb)
    compile_backend(backend_exe, mcb, bin_)
    rc = run_loader(loader_exe, bin_)
    assert rc == expected_exit, f"{mc_name}: expected exit {expected_exit}, got {rc}"


@pytest.mark.e2e
def test_mcb_magic(backend_exe, tmp_path):
    """Compiled .mcb file must start with the b'MCBN' magic bytes."""
    mc = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"

    compile_mc(mc, mcb)
    header = mcb.read_bytes()[:4]
    assert header == b"MCBN", f"Expected magic b'MCBN', got {header!r}"


@pytest.mark.e2e
def test_bin_valid_header(backend_exe, tmp_path):
    """Compiled .bin must be larger than the 20-byte PIC header."""
    mc = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"
    bin_ = tmp_path / "simple_test.bin"

    compile_mc(mc, mcb)
    compile_backend(backend_exe, mcb, bin_)
    size = bin_.stat().st_size
    assert size > 20, f"BIN file too small ({size} bytes); expected > 20"


@pytest.mark.e2e
def test_pipeline_with_transforms(backend_exe, loader_exe, tmp_path):
    """Pipeline still produces correct exit code with IR + x86 transforms enabled."""
    mc = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"
    bin_ = tmp_path / "simple_test.bin"

    compile_mc(mc, mcb)
    compile_backend(backend_exe, mcb, bin_, flags=ALL_FLAGS)
    rc = run_loader(loader_exe, bin_)
    assert rc == 23, f"Expected exit 23, got {rc}"


@pytest.mark.e2e
def test_pipeline_different_seed(backend_exe, loader_exe, tmp_path):
    """Pipeline produces correct exit code with a non-default seed."""
    mc = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"
    bin_ = tmp_path / "simple_test.bin"

    compile_mc(mc, mcb)
    compile_backend(backend_exe, mcb, bin_, seed=2001)
    rc = run_loader(loader_exe, bin_)
    assert rc == 23, f"Expected exit 23 with seed=2001, got {rc}"


@pytest.mark.e2e
def test_two_programs_sequential(backend_exe, loader_exe, tmp_path):
    """Compile and run two programs in sequence to verify no global state leaks."""
    # First program: simple_test -> exit 23
    mc1 = EXAMPLES_DIR / "simple_test.mc"
    mcb1 = tmp_path / "simple_test.mcb"
    bin1 = tmp_path / "simple_test.bin"

    compile_mc(mc1, mcb1)
    compile_backend(backend_exe, mcb1, bin1)
    rc1 = run_loader(loader_exe, bin1)
    assert rc1 == 23, f"simple_test: expected exit 23, got {rc1}"

    # Second program: factorial -> exit 120
    mc2 = EXAMPLES_DIR / "factorial.mc"
    mcb2 = tmp_path / "factorial.mcb"
    bin2 = tmp_path / "factorial.bin"

    compile_mc(mc2, mcb2)
    compile_backend(backend_exe, mcb2, bin2)
    rc2 = run_loader(loader_exe, bin2)
    assert rc2 == 120, f"factorial: expected exit 120, got {rc2}"
