"""Self-hosting tests: backend compiles its own bytecode."""
import pytest

from tests.e2e.conftest import BACKEND_MCB, ALL_FLAGS, compile_backend, sha256


@pytest.mark.recompilation
def test_backend_compiles_own_mcb_no_transforms(backend_exe, tmp_path):
    """Backend compiles its own .mcb to PIC shellcode without transforms."""
    assert BACKEND_MCB.exists(), f"Backend MCB not found: {BACKEND_MCB}"

    out = tmp_path / "self.bin"
    compile_backend(backend_exe, BACKEND_MCB, out, seed=1001)

    assert out.exists(), "Output .bin was not created"
    assert out.stat().st_size > 0, "Output .bin is empty"


@pytest.mark.recompilation
def test_backend_compiles_own_mcb_all_transforms(backend_exe, tmp_path):
    """Backend compiles its own .mcb to PIC shellcode with all transforms."""
    assert BACKEND_MCB.exists(), f"Backend MCB not found: {BACKEND_MCB}"

    out = tmp_path / "self_all.bin"
    compile_backend(backend_exe, BACKEND_MCB, out, seed=1001, flags=ALL_FLAGS)

    assert out.exists(), "Output .bin was not created"
    assert out.stat().st_size > 0, "Output .bin is empty"


@pytest.mark.recompilation
def test_self_compiled_backend_is_polymorphic(backend_exe, tmp_path):
    """Two seeds produce different shellcode from the same backend .mcb."""
    assert BACKEND_MCB.exists(), f"Backend MCB not found: {BACKEND_MCB}"

    out_a = tmp_path / "self_1001.bin"
    out_b = tmp_path / "self_1002.bin"

    compile_backend(backend_exe, BACKEND_MCB, out_a, seed=1001, flags=ALL_FLAGS)
    compile_backend(backend_exe, BACKEND_MCB, out_b, seed=1002, flags=ALL_FLAGS)

    assert out_a.exists() and out_a.stat().st_size > 0
    assert out_b.exists() and out_b.stat().st_size > 0
    assert sha256(out_a) != sha256(out_b), \
        "Different seeds should produce different shellcode"
