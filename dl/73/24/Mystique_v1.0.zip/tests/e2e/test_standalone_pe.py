"""End-to-end tests for --pe-standalone output format."""
import hashlib
import struct
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e.conftest import (
    ROOT, BACKEND_EXE, PROGRAMS_DIR, ALL_FLAGS,
    compile_mc, sha256, ensure_built,
)

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.skipif(sys.platform != "win32", reason="PE standalone requires Windows"),
]

STRESS_MC = PROGRAMS_DIR / "compiler_stress.mc"
STANDALONE_MC = PROGRAMS_DIR / "standalone_test.mc"


def compile_pe_standalone(backend_exe, mcb, pe_out, seed=1001, flags=None):
    """Backend: .mcb -> standalone PE."""
    cmd = [str(backend_exe), str(mcb), "--pe-standalone", str(pe_out),
           "--seed", str(seed)]
    if flags:
        cmd.extend(flags)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(
            f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}")
    return pe_out


def run_pe(pe_path, timeout=30):
    """Run a PE and return (exit_code, stdout, stderr).

    Runs with cwd set to the PE's own directory so any side-effect files
    (e.g. _standalone_test_tmp.bin) land in tmp_path alongside it instead
    of polluting the project root."""
    r = subprocess.run(
        [str(pe_path)], capture_output=True, text=True, timeout=timeout,
        cwd=str(Path(pe_path).parent),
    )
    return r.returncode, r.stdout, r.stderr


class TestPeStandaloneBasic:
    """Basic standalone PE generation and execution."""

    def test_produces_valid_pe(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "stress.exe")
        data = pe.read_bytes()
        assert data[:2] == b"MZ", f"Expected MZ header, got {data[:2]!r}"
        assert len(data) > 512, f"PE too small: {len(data)} bytes"

    def test_runs_correctly(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "stress.exe")
        rc, out, err = run_pe(pe)
        assert rc == 0, f"Expected exit 0, got {rc}\nstdout: {out}\nstderr: {err}"
        assert "Total errors: 0" in out

    def test_all_transforms(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "stress.exe",
                                   seed=4242, flags=ALL_FLAGS)
        rc, out, err = run_pe(pe)
        assert rc == 0, f"Expected exit 0, got {rc}\nstdout: {out}\nstderr: {err}"
        assert "Total errors: 0" in out

    def test_determinism(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        pe1 = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "s1.exe", seed=1001)
        pe2 = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "s2.exe", seed=1001)
        assert sha256(pe1) == sha256(pe2), "Same seed should produce identical output"


class TestPeStandalonePolymorphism:
    """Polymorphic output across different seeds."""

    def test_different_seeds_produce_different_binaries(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        flags = ["--x86-poly-instrs", "--x86-dead-code"]
        hashes = []
        for seed in range(1001, 1006):
            pe = compile_pe_standalone(BACKEND_EXE, mcb,
                                       tmp_path / f"s_{seed}.exe",
                                       seed=seed, flags=flags)
            rc, _, _ = run_pe(pe)
            assert rc == 0, f"Seed {seed} failed with exit {rc}"
            hashes.append(sha256(pe))
        assert len(set(hashes)) == 5, f"Expected 5 unique, got {len(set(hashes))}"

    def test_stress_12_seeds_all_transforms(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        hashes = []
        for seed in range(1001, 1013):
            pe = compile_pe_standalone(BACKEND_EXE, mcb,
                                       tmp_path / f"s_{seed}.exe",
                                       seed=seed, flags=ALL_FLAGS)
            rc, _, _ = run_pe(pe)
            assert rc == 0, f"Seed {seed} failed with exit {rc}"
            hashes.append(sha256(pe))
        assert len(set(hashes)) == 12


class TestPeStandaloneBuiltins:
    """Test all kernel32 builtin wrappers via standalone_test.mc."""

    def test_builtins_no_transforms(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STANDALONE_MC, tmp_path / "st.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "st.exe")
        rc, out, err = run_pe(pe)
        assert rc == 42, f"Expected exit 42, got {rc}\nstdout: {out}"
        assert "0 failed" in out

    def test_builtins_all_transforms(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STANDALONE_MC, tmp_path / "st.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "st.exe",
                                   seed=3003, flags=ALL_FLAGS)
        rc, out, err = run_pe(pe)
        assert rc == 42, f"Expected exit 42, got {rc}\nstdout: {out}"
        assert "0 failed" in out


class TestPeStandaloneIdataValidation:
    """Validate PE .idata section structure."""

    def test_idata_structure(self, tmp_path):
        ensure_built()
        mcb = compile_mc(STRESS_MC, tmp_path / "stress.mcb")
        pe = compile_pe_standalone(BACKEND_EXE, mcb, tmp_path / "stress.exe")
        data = pe.read_bytes()

        # Parse PE header
        assert data[:2] == b"MZ"
        pe_off = struct.unpack_from("<I", data, 0x3C)[0]
        assert data[pe_off:pe_off+4] == b"PE\x00\x00"

        # COFF header
        num_sections = struct.unpack_from("<H", data, pe_off + 6)[0]
        assert num_sections == 3, f"Expected 3 sections, got {num_sections}"

        # Optional header
        opt_off = pe_off + 24
        magic = struct.unpack_from("<H", data, opt_off)[0]
        assert magic == 0x010B, f"Expected PE32 magic 0x010B, got 0x{magic:04X}"

        entry_rva = struct.unpack_from("<I", data, opt_off + 16)[0]
        image_base = struct.unpack_from("<I", data, opt_off + 28)[0]
        assert image_base == 0x00400000

        # Import data directory (index 1)
        imp_rva = struct.unpack_from("<I", data, opt_off + 96 + 8)[0]
        imp_size = struct.unpack_from("<I", data, opt_off + 96 + 12)[0]
        assert imp_rva > 0, "Import table RVA should be non-zero"
        assert imp_size > 0, "Import table size should be non-zero"

        # Find .idata section
        sh_base = pe_off + 24 + 224  # after optional header
        idata_sh = sh_base + 2 * 40  # third section
        idata_name = data[idata_sh:idata_sh+8].rstrip(b'\x00')
        assert idata_name == b".rdata", f"Third section should be .rdata, got {idata_name}"

        idata_rva = struct.unpack_from("<I", data, idata_sh + 12)[0]
        idata_rawptr = struct.unpack_from("<I", data, idata_sh + 20)[0]
        assert idata_rva == imp_rva, "Import RVA should match .idata RVA"

        # Walk IDT entries (20 bytes each, null-terminated)
        dll_names = []
        idt_off = idata_rawptr
        while True:
            ilt_rva = struct.unpack_from("<I", data, idt_off)[0]
            name_rva = struct.unpack_from("<I", data, idt_off + 12)[0]
            iat_rva = struct.unpack_from("<I", data, idt_off + 16)[0]
            if ilt_rva == 0 and name_rva == 0 and iat_rva == 0:
                break  # null terminator
            # Read DLL name
            name_off = idata_rawptr + (name_rva - idata_rva)
            name_end = data.index(b'\x00', name_off)
            dll_name = data[name_off:name_end].decode('ascii')
            dll_names.append(dll_name)
            assert ilt_rva > 0, f"ILT RVA should be non-zero for {dll_name}"
            assert iat_rva > 0, f"IAT RVA should be non-zero for {dll_name}"
            idt_off += 20

        assert len(dll_names) > 0, "Should have at least one DLL import"
        assert "kernel32.dll" in dll_names, f"Should import kernel32.dll, got {dll_names}"

        # Entry point should be within .text
        text_sh = sh_base
        text_rva = struct.unpack_from("<I", data, text_sh + 12)[0]
        text_vsize = struct.unpack_from("<I", data, text_sh + 8)[0]
        assert text_rva <= entry_rva < text_rva + text_vsize, \
            f"Entry RVA 0x{entry_rva:x} not in .text [0x{text_rva:x}..0x{text_rva+text_vsize:x})"
