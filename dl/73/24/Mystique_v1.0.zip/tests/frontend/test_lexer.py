"""Tests for the MystC lexer (tokenizer)."""
import pytest

from compiler.frontend.tokens import Token, TokenType
from compiler.frontend.lexer import tokenize


# ---------------------------------------------------------------------------
# Integer literals
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_integer_literal_decimal():
    tokens = tokenize("42")
    assert tokens[0].type == TokenType.INT_LIT
    assert tokens[0].value == 42


@pytest.mark.frontend
def test_integer_literal_zero():
    tokens = tokenize("0")
    assert tokens[0].type == TokenType.INT_LIT
    assert tokens[0].value == 0


@pytest.mark.frontend
def test_integer_literal_hex():
    tokens = tokenize("0xFF")
    assert tokens[0].type == TokenType.INT_LIT
    assert tokens[0].value == 255


@pytest.mark.frontend
def test_integer_literal_hex_zero():
    tokens = tokenize("0x0")
    assert tokens[0].type == TokenType.INT_LIT
    assert tokens[0].value == 0


# ---------------------------------------------------------------------------
# Character literals
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_char_literal_simple():
    tokens = tokenize("'a'")
    assert tokens[0].type == TokenType.CHAR_LIT
    assert tokens[0].value == ord('a')


@pytest.mark.frontend
def test_char_literal_escape_newline():
    tokens = tokenize("'\\n'")
    assert tokens[0].type == TokenType.CHAR_LIT
    assert tokens[0].value == ord('\n')


@pytest.mark.frontend
def test_char_literal_escape_null():
    tokens = tokenize("'\\0'")
    assert tokens[0].type == TokenType.CHAR_LIT
    assert tokens[0].value == 0


# ---------------------------------------------------------------------------
# String literals
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_string_literal_simple():
    tokens = tokenize('"hello"')
    assert tokens[0].type == TokenType.STRING_LIT
    assert tokens[0].value == "hello"


@pytest.mark.frontend
def test_string_literal_empty():
    tokens = tokenize('""')
    assert tokens[0].type == TokenType.STRING_LIT
    assert tokens[0].value == ""


@pytest.mark.frontend
def test_string_literal_with_escape():
    tokens = tokenize('"line1\\nline2"')
    assert tokens[0].type == TokenType.STRING_LIT
    assert tokens[0].value == "line1\nline2"


# ---------------------------------------------------------------------------
# Keywords
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_all_keywords():
    keywords = {
        "int": TokenType.INT,
        "char": TokenType.CHAR,
        "void": TokenType.VOID,
        "struct": TokenType.STRUCT,
        "if": TokenType.IF,
        "else": TokenType.ELSE,
        "while": TokenType.WHILE,
        "for": TokenType.FOR,
        "return": TokenType.RETURN,
        "break": TokenType.BREAK,
        "continue": TokenType.CONTINUE,
        "sizeof": TokenType.SIZEOF,
        "extern": TokenType.EXTERN,
        "emit": TokenType.EMIT,
    }
    for word, expected_type in keywords.items():
        tokens = tokenize(word)
        assert tokens[0].type == expected_type, f"'{word}' should be {expected_type}"
        assert tokens[0].value == word


@pytest.mark.frontend
def test_identifier_not_keyword():
    tokens = tokenize("foobar")
    assert tokens[0].type == TokenType.IDENT
    assert tokens[0].value == "foobar"


# ---------------------------------------------------------------------------
# Single-character operators
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_single_char_operators():
    ops = {
        "+": TokenType.PLUS,
        "-": TokenType.MINUS,
        "*": TokenType.STAR,
        "/": TokenType.SLASH,
        "%": TokenType.PERCENT,
        "&": TokenType.AMP,
        "|": TokenType.PIPE,
        "^": TokenType.CARET,
        "~": TokenType.TILDE,
        "!": TokenType.BANG,
        "<": TokenType.LT,
        ">": TokenType.GT,
        "=": TokenType.EQ,
        ".": TokenType.DOT,
    }
    for ch, expected_type in ops.items():
        # Surround with spaces to avoid forming two-char tokens
        tokens = tokenize(f"x {ch} y")
        assert tokens[1].type == expected_type, f"'{ch}' should be {expected_type}"


# ---------------------------------------------------------------------------
# Two-character operators
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_two_char_operators():
    ops = {
        "++": TokenType.PLUS_PLUS,
        "--": TokenType.MINUS_MINUS,
        "<<": TokenType.LT_LT,
        ">>": TokenType.GT_GT,
        "&&": TokenType.AMP_AMP,
        "||": TokenType.PIPE_PIPE,
        "==": TokenType.EQ_EQ,
        "!=": TokenType.BANG_EQ,
        "<=": TokenType.LT_EQ,
        ">=": TokenType.GT_EQ,
        "+=": TokenType.PLUS_EQ,
        "-=": TokenType.MINUS_EQ,
    }
    for op, expected_type in ops.items():
        tokens = tokenize(op)
        assert tokens[0].type == expected_type, f"'{op}' should be {expected_type}"
        assert tokens[0].value == op


@pytest.mark.frontend
def test_operator_arrow():
    tokens = tokenize("ptr->field")
    assert tokens[0].type == TokenType.IDENT
    assert tokens[0].value == "ptr"
    assert tokens[1].type == TokenType.ARROW
    assert tokens[1].value == "->"
    assert tokens[2].type == TokenType.IDENT
    assert tokens[2].value == "field"


# ---------------------------------------------------------------------------
# Punctuation
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_punctuation():
    tokens = tokenize("( ) [ ] { } ; ,")
    expected = [
        TokenType.LPAREN, TokenType.RPAREN,
        TokenType.LBRACKET, TokenType.RBRACKET,
        TokenType.LBRACE, TokenType.RBRACE,
        TokenType.SEMICOLON, TokenType.COMMA,
        TokenType.EOF,
    ]
    assert [t.type for t in tokens] == expected


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_line_comment_ignored():
    tokens = tokenize("x // this is a comment\ny")
    types = [t.type for t in tokens]
    assert types == [TokenType.IDENT, TokenType.IDENT, TokenType.EOF]
    assert tokens[0].value == "x"
    assert tokens[1].value == "y"


@pytest.mark.frontend
def test_block_comment_ignored():
    tokens = tokenize("a /* block comment */ b")
    types = [t.type for t in tokens]
    assert types == [TokenType.IDENT, TokenType.IDENT, TokenType.EOF]
    assert tokens[0].value == "a"
    assert tokens[1].value == "b"


# ---------------------------------------------------------------------------
# Whitespace handling
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_whitespace_tabs_and_newlines():
    tokens = tokenize("\t\n\n  x  \t\n  y\n")
    types = [t.type for t in tokens]
    assert types == [TokenType.IDENT, TokenType.IDENT, TokenType.EOF]


# ---------------------------------------------------------------------------
# Line/column tracking
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_line_column_tracking():
    source = "int x;\nreturn 0;"
    tokens = tokenize(source)
    # 'int' at line 1, column 1
    assert tokens[0].line == 1
    assert tokens[0].column == 1
    # 'x' at line 1, column 5
    assert tokens[1].line == 1
    assert tokens[1].column == 5
    # ';' at line 1, column 6
    assert tokens[2].line == 1
    assert tokens[2].column == 6
    # 'return' at line 2, column 1
    assert tokens[3].line == 2
    assert tokens[3].column == 1
    # '0' at line 2, column 8
    assert tokens[4].line == 2
    assert tokens[4].column == 8


# ---------------------------------------------------------------------------
# Error tokens
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_error_unterminated_string():
    tokens = tokenize('"hello')
    assert tokens[-1].type == TokenType.ERROR


@pytest.mark.frontend
def test_error_invalid_character():
    tokens = tokenize("$")
    assert tokens[0].type == TokenType.ERROR


# ---------------------------------------------------------------------------
# Empty input
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_empty_input():
    tokens = tokenize("")
    assert len(tokens) == 1
    assert tokens[0].type == TokenType.EOF
