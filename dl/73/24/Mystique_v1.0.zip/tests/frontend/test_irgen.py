"""Tests for IR generation (parse -> typecheck -> generate_ir)."""

import pytest

from compiler.frontend.parser import parse
from compiler.frontend.typecheck import typecheck
from compiler.frontend.irgen import generate_ir
from compiler.frontend.bytecode import MCProgram, Opcode, ValueKind, TypeCode


def compile_to_ir(source: str) -> MCProgram:
    """Helper: full pipeline from source string to MCProgram."""
    program = parse(source)
    success, symbols, errors = typecheck(program)
    if not success:
        raise RuntimeError(f"Typecheck failed: {errors}")
    return generate_ir(program, symbols)


def _all_opcodes(mc: MCProgram) -> set:
    """Collect every opcode used across all functions/blocks."""
    ops = set()
    for func in mc.functions:
        for block in func.blocks:
            for instr in block.instructions:
                ops.add(instr.opcode)
    return ops


def _func_opcodes(func) -> set:
    """Collect every opcode used in a single function."""
    ops = set()
    for block in func.blocks:
        for instr in block.instructions:
            ops.add(instr.opcode)
    return ops


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_simple_function_blocks_and_instructions():
    """A minimal function should produce at least one block with instructions."""
    mc = compile_to_ir("int main() { return 0; }")
    main = [f for f in mc.functions if f.name == "main"]
    assert len(main) == 1
    assert len(main[0].blocks) >= 1
    total_instrs = sum(len(b.instructions) for b in main[0].blocks)
    assert total_instrs >= 1


@pytest.mark.frontend
def test_arithmetic_opcodes():
    """Arithmetic expressions should produce ADD, SUB, MUL, DIV opcodes."""
    src = """
    int main() {
        int a;
        a = 1 + 2 - 3 * 4 / 5;
        return a;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    assert Opcode.ADD in ops
    assert Opcode.SUB in ops
    assert Opcode.MUL in ops
    assert Opcode.DIV in ops


@pytest.mark.frontend
def test_comparison_opcodes():
    """Comparison operators should generate the corresponding opcodes."""
    src = """
    int main() {
        int a; int b; int c;
        a = 1; b = 2;
        c = (a == b) + (a != b) + (a < b) + (a <= b) + (a > b) + (a >= b);
        return c;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    for op in (Opcode.EQ, Opcode.NE, Opcode.LT, Opcode.LE, Opcode.GT, Opcode.GE):
        assert op in ops, f"Expected {op.name} in generated opcodes"


@pytest.mark.frontend
def test_if_else_generates_jz_and_jmp():
    """An if/else should produce JZ (conditional branch) and JMP."""
    src = """
    int main() {
        int x;
        x = 1;
        if (x) {
            x = 2;
        } else {
            x = 3;
        }
        return x;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    assert Opcode.JZ in ops or Opcode.JNZ in ops, "Expected a conditional jump"
    assert Opcode.JMP in ops, "Expected an unconditional jump"


@pytest.mark.frontend
def test_while_loop_generates_jz_and_jmp():
    """A while loop needs a back-edge JMP and a conditional JZ/JNZ."""
    src = """
    int main() {
        int i;
        i = 10;
        while (i > 0) {
            i = i - 1;
        }
        return i;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    assert Opcode.JZ in ops or Opcode.JNZ in ops, "Expected a conditional jump for loop test"
    assert Opcode.JMP in ops, "Expected an unconditional jump for loop back-edge"


@pytest.mark.frontend
def test_function_call_generates_call_opcode():
    """Calling a function that returns a value should emit CALL."""
    src = """
    int add(int a, int b) { return a + b; }
    int main() {
        int r;
        r = add(1, 2);
        return r;
    }
    """
    mc = compile_to_ir(src)
    main = [f for f in mc.functions if f.name == "main"][0]
    ops = _func_opcodes(main)
    assert Opcode.CALL in ops or Opcode.CALLV in ops, "Expected CALL or CALLV opcode"


@pytest.mark.frontend
def test_pointer_operations():
    """Pointer dereference and address-of should generate LOAD, STORE, ADDR."""
    src = """
    int main() {
        int x;
        int* p;
        x = 42;
        p = &x;
        *p = 10;
        return *p;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    assert Opcode.ADDR in ops, "Expected ADDR for address-of"
    assert Opcode.STORE in ops, "Expected STORE for pointer write"
    assert Opcode.LOAD in ops, "Expected LOAD for pointer read"


@pytest.mark.frontend
def test_global_variable():
    """A global variable should appear in mc.globals and generate LOAD/STORE."""
    src = """
    int g;
    int main() {
        g = 42;
        return g;
    }
    """
    mc = compile_to_ir(src)
    assert len(mc.globals) >= 1
    names = [gl.name for gl in mc.globals]
    assert "g" in names


@pytest.mark.frontend
def test_struct_field_access_generates_fieldptr():
    """Accessing a struct field should generate FIELDPTR."""
    src = """
    struct Point { int x; int y; };
    int main() {
        struct Point p;
        p.x = 10;
        p.y = 20;
        return p.x + p.y;
    }
    """
    mc = compile_to_ir(src)
    ops = _all_opcodes(mc)
    assert Opcode.FIELDPTR in ops, "Expected FIELDPTR for struct field access"


@pytest.mark.frontend
def test_string_literal_in_strings_table():
    """A string literal should be recorded in mc.strings."""
    src = """
    int main() {
        char* s;
        s = "hello world";
        return 0;
    }
    """
    mc = compile_to_ir(src)
    assert "hello world" in mc.strings


@pytest.mark.frontend
def test_extern_function():
    """An extern declaration should produce a function marked is_extern."""
    src = """
    extern "kernel32.dll" int GetTickCount();
    int main() {
        return 0;
    }
    """
    mc = compile_to_ir(src)
    ext = [f for f in mc.functions if f.name == "GetTickCount"]
    assert len(ext) == 1
    assert ext[0].is_extern is True
    assert ext[0].dll == "kernel32.dll"


@pytest.mark.frontend
def test_no_builtins():
    """Without extern declarations, no builtin functions are auto-registered."""
    mc = compile_to_ir("int main() { return 0; }")
    func_names = [f.name for f in mc.functions]
    assert "malloc" not in func_names
    assert "free" not in func_names
    assert "write" not in func_names


@pytest.mark.frontend
def test_multiple_functions():
    """All user-defined functions should appear in mc.functions."""
    src = """
    int foo() { return 1; }
    int bar() { return 2; }
    int main() { return foo() + bar(); }
    """
    mc = compile_to_ir(src)
    func_names = [f.name for f in mc.functions]
    assert "foo" in func_names
    assert "bar" in func_names
    assert "main" in func_names


@pytest.mark.frontend
def test_return_value_generates_ret():
    """A function returning a value should use RET (return with value)."""
    src = "int main() { return 42; }"
    mc = compile_to_ir(src)
    main = [f for f in mc.functions if f.name == "main"][0]
    ops = _func_opcodes(main)
    assert Opcode.RET in ops, "Expected RET opcode for return with value"


@pytest.mark.frontend
def test_void_return_generates_retv():
    """A void function should use RETV (void return)."""
    src = """
    void do_nothing() { return; }
    int main() { do_nothing(); return 0; }
    """
    mc = compile_to_ir(src)
    fn = [f for f in mc.functions if f.name == "do_nothing"][0]
    ops = _func_opcodes(fn)
    assert Opcode.RETV in ops, "Expected RETV opcode for void return"
