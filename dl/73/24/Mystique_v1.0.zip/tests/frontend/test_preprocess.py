"""Tests for the MystC preprocessor (#include, #ifdef, #define)."""

import os
import pytest
from compiler.frontend.mystcc import preprocess, compile_file


class TestInclude:
    """Tests for #include directive."""

    def test_basic_include(self, tmp_path):
        """A includes B, merged output contains B's content."""
        (tmp_path / "b.mc").write_text("int x;\n")
        (tmp_path / "a.mc").write_text('#include "b.mc"\nint y;\n')

        result = preprocess(
            '#include "b.mc"\nint y;\n',
            str(tmp_path / "a.mc"))

        assert "int x;" in result
        assert "int y;" in result

    def test_recursive_include(self, tmp_path):
        """A includes B, B includes C."""
        (tmp_path / "c.mc").write_text("int z;\n")
        (tmp_path / "b.mc").write_text('#include "c.mc"\nint y;\n')
        (tmp_path / "a.mc").write_text('#include "b.mc"\nint x;\n')

        result = preprocess(
            '#include "b.mc"\nint x;\n',
            str(tmp_path / "a.mc"))

        assert "int z;" in result
        assert "int y;" in result
        assert "int x;" in result

    def test_cycle_guard(self, tmp_path):
        """A includes B, B includes A — no infinite recursion."""
        (tmp_path / "b.mc").write_text('#include "a.mc"\nint y;\n')
        (tmp_path / "a.mc").write_text('#include "b.mc"\nint x;\n')

        result = preprocess(
            '#include "b.mc"\nint x;\n',
            str(tmp_path / "a.mc"))

        assert "int y;" in result
        assert "int x;" in result

    def test_diamond_include(self, tmp_path):
        """A includes B and C, both include D — D appears once."""
        (tmp_path / "d.mc").write_text("int d_var;\n")
        (tmp_path / "b.mc").write_text('#include "d.mc"\nint b_var;\n')
        (tmp_path / "c.mc").write_text('#include "d.mc"\nint c_var;\n')
        (tmp_path / "a.mc").write_text('#include "b.mc"\n#include "c.mc"\nint a_var;\n')

        result = preprocess(
            '#include "b.mc"\n#include "c.mc"\nint a_var;\n',
            str(tmp_path / "a.mc"))

        assert result.count("int d_var;") == 1
        assert "int b_var;" in result
        assert "int c_var;" in result

    def test_file_not_found(self, tmp_path):
        """Missing include file raises clear error."""
        (tmp_path / "a.mc").write_text('#include "nonexistent.mc"\n')

        with pytest.raises(RuntimeError, match="cannot find 'nonexistent.mc'"):
            preprocess('#include "nonexistent.mc"\n', str(tmp_path / "a.mc"))

    def test_relative_path(self, tmp_path):
        """Include from subdirectory resolves relative to including file."""
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "helper.mc").write_text("int helper;\n")
        (tmp_path / "main.mc").write_text('#include "sub/helper.mc"\nint main_var;\n')

        result = preprocess(
            '#include "sub/helper.mc"\nint main_var;\n',
            str(tmp_path / "main.mc"))

        assert "int helper;" in result
        assert "int main_var;" in result


class TestIfdef:
    """Tests for #ifdef / #ifndef / #else / #endif."""

    def test_ifdef_true(self):
        """Defined symbol → include block."""
        source = "#ifdef FOO\nint x;\n#endif\n"
        result = preprocess(source, "test.mc", defines={"FOO"})
        assert "int x;" in result

    def test_ifdef_false(self):
        """Undefined symbol → exclude block."""
        source = "#ifdef FOO\nint x;\n#endif\n"
        result = preprocess(source, "test.mc", defines=set())
        assert "int x;" not in result

    def test_ifdef_else(self):
        """#else branch works."""
        source = "#ifdef FOO\nint x;\n#else\nint y;\n#endif\n"
        result = preprocess(source, "test.mc", defines=set())
        assert "int x;" not in result
        assert "int y;" in result

    def test_ifndef(self):
        """#ifndef — inverse logic."""
        source = "#ifndef FOO\nint x;\n#endif\n"
        result = preprocess(source, "test.mc", defines=set())
        assert "int x;" in result

        result2 = preprocess(source, "test.mc", defines={"FOO"})
        assert "int x;" not in result2

    def test_nested_ifdef(self):
        """Nested conditionals."""
        source = "#ifdef A\n#ifdef B\nint both;\n#endif\nint a_only;\n#endif\n"

        result = preprocess(source, "test.mc", defines={"A", "B"})
        assert "int both;" in result
        assert "int a_only;" in result

        result2 = preprocess(source, "test.mc", defines={"A"})
        assert "int both;" not in result2
        assert "int a_only;" in result2

        result3 = preprocess(source, "test.mc", defines=set())
        assert "int both;" not in result3
        assert "int a_only;" not in result3

    def test_preserves_line_numbers(self):
        """False branch lines replaced with empty lines — line count unchanged."""
        source = "line1\n#ifdef FOO\nskipped\nskipped2\n#endif\nline5\n"
        result = preprocess(source, "test.mc", defines=set())
        lines = result.split('\n')
        assert lines[0] == "line1"
        assert lines[1] == ""  # #ifdef
        assert lines[2] == ""  # skipped
        assert lines[3] == ""  # skipped2
        assert lines[4] == ""  # #endif
        assert lines[5] == "line5"


class TestDefine:
    """Tests for #define directive."""

    def test_define_from_source(self):
        """#define in source file."""
        source = "#define FOO\n#ifdef FOO\nint x;\n#endif\n"
        result = preprocess(source, "test.mc")
        assert "int x;" in result

    def test_define_from_cli(self):
        """Define passed via CLI."""
        source = "#ifdef WIN32\nint x;\n#endif\n"
        result = preprocess(source, "test.mc", defines={"WIN32"})
        assert "int x;" in result

    def test_define_in_included_file(self, tmp_path):
        """Define in included file visible to includer."""
        (tmp_path / "defs.mc").write_text("#define FEATURE_X\n")
        source = '#include "defs.mc"\n#ifdef FEATURE_X\nint x;\n#endif\n'
        (tmp_path / "main.mc").write_text(source)

        result = preprocess(source, str(tmp_path / "main.mc"))
        assert "int x;" in result


class TestCombined:
    """Tests combining #include and #ifdef."""

    def test_include_inside_ifdef(self, tmp_path):
        """Conditional include."""
        (tmp_path / "win.mc").write_text("int win_api;\n")
        (tmp_path / "main.mc").write_text(
            '#ifdef WIN32\n#include "win.mc"\n#endif\nint main;\n')

        result = preprocess(
            '#ifdef WIN32\n#include "win.mc"\n#endif\nint main;\n',
            str(tmp_path / "main.mc"), defines={"WIN32"})
        assert "int win_api;" in result

        result2 = preprocess(
            '#ifdef WIN32\n#include "win.mc"\n#endif\nint main;\n',
            str(tmp_path / "main.mc"), defines={"LINUX"})
        assert "int win_api;" not in result2

    def test_ifdef_in_included_file(self, tmp_path):
        """Included file uses caller's defines."""
        (tmp_path / "platform.mc").write_text(
            "#ifdef WIN32\nint win;\n#endif\n#ifdef LINUX\nint lin;\n#endif\n")
        source = '#include "platform.mc"\n'
        (tmp_path / "main.mc").write_text(source)

        result = preprocess(source, str(tmp_path / "main.mc"), defines={"WIN32"})
        assert "int win;" in result
        assert "int lin;" not in result


class TestPassthrough:
    """Test that source without directives passes through unchanged."""

    def test_no_directives(self):
        """Source without preprocessor directives unchanged."""
        source = "int main() {\n    return 42;\n}\n"
        result = preprocess(source, "test.mc")
        assert result == source


class TestFullPipeline:
    """Test that #include works through the full compilation pipeline."""

    def test_compile_with_include(self, tmp_path):
        """Multi-file program compiles to correct .mcb."""
        (tmp_path / "helper.mc").write_text(
            "int add(int a, int b) {\n    return a + b;\n}\n")
        (tmp_path / "main.mc").write_text(
            '#include "helper.mc"\n'
            "int main() {\n    return add(1, 2);\n}\n")

        mcb_path = str(tmp_path / "out.mcb")
        success = compile_file(str(tmp_path / "main.mc"), mcb_path)
        assert success
        assert os.path.exists(mcb_path)
        # Verify .mcb has correct magic
        with open(mcb_path, 'rb') as f:
            magic = f.read(4)
        assert magic == b'MCBN'
