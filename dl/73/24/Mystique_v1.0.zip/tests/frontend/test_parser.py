"""Tests for the MystC parser."""
import pytest

from compiler.frontend.parser import parse
from compiler.frontend import mystc_ast as ast


# ---------------------------------------------------------------------------
# Function declarations
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_void_function_empty_body():
    prog = parse("void main() {}")
    assert len(prog.functions) == 1
    fn = prog.functions[0]
    assert fn.name == "main"
    assert isinstance(fn.return_type, ast.PrimitiveType)
    assert fn.return_type.base == ast.BaseType.VOID
    assert fn.params == []
    assert isinstance(fn.body, ast.Block)
    assert fn.body.stmts == []


@pytest.mark.frontend
def test_int_function_with_params():
    prog = parse("int add(int a, int b) { return a; }")
    fn = prog.functions[0]
    assert fn.name == "add"
    assert fn.return_type.base == ast.BaseType.INT
    assert len(fn.params) == 2
    assert fn.params[0].name == "a"
    assert isinstance(fn.params[0].type, ast.PrimitiveType)
    assert fn.params[0].type.base == ast.BaseType.INT
    assert fn.params[1].name == "b"


@pytest.mark.frontend
def test_function_pointer_param():
    prog = parse("void write(char* buf) {}")
    fn = prog.functions[0]
    assert len(fn.params) == 1
    p = fn.params[0]
    assert p.name == "buf"
    assert isinstance(p.type, ast.PointerType)
    assert isinstance(p.type.pointee, ast.PrimitiveType)
    assert p.type.pointee.base == ast.BaseType.CHAR


# ---------------------------------------------------------------------------
# Variable declarations
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_local_int_decl():
    prog = parse("void f() { int x; }")
    stmts = prog.functions[0].body.stmts
    assert len(stmts) == 1
    assert isinstance(stmts[0], ast.DeclStmt)
    decl = stmts[0].decl
    assert isinstance(decl, ast.VarDecl)
    assert decl.name == "x"
    assert isinstance(decl.type, ast.PrimitiveType)
    assert decl.type.base == ast.BaseType.INT
    assert decl.init is None
    assert decl.array_size is None


@pytest.mark.frontend
def test_local_char_decl_with_init():
    prog = parse("void f() { char c = 65; }")
    decl = prog.functions[0].body.stmts[0].decl
    assert decl.name == "c"
    assert decl.type.base == ast.BaseType.CHAR
    assert isinstance(decl.init, ast.IntLiteral)
    assert decl.init.value == 65


@pytest.mark.frontend
def test_local_pointer_decl():
    prog = parse("void f() { int* p; }")
    decl = prog.functions[0].body.stmts[0].decl
    assert decl.name == "p"
    assert isinstance(decl.type, ast.PointerType)
    assert decl.type.pointee.base == ast.BaseType.INT


@pytest.mark.frontend
def test_local_array_decl():
    prog = parse("void f() { int x[10]; }")
    decl = prog.functions[0].body.stmts[0].decl
    assert decl.name == "x"
    assert decl.array_size == 10


# ---------------------------------------------------------------------------
# Struct definitions
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_struct_def():
    prog = parse("struct Point { int x; int y; };")
    assert len(prog.structs) == 1
    s = prog.structs[0]
    assert isinstance(s, ast.StructDef)
    assert s.name == "Point"
    assert len(s.fields) == 2
    assert s.fields[0].name == "x"
    assert isinstance(s.fields[0].type, ast.PrimitiveType)
    assert s.fields[0].type.base == ast.BaseType.INT
    assert s.fields[1].name == "y"


@pytest.mark.frontend
def test_struct_field_array():
    prog = parse("struct Buf { char data[256]; };")
    field = prog.structs[0].fields[0]
    assert field.name == "data"
    assert field.type.base == ast.BaseType.CHAR
    assert field.array_size == 256


# ---------------------------------------------------------------------------
# Extern declarations
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_extern_with_dll():
    prog = parse('extern "kernel32.dll" int GetTickCount();')
    assert len(prog.externs) == 1
    ext = prog.externs[0]
    assert isinstance(ext, ast.ExternDecl)
    assert ext.name == "GetTickCount"
    assert ext.dll == "kernel32.dll"
    assert ext.return_type.base == ast.BaseType.INT
    assert ext.params == []


@pytest.mark.frontend
def test_extern_with_params():
    prog = parse('extern "user32.dll" int MessageBoxA(int hwnd, char* text, char* cap, int type);')
    ext = prog.externs[0]
    assert ext.name == "MessageBoxA"
    assert ext.dll == "user32.dll"
    assert len(ext.params) == 4
    assert ext.params[1].name == "text"
    assert isinstance(ext.params[1].type, ast.PointerType)


# ---------------------------------------------------------------------------
# Expressions — binary ops and precedence
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_binary_add_mul_precedence():
    """a + b * c  =>  ADD(a, MUL(b, c)) — MUL should be deeper."""
    prog = parse("void f() { a + b * c; }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.BinaryExpr)
    assert expr.op == ast.BinOp.ADD
    assert isinstance(expr.left, ast.Identifier)
    assert expr.left.name == "a"
    assert isinstance(expr.right, ast.BinaryExpr)
    assert expr.right.op == ast.BinOp.MUL


@pytest.mark.frontend
def test_binary_comparison():
    prog = parse("void f() { a == b; }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.BinaryExpr)
    assert expr.op == ast.BinOp.EQ


@pytest.mark.frontend
def test_assignment_expr():
    prog = parse("void f() { x = 42; }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.BinaryExpr)
    assert expr.op == ast.BinOp.ASSIGN
    assert isinstance(expr.left, ast.Identifier)
    assert isinstance(expr.right, ast.IntLiteral)
    assert expr.right.value == 42


# ---------------------------------------------------------------------------
# Expressions — unary ops
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_unary_negation():
    prog = parse("void f() { -x; }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.UnaryExpr)
    assert expr.op == ast.UnaryOp.NEG
    assert isinstance(expr.operand, ast.Identifier)


@pytest.mark.frontend
def test_unary_deref_and_addr():
    prog = parse("void f() { *p; &x; }")
    stmts = prog.functions[0].body.stmts
    deref = stmts[0].expr
    assert isinstance(deref, ast.UnaryExpr)
    assert deref.op == ast.UnaryOp.DEREF

    addr = stmts[1].expr
    assert isinstance(addr, ast.UnaryExpr)
    assert addr.op == ast.UnaryOp.ADDR


@pytest.mark.frontend
def test_pre_post_increment():
    prog = parse("void f() { ++i; i++; }")
    stmts = prog.functions[0].body.stmts
    pre = stmts[0].expr
    assert isinstance(pre, ast.UnaryExpr)
    assert pre.op == ast.UnaryOp.PRE_INC

    post = stmts[1].expr
    assert isinstance(post, ast.UnaryExpr)
    assert post.op == ast.UnaryOp.POST_INC


# ---------------------------------------------------------------------------
# Function calls, member access, indexing, sizeof
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_function_call():
    prog = parse("void f() { foo(a, b); }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.CallExpr)
    assert expr.func == "foo"
    assert len(expr.args) == 2
    assert isinstance(expr.args[0], ast.Identifier)
    assert expr.args[0].name == "a"
    assert expr.args[1].name == "b"


@pytest.mark.frontend
def test_member_access_dot_and_arrow():
    prog = parse("void f() { a.x; p->y; }")
    stmts = prog.functions[0].body.stmts
    dot = stmts[0].expr
    assert isinstance(dot, ast.MemberExpr)
    assert dot.member == "x"
    assert dot.is_arrow is False

    arrow = stmts[1].expr
    assert isinstance(arrow, ast.MemberExpr)
    assert arrow.member == "y"
    assert arrow.is_arrow is True


@pytest.mark.frontend
def test_array_indexing():
    prog = parse("void f() { a[i]; }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.IndexExpr)
    assert isinstance(expr.base, ast.Identifier)
    assert expr.base.name == "a"
    assert isinstance(expr.index, ast.Identifier)
    assert expr.index.name == "i"


@pytest.mark.frontend
def test_sizeof_primitive():
    prog = parse("void f() { sizeof(int); }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.SizeofExpr)
    assert isinstance(expr.target_type, ast.PrimitiveType)
    assert expr.target_type.base == ast.BaseType.INT


@pytest.mark.frontend
def test_sizeof_struct():
    prog = parse("struct Foo { int a; }; void f() { sizeof(struct Foo); }")
    expr = prog.functions[0].body.stmts[0].expr
    assert isinstance(expr, ast.SizeofExpr)
    assert isinstance(expr.target_type, ast.StructType)
    assert expr.target_type.name == "Foo"


# ---------------------------------------------------------------------------
# Statements
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_if_else():
    prog = parse("void f() { if (x) { return 1; } else { return 0; } }")
    stmt = prog.functions[0].body.stmts[0]
    assert isinstance(stmt, ast.IfStmt)
    assert isinstance(stmt.cond, ast.Identifier)
    assert isinstance(stmt.then_branch, ast.Block)
    assert stmt.else_branch is not None
    assert isinstance(stmt.else_branch, ast.Block)


@pytest.mark.frontend
def test_while_stmt():
    prog = parse("void f() { while (i) { i = i - 1; } }")
    stmt = prog.functions[0].body.stmts[0]
    assert isinstance(stmt, ast.WhileStmt)
    assert isinstance(stmt.cond, ast.Identifier)
    assert isinstance(stmt.body, ast.Block)


@pytest.mark.frontend
def test_for_stmt():
    prog = parse("void f() { for (i = 0; i < 10; i = i + 1) { x = i; } }")
    stmt = prog.functions[0].body.stmts[0]
    assert isinstance(stmt, ast.ForStmt)
    assert isinstance(stmt.init, ast.BinaryExpr)
    assert stmt.init.op == ast.BinOp.ASSIGN
    assert isinstance(stmt.cond, ast.BinaryExpr)
    assert stmt.cond.op == ast.BinOp.LT
    assert isinstance(stmt.step, ast.BinaryExpr)
    assert isinstance(stmt.body, ast.Block)


@pytest.mark.frontend
def test_return_value():
    prog = parse("int f() { return 42; }")
    stmt = prog.functions[0].body.stmts[0]
    assert isinstance(stmt, ast.ReturnStmt)
    assert isinstance(stmt.value, ast.IntLiteral)
    assert stmt.value.value == 42


@pytest.mark.frontend
def test_break_continue():
    prog = parse("void f() { while (1) { break; continue; } }")
    body = prog.functions[0].body.stmts[0].body
    assert isinstance(body.stmts[0], ast.BreakStmt)
    assert isinstance(body.stmts[1], ast.ContinueStmt)


@pytest.mark.frontend
def test_block_nesting():
    prog = parse("void f() { { int a; } }")
    outer = prog.functions[0].body
    assert len(outer.stmts) == 1
    inner = outer.stmts[0]
    assert isinstance(inner, ast.Block)
    assert len(inner.stmts) == 1
    assert isinstance(inner.stmts[0], ast.DeclStmt)


# ---------------------------------------------------------------------------
# Emit statement
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_emit_stmt():
    prog = parse("void f() { emit 0x90, 0xCC; }")
    stmt = prog.functions[0].body.stmts[0]
    assert isinstance(stmt, ast.EmitStmt)
    assert stmt.emit_bytes == [0x90, 0xCC]


# ---------------------------------------------------------------------------
# Program-level: multiple functions, globals
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_multiple_functions():
    src = """
    int helper() { return 1; }
    int main() { return helper(); }
    """
    prog = parse(src)
    assert len(prog.functions) == 2
    assert prog.functions[0].name == "helper"
    assert prog.functions[1].name == "main"


@pytest.mark.frontend
def test_global_variable():
    prog = parse("int counter; void f() {}")
    assert len(prog.globals) == 1
    g = prog.globals[0]
    assert isinstance(g, ast.VarDecl)
    assert g.name == "counter"
    assert isinstance(g.type, ast.PrimitiveType)
    assert g.type.base == ast.BaseType.INT
    assert len(prog.functions) == 1
