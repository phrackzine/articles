"""Frontend test fixtures and helpers."""
import pytest

from compiler.frontend.tokens import Token, TokenType
from compiler.frontend.lexer import Lexer, tokenize
from compiler.frontend.parser import Parser, parse, ParseError
from compiler.frontend import mystc_ast as ast
from compiler.frontend.typecheck import TypeChecker, typecheck
from compiler.frontend.irgen import generate_ir
from compiler.frontend.bytecode import MCProgram, write_bytecode, read_bytecode, write_text


def compile_source(source: str) -> MCProgram:
    """Full pipeline: source string -> MCProgram (no file I/O)."""
    program = parse(source)
    success, symbols, errors = typecheck(program)
    if not success:
        raise RuntimeError(f"Typecheck failed: {errors}")
    return generate_ir(program, symbols)


def compile_to_mcb(source: str, tmp_path) -> str:
    """Full pipeline: source string -> .mcb file path."""
    mc_prog = compile_source(source)
    mcb_path = str(tmp_path / "test.mcb")
    write_bytecode(mc_prog, mcb_path)
    return mcb_path
