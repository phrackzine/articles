"""Tests for MystC bytecode serialization (.mcb / .mct)."""
import pytest

from tests.frontend.conftest import compile_source
from compiler.frontend.bytecode import write_bytecode, read_bytecode, write_text


def compile_to_ir(source: str):
    """Shorthand: source string -> MCProgram (no file I/O)."""
    return compile_source(source)


# ---------------------------------------------------------------------------
# .mcb magic bytes
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_starts_with_magic_bytes(tmp_path):
    mc = compile_to_ir("int main() { return 0; }")
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    with open(path, "rb") as f:
        magic = f.read(4)
    assert magic == b"MCBN"


# ---------------------------------------------------------------------------
# .mcb roundtrip: function count
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_function_count(tmp_path):
    source = """
    int add(int a, int b) { return a + b; }
    int main() { return add(1, 2); }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)
    assert len(mc2.functions) == len(mc.functions)


# ---------------------------------------------------------------------------
# .mcb roundtrip: string table
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_string_table(tmp_path):
    source = r"""
    extern "kernel32.dll" void* GetStdHandle(int nStdHandle);
    int main() {
        char* msg;
        msg = "hello world";
        return 0;
    }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)
    assert set(mc.strings) == set(mc2.strings)


# ---------------------------------------------------------------------------
# .mcb roundtrip: struct definitions
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_struct_definitions(tmp_path):
    source = """
    struct Point { int x; int y; };
    struct Rect  { int x; int y; int w; int h; };
    int main() {
        struct Point p;
        struct Rect r;
        p.x = 1;
        r.w = 10;
        return 0;
    }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)

    assert len(mc2.structs) == len(mc.structs)
    for orig, loaded in zip(mc.structs, mc2.structs):
        assert loaded.name == orig.name
        assert len(loaded.fields) == len(orig.fields)


# ---------------------------------------------------------------------------
# .mcb roundtrip: function names
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_function_names(tmp_path):
    source = """
    int foo() { return 1; }
    int bar() { return 2; }
    int main() { return foo() + bar(); }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)
    orig_names = [f.name for f in mc.functions]
    loaded_names = [f.name for f in mc2.functions]
    assert orig_names == loaded_names


# ---------------------------------------------------------------------------
# .mcb roundtrip: extern functions preserve dll name
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_extern_dll_name(tmp_path):
    source = r"""
    extern "kernel32.dll" void* GetStdHandle(int nStdHandle);
    extern "kernel32.dll" int WriteFile(void* hFile, char* buf, int len, int* written, void* overlapped);
    int main() { return 0; }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)

    extern_by_name = {f.name: f for f in mc2.functions if f.is_extern}
    assert "GetStdHandle" in extern_by_name
    assert "WriteFile" in extern_by_name
    assert extern_by_name["GetStdHandle"].dll == "kernel32.dll"
    assert extern_by_name["WriteFile"].dll == "kernel32.dll"


# ---------------------------------------------------------------------------
# .mcb roundtrip: instruction count per function
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_instruction_counts(tmp_path):
    source = """
    int compute(int x) {
        int a;
        a = x + 1;
        if (a > 10) {
            a = a - 5;
        }
        return a;
    }
    int main() { return compute(7); }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)

    for orig_fn, loaded_fn in zip(mc.functions, mc2.functions):
        orig_count = sum(len(b.instructions) for b in orig_fn.blocks)
        loaded_count = sum(len(b.instructions) for b in loaded_fn.blocks)
        assert loaded_count == orig_count, (
            f"Function {orig_fn.name}: expected {orig_count} instructions, got {loaded_count}"
        )


# ---------------------------------------------------------------------------
# .mct output is non-empty and contains expected directives
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mct_output_contains_directives(tmp_path):
    source = """
    int main() { return 42; }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mct")
    write_text(mc, path)

    with open(path, "r") as f:
        text = f.read()

    assert len(text) > 0
    assert ".func" in text or "@main" in text
    assert "main" in text


# ---------------------------------------------------------------------------
# Empty program roundtrips correctly
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_empty_program(tmp_path):
    source = "int main() { return 0; }"
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)

    assert len(mc2.functions) == len(mc.functions)
    main_fns = [f for f in mc2.functions if f.name == "main"]
    assert len(main_fns) == 1
    total_instrs = sum(len(b.instructions) for b in main_fns[0].blocks)
    assert total_instrs > 0


# ---------------------------------------------------------------------------
# Program with globals roundtrips (global count matches)
# ---------------------------------------------------------------------------

@pytest.mark.frontend
def test_mcb_roundtrip_globals(tmp_path):
    source = """
    int counter;
    int limit;
    int main() {
        counter = 0;
        limit = 100;
        return counter + limit;
    }
    """
    mc = compile_to_ir(source)
    path = str(tmp_path / "out.mcb")
    write_bytecode(mc, path)
    mc2 = read_bytecode(path)

    assert len(mc2.globals) == len(mc.globals)
    orig_names = [g.name for g in mc.globals]
    loaded_names = [g.name for g in mc2.globals]
    assert orig_names == loaded_names
