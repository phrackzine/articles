"""Tests for the MystC type checker."""
import pytest

from compiler.frontend.parser import parse
from compiler.frontend.typecheck import typecheck
from compiler.frontend import mystc_ast as ast


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def check(source: str):
    """Parse + typecheck, return (success, symbols, errors)."""
    program = parse(source)
    return typecheck(program)


def assert_ok(source: str):
    """Assert source typechecks without errors."""
    success, symbols, errors = check(source)
    assert success, f"Expected success but got errors: {errors}"
    assert errors == []
    return symbols


def assert_fail(source: str, *, fragment: str = None):
    """Assert source fails typecheck; optionally check error message fragment."""
    success, symbols, errors = check(source)
    assert not success, "Expected typecheck failure but it succeeded"
    assert len(errors) > 0
    if fragment:
        msgs = " | ".join(str(e) for e in errors)
        assert any(fragment in str(e) for e in errors), \
            f"No error contains '{fragment}'; got: {msgs}"
    return errors


# ===========================================================================
# Positive tests
# ===========================================================================

@pytest.mark.frontend
class TestPositiveSimpleFunction:
    def test_simple_return(self):
        assert_ok("""
            int main() {
                return 0;
            }
        """)

    def test_void_function(self):
        assert_ok("""
            void noop() {
                return;
            }
        """)


@pytest.mark.frontend
class TestPositiveParamsAndLocals:
    def test_params_and_locals(self):
        assert_ok("""
            int add(int a, int b) {
                int c;
                c = a + b;
                return c;
            }
        """)

    def test_local_init(self):
        assert_ok("""
            int f() {
                int x = 10;
                return x;
            }
        """)


@pytest.mark.frontend
class TestPositiveArithmetic:
    def test_int_arithmetic(self):
        assert_ok("""
            int calc(int a, int b) {
                int r;
                r = a + b * 2 - a / b;
                return r;
            }
        """)


@pytest.mark.frontend
class TestPositivePointers:
    def test_address_of_and_deref(self):
        assert_ok("""
            int f() {
                int x = 5;
                int *p;
                p = &x;
                return *p;
            }
        """)


@pytest.mark.frontend
class TestPositiveStruct:
    def test_struct_dot_access(self):
        assert_ok("""
            struct Point {
                int x;
                int y;
            };
            int f() {
                struct Point pt;
                pt.x = 1;
                pt.y = 2;
                return pt.x + pt.y;
            }
        """)

    def test_struct_arrow_access(self):
        assert_ok("""
            struct Node {
                int val;
            };
            int f(struct Node *np) {
                return np->val;
            }
        """)


@pytest.mark.frontend
class TestPositiveExtern:
    def test_extern_declaration(self):
        symbols = assert_ok("""
            extern "kernel32.dll" int GetTickCount();
            int main() {
                int t;
                t = GetTickCount();
                return t;
            }
        """)
        fi = symbols.lookup_function("GetTickCount")
        assert fi is not None
        assert fi.is_extern
        assert fi.dll == "kernel32.dll"


@pytest.mark.frontend
class TestPositiveGlobals:
    def test_global_variable(self):
        assert_ok("""
            int g_count;
            int inc() {
                g_count = g_count + 1;
                return g_count;
            }
        """)

    def test_global_with_init(self):
        assert_ok("""
            int g_val = 42;
            int get() {
                return g_val;
            }
        """)


@pytest.mark.frontend
class TestPositiveLoops:
    def test_while_with_break(self):
        assert_ok("""
            int f() {
                int i = 0;
                while (i < 10) {
                    if (i == 5) {
                        break;
                    }
                    i = i + 1;
                }
                return i;
            }
        """)

    def test_for_with_continue(self):
        assert_ok("""
            int f() {
                int sum = 0;
                int i;
                for (i = 0; i < 10; i = i + 1) {
                    if (i == 3) {
                        continue;
                    }
                    sum = sum + i;
                }
                return sum;
            }
        """)


@pytest.mark.frontend
class TestPositiveFunctionCalls:
    def test_correct_call(self):
        assert_ok("""
            int double_it(int x) {
                return x + x;
            }
            int main() {
                return double_it(21);
            }
        """)


@pytest.mark.frontend
class TestPositiveArrays:
    def test_array_decl_and_index(self):
        assert_ok("""
            int f() {
                int arr[10];
                arr[0] = 42;
                return arr[0];
            }
        """)


@pytest.mark.frontend
class TestPositiveSizeof:
    def test_sizeof_int(self):
        assert_ok("""
            int f() {
                int sz;
                sz = sizeof(int);
                return sz;
            }
        """)

    def test_sizeof_struct(self):
        assert_ok("""
            struct Pair {
                int a;
                int b;
            };
            int f() {
                return sizeof(struct Pair);
            }
        """)


@pytest.mark.frontend
class TestPositiveExterns:
    def test_malloc_free_with_extern(self):
        assert_ok("""
            extern void* malloc(int size);
            extern void free(void* ptr);
            int f() {
                void *p;
                p = malloc(100);
                free(p);
                return 0;
            }
        """)

    def test_write_with_extern(self):
        assert_ok("""
            extern int write(int fd, char* buf, int n);
            int f() {
                char *msg = "hello";
                write(1, msg, 5);
                return 0;
            }
        """)

    def test_undeclared_function_error(self):
        assert_fail("""
            int f() {
                void *p;
                p = malloc(100);
                return 0;
            }
        """, fragment="Undefined function")


@pytest.mark.frontend
class TestPositiveCharArithmetic:
    def test_char_ops(self):
        assert_ok("""
            int f() {
                char c = 'A';
                int v;
                v = c + 1;
                return v;
            }
        """)


# ===========================================================================
# Negative tests
# ===========================================================================

@pytest.mark.frontend
class TestNegativeUndeclaredVar:
    def test_undeclared_variable(self):
        assert_fail("""
            int f() {
                return x;
            }
        """, fragment="Undefined variable 'x'")


@pytest.mark.frontend
class TestNegativeArgCount:
    def test_wrong_arg_count(self):
        assert_fail("""
            int add(int a, int b) {
                return a + b;
            }
            int main() {
                return add(1);
            }
        """, fragment="expects 2 arguments, got 1")


@pytest.mark.frontend
class TestNegativeDuplicateFunction:
    def test_duplicate_function(self):
        assert_fail("""
            int f() { return 0; }
            int f() { return 1; }
        """, fragment="already defined")


@pytest.mark.frontend
class TestNegativeReturnTypeMismatch:
    def test_return_value_from_void(self):
        assert_fail("""
            void f() {
                return 42;
            }
        """, fragment="Cannot return value from void function")


@pytest.mark.frontend
class TestNegativeBreakOutsideLoop:
    def test_break_outside_loop(self):
        assert_fail("""
            int f() {
                break;
                return 0;
            }
        """, fragment="outside of loop")


@pytest.mark.frontend
class TestNegativeContinueOutsideLoop:
    def test_continue_outside_loop(self):
        assert_fail("""
            int f() {
                continue;
                return 0;
            }
        """, fragment="outside of loop")


@pytest.mark.frontend
class TestNegativeUndeclaredStruct:
    def test_undeclared_struct(self):
        assert_fail("""
            int f() {
                struct Ghost g;
                return 0;
            }
        """, fragment="Unknown struct 'Ghost'")
