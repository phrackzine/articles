"""Tests for the --strip-debug AST pass."""
from compiler.frontend.lexer import tokenize
from compiler.frontend.parser import Parser
from compiler.frontend.strip_debug import strip_debug_calls
from compiler.frontend import mystc_ast as ast


def _parse(source: str) -> ast.Program:
    tokens = tokenize(source, "<test>")
    parser = Parser(tokens, "<test>")
    program = parser.parse_program()
    assert not parser.errors, parser.errors
    return program


def _count_calls(program: ast.Program, name: str) -> int:
    n = 0
    def walk(stmt):
        nonlocal n
        if isinstance(stmt, ast.ExprStmt) and isinstance(stmt.expr, ast.CallExpr):
            if stmt.expr.func == name and not stmt.expr.is_indirect:
                n += 1
        if isinstance(stmt, ast.Block):
            for s in stmt.stmts: walk(s)
        elif isinstance(stmt, ast.IfStmt):
            walk(stmt.then_branch)
            if stmt.else_branch is not None: walk(stmt.else_branch)
        elif isinstance(stmt, ast.WhileStmt):
            walk(stmt.body)
        elif isinstance(stmt, ast.ForStmt):
            walk(stmt.body)
    for f in program.functions:
        if f.body is not None: walk(f.body)
    return n


class TestStripDebug:
    def test_strips_top_level_print(self):
        src = """
        void hello() {
            print("hi");
            print_int(42);
            print_hex(255);
            print_err("err");
            print_int_err(-1);
        }
        """
        prog = _parse(src)
        assert _count_calls(prog, "print") == 1
        n = strip_debug_calls(prog)
        assert n == 5
        assert _count_calls(prog, "print") == 0
        assert _count_calls(prog, "print_int") == 0
        assert _count_calls(prog, "print_hex") == 0
        assert _count_calls(prog, "print_err") == 0
        assert _count_calls(prog, "print_int_err") == 0

    def test_keeps_non_debug_calls(self):
        src = """
        void f(int x) {}
        void g() { f(1); print("debug"); f(2); }
        """
        prog = _parse(src)
        assert strip_debug_calls(prog) == 1
        assert _count_calls(prog, "f") == 2
        assert _count_calls(prog, "print") == 0

    def test_strips_inside_if_while_for(self):
        src = """
        void g(int n) {
            int i;
            if (n > 0) { print("pos"); print_int(n); }
            else       { print("neg"); }
            while (n > 0) { print("loop"); n = n - 1; }
            for (i = 0; i < 10; i = i + 1) { print_hex(i); }
        }
        """
        prog = _parse(src)
        n = strip_debug_calls(prog)
        assert n == 5

    def test_braceless_branch_replaced_with_empty_block(self):
        # Branch body is a single debug call (no braces) — must become empty Block
        src = """
        void g(int n) {
            if (n > 0) print("hi");
            while (n > 0) print("loop");
        }
        """
        prog = _parse(src)
        n = strip_debug_calls(prog)
        assert n == 2
        body = prog.functions[0].body
        if_stmt = body.stmts[0]
        assert isinstance(if_stmt, ast.IfStmt)
        assert isinstance(if_stmt.then_branch, ast.Block)
        assert if_stmt.then_branch.stmts == []
        while_stmt = body.stmts[1]
        assert isinstance(while_stmt, ast.WhileStmt)
        assert isinstance(while_stmt.body, ast.Block)
        assert while_stmt.body.stmts == []

    def test_keeps_indirect_calls(self):
        # `int fp = &print; fp("x");` — call through variable is indirect, keep it
        src = """
        void caller() {
            int fp;
            fp = 42;
            fp("hi");
        }
        """
        prog = _parse(src)
        n = strip_debug_calls(prog)
        assert n == 0

    def test_keeps_nested_call_expressions(self):
        # print(...) used as a sub-expression (not statement-level) — leave alone.
        # In MystC print returns void so this typically doesn't typecheck,
        # but the strip pass operates pre-typecheck and must not touch sub-exprs.
        src = """
        void f(int x) {}
        void g() { f(1 + 2); }
        """
        prog = _parse(src)
        n = strip_debug_calls(prog)
        assert n == 0  # f(1+2) is not a debug call; sub-exprs untouched

    def test_returns_zero_when_nothing_to_strip(self):
        src = """
        int add(int a, int b) { return a + b; }
        void f(int x) {}
        void g() { f(add(1, 2)); }
        """
        prog = _parse(src)
        assert strip_debug_calls(prog) == 0
