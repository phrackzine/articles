"""Tests for the --scramble-globals frontend pass."""
import zlib

import pytest

from compiler.frontend.parser import parse
from compiler.frontend.typecheck import typecheck
from compiler.frontend.irgen import generate_ir
from compiler.frontend.scramble import scramble_globals, INIT_FUNC_NAME
from compiler.frontend.bytecode import MCProgram, Opcode, ValueKind, TypeCode


def _compile_to_ir(source: str) -> MCProgram:
    program = parse(source)
    success, symbols, errors = typecheck(program)
    if not success:
        raise RuntimeError(f"Typecheck failed: {errors}")
    return generate_ir(program, symbols)


def _crc32_signed(name: str) -> int:
    h = zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF
    if h & 0x80000000:
        h -= 0x100000000
    return h


def _find_func(mc: MCProgram, name: str):
    for f in mc.functions:
        if f.name == name:
            return f
    return None


def _find_global(mc: MCProgram, name: str):
    for g in mc.globals:
        if g.name == name:
            return g
    return None


@pytest.mark.frontend
class TestScrambleGlobals:
    def test_demotes_int_literal_globals(self):
        src = """
        int META_MAGIC = 0x12345678;
        int OTHER = 42;
        int main() { return META_MAGIC; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 2
        g1 = _find_global(mc, "META_MAGIC")
        g2 = _find_global(mc, "OTHER")
        assert g1.init_kind == 1
        assert g1.init_value == _crc32_signed("META_MAGIC")
        assert g1.init_value != 0x12345678
        assert g2.init_value == _crc32_signed("OTHER")

    def test_generates_init_globals_function(self):
        src = """
        int A = 100;
        int B = 200;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        scramble_globals(mc)
        init_fn = _find_func(mc, INIT_FUNC_NAME)
        assert init_fn is not None
        assert init_fn.return_type == TypeCode.VOID
        block = init_fn.blocks[0]
        ops = [i.opcode for i in block.instructions]
        assert ops.count(Opcode.CONST) == 2
        assert ops.count(Opcode.STORE) == 2
        assert ops[-1] == Opcode.RETV

    def test_init_globals_stores_real_values(self):
        src = """
        int X = 12345;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        scramble_globals(mc)
        init_fn = _find_func(mc, INIT_FUNC_NAME)
        block = init_fn.blocks[0]
        # First instruction is CONST with the real value 12345
        assert block.instructions[0].opcode == Opcode.CONST
        assert block.instructions[0].arg1.imm_value == 12345
        # Second is STORE through GLOBAL kind targeting the global
        assert block.instructions[1].opcode == Opcode.STORE
        assert block.instructions[1].arg1.kind == ValueKind.GLOBAL

    def test_call_injected_at_head_of_main(self):
        src = """
        int X = 7;
        int main() { return 1; }
        """
        mc = _compile_to_ir(src)
        scramble_globals(mc)
        main = _find_func(mc, "main")
        first = main.blocks[0].instructions[0]
        assert first.opcode == Opcode.CALLV
        init_fn_idx = mc.functions.index(_find_func(mc, INIT_FUNC_NAME))
        assert first.func_index == init_fn_idx
        assert first.nargs == 0

    def test_skips_uninitialized_globals(self):
        src = """
        int X;
        int Y = 99;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 1
        gx = _find_global(mc, "X")
        assert gx.init_kind == 0
        assert gx.init_value == 0

    def test_skips_string_pointer_globals(self):
        src = """
        char* MSG = "hello";
        int N = 5;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 1
        gmsg = _find_global(mc, "MSG")
        assert gmsg.init_kind == 2  # string ref, untouched

    def test_demotes_zero_initialized_scalars(self):
        # Category B: explicit `= 0` is init_kind == 1 with value 0; gets demoted
        # so .data has the scramble value, __init_globals stores 0 back.
        src = """
        int ZERO = 0;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 1
        g = _find_global(mc, "ZERO")
        assert g.init_value == _crc32_signed("ZERO")
        assert g.init_value != 0

    def test_library_no_main_is_noop(self):
        src = """
        int X = 42;
        int helper(int a) { return a; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 0
        g = _find_global(mc, "X")
        assert g.init_value == 42
        assert _find_func(mc, INIT_FUNC_NAME) is None

    def test_no_eligible_globals_is_noop(self):
        src = """
        int X;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 0
        assert _find_func(mc, INIT_FUNC_NAME) is None

    def test_negative_literal_initializer(self):
        # `int X = -11;` parses as UnaryExpr(NEG, IntLiteral(11)); irgen treats
        # it as init_kind == 1 with a negative init_value.
        src = """
        int X = -11;
        int main() { return 0; }
        """
        mc = _compile_to_ir(src)
        n = scramble_globals(mc)
        assert n == 1
        init_fn = _find_func(mc, INIT_FUNC_NAME)
        assert init_fn.blocks[0].instructions[0].arg1.imm_value == -11

    def test_deterministic_across_runs(self):
        src = """
        int A = 1;
        int B = 2;
        int main() { return 0; }
        """
        mc1 = _compile_to_ir(src)
        scramble_globals(mc1)
        mc2 = _compile_to_ir(src)
        scramble_globals(mc2)
        for g1, g2 in zip(mc1.globals, mc2.globals):
            assert g1.init_value == g2.init_value

    def test_main_entry_block_other_instructions_preserved(self):
        # The injected CALLV must go BEFORE existing main body, not replace it.
        src = """
        int X = 7;
        int main() {
            int a;
            a = X;
            return a;
        }
        """
        mc = _compile_to_ir(src)
        pre_count = sum(len(b.instructions) for b in _find_func(mc, "main").blocks)
        scramble_globals(mc)
        post_count = sum(len(b.instructions) for b in _find_func(mc, "main").blocks)
        # Exactly one CALLV added at the head, nothing removed.
        assert post_count == pre_count + 1
        assert _find_func(mc, "main").blocks[0].instructions[0].opcode == Opcode.CALLV

