"""Negative / error tests for the MystC compiler frontend."""
import pytest

from compiler.frontend.tokens import TokenType
from compiler.frontend.lexer import Lexer, tokenize
from compiler.frontend.parser import Parser, parse, ParseError
from compiler.frontend.typecheck import typecheck


# ===========================================================================
# Lexer errors — expect an ERROR token in output
# ===========================================================================

@pytest.mark.frontend
def test_lexer_unterminated_string():
    tokens = tokenize('"hello')
    assert any(t.type == TokenType.ERROR for t in tokens)


@pytest.mark.frontend
def test_lexer_unterminated_char():
    tokens = tokenize("'a")
    assert any(t.type == TokenType.ERROR for t in tokens)


@pytest.mark.frontend
def test_lexer_invalid_char_at_sign():
    tokens = tokenize("@")
    assert any(t.type == TokenType.ERROR for t in tokens)


@pytest.mark.frontend
def test_lexer_invalid_char_hash():
    tokens = tokenize("#")
    assert any(t.type == TokenType.ERROR for t in tokens)


# ===========================================================================
# Parser errors — expect parser.errors to be non-empty
# ===========================================================================

def _parse_with_errors(source: str) -> Parser:
    """Tokenize and parse source, returning the parser (with .errors)."""
    tokens = Lexer(source, "<test>").tokenize()
    parser = Parser(tokens, "<test>")
    parser.parse_program()
    return parser


@pytest.mark.frontend
def test_parser_missing_semicolon():
    parser = _parse_with_errors("int main() { return 1 }")
    assert len(parser.errors) > 0


@pytest.mark.frontend
def test_parser_missing_closing_brace():
    parser = _parse_with_errors("int main() { return 1;")
    assert len(parser.errors) > 0


@pytest.mark.frontend
def test_parser_missing_closing_paren():
    parser = _parse_with_errors("int main( { return 0; }")
    assert len(parser.errors) > 0


@pytest.mark.frontend
def test_parser_empty_source_no_crash():
    """Empty source should not crash the parser."""
    parser = _parse_with_errors("")
    # No assertion on errors — just verifying no exception is raised.


# ===========================================================================
# Type errors — parse succeeds, typecheck returns success=False
# ===========================================================================

def _typecheck_source(source: str):
    """Parse and typecheck source. Returns (success, errors)."""
    program = parse(source)
    success, _symbols, errors = typecheck(program)
    return success, errors


@pytest.mark.frontend
def test_type_undeclared_variable():
    success, errors = _typecheck_source("int main() { return x; }")
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_wrong_arg_count():
    source = "int f(int a) { return a; } int main() { return f(1, 2); }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_duplicate_function():
    source = "int f() { return 0; } int f() { return 1; } int main() { return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_break_outside_loop():
    source = "int main() { break; return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_continue_outside_loop():
    source = "int main() { continue; return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_undeclared_struct():
    source = "int main() { struct Foo f; return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_return_value_from_void():
    source = "void f() { return 1; } int main() { f(); return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_call_nonexistent_function():
    source = "int main() { return foo(); }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_undeclared_variable_in_expr():
    source = "int main() { int a; a = b + 1; return a; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0


@pytest.mark.frontend
def test_type_double_local_declaration():
    source = "int main() { int x; int x; return 0; }"
    success, errors = _typecheck_source(source)
    assert not success
    assert len(errors) > 0
