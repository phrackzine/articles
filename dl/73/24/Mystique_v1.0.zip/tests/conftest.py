"""Root test fixtures: paths, builders, helpers."""
import sys
import os
from pathlib import Path

import pytest

# ── Paths ────────────────────────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent                  # Mystique/
COMPILER_DIR  = ROOT / "compiler"
BACKEND_DIR   = COMPILER_DIR / "backend"
BUNDLES_DIR      = ROOT / "bundles"
EXAMPLES_DIR  = ROOT / "docs" / "examples"
TESTS_DIR     = ROOT / "tests"

# Ensure project root is on sys.path for imports
sys.path.insert(0, str(ROOT))


@pytest.fixture(scope="session")
def project_root():
    return ROOT


@pytest.fixture(scope="session")
def examples_dir():
    return EXAMPLES_DIR
