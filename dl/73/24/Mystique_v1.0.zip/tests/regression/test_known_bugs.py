"""Regression tests for known bugs that have been fixed.

Each test targets a specific historical bug and verifies it doesn't regress.
"""
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.regression

ROOT = Path(__file__).parent.parent.parent
BACKEND_DIR = ROOT / "compiler" / "backend"
LOADERS_DIR = ROOT / "compiler" / "loaders"
BUNDLES_DIR = ROOT / "bundles"
TESTS_DIR = ROOT / "tests"

IS_WINDOWS = sys.platform == "win32"
EXPECTED_EXIT = 0 if IS_WINDOWS else 42

BACKEND_EXE = BACKEND_DIR / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")
LOADER_EXE = LOADERS_DIR / ("loader_win32.exe" if IS_WINDOWS else "loader_linux")

if IS_WINDOWS:
    STRESS_MC = TESTS_DIR / "programs" / "compiler_stress.mc"
else:
    STRESS_MC = TESTS_DIR / "programs" / "test_linux.mc"

X86_FLAGS = [
    "--x86-poly-instrs", "--x86-dead-code", "--x86-opaque",
    "--x86-junk-funcs", "--x86-harmless-calls", "--x86-shuffle-funcs",
]


# ---------------------------------------------------------------------------
# Helpers (mirrors backend conftest pattern)
# ---------------------------------------------------------------------------

def _compile_mc(source_path, mcb_path):
    platform_def = "WIN32" if sys.platform == "win32" else "LINUX"
    r = subprocess.run(
        [sys.executable, "-m", "compiler.frontend.mystcc",
         str(source_path), "-o", str(mcb_path), f"-D{platform_def}"],
        cwd=str(ROOT), capture_output=True, text=True,
    )
    if r.returncode != 0:
        raise RuntimeError(f"Frontend failed on {source_path}:\n{r.stderr}")
    return mcb_path


def _compile_backend(mcb, bin_out, seed=1001, flags=None):
    cmd = [str(BACKEND_EXE), str(mcb), "--pic", str(bin_out),
           "--seed", str(seed)]
    if flags:
        cmd.extend(flags)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(
            f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}")
    return bin_out


def _run_loader(bin_path, timeout=30):
    r = subprocess.run(
        [str(LOADER_EXE), str(bin_path)],
        capture_output=True, text=True, timeout=timeout,
    )
    return r.returncode


def _ensure_built():
    missing = []
    for p in [BACKEND_EXE, LOADER_EXE]:
        if not p.exists():
            missing.append(p.name)
    if missing:
        pytest.skip(f"Missing binaries: {', '.join(missing)}")


@pytest.fixture(scope="module")
def stress_mcb(tmp_path_factory):
    """Compile the stress test .mc -> .mcb once per module."""
    _ensure_built()
    if not STRESS_MC.exists():
        pytest.skip(f"Stress source not found: {STRESS_MC}")
    d = tmp_path_factory.mktemp("regression_stress")
    mcb = d / "stress.mcb"
    _compile_mc(STRESS_MC, mcb)
    return mcb


def _compile_and_run(stress_mcb, tmp_path, seed, flags, label=""):
    """Compile + run the stress .mcb with given flags/seed. Assert expected exit."""
    safe = label or f"s{seed}"
    bin_out = tmp_path / f"reg_{safe}.bin"
    _compile_backend(stress_mcb, bin_out, seed=seed, flags=flags)
    rc = _run_loader(bin_out)
    assert rc == EXPECTED_EXIT, (
        f"[{label}] seed={seed} flags={flags} exited {rc}, expected {EXPECTED_EXIT}"
    )


# ---------------------------------------------------------------------------
# a. Pre-prologue junk -- certain seed/flag combos used to crash
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("flag,seed", [
    ("--ir-unfold", 1001),
    ("--ir-substitute", 1008),
    ("--ir-reorder-locals", 1002),
], ids=["unfold_s1001", "substitute_s1008", "reorder_locals_s1002"])
def test_pre_prologue_junk(stress_mcb, tmp_path, flag, seed):
    """Pre-prologue junk insertion used to crash with certain IR transforms."""
    _compile_and_run(stress_mcb, tmp_path, seed, [flag],
                     label=f"pre_prologue_{flag.lstrip('-')}_s{seed}")


# ---------------------------------------------------------------------------
# b. Unspill slot zero -- --ir-reorder-blocks --ir-nops at seeds 1001-1003
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("seed", [1001, 1002, 1003])
def test_unspill_slot_zero(stress_mcb, tmp_path, seed):
    """Unspill slot zero bug with --ir-reorder-blocks --ir-nops."""
    _compile_and_run(stress_mcb, tmp_path, seed,
                     ["--ir-reorder-blocks", "--ir-nops"],
                     label=f"unspill_slot0_s{seed}")


# ---------------------------------------------------------------------------
# c. Reorder funcs extern breakage -- --ir-reorder-funcs at seeds 1001, 1005, 1010
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("seed", [1001, 1005, 1010])
def test_reorder_funcs_extern_breakage(stress_mcb, tmp_path, seed):
    """--ir-reorder-funcs used to break extern resolution."""
    _compile_and_run(stress_mcb, tmp_path, seed,
                     ["--ir-reorder-funcs"],
                     label=f"reorder_funcs_s{seed}")


# ---------------------------------------------------------------------------
# d. Dead code RA clobber -- --x86-dead-code at seeds 1001-1003
#    plus --x86-dead-code combined with all other x86 flags at seed 1001
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("seed", [1001, 1002, 1003])
def test_dead_code_ra_clobber_standalone(stress_mcb, tmp_path, seed):
    """--x86-dead-code RA clobber fix, standalone at multiple seeds."""
    _compile_and_run(stress_mcb, tmp_path, seed,
                     ["--x86-dead-code"],
                     label=f"dead_code_ra_s{seed}")


def test_dead_code_ra_clobber_combined(stress_mcb, tmp_path):
    """--x86-dead-code combined with all other x86 flags at seed 1001."""
    _compile_and_run(stress_mcb, tmp_path, 1001,
                     X86_FLAGS,
                     label="dead_code_ra_all_x86_s1001")


# ---------------------------------------------------------------------------
# e. Poly variant MOV guards -- --x86-poly-instrs at seeds 1001-1005
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("seed", [1001, 1002, 1003, 1004, 1005])
def test_poly_variant_mov_guards(stress_mcb, tmp_path, seed):
    """Poly variant MOV guard fix (if dst != src1) in emit_add/sub variants."""
    _compile_and_run(stress_mcb, tmp_path, seed,
                     ["--x86-poly-instrs"],
                     label=f"poly_mov_guards_s{seed}")
