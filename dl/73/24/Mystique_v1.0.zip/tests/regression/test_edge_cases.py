"""Edge case tests: small inline MystC programs exercising tricky codegen paths."""
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.regression

ROOT = Path(__file__).parent.parent.parent
BACKEND_DIR = ROOT / "compiler" / "backend"
LOADERS_DIR = ROOT / "compiler" / "loaders"
BUNDLES_DIR = ROOT / "bundles"

IS_WINDOWS = sys.platform == "win32"

BACKEND_EXE = BACKEND_DIR / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")
LOADER_EXE = LOADERS_DIR / ("loader_win32.exe" if IS_WINDOWS else "loader_linux")

# Ensure project root is on sys.path for frontend imports
sys.path.insert(0, str(ROOT))


# ---------------------------------------------------------------------------
# Helper: compile inline source -> .mcb -> .bin -> run, return exit code
# ---------------------------------------------------------------------------

def _compile_and_run(source, tmp_path, timeout=30):
    """Compile inline MystC source through the full pipeline and run it.

    Returns the process exit code (returncode).
    """
    if not BACKEND_EXE.exists():
        pytest.skip(f"Backend not found: {BACKEND_EXE}")
    if not LOADER_EXE.exists():
        pytest.skip(f"Loader not found: {LOADER_EXE}")

    from compiler.frontend.parser import parse
    from compiler.frontend.typecheck import typecheck
    from compiler.frontend.irgen import generate_ir
    from compiler.frontend.bytecode import write_bytecode

    program = parse(source)
    success, symbols, errors = typecheck(program)
    assert success, f"Typecheck failed: {errors}"
    mc = generate_ir(program, symbols)

    mcb_path = str(tmp_path / "edge.mcb")
    write_bytecode(mc, mcb_path)

    bin_path = tmp_path / "edge.bin"
    r = subprocess.run(
        [str(BACKEND_EXE), mcb_path, "--pic", str(bin_path),
         "--seed", "1001"],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        pytest.fail(f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}")

    r = subprocess.run(
        [str(LOADER_EXE), str(bin_path)],
        capture_output=True, text=True, timeout=timeout,
    )
    return r.returncode


# ---------------------------------------------------------------------------
# Edge case tests
# ---------------------------------------------------------------------------

def test_division_by_one(tmp_path):
    """Division by 1 returns the dividend unchanged."""
    rc = _compile_and_run("int main() { return 7 / 1; }", tmp_path)
    assert rc == 7, f"7 / 1 should be 7, got {rc}"


def test_modulo_by_one(tmp_path):
    """Modulo by 1 always yields 0."""
    rc = _compile_and_run("int main() { return 7 % 1; }", tmp_path)
    assert rc == 0, f"7 % 1 should be 0, got {rc}"


def test_shift_by_zero(tmp_path):
    """Shifting by 0 is a no-op."""
    rc = _compile_and_run("int main() { return 5 << 0; }", tmp_path)
    assert rc == 5, f"5 << 0 should be 5, got {rc}"


def test_shift_by_31_no_crash(tmp_path):
    """Shifting by 31 may wrap but must not crash."""
    source = "int main() { int x; x = 1 << 31; return x >> 31; }"
    rc = _compile_and_run(source, tmp_path)
    # The exact value depends on whether >> is arithmetic or logical shift.
    # The key assertion is that it doesn't crash -- any int exit code is fine.
    assert isinstance(rc, int), f"Expected int returncode, got {type(rc).__name__}"


def test_deep_recursion(tmp_path):
    """Recursive function to depth 12 returns 12."""
    source = (
        "int f(int n) { if (n <= 0) { return 0; } return f(n-1) + 1; }\n"
        "int main() { return f(12); }"
    )
    rc = _compile_and_run(source, tmp_path)
    assert rc == 12, f"f(12) should be 12, got {rc}"


def test_empty_function_body(tmp_path):
    """Calling a void function with empty body, then returning 1."""
    source = "void f() { } int main() { f(); return 1; }"
    rc = _compile_and_run(source, tmp_path)
    assert rc == 1, f"Expected 1, got {rc}"


def test_single_if_no_else(tmp_path):
    """Single if with no else branch."""
    source = (
        "int main() { int x; x = 5; "
        "if (x > 3) { x = 10; } "
        "return x; }"
    )
    rc = _compile_and_run(source, tmp_path)
    assert rc == 10, f"Expected 10, got {rc}"


def test_chained_and_conditions(tmp_path):
    """Chained && conditions in if statement."""
    source = (
        "int main() { int a; int b; int c; "
        "a = 3; b = 5; c = 7; "
        "if (a < b && b < c && c < 10) { return 1; } "
        "return 0; }"
    )
    rc = _compile_and_run(source, tmp_path)
    assert rc == 1, f"Expected 1 (all conditions true), got {rc}"


def test_char_arithmetic(tmp_path):
    """Char + 1 arithmetic yields next ASCII value (low byte)."""
    source = "int main() { char c; c = 'A'; return c + 1; }"
    rc = _compile_and_run(source, tmp_path)
    # MystC char locals are stack slots; check low byte for 'B' (66)
    assert (rc & 0xFF) == 66, f"'A' + 1 low byte should be 66 ('B'), got {rc} (low byte {rc & 0xFF})"


def test_large_local_array(tmp_path):
    """256-byte local char array: write and read back first element."""
    source = (
        "int main() { char buf[256]; "
        "buf[0] = 42; "
        "return buf[0]; }"
    )
    rc = _compile_and_run(source, tmp_path)
    assert rc == 42, f"buf[0] should be 42, got {rc}"
