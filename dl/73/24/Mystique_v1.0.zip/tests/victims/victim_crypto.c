/* victim_crypto.c - Crypto primitives stress test for MystiqueFall
 * Build: cl /nologo /O1 victim_crypto.c /Fe:victim_crypto.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * All output is deterministic.
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* Helper: write unsigned 32-bit as hex */
static void write_hex32(unsigned int v) {
    char buf[9];
    int i;
    const char *hx = "0123456789abcdef";
    for (i = 7; i >= 0; i--) {
        buf[i] = hx[v & 0xF];
        v >>= 4;
    }
    buf[8] = 0;
    write_str(buf);
}

/* Helper: compare byte arrays */
static int mem_eq(const unsigned char *a, const unsigned char *b, int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (a[i] != b[i]) return 0;
    }
    return 1;
}

/* Helper: zero memory */
static void mem_zero(unsigned char *p, int n) {
    int i;
    for (i = 0; i < n; i++) p[i] = 0;
}

/* Helper: copy memory */
static void mem_copy(unsigned char *dst, const unsigned char *src, int n) {
    int i;
    for (i = 0; i < n; i++) dst[i] = src[i];
}

/* ================================================================
 * Global 256-byte S-box (used by Feistel cipher)
 * ================================================================ */
static const unsigned char g_sbox[256] = {
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5,
    0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0,
    0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC,
    0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A,
    0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0,
    0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B,
    0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85,
    0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5,
    0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17,
    0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88,
    0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C,
    0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9,
    0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6,
    0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E,
    0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94,
    0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68,
    0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
};

/* ================================================================
 * RC4 (KSA + PRGA)
 * ================================================================ */
typedef struct {
    unsigned char S[256];
    int i;
    int j;
} rc4_state;

static void rc4_ksa(rc4_state *st, const unsigned char *key, int keylen) {
    int i, j;
    unsigned char t;
    for (i = 0; i < 256; i++) st->S[i] = (unsigned char)i;
    j = 0;
    for (i = 0; i < 256; i++) {
        j = (j + st->S[i] + key[i % keylen]) & 0xFF;
        t = st->S[i]; st->S[i] = st->S[j]; st->S[j] = t;
    }
    st->i = 0;
    st->j = 0;
}

static unsigned char rc4_prga(rc4_state *st) {
    unsigned char t;
    st->i = (st->i + 1) & 0xFF;
    st->j = (st->j + st->S[st->i]) & 0xFF;
    t = st->S[st->i]; st->S[st->i] = st->S[st->j]; st->S[st->j] = t;
    return st->S[(st->S[st->i] + st->S[st->j]) & 0xFF];
}

static void rc4_crypt(const unsigned char *key, int keylen,
                       const unsigned char *in, unsigned char *out, int len) {
    rc4_state st;
    int i;
    rc4_ksa(&st, key, keylen);
    for (i = 0; i < len; i++) {
        out[i] = in[i] ^ rc4_prga(&st);
    }
}

/* ================================================================
 * TEA (Tiny Encryption Algorithm) - 32 rounds
 * Operates on 64-bit blocks (two 32-bit words), 128-bit key
 * ================================================================ */
static void tea_encrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int v0 = v[0], v1 = v[1];
    unsigned int sum = 0;
    unsigned int delta = 0x9E3779B9u;
    int i;
    for (i = 0; i < 32; i++) {
        sum += delta;
        v0 += ((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >> 5) + k[1]);
        v1 += ((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >> 5) + k[3]);
    }
    v[0] = v0; v[1] = v1;
}

static void tea_decrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int v0 = v[0], v1 = v[1];
    unsigned int sum = 0xC6EF3720u; /* delta * 32 */
    unsigned int delta = 0x9E3779B9u;
    int i;
    for (i = 0; i < 32; i++) {
        v1 -= ((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >> 5) + k[3]);
        v0 -= ((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >> 5) + k[1]);
        sum -= delta;
    }
    v[0] = v0; v[1] = v1;
}

/* ================================================================
 * XTEA (eXtended TEA) - 32 rounds
 * ================================================================ */
static void xtea_encrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int v0 = v[0], v1 = v[1];
    unsigned int sum = 0;
    unsigned int delta = 0x9E3779B9u;
    int i;
    for (i = 0; i < 32; i++) {
        v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + k[sum & 3]);
        sum += delta;
        v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + k[(sum >> 11) & 3]);
    }
    v[0] = v0; v[1] = v1;
}

static void xtea_decrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int v0 = v[0], v1 = v[1];
    unsigned int sum = 0xC6EF3720u;
    unsigned int delta = 0x9E3779B9u;
    int i;
    for (i = 0; i < 32; i++) {
        v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + k[(sum >> 11) & 3]);
        sum -= delta;
        v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + k[sum & 3]);
    }
    v[0] = v0; v[1] = v1;
}

/* ================================================================
 * Simple Feistel cipher (4 rounds with S-box-based F function)
 * 64-bit block (two 32-bit halves), 128-bit key (4 x 32-bit subkeys)
 * ================================================================ */
static unsigned int feistel_f(unsigned int half, unsigned int subkey) {
    unsigned int x = half ^ subkey;
    unsigned int b0, b1, b2, b3;
    b0 = g_sbox[(x >> 0) & 0xFF];
    b1 = g_sbox[(x >> 8) & 0xFF];
    b2 = g_sbox[(x >> 16) & 0xFF];
    b3 = g_sbox[(x >> 24) & 0xFF];
    return (b3 << 24) | (b2 << 16) | (b1 << 8) | b0;
}

static void feistel_encrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int L = v[0], R = v[1];
    unsigned int tmp;
    int i;
    for (i = 0; i < 4; i++) {
        tmp = R;
        R = L ^ feistel_f(R, k[i]);
        L = tmp;
    }
    v[0] = L; v[1] = R;
}

static void feistel_decrypt(unsigned int v[2], const unsigned int k[4]) {
    unsigned int L = v[0], R = v[1];
    unsigned int tmp;
    int i;
    for (i = 3; i >= 0; i--) {
        tmp = L;
        L = R ^ feistel_f(L, k[i]);
        R = tmp;
    }
    v[0] = L; v[1] = R;
}

/* ================================================================
 * CRC32 (with full 256-entry lookup table)
 * ================================================================ */
static unsigned int g_crc32_table[256];
static int g_crc32_init = 0;

static void crc32_init_table(void) {
    unsigned int i, j, crc;
    if (g_crc32_init) return;
    for (i = 0; i < 256; i++) {
        crc = i;
        for (j = 0; j < 8; j++) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xEDB88320u;
            else
                crc = crc >> 1;
        }
        g_crc32_table[i] = crc;
    }
    g_crc32_init = 1;
}

static unsigned int crc32_compute(const unsigned char *data, int len) {
    unsigned int crc = 0xFFFFFFFFu;
    int i;
    for (i = 0; i < len; i++) {
        crc = g_crc32_table[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    }
    return crc ^ 0xFFFFFFFFu;
}

/* ================================================================
 * FNV-1a hash (32-bit)
 * ================================================================ */
static unsigned int fnv1a_hash(const unsigned char *data, int len) {
    unsigned int hash = 0x811C9DC5u; /* FNV offset basis */
    int i;
    for (i = 0; i < len; i++) {
        hash ^= data[i];
        hash *= 0x01000193u; /* FNV prime */
    }
    return hash;
}

/* ================================================================
 * DJB2 hash
 * ================================================================ */
static unsigned int djb2_hash(const unsigned char *data, int len) {
    unsigned int hash = 5381;
    int i;
    for (i = 0; i < len; i++) {
        hash = ((hash << 5) + hash) + data[i]; /* hash * 33 + c */
    }
    return hash;
}

/* ================================================================
 * SDBM hash
 * ================================================================ */
static unsigned int sdbm_hash(const unsigned char *data, int len) {
    unsigned int hash = 0;
    int i;
    for (i = 0; i < len; i++) {
        hash = data[i] + (hash << 6) + (hash << 16) - hash;
    }
    return hash;
}

/* ================================================================
 * TEA-based ECB mode (for 8-byte blocks)
 * ================================================================ */
static void tea_ecb_encrypt(unsigned char *data, int len, const unsigned int key[4]) {
    int i;
    unsigned int block[2];
    /* len must be multiple of 8 */
    for (i = 0; i < len; i += 8) {
        block[0] = (unsigned int)data[i]
                 | ((unsigned int)data[i+1] << 8)
                 | ((unsigned int)data[i+2] << 16)
                 | ((unsigned int)data[i+3] << 24);
        block[1] = (unsigned int)data[i+4]
                 | ((unsigned int)data[i+5] << 8)
                 | ((unsigned int)data[i+6] << 16)
                 | ((unsigned int)data[i+7] << 24);
        tea_encrypt(block, key);
        data[i]   = (unsigned char)(block[0]);
        data[i+1] = (unsigned char)(block[0] >> 8);
        data[i+2] = (unsigned char)(block[0] >> 16);
        data[i+3] = (unsigned char)(block[0] >> 24);
        data[i+4] = (unsigned char)(block[1]);
        data[i+5] = (unsigned char)(block[1] >> 8);
        data[i+6] = (unsigned char)(block[1] >> 16);
        data[i+7] = (unsigned char)(block[1] >> 24);
    }
}

static void tea_ecb_decrypt(unsigned char *data, int len, const unsigned int key[4]) {
    int i;
    unsigned int block[2];
    for (i = 0; i < len; i += 8) {
        block[0] = (unsigned int)data[i]
                 | ((unsigned int)data[i+1] << 8)
                 | ((unsigned int)data[i+2] << 16)
                 | ((unsigned int)data[i+3] << 24);
        block[1] = (unsigned int)data[i+4]
                 | ((unsigned int)data[i+5] << 8)
                 | ((unsigned int)data[i+6] << 16)
                 | ((unsigned int)data[i+7] << 24);
        tea_decrypt(block, key);
        data[i]   = (unsigned char)(block[0]);
        data[i+1] = (unsigned char)(block[0] >> 8);
        data[i+2] = (unsigned char)(block[0] >> 16);
        data[i+3] = (unsigned char)(block[0] >> 24);
        data[i+4] = (unsigned char)(block[1]);
        data[i+5] = (unsigned char)(block[1] >> 8);
        data[i+6] = (unsigned char)(block[1] >> 16);
        data[i+7] = (unsigned char)(block[1] >> 24);
    }
}

/* ================================================================
 * TEA-based CBC mode
 * IV is 8 bytes. data length must be multiple of 8.
 * ================================================================ */
static void tea_cbc_encrypt(unsigned char *data, int len,
                             const unsigned int key[4],
                             const unsigned char iv[8]) {
    int i, j;
    unsigned char prev[8];
    unsigned int block[2];

    mem_copy(prev, iv, 8);
    for (i = 0; i < len; i += 8) {
        /* XOR with previous ciphertext (or IV) */
        for (j = 0; j < 8; j++) data[i+j] ^= prev[j];

        block[0] = (unsigned int)data[i]
                 | ((unsigned int)data[i+1] << 8)
                 | ((unsigned int)data[i+2] << 16)
                 | ((unsigned int)data[i+3] << 24);
        block[1] = (unsigned int)data[i+4]
                 | ((unsigned int)data[i+5] << 8)
                 | ((unsigned int)data[i+6] << 16)
                 | ((unsigned int)data[i+7] << 24);
        tea_encrypt(block, key);
        data[i]   = (unsigned char)(block[0]);
        data[i+1] = (unsigned char)(block[0] >> 8);
        data[i+2] = (unsigned char)(block[0] >> 16);
        data[i+3] = (unsigned char)(block[0] >> 24);
        data[i+4] = (unsigned char)(block[1]);
        data[i+5] = (unsigned char)(block[1] >> 8);
        data[i+6] = (unsigned char)(block[1] >> 16);
        data[i+7] = (unsigned char)(block[1] >> 24);

        mem_copy(prev, &data[i], 8);
    }
}

static void tea_cbc_decrypt(unsigned char *data, int len,
                             const unsigned int key[4],
                             const unsigned char iv[8]) {
    int i, j;
    unsigned char prev[8], cur[8];
    unsigned int block[2];

    mem_copy(prev, iv, 8);
    for (i = 0; i < len; i += 8) {
        mem_copy(cur, &data[i], 8);

        block[0] = (unsigned int)data[i]
                 | ((unsigned int)data[i+1] << 8)
                 | ((unsigned int)data[i+2] << 16)
                 | ((unsigned int)data[i+3] << 24);
        block[1] = (unsigned int)data[i+4]
                 | ((unsigned int)data[i+5] << 8)
                 | ((unsigned int)data[i+6] << 16)
                 | ((unsigned int)data[i+7] << 24);
        tea_decrypt(block, key);
        data[i]   = (unsigned char)(block[0]);
        data[i+1] = (unsigned char)(block[0] >> 8);
        data[i+2] = (unsigned char)(block[0] >> 16);
        data[i+3] = (unsigned char)(block[0] >> 24);
        data[i+4] = (unsigned char)(block[1]);
        data[i+5] = (unsigned char)(block[1] >> 8);
        data[i+6] = (unsigned char)(block[1] >> 16);
        data[i+7] = (unsigned char)(block[1] >> 24);

        /* XOR with previous ciphertext (or IV) */
        for (j = 0; j < 8; j++) data[i+j] ^= prev[j];

        mem_copy(prev, cur, 8);
    }
}

/* ================================================================
 * HMAC-like construct using FNV-1a
 * HMAC(key, msg) = FNV1a(key ^ opad || FNV1a(key ^ ipad || msg))
 * We use a simplified fixed 16-byte key.
 * ================================================================ */
static unsigned int hmac_fnv1a(const unsigned char *key, int keylen,
                                const unsigned char *msg, int msglen) {
    unsigned char ipad_key[16];
    unsigned char opad_key[16];
    unsigned char inner_buf[256]; /* max msglen = 240 */
    unsigned char outer_buf[20]; /* 16 + 4 */
    unsigned int inner_hash;
    int i;
    int actual_keylen = keylen;
    if (actual_keylen > 16) actual_keylen = 16;

    /* Prepare padded keys */
    mem_zero(ipad_key, 16);
    mem_zero(opad_key, 16);
    for (i = 0; i < actual_keylen; i++) {
        ipad_key[i] = key[i] ^ 0x36;
        opad_key[i] = key[i] ^ 0x5C;
    }
    for (i = actual_keylen; i < 16; i++) {
        ipad_key[i] = 0x36;
        opad_key[i] = 0x5C;
    }

    /* Inner: FNV1a(ipad_key || msg) */
    mem_copy(inner_buf, ipad_key, 16);
    if (msglen > 240) msglen = 240;
    mem_copy(inner_buf + 16, msg, msglen);
    inner_hash = fnv1a_hash(inner_buf, 16 + msglen);

    /* Outer: FNV1a(opad_key || inner_hash_bytes) */
    mem_copy(outer_buf, opad_key, 16);
    outer_buf[16] = (unsigned char)(inner_hash);
    outer_buf[17] = (unsigned char)(inner_hash >> 8);
    outer_buf[18] = (unsigned char)(inner_hash >> 16);
    outer_buf[19] = (unsigned char)(inner_hash >> 24);
    return fnv1a_hash(outer_buf, 20);
}

/* ================================================================
 * Test helpers
 * ================================================================ */
static void write_label(const char *section, const char *name) {
    write_str("  ");
    write_str(section);
    write_str("/");
    write_str(name);
}

/* ================================================================
 * RC4 Tests
 * ================================================================ */
static void test_rc4_roundtrip(void) {
    /* Test 1: Basic round-trip */
    {
        unsigned char key[] = {0x01, 0x02, 0x03, 0x04, 0x05};
        unsigned char plain[] = "Hello, World!";
        unsigned char cipher[16];
        unsigned char decrypted[16];
        int len = 13;

        rc4_crypt(key, 5, plain, cipher, len);
        rc4_crypt(key, 5, cipher, decrypted, len);
        check(mem_eq(plain, decrypted, len), "rc4/roundtrip_basic");
    }

    /* Test 2: cipher != plaintext */
    {
        unsigned char key[] = {0xAB, 0xCD, 0xEF};
        unsigned char plain[] = "Test message";
        unsigned char cipher[16];
        int len = 12;

        rc4_crypt(key, 3, plain, cipher, len);
        check(!mem_eq(plain, cipher, len), "rc4/not_identity");
    }

    /* Test 3: Empty key edge (single byte key) */
    {
        unsigned char key[] = {0xFF};
        unsigned char plain[] = {0x00, 0x01, 0x02, 0x03};
        unsigned char cipher[4];
        unsigned char decrypted[4];

        rc4_crypt(key, 1, plain, cipher, 4);
        rc4_crypt(key, 1, cipher, decrypted, 4);
        check(mem_eq(plain, decrypted, 4), "rc4/roundtrip_1byte_key");
    }

    /* Test 4: Long message */
    {
        unsigned char key[] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};
        unsigned char plain[256];
        unsigned char cipher[256];
        unsigned char decrypted[256];
        int i;

        for (i = 0; i < 256; i++) plain[i] = (unsigned char)i;
        rc4_crypt(key, 8, plain, cipher, 256);
        rc4_crypt(key, 8, cipher, decrypted, 256);
        check(mem_eq(plain, decrypted, 256), "rc4/roundtrip_256");
    }

    /* Test 5: Known test vector - RC4("Key", "Plaintext") */
    {
        unsigned char key[] = "Key";
        unsigned char plain[] = "Plaintext";
        unsigned char cipher[9];
        unsigned char expected[] = {0xBB, 0xF3, 0x16, 0xE8, 0xD9, 0x40, 0xAF, 0x0A, 0xD3};
        int len = 9;

        rc4_crypt(key, 3, plain, cipher, len);
        check(mem_eq(cipher, expected, len), "rc4/known_vector");
    }

    /* Test 6: Determinism - same key+plaintext = same cipher */
    {
        unsigned char key[] = {0xDE, 0xAD, 0xBE, 0xEF};
        unsigned char plain[] = "Deterministic";
        unsigned char c1[16], c2[16];
        int len = 13;

        rc4_crypt(key, 4, plain, c1, len);
        rc4_crypt(key, 4, plain, c2, len);
        check(mem_eq(c1, c2, len), "rc4/deterministic");
    }

    /* Test 7: Different keys produce different ciphertext */
    {
        unsigned char key1[] = {0x01, 0x02};
        unsigned char key2[] = {0x03, 0x04};
        unsigned char plain[] = "Same plain";
        unsigned char c1[16], c2[16];
        int len = 10;

        rc4_crypt(key1, 2, plain, c1, len);
        rc4_crypt(key2, 2, plain, c2, len);
        check(!mem_eq(c1, c2, len), "rc4/diff_keys");
    }

    /* Test 8: RC4 stream XOR property (encrypting twice = identity) */
    {
        unsigned char key[] = {0x42};
        unsigned char plain[] = {0xAA, 0xBB, 0xCC, 0xDD};
        unsigned char tmp[4], result[4];

        rc4_crypt(key, 1, plain, tmp, 4);
        rc4_crypt(key, 1, tmp, result, 4);
        check(mem_eq(plain, result, 4), "rc4/double_encrypt");
    }
}

/* ================================================================
 * TEA Tests
 * ================================================================ */
static void test_tea(void) {
    /* Test 1: Basic round-trip */
    {
        unsigned int v[2] = {0x01234567u, 0x89ABCDEFu};
        unsigned int orig[2] = {0x01234567u, 0x89ABCDEFu};
        unsigned int k[4] = {0xA56BABCDu, 0x00000000u, 0xFFFFFFFFu, 0xDEADBEEFu};

        tea_encrypt(v, k);
        check(v[0] != orig[0] || v[1] != orig[1], "tea/encrypts");
        tea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "tea/roundtrip");
    }

    /* Test 2: Zero key, zero plaintext */
    {
        unsigned int v[2] = {0, 0};
        unsigned int orig[2] = {0, 0};
        unsigned int k[4] = {0, 0, 0, 0};

        tea_encrypt(v, k);
        /* Even zero key should produce non-zero ciphertext from delta additions */
        check(v[0] != 0 || v[1] != 0, "tea/zero_not_identity");
        tea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "tea/zero_roundtrip");
    }

    /* Test 3: Known vector check (deterministic) */
    {
        unsigned int v1[2] = {0xDEADBEEFu, 0xCAFEBABEu};
        unsigned int v2[2] = {0xDEADBEEFu, 0xCAFEBABEu};
        unsigned int k[4] = {0x11111111u, 0x22222222u, 0x33333333u, 0x44444444u};

        tea_encrypt(v1, k);
        tea_encrypt(v2, k);
        check(v1[0] == v2[0] && v1[1] == v2[1], "tea/deterministic");
    }

    /* Test 4: Different keys produce different ciphertext */
    {
        unsigned int v1[2] = {0x12345678u, 0x9ABCDEF0u};
        unsigned int v2[2] = {0x12345678u, 0x9ABCDEF0u};
        unsigned int k1[4] = {1, 2, 3, 4};
        unsigned int k2[4] = {5, 6, 7, 8};

        tea_encrypt(v1, k1);
        tea_encrypt(v2, k2);
        check(v1[0] != v2[0] || v1[1] != v2[1], "tea/diff_keys");
    }

    /* Test 5: Multiple encrypt-decrypt cycles */
    {
        unsigned int v[2] = {0xAAAAAAAAu, 0x55555555u};
        unsigned int orig[2] = {0xAAAAAAAAu, 0x55555555u};
        unsigned int k[4] = {0xFEDCBA98u, 0x76543210u, 0x01234567u, 0x89ABCDEFu};
        int i;

        for (i = 0; i < 10; i++) tea_encrypt(v, k);
        for (i = 0; i < 10; i++) tea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "tea/multi_cycle");
    }

    /* Test 6: Avalanche - flipping one bit changes output significantly */
    {
        unsigned int v1[2] = {0x00000000u, 0x00000000u};
        unsigned int v2[2] = {0x00000001u, 0x00000000u};
        unsigned int k[4] = {0xAAAAAAAAu, 0xBBBBBBBBu, 0xCCCCCCCCu, 0xDDDDDDDDu};
        unsigned int diff;

        tea_encrypt(v1, k);
        tea_encrypt(v2, k);
        diff = (v1[0] ^ v2[0]) | (v1[1] ^ v2[1]);
        check(diff != 0, "tea/avalanche");
    }
}

/* ================================================================
 * XTEA Tests
 * ================================================================ */
static void test_xtea(void) {
    /* Test 1: Basic round-trip */
    {
        unsigned int v[2] = {0x41424344u, 0x45464748u};
        unsigned int orig[2] = {0x41424344u, 0x45464748u};
        unsigned int k[4] = {0x00010203u, 0x04050607u, 0x08090A0Bu, 0x0C0D0E0Fu};

        xtea_encrypt(v, k);
        check(v[0] != orig[0] || v[1] != orig[1], "xtea/encrypts");
        xtea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "xtea/roundtrip");
    }

    /* Test 2: Zero plaintext zero key */
    {
        unsigned int v[2] = {0, 0};
        unsigned int orig[2] = {0, 0};
        unsigned int k[4] = {0, 0, 0, 0};

        xtea_encrypt(v, k);
        check(v[0] != 0 || v[1] != 0, "xtea/zero_not_identity");
        xtea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "xtea/zero_roundtrip");
    }

    /* Test 3: Deterministic */
    {
        unsigned int v1[2] = {0x12345678u, 0x9ABCDEF0u};
        unsigned int v2[2] = {0x12345678u, 0x9ABCDEF0u};
        unsigned int k[4] = {0xDEADBEEFu, 0xCAFEBABEu, 0x0BADF00Du, 0xFEEDFACEu};

        xtea_encrypt(v1, k);
        xtea_encrypt(v2, k);
        check(v1[0] == v2[0] && v1[1] == v2[1], "xtea/deterministic");
    }

    /* Test 4: TEA != XTEA (different algorithms) */
    {
        unsigned int vt[2] = {0x11111111u, 0x22222222u};
        unsigned int vx[2] = {0x11111111u, 0x22222222u};
        unsigned int k[4] = {0xAAAAAAAAu, 0xBBBBBBBBu, 0xCCCCCCCCu, 0xDDDDDDDDu};

        tea_encrypt(vt, k);
        xtea_encrypt(vx, k);
        check(vt[0] != vx[0] || vt[1] != vx[1], "xtea/differs_from_tea");
    }

    /* Test 5: Multi-cycle */
    {
        unsigned int v[2] = {0xFFFFFFFFu, 0x00000000u};
        unsigned int orig[2] = {0xFFFFFFFFu, 0x00000000u};
        unsigned int k[4] = {1, 2, 3, 4};
        int i;

        for (i = 0; i < 5; i++) xtea_encrypt(v, k);
        for (i = 0; i < 5; i++) xtea_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "xtea/multi_cycle");
    }

    /* Test 6: Avalanche */
    {
        unsigned int v1[2] = {0, 0};
        unsigned int v2[2] = {1, 0};
        unsigned int k[4] = {0x12345678u, 0x9ABCDEF0u, 0x0FEDCBA9u, 0x87654321u};
        unsigned int diff;

        xtea_encrypt(v1, k);
        xtea_encrypt(v2, k);
        diff = (v1[0] ^ v2[0]) | (v1[1] ^ v2[1]);
        check(diff != 0, "xtea/avalanche");
    }
}

/* ================================================================
 * Feistel cipher tests
 * ================================================================ */
static void test_feistel(void) {
    /* Test 1: Basic round-trip */
    {
        unsigned int v[2] = {0xDEADBEEFu, 0xCAFEBABEu};
        unsigned int orig[2] = {0xDEADBEEFu, 0xCAFEBABEu};
        unsigned int k[4] = {0x01020304u, 0x05060708u, 0x090A0B0Cu, 0x0D0E0F10u};

        feistel_encrypt(v, k);
        check(v[0] != orig[0] || v[1] != orig[1], "feistel/encrypts");
        feistel_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "feistel/roundtrip");
    }

    /* Test 2: Zero block */
    {
        unsigned int v[2] = {0, 0};
        unsigned int orig[2] = {0, 0};
        unsigned int k[4] = {0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu};

        feistel_encrypt(v, k);
        feistel_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "feistel/zero_roundtrip");
    }

    /* Test 3: S-box dependency - verify S-box affects output */
    {
        unsigned int v[2] = {0x00000001u, 0x00000000u};
        unsigned int k[4] = {0, 0, 0, 0};

        feistel_encrypt(v, k);
        /* With S-box, even simple input should produce interesting output */
        check(v[0] != 0x00000001u || v[1] != 0x00000000u, "feistel/sbox_active");
    }

    /* Test 4: Deterministic */
    {
        unsigned int v1[2] = {0xAAAAAAAAu, 0x55555555u};
        unsigned int v2[2] = {0xAAAAAAAAu, 0x55555555u};
        unsigned int k[4] = {0x12345678u, 0x9ABCDEF0u, 0x0FEDCBA9u, 0x87654321u};

        feistel_encrypt(v1, k);
        feistel_encrypt(v2, k);
        check(v1[0] == v2[0] && v1[1] == v2[1], "feistel/deterministic");
    }

    /* Test 5: Multi-cycle */
    {
        unsigned int v[2] = {0x11223344u, 0x55667788u};
        unsigned int orig[2] = {0x11223344u, 0x55667788u};
        unsigned int k[4] = {0xAABBCCDDu, 0xEEFF0011u, 0x22334455u, 0x66778899u};
        int i;

        for (i = 0; i < 20; i++) feistel_encrypt(v, k);
        for (i = 0; i < 20; i++) feistel_decrypt(v, k);
        check(v[0] == orig[0] && v[1] == orig[1], "feistel/multi_cycle");
    }

    /* Test 6: Different keys */
    {
        unsigned int v1[2] = {0x99887766u, 0x55443322u};
        unsigned int v2[2] = {0x99887766u, 0x55443322u};
        unsigned int k1[4] = {1, 2, 3, 4};
        unsigned int k2[4] = {5, 6, 7, 8};

        feistel_encrypt(v1, k1);
        feistel_encrypt(v2, k2);
        check(v1[0] != v2[0] || v1[1] != v2[1], "feistel/diff_keys");
    }
}

/* ================================================================
 * CRC32 Tests
 * ================================================================ */
static void test_crc32(void) {
    unsigned int crc;

    /* Test 1: CRC32("") = 0x00000000 */
    crc = crc32_compute((const unsigned char *)"", 0);
    check(crc == 0x00000000u, "crc32/empty");

    /* Test 2: CRC32("123456789") - standard check value */
    crc = crc32_compute((const unsigned char *)"123456789", 9);
    check(crc == 0xCBF43926u, "crc32/check_value");

    /* Test 3: CRC32("a") */
    crc = crc32_compute((const unsigned char *)"a", 1);
    check(crc == 0xE8B7BE43u, "crc32/single_a");

    /* Test 4: CRC32("abc") */
    crc = crc32_compute((const unsigned char *)"abc", 3);
    check(crc == 0x352441C2u, "crc32/abc");

    /* Test 5: CRC32("Hello, World!") */
    crc = crc32_compute((const unsigned char *)"Hello, World!", 13);
    check(crc == 0xEC4AC3D0u, "crc32/hello_world");

    /* Test 6: Determinism */
    {
        unsigned int c1, c2;
        c1 = crc32_compute((const unsigned char *)"test", 4);
        c2 = crc32_compute((const unsigned char *)"test", 4);
        check(c1 == c2, "crc32/deterministic");
    }

    /* Test 7: Different inputs produce different CRCs */
    {
        unsigned int c1, c2;
        c1 = crc32_compute((const unsigned char *)"foo", 3);
        c2 = crc32_compute((const unsigned char *)"bar", 3);
        check(c1 != c2, "crc32/diff_input");
    }

    /* Test 8: All zero bytes */
    {
        unsigned char zeros[16];
        mem_zero(zeros, 16);
        crc = crc32_compute(zeros, 16);
        check(crc != 0, "crc32/zeros_nonzero");
    }

    /* Test 9: All 0xFF bytes */
    {
        unsigned char ones[16];
        int i;
        for (i = 0; i < 16; i++) ones[i] = 0xFF;
        crc = crc32_compute(ones, 16);
        check(crc != 0, "crc32/ones_nonzero");
    }

    /* Test 10: CRC32 table spot check */
    check(g_crc32_table[0] == 0x00000000u, "crc32/table_0");
    check(g_crc32_table[1] == 0x77073096u, "crc32/table_1");
    check(g_crc32_table[255] == 0x2D02EF8Du, "crc32/table_255");
}

/* ================================================================
 * FNV-1a Tests
 * ================================================================ */
static void test_fnv1a(void) {
    unsigned int h;

    /* Test 1: FNV1a("") = offset basis */
    h = fnv1a_hash((const unsigned char *)"", 0);
    check(h == 0x811C9DC5u, "fnv1a/empty");

    /* Test 2: FNV1a("a") */
    h = fnv1a_hash((const unsigned char *)"a", 1);
    check(h == 0xE40C292Cu, "fnv1a/a");

    /* Test 3: FNV1a("foobar") */
    h = fnv1a_hash((const unsigned char *)"foobar", 6);
    check(h == 0xBF9CF968u, "fnv1a/foobar");

    /* Test 4: Determinism */
    {
        unsigned int h1, h2;
        h1 = fnv1a_hash((const unsigned char *)"test", 4);
        h2 = fnv1a_hash((const unsigned char *)"test", 4);
        check(h1 == h2, "fnv1a/deterministic");
    }

    /* Test 5: Different inputs */
    {
        unsigned int h1, h2;
        h1 = fnv1a_hash((const unsigned char *)"abc", 3);
        h2 = fnv1a_hash((const unsigned char *)"abd", 3);
        check(h1 != h2, "fnv1a/diff_input");
    }

    /* Test 6: Order matters */
    {
        unsigned int h1, h2;
        h1 = fnv1a_hash((const unsigned char *)"ab", 2);
        h2 = fnv1a_hash((const unsigned char *)"ba", 2);
        check(h1 != h2, "fnv1a/order_matters");
    }

    /* Test 7: FNV1a("") known value (32-bit offset basis) */
    h = fnv1a_hash((const unsigned char *)"", 0);
    check(h == 2166136261u, "fnv1a/offset_basis");

    /* Test 8: Single zero byte */
    {
        unsigned char z = 0;
        h = fnv1a_hash(&z, 1);
        check(h != 0x811C9DC5u, "fnv1a/zero_byte_differs");
    }
}

/* ================================================================
 * DJB2 Tests
 * ================================================================ */
static void test_djb2(void) {
    unsigned int h;

    /* Test 1: DJB2("") = 5381 */
    h = djb2_hash((const unsigned char *)"", 0);
    check(h == 5381, "djb2/empty");

    /* Test 2: DJB2("a") = 5381*33 + 97 = 177670 + 97 = 177673 (mod 2^32) */
    h = djb2_hash((const unsigned char *)"a", 1);
    check(h == (5381u * 33u + 97u), "djb2/a");

    /* Test 3: Determinism */
    {
        unsigned int h1, h2;
        h1 = djb2_hash((const unsigned char *)"hello", 5);
        h2 = djb2_hash((const unsigned char *)"hello", 5);
        check(h1 == h2, "djb2/deterministic");
    }

    /* Test 4: Different inputs */
    {
        unsigned int h1, h2;
        h1 = djb2_hash((const unsigned char *)"cat", 3);
        h2 = djb2_hash((const unsigned char *)"dog", 3);
        check(h1 != h2, "djb2/diff_input");
    }

    /* Test 5: Order matters */
    {
        unsigned int h1, h2;
        h1 = djb2_hash((const unsigned char *)"ab", 2);
        h2 = djb2_hash((const unsigned char *)"ba", 2);
        check(h1 != h2, "djb2/order_matters");
    }

    /* Test 6: Known value for "Hello" */
    h = djb2_hash((const unsigned char *)"Hello", 5);
    {
        /* Compute manually: 5381 -> *33+'H' -> *33+'e' -> ... */
        unsigned int expected = 5381;
        expected = expected * 33 + 'H';
        expected = expected * 33 + 'e';
        expected = expected * 33 + 'l';
        expected = expected * 33 + 'l';
        expected = expected * 33 + 'o';
        check(h == expected, "djb2/hello_manual");
    }

    /* Test 7: Long string */
    {
        unsigned char long_str[100];
        int i;
        unsigned int h1, h2;
        for (i = 0; i < 100; i++) long_str[i] = (unsigned char)('A' + (i % 26));
        h1 = djb2_hash(long_str, 100);
        h2 = djb2_hash(long_str, 100);
        check(h1 == h2, "djb2/long_deterministic");
    }
}

/* ================================================================
 * SDBM Tests
 * ================================================================ */
static void test_sdbm(void) {
    unsigned int h;

    /* Test 1: SDBM("") = 0 */
    h = sdbm_hash((const unsigned char *)"", 0);
    check(h == 0, "sdbm/empty");

    /* Test 2: SDBM("a") = 'a' + 0 = 97 */
    h = sdbm_hash((const unsigned char *)"a", 1);
    check(h == 97, "sdbm/a");

    /* Test 3: Determinism */
    {
        unsigned int h1, h2;
        h1 = sdbm_hash((const unsigned char *)"test", 4);
        h2 = sdbm_hash((const unsigned char *)"test", 4);
        check(h1 == h2, "sdbm/deterministic");
    }

    /* Test 4: Different inputs */
    {
        unsigned int h1, h2;
        h1 = sdbm_hash((const unsigned char *)"foo", 3);
        h2 = sdbm_hash((const unsigned char *)"bar", 3);
        check(h1 != h2, "sdbm/diff_input");
    }

    /* Test 5: Order matters */
    {
        unsigned int h1, h2;
        h1 = sdbm_hash((const unsigned char *)"xy", 2);
        h2 = sdbm_hash((const unsigned char *)"yx", 2);
        check(h1 != h2, "sdbm/order_matters");
    }

    /* Test 6: Manual computation for "ab" */
    {
        unsigned int expected = 0;
        expected = 'a' + (expected << 6) + (expected << 16) - expected;
        expected = 'b' + (expected << 6) + (expected << 16) - expected;
        h = sdbm_hash((const unsigned char *)"ab", 2);
        check(h == expected, "sdbm/ab_manual");
    }

    /* Test 7: Single zero byte vs empty */
    {
        unsigned char z = 0;
        unsigned int h1, h2;
        h1 = sdbm_hash((const unsigned char *)"", 0);
        h2 = sdbm_hash(&z, 1);
        check(h1 == h2, "sdbm/zero_byte_equals_empty"); /* 0 + 0 = 0 */
    }
}

/* ================================================================
 * ECB mode tests
 * ================================================================ */
static void test_ecb(void) {
    /* Test 1: Single block round-trip */
    {
        unsigned char data[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
        unsigned char orig[8];
        unsigned int key[4] = {0xDEADBEEFu, 0xCAFEBABEu, 0x0BADF00Du, 0xFEEDFACEu};

        mem_copy(orig, data, 8);
        tea_ecb_encrypt(data, 8, key);
        check(!mem_eq(data, orig, 8), "ecb/encrypts");
        tea_ecb_decrypt(data, 8, key);
        check(mem_eq(data, orig, 8), "ecb/roundtrip_1block");
    }

    /* Test 2: Multi-block round-trip */
    {
        unsigned char data[32];
        unsigned char orig[32];
        unsigned int key[4] = {0x11111111u, 0x22222222u, 0x33333333u, 0x44444444u};
        int i;

        for (i = 0; i < 32; i++) data[i] = (unsigned char)(i * 7 + 3);
        mem_copy(orig, data, 32);
        tea_ecb_encrypt(data, 32, key);
        tea_ecb_decrypt(data, 32, key);
        check(mem_eq(data, orig, 32), "ecb/roundtrip_4blocks");
    }

    /* Test 3: ECB determinism */
    {
        unsigned char d1[16], d2[16];
        unsigned int key[4] = {1, 2, 3, 4};
        int i;

        for (i = 0; i < 16; i++) d1[i] = d2[i] = (unsigned char)i;
        tea_ecb_encrypt(d1, 16, key);
        tea_ecb_encrypt(d2, 16, key);
        check(mem_eq(d1, d2, 16), "ecb/deterministic");
    }

    /* Test 4: ECB same block = same ciphertext (ECB property) */
    {
        unsigned char data[16];
        unsigned int key[4] = {0xAAAAAAAAu, 0xBBBBBBBBu, 0xCCCCCCCCu, 0xDDDDDDDDu};
        int i;

        /* Two identical 8-byte blocks */
        for (i = 0; i < 8; i++) data[i] = (unsigned char)(i + 1);
        for (i = 0; i < 8; i++) data[i+8] = (unsigned char)(i + 1);
        tea_ecb_encrypt(data, 16, key);
        check(mem_eq(data, data + 8, 8), "ecb/same_block_property");
    }

    /* Test 5: Large multi-block (64 bytes = 8 blocks) */
    {
        unsigned char data[64];
        unsigned char orig[64];
        unsigned int key[4] = {0x12345678u, 0x9ABCDEF0u, 0xFEDCBA98u, 0x76543210u};
        int i;

        for (i = 0; i < 64; i++) data[i] = (unsigned char)(i ^ 0xAA);
        mem_copy(orig, data, 64);
        tea_ecb_encrypt(data, 64, key);
        tea_ecb_decrypt(data, 64, key);
        check(mem_eq(data, orig, 64), "ecb/roundtrip_8blocks");
    }
}

/* ================================================================
 * CBC mode tests
 * ================================================================ */
static void test_cbc(void) {
    /* Test 1: Single block round-trip */
    {
        unsigned char data[8] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};
        unsigned char orig[8];
        unsigned int key[4] = {0xDEADBEEFu, 0xCAFEBABEu, 0x0BADF00Du, 0xFEEDFACEu};
        unsigned char iv[8] = {0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6, 0x07, 0x18};

        mem_copy(orig, data, 8);
        tea_cbc_encrypt(data, 8, key, iv);
        check(!mem_eq(data, orig, 8), "cbc/encrypts");
        tea_cbc_decrypt(data, 8, key, iv);
        check(mem_eq(data, orig, 8), "cbc/roundtrip_1block");
    }

    /* Test 2: Multi-block round-trip */
    {
        unsigned char data[32];
        unsigned char orig[32];
        unsigned int key[4] = {0x11111111u, 0x22222222u, 0x33333333u, 0x44444444u};
        unsigned char iv[8] = {0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE};
        int i;

        for (i = 0; i < 32; i++) data[i] = (unsigned char)(i * 3 + 17);
        mem_copy(orig, data, 32);
        tea_cbc_encrypt(data, 32, key, iv);
        tea_cbc_decrypt(data, 32, key, iv);
        check(mem_eq(data, orig, 32), "cbc/roundtrip_4blocks");
    }

    /* Test 3: CBC vs ECB - same plaintext blocks should encrypt differently in CBC */
    {
        unsigned char ecb_data[16], cbc_data[16];
        unsigned int key[4] = {1, 2, 3, 4};
        unsigned char iv[8] = {0xFF, 0xFE, 0xFD, 0xFC, 0xFB, 0xFA, 0xF9, 0xF8};
        int i;

        /* Two identical blocks */
        for (i = 0; i < 8; i++) ecb_data[i] = cbc_data[i] = (unsigned char)(i + 1);
        for (i = 0; i < 8; i++) ecb_data[i+8] = cbc_data[i+8] = (unsigned char)(i + 1);

        tea_ecb_encrypt(ecb_data, 16, key);
        tea_cbc_encrypt(cbc_data, 16, key, iv);

        /* In ECB, identical blocks produce identical ciphertext */
        /* In CBC, they should differ */
        check(!mem_eq(cbc_data, cbc_data + 8, 8), "cbc/blocks_differ");
    }

    /* Test 4: Different IVs produce different ciphertext */
    {
        unsigned char d1[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
        unsigned char d2[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
        unsigned int key[4] = {0xAAAAAAAAu, 0xBBBBBBBBu, 0xCCCCCCCCu, 0xDDDDDDDDu};
        unsigned char iv1[8] = {0, 0, 0, 0, 0, 0, 0, 1};
        unsigned char iv2[8] = {0, 0, 0, 0, 0, 0, 0, 2};

        tea_cbc_encrypt(d1, 8, key, iv1);
        tea_cbc_encrypt(d2, 8, key, iv2);
        check(!mem_eq(d1, d2, 8), "cbc/diff_ivs");
    }

    /* Test 5: Large round-trip (64 bytes) */
    {
        unsigned char data[64];
        unsigned char orig[64];
        unsigned int key[4] = {0x12345678u, 0x9ABCDEF0u, 0xFEDCBA98u, 0x76543210u};
        unsigned char iv[8] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF};
        int i;

        for (i = 0; i < 64; i++) data[i] = (unsigned char)(i ^ 0x55);
        mem_copy(orig, data, 64);
        tea_cbc_encrypt(data, 64, key, iv);
        tea_cbc_decrypt(data, 64, key, iv);
        check(mem_eq(data, orig, 64), "cbc/roundtrip_8blocks");
    }

    /* Test 6: Zero IV should differ from non-zero IV */
    {
        unsigned char d1[8] = {0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42};
        unsigned char d2[8] = {0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42};
        unsigned int key[4] = {1, 1, 1, 1};
        unsigned char iv0[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        unsigned char iv1[8] = {1, 1, 1, 1, 1, 1, 1, 1};

        tea_cbc_encrypt(d1, 8, key, iv0);
        tea_cbc_encrypt(d2, 8, key, iv1);
        check(!mem_eq(d1, d2, 8), "cbc/zero_vs_nonzero_iv");
    }
}

/* ================================================================
 * HMAC-FNV1a tests
 * ================================================================ */
static void test_hmac_fnv1a(void) {
    /* Test 1: Basic computation */
    {
        unsigned char key[] = {0x0B, 0x0B, 0x0B, 0x0B, 0x0B, 0x0B, 0x0B, 0x0B};
        unsigned char msg[] = "Hi There";
        unsigned int h = hmac_fnv1a(key, 8, msg, 8);
        check(h != 0, "hmac_fnv1a/basic_nonzero");
    }

    /* Test 2: Determinism */
    {
        unsigned char key[] = {1, 2, 3, 4};
        unsigned char msg[] = "test message";
        unsigned int h1 = hmac_fnv1a(key, 4, msg, 12);
        unsigned int h2 = hmac_fnv1a(key, 4, msg, 12);
        check(h1 == h2, "hmac_fnv1a/deterministic");
    }

    /* Test 3: Different keys produce different MACs */
    {
        unsigned char k1[] = {0x01, 0x02, 0x03, 0x04};
        unsigned char k2[] = {0x05, 0x06, 0x07, 0x08};
        unsigned char msg[] = "same message";
        unsigned int h1 = hmac_fnv1a(k1, 4, msg, 12);
        unsigned int h2 = hmac_fnv1a(k2, 4, msg, 12);
        check(h1 != h2, "hmac_fnv1a/diff_keys");
    }

    /* Test 4: Different messages produce different MACs */
    {
        unsigned char key[] = {0xAA, 0xBB, 0xCC, 0xDD};
        unsigned char msg1[] = "message one";
        unsigned char msg2[] = "message two";
        unsigned int h1 = hmac_fnv1a(key, 4, msg1, 11);
        unsigned int h2 = hmac_fnv1a(key, 4, msg2, 11);
        check(h1 != h2, "hmac_fnv1a/diff_msgs");
    }

    /* Test 5: Empty message */
    {
        unsigned char key[] = {0xFF};
        unsigned char msg[] = "";
        unsigned int h = hmac_fnv1a(key, 1, (const unsigned char *)msg, 0);
        check(h != 0, "hmac_fnv1a/empty_msg");
    }

    /* Test 6: Long message */
    {
        unsigned char key[] = {0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0};
        unsigned char msg[200];
        unsigned int h1, h2;
        int i;

        for (i = 0; i < 200; i++) msg[i] = (unsigned char)(i & 0xFF);
        h1 = hmac_fnv1a(key, 8, msg, 200);
        h2 = hmac_fnv1a(key, 8, msg, 200);
        check(h1 == h2, "hmac_fnv1a/long_deterministic");
    }

    /* Test 7: HMAC != plain FNV1a */
    {
        unsigned char key[] = {0x00};
        unsigned char msg[] = "test";
        unsigned int hmac_h = hmac_fnv1a(key, 1, msg, 4);
        unsigned int plain_h = fnv1a_hash(msg, 4);
        check(hmac_h != plain_h, "hmac_fnv1a/differs_from_plain");
    }
}

/* ================================================================
 * Cross-algorithm tests
 * ================================================================ */
static void test_cross_algorithm(void) {
    /* Test: All three hashes give different results for same input */
    {
        const unsigned char *msg = (const unsigned char *)"cross-test";
        unsigned int h_fnv = fnv1a_hash(msg, 10);
        unsigned int h_djb = djb2_hash(msg, 10);
        unsigned int h_sdbm = sdbm_hash(msg, 10);

        check(h_fnv != h_djb, "cross/fnv_vs_djb2");
        check(h_fnv != h_sdbm, "cross/fnv_vs_sdbm");
        check(h_djb != h_sdbm, "cross/djb2_vs_sdbm");
    }

    /* Test: TEA and XTEA give different ciphertext */
    {
        unsigned int vt[2] = {0x42424242u, 0x43434343u};
        unsigned int vx[2] = {0x42424242u, 0x43434343u};
        unsigned int k[4] = {0x10203040u, 0x50607080u, 0x90A0B0C0u, 0xD0E0F000u};

        tea_encrypt(vt, k);
        xtea_encrypt(vx, k);
        check(vt[0] != vx[0] || vt[1] != vx[1], "cross/tea_vs_xtea");
    }

    /* Test: Feistel differs from TEA and XTEA */
    {
        unsigned int vf[2] = {0x42424242u, 0x43434343u};
        unsigned int vt[2] = {0x42424242u, 0x43434343u};
        unsigned int k[4] = {0x10203040u, 0x50607080u, 0x90A0B0C0u, 0xD0E0F000u};

        feistel_encrypt(vf, k);
        tea_encrypt(vt, k);
        check(vf[0] != vt[0] || vf[1] != vt[1], "cross/feistel_vs_tea");
    }

    /* Test: CRC32 and FNV-1a give different results */
    {
        const unsigned char *msg = (const unsigned char *)"hash-compare";
        unsigned int c = crc32_compute(msg, 12);
        unsigned int f = fnv1a_hash(msg, 12);
        check(c != f, "cross/crc32_vs_fnv1a");
    }
}

/* ================================================================
 * S-box tests
 * ================================================================ */
static void test_sbox(void) {
    int i, count[256];
    int all_unique;

    /* Test 1: S-box is a permutation (all 256 values appear exactly once) */
    for (i = 0; i < 256; i++) count[i] = 0;
    for (i = 0; i < 256; i++) count[g_sbox[i]]++;

    all_unique = 1;
    for (i = 0; i < 256; i++) {
        if (count[i] != 1) { all_unique = 0; break; }
    }
    check(all_unique, "sbox/permutation");

    /* Test 2: S-box is not identity */
    {
        int identity = 1;
        for (i = 0; i < 256; i++) {
            if (g_sbox[i] != (unsigned char)i) { identity = 0; break; }
        }
        check(!identity, "sbox/not_identity");
    }

    /* Test 3: First entry = 0x63 (AES S-box first entry) */
    check(g_sbox[0] == 0x63, "sbox/first_entry");

    /* Test 4: Last entry = 0x16 */
    check(g_sbox[255] == 0x16, "sbox/last_entry");

    /* Test 5: No fixed points (or at least not all fixed) */
    {
        int fixed = 0;
        for (i = 0; i < 256; i++) {
            if (g_sbox[i] == (unsigned char)i) fixed++;
        }
        check(fixed < 256, "sbox/not_all_fixed");
    }
}

/* ================================================================
 * RC4 internal state test
 * ================================================================ */
static void test_rc4_state(void) {
    /* Verify KSA produces a proper permutation */
    {
        rc4_state st;
        unsigned char key[] = {0x01, 0x23, 0x45, 0x67, 0x89};
        int count[256];
        int i, ok;

        rc4_ksa(&st, key, 5);

        for (i = 0; i < 256; i++) count[i] = 0;
        for (i = 0; i < 256; i++) count[st.S[i]]++;

        ok = 1;
        for (i = 0; i < 256; i++) {
            if (count[i] != 1) { ok = 0; break; }
        }
        check(ok, "rc4/ksa_permutation");
    }

    /* KSA with different keys gives different permutations */
    {
        rc4_state st1, st2;
        unsigned char k1[] = {0x00};
        unsigned char k2[] = {0xFF};
        int differ = 0, i;

        rc4_ksa(&st1, k1, 1);
        rc4_ksa(&st2, k2, 1);

        for (i = 0; i < 256; i++) {
            if (st1.S[i] != st2.S[i]) { differ = 1; break; }
        }
        check(differ, "rc4/ksa_diff_keys");
    }

    /* Stream output is not all zeros */
    {
        rc4_state st;
        unsigned char key[] = {0x42};
        int i, all_zero;
        unsigned char byte;

        rc4_ksa(&st, key, 1);
        all_zero = 1;
        for (i = 0; i < 256; i++) {
            byte = rc4_prga(&st);
            if (byte != 0) { all_zero = 0; break; }
        }
        check(!all_zero, "rc4/stream_not_zero");
    }
}

/* ================================================================
 * Comprehensive encrypt/decrypt stress test
 * ================================================================ */
static void test_encrypt_decrypt_stress(void) {
    int trial;

    write_str("  Encrypt/decrypt stress (50 trials)...\n");

    for (trial = 0; trial < 50; trial++) {
        unsigned int v[2];
        unsigned int orig[2];
        unsigned int k[4];

        /* Use trial number to generate deterministic test data */
        v[0] = (unsigned int)(trial * 0x13579BDFu + 0x02468ACEu);
        v[1] = (unsigned int)(trial * 0x0FEDCBA9u + 0x87654321u);
        k[0] = (unsigned int)(trial * 111 + 1);
        k[1] = (unsigned int)(trial * 222 + 2);
        k[2] = (unsigned int)(trial * 333 + 3);
        k[3] = (unsigned int)(trial * 444 + 4);
        orig[0] = v[0]; orig[1] = v[1];

        /* TEA round-trip */
        tea_encrypt(v, k);
        tea_decrypt(v, k);
        if (v[0] != orig[0] || v[1] != orig[1]) {
            check(0, "stress/tea");
            return;
        }

        /* XTEA round-trip */
        v[0] = orig[0]; v[1] = orig[1];
        xtea_encrypt(v, k);
        xtea_decrypt(v, k);
        if (v[0] != orig[0] || v[1] != orig[1]) {
            check(0, "stress/xtea");
            return;
        }

        /* Feistel round-trip */
        v[0] = orig[0]; v[1] = orig[1];
        feistel_encrypt(v, k);
        feistel_decrypt(v, k);
        if (v[0] != orig[0] || v[1] != orig[1]) {
            check(0, "stress/feistel");
            return;
        }
    }
    check(1, "stress/tea_50");
    check(1, "stress/xtea_50");
    check(1, "stress/feistel_50");
}

/* ================================================================
 * RC4 longer message stress
 * ================================================================ */
static void test_rc4_stress(void) {
    int trial;

    write_str("  RC4 stress (20 trials)...\n");

    for (trial = 0; trial < 20; trial++) {
        unsigned char key[16];
        unsigned char plain[128];
        unsigned char cipher[128];
        unsigned char decrypted[128];
        int i;
        int keylen = (trial % 15) + 1;
        int msglen = (trial + 1) * 6;

        if (msglen > 128) msglen = 128;

        for (i = 0; i < keylen; i++) key[i] = (unsigned char)(trial * 7 + i * 13);
        for (i = 0; i < msglen; i++) plain[i] = (unsigned char)(trial * 3 + i * 5);

        rc4_crypt(key, keylen, plain, cipher, msglen);
        rc4_crypt(key, keylen, cipher, decrypted, msglen);

        if (!mem_eq(plain, decrypted, msglen)) {
            check(0, "rc4/stress");
            return;
        }
    }
    check(1, "rc4/stress_20");
}

/* ================================================================
 * ECB/CBC block mode stress
 * ================================================================ */
static void test_block_mode_stress(void) {
    int trial;

    write_str("  Block mode stress (16 trials)...\n");

    for (trial = 0; trial < 16; trial++) {
        unsigned char data[64];
        unsigned char orig[64];
        unsigned int key[4];
        unsigned char iv[8];
        int i;
        int len = ((trial % 8) + 1) * 8; /* 8, 16, 24, ..., 64 */

        key[0] = (unsigned int)(trial * 1111 + 100);
        key[1] = (unsigned int)(trial * 2222 + 200);
        key[2] = (unsigned int)(trial * 3333 + 300);
        key[3] = (unsigned int)(trial * 4444 + 400);

        for (i = 0; i < 8; i++) iv[i] = (unsigned char)(trial * 17 + i);
        for (i = 0; i < len; i++) data[i] = (unsigned char)(trial * 5 + i * 3);
        mem_copy(orig, data, len);

        /* ECB */
        tea_ecb_encrypt(data, len, key);
        tea_ecb_decrypt(data, len, key);
        if (!mem_eq(data, orig, len)) {
            check(0, "stress/ecb");
            return;
        }

        /* CBC */
        mem_copy(data, orig, len);
        tea_cbc_encrypt(data, len, key, iv);
        tea_cbc_decrypt(data, len, key, iv);
        if (!mem_eq(data, orig, len)) {
            check(0, "stress/cbc");
            return;
        }
    }
    check(1, "stress/ecb_16");
    check(1, "stress/cbc_16");
}

/* ================================================================
 * Hash collision resistance (basic check)
 * ================================================================ */
static void test_hash_collision_basic(void) {
    unsigned int hashes_fnv[100];
    unsigned int hashes_djb[100];
    unsigned int hashes_sdbm[100];
    unsigned int hashes_crc[100];
    unsigned char buf[8];
    int i, j;
    int fnv_collisions = 0, djb_collisions = 0, sdbm_collisions = 0, crc_collisions = 0;

    write_str("  Hash collision resistance (100 inputs)...\n");

    for (i = 0; i < 100; i++) {
        /* Generate deterministic 8-byte input from index */
        buf[0] = (unsigned char)(i);
        buf[1] = (unsigned char)(i >> 8);
        buf[2] = (unsigned char)(i * 7);
        buf[3] = (unsigned char)(i * 13);
        buf[4] = (unsigned char)(i ^ 0xAA);
        buf[5] = (unsigned char)(i + 55);
        buf[6] = (unsigned char)(i * 3 + 1);
        buf[7] = (unsigned char)(i * 11 + 7);

        hashes_fnv[i] = fnv1a_hash(buf, 8);
        hashes_djb[i] = djb2_hash(buf, 8);
        hashes_sdbm[i] = sdbm_hash(buf, 8);
        hashes_crc[i] = crc32_compute(buf, 8);
    }

    /* Count collisions */
    for (i = 0; i < 100; i++) {
        for (j = i + 1; j < 100; j++) {
            if (hashes_fnv[i] == hashes_fnv[j]) fnv_collisions++;
            if (hashes_djb[i] == hashes_djb[j]) djb_collisions++;
            if (hashes_sdbm[i] == hashes_sdbm[j]) sdbm_collisions++;
            if (hashes_crc[i] == hashes_crc[j]) crc_collisions++;
        }
    }

    check(fnv_collisions == 0, "collision/fnv1a_none");
    check(djb_collisions == 0, "collision/djb2_none");
    check(sdbm_collisions == 0, "collision/sdbm_none");
    check(crc_collisions == 0, "collision/crc32_none");
}

/* ================================================================
 * CRC32 incremental property test
 * ================================================================ */
static void test_crc32_properties(void) {
    /* CRC of concatenation test: CRC("AB") should differ from CRC("A") and CRC("B") */
    {
        unsigned int ca = crc32_compute((const unsigned char *)"A", 1);
        unsigned int cb = crc32_compute((const unsigned char *)"B", 1);
        unsigned int cab = crc32_compute((const unsigned char *)"AB", 2);

        check(cab != ca, "crc32/concat_not_a");
        check(cab != cb, "crc32/concat_not_b");
        check(cab != (ca ^ cb), "crc32/not_simple_xor");
    }

    /* Length sensitivity */
    {
        unsigned int c1 = crc32_compute((const unsigned char *)"aaa", 3);
        unsigned int c2 = crc32_compute((const unsigned char *)"aaaa", 4);
        check(c1 != c2, "crc32/length_sensitive");
    }

    /* Single bit flip */
    {
        unsigned char d1[4] = {0x00, 0x00, 0x00, 0x00};
        unsigned char d2[4] = {0x01, 0x00, 0x00, 0x00};
        unsigned int c1 = crc32_compute(d1, 4);
        unsigned int c2 = crc32_compute(d2, 4);
        check(c1 != c2, "crc32/bit_flip");
    }
}

/* ================================================================
 * Feistel cipher specific F-function tests
 * ================================================================ */
static void test_feistel_f_function(void) {
    /* F function should use S-box and produce non-trivial output */
    {
        unsigned int out1 = feistel_f(0x00000000u, 0x00000000u);
        unsigned int out2 = feistel_f(0x00000001u, 0x00000000u);

        /* sbox[0] = 0x63 for the zero input bytes */
        check(out1 != 0, "feistel_f/zero_input_nonzero");
        check(out1 != out2, "feistel_f/diff_input");
    }

    /* F function is deterministic */
    {
        unsigned int r1 = feistel_f(0xDEADBEEFu, 0xCAFEBABEu);
        unsigned int r2 = feistel_f(0xDEADBEEFu, 0xCAFEBABEu);
        check(r1 == r2, "feistel_f/deterministic");
    }

    /* Key changes output */
    {
        unsigned int r1 = feistel_f(0x12345678u, 0x00000000u);
        unsigned int r2 = feistel_f(0x12345678u, 0xFFFFFFFFu);
        check(r1 != r2, "feistel_f/key_effect");
    }
}

/* ================================================================
 * TEA known answer test (additional verification)
 * ================================================================ */
static void test_tea_known_answer(void) {
    /* TEA encrypt with all-zero key and all-zero plaintext */
    {
        unsigned int v[2] = {0, 0};
        unsigned int k[4] = {0, 0, 0, 0};
        tea_encrypt(v, k);
        /* Write the actual output for reference */
        write_str("  TEA(0,0,0,0)(0,0) = ");
        write_hex32(v[0]);
        write_str(" ");
        write_hex32(v[1]);
        write_str("\n");

        /* Verify it's deterministic by encrypting again */
        {
            unsigned int v2[2] = {0, 0};
            tea_encrypt(v2, k);
            check(v[0] == v2[0] && v[1] == v2[1], "tea/known_deterministic");
        }
    }

    /* XTEA with same parameters */
    {
        unsigned int v[2] = {0, 0};
        unsigned int k[4] = {0, 0, 0, 0};
        xtea_encrypt(v, k);
        write_str("  XTEA(0,0,0,0)(0,0) = ");
        write_hex32(v[0]);
        write_str(" ");
        write_hex32(v[1]);
        write_str("\n");

        {
            unsigned int v2[2] = {0, 0};
            xtea_encrypt(v2, k);
            check(v[0] == v2[0] && v[1] == v2[1], "xtea/known_deterministic");
        }
    }
}

/* ================================================================
 * Chained encryption test
 * ================================================================ */
static void test_chained_encryption(void) {
    /* Encrypt with TEA, then XTEA, then Feistel; decrypt in reverse */
    {
        unsigned int v[2] = {0xFACEFEEDu, 0xBAADF00Du};
        unsigned int orig[2] = {0xFACEFEEDu, 0xBAADF00Du};
        unsigned int k1[4] = {1, 2, 3, 4};
        unsigned int k2[4] = {5, 6, 7, 8};
        unsigned int k3[4] = {9, 10, 11, 12};

        tea_encrypt(v, k1);
        xtea_encrypt(v, k2);
        feistel_encrypt(v, k3);

        feistel_decrypt(v, k3);
        xtea_decrypt(v, k2);
        tea_decrypt(v, k1);

        check(v[0] == orig[0] && v[1] == orig[1], "chained/tea_xtea_feistel");
    }

    /* RC4 -> TEA-ECB -> RC4 -> TEA-ECB decrypt chain */
    {
        unsigned char data[16];
        unsigned char orig[16];
        unsigned char rc4_key[] = {0xDE, 0xAD};
        unsigned int tea_key[4] = {0x11u, 0x22u, 0x33u, 0x44u};
        unsigned char tmp[16];
        int i;

        for (i = 0; i < 16; i++) data[i] = (unsigned char)(i * 17);
        mem_copy(orig, data, 16);

        /* Encrypt: RC4 -> TEA-ECB */
        rc4_crypt(rc4_key, 2, data, tmp, 16);
        mem_copy(data, tmp, 16);
        tea_ecb_encrypt(data, 16, tea_key);

        /* Decrypt: TEA-ECB -> RC4 */
        tea_ecb_decrypt(data, 16, tea_key);
        rc4_crypt(rc4_key, 2, data, tmp, 16);
        mem_copy(data, tmp, 16);

        check(mem_eq(data, orig, 16), "chained/rc4_ecb");
    }
}

/* ================================================================
 * Hash distribution test (check bit spread)
 * ================================================================ */
static void test_hash_distribution(void) {
    /* For 1000 sequential inputs, check that high and low bits are used */
    {
        int i;
        unsigned int or_accum = 0;
        unsigned int and_accum = 0xFFFFFFFFu;
        unsigned char buf[4];

        for (i = 0; i < 1000; i++) {
            unsigned int h;
            buf[0] = (unsigned char)(i & 0xFF);
            buf[1] = (unsigned char)((i >> 8) & 0xFF);
            buf[2] = 0; buf[3] = 0;
            h = fnv1a_hash(buf, 4);
            or_accum |= h;
            and_accum &= h;
        }
        /* All 32 bits should be set in at least one hash */
        check(or_accum == 0xFFFFFFFFu, "dist/fnv1a_all_bits_set");
        /* Not all bits are always 1 */
        check(and_accum != 0xFFFFFFFFu, "dist/fnv1a_not_all_ones");
    }

    /* Same for DJB2 (use more varied inputs to exercise all bits) */
    {
        int i;
        unsigned int or_accum = 0;
        unsigned char buf[8];

        for (i = 0; i < 2000; i++) {
            unsigned int h;
            buf[0] = (unsigned char)(i & 0xFF);
            buf[1] = (unsigned char)((i >> 8) & 0xFF);
            buf[2] = (unsigned char)(i * 7);
            buf[3] = (unsigned char)(i * 13);
            buf[4] = (unsigned char)(i ^ 0xAA);
            buf[5] = (unsigned char)(i + 55);
            buf[6] = (unsigned char)(i * 3 + 1);
            buf[7] = (unsigned char)(i * 11 + 7);
            h = djb2_hash(buf, 8);
            or_accum |= h;
        }
        check(or_accum == 0xFFFFFFFFu, "dist/djb2_all_bits_set");
    }

    /* Same for CRC32 */
    {
        int i;
        unsigned int or_accum = 0;
        unsigned char buf[4];

        for (i = 0; i < 1000; i++) {
            unsigned int h;
            buf[0] = (unsigned char)(i & 0xFF);
            buf[1] = (unsigned char)((i >> 8) & 0xFF);
            buf[2] = 0; buf[3] = 0;
            h = crc32_compute(buf, 4);
            or_accum |= h;
        }
        check(or_accum == 0xFFFFFFFFu, "dist/crc32_all_bits_set");
    }
}

/* ================================================================
 * HMAC verify/tamper test
 * ================================================================ */
static void test_hmac_verify_tamper(void) {
    unsigned char key[] = {0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49};
    unsigned char msg[] = "This is the authentic message";
    unsigned char tampered[] = "This is the authentiC message"; /* one bit changed */
    unsigned int mac_orig, mac_tampered;

    mac_orig = hmac_fnv1a(key, 8, msg, 29);
    mac_tampered = hmac_fnv1a(key, 8, tampered, 29);
    check(mac_orig != mac_tampered, "hmac/tamper_detect");

    /* Verify same message produces same MAC */
    {
        unsigned int mac2 = hmac_fnv1a(key, 8, msg, 29);
        check(mac_orig == mac2, "hmac/verify_pass");
    }
}

/* ================================================================
 * Integration: hash-then-encrypt-then-hash
 * ================================================================ */
static void test_hash_encrypt_hash(void) {
    unsigned char msg[] = "Integration test payload data!"; /* 30 bytes */
    unsigned int pre_hash, post_hash;
    unsigned char padded[32]; /* pad to 32 for block cipher */
    unsigned char orig_padded[32];
    unsigned int key[4] = {0xDEADu, 0xBEEFu, 0xCAFEu, 0xBABEu};
    unsigned char iv[8] = {1, 2, 3, 4, 5, 6, 7, 8};

    mem_zero(padded, 32);
    mem_copy(padded, msg, 30);
    mem_copy(orig_padded, padded, 32);

    pre_hash = crc32_compute(padded, 32);

    /* Encrypt then decrypt */
    tea_cbc_encrypt(padded, 32, key, iv);
    tea_cbc_decrypt(padded, 32, key, iv);

    post_hash = crc32_compute(padded, 32);

    check(pre_hash == post_hash, "integration/hash_encrypt_hash");
    check(mem_eq(padded, orig_padded, 32), "integration/data_preserved");
}

/* ================================================================
 * main
 * ================================================================ */
int main(void) {
    g_errs = 0;
    init_io();

    /* Initialize CRC32 table */
    crc32_init_table();

    write_str("=== victim_crypto.c test suite ===\n\n");

    /* Section 1: RC4 */
    write_str("[RC4]\n");
    test_rc4_roundtrip();
    test_rc4_state();
    test_rc4_stress();

    /* Section 2: TEA */
    write_str("\n[TEA]\n");
    test_tea();
    test_tea_known_answer();

    /* Section 3: XTEA */
    write_str("\n[XTEA]\n");
    test_xtea();

    /* Section 4: Feistel */
    write_str("\n[Feistel]\n");
    test_feistel();
    test_feistel_f_function();

    /* Section 5: CRC32 */
    write_str("\n[CRC32]\n");
    test_crc32();
    test_crc32_properties();

    /* Section 6: FNV-1a */
    write_str("\n[FNV-1a]\n");
    test_fnv1a();

    /* Section 7: DJB2 */
    write_str("\n[DJB2]\n");
    test_djb2();

    /* Section 8: SDBM */
    write_str("\n[SDBM]\n");
    test_sdbm();

    /* Section 9: ECB mode */
    write_str("\n[ECB mode]\n");
    test_ecb();

    /* Section 10: CBC mode */
    write_str("\n[CBC mode]\n");
    test_cbc();

    /* Section 11: HMAC-FNV1a */
    write_str("\n[HMAC-FNV1a]\n");
    test_hmac_fnv1a();
    test_hmac_verify_tamper();

    /* Section 12: S-box */
    write_str("\n[S-box]\n");
    test_sbox();

    /* Section 13: Cross-algorithm */
    write_str("\n[Cross-algorithm]\n");
    test_cross_algorithm();

    /* Section 14: Encrypt/decrypt stress */
    write_str("\n[Encrypt/decrypt stress]\n");
    test_encrypt_decrypt_stress();
    test_block_mode_stress();

    /* Section 15: Hash collision resistance */
    write_str("\n[Hash collision resistance]\n");
    test_hash_collision_basic();

    /* Section 16: Hash distribution */
    write_str("\n[Hash distribution]\n");
    test_hash_distribution();

    /* Section 17: Chained encryption */
    write_str("\n[Chained encryption]\n");
    test_chained_encryption();

    /* Section 18: Integration */
    write_str("\n[Integration]\n");
    test_hash_encrypt_hash();

    write_str("\n=== Done ===\n");
    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
