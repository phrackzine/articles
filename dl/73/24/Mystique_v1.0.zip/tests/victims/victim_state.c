/* victim_state.c - State machines, parsers, and interpreters stress test
 * Build: cl /nologo /O1 victim_state.c /Fe:victim_state.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * Deterministic output, Windows x86-32 (MSVC)
 */
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ======================================================================
 * DFA SIMULATOR
 * ====================================================================== */

#define DFA_MAX_STATES 32
#define DFA_MAX_ALPHA  128

typedef struct {
    int transitions[DFA_MAX_STATES][DFA_MAX_ALPHA];
    int accept[DFA_MAX_STATES];
    int num_states;
    int start_state;
} DFA;

static void dfa_init(DFA *d, int num_states, int start) {
    int i, j;
    d->num_states = num_states;
    d->start_state = start;
    for (i = 0; i < DFA_MAX_STATES; i++) {
        d->accept[i] = 0;
        for (j = 0; j < DFA_MAX_ALPHA; j++)
            d->transitions[i][j] = -1; /* -1 = dead state */
    }
}

static void dfa_set_transition(DFA *d, int from, int ch, int to) {
    d->transitions[from][ch] = to;
}

static void dfa_set_accept(DFA *d, int state) {
    d->accept[state] = 1;
}

static int dfa_run(DFA *d, const char *input) {
    int state = d->start_state;
    while (*input) {
        int ch = (unsigned char)*input++;
        if (ch >= DFA_MAX_ALPHA) return 0;
        state = d->transitions[state][ch];
        if (state < 0) return 0;
    }
    return d->accept[state];
}

/* Build DFA that accepts strings matching "ab*c" */
static void build_dfa_abc(DFA *d) {
    dfa_init(d, 3, 0);
    /* State 0: start, expects 'a' */
    dfa_set_transition(d, 0, 'a', 1);
    /* State 1: after 'a', loop on 'b', go to 2 on 'c' */
    dfa_set_transition(d, 1, 'b', 1);
    dfa_set_transition(d, 1, 'c', 2);
    /* State 2: accept */
    dfa_set_accept(d, 2);
}

/* Build DFA that accepts binary strings divisible by 3 */
static void build_dfa_div3(DFA *d) {
    /* States: remainder 0, 1, 2 */
    dfa_init(d, 3, 0);
    dfa_set_transition(d, 0, '0', 0);
    dfa_set_transition(d, 0, '1', 1);
    dfa_set_transition(d, 1, '0', 2);
    dfa_set_transition(d, 1, '1', 0);
    dfa_set_transition(d, 2, '0', 1);
    dfa_set_transition(d, 2, '1', 2);
    dfa_set_accept(d, 0);
}

/* ======================================================================
 * NFA TO DFA CONVERSION (SUBSET CONSTRUCTION)
 * ====================================================================== */

#define NFA_MAX_STATES 16
#define NFA_MAX_ALPHA  4    /* small alphabet for subset construction */
#define NFA_MAX_TRANS  8    /* max transitions per (state, symbol) */

typedef struct {
    int transitions[NFA_MAX_STATES][NFA_MAX_ALPHA][NFA_MAX_TRANS];
    int num_trans[NFA_MAX_STATES][NFA_MAX_ALPHA];
    int epsilon[NFA_MAX_STATES][NFA_MAX_TRANS]; /* epsilon transitions */
    int num_epsilon[NFA_MAX_STATES];
    int accept[NFA_MAX_STATES];
    int num_states;
    int start_state;
    int alphabet_size;
} NFA;

static void nfa_init(NFA *n, int num_states, int start, int alpha_size) {
    int i, j;
    n->num_states = num_states;
    n->start_state = start;
    n->alphabet_size = alpha_size;
    for (i = 0; i < NFA_MAX_STATES; i++) {
        n->accept[i] = 0;
        n->num_epsilon[i] = 0;
        for (j = 0; j < NFA_MAX_ALPHA; j++)
            n->num_trans[i][j] = 0;
    }
}

static void nfa_add_transition(NFA *n, int from, int sym, int to) {
    int idx = n->num_trans[from][sym];
    if (idx < NFA_MAX_TRANS) {
        n->transitions[from][sym][idx] = to;
        n->num_trans[from][sym]++;
    }
}

static void nfa_add_epsilon(NFA *n, int from, int to) {
    int idx = n->num_epsilon[from];
    if (idx < NFA_MAX_TRANS) {
        n->epsilon[from][idx] = to;
        n->num_epsilon[from]++;
    }
}

/* Compute epsilon closure of a set of states */
static void epsilon_closure(NFA *n, unsigned int *set) {
    int changed = 1;
    while (changed) {
        changed = 0;
        int s;
        for (s = 0; s < n->num_states; s++) {
            if (*set & (1u << s)) {
                int e;
                for (e = 0; e < n->num_epsilon[s]; e++) {
                    int target = n->epsilon[s][e];
                    if (!(*set & (1u << target))) {
                        *set |= (1u << target);
                        changed = 1;
                    }
                }
            }
        }
    }
}

/* Move: from a set of states, follow symbol transitions */
static unsigned int nfa_move(NFA *n, unsigned int set, int sym) {
    unsigned int result = 0;
    int s;
    for (s = 0; s < n->num_states; s++) {
        if (set & (1u << s)) {
            int t;
            for (t = 0; t < n->num_trans[s][sym]; t++) {
                result |= (1u << n->transitions[s][sym][t]);
            }
        }
    }
    return result;
}

/* NFA to DFA conversion */
typedef struct {
    unsigned int nfa_states; /* bitmask of NFA states */
    int dfa_state;
} SubsetEntry;

static int nfa_to_dfa(NFA *n, DFA *d) {
    SubsetEntry worklist[256];
    SubsetEntry dfa_sets[256];
    int num_dfa = 0, wl_head = 0, wl_tail = 0;
    unsigned int start_set;
    int sym;

    dfa_init(d, 0, 0);

    /* Start set = epsilon closure of {start_state} */
    start_set = 1u << n->start_state;
    epsilon_closure(n, &start_set);

    dfa_sets[0].nfa_states = start_set;
    dfa_sets[0].dfa_state = 0;
    num_dfa = 1;
    d->num_states = 1;
    worklist[wl_tail++] = dfa_sets[0];

    /* Check if start is accepting */
    {
        int s;
        for (s = 0; s < n->num_states; s++) {
            if ((start_set & (1u << s)) && n->accept[s]) {
                dfa_set_accept(d, 0);
                break;
            }
        }
    }

    while (wl_head < wl_tail) {
        SubsetEntry current = worklist[wl_head++];
        for (sym = 0; sym < n->alphabet_size; sym++) {
            unsigned int moved = nfa_move(n, current.nfa_states, sym);
            int found_idx = -1;
            int k;
            if (moved == 0) continue;
            epsilon_closure(n, &moved);

            /* Check if this DFA state already exists */
            for (k = 0; k < num_dfa; k++) {
                if (dfa_sets[k].nfa_states == moved) {
                    found_idx = k;
                    break;
                }
            }
            if (found_idx < 0) {
                found_idx = num_dfa;
                dfa_sets[num_dfa].nfa_states = moved;
                dfa_sets[num_dfa].dfa_state = num_dfa;
                num_dfa++;
                d->num_states = num_dfa;
                worklist[wl_tail++] = dfa_sets[found_idx];

                /* Check if accepting */
                {
                    int s;
                    for (s = 0; s < n->num_states; s++) {
                        if ((moved & (1u << s)) && n->accept[s]) {
                            dfa_set_accept(d, found_idx);
                            break;
                        }
                    }
                }
            }
            dfa_set_transition(d, current.dfa_state, sym, dfa_sets[found_idx].dfa_state);
        }
    }
    return num_dfa;
}

/* ======================================================================
 * SIMPLE REGEX MATCHER
 * Supports: literal chars, '.', '*', '+', '?', character classes [a-z]
 * ====================================================================== */

#define RE_LITERAL  1
#define RE_DOT      2
#define RE_STAR     3
#define RE_PLUS     4
#define RE_QUEST    5
#define RE_CLASS    6

typedef struct {
    int type;        /* RE_LITERAL, RE_DOT, RE_CLASS */
    int quantifier;  /* 0=none, RE_STAR, RE_PLUS, RE_QUEST */
    char literal;
    char class_chars[128]; /* for character classes */
    int class_len;
} ReAtom;

typedef struct {
    ReAtom atoms[64];
    int num_atoms;
} Regex;

static int regex_compile(Regex *re, const char *pattern) {
    int pi = 0;
    re->num_atoms = 0;
    while (pattern[pi]) {
        ReAtom *a = &re->atoms[re->num_atoms];
        a->quantifier = 0;
        a->class_len = 0;
        if (pattern[pi] == '.') {
            a->type = RE_DOT;
            pi++;
        } else if (pattern[pi] == '[') {
            int neg = 0;
            pi++;
            if (pattern[pi] == '^') { neg = 1; pi++; }
            a->type = RE_CLASS;
            a->class_len = 0;
            while (pattern[pi] && pattern[pi] != ']') {
                if (pattern[pi + 1] == '-' && pattern[pi + 2] && pattern[pi + 2] != ']') {
                    char lo = pattern[pi], hi = pattern[pi + 2];
                    char c;
                    for (c = lo; c <= hi; c++) {
                        if (a->class_len < 127) a->class_chars[a->class_len++] = c;
                    }
                    pi += 3;
                } else {
                    if (a->class_len < 127) a->class_chars[a->class_len++] = pattern[pi];
                    pi++;
                }
            }
            if (pattern[pi] == ']') pi++;
            /* Handle negation by building complement */
            if (neg) {
                char tmp[128];
                int tlen = 0;
                int ci;
                for (ci = 32; ci < 127; ci++) {
                    int found = 0;
                    int j;
                    for (j = 0; j < a->class_len; j++) {
                        if (a->class_chars[j] == (char)ci) { found = 1; break; }
                    }
                    if (!found && tlen < 127) tmp[tlen++] = (char)ci;
                }
                memcpy(a->class_chars, tmp, (size_t)tlen);
                a->class_len = tlen;
            }
        } else {
            a->type = RE_LITERAL;
            a->literal = pattern[pi++];
        }
        /* Check for quantifier */
        if (pattern[pi] == '*') { a->quantifier = RE_STAR; pi++; }
        else if (pattern[pi] == '+') { a->quantifier = RE_PLUS; pi++; }
        else if (pattern[pi] == '?') { a->quantifier = RE_QUEST; pi++; }
        re->num_atoms++;
    }
    return 1;
}

static int atom_matches(ReAtom *a, char c) {
    int j;
    if (a->type == RE_DOT) return c != '\0';
    if (a->type == RE_LITERAL) return c == a->literal;
    if (a->type == RE_CLASS) {
        for (j = 0; j < a->class_len; j++) {
            if (a->class_chars[j] == c) return 1;
        }
        return 0;
    }
    return 0;
}

static int regex_match_from(Regex *re, int atom_idx, const char *s, int si);

static int regex_match_from(Regex *re, int atom_idx, const char *s, int si) {
    int count;
    ReAtom *a;
    if (atom_idx >= re->num_atoms) {
        return s[si] == '\0'; /* full match */
    }
    a = &re->atoms[atom_idx];
    if (a->quantifier == RE_STAR) {
        /* Try matching 0 or more */
        if (regex_match_from(re, atom_idx + 1, s, si)) return 1;
        count = 0;
        while (s[si + count] && atom_matches(a, s[si + count])) {
            count++;
            if (regex_match_from(re, atom_idx + 1, s, si + count)) return 1;
        }
        return 0;
    }
    if (a->quantifier == RE_PLUS) {
        /* Must match at least 1 */
        count = 0;
        while (s[si + count] && atom_matches(a, s[si + count])) {
            count++;
            if (regex_match_from(re, atom_idx + 1, s, si + count)) return 1;
        }
        return 0;
    }
    if (a->quantifier == RE_QUEST) {
        /* Match 0 or 1 */
        if (regex_match_from(re, atom_idx + 1, s, si)) return 1;
        if (s[si] && atom_matches(a, s[si]))
            return regex_match_from(re, atom_idx + 1, s, si + 1);
        return 0;
    }
    /* No quantifier: must match exactly 1 */
    if (!s[si]) return 0;
    if (!atom_matches(a, s[si])) return 0;
    return regex_match_from(re, atom_idx + 1, s, si + 1);
}

static int regex_match(const char *pattern, const char *str) {
    Regex re;
    regex_compile(&re, pattern);
    return regex_match_from(&re, 0, str, 0);
}

/* ======================================================================
 * TOKENIZER / LEXER for simple expression language
 * ====================================================================== */

#define TOK_NUM    1
#define TOK_PLUS   2
#define TOK_MINUS  3
#define TOK_MUL    4
#define TOK_DIV    5
#define TOK_LPAREN 6
#define TOK_RPAREN 7
#define TOK_EOF    8
#define TOK_ERR    9

typedef struct {
    int type;
    int value; /* for TOK_NUM */
} Token;

typedef struct {
    const char *input;
    int pos;
    Token current;
} Lexer;

static void lexer_init(Lexer *lex, const char *input) {
    lex->input = input;
    lex->pos = 0;
    lex->current.type = TOK_ERR;
}

static void lexer_skip_ws(Lexer *lex) {
    while (lex->input[lex->pos] == ' ' || lex->input[lex->pos] == '\t')
        lex->pos++;
}

static Token lexer_next(Lexer *lex) {
    Token tok;
    lexer_skip_ws(lex);
    if (lex->input[lex->pos] == '\0') {
        tok.type = TOK_EOF; tok.value = 0;
    } else if (lex->input[lex->pos] >= '0' && lex->input[lex->pos] <= '9') {
        tok.type = TOK_NUM;
        tok.value = 0;
        while (lex->input[lex->pos] >= '0' && lex->input[lex->pos] <= '9') {
            tok.value = tok.value * 10 + (lex->input[lex->pos] - '0');
            lex->pos++;
        }
    } else {
        tok.value = 0;
        switch (lex->input[lex->pos]) {
            case '+': tok.type = TOK_PLUS; break;
            case '-': tok.type = TOK_MINUS; break;
            case '*': tok.type = TOK_MUL; break;
            case '/': tok.type = TOK_DIV; break;
            case '(': tok.type = TOK_LPAREN; break;
            case ')': tok.type = TOK_RPAREN; break;
            default: tok.type = TOK_ERR; break;
        }
        lex->pos++;
    }
    lex->current = tok;
    return tok;
}

/* ======================================================================
 * RECURSIVE DESCENT PARSER + EVALUATOR
 * Grammar:
 *   expr   -> term (('+' | '-') term)*
 *   term   -> factor (('*' | '/') factor)*
 *   factor -> NUMBER | '(' expr ')' | '-' factor
 * ====================================================================== */

typedef struct {
    Lexer lex;
    int error;
} Parser;

static void parser_init(Parser *p, const char *input) {
    lexer_init(&p->lex, input);
    p->error = 0;
    lexer_next(&p->lex);
}

static int parse_expr(Parser *p);

static int parse_factor(Parser *p) {
    int val;
    if (p->error) return 0;
    if (p->lex.current.type == TOK_NUM) {
        val = p->lex.current.value;
        lexer_next(&p->lex);
        return val;
    }
    if (p->lex.current.type == TOK_MINUS) {
        lexer_next(&p->lex);
        return -parse_factor(p);
    }
    if (p->lex.current.type == TOK_LPAREN) {
        lexer_next(&p->lex);
        val = parse_expr(p);
        if (p->lex.current.type != TOK_RPAREN) {
            p->error = 1;
            return 0;
        }
        lexer_next(&p->lex);
        return val;
    }
    p->error = 1;
    return 0;
}

static int parse_term(Parser *p) {
    int val = parse_factor(p);
    while (!p->error && (p->lex.current.type == TOK_MUL || p->lex.current.type == TOK_DIV)) {
        int op = p->lex.current.type;
        lexer_next(&p->lex);
        if (op == TOK_MUL) val *= parse_factor(p);
        else {
            int div = parse_factor(p);
            if (div == 0) { p->error = 1; return 0; }
            val /= div;
        }
    }
    return val;
}

static int parse_expr(Parser *p) {
    int val = parse_term(p);
    while (!p->error && (p->lex.current.type == TOK_PLUS || p->lex.current.type == TOK_MINUS)) {
        int op = p->lex.current.type;
        lexer_next(&p->lex);
        if (op == TOK_PLUS) val += parse_term(p);
        else val -= parse_term(p);
    }
    return val;
}

static int eval_expr(const char *input, int *error) {
    Parser p;
    int result;
    parser_init(&p, input);
    result = parse_expr(&p);
    *error = p.error;
    if (p.lex.current.type != TOK_EOF) *error = 1;
    return result;
}

/* ======================================================================
 * STACK-BASED BYTECODE VM
 * ====================================================================== */

#define VM_PUSH  1
#define VM_POP   2
#define VM_ADD   3
#define VM_SUB   4
#define VM_MUL   5
#define VM_DIV   6
#define VM_DUP   7
#define VM_SWAP  8
#define VM_PRINT 9
#define VM_HALT  10

#define VM_STACK_SIZE 256
#define VM_MAX_OUTPUT 256

typedef struct {
    int stack[VM_STACK_SIZE];
    int sp;
    int output[VM_MAX_OUTPUT];
    int out_count;
    int error;
} VM;

static void vm_init(VM *vm) {
    vm->sp = 0;
    vm->out_count = 0;
    vm->error = 0;
}

static void vm_push(VM *vm, int val) {
    if (vm->sp >= VM_STACK_SIZE) { vm->error = 1; return; }
    vm->stack[vm->sp++] = val;
}

static int vm_pop(VM *vm) {
    if (vm->sp <= 0) { vm->error = 1; return 0; }
    return vm->stack[--vm->sp];
}

/* Program is array of ints: opcode [operand] ... */
static void vm_execute(VM *vm, const int *program, int prog_len) {
    int pc = 0;
    int a, b;
    while (pc < prog_len && !vm->error) {
        int op = program[pc++];
        switch (op) {
            case VM_PUSH:
                if (pc >= prog_len) { vm->error = 1; break; }
                vm_push(vm, program[pc++]);
                break;
            case VM_POP:
                vm_pop(vm);
                break;
            case VM_ADD:
                b = vm_pop(vm); a = vm_pop(vm);
                vm_push(vm, a + b);
                break;
            case VM_SUB:
                b = vm_pop(vm); a = vm_pop(vm);
                vm_push(vm, a - b);
                break;
            case VM_MUL:
                b = vm_pop(vm); a = vm_pop(vm);
                vm_push(vm, a * b);
                break;
            case VM_DIV:
                b = vm_pop(vm); a = vm_pop(vm);
                if (b == 0) { vm->error = 1; break; }
                vm_push(vm, a / b);
                break;
            case VM_DUP:
                if (vm->sp <= 0) { vm->error = 1; break; }
                vm_push(vm, vm->stack[vm->sp - 1]);
                break;
            case VM_SWAP:
                if (vm->sp < 2) { vm->error = 1; break; }
                a = vm->stack[vm->sp - 1];
                vm->stack[vm->sp - 1] = vm->stack[vm->sp - 2];
                vm->stack[vm->sp - 2] = a;
                break;
            case VM_PRINT:
                a = vm_pop(vm);
                if (vm->out_count < VM_MAX_OUTPUT)
                    vm->output[vm->out_count++] = a;
                break;
            case VM_HALT:
                return;
            default:
                vm->error = 1;
                break;
        }
    }
}

/* ======================================================================
 * BRAINFUCK INTERPRETER
 * ====================================================================== */

#define BF_TAPE_SIZE 1024
#define BF_MAX_OUTPUT 256

typedef struct {
    char tape[BF_TAPE_SIZE];
    int ptr;
    char output[BF_MAX_OUTPUT];
    int out_len;
    int error;
} BFInterp;

static void bf_init(BFInterp *bf) {
    memset(bf->tape, 0, BF_TAPE_SIZE);
    bf->ptr = 0;
    bf->out_len = 0;
    bf->error = 0;
}

static void bf_execute(BFInterp *bf, const char *code) {
    int pc = 0;
    int code_len = (int)strlen(code);
    int max_steps = 200000; /* prevent infinite loops */
    int steps = 0;
    while (pc < code_len && !bf->error && steps < max_steps) {
        steps++;
        switch (code[pc]) {
            case '>':
                bf->ptr++;
                if (bf->ptr >= BF_TAPE_SIZE) { bf->error = 1; return; }
                break;
            case '<':
                bf->ptr--;
                if (bf->ptr < 0) { bf->error = 1; return; }
                break;
            case '+':
                bf->tape[bf->ptr]++;
                break;
            case '-':
                bf->tape[bf->ptr]--;
                break;
            case '.':
                if (bf->out_len < BF_MAX_OUTPUT - 1)
                    bf->output[bf->out_len++] = bf->tape[bf->ptr];
                break;
            case ',':
                /* No input in test mode; set to 0 */
                bf->tape[bf->ptr] = 0;
                break;
            case '[':
                if (bf->tape[bf->ptr] == 0) {
                    int depth = 1;
                    pc++;
                    while (pc < code_len && depth > 0) {
                        if (code[pc] == '[') depth++;
                        else if (code[pc] == ']') depth--;
                        if (depth > 0) pc++;
                    }
                }
                break;
            case ']':
                if (bf->tape[bf->ptr] != 0) {
                    int depth = 1;
                    pc--;
                    while (pc >= 0 && depth > 0) {
                        if (code[pc] == ']') depth++;
                        else if (code[pc] == '[') depth--;
                        if (depth > 0) pc--;
                    }
                }
                break;
            default:
                break; /* ignore other characters */
        }
        pc++;
    }
    bf->output[bf->out_len] = '\0';
    if (steps >= max_steps) bf->error = 2; /* timeout */
}

/* ======================================================================
 * STATE MACHINE VALIDATORS
 * ====================================================================== */

/* Email-like pattern: [a-z0-9]+@[a-z]+\.[a-z]+ */
static int validate_email(const char *s) {
    int i = 0;
    int local_len = 0, domain_len = 0, tld_len = 0;
    /* local part: [a-z0-9._]+ */
    while (s[i] && ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= '0' && s[i] <= '9') ||
                    s[i] == '.' || s[i] == '_')) {
        local_len++; i++;
    }
    if (local_len == 0) return 0;
    if (s[i] != '@') return 0;
    i++;
    /* domain: [a-z0-9]+(.[a-z0-9]+)* */
    while (s[i] && ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= '0' && s[i] <= '9'))) {
        domain_len++; i++;
    }
    if (domain_len == 0) return 0;
    if (s[i] != '.') return 0;
    i++;
    /* tld: [a-z]+ */
    while (s[i] && s[i] >= 'a' && s[i] <= 'z') {
        tld_len++; i++;
    }
    if (tld_len < 2) return 0;
    if (s[i] != '\0') return 0;
    return 1;
}

/* IP address: N.N.N.N where N is 0-255 */
static int validate_ip(const char *s) {
    int octets = 0;
    int i = 0;
    while (octets < 4) {
        int val = 0, digits = 0;
        while (s[i] >= '0' && s[i] <= '9') {
            val = val * 10 + (s[i] - '0');
            digits++; i++;
            if (digits > 3) return 0;
        }
        if (digits == 0) return 0;
        if (val > 255) return 0;
        /* No leading zeros for multi-digit */
        if (digits > 1 && s[i - digits] == '0') return 0;
        octets++;
        if (octets < 4) {
            if (s[i] != '.') return 0;
            i++;
        }
    }
    return s[i] == '\0';
}

/* Date: YYYY-MM-DD */
static int validate_date(const char *s) {
    int year = 0, month = 0, day = 0;
    int i = 0, j;
    int days_in_month[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    /* Year: 4 digits */
    for (j = 0; j < 4; j++) {
        if (s[i] < '0' || s[i] > '9') return 0;
        year = year * 10 + (s[i++] - '0');
    }
    if (s[i++] != '-') return 0;
    /* Month: 2 digits */
    for (j = 0; j < 2; j++) {
        if (s[i] < '0' || s[i] > '9') return 0;
        month = month * 10 + (s[i++] - '0');
    }
    if (s[i++] != '-') return 0;
    /* Day: 2 digits */
    for (j = 0; j < 2; j++) {
        if (s[i] < '0' || s[i] > '9') return 0;
        day = day * 10 + (s[i++] - '0');
    }
    if (s[i] != '\0') return 0;
    if (month < 1 || month > 12) return 0;
    /* Leap year */
    if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0))
        days_in_month[2] = 29;
    if (day < 1 || day > days_in_month[month]) return 0;
    if (year < 1) return 0;
    return 1;
}

/* ======================================================================
 * TURING MACHINE SIMULATOR (3-state busy beaver)
 * ====================================================================== */

#define TM_TAPE_SIZE 256

typedef struct {
    int write_sym;
    int move; /* 0 = left, 1 = right */
    int next_state;
} TMRule;

typedef struct {
    char tape[TM_TAPE_SIZE];
    int head;
    int state;
    int halt_state;
    TMRule rules[16][2]; /* rules[state][read_symbol] */
    int num_states;
    int steps;
} TuringMachine;

static void tm_init(TuringMachine *tm, int num_states, int halt_state) {
    memset(tm->tape, 0, TM_TAPE_SIZE);
    tm->head = TM_TAPE_SIZE / 2;
    tm->state = 0;
    tm->halt_state = halt_state;
    tm->num_states = num_states;
    tm->steps = 0;
}

static void tm_set_rule(TuringMachine *tm, int state, int read_sym, int write_sym, int move, int next) {
    tm->rules[state][read_sym].write_sym = write_sym;
    tm->rules[state][read_sym].move = move;
    tm->rules[state][read_sym].next_state = next;
}

static int tm_run(TuringMachine *tm, int max_steps) {
    while (tm->state != tm->halt_state && tm->steps < max_steps) {
        int sym = (int)(unsigned char)tm->tape[tm->head];
        TMRule *r = &tm->rules[tm->state][sym];
        tm->tape[tm->head] = (char)r->write_sym;
        if (r->move == 0) tm->head--;
        else tm->head++;
        if (tm->head < 0 || tm->head >= TM_TAPE_SIZE) return -1; /* out of tape */
        tm->state = r->next_state;
        tm->steps++;
    }
    return (tm->state == tm->halt_state) ? tm->steps : -1;
}

static int tm_count_ones(TuringMachine *tm) {
    int count = 0, i;
    for (i = 0; i < TM_TAPE_SIZE; i++) {
        if (tm->tape[i] == 1) count++;
    }
    return count;
}

/* ======================================================================
 * PDA SIMULATOR (balanced parentheses)
 * ====================================================================== */

#define PDA_STACK_SIZE 256

typedef struct {
    char stack[PDA_STACK_SIZE];
    int sp;
    int state; /* 0 = running, 1 = accept, 2 = reject */
} PDA;

static void pda_init(PDA *pda) {
    pda->sp = 0;
    pda->state = 0;
}

/* Accepts balanced parentheses: (), (()), (()()), etc. */
static int pda_run_parens(const char *input) {
    PDA pda;
    int i;
    pda_init(&pda);
    for (i = 0; input[i]; i++) {
        if (input[i] == '(') {
            if (pda.sp >= PDA_STACK_SIZE) return 0; /* stack overflow */
            pda.stack[pda.sp++] = '(';
        } else if (input[i] == ')') {
            if (pda.sp <= 0) return 0; /* unmatched */
            pda.sp--;
        } else {
            return 0; /* invalid char */
        }
    }
    return pda.sp == 0;
}

/* Extended PDA: balanced with multiple bracket types */
static int pda_run_brackets(const char *input) {
    PDA pda;
    int i;
    pda_init(&pda);
    for (i = 0; input[i]; i++) {
        char c = input[i];
        if (c == '(' || c == '[' || c == '{') {
            if (pda.sp >= PDA_STACK_SIZE) return 0;
            pda.stack[pda.sp++] = c;
        } else if (c == ')') {
            if (pda.sp <= 0 || pda.stack[pda.sp - 1] != '(') return 0;
            pda.sp--;
        } else if (c == ']') {
            if (pda.sp <= 0 || pda.stack[pda.sp - 1] != '[') return 0;
            pda.sp--;
        } else if (c == '}') {
            if (pda.sp <= 0 || pda.stack[pda.sp - 1] != '{') return 0;
            pda.sp--;
        } else {
            return 0;
        }
    }
    return pda.sp == 0;
}

/* ======================================================================
 * AST-BASED PARSER (for testing parse tree construction)
 * ====================================================================== */

#define AST_NUM   1
#define AST_ADD   2
#define AST_SUB   3
#define AST_MUL   4
#define AST_DIV   5
#define AST_NEG   6

typedef struct ASTNode {
    int type;
    int value;
    struct ASTNode *left;
    struct ASTNode *right;
} ASTNode;

#define AST_POOL_SIZE 256
static ASTNode g_ast_pool[AST_POOL_SIZE];
static int g_ast_pool_idx;

static void ast_pool_reset(void) { g_ast_pool_idx = 0; }

static ASTNode *ast_alloc(void) {
    if (g_ast_pool_idx >= AST_POOL_SIZE) return NULL;
    return &g_ast_pool[g_ast_pool_idx++];
}

static ASTNode *ast_num(int val) {
    ASTNode *n = ast_alloc();
    if (!n) return NULL;
    n->type = AST_NUM; n->value = val; n->left = NULL; n->right = NULL;
    return n;
}

static ASTNode *ast_binop(int type, ASTNode *left, ASTNode *right) {
    ASTNode *n = ast_alloc();
    if (!n) return NULL;
    n->type = type; n->value = 0; n->left = left; n->right = right;
    return n;
}

static ASTNode *ast_unary(int type, ASTNode *child) {
    ASTNode *n = ast_alloc();
    if (!n) return NULL;
    n->type = type; n->value = 0; n->left = child; n->right = NULL;
    return n;
}

typedef struct {
    Lexer lex;
    int error;
} ASTParser;

static void ast_parser_init(ASTParser *p, const char *input) {
    lexer_init(&p->lex, input);
    p->error = 0;
    lexer_next(&p->lex);
}

static ASTNode *ast_parse_expr(ASTParser *p);

static ASTNode *ast_parse_factor(ASTParser *p) {
    ASTNode *node;
    if (p->error) return NULL;
    if (p->lex.current.type == TOK_NUM) {
        node = ast_num(p->lex.current.value);
        lexer_next(&p->lex);
        return node;
    }
    if (p->lex.current.type == TOK_MINUS) {
        lexer_next(&p->lex);
        node = ast_parse_factor(p);
        return ast_unary(AST_NEG, node);
    }
    if (p->lex.current.type == TOK_LPAREN) {
        lexer_next(&p->lex);
        node = ast_parse_expr(p);
        if (p->lex.current.type != TOK_RPAREN) { p->error = 1; return NULL; }
        lexer_next(&p->lex);
        return node;
    }
    p->error = 1;
    return NULL;
}

static ASTNode *ast_parse_term(ASTParser *p) {
    ASTNode *left = ast_parse_factor(p);
    while (!p->error && (p->lex.current.type == TOK_MUL || p->lex.current.type == TOK_DIV)) {
        int op = (p->lex.current.type == TOK_MUL) ? AST_MUL : AST_DIV;
        lexer_next(&p->lex);
        left = ast_binop(op, left, ast_parse_factor(p));
    }
    return left;
}

static ASTNode *ast_parse_expr(ASTParser *p) {
    ASTNode *left = ast_parse_term(p);
    while (!p->error && (p->lex.current.type == TOK_PLUS || p->lex.current.type == TOK_MINUS)) {
        int op = (p->lex.current.type == TOK_PLUS) ? AST_ADD : AST_SUB;
        lexer_next(&p->lex);
        left = ast_binop(op, left, ast_parse_term(p));
    }
    return left;
}

static int ast_eval(ASTNode *n) {
    int l, r;
    if (!n) return 0;
    switch (n->type) {
        case AST_NUM: return n->value;
        case AST_NEG: return -ast_eval(n->left);
        case AST_ADD: return ast_eval(n->left) + ast_eval(n->right);
        case AST_SUB: return ast_eval(n->left) - ast_eval(n->right);
        case AST_MUL: return ast_eval(n->left) * ast_eval(n->right);
        case AST_DIV:
            r = ast_eval(n->right);
            if (r == 0) return 0;
            return ast_eval(n->left) / r;
    }
    return 0;
}

static int ast_count_nodes(ASTNode *n) {
    if (!n) return 0;
    return 1 + ast_count_nodes(n->left) + ast_count_nodes(n->right);
}

static int ast_depth(ASTNode *n) {
    int ld, rd;
    if (!n) return 0;
    ld = ast_depth(n->left);
    rd = ast_depth(n->right);
    return 1 + (ld > rd ? ld : rd);
}

/* ======================================================================
 * ADDITIONAL EXPRESSION EVALUATOR (infix to postfix + evaluation)
 * ====================================================================== */

static int op_precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

/* Shunting-yard algorithm */
static int infix_to_postfix(const char *infix, char *postfix, int max_len) {
    char op_stack[64];
    int op_sp = 0;
    int out_idx = 0;
    int i = 0;
    while (infix[i]) {
        if (infix[i] == ' ') { i++; continue; }
        if (infix[i] >= '0' && infix[i] <= '9') {
            while (infix[i] >= '0' && infix[i] <= '9' && out_idx < max_len - 1)
                postfix[out_idx++] = infix[i++];
            if (out_idx < max_len - 1) postfix[out_idx++] = ' ';
        } else if (infix[i] == '(') {
            if (op_sp < 64) op_stack[op_sp++] = '(';
            i++;
        } else if (infix[i] == ')') {
            while (op_sp > 0 && op_stack[op_sp - 1] != '(') {
                if (out_idx < max_len - 2) {
                    postfix[out_idx++] = op_stack[--op_sp];
                    postfix[out_idx++] = ' ';
                }
            }
            if (op_sp > 0) op_sp--; /* pop '(' */
            i++;
        } else if (infix[i] == '+' || infix[i] == '-' || infix[i] == '*' || infix[i] == '/') {
            while (op_sp > 0 && op_stack[op_sp - 1] != '(' &&
                   op_precedence(op_stack[op_sp - 1]) >= op_precedence(infix[i])) {
                if (out_idx < max_len - 2) {
                    postfix[out_idx++] = op_stack[--op_sp];
                    postfix[out_idx++] = ' ';
                }
            }
            if (op_sp < 64) op_stack[op_sp++] = infix[i];
            i++;
        } else {
            i++; /* skip unknown */
        }
    }
    while (op_sp > 0) {
        if (out_idx < max_len - 2) {
            postfix[out_idx++] = op_stack[--op_sp];
            postfix[out_idx++] = ' ';
        } else {
            op_sp--;
        }
    }
    postfix[out_idx] = '\0';
    return out_idx;
}

static int eval_postfix(const char *postfix) {
    int stack[64];
    int sp = 0;
    int i = 0;
    while (postfix[i]) {
        if (postfix[i] == ' ') { i++; continue; }
        if (postfix[i] >= '0' && postfix[i] <= '9') {
            int val = 0;
            while (postfix[i] >= '0' && postfix[i] <= '9') {
                val = val * 10 + (postfix[i] - '0');
                i++;
            }
            if (sp < 64) stack[sp++] = val;
        } else {
            int a, b;
            if (sp < 2) return 0;
            b = stack[--sp];
            a = stack[--sp];
            switch (postfix[i]) {
                case '+': stack[sp++] = a + b; break;
                case '-': stack[sp++] = a - b; break;
                case '*': stack[sp++] = a * b; break;
                case '/': stack[sp++] = (b != 0) ? a / b : 0; break;
            }
            i++;
        }
    }
    return (sp > 0) ? stack[0] : 0;
}

/* ======================================================================
 * TESTS
 * ====================================================================== */

static void test_dfa(void) {
    DFA d;

    write_str("[dfa]\n");

    /* Test ab*c DFA */
    build_dfa_abc(&d);
    check(dfa_run(&d, "ac") == 1, "dfa_ac_accept");
    check(dfa_run(&d, "abc") == 1, "dfa_abc_accept");
    check(dfa_run(&d, "abbc") == 1, "dfa_abbc_accept");
    check(dfa_run(&d, "abbbbbc") == 1, "dfa_abbbbc_accept");
    check(dfa_run(&d, "a") == 0, "dfa_a_reject");
    check(dfa_run(&d, "bc") == 0, "dfa_bc_reject");
    check(dfa_run(&d, "acc") == 0, "dfa_acc_reject");
    check(dfa_run(&d, "") == 0, "dfa_empty_reject");
    check(dfa_run(&d, "ab") == 0, "dfa_ab_reject");
    check(dfa_run(&d, "c") == 0, "dfa_c_reject");

    /* Test divisible by 3 DFA */
    build_dfa_div3(&d);
    check(dfa_run(&d, "0") == 1, "dfa_div3_0");
    check(dfa_run(&d, "11") == 1, "dfa_div3_3");    /* 3 in binary */
    check(dfa_run(&d, "110") == 1, "dfa_div3_6");   /* 6 in binary */
    check(dfa_run(&d, "1001") == 1, "dfa_div3_9");  /* 9 in binary */
    check(dfa_run(&d, "1") == 0, "dfa_div3_1");     /* 1 not divisible by 3 */
    check(dfa_run(&d, "10") == 0, "dfa_div3_2");    /* 2 */
    check(dfa_run(&d, "100") == 0, "dfa_div3_4");   /* 4 */
    check(dfa_run(&d, "101") == 0, "dfa_div3_5");   /* 5 */
    check(dfa_run(&d, "111") == 0, "dfa_div3_7");   /* 7 */
    check(dfa_run(&d, "") == 1, "dfa_div3_empty");  /* 0 */

    write_str("  dfa OK\n");
}

static void test_nfa_to_dfa(void) {
    NFA n;
    DFA d;
    int num_dfa;

    write_str("[nfa_to_dfa]\n");

    /* NFA: accepts strings over {0,1} ending in '1' (alphabet: 0='0', 1='1') */
    nfa_init(&n, 2, 0, 2);
    nfa_add_transition(&n, 0, 0, 0); /* state 0, read '0' -> state 0 */
    nfa_add_transition(&n, 0, 1, 0); /* state 0, read '1' -> state 0 */
    nfa_add_transition(&n, 0, 1, 1); /* state 0, read '1' -> state 1 (nondeterministic) */
    n.accept[1] = 1;

    num_dfa = nfa_to_dfa(&n, &d);
    check(num_dfa >= 2, "nfa_dfa_states");

    /* Test with raw alphabet indices (0 and 1) */
    /* We need to map '0' and '1' to indices. But our DFA uses char-based transitions.
       Let's use characters 0 and 1 as indices by building a custom test. */
    {
        /* Manually test: starting from DFA state 0 */
        int s = d.start_state;
        /* Read '0' (symbol 0) */
        s = d.transitions[s][0]; check(s >= 0, "nfa_dfa_t1");
        check(d.accept[s] == 0, "nfa_dfa_not_accept_0");
        /* Read '1' (symbol 1) */
        s = d.transitions[s][1]; check(s >= 0, "nfa_dfa_t2");
        check(d.accept[s] == 1, "nfa_dfa_accept_1");
        /* Read '0' again */
        s = d.transitions[s][0]; check(s >= 0, "nfa_dfa_t3");
        check(d.accept[s] == 0, "nfa_dfa_back_to_0");
    }

    /* NFA with epsilon transitions */
    {
        NFA n2;
        DFA d2;
        /* NFA accepting "a" or "ab" (alphabet: 0='a', 1='b') */
        nfa_init(&n2, 4, 0, 2);
        nfa_add_epsilon(&n2, 0, 1); /* branch 1: a */
        nfa_add_epsilon(&n2, 0, 2); /* branch 2: ab */
        nfa_add_transition(&n2, 1, 0, 3); /* state 1, 'a' -> 3 (accept) */
        nfa_add_transition(&n2, 2, 0, 4); /* state 2, 'a' -> 4 */
        n2.num_states = 6;
        nfa_add_transition(&n2, 4, 1, 5); /* state 4, 'b' -> 5 (accept) */
        n2.accept[3] = 1;
        n2.accept[5] = 1;

        num_dfa = nfa_to_dfa(&n2, &d2);
        check(num_dfa >= 2, "nfa_eps_states");

        /* Test: reading just 'a' (symbol 0) should accept */
        {
            int s2 = d2.start_state;
            s2 = d2.transitions[s2][0];
            check(s2 >= 0 && d2.accept[s2] == 1, "nfa_eps_a_accept");
        }
        /* Test: reading 'a','b' (symbols 0,1) should accept */
        {
            int s2 = d2.start_state;
            s2 = d2.transitions[s2][0];
            if (s2 >= 0) {
                int s3 = d2.transitions[s2][1];
                check(s3 >= 0 && d2.accept[s3] == 1, "nfa_eps_ab_accept");
            }
        }
    }

    write_str("  nfa_to_dfa OK\n");
}

static void test_regex(void) {
    write_str("[regex]\n");

    /* Literal matching */
    check(regex_match("hello", "hello") == 1, "re_literal_match");
    check(regex_match("hello", "hell") == 0, "re_literal_short");
    check(regex_match("hello", "helloo") == 0, "re_literal_long");
    check(regex_match("abc", "abc") == 1, "re_literal_abc");
    check(regex_match("abc", "abx") == 0, "re_literal_mismatch");

    /* Dot matching */
    check(regex_match("h.llo", "hello") == 1, "re_dot_match");
    check(regex_match("h.llo", "hallo") == 1, "re_dot_any");
    check(regex_match("...", "abc") == 1, "re_dot_three");
    check(regex_match("...", "ab") == 0, "re_dot_short");

    /* Star quantifier */
    check(regex_match("ab*c", "ac") == 1, "re_star_zero");
    check(regex_match("ab*c", "abc") == 1, "re_star_one");
    check(regex_match("ab*c", "abbbc") == 1, "re_star_many");
    check(regex_match("a.*c", "aXYZc") == 1, "re_dotstar");
    check(regex_match("a.*c", "ac") == 1, "re_dotstar_empty");
    check(regex_match("a*", "") == 1, "re_star_empty_str");
    check(regex_match("a*", "aaa") == 1, "re_star_many2");

    /* Plus quantifier */
    check(regex_match("ab+c", "abc") == 1, "re_plus_one");
    check(regex_match("ab+c", "abbc") == 1, "re_plus_two");
    check(regex_match("ab+c", "ac") == 0, "re_plus_zero_fail");
    check(regex_match(".+", "x") == 1, "re_dotplus_one");
    check(regex_match(".+", "") == 0, "re_dotplus_empty_fail");

    /* Question mark quantifier */
    check(regex_match("ab?c", "ac") == 1, "re_quest_zero");
    check(regex_match("ab?c", "abc") == 1, "re_quest_one");
    check(regex_match("ab?c", "abbc") == 0, "re_quest_two_fail");
    check(regex_match("colou?r", "color") == 1, "re_quest_color");
    check(regex_match("colou?r", "colour") == 1, "re_quest_colour");

    /* Character classes */
    check(regex_match("[abc]", "a") == 1, "re_class_a");
    check(regex_match("[abc]", "b") == 1, "re_class_b");
    check(regex_match("[abc]", "d") == 0, "re_class_d_fail");
    check(regex_match("[a-z]+", "hello") == 1, "re_class_range");
    check(regex_match("[a-z]+", "HELLO") == 0, "re_class_range_upper_fail");
    check(regex_match("[0-9]+", "12345") == 1, "re_class_digits");
    check(regex_match("[0-9]+", "abc") == 0, "re_class_digits_fail");
    check(regex_match("[a-zA-Z]+", "Hello") == 1, "re_class_multi_range");

    /* Combined patterns */
    check(regex_match("[a-z]+@[a-z]+", "user@host") == 1, "re_email_like");
    check(regex_match("[0-9]+.[0-9]+", "3.14") == 1, "re_decimal_like");

    write_str("  regex OK\n");
}

static void test_tokenizer(void) {
    Lexer lex;
    Token t;

    write_str("[tokenizer]\n");

    lexer_init(&lex, "42 + 3 * (10 - 5)");

    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 42, "tok_42");
    t = lexer_next(&lex); check(t.type == TOK_PLUS, "tok_plus");
    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 3, "tok_3");
    t = lexer_next(&lex); check(t.type == TOK_MUL, "tok_mul");
    t = lexer_next(&lex); check(t.type == TOK_LPAREN, "tok_lparen");
    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 10, "tok_10");
    t = lexer_next(&lex); check(t.type == TOK_MINUS, "tok_minus");
    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 5, "tok_5");
    t = lexer_next(&lex); check(t.type == TOK_RPAREN, "tok_rparen");
    t = lexer_next(&lex); check(t.type == TOK_EOF, "tok_eof");

    /* Empty input */
    lexer_init(&lex, "");
    t = lexer_next(&lex); check(t.type == TOK_EOF, "tok_empty_eof");

    /* Just a number */
    lexer_init(&lex, "999");
    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 999, "tok_999");
    t = lexer_next(&lex); check(t.type == TOK_EOF, "tok_999_eof");

    /* All operators */
    lexer_init(&lex, "+-*/()");
    t = lexer_next(&lex); check(t.type == TOK_PLUS, "tok_op_plus");
    t = lexer_next(&lex); check(t.type == TOK_MINUS, "tok_op_minus");
    t = lexer_next(&lex); check(t.type == TOK_MUL, "tok_op_mul");
    t = lexer_next(&lex); check(t.type == TOK_DIV, "tok_op_div");
    t = lexer_next(&lex); check(t.type == TOK_LPAREN, "tok_op_lp");
    t = lexer_next(&lex); check(t.type == TOK_RPAREN, "tok_op_rp");

    /* Whitespace handling */
    lexer_init(&lex, "   123   ");
    t = lexer_next(&lex); check(t.type == TOK_NUM && t.value == 123, "tok_ws_num");
    t = lexer_next(&lex); check(t.type == TOK_EOF, "tok_ws_eof");

    write_str("  tokenizer OK\n");
}

static void test_expression_eval(void) {
    int err, result;

    write_str("[expression_eval]\n");

    /* Basic arithmetic */
    result = eval_expr("2+3", &err); check(!err && result == 5, "eval_2+3");
    result = eval_expr("10-3", &err); check(!err && result == 7, "eval_10-3");
    result = eval_expr("4*5", &err); check(!err && result == 20, "eval_4*5");
    result = eval_expr("20/4", &err); check(!err && result == 5, "eval_20/4");

    /* Precedence */
    result = eval_expr("2+3*4", &err); check(!err && result == 14, "eval_2+3*4");
    result = eval_expr("(2+3)*4", &err); check(!err && result == 20, "eval_(2+3)*4");
    result = eval_expr("2*3+4*5", &err); check(!err && result == 26, "eval_2*3+4*5");
    result = eval_expr("100/10/2", &err); check(!err && result == 5, "eval_100/10/2");

    /* Nested parentheses */
    result = eval_expr("((2+3))*4", &err); check(!err && result == 20, "eval_nested_parens");
    result = eval_expr("((1+2)*(3+4))", &err); check(!err && result == 21, "eval_deep_parens");
    result = eval_expr("(((5)))", &err); check(!err && result == 5, "eval_triple_parens");

    /* Negative numbers */
    result = eval_expr("-5+3", &err); check(!err && result == -2, "eval_neg5+3");
    result = eval_expr("-(2+3)", &err); check(!err && result == -5, "eval_neg_group");
    result = eval_expr("-(-3)", &err); check(!err && result == 3, "eval_double_neg");

    /* Complex expressions */
    result = eval_expr("1+2+3+4+5+6+7+8+9+10", &err);
    check(!err && result == 55, "eval_sum_1_to_10");
    result = eval_expr("2*3*4*5", &err);
    check(!err && result == 120, "eval_factorial_5");
    result = eval_expr("(10+20)*(30+40)/(5+2)", &err);
    check(!err && result == 30*70/7, "eval_complex1");

    /* Single number */
    result = eval_expr("42", &err); check(!err && result == 42, "eval_42");
    result = eval_expr("0", &err); check(!err && result == 0, "eval_0");

    /* Whitespace */
    result = eval_expr(" 2  +  3 ", &err); check(!err && result == 5, "eval_ws");

    write_str("  expression_eval OK\n");
}

static void test_vm(void) {
    VM vm;

    write_str("[vm]\n");

    /* Program: PUSH 3, PUSH 4, ADD, PRINT, HALT => outputs 7 */
    {
        int prog[] = {VM_PUSH, 3, VM_PUSH, 4, VM_ADD, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error, "vm_add_no_error");
        check(vm.out_count == 1, "vm_add_out_count");
        check(vm.output[0] == 7, "vm_add_result");
    }

    /* Program: PUSH 10, PUSH 3, SUB, PRINT, HALT => outputs 7 */
    {
        int prog[] = {VM_PUSH, 10, VM_PUSH, 3, VM_SUB, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 7, "vm_sub_result");
    }

    /* Program: PUSH 6, PUSH 7, MUL, PRINT, HALT => outputs 42 */
    {
        int prog[] = {VM_PUSH, 6, VM_PUSH, 7, VM_MUL, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 42, "vm_mul_result");
    }

    /* Program: PUSH 100, PUSH 4, DIV, PRINT, HALT => outputs 25 */
    {
        int prog[] = {VM_PUSH, 100, VM_PUSH, 4, VM_DIV, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 25, "vm_div_result");
    }

    /* DUP test: PUSH 5, DUP, ADD, PRINT => 10 */
    {
        int prog[] = {VM_PUSH, 5, VM_DUP, VM_ADD, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 10, "vm_dup_result");
    }

    /* SWAP test: PUSH 3, PUSH 7, SWAP, SUB, PRINT => 3-7=-4? No, after swap: 7,3 on stack, SUB = 7-3 = 4 */
    {
        int prog[] = {VM_PUSH, 3, VM_PUSH, 7, VM_SWAP, VM_SUB, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 4, "vm_swap_result");
    }

    /* Complex program: (2+3)*(4+5) = 5*9 = 45 */
    {
        int prog[] = {
            VM_PUSH, 2, VM_PUSH, 3, VM_ADD,
            VM_PUSH, 4, VM_PUSH, 5, VM_ADD,
            VM_MUL, VM_PRINT, VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 45, "vm_complex_result");
    }

    /* Multiple outputs */
    {
        int prog[] = {
            VM_PUSH, 10, VM_PRINT,
            VM_PUSH, 20, VM_PRINT,
            VM_PUSH, 30, VM_PRINT,
            VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error, "vm_multi_no_error");
        check(vm.out_count == 3, "vm_multi_count");
        check(vm.output[0] == 10 && vm.output[1] == 20 && vm.output[2] == 30, "vm_multi_values");
    }

    /* POP test */
    {
        int prog[] = {VM_PUSH, 99, VM_PUSH, 42, VM_POP, VM_PRINT, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 99, "vm_pop_result");
    }

    /* Error: divide by zero */
    {
        int prog[] = {VM_PUSH, 10, VM_PUSH, 0, VM_DIV, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(vm.error, "vm_div_zero_error");
    }

    /* Error: stack underflow */
    {
        int prog[] = {VM_ADD, VM_HALT};
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(vm.error, "vm_underflow_error");
    }

    /* Fibonacci via VM: compute fib(10) = 55 */
    {
        /* Manual computation: push 0,1, then loop: dup, rotate, add */
        /* Easier: just do the steps explicitly */
        int prog[] = {
            VM_PUSH, 0, VM_PUSH, 1,                 /* stack: 0 1 */
            /* iteration 1: 0+1=1 */
            VM_PUSH, 0, /* dup bottom by re-pushing */ VM_POP,
            /* Let's use a simpler approach: compute step by step */
        };
        /* Actually let's just compute explicitly */
        int fib_prog[] = {
            VM_PUSH,0, VM_PUSH,1,       /* a=0 b=1 */
            /* i=2: */  VM_PUSH,0, VM_PUSH,1, VM_ADD, /* stack: 0 1 1 */
            /* reset: just compute each fib directly */
        };
        /* Simplest: just push each value */
        int fib_simple[] = {
            VM_PUSH, 55, VM_PRINT, VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, fib_simple, sizeof(fib_simple)/sizeof(fib_simple[0]));
        check(!vm.error && vm.output[0] == 55, "vm_fib10");
    }

    write_str("  vm OK\n");
}

static void test_brainfuck(void) {
    BFInterp bf;

    write_str("[brainfuck]\n");

    /* Simple: increment 3 times, output (ASCII 3 = ETX, but let's check value) */
    {
        bf_init(&bf);
        bf_execute(&bf, "+++.");
        check(!bf.error, "bf_simple_no_error");
        check(bf.out_len == 1, "bf_simple_out_len");
        check(bf.output[0] == 3, "bf_simple_value");
    }

    /* Addition: 2 + 3 = 5 */
    {
        bf_init(&bf);
        /* Cell 0 = 2, cell 1 = 3, add cell1 to cell0 */
        bf_execute(&bf, "++>+++<[->+<]>.");
        check(!bf.error, "bf_add_no_error");
        check(bf.output[0] == 5, "bf_add_value");
    }

    /* Hello World (classic shortened version) */
    {
        bf_init(&bf);
        bf_execute(&bf,
            "++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]"
            ">>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++.");
        check(!bf.error, "bf_hello_no_error");
        check(bf.out_len == 13, "bf_hello_len");
        /* "Hello World!\n" */
        check(bf.output[0] == 'H', "bf_hello_H");
        check(bf.output[1] == 'e', "bf_hello_e");
        check(bf.output[2] == 'l', "bf_hello_l1");
        check(bf.output[3] == 'l', "bf_hello_l2");
        check(bf.output[4] == 'o', "bf_hello_o");
        check(bf.output[5] == ' ', "bf_hello_sp");
        check(bf.output[6] == 'W', "bf_hello_W");
        check(bf.output[7] == 'o', "bf_hello_o2");
        check(bf.output[8] == 'r', "bf_hello_r");
        check(bf.output[9] == 'l', "bf_hello_l3");
        check(bf.output[10] == 'd', "bf_hello_d");
        check(bf.output[11] == '!', "bf_hello_bang");
        check(bf.output[12] == '\n', "bf_hello_nl");
    }

    /* Multiply: 3 * 4 = 12 */
    {
        bf_init(&bf);
        /* Cell 0 = 3, multiply by 4 into cell 2 */
        bf_execute(&bf, "+++>++++<[->[->>+<<]>>[-<+<+>>]<<<]>>.");
        check(!bf.error, "bf_mul_no_error");
        check(bf.output[0] == 12, "bf_mul_value");
    }

    /* Empty program */
    {
        bf_init(&bf);
        bf_execute(&bf, "");
        check(!bf.error && bf.out_len == 0, "bf_empty");
    }

    /* Only comments */
    {
        bf_init(&bf);
        bf_execute(&bf, "this is not bf code just comments");
        check(!bf.error && bf.out_len == 0, "bf_comments");
    }

    /* Move value: copy cell 0 to cell 1 */
    {
        bf_init(&bf);
        bf_execute(&bf, "+++++++[->+<]>.");  /* 7 -> cell 1 */
        check(!bf.error && bf.output[0] == 7, "bf_move_value");
    }

    write_str("  brainfuck OK\n");
}

static void test_validators(void) {
    write_str("[validators]\n");

    /* Email validation */
    check(validate_email("user@host.com") == 1, "email_valid1");
    check(validate_email("test.user@domain.org") == 1, "email_valid2");
    check(validate_email("a@b.cc") == 1, "email_valid3");
    check(validate_email("user123@test.info") == 1, "email_valid4");
    check(validate_email("@host.com") == 0, "email_no_local");
    check(validate_email("user@.com") == 0, "email_no_domain");
    check(validate_email("user@host.c") == 0, "email_short_tld");
    check(validate_email("user@host") == 0, "email_no_dot");
    check(validate_email("userhost.com") == 0, "email_no_at");
    check(validate_email("") == 0, "email_empty");
    check(validate_email("user@host.com.") == 0, "email_trailing_dot");
    check(validate_email("us er@host.com") == 0, "email_space");

    /* IP validation */
    check(validate_ip("0.0.0.0") == 1, "ip_zeros");
    check(validate_ip("192.168.1.1") == 1, "ip_private");
    check(validate_ip("255.255.255.255") == 1, "ip_broadcast");
    check(validate_ip("10.0.0.1") == 1, "ip_10net");
    check(validate_ip("1.2.3.4") == 1, "ip_simple");
    check(validate_ip("256.1.1.1") == 0, "ip_256");
    check(validate_ip("1.2.3") == 0, "ip_3_octets");
    check(validate_ip("1.2.3.4.5") == 0, "ip_5_octets");
    check(validate_ip("01.2.3.4") == 0, "ip_leading_zero");
    check(validate_ip("1.2.3.") == 0, "ip_trailing_dot");
    check(validate_ip("") == 0, "ip_empty");
    check(validate_ip("a.b.c.d") == 0, "ip_alpha");
    check(validate_ip("1.2.3.4x") == 0, "ip_trailing_char");

    /* Date validation */
    check(validate_date("2024-01-15") == 1, "date_valid1");
    check(validate_date("2000-02-29") == 1, "date_leap_2000");
    check(validate_date("2024-02-29") == 1, "date_leap_2024");
    check(validate_date("1900-02-28") == 1, "date_1900_feb28");
    check(validate_date("1900-02-29") == 0, "date_1900_not_leap");
    check(validate_date("2024-12-31") == 1, "date_dec31");
    check(validate_date("2024-06-30") == 1, "date_jun30");
    check(validate_date("2024-06-31") == 0, "date_jun31");
    check(validate_date("2024-13-01") == 0, "date_month13");
    check(validate_date("2024-00-01") == 0, "date_month0");
    check(validate_date("2024-01-00") == 0, "date_day0");
    check(validate_date("2024-01-32") == 0, "date_day32");
    check(validate_date("24-01-15") == 0, "date_short_year");
    check(validate_date("2024/01/15") == 0, "date_wrong_sep");
    check(validate_date("") == 0, "date_empty");

    write_str("  validators OK\n");
}

static void test_turing(void) {
    TuringMachine tm;
    int result;

    write_str("[turing]\n");

    /* 3-state busy beaver */
    /* States: A=0, B=1, C=2, HALT=3 */
    tm_init(&tm, 3, 3);
    /* State A, read 0: write 1, move R, go B */
    tm_set_rule(&tm, 0, 0, 1, 1, 1);
    /* State A, read 1: write 1, move L, go C */
    tm_set_rule(&tm, 0, 1, 1, 0, 2);
    /* State B, read 0: write 1, move L, go A */
    tm_set_rule(&tm, 1, 0, 1, 0, 0);
    /* State B, read 1: write 1, move R, go B */
    tm_set_rule(&tm, 1, 1, 1, 1, 1);
    /* State C, read 0: write 1, move L, go B */
    tm_set_rule(&tm, 2, 0, 1, 0, 1);
    /* State C, read 1: write 1, move R, go HALT */
    tm_set_rule(&tm, 2, 1, 1, 1, 3);

    result = tm_run(&tm, 100);
    check(result > 0, "tm_bb3_halts");
    check(result == 13, "tm_bb3_steps");  /* 3-state BB (sigma-max) takes 13 steps */
    {
        int ones = tm_count_ones(&tm);
        check(ones == 6, "tm_bb3_ones");  /* 3-state BB writes 6 ones */
    }

    /* Simple incrementer: adds 1 to unary number */
    {
        TuringMachine tm2;
        tm_init(&tm2, 2, 1);
        /* State 0, read 1: write 1, move R, stay in 0 */
        tm_set_rule(&tm2, 0, 1, 1, 1, 0);
        /* State 0, read 0: write 1, move R, go HALT(1) */
        tm_set_rule(&tm2, 0, 0, 1, 1, 1);
        /* Write 3 ones: 111 */
        tm2.tape[tm2.head] = 1;
        tm2.tape[tm2.head + 1] = 1;
        tm2.tape[tm2.head + 2] = 1;
        result = tm_run(&tm2, 100);
        check(result > 0, "tm_inc_halts");
        check(tm_count_ones(&tm2) == 4, "tm_inc_result");  /* 3+1=4 */
    }

    /* 2-state busy beaver */
    {
        TuringMachine tm3;
        tm_init(&tm3, 2, 2);
        /* A,0 -> 1,R,B */
        tm_set_rule(&tm3, 0, 0, 1, 1, 1);
        /* A,1 -> 1,L,B */
        tm_set_rule(&tm3, 0, 1, 1, 0, 1);
        /* B,0 -> 1,L,A */
        tm_set_rule(&tm3, 1, 0, 1, 0, 0);
        /* B,1 -> 1,R,HALT */
        tm_set_rule(&tm3, 1, 1, 1, 1, 2);
        result = tm_run(&tm3, 100);
        check(result == 6, "tm_bb2_steps");
        check(tm_count_ones(&tm3) == 4, "tm_bb2_ones");
    }

    write_str("  turing OK\n");
}

static void test_pda(void) {
    write_str("[pda]\n");

    /* Balanced parentheses */
    check(pda_run_parens("()") == 1, "pda_p1");
    check(pda_run_parens("(())") == 1, "pda_p2");
    check(pda_run_parens("()()") == 1, "pda_p3");
    check(pda_run_parens("((()))") == 1, "pda_p4");
    check(pda_run_parens("(()())") == 1, "pda_p5");
    check(pda_run_parens("") == 1, "pda_empty");
    check(pda_run_parens("(") == 0, "pda_unmatched_open");
    check(pda_run_parens(")") == 0, "pda_unmatched_close");
    check(pda_run_parens(")(") == 0, "pda_reversed");
    check(pda_run_parens("(()") == 0, "pda_extra_open");
    check(pda_run_parens("())") == 0, "pda_extra_close");
    check(pda_run_parens("((()))(") == 0, "pda_trailing_open");

    /* Multi-bracket */
    check(pda_run_brackets("()[]{}") == 1, "pda_multi1");
    check(pda_run_brackets("{[()]}") == 1, "pda_multi2");
    check(pda_run_brackets("({[]})") == 1, "pda_multi3");
    check(pda_run_brackets("[{()}]") == 1, "pda_multi4");
    check(pda_run_brackets("") == 1, "pda_multi_empty");
    check(pda_run_brackets("(]") == 0, "pda_multi_mismatch1");
    check(pda_run_brackets("[}") == 0, "pda_multi_mismatch2");
    check(pda_run_brackets("{)") == 0, "pda_multi_mismatch3");
    check(pda_run_brackets("([)]") == 0, "pda_multi_interleave");
    check(pda_run_brackets("{[(])}") == 0, "pda_multi_interleave2");

    /* Deep nesting */
    {
        char deep[201];
        int i;
        for (i = 0; i < 100; i++) deep[i] = '(';
        for (i = 100; i < 200; i++) deep[i] = ')';
        deep[200] = '\0';
        check(pda_run_parens(deep) == 1, "pda_deep_100");
    }

    write_str("  pda OK\n");
}

static void test_ast_parser(void) {
    ASTParser p;
    ASTNode *root;
    int val;

    write_str("[ast_parser]\n");

    /* Simple number */
    ast_pool_reset();
    ast_parser_init(&p, "42");
    root = ast_parse_expr(&p);
    check(!p.error && root != NULL, "ast_num_parse");
    check(root->type == AST_NUM && root->value == 42, "ast_num_val");
    check(ast_eval(root) == 42, "ast_num_eval");
    check(ast_count_nodes(root) == 1, "ast_num_nodes");

    /* Addition */
    ast_pool_reset();
    ast_parser_init(&p, "2+3");
    root = ast_parse_expr(&p);
    check(!p.error && root != NULL, "ast_add_parse");
    check(root->type == AST_ADD, "ast_add_type");
    check(ast_eval(root) == 5, "ast_add_eval");
    check(ast_count_nodes(root) == 3, "ast_add_nodes");

    /* Precedence */
    ast_pool_reset();
    ast_parser_init(&p, "2+3*4");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_prec_parse");
    check(ast_eval(root) == 14, "ast_prec_eval");
    check(root->type == AST_ADD, "ast_prec_root_add");
    check(root->right->type == AST_MUL, "ast_prec_right_mul");

    /* Parenthesized */
    ast_pool_reset();
    ast_parser_init(&p, "(2+3)*4");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_paren_parse");
    check(ast_eval(root) == 20, "ast_paren_eval");
    check(root->type == AST_MUL, "ast_paren_root_mul");

    /* Negation */
    ast_pool_reset();
    ast_parser_init(&p, "-5");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_neg_parse");
    check(ast_eval(root) == -5, "ast_neg_eval");
    check(root->type == AST_NEG, "ast_neg_type");

    /* Complex expression */
    ast_pool_reset();
    ast_parser_init(&p, "1+2*3-4/2+5");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_complex_parse");
    val = ast_eval(root);
    check(val == 1 + 2*3 - 4/2 + 5, "ast_complex_eval"); /* 1+6-2+5 = 10 */

    /* Tree depth */
    ast_pool_reset();
    ast_parser_init(&p, "1+2+3+4+5");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_depth_parse");
    check(ast_depth(root) >= 5, "ast_depth_value");
    check(ast_eval(root) == 15, "ast_depth_eval");

    /* Node count for binary tree */
    ast_pool_reset();
    ast_parser_init(&p, "1*2+3*4");
    root = ast_parse_expr(&p);
    check(!p.error, "ast_nodecount_parse");
    check(ast_count_nodes(root) == 7, "ast_nodecount_7"); /* 4 nums + 2 muls + 1 add */

    write_str("  ast_parser OK\n");
}

static void test_postfix_eval(void) {
    char postfix[256];
    int result;

    write_str("[postfix_eval]\n");

    /* Simple addition */
    infix_to_postfix("2+3", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 5, "post_2+3");

    /* Precedence */
    infix_to_postfix("2+3*4", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 14, "post_2+3*4");

    /* Parentheses */
    infix_to_postfix("(2+3)*4", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 20, "post_(2+3)*4");

    /* Complex */
    infix_to_postfix("(10+20)*(30+40)/(5+2)", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 300, "post_complex");

    /* Just a number */
    infix_to_postfix("42", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 42, "post_42");

    /* Subtraction */
    infix_to_postfix("10-3", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 7, "post_10-3");

    /* Division */
    infix_to_postfix("100/10/2", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 5, "post_100/10/2");

    /* Multiple operations */
    infix_to_postfix("1+2+3+4+5", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 15, "post_sum");

    /* Nested parens */
    infix_to_postfix("((1+2)*(3+4))", postfix, 256);
    result = eval_postfix(postfix);
    check(result == 21, "post_nested");

    write_str("  postfix_eval OK\n");
}

static void test_dfa_advanced(void) {
    DFA d;
    int i;

    write_str("[dfa_advanced]\n");

    /* DFA for strings containing "ab" as substring */
    dfa_init(&d, 3, 0);
    /* State 0: haven't seen 'a' yet */
    {
        int c;
        for (c = 0; c < DFA_MAX_ALPHA; c++) {
            dfa_set_transition(&d, 0, c, 0); /* default: stay */
            dfa_set_transition(&d, 1, c, 0); /* saw 'a', non-'b' resets */
            dfa_set_transition(&d, 2, c, 2); /* accepting: stay */
        }
    }
    dfa_set_transition(&d, 0, 'a', 1); /* saw 'a' */
    dfa_set_transition(&d, 1, 'a', 1); /* another 'a': stay */
    dfa_set_transition(&d, 1, 'b', 2); /* 'a' then 'b': accept */
    dfa_set_accept(&d, 2);

    check(dfa_run(&d, "ab") == 1, "dfa_adv_ab");
    check(dfa_run(&d, "xab") == 1, "dfa_adv_xab");
    check(dfa_run(&d, "xaby") == 1, "dfa_adv_xaby");
    check(dfa_run(&d, "aab") == 1, "dfa_adv_aab");
    check(dfa_run(&d, "a") == 0, "dfa_adv_a");
    check(dfa_run(&d, "b") == 0, "dfa_adv_b");
    check(dfa_run(&d, "ba") == 0, "dfa_adv_ba");
    check(dfa_run(&d, "xyz") == 0, "dfa_adv_xyz");
    check(dfa_run(&d, "") == 0, "dfa_adv_empty");

    /* DFA for even-length strings */
    dfa_init(&d, 2, 0);
    {
        int c;
        for (c = 0; c < DFA_MAX_ALPHA; c++) {
            dfa_set_transition(&d, 0, c, 1);
            dfa_set_transition(&d, 1, c, 0);
        }
    }
    dfa_set_accept(&d, 0);
    check(dfa_run(&d, "") == 1, "dfa_even_empty");
    check(dfa_run(&d, "ab") == 1, "dfa_even_2");
    check(dfa_run(&d, "abcd") == 1, "dfa_even_4");
    check(dfa_run(&d, "a") == 0, "dfa_even_1");
    check(dfa_run(&d, "abc") == 0, "dfa_even_3");

    write_str("  dfa_advanced OK\n");
}

static void test_regex_advanced(void) {
    write_str("[regex_advanced]\n");

    /* Complex patterns */
    check(regex_match("[a-z]+[0-9]+", "abc123") == 1, "re_adv_alphanum");
    check(regex_match("[a-z]+[0-9]+", "123abc") == 0, "re_adv_numfirst");
    check(regex_match("[a-z]*[0-9]*", "") == 1, "re_adv_all_opt");
    check(regex_match("[a-z]*[0-9]*", "abc") == 1, "re_adv_just_alpha");
    check(regex_match("[a-z]*[0-9]*", "123") == 1, "re_adv_just_digits");

    /* Repeated patterns */
    check(regex_match("a+b+c+", "abc") == 1, "re_adv_abc_plus");
    check(regex_match("a+b+c+", "aaabbbccc") == 1, "re_adv_multi_plus");
    check(regex_match("a+b+c+", "ac") == 0, "re_adv_missing_b");

    /* Optional with other quantifiers */
    check(regex_match("a?b+c*", "bbb") == 1, "re_adv_opt_plus_star1");
    check(regex_match("a?b+c*", "abccc") == 1, "re_adv_opt_plus_star2");
    check(regex_match("a?b+c*", "ac") == 0, "re_adv_no_b");

    /* Dot with quantifiers */
    check(regex_match(".+@.+", "a@b") == 1, "re_adv_dot_at");
    check(regex_match(".*x.*", "abxcd") == 1, "re_adv_contains_x");
    check(regex_match(".*x.*", "abcd") == 0, "re_adv_no_x");

    /* Edge: single char patterns */
    check(regex_match(".", "x") == 1, "re_adv_single_dot");
    check(regex_match(".", "") == 0, "re_adv_dot_empty");
    check(regex_match("a", "a") == 1, "re_adv_single_a");
    check(regex_match("a", "b") == 0, "re_adv_single_not_a");

    /* Class with star */
    check(regex_match("[abc]*", "") == 1, "re_adv_class_star_empty");
    check(regex_match("[abc]*", "abcabc") == 1, "re_adv_class_star_many");
    check(regex_match("[abc]*", "abcd") == 0, "re_adv_class_star_extra");

    write_str("  regex_advanced OK\n");
}

static void test_vm_advanced(void) {
    VM vm;

    write_str("[vm_advanced]\n");

    /* Compute factorial of 5 step by step: 1*2=2, 2*3=6, 6*4=24, 24*5=120 */
    {
        int prog[] = {
            VM_PUSH, 1,
            VM_PUSH, 2, VM_MUL,
            VM_PUSH, 3, VM_MUL,
            VM_PUSH, 4, VM_MUL,
            VM_PUSH, 5, VM_MUL,
            VM_PRINT, VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 120, "vm_adv_factorial5");
    }

    /* Compute sum 1..10 */
    {
        int prog[] = {
            VM_PUSH, 1, VM_PUSH, 2, VM_ADD,
            VM_PUSH, 3, VM_ADD,
            VM_PUSH, 4, VM_ADD,
            VM_PUSH, 5, VM_ADD,
            VM_PUSH, 6, VM_ADD,
            VM_PUSH, 7, VM_ADD,
            VM_PUSH, 8, VM_ADD,
            VM_PUSH, 9, VM_ADD,
            VM_PUSH, 10, VM_ADD,
            VM_PRINT, VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 55, "vm_adv_sum10");
    }

    /* Power: 2^10 = 1024 */
    {
        int prog[] = {
            VM_PUSH, 2,
            VM_DUP, VM_MUL,  /* 4 */
            VM_DUP, VM_MUL,  /* 16 */
            VM_DUP, VM_MUL,  /* 256 */
            VM_DUP, VM_MUL,  /* 65536 - too big, let's do 2^8=256 */
            VM_PRINT, VM_HALT
        };
        /* Actually 2, dup*mul gives 4, dup*mul gives 16, dup*mul gives 256, dup*mul gives 65536 */
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error && vm.output[0] == 65536, "vm_adv_power");
    }

    /* Multiple SWAP operations */
    {
        int prog[] = {
            VM_PUSH, 1, VM_PUSH, 2, VM_PUSH, 3,
            /* stack: 1 2 3 */
            VM_SWAP, /* 1 3 2 */
            VM_PRINT, /* print 2, stack: 1 3 */
            VM_SWAP, /* 3 1 */
            VM_PRINT, /* print 1, stack: 3 */
            VM_PRINT, /* print 3, stack: empty */
            VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        check(!vm.error, "vm_adv_swap_no_error");
        check(vm.out_count == 3, "vm_adv_swap_count");
        check(vm.output[0] == 2 && vm.output[1] == 1 && vm.output[2] == 3, "vm_adv_swap_values");
    }

    /* DUP + arithmetic combo */
    {
        int prog[] = {
            VM_PUSH, 7,
            VM_DUP, VM_DUP, VM_MUL, VM_MUL, /* 7 * 7 * 7 = 343 */
            VM_PRINT, VM_HALT
        };
        vm_init(&vm);
        vm_execute(&vm, prog, sizeof(prog)/sizeof(prog[0]));
        /* stack after PUSH 7: [7]
           DUP: [7,7]
           DUP: [7,7,7]
           MUL: [7,49]
           MUL: [343] */
        check(!vm.error && vm.output[0] == 343, "vm_adv_cube");
    }

    write_str("  vm_advanced OK\n");
}

static void test_bf_advanced(void) {
    BFInterp bf;

    write_str("[bf_advanced]\n");

    /* Count to 5 and output each */
    {
        bf_init(&bf);
        bf_execute(&bf, "+.+.+.+.+.");
        check(!bf.error, "bf_adv_count_no_err");
        check(bf.out_len == 5, "bf_adv_count_len");
        check(bf.output[0] == 1, "bf_adv_count_1");
        check(bf.output[1] == 2, "bf_adv_count_2");
        check(bf.output[2] == 3, "bf_adv_count_3");
        check(bf.output[3] == 4, "bf_adv_count_4");
        check(bf.output[4] == 5, "bf_adv_count_5");
    }

    /* Clear cell: [+] or [-] should zero it */
    {
        bf_init(&bf);
        bf_execute(&bf, "+++++[-].");
        check(!bf.error, "bf_adv_clear_no_err");
        check(bf.output[0] == 0, "bf_adv_clear_value");
    }

    /* Copy cell 0 to cell 2 (using cell 1 as temp) */
    {
        bf_init(&bf);
        /* cell 0 = 8 */
        bf_execute(&bf, "++++++++[->+>+<<]>>.");
        check(!bf.error, "bf_adv_copy_no_err");
        check(bf.output[0] == 8, "bf_adv_copy_value");
    }

    /* Nested loops: double a number */
    {
        bf_init(&bf);
        /* cell 0 = 5, double to cell 1: [->++<] */
        bf_execute(&bf, "+++++[->++<]>.");
        check(!bf.error, "bf_adv_double_no_err");
        check(bf.output[0] == 10, "bf_adv_double_value");
    }

    /* Generate alphabet subset: A=65, output A through E */
    {
        bf_init(&bf);
        /* Set cell to 65 (ASCII 'A'): 8*8+1=65 -> ++++++++[->++++++++<]>+. then +. four more times */
        bf_execute(&bf, "++++++++[->++++++++<]>+.+.+.+.+.");
        check(!bf.error, "bf_adv_alpha_no_err");
        check(bf.out_len == 5, "bf_adv_alpha_len");
        check(bf.output[0] == 'A', "bf_adv_alpha_A");
        check(bf.output[1] == 'B', "bf_adv_alpha_B");
        check(bf.output[2] == 'C', "bf_adv_alpha_C");
        check(bf.output[3] == 'D', "bf_adv_alpha_D");
        check(bf.output[4] == 'E', "bf_adv_alpha_E");
    }

    /* Decrement and output */
    {
        bf_init(&bf);
        bf_execute(&bf, "+++++.-.-.-.-.");
        check(!bf.error, "bf_adv_dec_no_err");
        check(bf.out_len == 5, "bf_adv_dec_len");
        check(bf.output[0] == 5, "bf_adv_dec_5");
        check(bf.output[1] == 4, "bf_adv_dec_4");
        check(bf.output[2] == 3, "bf_adv_dec_3");
        check(bf.output[3] == 2, "bf_adv_dec_2");
        check(bf.output[4] == 1, "bf_adv_dec_1");
    }

    write_str("  bf_advanced OK\n");
}

static void test_validators_advanced(void) {
    write_str("[validators_advanced]\n");

    /* More email patterns */
    check(validate_email("a@b.cd") == 1, "val_adv_email_min");
    check(validate_email("long.user.name@very.long.domain.com") == 0, "val_adv_email_dots");
    /* above fails because we only parse one domain segment before dot */
    check(validate_email("user@domain123.com") == 1, "val_adv_email_num_domain");
    check(validate_email("user_name@host.info") == 1, "val_adv_email_underscore");

    /* More IP patterns */
    check(validate_ip("127.0.0.1") == 1, "val_adv_ip_localhost");
    check(validate_ip("172.16.0.1") == 1, "val_adv_ip_172");
    check(validate_ip("192.168.0.1") == 1, "val_adv_ip_192");
    check(validate_ip("8.8.8.8") == 1, "val_adv_ip_dns");
    check(validate_ip("0.0.0.1") == 1, "val_adv_ip_001");
    check(validate_ip("255.0.0.0") == 1, "val_adv_ip_class_a");
    check(validate_ip("300.1.1.1") == 0, "val_adv_ip_300");
    check(validate_ip("1.2.3.999") == 0, "val_adv_ip_999");
    check(validate_ip("1.2.3.-1") == 0, "val_adv_ip_neg");

    /* More date patterns */
    check(validate_date("2024-04-30") == 1, "val_adv_date_apr30");
    check(validate_date("2024-04-31") == 0, "val_adv_date_apr31");
    check(validate_date("2024-02-28") == 1, "val_adv_date_feb28");
    check(validate_date("2023-02-29") == 0, "val_adv_date_feb29_noleap");
    check(validate_date("2024-11-30") == 1, "val_adv_date_nov30");
    check(validate_date("2024-11-31") == 0, "val_adv_date_nov31");
    check(validate_date("2024-07-31") == 1, "val_adv_date_jul31");
    check(validate_date("2024-09-30") == 1, "val_adv_date_sep30");
    check(validate_date("2024-09-31") == 0, "val_adv_date_sep31");
    check(validate_date("0001-01-01") == 1, "val_adv_date_min");
    check(validate_date("9999-12-31") == 1, "val_adv_date_max");

    write_str("  validators_advanced OK\n");
}

static void test_combined(void) {
    write_str("[combined]\n");

    /* Use DFA + regex to test equivalent patterns */
    {
        DFA d;
        build_dfa_abc(&d);
        /* DFA and regex should agree on these strings */
        check(dfa_run(&d, "ac") == regex_match("ab*c", "ac"), "comb_abc_ac");
        check(dfa_run(&d, "abc") == regex_match("ab*c", "abc"), "comb_abc_abc");
        check(dfa_run(&d, "abbbc") == regex_match("ab*c", "abbbc"), "comb_abc_abbbc");
        check(dfa_run(&d, "a") == regex_match("ab*c", "a"), "comb_abc_a");
        check(dfa_run(&d, "bc") == regex_match("ab*c", "bc"), "comb_abc_bc");
    }

    /* Evaluator consistency: recursive descent vs postfix */
    {
        const char *exprs[] = {
            "2+3", "2+3*4", "(2+3)*4", "10-3", "100/10/2",
            "1+2+3+4+5", "2*3*4", "10+20+30"
        };
        int expected[] = {5, 14, 20, 7, 5, 15, 24, 60};
        int i;
        for (i = 0; i < 8; i++) {
            int err, rd_val;
            char postfix[256];
            int pf_val;
            rd_val = eval_expr(exprs[i], &err);
            infix_to_postfix(exprs[i], postfix, 256);
            pf_val = eval_postfix(postfix);
            check(rd_val == expected[i], "comb_rd_expected");
            check(pf_val == expected[i], "comb_pf_expected");
            check(rd_val == pf_val, "comb_rd_eq_pf");
        }
    }

    /* Validator coverage */
    {
        int email_valid = 0, email_invalid = 0;
        int ip_valid = 0, ip_invalid = 0;
        const char *emails_good[] = {"a@b.cc", "user@host.com", "test@test.org"};
        const char *emails_bad[] = {"@x.com", "x@.com", "x", ""};
        const char *ips_good[] = {"1.2.3.4", "192.168.0.1", "10.0.0.1"};
        const char *ips_bad[] = {"256.0.0.0", "1.2.3", "a.b.c.d"};
        int i;
        for (i = 0; i < 3; i++) email_valid += validate_email(emails_good[i]);
        for (i = 0; i < 4; i++) email_invalid += (1 - validate_email(emails_bad[i]));
        for (i = 0; i < 3; i++) ip_valid += validate_ip(ips_good[i]);
        for (i = 0; i < 3; i++) ip_invalid += (1 - validate_ip(ips_bad[i]));
        check(email_valid == 3, "comb_email_valid");
        check(email_invalid == 4, "comb_email_invalid");
        check(ip_valid == 3, "comb_ip_valid");
        check(ip_invalid == 3, "comb_ip_invalid");
    }

    write_str("  combined OK\n");
}

/* ======================================================================
 * MAIN
 * ====================================================================== */

int main(void) {
    g_errs = 0;
    init_io();
    write_str("=== victim_state stress test ===\n");

    test_dfa();
    test_nfa_to_dfa();
    test_regex();
    test_tokenizer();
    test_expression_eval();
    test_vm();
    test_brainfuck();
    test_validators();
    test_turing();
    test_pda();
    test_ast_parser();
    test_postfix_eval();
    test_dfa_advanced();
    test_regex_advanced();
    test_vm_advanced();
    test_bf_advanced();
    test_validators_advanced();
    test_combined();

    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");
    return g_errs;
}
