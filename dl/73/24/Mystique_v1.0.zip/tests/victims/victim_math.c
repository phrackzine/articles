/*
 * victim_math.c - Number theory and mathematical algorithms stress test
 * Build: cl /nologo /O1 victim_math.c /Fe:victim_math.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * Deterministic output, self-contained, Windows x86-32 (MSVC)
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ========================================================================
 * GCD - Euclidean algorithm
 * ======================================================================== */
static int gcd(int a, int b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a;
}

static void test_gcd(void) {
    write_str("[GCD]\n");
    check(gcd(48, 18) == 6, "gcd(48,18)==6");
    check(gcd(18, 48) == 6, "gcd(18,48)==6");
    check(gcd(0, 5) == 5, "gcd(0,5)==5");
    check(gcd(5, 0) == 5, "gcd(5,0)==5");
    check(gcd(0, 0) == 0, "gcd(0,0)==0");
    check(gcd(1, 1) == 1, "gcd(1,1)==1");
    check(gcd(100, 75) == 25, "gcd(100,75)==25");
    check(gcd(13, 7) == 1, "gcd(13,7)==1");
    check(gcd(270, 192) == 6, "gcd(270,192)==6");
    check(gcd(35, 14) == 7, "gcd(35,14)==7");
    check(gcd(1071, 462) == 21, "gcd(1071,462)==21");
    check(gcd(3 * 5 * 7, 5 * 7 * 11) == 35, "gcd(105,385)==35");
    check(gcd(-48, 18) == 6, "gcd(-48,18)==6");
    check(gcd(48, -18) == 6, "gcd(48,-18)==6");
    check(gcd(17, 1) == 1, "gcd(17,1)==1");
    check(gcd(12, 12) == 12, "gcd(12,12)==12");
    check(gcd(1000000, 999999) == 1, "gcd(1000000,999999)==1");
    check(gcd(462, 1071) == 21, "gcd(462,1071)==21");
    check(gcd(2 * 3 * 5, 3 * 5 * 7) == 15, "gcd(30,105)==15");
    check(gcd(7 * 11 * 13, 11 * 13 * 17) == 143, "gcd(1001,2431)==143");
}

/* ========================================================================
 * Extended GCD - returns gcd, and sets *px, *py such that a*x + b*y = gcd
 * ======================================================================== */
static int ext_gcd(int a, int b, int *px, int *py) {
    if (b == 0) {
        *px = 1;
        *py = 0;
        return a;
    } else {
        int x1, y1;
        int g = ext_gcd(b, a % b, &x1, &y1);
        *px = y1;
        *py = x1 - (a / b) * y1;
        return g;
    }
}

static void test_ext_gcd(void) {
    int x, y, g;
    write_str("[Extended GCD]\n");

    g = ext_gcd(48, 18, &x, &y);
    check(g == 6, "ext_gcd(48,18) g==6");
    check(48 * x + 18 * y == 6, "48*x+18*y==6");

    g = ext_gcd(35, 15, &x, &y);
    check(g == 5, "ext_gcd(35,15) g==5");
    check(35 * x + 15 * y == 5, "35*x+15*y==5");

    g = ext_gcd(99, 78, &x, &y);
    check(g == 3, "ext_gcd(99,78) g==3");
    check(99 * x + 78 * y == 3, "99*x+78*y==3");

    g = ext_gcd(240, 46, &x, &y);
    check(g == 2, "ext_gcd(240,46) g==2");
    check(240 * x + 46 * y == 2, "240*x+46*y==2");

    g = ext_gcd(17, 13, &x, &y);
    check(g == 1, "ext_gcd(17,13) g==1");
    check(17 * x + 13 * y == 1, "17*x+13*y==1");

    g = ext_gcd(1, 1, &x, &y);
    check(g == 1, "ext_gcd(1,1) g==1");
    check(1 * x + 1 * y == 1, "1*x+1*y==1");

    g = ext_gcd(100, 23, &x, &y);
    check(g == 1, "ext_gcd(100,23) g==1");
    check(100 * x + 23 * y == 1, "100*x+23*y==1");

    g = ext_gcd(252, 198, &x, &y);
    check(g == 18, "ext_gcd(252,198) g==18");
    check(252 * x + 198 * y == 18, "252*x+198*y==18");

    g = ext_gcd(1071, 462, &x, &y);
    check(g == 21, "ext_gcd(1071,462) g==21");
    check(1071 * x + 462 * y == 21, "1071*x+462*y==21");

    g = ext_gcd(3, 7, &x, &y);
    check(g == 1, "ext_gcd(3,7) g==1");
    check(3 * x + 7 * y == 1, "3*x+7*y==1");
}

/* ========================================================================
 * LCM
 * ======================================================================== */
static int lcm(int a, int b) {
    if (a == 0 || b == 0) return 0;
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    return (a / gcd(a, b)) * b;
}

static void test_lcm(void) {
    write_str("[LCM]\n");
    check(lcm(4, 6) == 12, "lcm(4,6)==12");
    check(lcm(3, 5) == 15, "lcm(3,5)==15");
    check(lcm(12, 18) == 36, "lcm(12,18)==36");
    check(lcm(0, 5) == 0, "lcm(0,5)==0");
    check(lcm(7, 7) == 7, "lcm(7,7)==7");
    check(lcm(1, 100) == 100, "lcm(1,100)==100");
    check(lcm(21, 6) == 42, "lcm(21,6)==42");
    check(lcm(8, 12) == 24, "lcm(8,12)==24");
    check(lcm(15, 25) == 75, "lcm(15,25)==75");
    check(lcm(13, 17) == 221, "lcm(13,17)==221");
    check(lcm(100, 75) == 300, "lcm(100,75)==300");
    check(lcm(14, 21) == 42, "lcm(14,21)==42");
    check(lcm(9, 12) == 36, "lcm(9,12)==36");
    check(lcm(35, 25) == 175, "lcm(35,25)==175");
}

/* ========================================================================
 * Modular exponentiation - binary method
 * ======================================================================== */
static int mod_exp(int base, int exp, int mod) {
    int result = 1;
    base = base % mod;
    if (base < 0) base += mod;
    while (exp > 0) {
        if (exp & 1) {
            result = (int)(((long long)result * base) % mod);
        }
        exp >>= 1;
        base = (int)(((long long)base * base) % mod);
    }
    return result;
}

static void test_mod_exp(void) {
    write_str("[Modular Exponentiation]\n");
    check(mod_exp(2, 10, 1000) == 24, "2^10 mod 1000 == 24");
    check(mod_exp(2, 10, 1024) == 0, "2^10 mod 1024 == 0");
    check(mod_exp(3, 5, 13) == 9, "3^5 mod 13 == 9");
    check(mod_exp(5, 3, 13) == 8, "5^3 mod 13 == 8");
    check(mod_exp(2, 20, 1000000) == 48576, "2^20 mod 1000000");
    check(mod_exp(7, 0, 13) == 1, "7^0 mod 13 == 1");
    check(mod_exp(7, 1, 13) == 7, "7^1 mod 13 == 7");
    check(mod_exp(2, 16, 100) == 36, "2^16 mod 100 == 36");
    check(mod_exp(10, 5, 100003) == 100000 % 100003, "10^5 mod 100003");
    check(mod_exp(3, 7, 100) == 2187 % 100, "3^7 mod 100 == 87");
    check(mod_exp(2, 31, 1000000007) == mod_exp(2, 31, 1000000007), "2^31 self-consistent");
    check(mod_exp(13, 4, 497) == (28561 % 497), "13^4 mod 497");
    /* Fermat's little theorem: a^(p-1) = 1 mod p for prime p */
    check(mod_exp(2, 12, 13) == 1, "Fermat: 2^12 mod 13 == 1");
    check(mod_exp(3, 16, 17) == 1, "Fermat: 3^16 mod 17 == 1");
    check(mod_exp(5, 22, 23) == 1, "Fermat: 5^22 mod 23 == 1");
    check(mod_exp(7, 10, 11) == 1, "Fermat: 7^10 mod 11 == 1");
}

/* ========================================================================
 * Modular inverse using extended GCD
 * ======================================================================== */
static int mod_inverse(int a, int m) {
    int x, y;
    int g = ext_gcd(a, m, &x, &y);
    if (g != 1) return -1; /* no inverse */
    return ((x % m) + m) % m;
}

static void test_mod_inverse(void) {
    write_str("[Modular Inverse]\n");
    check(mod_inverse(3, 7) == 5, "3^-1 mod 7 == 5");
    check((3 * 5) % 7 == 1, "verify 3*5 mod 7 == 1");
    check(mod_inverse(2, 5) == 3, "2^-1 mod 5 == 3");
    check(mod_inverse(7, 11) == 8, "7^-1 mod 11 == 8");
    check((7 * 8) % 11 == 1, "verify 7*8 mod 11 == 1");
    check(mod_inverse(3, 11) == 4, "3^-1 mod 11 == 4");
    check(mod_inverse(10, 17) == 12, "10^-1 mod 17 == 12");
    check((10 * 12) % 17 == 1, "verify 10*12 mod 17 == 1");
    check(mod_inverse(4, 9) == 7, "4^-1 mod 9 == 7");
    check(mod_inverse(2, 4) == -1, "2^-1 mod 4 == no inverse");
    check(mod_inverse(6, 9) == -1, "6^-1 mod 9 == no inverse");
    check(mod_inverse(1, 100) == 1, "1^-1 mod 100 == 1");
    {
        int inv = mod_inverse(13, 97);
        check((13 * inv) % 97 == 1, "13*inv mod 97 == 1");
    }
    {
        int inv = mod_inverse(37, 101);
        check((37 * inv) % 101 == 1, "37*inv mod 101 == 1");
    }
}

/* ========================================================================
 * Sieve of Eratosthenes (up to 10000)
 * ======================================================================== */
#define SIEVE_MAX 10001
static char sieve[SIEVE_MAX];
static int primes[1300]; /* pi(10000) = 1229 */
static int prime_count;

static void build_sieve(void) {
    int i, j;
    memset(sieve, 1, sizeof(sieve));
    sieve[0] = sieve[1] = 0;
    for (i = 2; i * i < SIEVE_MAX; i++) {
        if (sieve[i]) {
            for (j = i * i; j < SIEVE_MAX; j += i) {
                sieve[j] = 0;
            }
        }
    }
    prime_count = 0;
    for (i = 2; i < SIEVE_MAX; i++) {
        if (sieve[i]) {
            primes[prime_count++] = i;
        }
    }
}

static void test_sieve(void) {
    /* Primes up to 100 */
    static const int p100[] = {
        2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97
    };
    int i, count100 = 0;

    write_str("[Sieve of Eratosthenes]\n");
    build_sieve();

    check(prime_count == 1229, "pi(10000)==1229");

    /* verify all primes up to 100 */
    for (i = 2; i <= 100; i++) {
        if (sieve[i]) count100++;
    }
    check(count100 == 25, "25 primes up to 100");

    for (i = 0; i < 25; i++) {
        check(sieve[p100[i]] == 1, "prime check p100");
    }

    /* verify composites */
    check(sieve[4] == 0, "4 is composite");
    check(sieve[6] == 0, "6 is composite");
    check(sieve[8] == 0, "8 is composite");
    check(sieve[9] == 0, "9 is composite");
    check(sieve[10] == 0, "10 is composite");
    check(sieve[100] == 0, "100 is composite");
    check(sieve[1000] == 0, "1000 is composite");
    check(sieve[9999] == 0, "9999 is composite");
    check(sieve[9973] == 1, "9973 is prime");

    /* first prime */
    check(primes[0] == 2, "first prime == 2");
    /* last prime below 10000 */
    check(primes[prime_count - 1] == 9973, "last prime == 9973");

    /* twin primes check: (3,5), (5,7), (11,13), (17,19) */
    check(sieve[3] && sieve[5], "twin (3,5)");
    check(sieve[11] && sieve[13], "twin (11,13)");
    check(sieve[17] && sieve[19], "twin (17,19)");
    check(sieve[29] && sieve[31], "twin (29,31)");
}

/* ========================================================================
 * Primality test - trial division
 * ======================================================================== */
static int is_prime_trial(int n) {
    int i;
    if (n < 2) return 0;
    if (n < 4) return 1;
    if (n % 2 == 0) return 0;
    if (n % 3 == 0) return 0;
    for (i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return 0;
    }
    return 1;
}

static void test_trial_division(void) {
    int i, mismatches;
    write_str("[Trial Division Primality]\n");
    check(is_prime_trial(2) == 1, "2 is prime");
    check(is_prime_trial(3) == 1, "3 is prime");
    check(is_prime_trial(4) == 0, "4 is not prime");
    check(is_prime_trial(5) == 1, "5 is prime");
    check(is_prime_trial(17) == 1, "17 is prime");
    check(is_prime_trial(97) == 1, "97 is prime");
    check(is_prime_trial(100) == 0, "100 is not prime");
    check(is_prime_trial(1) == 0, "1 is not prime");
    check(is_prime_trial(0) == 0, "0 is not prime");
    check(is_prime_trial(-5) == 0, "-5 is not prime");
    check(is_prime_trial(7919) == 1, "7919 is prime");
    check(is_prime_trial(7920) == 0, "7920 is not prime");
    check(is_prime_trial(104729) == 1, "104729 is prime");

    /* Cross-check against sieve */
    mismatches = 0;
    for (i = 2; i < SIEVE_MAX; i++) {
        if (is_prime_trial(i) != sieve[i]) mismatches++;
    }
    check(mismatches == 0, "trial div matches sieve for [2,10000]");
}

/* ========================================================================
 * Miller-Rabin-like deterministic primality test (fixed witnesses)
 * Deterministic for n < 3,215,031,751 using witnesses {2, 3, 5, 7}
 * ======================================================================== */
static int miller_rabin_witness(int n, int a) {
    int d, r, i;
    long long x;
    if (n % a == 0) return (n == a) ? 1 : 0;

    d = n - 1;
    r = 0;
    while ((d & 1) == 0) {
        d >>= 1;
        r++;
    }

    x = mod_exp(a, d, n);
    if (x == 1 || x == n - 1) return 1;

    for (i = 0; i < r - 1; i++) {
        x = (x * x) % n;
        if (x == n - 1) return 1;
    }
    return 0;
}

static int is_prime_mr(int n) {
    static const int witnesses[] = { 2, 3, 5, 7 };
    int i;
    if (n < 2) return 0;
    if (n < 4) return 1;
    if (n % 2 == 0) return 0;
    for (i = 0; i < 4; i++) {
        if (!miller_rabin_witness(n, witnesses[i])) return 0;
    }
    return 1;
}

static void test_miller_rabin(void) {
    int i, mismatches;
    write_str("[Miller-Rabin Primality]\n");
    check(is_prime_mr(2) == 1, "MR: 2 is prime");
    check(is_prime_mr(3) == 1, "MR: 3 is prime");
    check(is_prime_mr(5) == 1, "MR: 5 is prime");
    check(is_prime_mr(7) == 1, "MR: 7 is prime");
    check(is_prime_mr(11) == 1, "MR: 11 is prime");
    check(is_prime_mr(13) == 1, "MR: 13 is prime");
    check(is_prime_mr(4) == 0, "MR: 4 is composite");
    check(is_prime_mr(9) == 0, "MR: 9 is composite");
    check(is_prime_mr(15) == 0, "MR: 15 is composite");
    check(is_prime_mr(561) == 0, "MR: 561 Carmichael composite");
    check(is_prime_mr(1105) == 0, "MR: 1105 Carmichael composite");
    check(is_prime_mr(7919) == 1, "MR: 7919 is prime");
    check(is_prime_mr(104729) == 1, "MR: 104729 is prime");
    check(is_prime_mr(1000003) == 1, "MR: 1000003 is prime");
    check(is_prime_mr(1000004) == 0, "MR: 1000004 is composite");

    /* Cross-check against sieve for 2..10000 */
    mismatches = 0;
    for (i = 2; i < SIEVE_MAX; i++) {
        if (is_prime_mr(i) != sieve[i]) mismatches++;
    }
    check(mismatches == 0, "MR matches sieve for [2,10000]");
}

/* ========================================================================
 * Integer square root - binary search
 * ======================================================================== */
static int isqrt(int n) {
    int lo, hi, mid;
    if (n <= 0) return 0;
    if (n == 1) return 1;
    lo = 1;
    hi = (n < 46340) ? n : 46340; /* avoid overflow: 46340^2 < 2^31 */
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (mid <= n / mid) {
            if ((mid + 1) > n / (mid + 1)) return mid;
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return lo;
}

static void test_isqrt(void) {
    write_str("[Integer Square Root]\n");
    check(isqrt(0) == 0, "isqrt(0)==0");
    check(isqrt(1) == 1, "isqrt(1)==1");
    check(isqrt(4) == 2, "isqrt(4)==2");
    check(isqrt(9) == 3, "isqrt(9)==3");
    check(isqrt(16) == 4, "isqrt(16)==4");
    check(isqrt(25) == 5, "isqrt(25)==5");
    check(isqrt(26) == 5, "isqrt(26)==5");
    check(isqrt(35) == 5, "isqrt(35)==5");
    check(isqrt(36) == 6, "isqrt(36)==6");
    check(isqrt(100) == 10, "isqrt(100)==10");
    check(isqrt(10000) == 100, "isqrt(10000)==100");
    check(isqrt(99) == 9, "isqrt(99)==9");
    check(isqrt(101) == 10, "isqrt(101)==10");
    check(isqrt(2) == 1, "isqrt(2)==1");
    check(isqrt(3) == 1, "isqrt(3)==1");
    check(isqrt(8) == 2, "isqrt(8)==2");
    check(isqrt(1000000) == 1000, "isqrt(1000000)==1000");
    check(isqrt(1000001) == 1000, "isqrt(1000001)==1000");
    check(isqrt(999999) == 999, "isqrt(999999)==999");
    check(isqrt(46340 * 46340) == 46340, "isqrt(46340^2)==46340");

    /* verify all perfect squares up to 200 */
    {
        int i, ok = 1;
        for (i = 0; i <= 200; i++) {
            if (isqrt(i * i) != i) { ok = 0; break; }
        }
        check(ok, "isqrt(i^2)==i for i in [0,200]");
    }
}

/* ========================================================================
 * Euler's totient function
 * ======================================================================== */
static int euler_totient(int n) {
    int result, p;
    if (n <= 1) return (n == 1) ? 1 : 0;
    result = n;
    for (p = 2; p * p <= n; p++) {
        if (n % p == 0) {
            while (n % p == 0) n /= p;
            result -= result / p;
        }
    }
    if (n > 1) {
        result -= result / n;
    }
    return result;
}

static void test_euler_totient(void) {
    write_str("[Euler's Totient]\n");
    check(euler_totient(1) == 1, "phi(1)==1");
    check(euler_totient(2) == 1, "phi(2)==1");
    check(euler_totient(3) == 2, "phi(3)==2");
    check(euler_totient(4) == 2, "phi(4)==2");
    check(euler_totient(5) == 4, "phi(5)==4");
    check(euler_totient(6) == 2, "phi(6)==2");
    check(euler_totient(7) == 6, "phi(7)==6");
    check(euler_totient(8) == 4, "phi(8)==4");
    check(euler_totient(9) == 6, "phi(9)==6");
    check(euler_totient(10) == 4, "phi(10)==4");
    check(euler_totient(12) == 4, "phi(12)==4");
    check(euler_totient(13) == 12, "phi(13)==12 (prime)");
    check(euler_totient(100) == 40, "phi(100)==40");
    check(euler_totient(36) == 12, "phi(36)==12");
    check(euler_totient(97) == 96, "phi(97)==96 (prime)");
    check(euler_totient(1000) == 400, "phi(1000)==400");

    /* For prime p, phi(p) = p-1 */
    check(euler_totient(17) == 16, "phi(17)==16");
    check(euler_totient(31) == 30, "phi(31)==30");
    check(euler_totient(101) == 100, "phi(101)==100");

    /* Euler's theorem: a^phi(n) = 1 mod n when gcd(a,n)=1 */
    {
        int n = 100, phi = euler_totient(100); /* phi(100)=40 */
        check(mod_exp(3, phi, n) == 1, "Euler thm: 3^40 mod 100 == 1");
        check(mod_exp(7, phi, n) == 1, "Euler thm: 7^40 mod 100 == 1");
        check(mod_exp(11, phi, n) == 1, "Euler thm: 11^40 mod 100 == 1");
    }
}

/* ========================================================================
 * Chinese Remainder Theorem - solve 2 or 3 congruences
 * x = a1 mod m1, x = a2 mod m2
 * ======================================================================== */
static int crt2(int a1, int m1, int a2, int m2) {
    /* Requires gcd(m1, m2) == 1 */
    int inv = mod_inverse(m1, m2);
    long long x;
    if (inv < 0) return -1;
    x = (long long)a1 + (long long)m1 * (((long long)(a2 - a1) * inv) % m2);
    x = ((x % ((long long)m1 * m2)) + (long long)m1 * m2) % ((long long)m1 * m2);
    return (int)x;
}

static int crt3(int a1, int m1, int a2, int m2, int a3, int m3) {
    int x12 = crt2(a1, m1, a2, m2);
    if (x12 < 0) return -1;
    return crt2(x12, m1 * m2, a3, m3);
}

static void test_crt(void) {
    int x;
    write_str("[Chinese Remainder Theorem]\n");

    /* x = 2 mod 3, x = 3 mod 5 => x = 8 mod 15 */
    x = crt2(2, 3, 3, 5);
    check(x == 8, "CRT: x=2 mod 3, x=3 mod 5 => x=8");
    check(x % 3 == 2, "verify x mod 3 == 2");
    check(x % 5 == 3, "verify x mod 5 == 3");

    /* x = 1 mod 2, x = 2 mod 3 => x = 5 mod 6 */
    x = crt2(1, 2, 2, 3);
    check(x == 5, "CRT: x=1 mod 2, x=2 mod 3 => x=5");

    /* x = 3 mod 5, x = 1 mod 7 => x = 8 mod 35 */
    x = crt2(3, 5, 1, 7);
    check(x == 8, "CRT: x=3 mod 5, x=1 mod 7 => x=8");

    /* 3 congruences: x = 2 mod 3, x = 3 mod 5, x = 2 mod 7 => x = 23 mod 105 */
    x = crt3(2, 3, 3, 5, 2, 7);
    check(x == 23, "CRT3: x=2mod3,3mod5,2mod7 => x=23");
    check(x % 3 == 2, "verify x mod 3 == 2 (3-way)");
    check(x % 5 == 3, "verify x mod 5 == 3 (3-way)");
    check(x % 7 == 2, "verify x mod 7 == 2 (3-way)");

    /* x = 1 mod 2, x = 2 mod 3, x = 3 mod 5 => x = 23 mod 30 */
    x = crt3(1, 2, 2, 3, 3, 5);
    check(x == 23, "CRT3: 1mod2,2mod3,3mod5 => 23");
    check(x % 2 == 1, "verify mod 2");
    check(x % 3 == 2, "verify mod 3");
    check(x % 5 == 3, "verify mod 5");

    /* x = 0 mod 3, x = 4 mod 5, x = 6 mod 7 => ? mod 105 */
    x = crt3(0, 3, 4, 5, 6, 7);
    check(x % 3 == 0, "CRT3 verify mod 3");
    check(x % 5 == 4, "CRT3 verify mod 5");
    check(x % 7 == 6, "CRT3 verify mod 7");
}

/* ========================================================================
 * Fibonacci - iterative
 * ======================================================================== */
static int fib_iter(int n) {
    int a = 0, b = 1, i, t;
    if (n <= 0) return 0;
    if (n == 1) return 1;
    for (i = 2; i <= n; i++) {
        t = a + b;
        a = b;
        b = t;
    }
    return b;
}

/* ========================================================================
 * Fibonacci - matrix method (fast doubling)
 * F(2k) = F(k) * [2*F(k+1) - F(k)]
 * F(2k+1) = F(k)^2 + F(k+1)^2
 * ======================================================================== */
static void fib_matrix_helper(int n, int *pfn, int *pfn1) {
    int a, b, c, d;
    if (n == 0) {
        *pfn = 0;
        *pfn1 = 1;
        return;
    }
    fib_matrix_helper(n >> 1, &a, &b);
    c = a * (2 * b - a);
    d = a * a + b * b;
    if (n & 1) {
        *pfn = d;
        *pfn1 = c + d;
    } else {
        *pfn = c;
        *pfn1 = d;
    }
}

static int fib_matrix(int n) {
    int fn, fn1;
    if (n <= 0) return 0;
    fib_matrix_helper(n, &fn, &fn1);
    return fn;
}

static void test_fibonacci(void) {
    int i;
    static const int fib_expected[] = {
        0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610,
        987, 1597, 2584, 4181, 6765
    };
    write_str("[Fibonacci]\n");

    /* test iterative */
    for (i = 0; i <= 20; i++) {
        check(fib_iter(i) == fib_expected[i], "fib_iter check");
    }
    check(fib_iter(20) == 6765, "fib_iter(20)==6765");
    check(fib_iter(30) == 832040, "fib_iter(30)==832040");

    /* test matrix method */
    for (i = 0; i <= 20; i++) {
        check(fib_matrix(i) == fib_expected[i], "fib_matrix check");
    }
    check(fib_matrix(20) == 6765, "fib_matrix(20)==6765");
    check(fib_matrix(30) == 832040, "fib_matrix(30)==832040");

    /* cross-check both methods */
    {
        int ok = 1;
        for (i = 0; i <= 40; i++) {
            if (fib_iter(i) != fib_matrix(i)) { ok = 0; break; }
        }
        check(ok, "fib_iter == fib_matrix for [0..40]");
    }
}

/* ========================================================================
 * Catalan numbers - iterative using C(n) = C(2n,n)/(n+1)
 * ======================================================================== */
static int catalan(int n) {
    /* C(n) = binomial(2n,n) / (n+1) computed iteratively */
    long long result = 1;
    int i;
    for (i = 0; i < n; i++) {
        result = result * (2 * n - i) / (i + 1);
    }
    return (int)(result / (n + 1));
}

static void test_catalan(void) {
    static const int cat_expected[] = {
        1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862,
        16796, 58786, 208012, 742900, 2674440, 9694845
    };
    int i;
    write_str("[Catalan Numbers]\n");
    for (i = 0; i <= 15; i++) {
        check(catalan(i) == cat_expected[i], "catalan check");
    }
    check(catalan(0) == 1, "C(0)==1");
    check(catalan(1) == 1, "C(1)==1");
    check(catalan(2) == 2, "C(2)==2");
    check(catalan(5) == 42, "C(5)==42");
    check(catalan(10) == 16796, "C(10)==16796");
    check(catalan(15) == 9694845, "C(15)==9694845");
}

/* ========================================================================
 * Binomial coefficients - Pascal's triangle
 * ======================================================================== */
#define BINOM_MAX 21
static int pascal_tri[BINOM_MAX][BINOM_MAX];

static void build_pascal(void) {
    int i, j;
    for (i = 0; i < BINOM_MAX; i++) {
        pascal_tri[i][0] = 1;
        for (j = 1; j <= i; j++) {
            pascal_tri[i][j] = pascal_tri[i - 1][j - 1] + pascal_tri[i - 1][j];
        }
    }
}

static int binom(int n, int k) {
    if (k < 0 || k > n) return 0;
    return pascal_tri[n][k];
}

static void test_binomial(void) {
    int i;
    write_str("[Binomial Coefficients]\n");
    build_pascal();

    check(binom(0, 0) == 1, "C(0,0)==1");
    check(binom(1, 0) == 1, "C(1,0)==1");
    check(binom(1, 1) == 1, "C(1,1)==1");
    check(binom(5, 2) == 10, "C(5,2)==10");
    check(binom(10, 5) == 252, "C(10,5)==252");
    check(binom(10, 3) == 120, "C(10,3)==120");
    check(binom(20, 10) == 184756, "C(20,10)==184756");
    check(binom(20, 0) == 1, "C(20,0)==1");
    check(binom(20, 20) == 1, "C(20,20)==1");
    check(binom(15, 7) == 6435, "C(15,7)==6435");

    /* Symmetry: C(n,k) == C(n, n-k) */
    {
        int ok = 1;
        for (i = 0; i <= 20; i++) {
            int j;
            for (j = 0; j <= i; j++) {
                if (binom(i, j) != binom(i, i - j)) { ok = 0; break; }
            }
            if (!ok) break;
        }
        check(ok, "C(n,k)==C(n,n-k) symmetry");
    }

    /* Sum of row: sum C(n,k) = 2^n */
    {
        int n;
        for (n = 0; n <= 20; n++) {
            int sum = 0, k;
            for (k = 0; k <= n; k++) sum += binom(n, k);
            check(sum == (1 << n), "row sum == 2^n");
        }
    }

    /* Pascal's rule: C(n,k) = C(n-1,k-1) + C(n-1,k) */
    {
        int ok = 1, n, k;
        for (n = 2; n <= 20; n++) {
            for (k = 1; k < n; k++) {
                if (binom(n, k) != binom(n - 1, k - 1) + binom(n - 1, k)) { ok = 0; break; }
            }
            if (!ok) break;
        }
        check(ok, "Pascal's rule verified");
    }
}

/* ========================================================================
 * Collatz sequence - count steps to reach 1
 * ======================================================================== */
static int collatz_steps(int n) {
    int steps = 0;
    while (n != 1) {
        if (n & 1) {
            n = 3 * n + 1;
        } else {
            n >>= 1;
        }
        steps++;
    }
    return steps;
}

static void test_collatz(void) {
    write_str("[Collatz Sequence]\n");
    check(collatz_steps(1) == 0, "collatz(1)==0");
    check(collatz_steps(2) == 1, "collatz(2)==1");
    check(collatz_steps(3) == 7, "collatz(3)==7");
    check(collatz_steps(4) == 2, "collatz(4)==2");
    check(collatz_steps(5) == 5, "collatz(5)==5");
    check(collatz_steps(6) == 8, "collatz(6)==8");
    check(collatz_steps(7) == 16, "collatz(7)==16");
    check(collatz_steps(8) == 3, "collatz(8)==3");
    check(collatz_steps(9) == 19, "collatz(9)==19");
    check(collatz_steps(10) == 6, "collatz(10)==6");
    check(collatz_steps(27) == 111, "collatz(27)==111");
    check(collatz_steps(16) == 4, "collatz(16)==4");
    check(collatz_steps(32) == 5, "collatz(32)==5");
    check(collatz_steps(64) == 6, "collatz(64)==6");
    check(collatz_steps(128) == 7, "collatz(128)==7");
    check(collatz_steps(256) == 8, "collatz(256)==8");

    /* Powers of 2 take log2(n) steps */
    {
        int p = 1, s;
        for (s = 0; s <= 15; s++) {
            check(collatz_steps(p) == s, "collatz(2^k)==k");
            p <<= 1;
        }
    }

    /* Verify some all reach 1 */
    {
        int ok = 1, i;
        for (i = 1; i <= 1000; i++) {
            if (collatz_steps(i) < 0) { ok = 0; break; }
        }
        check(ok, "all 1..1000 reach 1");
    }
}

/* ========================================================================
 * Polynomial evaluation - Horner's method
 * p(x) = coeffs[0] + coeffs[1]*x + coeffs[2]*x^2 + ...
 * ======================================================================== */
static int poly_eval(const int *coeffs, int degree, int x) {
    int result = coeffs[degree];
    int i;
    for (i = degree - 1; i >= 0; i--) {
        result = result * x + coeffs[i];
    }
    return result;
}

/* Also brute-force evaluation for cross-check */
static int poly_eval_brute(const int *coeffs, int degree, int x) {
    int result = 0;
    int i;
    int power = 1;
    for (i = 0; i <= degree; i++) {
        result += coeffs[i] * power;
        power *= x;
    }
    return result;
}

static void test_horner(void) {
    /* p(x) = 2 + 3x + x^2 */
    static const int poly1[] = { 2, 3, 1 };
    /* p(x) = 1 - x + x^2 - x^3 + x^4 */
    static const int poly2[] = { 1, -1, 1, -1, 1 };
    /* p(x) = 5 */
    static const int poly3[] = { 5 };
    /* p(x) = x^5 */
    static const int poly4[] = { 0, 0, 0, 0, 0, 1 };
    /* p(x) = 1 + x + x^2 + x^3 + x^4 + x^5 (geometric sum) */
    static const int poly5[] = { 1, 1, 1, 1, 1, 1 };

    int i, ok;

    write_str("[Horner's Method]\n");

    /* poly1: p(0)=2, p(1)=6, p(2)=12, p(-1)=0, p(3)=20 */
    check(poly_eval(poly1, 2, 0) == 2, "p1(0)==2");
    check(poly_eval(poly1, 2, 1) == 6, "p1(1)==6");
    check(poly_eval(poly1, 2, 2) == 12, "p1(2)==12");
    check(poly_eval(poly1, 2, -1) == 0, "p1(-1)==0");
    check(poly_eval(poly1, 2, 3) == 20, "p1(3)==20");
    check(poly_eval(poly1, 2, 10) == 132, "p1(10)==132");

    /* poly2 */
    check(poly_eval(poly2, 4, 0) == 1, "p2(0)==1");
    check(poly_eval(poly2, 4, 1) == 1, "p2(1)==1");
    check(poly_eval(poly2, 4, 2) == 11, "p2(2)==11");
    check(poly_eval(poly2, 4, -1) == 5, "p2(-1)==5");

    /* constant */
    check(poly_eval(poly3, 0, 100) == 5, "constant(100)==5");
    check(poly_eval(poly3, 0, 0) == 5, "constant(0)==5");

    /* x^5 */
    check(poly_eval(poly4, 5, 2) == 32, "x^5 at 2 == 32");
    check(poly_eval(poly4, 5, 3) == 243, "x^5 at 3 == 243");
    check(poly_eval(poly4, 5, -2) == -32, "x^5 at -2 == -32");

    /* Geometric sum: (x^6-1)/(x-1) for x != 1 */
    check(poly_eval(poly5, 5, 2) == 63, "geo(2)==63");
    check(poly_eval(poly5, 5, 3) == 364, "geo(3)==364");

    /* Cross-check Horner vs brute-force */
    ok = 1;
    for (i = -10; i <= 10; i++) {
        if (poly_eval(poly1, 2, i) != poly_eval_brute(poly1, 2, i)) { ok = 0; break; }
        if (poly_eval(poly2, 4, i) != poly_eval_brute(poly2, 4, i)) { ok = 0; break; }
        if (poly_eval(poly4, 5, i) != poly_eval_brute(poly4, 5, i)) { ok = 0; break; }
        if (poly_eval(poly5, 5, i) != poly_eval_brute(poly5, 5, i)) { ok = 0; break; }
    }
    check(ok, "Horner matches brute-force [-10..10]");
}

/* ========================================================================
 * Newton's method integer approximation for cube root
 * floor(cbrt(n)) for n >= 0
 * ======================================================================== */
static int icbrt(int n) {
    int x, x1;
    if (n <= 0) return 0;
    if (n < 8) return 1;

    /* Initial guess */
    x = n;
    if (x > 1000) x = 100;
    else if (x > 100) x = 10;

    /* Newton iteration: x = (2*x + n/(x*x)) / 3 */
    while (1) {
        x1 = (2 * x + n / (x * x)) / 3;
        if (x1 >= x) break;
        x = x1;
    }

    /* Adjust */
    while ((x + 1) * (x + 1) * (x + 1) <= n) x++;
    while (x * x * x > n) x--;
    return x;
}

static void test_icbrt(void) {
    int i;
    write_str("[Integer Cube Root]\n");
    check(icbrt(0) == 0, "cbrt(0)==0");
    check(icbrt(1) == 1, "cbrt(1)==1");
    check(icbrt(7) == 1, "cbrt(7)==1");
    check(icbrt(8) == 2, "cbrt(8)==2");
    check(icbrt(26) == 2, "cbrt(26)==2");
    check(icbrt(27) == 3, "cbrt(27)==3");
    check(icbrt(28) == 3, "cbrt(28)==3");
    check(icbrt(64) == 4, "cbrt(64)==4");
    check(icbrt(125) == 5, "cbrt(125)==5");
    check(icbrt(216) == 6, "cbrt(216)==6");
    check(icbrt(343) == 7, "cbrt(343)==7");
    check(icbrt(1000) == 10, "cbrt(1000)==10");
    check(icbrt(999) == 9, "cbrt(999)==9");
    check(icbrt(1001) == 10, "cbrt(1001)==10");
    check(icbrt(1000000) == 100, "cbrt(1000000)==100");
    check(icbrt(999999) == 99, "cbrt(999999)==99");

    /* verify all perfect cubes up to 100 */
    {
        int ok = 1;
        for (i = 0; i <= 100; i++) {
            if (icbrt(i * i * i) != i) { ok = 0; break; }
        }
        check(ok, "cbrt(i^3)==i for i in [0,100]");
    }
}

/* ========================================================================
 * Simple big-number addition (arrays of digits, up to 100 digits)
 * Digits stored LSB-first: num[0] is ones digit
 * ======================================================================== */
#define BIG_MAX 101

typedef struct {
    int digits[BIG_MAX];
    int len;
} BigNum;

static void big_zero(BigNum *n) {
    memset(n->digits, 0, sizeof(n->digits));
    n->len = 1;
}

static void big_from_int(BigNum *n, int val) {
    big_zero(n);
    if (val == 0) return;
    n->len = 0;
    while (val > 0) {
        n->digits[n->len++] = val % 10;
        val /= 10;
    }
}

static void big_from_str(BigNum *n, const char *s) {
    int slen, i;
    big_zero(n);
    slen = (int)strlen(s);
    n->len = slen;
    for (i = 0; i < slen; i++) {
        n->digits[i] = s[slen - 1 - i] - '0';
    }
}

static void big_add(const BigNum *a, const BigNum *b, BigNum *result) {
    int carry = 0, i;
    int maxlen = a->len > b->len ? a->len : b->len;
    big_zero(result);
    for (i = 0; i < maxlen || carry; i++) {
        int sum = carry;
        if (i < a->len) sum += a->digits[i];
        if (i < b->len) sum += b->digits[i];
        result->digits[i] = sum % 10;
        carry = sum / 10;
    }
    result->len = i;
    if (result->len == 0) result->len = 1;
}

static void big_to_str(const BigNum *n, char *buf) {
    int i;
    for (i = n->len - 1; i >= 0; i--) {
        *buf++ = (char)(n->digits[i] + '0');
    }
    *buf = '\0';
}

static int big_eq_str(const BigNum *n, const char *s) {
    char buf[BIG_MAX + 1];
    big_to_str(n, buf);
    return strcmp(buf, s) == 0;
}

/* Big number multiplication (for Fibonacci cross-check) */
static void big_mul_int(const BigNum *a, int m, BigNum *result) {
    int carry = 0, i;
    big_zero(result);
    for (i = 0; i < a->len || carry; i++) {
        long long prod = carry;
        if (i < a->len) prod += (long long)a->digits[i] * m;
        result->digits[i] = (int)(prod % 10);
        carry = (int)(prod / 10);
    }
    result->len = i;
    if (result->len == 0) result->len = 1;
}

static void test_bignum(void) {
    BigNum a, b, c;

    write_str("[Big Number Addition]\n");

    /* Basic additions */
    big_from_int(&a, 0);
    big_from_int(&b, 0);
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "0"), "0+0=0");

    big_from_int(&a, 123);
    big_from_int(&b, 456);
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "579"), "123+456=579");

    big_from_int(&a, 999);
    big_from_int(&b, 1);
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "1000"), "999+1=1000");

    big_from_int(&a, 999999);
    big_from_int(&b, 1);
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "1000000"), "999999+1=1000000");

    /* Large number additions using strings */
    big_from_str(&a, "99999999999999999999999999999999999999999999999999");
    big_from_str(&b, "1");
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "100000000000000000000000000000000000000000000000000"),
          "50-digit carry chain");

    big_from_str(&a, "12345678901234567890");
    big_from_str(&b, "98765432109876543210");
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "111111111011111111100"),
          "20-digit addition");

    big_from_str(&a, "55555555555555555555555555555555555555555555555555");
    big_from_str(&b, "55555555555555555555555555555555555555555555555555");
    big_add(&a, &b, &c);
    check(big_eq_str(&c, "111111111111111111111111111111111111111111111111110"),
          "50-digit doubled");

    /* Fibonacci(100) using bignum */
    {
        BigNum f0, f1, f2;
        int i;
        big_from_int(&f0, 0);
        big_from_int(&f1, 1);
        for (i = 2; i <= 100; i++) {
            big_add(&f0, &f1, &f2);
            f0 = f1;
            f1 = f2;
        }
        check(big_eq_str(&f1, "354224848179261915075"),
              "big fib(100)==354224848179261915075");
    }

    /* Factorial-like: 1+2+3+...+100 = 5050 */
    {
        BigNum sum, addend;
        int i;
        big_from_int(&sum, 0);
        for (i = 1; i <= 100; i++) {
            big_from_int(&addend, i);
            big_add(&sum, &addend, &c);
            sum = c;
        }
        check(big_eq_str(&sum, "5050"), "sum 1..100 = 5050");
    }

    /* big_mul_int test: 12345 * 99 = 1222155 */
    big_from_int(&a, 12345);
    big_mul_int(&a, 99, &c);
    check(big_eq_str(&c, "1222155"), "12345*99=1222155");

    /* big_mul_int with large: 999999999 * 2 = 1999999998 */
    big_from_str(&a, "999999999");
    big_mul_int(&a, 2, &c);
    check(big_eq_str(&c, "1999999998"), "999999999*2=1999999998");

    /* Commutativity */
    big_from_int(&a, 54321);
    big_from_int(&b, 12345);
    {
        BigNum r1, r2;
        big_add(&a, &b, &r1);
        big_add(&b, &a, &r2);
        {
            char s1[BIG_MAX + 1], s2[BIG_MAX + 1];
            big_to_str(&r1, s1);
            big_to_str(&r2, s2);
            check(strcmp(s1, s2) == 0, "addition commutative");
        }
    }
}

/* ========================================================================
 * Additional number theory tests for line count
 * ======================================================================== */

/* Sum of divisors */
static int sum_of_divisors(int n) {
    int sum = 0, i;
    for (i = 1; i * i <= n; i++) {
        if (n % i == 0) {
            sum += i;
            if (i != n / i) sum += n / i;
        }
    }
    return sum;
}

/* Is perfect number */
static int is_perfect(int n) {
    return n > 1 && sum_of_divisors(n) == 2 * n;
}

/* Count divisors */
static int count_divisors(int n) {
    int count = 0, i;
    for (i = 1; i * i <= n; i++) {
        if (n % i == 0) {
            count++;
            if (i != n / i) count++;
        }
    }
    return count;
}

static void test_divisor_functions(void) {
    write_str("[Divisor Functions]\n");
    check(sum_of_divisors(1) == 1, "sigma(1)==1");
    check(sum_of_divisors(6) == 12, "sigma(6)==12");
    check(sum_of_divisors(12) == 28, "sigma(12)==28");
    check(sum_of_divisors(28) == 56, "sigma(28)==56");

    check(is_perfect(6), "6 is perfect");
    check(is_perfect(28), "28 is perfect");
    check(is_perfect(496), "496 is perfect");
    check(!is_perfect(10), "10 is not perfect");
    check(!is_perfect(12), "12 is not perfect");

    check(count_divisors(1) == 1, "d(1)==1");
    check(count_divisors(2) == 2, "d(2)==2");
    check(count_divisors(6) == 4, "d(6)==4");
    check(count_divisors(12) == 6, "d(12)==6");
    check(count_divisors(24) == 8, "d(24)==8");
    check(count_divisors(36) == 9, "d(36)==9");
    check(count_divisors(100) == 9, "d(100)==9");
    check(count_divisors(1) == 1, "d(1)==1 again");
    check(count_divisors(97) == 2, "d(97)==2 (prime)");

    /* Highly composite: 120 has 16 divisors */
    check(count_divisors(120) == 16, "d(120)==16");
}

/* ========================================================================
 * Modular arithmetic: linear congruence solver
 * Solve ax = b (mod m)
 * ======================================================================== */
static int solve_linear_congruence(int a, int b, int m) {
    /* Returns smallest non-negative x such that ax = b mod m, or -1 */
    int g = gcd(a, m);
    int inv;
    long long x;
    if (b % g != 0) return -1;
    a /= g;
    b /= g;
    m /= g;
    inv = mod_inverse(a, m);
    if (inv < 0) return -1;
    x = ((long long)inv * b) % m;
    if (x < 0) x += m;
    return (int)x;
}

static void test_linear_congruence(void) {
    int x;
    write_str("[Linear Congruence]\n");

    /* 3x = 6 mod 9 => x = 2 (or 5 or 8) */
    x = solve_linear_congruence(3, 6, 9);
    check(x >= 0 && (3 * x) % 9 == 6 % 9, "3x=6 mod 9");

    /* 2x = 1 mod 5 => x = 3 */
    x = solve_linear_congruence(2, 1, 5);
    check(x == 3, "2x=1 mod 5 => x=3");
    check((2 * 3) % 5 == 1, "verify 2*3 mod 5 == 1");

    /* 4x = 3 mod 7 => x = 6 (since 4*6=24, 24 mod 7=3) */
    x = solve_linear_congruence(4, 3, 7);
    check(x == 6, "4x=3 mod 7 => x=6");

    /* 6x = 3 mod 9 => x = 2 */
    x = solve_linear_congruence(6, 3, 9);
    check(x >= 0 && (6 * x) % 9 == 3, "6x=3 mod 9");

    /* No solution: 2x = 1 mod 4 */
    x = solve_linear_congruence(2, 1, 4);
    check(x == -1, "2x=1 mod 4 => no solution");

    /* 5x = 0 mod 5 => x = 0 */
    x = solve_linear_congruence(5, 0, 5);
    check(x == 0, "5x=0 mod 5 => x=0");
}

/* ========================================================================
 * Power sum: 1^k + 2^k + ... + n^k
 * ======================================================================== */
static long long power_sum(int n, int k) {
    long long sum = 0;
    int i;
    for (i = 1; i <= n; i++) {
        long long p = 1;
        int j;
        for (j = 0; j < k; j++) p *= i;
        sum += p;
    }
    return sum;
}

static void test_power_sum(void) {
    write_str("[Power Sums]\n");
    /* Sum of first n: n(n+1)/2 */
    check((int)power_sum(100, 1) == 5050, "sum(1..100)=5050");
    check((int)power_sum(10, 1) == 55, "sum(1..10)=55");

    /* Sum of squares: n(n+1)(2n+1)/6 */
    check((int)power_sum(10, 2) == 385, "sum sq(1..10)=385");
    check((int)power_sum(5, 2) == 55, "sum sq(1..5)=55");

    /* Sum of cubes: [n(n+1)/2]^2 */
    check((int)power_sum(10, 3) == 3025, "sum cu(1..10)=3025");
    check((int)power_sum(5, 3) == 225, "sum cu(1..5)=225");

    /* Verify formula: sum_cubes = (sum_linear)^2 */
    {
        int s1 = (int)power_sum(20, 1);
        int s3 = (int)power_sum(20, 3);
        check(s3 == s1 * s1, "Nicomachus: sum_cubes = (sum)^2 for n=20");
    }

    /* Sum of 0th power = n */
    check((int)power_sum(100, 0) == 100, "sum(1^0..100^0)=100");
}

/* ========================================================================
 * Digital root and digit sum
 * ======================================================================== */
static int digit_sum(int n) {
    int sum = 0;
    if (n < 0) n = -n;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

static int digital_root(int n) {
    if (n == 0) return 0;
    if (n < 0) n = -n;
    return 1 + (n - 1) % 9;
}

static void test_digital_root(void) {
    write_str("[Digital Root]\n");
    check(digit_sum(123) == 6, "dsum(123)==6");
    check(digit_sum(999) == 27, "dsum(999)==27");
    check(digit_sum(0) == 0, "dsum(0)==0");
    check(digit_sum(100000) == 1, "dsum(100000)==1");

    check(digital_root(0) == 0, "droot(0)==0");
    check(digital_root(1) == 1, "droot(1)==1");
    check(digital_root(9) == 9, "droot(9)==9");
    check(digital_root(10) == 1, "droot(10)==1");
    check(digital_root(123) == 6, "droot(123)==6");
    check(digital_root(999) == 9, "droot(999)==9");
    check(digital_root(493) == 7, "droot(493)==7");
    check(digital_root(18) == 9, "droot(18)==9");

    /* digital_root(n) == n mod 9 (with 0->9) for n>0 */
    {
        int ok = 1, i;
        for (i = 1; i <= 1000; i++) {
            int dr = digital_root(i);
            int expected = (i % 9 == 0) ? 9 : i % 9;
            if (dr != expected) { ok = 0; break; }
        }
        check(ok, "digital_root congruence property");
    }
}

/* ========================================================================
 * Integer factorization (trial division)
 * ======================================================================== */
typedef struct {
    int factors[30];
    int exponents[30];
    int count;
} Factorization;

static void factorize(int n, Factorization *f) {
    int p;
    f->count = 0;
    if (n <= 1) return;
    for (p = 2; p * p <= n; p++) {
        if (n % p == 0) {
            f->factors[f->count] = p;
            f->exponents[f->count] = 0;
            while (n % p == 0) {
                f->exponents[f->count]++;
                n /= p;
            }
            f->count++;
        }
    }
    if (n > 1) {
        f->factors[f->count] = n;
        f->exponents[f->count] = 1;
        f->count++;
    }
}

static int reconstruct(const Factorization *f) {
    int result = 1, i, j;
    for (i = 0; i < f->count; i++) {
        for (j = 0; j < f->exponents[i]; j++) {
            result *= f->factors[i];
        }
    }
    return result;
}

static void test_factorization(void) {
    Factorization f;
    write_str("[Integer Factorization]\n");

    factorize(1, &f);
    check(f.count == 0, "factor(1): empty");

    factorize(2, &f);
    check(f.count == 1 && f.factors[0] == 2 && f.exponents[0] == 1, "factor(2)=2^1");

    factorize(12, &f);
    check(f.count == 2, "factor(12): 2 primes");
    check(reconstruct(&f) == 12, "reconstruct 12");

    factorize(360, &f);
    /* 360 = 2^3 * 3^2 * 5 */
    check(reconstruct(&f) == 360, "reconstruct 360");
    check(f.count == 3, "factor(360): 3 primes");

    factorize(97, &f);
    check(f.count == 1 && f.factors[0] == 97, "factor(97)=97 (prime)");

    factorize(1000000, &f);
    check(reconstruct(&f) == 1000000, "reconstruct 1000000");
    /* 10^6 = 2^6 * 5^6 */
    check(f.count == 2, "factor(10^6): 2 primes");

    factorize(2310, &f);
    /* 2310 = 2*3*5*7*11 */
    check(f.count == 5, "factor(2310): 5 primes");
    check(reconstruct(&f) == 2310, "reconstruct 2310");

    /* Verify reconstruction for many numbers */
    {
        int ok = 1, i;
        for (i = 2; i <= 500; i++) {
            factorize(i, &f);
            if (reconstruct(&f) != i) { ok = 0; break; }
        }
        check(ok, "reconstruct matches for [2..500]");
    }
}

/* ========================================================================
 * Josephus problem
 * ======================================================================== */
static int josephus(int n, int k) {
    int pos = 0, i;
    for (i = 2; i <= n; i++) {
        pos = (pos + k) % i;
    }
    return pos;
}

static void test_josephus(void) {
    write_str("[Josephus Problem]\n");
    check(josephus(1, 2) == 0, "J(1,2)==0");
    check(josephus(2, 2) == 0, "J(2,2)==0");
    check(josephus(3, 2) == 2, "J(3,2)==2");
    check(josephus(5, 2) == 2, "J(5,2)==2");
    check(josephus(7, 2) == 6, "J(7,2)==6");
    check(josephus(10, 2) == 4, "J(10,2)==4");
    check(josephus(6, 3) == 0, "J(6,3)==0");
    check(josephus(10, 3) == 3, "J(10,3)==3");
    check(josephus(41, 3) == 30, "J(41,3)==30");

    /* For k=2: J(2^m) = 0 */
    check(josephus(1, 2) == 0, "J(1,2)==0");
    check(josephus(2, 2) == 0, "J(2,2)==0");
    check(josephus(4, 2) == 0, "J(4,2)==0");
    check(josephus(8, 2) == 0, "J(8,2)==0");
    check(josephus(16, 2) == 0, "J(16,2)==0");
    check(josephus(32, 2) == 0, "J(32,2)==0");
    check(josephus(64, 2) == 0, "J(64,2)==0");
}

/* ========================================================================
 * Integer partitions count (using DP)
 * ======================================================================== */
static int partition_count(int n) {
    int dp[201];
    int i, j;
    if (n > 200) return -1;
    memset(dp, 0, sizeof(dp));
    dp[0] = 1;
    for (i = 1; i <= n; i++) {
        for (j = i; j <= n; j++) {
            dp[j] += dp[j - i];
        }
    }
    return dp[n];
}

static void test_partitions(void) {
    write_str("[Integer Partitions]\n");
    check(partition_count(0) == 1, "p(0)==1");
    check(partition_count(1) == 1, "p(1)==1");
    check(partition_count(2) == 2, "p(2)==2");
    check(partition_count(3) == 3, "p(3)==3");
    check(partition_count(4) == 5, "p(4)==5");
    check(partition_count(5) == 7, "p(5)==7");
    check(partition_count(10) == 42, "p(10)==42");
    check(partition_count(20) == 627, "p(20)==627");
    check(partition_count(50) == 204226, "p(50)==204226");
}

/* ========================================================================
 * Modular Fibonacci (Pisano period check)
 * ======================================================================== */
static int fib_mod(int n, int m) {
    int a = 0, b = 1, i, t;
    if (n == 0) return 0;
    for (i = 2; i <= n; i++) {
        t = (a + b) % m;
        a = b;
        b = t;
    }
    return b;
}

static int pisano_period(int m) {
    /* Pisano period: smallest k>0 such that F(k)=0, F(k+1)=1 mod m */
    int a = 0, b = 1, i, t;
    for (i = 1; i <= 6 * m; i++) {
        t = (a + b) % m;
        a = b;
        b = t;
        if (a == 0 && b == 1) return i;
    }
    return -1;
}

static void test_pisano(void) {
    write_str("[Pisano Period]\n");
    check(pisano_period(2) == 3, "pi(2)==3");
    check(pisano_period(3) == 8, "pi(3)==8");
    check(pisano_period(5) == 20, "pi(5)==20");
    check(pisano_period(10) == 60, "pi(10)==60");

    /* Verify period: F(k) mod m == F(k+period) mod m */
    {
        int ok = 1, k;
        int period = pisano_period(7); /* pi(7) = 16 */
        check(period == 16, "pi(7)==16");
        for (k = 0; k < 20; k++) {
            if (fib_mod(k, 7) != fib_mod(k + period, 7)) { ok = 0; break; }
        }
        check(ok, "Fibonacci periodic mod 7");
    }

    /* F(n) mod m for known values */
    check(fib_mod(10, 1000) == 55, "F(10) mod 1000 == 55");
    check(fib_mod(20, 1000) == 765, "F(20) mod 1000 == 765");
}

/* ========================================================================
 * Stern-Brocot / Calkin-Wilf sequence
 * ======================================================================== */
static int stern_brocot(int n) {
    /* Stern's diatomic series: s(0)=0, s(1)=1,
       s(2n)=s(n), s(2n+1)=s(n)+s(n+1) */
    if (n == 0) return 0;
    if (n == 1) return 1;
    if (n % 2 == 0) return stern_brocot(n / 2);
    return stern_brocot(n / 2) + stern_brocot(n / 2 + 1);
}

static void test_stern_brocot(void) {
    /* 0,1,1,2,1,3,2,3,1,4,3,5,2,5,3,4 */
    static const int expected[] = {0,1,1,2,1,3,2,3,1,4,3,5,2,5,3,4};
    int i, ok = 1;
    write_str("[Stern-Brocot]\n");
    for (i = 0; i < 16; i++) {
        if (stern_brocot(i) != expected[i]) { ok = 0; break; }
    }
    check(ok, "Stern-Brocot first 16 terms");

    /* Property: gcd(s(n), s(n+1)) = 1 for n >= 1 */
    ok = 1;
    for (i = 1; i <= 100; i++) {
        if (gcd(stern_brocot(i), stern_brocot(i + 1)) != 1) { ok = 0; break; }
    }
    check(ok, "Stern-Brocot coprime property");
}

/* ========================================================================
 * Continued fraction expansion of rational p/q
 * ======================================================================== */
static void cf_expand(int p, int q, int *cf, int *cflen) {
    *cflen = 0;
    while (q != 0) {
        cf[(*cflen)++] = p / q;
        { int t = q; q = p % q; p = t; }
    }
}

static void cf_to_rational(const int *cf, int cflen, int *pn, int *pd) {
    int n, d, i;
    n = cf[cflen - 1];
    d = 1;
    for (i = cflen - 2; i >= 0; i--) {
        int t = n;
        n = cf[i] * n + d;
        d = t;
    }
    *pn = n;
    *pd = d;
}

static void test_continued_fractions(void) {
    int cf[50], cflen, n, d;
    write_str("[Continued Fractions]\n");

    /* 355/113 = [3; 7, 16] (famous pi approximation) */
    cf_expand(355, 113, cf, &cflen);
    check(cflen == 3, "355/113: 3 terms");
    check(cf[0] == 3 && cf[1] == 7 && cf[2] == 16, "355/113=[3;7,16]");

    cf_to_rational(cf, cflen, &n, &d);
    check(n == 355 && d == 113, "reconstruct 355/113");

    /* 22/7 = [3; 7] */
    cf_expand(22, 7, cf, &cflen);
    check(cflen == 2, "22/7: 2 terms");
    check(cf[0] == 3 && cf[1] == 7, "22/7=[3;7]");

    /* 1/1 = [1] */
    cf_expand(1, 1, cf, &cflen);
    check(cflen == 1 && cf[0] == 1, "1/1=[1]");

    /* 7/3 = [2; 3] */
    cf_expand(7, 3, cf, &cflen);
    check(cf[0] == 2 && cf[1] == 3, "7/3=[2;3]");
    cf_to_rational(cf, cflen, &n, &d);
    check(n == 7 && d == 3, "reconstruct 7/3");

    /* 649/200 = [3; 4, 12, 4] */
    cf_expand(649, 200, cf, &cflen);
    cf_to_rational(cf, cflen, &n, &d);
    check(n == 649 && d == 200, "reconstruct 649/200");
}

/* ========================================================================
 * Ackermann function (small values)
 * ======================================================================== */
static int ackermann(int m, int n) {
    if (m == 0) return n + 1;
    if (n == 0) return ackermann(m - 1, 1);
    return ackermann(m - 1, ackermann(m, n - 1));
}

static void test_ackermann(void) {
    write_str("[Ackermann Function]\n");
    check(ackermann(0, 0) == 1, "A(0,0)==1");
    check(ackermann(0, 5) == 6, "A(0,5)==6");
    check(ackermann(1, 0) == 2, "A(1,0)==2");
    check(ackermann(1, 1) == 3, "A(1,1)==3");
    check(ackermann(1, 5) == 7, "A(1,5)==7");
    check(ackermann(2, 0) == 3, "A(2,0)==3");
    check(ackermann(2, 1) == 5, "A(2,1)==5");
    check(ackermann(2, 3) == 9, "A(2,3)==9");
    check(ackermann(3, 0) == 5, "A(3,0)==5");
    check(ackermann(3, 1) == 13, "A(3,1)==13");
    check(ackermann(3, 2) == 29, "A(3,2)==29");
    check(ackermann(3, 3) == 61, "A(3,3)==61");
    check(ackermann(3, 4) == 125, "A(3,4)==125");
}

/* ========================================================================
 * Gray code conversion
 * ======================================================================== */
static int to_gray(int n) { return n ^ (n >> 1); }
static int from_gray(int g) {
    int n = 0;
    while (g) { n ^= g; g >>= 1; }
    return n;
}

static void test_gray_code(void) {
    int i, ok;
    write_str("[Gray Code]\n");
    check(to_gray(0) == 0, "gray(0)==0");
    check(to_gray(1) == 1, "gray(1)==1");
    check(to_gray(2) == 3, "gray(2)==3");
    check(to_gray(3) == 2, "gray(3)==2");
    check(to_gray(4) == 6, "gray(4)==6");
    check(to_gray(7) == 4, "gray(7)==4");

    /* Round-trip */
    ok = 1;
    for (i = 0; i < 256; i++) {
        if (from_gray(to_gray(i)) != i) { ok = 0; break; }
    }
    check(ok, "gray round-trip [0..255]");

    /* Adjacent gray codes differ by 1 bit */
    ok = 1;
    for (i = 0; i < 255; i++) {
        int diff = to_gray(i) ^ to_gray(i + 1);
        /* diff should be a power of 2 (single bit) */
        if (diff == 0 || (diff & (diff - 1)) != 0) { ok = 0; break; }
    }
    check(ok, "adjacent gray codes differ by 1 bit");
}

/* ========================================================================
 * Bit manipulation utilities
 * ======================================================================== */
static int popcount(unsigned int n) {
    int c = 0;
    while (n) { c++; n &= n - 1; }
    return c;
}

static int clz(unsigned int n) {
    int c = 0;
    if (n == 0) return 32;
    while (!(n & 0x80000000u)) { c++; n <<= 1; }
    return c;
}

static int ctz(unsigned int n) {
    int c = 0;
    if (n == 0) return 32;
    while (!(n & 1)) { c++; n >>= 1; }
    return c;
}

static unsigned int reverse_bits(unsigned int n) {
    unsigned int r = 0;
    int i;
    for (i = 0; i < 32; i++) {
        r = (r << 1) | (n & 1);
        n >>= 1;
    }
    return r;
}

static void test_bit_ops(void) {
    write_str("[Bit Operations]\n");
    check(popcount(0) == 0, "pop(0)==0");
    check(popcount(1) == 1, "pop(1)==1");
    check(popcount(0xFF) == 8, "pop(0xFF)==8");
    check(popcount(0xFFFFFFFF) == 32, "pop(0xFFFFFFFF)==32");
    check(popcount(0xAAAAAAAA) == 16, "pop(0xAAAAAAAA)==16");

    check(clz(1) == 31, "clz(1)==31");
    check(clz(0x80000000) == 0, "clz(0x80000000)==0");
    check(clz(256) == 23, "clz(256)==23");
    check(clz(0) == 32, "clz(0)==32");

    check(ctz(1) == 0, "ctz(1)==0");
    check(ctz(2) == 1, "ctz(2)==1");
    check(ctz(256) == 8, "ctz(256)==8");
    check(ctz(0x80000000) == 31, "ctz(0x80000000)==31");
    check(ctz(0) == 32, "ctz(0)==32");

    check(reverse_bits(1) == 0x80000000u, "rev(1)==0x80000000");
    check(reverse_bits(0x80000000u) == 1, "rev(0x80000000)==1");
    check(reverse_bits(0) == 0, "rev(0)==0");
    check(reverse_bits(0xFFFFFFFF) == 0xFFFFFFFF, "rev(0xFFFFFFFF)==self");

    /* popcount(n) + popcount(~n) == 32 */
    {
        int ok = 1;
        unsigned int vals[] = {0, 1, 42, 255, 1000, 0xDEADBEEF, 0xFFFFFFFF};
        int j;
        for (j = 0; j < 7; j++) {
            if (popcount(vals[j]) + popcount(~vals[j]) != 32) { ok = 0; break; }
        }
        check(ok, "popcount(n)+popcount(~n)==32");
    }
}

/* ========================================================================
 * Modular matrix exponentiation for Fibonacci
 * ======================================================================== */
typedef struct { long long m[2][2]; } Mat2;

static Mat2 mat_mul_mod(Mat2 a, Mat2 b, int mod) {
    Mat2 c;
    int i, j, k;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 2; j++) {
            c.m[i][j] = 0;
            for (k = 0; k < 2; k++) {
                c.m[i][j] = (c.m[i][j] + a.m[i][k] * b.m[k][j]) % mod;
            }
        }
    }
    return c;
}

static Mat2 mat_pow_mod(Mat2 base, int exp, int mod) {
    Mat2 result;
    result.m[0][0] = 1; result.m[0][1] = 0;
    result.m[1][0] = 0; result.m[1][1] = 1; /* identity */
    while (exp > 0) {
        if (exp & 1) result = mat_mul_mod(result, base, mod);
        base = mat_mul_mod(base, base, mod);
        exp >>= 1;
    }
    return result;
}

static int fib_matrix_mod(int n, int mod) {
    Mat2 base;
    Mat2 r;
    if (n <= 0) return 0;
    base.m[0][0] = 1; base.m[0][1] = 1;
    base.m[1][0] = 1; base.m[1][1] = 0;
    r = mat_pow_mod(base, n, mod);
    return (int)r.m[1][0];
}

static void test_fib_matrix_mod(void) {
    write_str("[Fibonacci Matrix Mod]\n");
    check(fib_matrix_mod(10, 1000) == 55, "F(10) mod 1000 == 55");
    check(fib_matrix_mod(20, 10000) == 6765, "F(20) mod 10000 == 6765");
    check(fib_matrix_mod(30, 1000000) == 832040, "F(30) mod 1000000 == 832040");
    check(fib_matrix_mod(50, 1000000) == fib_mod(50, 1000000), "F(50) mod 1M matrix==iter");
    check(fib_matrix_mod(100, 997) == fib_mod(100, 997), "F(100) mod 997 matrix==iter");
    check(fib_matrix_mod(200, 9973) == fib_mod(200, 9973), "F(200) mod 9973 matrix==iter");
    check(fib_matrix_mod(1, 100) == 1, "F(1) mod 100 == 1");
    check(fib_matrix_mod(2, 100) == 1, "F(2) mod 100 == 1");
}

/* ========================================================================
 * Pollard's rho-like trial: check perfect powers
 * ======================================================================== */
static int is_perfect_square(int n) {
    int s;
    if (n < 0) return 0;
    s = isqrt(n);
    return s * s == n;
}

static int is_perfect_cube(int n) {
    int c;
    if (n < 0) { c = icbrt(-n); return c * c * c == -n; }
    c = icbrt(n);
    return c * c * c == n;
}

static int is_perfect_power(int n) {
    int base, power, result;
    if (n <= 1) return 0;
    /* Try each base from 2 upward; for each base try exponents 2,3,... */
    for (base = 2; base * base <= n; base++) {
        result = base * base;
        for (power = 2; result <= n; power++) {
            if (result == n) return 1;
            result = result * base;
        }
    }
    return 0;
}

static void test_perfect_powers(void) {
    write_str("[Perfect Powers]\n");
    check(is_perfect_square(0), "0 is perfect square");
    check(is_perfect_square(1), "1 is perfect square");
    check(is_perfect_square(4), "4 is perfect square");
    check(is_perfect_square(9), "9 is perfect square");
    check(is_perfect_square(144), "144 is perfect square");
    check(!is_perfect_square(2), "2 not perfect square");
    check(!is_perfect_square(3), "3 not perfect square");
    check(!is_perfect_square(5), "5 not perfect square");
    check(!is_perfect_square(143), "143 not perfect square");

    check(is_perfect_cube(0), "0 is perfect cube");
    check(is_perfect_cube(1), "1 is perfect cube");
    check(is_perfect_cube(8), "8 is perfect cube");
    check(is_perfect_cube(27), "27 is perfect cube");
    check(is_perfect_cube(64), "64 is perfect cube");
    check(is_perfect_cube(1000), "1000 is perfect cube");
    check(!is_perfect_cube(2), "2 not perfect cube");
    check(!is_perfect_cube(9), "9 not perfect cube");
    check(!is_perfect_cube(63), "63 not perfect cube");

    check(is_perfect_power(4), "4 is perfect power");
    check(is_perfect_power(8), "8 is perfect power");
    check(is_perfect_power(16), "16 is perfect power");
    check(is_perfect_power(25), "25 is perfect power");
    check(is_perfect_power(27), "27 is perfect power");
    check(is_perfect_power(32), "32 is perfect power (2^5)");
    check(is_perfect_power(64), "64 is perfect power");
    check(is_perfect_power(100), "100 is perfect power");
    check(is_perfect_power(125), "125 is perfect power");
    check(!is_perfect_power(6), "6 not perfect power");
    check(!is_perfect_power(10), "10 not perfect power");
}

/* ========================================================================
 * Legendre symbol (a/p) for odd prime p
 * ======================================================================== */
static int legendre_symbol(int a, int p) {
    int ls;
    a = ((a % p) + p) % p;
    if (a == 0) return 0;
    ls = mod_exp(a, (p - 1) / 2, p);
    return (ls == p - 1) ? -1 : ls;
}

static void test_legendre(void) {
    write_str("[Legendre Symbol]\n");
    /* Quadratic residues mod 7: 1, 2, 4 */
    check(legendre_symbol(1, 7) == 1, "(1/7)==1");
    check(legendre_symbol(2, 7) == 1, "(2/7)==1");
    check(legendre_symbol(3, 7) == -1, "(3/7)==-1");
    check(legendre_symbol(4, 7) == 1, "(4/7)==1");
    check(legendre_symbol(5, 7) == -1, "(5/7)==-1");
    check(legendre_symbol(6, 7) == -1, "(6/7)==-1");
    check(legendre_symbol(0, 7) == 0, "(0/7)==0");

    /* mod 13 */
    check(legendre_symbol(1, 13) == 1, "(1/13)==1");
    check(legendre_symbol(3, 13) == 1, "(3/13)==1");
    check(legendre_symbol(4, 13) == 1, "(4/13)==1");
    check(legendre_symbol(2, 13) == -1, "(2/13)==-1");
    check(legendre_symbol(5, 13) == -1, "(5/13)==-1");

    /* Euler's criterion: a^((p-1)/2) = (a/p) mod p */
    {
        int ok = 1, a;
        for (a = 1; a < 23; a++) {
            int ls = legendre_symbol(a, 23);
            int ec = mod_exp(a, 11, 23); /* (23-1)/2 = 11 */
            int expected = (ec == 22) ? -1 : ec;
            if (ls != expected) { ok = 0; break; }
        }
        check(ok, "Euler criterion for p=23");
    }
}

/* ========================================================================
 * Harmonic numbers (integer approximation * denominator)
 * H(n) = 1 + 1/2 + 1/3 + ... + 1/n, computed as sum of numerators/LCM
 * We compute H(n) * n! / n! approximately via digit sums
 * Actually let's just compute partial harmonic sums * 60060 (LCM of 1..14)
 * ======================================================================== */
static void test_harmonic_approx(void) {
    /* H(n) * n(n+1)...(2n) approximated. Instead, use simpler check:
       Multiply out: H(1)=1, H(2)=3/2, H(3)=11/6, H(4)=25/12 */
    /* We'll verify by computing numerators with common denominators */
    write_str("[Harmonic Numbers]\n");

    /* H(1) = 1/1, H(2) = 3/2, H(3) = 11/6, H(4) = 25/12 */
    /* Verify: 1*12 = 12, (3/2)*12 = 18, (11/6)*12 = 22, (25/12)*12 = 25 */
    {
        int h_num[11], h_den[11], i;
        /* H(n) as fraction: start with 0/1, add 1/k each step */
        h_num[0] = 0; h_den[0] = 1;
        for (i = 1; i <= 10; i++) {
            /* h_num/h_den + 1/i = (h_num*i + h_den) / (h_den*i) */
            int nn = h_num[i-1] * i + h_den[i-1];
            int dd = h_den[i-1] * i;
            int g = gcd(nn, dd);
            h_num[i] = nn / g;
            h_den[i] = dd / g;
        }
        check(h_num[1] == 1 && h_den[1] == 1, "H(1) = 1/1");
        check(h_num[2] == 3 && h_den[2] == 2, "H(2) = 3/2");
        check(h_num[3] == 11 && h_den[3] == 6, "H(3) = 11/6");
        check(h_num[4] == 25 && h_den[4] == 12, "H(4) = 25/12");
        check(h_num[5] == 137 && h_den[5] == 60, "H(5) = 137/60");
        check(h_num[6] == 49 && h_den[6] == 20, "H(6) = 49/20");

        /* H(n) is never an integer for n > 1 (Wolstenholme-adjacent) */
        {
            int ok = 1;
            for (i = 2; i <= 10; i++) {
                if (h_den[i] == 1) { ok = 0; break; }
            }
            check(ok, "H(n) not integer for n=2..10");
        }
    }
}

/* ========================================================================
 * Stirling numbers of the second kind S(n,k)
 * S(n,k) = k*S(n-1,k) + S(n-1,k-1)
 * ======================================================================== */
static int stirling2[16][16];

static void build_stirling2(void) {
    int n, k;
    memset(stirling2, 0, sizeof(stirling2));
    stirling2[0][0] = 1;
    for (n = 1; n <= 15; n++) {
        for (k = 1; k <= n; k++) {
            stirling2[n][k] = k * stirling2[n-1][k] + stirling2[n-1][k-1];
        }
    }
}

static void test_stirling(void) {
    write_str("[Stirling Numbers]\n");
    build_stirling2();

    check(stirling2[0][0] == 1, "S(0,0)==1");
    check(stirling2[1][1] == 1, "S(1,1)==1");
    check(stirling2[2][1] == 1, "S(2,1)==1");
    check(stirling2[2][2] == 1, "S(2,2)==1");
    check(stirling2[3][1] == 1, "S(3,1)==1");
    check(stirling2[3][2] == 3, "S(3,2)==3");
    check(stirling2[3][3] == 1, "S(3,3)==1");
    check(stirling2[4][2] == 7, "S(4,2)==7");
    check(stirling2[5][2] == 15, "S(5,2)==15");
    check(stirling2[5][3] == 25, "S(5,3)==25");
    check(stirling2[5][4] == 10, "S(5,4)==10");
    check(stirling2[5][5] == 1, "S(5,5)==1");
    check(stirling2[10][3] == 9330, "S(10,3)==9330");

    /* Bell number B(n) = sum S(n,k) for k=0..n */
    {
        int bell5 = 0, bell6 = 0, k;
        for (k = 0; k <= 5; k++) bell5 += stirling2[5][k];
        for (k = 0; k <= 6; k++) bell6 += stirling2[6][k];
        check(bell5 == 52, "B(5)==52");
        check(bell6 == 203, "B(6)==203");
    }

    /* S(n,1) = 1 for all n >= 1 */
    {
        int ok = 1, n;
        for (n = 1; n <= 15; n++) {
            if (stirling2[n][1] != 1) { ok = 0; break; }
        }
        check(ok, "S(n,1)==1 for n>=1");
    }

    /* S(n,n) = 1 for all n >= 0 */
    {
        int ok = 1, n;
        for (n = 0; n <= 15; n++) {
            if (stirling2[n][n] != 1) { ok = 0; break; }
        }
        check(ok, "S(n,n)==1 for n>=0");
    }
}

/* ========================================================================
 * Derangements D(n) = (n-1) * (D(n-1) + D(n-2))
 * ======================================================================== */
static int derangement(int n) {
    int d0 = 1, d1 = 0, i, d;
    if (n == 0) return 1;
    if (n == 1) return 0;
    for (i = 2; i <= n; i++) {
        d = (i - 1) * (d1 + d0);
        d0 = d1;
        d1 = d;
    }
    return d1;
}

static void test_derangements(void) {
    write_str("[Derangements]\n");
    check(derangement(0) == 1, "D(0)==1");
    check(derangement(1) == 0, "D(1)==0");
    check(derangement(2) == 1, "D(2)==1");
    check(derangement(3) == 2, "D(3)==2");
    check(derangement(4) == 9, "D(4)==9");
    check(derangement(5) == 44, "D(5)==44");
    check(derangement(6) == 265, "D(6)==265");
    check(derangement(7) == 1854, "D(7)==1854");
    check(derangement(8) == 14833, "D(8)==14833");
    check(derangement(9) == 133496, "D(9)==133496");
    check(derangement(10) == 1334961, "D(10)==1334961");

    /* D(n) = n! * sum(-1)^k / k! for k=0..n, so n!-D(n) gives permutations with fixed points */
    /* Also: D(n)/n! -> 1/e as n grows */
}

/* ========================================================================
 * Moebius function mu(n)
 * ======================================================================== */
static int moebius(int n) {
    int p, count = 0;
    if (n <= 0) return 0;
    if (n == 1) return 1;
    for (p = 2; p * p <= n; p++) {
        if (n % p == 0) {
            n /= p;
            if (n % p == 0) return 0; /* p^2 divides n */
            count++;
        }
    }
    if (n > 1) count++;
    return (count & 1) ? -1 : 1;
}

static void test_moebius(void) {
    write_str("[Moebius Function]\n");
    check(moebius(1) == 1, "mu(1)==1");
    check(moebius(2) == -1, "mu(2)==-1");
    check(moebius(3) == -1, "mu(3)==-1");
    check(moebius(4) == 0, "mu(4)==0 (2^2)");
    check(moebius(5) == -1, "mu(5)==-1");
    check(moebius(6) == 1, "mu(6)==1 (2*3)");
    check(moebius(7) == -1, "mu(7)==-1");
    check(moebius(8) == 0, "mu(8)==0 (2^3)");
    check(moebius(9) == 0, "mu(9)==0 (3^2)");
    check(moebius(10) == 1, "mu(10)==1 (2*5)");
    check(moebius(30) == -1, "mu(30)==-1 (2*3*5)");
    check(moebius(12) == 0, "mu(12)==0");
    check(moebius(105) == -1, "mu(105)==-1 (3*5*7)");
    check(moebius(210) == 1, "mu(210)==1 (2*3*5*7)");

    /* Moebius inversion check: sum mu(d) for d|n = 0 for n>1 */
    {
        int ok = 1, n, d, sum;
        for (n = 2; n <= 50; n++) {
            sum = 0;
            for (d = 1; d <= n; d++) {
                if (n % d == 0) sum += moebius(d);
            }
            if (sum != 0) { ok = 0; break; }
        }
        check(ok, "sum mu(d) for d|n == 0 for n=2..50");
    }
}

/* ========================================================================
 * Integer log base 2
 * ======================================================================== */
static int ilog2(int n) {
    int r = 0;
    if (n <= 0) return -1;
    while (n > 1) { n >>= 1; r++; }
    return r;
}

static void test_ilog2(void) {
    int i;
    write_str("[Integer Log2]\n");
    check(ilog2(1) == 0, "log2(1)==0");
    check(ilog2(2) == 1, "log2(2)==1");
    check(ilog2(3) == 1, "log2(3)==1");
    check(ilog2(4) == 2, "log2(4)==2");
    check(ilog2(7) == 2, "log2(7)==2");
    check(ilog2(8) == 3, "log2(8)==3");
    check(ilog2(16) == 4, "log2(16)==4");
    check(ilog2(1023) == 9, "log2(1023)==9");
    check(ilog2(1024) == 10, "log2(1024)==10");
    check(ilog2(1000000) == 19, "log2(1000000)==19");

    /* 2^ilog2(n) <= n < 2^(ilog2(n)+1) */
    {
        int ok = 1;
        for (i = 1; i <= 10000; i++) {
            int l = ilog2(i);
            if ((1 << l) > i || (1 << (l + 1)) <= i) { ok = 0; break; }
        }
        check(ok, "ilog2 bounds for [1..10000]");
    }
}

/* ========================================================================
 * Additional comprehensive tests
 * ======================================================================== */
static void test_cross_algorithm(void) {
    int i;
    write_str("[Cross-Algorithm Checks]\n");

    /* For every prime p < 100, phi(p) == p-1 */
    {
        int ok = 1;
        for (i = 2; i < 100; i++) {
            if (sieve[i]) {
                if (euler_totient(i) != i - 1) { ok = 0; break; }
            }
        }
        check(ok, "phi(p)==p-1 for primes < 100");
    }

    /* GCD * LCM == a * b for coprime check */
    {
        int ok = 1;
        int a, b;
        for (a = 1; a <= 50; a++) {
            for (b = 1; b <= 50; b++) {
                if ((long long)gcd(a, b) * lcm(a, b) != (long long)a * b) {
                    ok = 0; break;
                }
            }
            if (!ok) break;
        }
        check(ok, "gcd*lcm == a*b for [1..50]x[1..50]");
    }

    /* Modular inverse self-consistency: a * inv(a) = 1 mod p */
    {
        int ok = 1;
        for (i = 0; i < 25; i++) {
            int p = primes[i]; /* first 25 primes */
            int a;
            for (a = 1; a < p; a++) {
                int inv = mod_inverse(a, p);
                if (inv < 0 || (a * inv) % p != 1) { ok = 0; break; }
            }
            if (!ok) break;
        }
        check(ok, "mod_inverse consistency for first 25 primes");
    }

    /* Catalan(n) = C(2n,n)/(n+1) matches Pascal */
    {
        int ok = 1;
        for (i = 0; i <= 10; i++) {
            int cat = catalan(i);
            int b2n_n = binom(2 * i, i);
            if (cat != b2n_n / (i + 1)) { ok = 0; break; }
        }
        check(ok, "Catalan == C(2n,n)/(n+1) for n<=10");
    }

    /* isqrt consistency: isqrt(n)^2 <= n < (isqrt(n)+1)^2 */
    {
        int ok = 1;
        for (i = 0; i <= 10000; i++) {
            int s = isqrt(i);
            if (s * s > i || (s + 1) * (s + 1) <= i) { ok = 0; break; }
        }
        check(ok, "isqrt bounds for [0..10000]");
    }

    /* icbrt consistency: icbrt(n)^3 <= n < (icbrt(n)+1)^3 */
    {
        int ok = 1;
        for (i = 0; i <= 10000; i++) {
            int c = icbrt(i);
            if (c * c * c > i || (c + 1) * (c + 1) * (c + 1) <= i) { ok = 0; break; }
        }
        check(ok, "icbrt bounds for [0..10000]");
    }
}

/* ========================================================================
 * main
 * ======================================================================== */
int main(void) {
    g_errs = 0;
    init_io();

    write_str("=== victim_math: Number Theory Stress Test ===\n\n");

    test_gcd();
    test_ext_gcd();
    test_lcm();
    test_mod_exp();
    test_mod_inverse();
    test_sieve();
    test_trial_division();
    test_miller_rabin();
    test_isqrt();
    test_euler_totient();
    test_crt();
    test_fibonacci();
    test_catalan();
    test_binomial();
    test_collatz();
    test_horner();
    test_icbrt();
    test_bignum();
    test_divisor_functions();
    test_linear_congruence();
    test_power_sum();
    test_digital_root();
    test_factorization();
    test_josephus();
    test_partitions();
    test_pisano();
    test_stern_brocot();
    test_continued_fractions();
    test_ackermann();
    test_gray_code();
    test_bit_ops();
    test_fib_matrix_mod();
    test_perfect_powers();
    test_legendre();
    test_harmonic_approx();
    test_stirling();
    test_derangements();
    test_moebius();
    test_ilog2();
    test_cross_algorithm();

    write_str("\nTotal errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
