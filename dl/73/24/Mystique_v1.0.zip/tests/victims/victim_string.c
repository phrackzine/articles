/*
 * victim_string.c -- String algorithms stress test (Windows x86-32 MSVC)
 * Build: cl /nologo /O1 victim_string.c /Fe:victim_string.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * Deterministic output. All algorithms fully implemented.
 */
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* =========================================================================
 * 1. Naive string search (brute force)
 * Returns index of first occurrence, or -1
 * ========================================================================= */

static int naive_search(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int i, j;
    if (plen == 0) return 0;
    for (i = 0; i <= tlen - plen; i++) {
        for (j = 0; j < plen; j++) {
            if (text[i + j] != pat[j]) break;
        }
        if (j == plen) return i;
    }
    return -1;
}

/* Count all occurrences */
static int naive_count(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int i, j, count = 0;
    if (plen == 0) return 0;
    for (i = 0; i <= tlen - plen; i++) {
        for (j = 0; j < plen; j++) {
            if (text[i + j] != pat[j]) break;
        }
        if (j == plen) count++;
    }
    return count;
}

/* =========================================================================
 * 2. KMP (Knuth-Morris-Pratt)
 * ========================================================================= */

static void kmp_failure(const char* pat, int plen, int* fail) {
    int i, j;
    fail[0] = 0;
    j = 0;
    for (i = 1; i < plen; i++) {
        while (j > 0 && pat[i] != pat[j]) j = fail[j - 1];
        if (pat[i] == pat[j]) j++;
        fail[i] = j;
    }
}

static int kmp_search(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int fail[256];
    int i, j;
    if (plen == 0) return 0;
    if (plen > 256) return -1;
    kmp_failure(pat, plen, fail);
    j = 0;
    for (i = 0; i < tlen; i++) {
        while (j > 0 && text[i] != pat[j]) j = fail[j - 1];
        if (text[i] == pat[j]) j++;
        if (j == plen) return i - plen + 1;
    }
    return -1;
}

static int kmp_count(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int fail[256];
    int i, j, count = 0;
    if (plen == 0) return 0;
    if (plen > 256) return 0;
    kmp_failure(pat, plen, fail);
    j = 0;
    for (i = 0; i < tlen; i++) {
        while (j > 0 && text[i] != pat[j]) j = fail[j - 1];
        if (text[i] == pat[j]) j++;
        if (j == plen) {
            count++;
            j = fail[j - 1];
        }
    }
    return count;
}

/* =========================================================================
 * 3. Boyer-Moore (simplified bad character rule)
 * ========================================================================= */

static int bm_search(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int bad[256];
    int i, j, shift;
    if (plen == 0) return 0;
    /* Build bad character table */
    for (i = 0; i < 256; i++) bad[i] = plen;
    for (i = 0; i < plen - 1; i++) bad[(unsigned char)pat[i]] = plen - 1 - i;
    i = plen - 1;
    while (i < tlen) {
        j = plen - 1;
        while (j >= 0 && text[i] == pat[j]) { i--; j--; }
        if (j < 0) return i + 1;
        shift = bad[(unsigned char)text[i]];
        if (shift < 1) shift = 1;
        i += shift;
        if (i < plen - 1) i = plen - 1; /* ensure forward progress on edge */
    }
    return -1;
}

/* =========================================================================
 * 4. Rabin-Karp (rolling hash)
 * ========================================================================= */

#define RK_BASE 256
#define RK_MOD 101

static int rk_search(const char* text, const char* pat) {
    int tlen = (int)strlen(text);
    int plen = (int)strlen(pat);
    int phash = 0, thash = 0;
    int h = 1;
    int i, j;
    if (plen == 0) return 0;
    if (plen > tlen) return -1;
    /* h = BASE^(plen-1) % MOD */
    for (i = 0; i < plen - 1; i++) h = (h * RK_BASE) % RK_MOD;
    /* Initial hashes */
    for (i = 0; i < plen; i++) {
        phash = (phash * RK_BASE + (unsigned char)pat[i]) % RK_MOD;
        thash = (thash * RK_BASE + (unsigned char)text[i]) % RK_MOD;
    }
    for (i = 0; i <= tlen - plen; i++) {
        if (phash == thash) {
            /* Verify */
            for (j = 0; j < plen; j++) {
                if (text[i + j] != pat[j]) break;
            }
            if (j == plen) return i;
        }
        if (i < tlen - plen) {
            thash = (thash - (unsigned char)text[i] * h) * RK_BASE + (unsigned char)text[i + plen];
            thash = thash % RK_MOD;
            if (thash < 0) thash += RK_MOD;
        }
    }
    return -1;
}

/* =========================================================================
 * 5. Edit distance (Levenshtein, full DP table)
 * ========================================================================= */

static int edit_distance(const char* s1, const char* s2) {
    int len1 = (int)strlen(s1);
    int len2 = (int)strlen(s2);
    int* dp;
    int i, j, sub_cost, result;
    int idx;
    dp = (int*)malloc((len1 + 1) * (len2 + 1) * sizeof(int));
    for (i = 0; i <= len1; i++) dp[i * (len2 + 1)] = i;
    for (j = 0; j <= len2; j++) dp[j] = j;
    for (i = 1; i <= len1; i++) {
        for (j = 1; j <= len2; j++) {
            sub_cost = (s1[i - 1] == s2[j - 1]) ? 0 : 1;
            idx = i * (len2 + 1) + j;
            dp[idx] = dp[(i - 1) * (len2 + 1) + j] + 1; /* delete */
            if (dp[i * (len2 + 1) + (j - 1)] + 1 < dp[idx])
                dp[idx] = dp[i * (len2 + 1) + (j - 1)] + 1; /* insert */
            if (dp[(i - 1) * (len2 + 1) + (j - 1)] + sub_cost < dp[idx])
                dp[idx] = dp[(i - 1) * (len2 + 1) + (j - 1)] + sub_cost; /* replace */
        }
    }
    result = dp[len1 * (len2 + 1) + len2];
    free(dp);
    return result;
}

/* =========================================================================
 * 6. Longest Common Subsequence (LCS, full DP)
 * Returns length; optionally fills result buffer
 * ========================================================================= */

static int lcs_length(const char* s1, const char* s2) {
    int len1 = (int)strlen(s1);
    int len2 = (int)strlen(s2);
    int* dp;
    int i, j, result;
    dp = (int*)malloc((len1 + 1) * (len2 + 1) * sizeof(int));
    for (i = 0; i <= len1; i++) dp[i * (len2 + 1)] = 0;
    for (j = 0; j <= len2; j++) dp[j] = 0;
    for (i = 1; i <= len1; i++) {
        for (j = 1; j <= len2; j++) {
            if (s1[i - 1] == s2[j - 1])
                dp[i * (len2 + 1) + j] = dp[(i - 1) * (len2 + 1) + (j - 1)] + 1;
            else {
                int a = dp[(i - 1) * (len2 + 1) + j];
                int b = dp[i * (len2 + 1) + (j - 1)];
                dp[i * (len2 + 1) + j] = (a > b) ? a : b;
            }
        }
    }
    result = dp[len1 * (len2 + 1) + len2];
    free(dp);
    return result;
}

/* Reconstruct LCS string */
static void lcs_string(const char* s1, const char* s2, char* out, int outsz) {
    int len1 = (int)strlen(s1);
    int len2 = (int)strlen(s2);
    int* dp;
    int i, j, idx;
    dp = (int*)malloc((len1 + 1) * (len2 + 1) * sizeof(int));
    for (i = 0; i <= len1; i++) dp[i * (len2 + 1)] = 0;
    for (j = 0; j <= len2; j++) dp[j] = 0;
    for (i = 1; i <= len1; i++) {
        for (j = 1; j <= len2; j++) {
            if (s1[i - 1] == s2[j - 1])
                dp[i * (len2 + 1) + j] = dp[(i - 1) * (len2 + 1) + (j - 1)] + 1;
            else {
                int a = dp[(i - 1) * (len2 + 1) + j];
                int b = dp[i * (len2 + 1) + (j - 1)];
                dp[i * (len2 + 1) + j] = (a > b) ? a : b;
            }
        }
    }
    /* Backtrack */
    idx = dp[len1 * (len2 + 1) + len2];
    if (idx >= outsz) idx = outsz - 1;
    out[idx] = '\0';
    i = len1; j = len2;
    while (i > 0 && j > 0 && idx > 0) {
        if (s1[i - 1] == s2[j - 1]) {
            idx--;
            out[idx] = s1[i - 1];
            i--; j--;
        } else if (dp[(i - 1) * (len2 + 1) + j] > dp[i * (len2 + 1) + (j - 1)]) {
            i--;
        } else {
            j--;
        }
    }
    free(dp);
}

/* =========================================================================
 * 7. Longest Common Substring
 * ========================================================================= */

static int longest_common_substring(const char* s1, const char* s2, char* out, int outsz) {
    int len1 = (int)strlen(s1);
    int len2 = (int)strlen(s2);
    int* dp;
    int i, j, maxlen = 0, maxend = 0;
    dp = (int*)calloc((len1 + 1) * (len2 + 1), sizeof(int));
    for (i = 1; i <= len1; i++) {
        for (j = 1; j <= len2; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i * (len2 + 1) + j] = dp[(i - 1) * (len2 + 1) + (j - 1)] + 1;
                if (dp[i * (len2 + 1) + j] > maxlen) {
                    maxlen = dp[i * (len2 + 1) + j];
                    maxend = i;
                }
            }
        }
    }
    if (out && outsz > 0) {
        int copylen = maxlen;
        if (copylen >= outsz) copylen = outsz - 1;
        for (i = 0; i < copylen; i++) out[i] = s1[maxend - maxlen + i];
        out[copylen] = '\0';
    }
    free(dp);
    return maxlen;
}

/* =========================================================================
 * 8. String reversal
 * ========================================================================= */

static void str_reverse(char* s) {
    int len = (int)strlen(s);
    int i, j;
    char tmp;
    for (i = 0, j = len - 1; i < j; i++, j--) {
        tmp = s[i]; s[i] = s[j]; s[j] = tmp;
    }
}

/* =========================================================================
 * 9. String rotation
 * ========================================================================= */

/* Rotate left by k positions */
static void str_rotate_left(char* s, int k) {
    int len = (int)strlen(s);
    char* tmp;
    int i;
    if (len == 0) return;
    k = k % len;
    if (k < 0) k += len;
    if (k == 0) return;
    tmp = (char*)malloc(len + 1);
    for (i = 0; i < len; i++) tmp[i] = s[(i + k) % len];
    tmp[len] = '\0';
    memcpy(s, tmp, len + 1);
    free(tmp);
}

/* Check if s2 is a rotation of s1 */
static int is_rotation(const char* s1, const char* s2) {
    int len1 = (int)strlen(s1);
    int len2 = (int)strlen(s2);
    char* doubled;
    int result;
    if (len1 != len2) return 0;
    if (len1 == 0) return 1;
    doubled = (char*)malloc(2 * len1 + 1);
    memcpy(doubled, s1, len1);
    memcpy(doubled + len1, s1, len1);
    doubled[2 * len1] = '\0';
    result = (naive_search(doubled, s2) >= 0) ? 1 : 0;
    free(doubled);
    return result;
}

/* =========================================================================
 * 10. Run-length encoding/decoding
 * ========================================================================= */

static void rle_encode(const char* input, char* output, int outsz) {
    int ilen = (int)strlen(input);
    int i, count, oi = 0;
    char buf[16];
    int bi, n;
    i = 0;
    while (i < ilen && oi < outsz - 1) {
        count = 1;
        while (i + count < ilen && input[i + count] == input[i]) count++;
        /* Write count then char */
        n = count;
        bi = 15; buf[bi] = '\0';
        if (n == 0) { bi--; buf[bi] = '0'; }
        else { while (n > 0) { bi--; buf[bi] = (char)((n % 10) + '0'); n /= 10; } }
        while (buf[bi] && oi < outsz - 1) output[oi++] = buf[bi++];
        if (oi < outsz - 1) output[oi++] = input[i];
        i += count;
    }
    output[oi] = '\0';
}

static void rle_decode(const char* input, char* output, int outsz) {
    int ilen = (int)strlen(input);
    int i = 0, oi = 0, count, j;
    char ch;
    while (i < ilen && oi < outsz - 1) {
        /* Read number */
        count = 0;
        while (i < ilen && input[i] >= '0' && input[i] <= '9') {
            count = count * 10 + (input[i] - '0');
            i++;
        }
        if (i < ilen) {
            ch = input[i]; i++;
            for (j = 0; j < count && oi < outsz - 1; j++) output[oi++] = ch;
        }
    }
    output[oi] = '\0';
}

/* =========================================================================
 * 11. Simple regex-like matching (supports . and * only)
 * . matches any single character
 * * matches zero or more of the preceding character
 * ========================================================================= */

static int regex_match(const char* text, const char* pat) {
    /* Recursive implementation */
    if (*pat == '\0') return (*text == '\0') ? 1 : 0;
    /* Check if next char is * */
    if (*(pat + 1) == '*') {
        /* Try matching zero of current */
        if (regex_match(text, pat + 2)) return 1;
        /* Try matching one or more */
        while (*text != '\0' && (*pat == '.' || *text == *pat)) {
            text++;
            if (regex_match(text, pat + 2)) return 1;
        }
        return 0;
    }
    if (*text == '\0') return 0;
    if (*pat == '.' || *pat == *text) return regex_match(text + 1, pat + 1);
    return 0;
}

/* =========================================================================
 * 12. Palindrome check
 * ========================================================================= */

static int is_palindrome(const char* s) {
    int len = (int)strlen(s);
    int i, j;
    for (i = 0, j = len - 1; i < j; i++, j--) {
        if (s[i] != s[j]) return 0;
    }
    return 1;
}

/* Longest palindromic substring length */
static int longest_palindrome(const char* s) {
    int len = (int)strlen(s);
    int i, j, maxlen = 1;
    int lo, hi, curlen;
    if (len == 0) return 0;
    for (i = 0; i < len; i++) {
        /* Odd length */
        lo = i; hi = i;
        while (lo >= 0 && hi < len && s[lo] == s[hi]) { lo--; hi++; }
        curlen = hi - lo - 1;
        if (curlen > maxlen) maxlen = curlen;
        /* Even length */
        lo = i; hi = i + 1;
        while (lo >= 0 && hi < len && s[lo] == s[hi]) { lo--; hi++; }
        curlen = hi - lo - 1;
        if (curlen > maxlen) maxlen = curlen;
    }
    return maxlen;
}

/* =========================================================================
 * 13. Anagram check (frequency counting)
 * ========================================================================= */

static int are_anagrams(const char* s1, const char* s2) {
    int freq[256];
    int i;
    if (strlen(s1) != strlen(s2)) return 0;
    memset(freq, 0, sizeof(freq));
    for (i = 0; s1[i]; i++) freq[(unsigned char)s1[i]]++;
    for (i = 0; s2[i]; i++) freq[(unsigned char)s2[i]]--;
    for (i = 0; i < 256; i++) if (freq[i] != 0) return 0;
    return 1;
}

/* =========================================================================
 * 14. Caesar cipher encode/decode
 * ========================================================================= */

static void caesar_encode(const char* input, char* output, int shift) {
    int i;
    for (i = 0; input[i]; i++) {
        if (input[i] >= 'A' && input[i] <= 'Z')
            output[i] = (char)('A' + (input[i] - 'A' + shift) % 26);
        else if (input[i] >= 'a' && input[i] <= 'z')
            output[i] = (char)('a' + (input[i] - 'a' + shift) % 26);
        else
            output[i] = input[i];
    }
    output[i] = '\0';
}

static void caesar_decode(const char* input, char* output, int shift) {
    caesar_encode(input, output, 26 - (shift % 26));
}

/* =========================================================================
 * 15. ROT13
 * ========================================================================= */

static void rot13(const char* input, char* output) {
    caesar_encode(input, output, 13);
}

/* =========================================================================
 * 16. Base64 encode/decode
 * ========================================================================= */

static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void base64_encode(const unsigned char* input, int inlen, char* output, int outsz) {
    int i, oi = 0;
    unsigned int val;
    int pad;
    for (i = 0; i < inlen && oi < outsz - 4; i += 3) {
        val = ((unsigned int)input[i]) << 16;
        if (i + 1 < inlen) val |= ((unsigned int)input[i + 1]) << 8;
        if (i + 2 < inlen) val |= ((unsigned int)input[i + 2]);
        output[oi++] = b64_table[(val >> 18) & 0x3F];
        output[oi++] = b64_table[(val >> 12) & 0x3F];
        if (i + 1 < inlen)
            output[oi++] = b64_table[(val >> 6) & 0x3F];
        else
            output[oi++] = '=';
        if (i + 2 < inlen)
            output[oi++] = b64_table[val & 0x3F];
        else
            output[oi++] = '=';
    }
    output[oi] = '\0';
}

static int b64_decode_char(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static int base64_decode(const char* input, unsigned char* output, int outsz) {
    int ilen = (int)strlen(input);
    int i, oi = 0;
    unsigned int val;
    int v0, v1, v2, v3;
    for (i = 0; i < ilen && oi < outsz; i += 4) {
        v0 = b64_decode_char(input[i]);
        v1 = (i + 1 < ilen) ? b64_decode_char(input[i + 1]) : 0;
        v2 = (i + 2 < ilen && input[i + 2] != '=') ? b64_decode_char(input[i + 2]) : -1;
        v3 = (i + 3 < ilen && input[i + 3] != '=') ? b64_decode_char(input[i + 3]) : -1;
        if (v0 < 0 || v1 < 0) break;
        val = ((unsigned int)v0 << 18) | ((unsigned int)v1 << 12);
        if (v2 >= 0) val |= ((unsigned int)v2 << 6);
        if (v3 >= 0) val |= (unsigned int)v3;
        if (oi < outsz) output[oi++] = (unsigned char)((val >> 16) & 0xFF);
        if (v2 >= 0 && oi < outsz) output[oi++] = (unsigned char)((val >> 8) & 0xFF);
        if (v3 >= 0 && oi < outsz) output[oi++] = (unsigned char)(val & 0xFF);
    }
    if (oi < outsz) output[oi] = '\0';
    return oi;
}

/* =========================================================================
 * 17. Trie insert/search
 * ========================================================================= */

#define TRIE_CHILDREN 26

typedef struct TrieNode {
    struct TrieNode* children[TRIE_CHILDREN];
    int is_end;
} TrieNode;

static TrieNode* trie_create_node(void) {
    TrieNode* n = (TrieNode*)malloc(sizeof(TrieNode));
    int i;
    for (i = 0; i < TRIE_CHILDREN; i++) n->children[i] = NULL;
    n->is_end = 0;
    return n;
}

static void trie_insert(TrieNode* root, const char* word) {
    TrieNode* cur = root;
    int i, idx;
    for (i = 0; word[i]; i++) {
        idx = word[i] - 'a';
        if (idx < 0 || idx >= TRIE_CHILDREN) continue;
        if (!cur->children[idx]) cur->children[idx] = trie_create_node();
        cur = cur->children[idx];
    }
    cur->is_end = 1;
}

static int trie_search(TrieNode* root, const char* word) {
    TrieNode* cur = root;
    int i, idx;
    for (i = 0; word[i]; i++) {
        idx = word[i] - 'a';
        if (idx < 0 || idx >= TRIE_CHILDREN) return 0;
        if (!cur->children[idx]) return 0;
        cur = cur->children[idx];
    }
    return cur->is_end;
}

static int trie_starts_with(TrieNode* root, const char* prefix) {
    TrieNode* cur = root;
    int i, idx;
    for (i = 0; prefix[i]; i++) {
        idx = prefix[i] - 'a';
        if (idx < 0 || idx >= TRIE_CHILDREN) return 0;
        if (!cur->children[idx]) return 0;
        cur = cur->children[idx];
    }
    return 1;
}

static void trie_free(TrieNode* node) {
    int i;
    if (!node) return;
    for (i = 0; i < TRIE_CHILDREN; i++) trie_free(node->children[i]);
    free(node);
}

/* Count words in trie */
static int trie_count_words(TrieNode* node) {
    int i, count = 0;
    if (!node) return 0;
    if (node->is_end) count = 1;
    for (i = 0; i < TRIE_CHILDREN; i++) count += trie_count_words(node->children[i]);
    return count;
}

/* =========================================================================
 *  TEST SECTIONS
 * ========================================================================= */

/* --- Test 1: Naive search --- */
static void test_naive_search(void) {
    write_str("[test_naive_search]\n");
    check(naive_search("hello world", "world") == 6, "naive find 'world'");
    check(naive_search("hello world", "hello") == 0, "naive find 'hello'");
    check(naive_search("hello world", "xyz") == -1, "naive not found");
    check(naive_search("aaaaa", "aa") == 0, "naive overlap first");
    check(naive_search("abcabc", "abc") == 0, "naive repeated first");
    check(naive_search("", "abc") == -1, "naive empty text");
    check(naive_search("abc", "") == 0, "naive empty pattern");
    check(naive_search("a", "a") == 0, "naive single match");
    check(naive_search("a", "b") == -1, "naive single no match");
    check(naive_count("aaaa", "aa") == 3, "naive count overlapping 'aa' in 'aaaa'");
    check(naive_count("abababab", "ab") == 4, "naive count 'ab' in 'abababab'");
    check(naive_count("hello", "xyz") == 0, "naive count zero");
}

/* --- Test 2: KMP search --- */
static void test_kmp_search(void) {
    write_str("[test_kmp_search]\n");
    check(kmp_search("hello world", "world") == 6, "kmp find 'world'");
    check(kmp_search("hello world", "hello") == 0, "kmp find 'hello'");
    check(kmp_search("hello world", "xyz") == -1, "kmp not found");
    check(kmp_search("ababababc", "ababc") == 4, "kmp partial match");
    check(kmp_search("aaaaab", "aaab") == 2, "kmp repeated prefix");
    check(kmp_search("", "abc") == -1, "kmp empty text");
    check(kmp_search("abc", "") == 0, "kmp empty pattern");
    check(kmp_count("aaaa", "aa") == 3, "kmp count overlap");
    check(kmp_count("abcabcabc", "abc") == 3, "kmp count 3");
    check(kmp_count("aaa", "b") == 0, "kmp count zero");
    /* KMP failure function test: pattern "aabaaab" */
    {
        int fail[7];
        kmp_failure("aabaaab", 7, fail);
        check(fail[0] == 0, "kmp fail[0]=0");
        check(fail[1] == 1, "kmp fail[1]=1");
        check(fail[2] == 0, "kmp fail[2]=0");
        check(fail[3] == 1, "kmp fail[3]=1");
        check(fail[4] == 2, "kmp fail[4]=2");
        check(fail[5] == 2, "kmp fail[5]=2");
        check(fail[6] == 3, "kmp fail[6]=3");
    }
}

/* --- Test 3: Boyer-Moore search --- */
static void test_bm_search(void) {
    write_str("[test_bm_search]\n");
    check(bm_search("hello world", "world") == 6, "bm find 'world'");
    check(bm_search("hello world", "hello") == 0, "bm find 'hello'");
    check(bm_search("hello world", "xyz") == -1, "bm not found");
    check(bm_search("abcdefgh", "efg") == 4, "bm mid match");
    check(bm_search("a", "a") == 0, "bm single char match");
    check(bm_search("a", "b") == -1, "bm single char no match");
    check(bm_search("abc", "") == 0, "bm empty pattern");
    check(bm_search("the quick brown fox", "fox") == 16, "bm find 'fox'");
    check(bm_search("abcabc", "cab") == 2, "bm find 'cab'");
}

/* --- Test 4: Rabin-Karp search --- */
static void test_rk_search(void) {
    write_str("[test_rk_search]\n");
    check(rk_search("hello world", "world") == 6, "rk find 'world'");
    check(rk_search("hello world", "hello") == 0, "rk find 'hello'");
    check(rk_search("hello world", "xyz") == -1, "rk not found");
    check(rk_search("ababababc", "ababc") == 4, "rk partial");
    check(rk_search("", "abc") == -1, "rk empty text");
    check(rk_search("abc", "") == 0, "rk empty pattern");
    check(rk_search("the quick brown fox", "brown") == 10, "rk find 'brown'");
    check(rk_search("aaa", "a") == 0, "rk first of many");
}

/* --- Test 5: All search algorithms agree --- */
static void test_search_agreement(void) {
    const char* texts[] = {
        "the quick brown fox jumps over the lazy dog",
        "aaaaaaaaaa",
        "abcdefghijklmnopqrstuvwxyz",
        "ababababababab",
        "hello"
    };
    const char* pats[] = {
        "fox", "aaa", "xyz", "abab", "lo", "nothere", "the", "a", "hello", "z"
    };
    int ti, pi;
    write_str("[test_search_agreement]\n");
    for (ti = 0; ti < 5; ti++) {
        for (pi = 0; pi < 10; pi++) {
            int n = naive_search(texts[ti], pats[pi]);
            int k = kmp_search(texts[ti], pats[pi]);
            int b = bm_search(texts[ti], pats[pi]);
            int r = rk_search(texts[ti], pats[pi]);
            /* All should agree */
            check(n == k, "agree naive==kmp");
            check(n == b, "agree naive==bm");
            check(n == r, "agree naive==rk");
        }
    }
}

/* --- Test 6: Edit distance --- */
static void test_edit_distance(void) {
    write_str("[test_edit_distance]\n");
    check(edit_distance("kitten", "sitting") == 3, "ed kitten->sitting=3");
    check(edit_distance("", "") == 0, "ed empty->empty=0");
    check(edit_distance("abc", "") == 3, "ed abc->empty=3");
    check(edit_distance("", "abc") == 3, "ed empty->abc=3");
    check(edit_distance("abc", "abc") == 0, "ed same=0");
    check(edit_distance("abc", "axc") == 1, "ed 1 substitution");
    check(edit_distance("abc", "abcd") == 1, "ed 1 insertion");
    check(edit_distance("abcd", "abc") == 1, "ed 1 deletion");
    check(edit_distance("saturday", "sunday") == 3, "ed saturday->sunday=3");
    check(edit_distance("intention", "execution") == 5, "ed intention->execution=5");
    /* Symmetric */
    check(edit_distance("abc", "xyz") == edit_distance("xyz", "abc"), "ed symmetric");
    /* Triangle inequality: d(a,c) <= d(a,b) + d(b,c) */
    {
        int dab = edit_distance("abc", "def");
        int dbc = edit_distance("def", "ghi");
        int dac = edit_distance("abc", "ghi");
        check(dac <= dab + dbc, "ed triangle inequality");
    }
}

/* --- Test 7: LCS --- */
static void test_lcs(void) {
    char buf[64];
    write_str("[test_lcs]\n");
    check(lcs_length("ABCBDAB", "BDCAB") == 4, "lcs ABCBDAB,BDCAB=4");
    check(lcs_length("AGGTAB", "GXTXAYB") == 4, "lcs AGGTAB,GXTXAYB=4");
    check(lcs_length("", "abc") == 0, "lcs empty,abc=0");
    check(lcs_length("abc", "") == 0, "lcs abc,empty=0");
    check(lcs_length("abc", "abc") == 3, "lcs same=3");
    check(lcs_length("abc", "xyz") == 0, "lcs disjoint=0");
    check(lcs_length("aaa", "aa") == 2, "lcs aaa,aa=2");

    /* Reconstruct LCS string */
    lcs_string("ABCBDAB", "BDCAB", buf, 64);
    check(strcmp(buf, "BCAB") == 0 || strcmp(buf, "BDAB") == 0, "lcs string BCAB or BDAB");

    lcs_string("abc", "abc", buf, 64);
    check(strcmp(buf, "abc") == 0, "lcs string same");
}

/* --- Test 8: Longest common substring --- */
static void test_lc_substring(void) {
    char buf[64];
    int len;
    write_str("[test_lc_substring]\n");

    len = longest_common_substring("abcdef", "zbcdf", buf, 64);
    check(len == 3, "lcsub abcdef,zbcdf=3");
    check(strcmp(buf, "bcd") == 0, "lcsub string=bcd");

    len = longest_common_substring("abc", "xyz", buf, 64);
    check(len == 0, "lcsub disjoint=0");

    len = longest_common_substring("abc", "abc", buf, 64);
    check(len == 3, "lcsub same=3");
    check(strcmp(buf, "abc") == 0, "lcsub string same");

    len = longest_common_substring("", "abc", buf, 64);
    check(len == 0, "lcsub empty=0");

    len = longest_common_substring("xyzabcxyz", "123abc456", buf, 64);
    check(len == 3, "lcsub middle=3");
    check(strcmp(buf, "abc") == 0, "lcsub middle string");

    len = longest_common_substring("aabaa", "aab", buf, 64);
    check(len == 3, "lcsub aabaa,aab=3");
}

/* --- Test 9: String reversal --- */
static void test_reversal(void) {
    char buf[64];
    write_str("[test_reversal]\n");

    strcpy(buf, "hello");
    str_reverse(buf);
    check(strcmp(buf, "olleh") == 0, "reverse hello");

    strcpy(buf, "a");
    str_reverse(buf);
    check(strcmp(buf, "a") == 0, "reverse single");

    strcpy(buf, "");
    str_reverse(buf);
    check(strcmp(buf, "") == 0, "reverse empty");

    strcpy(buf, "ab");
    str_reverse(buf);
    check(strcmp(buf, "ba") == 0, "reverse pair");

    strcpy(buf, "abcde");
    str_reverse(buf);
    check(strcmp(buf, "edcba") == 0, "reverse odd");

    strcpy(buf, "abcdef");
    str_reverse(buf);
    check(strcmp(buf, "fedcba") == 0, "reverse even");

    /* Double reverse = original */
    strcpy(buf, "testing");
    str_reverse(buf);
    str_reverse(buf);
    check(strcmp(buf, "testing") == 0, "double reverse");
}

/* --- Test 10: String rotation --- */
static void test_rotation(void) {
    char buf[64];
    write_str("[test_rotation]\n");

    strcpy(buf, "abcde");
    str_rotate_left(buf, 2);
    check(strcmp(buf, "cdeab") == 0, "rotate left 2");

    strcpy(buf, "abcde");
    str_rotate_left(buf, 0);
    check(strcmp(buf, "abcde") == 0, "rotate left 0");

    strcpy(buf, "abcde");
    str_rotate_left(buf, 5);
    check(strcmp(buf, "abcde") == 0, "rotate left full");

    strcpy(buf, "abcde");
    str_rotate_left(buf, 1);
    check(strcmp(buf, "bcdea") == 0, "rotate left 1");

    check(is_rotation("abcde", "cdeab") == 1, "is rotation cdeab");
    check(is_rotation("abcde", "abcde") == 1, "is rotation self");
    check(is_rotation("abcde", "abced") == 0, "not rotation");
    check(is_rotation("abc", "ab") == 0, "diff len not rotation");
    check(is_rotation("", "") == 1, "empty rotation");
}

/* --- Test 11: RLE encode/decode --- */
static void test_rle(void) {
    char enc[256], dec[256];
    write_str("[test_rle]\n");

    rle_encode("aaabbc", enc, 256);
    check(strcmp(enc, "3a2b1c") == 0, "rle encode aaabbc");

    rle_decode("3a2b1c", dec, 256);
    check(strcmp(dec, "aaabbc") == 0, "rle decode 3a2b1c");

    rle_encode("a", enc, 256);
    check(strcmp(enc, "1a") == 0, "rle encode single");

    rle_decode("1a", dec, 256);
    check(strcmp(dec, "a") == 0, "rle decode single");

    rle_encode("", enc, 256);
    check(strcmp(enc, "") == 0, "rle encode empty");

    rle_decode("", dec, 256);
    check(strcmp(dec, "") == 0, "rle decode empty");

    /* Round-trip */
    rle_encode("aaaaaaaaaa", enc, 256);
    check(strcmp(enc, "10a") == 0, "rle encode 10 a's");
    rle_decode(enc, dec, 256);
    check(strcmp(dec, "aaaaaaaaaa") == 0, "rle roundtrip 10 a's");

    rle_encode("aabbccdd", enc, 256);
    rle_decode(enc, dec, 256);
    check(strcmp(dec, "aabbccdd") == 0, "rle roundtrip aabbccdd");

    rle_encode("abcdef", enc, 256);
    check(strcmp(enc, "1a1b1c1d1e1f") == 0, "rle no repeats");
    rle_decode(enc, dec, 256);
    check(strcmp(dec, "abcdef") == 0, "rle roundtrip no repeats");
}

/* --- Test 12: Regex matching --- */
static void test_regex(void) {
    write_str("[test_regex]\n");
    check(regex_match("abc", "abc") == 1, "regex exact");
    check(regex_match("abc", "a.c") == 1, "regex dot");
    check(regex_match("abc", "a..") == 1, "regex two dots");
    check(regex_match("abc", "...") == 1, "regex three dots");
    check(regex_match("abc", "..") == 0, "regex too short");
    check(regex_match("abc", "a*bc") == 1, "regex a* one a");
    check(regex_match("bc", "a*bc") == 1, "regex a* zero a");
    check(regex_match("aaaabc", "a*bc") == 1, "regex a* many a");
    check(regex_match("", "a*") == 1, "regex a* empty");
    check(regex_match("", "") == 1, "regex both empty");
    check(regex_match("a", "") == 0, "regex pat empty text not");
    check(regex_match("abc", ".*") == 1, "regex .* match all");
    check(regex_match("", ".*") == 1, "regex .* match empty");
    check(regex_match("aab", "c*a*b") == 1, "regex c*a*b on aab");
    check(regex_match("ab", ".*c") == 0, "regex .*c no c");
    check(regex_match("abcd", "a.*d") == 1, "regex a.*d");
    check(regex_match("abcd", "a.*e") == 0, "regex a.*e no match");
    /* Multiple stars */
    check(regex_match("aab", "a*a*b") == 1, "regex a*a*b");
    check(regex_match("", "a*b*c*") == 1, "regex all stars empty");
}

/* --- Test 13: Palindrome --- */
static void test_palindrome(void) {
    write_str("[test_palindrome]\n");
    check(is_palindrome("racecar") == 1, "palindrome racecar");
    check(is_palindrome("abba") == 1, "palindrome abba");
    check(is_palindrome("a") == 1, "palindrome single");
    check(is_palindrome("") == 1, "palindrome empty");
    check(is_palindrome("ab") == 0, "not palindrome ab");
    check(is_palindrome("abcba") == 1, "palindrome abcba");
    check(is_palindrome("abcda") == 0, "not palindrome abcda");
    check(is_palindrome("aa") == 1, "palindrome aa");
    check(is_palindrome("aba") == 1, "palindrome aba");

    check(longest_palindrome("babad") == 3, "longest pal babad=3");
    check(longest_palindrome("cbbd") == 2, "longest pal cbbd=2");
    check(longest_palindrome("a") == 1, "longest pal a=1");
    check(longest_palindrome("racecar") == 7, "longest pal racecar=7");
    check(longest_palindrome("abacaba") == 7, "longest pal abacaba=7");
}

/* --- Test 14: Anagram --- */
static void test_anagram(void) {
    write_str("[test_anagram]\n");
    check(are_anagrams("listen", "silent") == 1, "anagram listen/silent");
    check(are_anagrams("hello", "world") == 0, "not anagram hello/world");
    check(are_anagrams("abc", "cba") == 1, "anagram abc/cba");
    check(are_anagrams("abc", "abcd") == 0, "not anagram diff len");
    check(are_anagrams("", "") == 1, "anagram empty");
    check(are_anagrams("aabb", "abab") == 1, "anagram aabb/abab");
    check(are_anagrams("aabb", "aab") == 0, "not anagram aabb/aab");
    check(are_anagrams("abc", "abd") == 0, "not anagram abc/abd");
    check(are_anagrams("triangle", "integral") == 1, "anagram triangle/integral");
}

/* --- Test 15: Caesar cipher --- */
static void test_caesar(void) {
    char enc[64], dec[64];
    write_str("[test_caesar]\n");

    caesar_encode("hello", enc, 3);
    check(strcmp(enc, "khoor") == 0, "caesar enc shift3 hello");

    caesar_decode("khoor", dec, 3);
    check(strcmp(dec, "hello") == 0, "caesar dec shift3 khoor");

    caesar_encode("abc", enc, 1);
    check(strcmp(enc, "bcd") == 0, "caesar enc shift1 abc");

    caesar_encode("xyz", enc, 3);
    check(strcmp(enc, "abc") == 0, "caesar enc shift3 xyz wrap");

    caesar_encode("Hello World!", enc, 13);
    check(strcmp(enc, "Uryyb Jbeyq!") == 0, "caesar enc shift13 mixed");

    /* Round-trip */
    caesar_encode("testing123", enc, 7);
    caesar_decode(enc, dec, 7);
    check(strcmp(dec, "testing123") == 0, "caesar roundtrip");

    /* Shift 0 */
    caesar_encode("abc", enc, 0);
    check(strcmp(enc, "abc") == 0, "caesar shift0");

    /* Shift 26 = identity */
    caesar_encode("abc", enc, 26);
    check(strcmp(enc, "abc") == 0, "caesar shift26");
}

/* --- Test 16: ROT13 --- */
static void test_rot13(void) {
    char enc[64], dec[64];
    write_str("[test_rot13]\n");

    rot13("Hello", enc);
    check(strcmp(enc, "Uryyb") == 0, "rot13 Hello");

    rot13("Uryyb", dec);
    check(strcmp(dec, "Hello") == 0, "rot13 roundtrip");

    rot13("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", enc);
    check(strcmp(enc, "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm") == 0, "rot13 full alpha");

    rot13("123!@#", enc);
    check(strcmp(enc, "123!@#") == 0, "rot13 non-alpha unchanged");

    /* Double ROT13 = identity */
    rot13("anything goes here", enc);
    rot13(enc, dec);
    check(strcmp(dec, "anything goes here") == 0, "rot13 double=identity");
}

/* --- Test 17: Base64 --- */
static void test_base64(void) {
    char enc[256];
    unsigned char dec[256];
    int dlen;
    write_str("[test_base64]\n");

    base64_encode((const unsigned char*)"Man", 3, enc, 256);
    check(strcmp(enc, "TWFu") == 0, "b64 enc Man");

    base64_encode((const unsigned char*)"Ma", 2, enc, 256);
    check(strcmp(enc, "TWE=") == 0, "b64 enc Ma");

    base64_encode((const unsigned char*)"M", 1, enc, 256);
    check(strcmp(enc, "TQ==") == 0, "b64 enc M");

    base64_encode((const unsigned char*)"Hello", 5, enc, 256);
    check(strcmp(enc, "SGVsbG8=") == 0, "b64 enc Hello");

    /* Decode */
    dlen = base64_decode("TWFu", dec, 256);
    check(dlen == 3 && memcmp(dec, "Man", 3) == 0, "b64 dec Man");

    dlen = base64_decode("TWE=", dec, 256);
    check(dlen == 2 && memcmp(dec, "Ma", 2) == 0, "b64 dec Ma");

    dlen = base64_decode("TQ==", dec, 256);
    check(dlen == 1 && dec[0] == 'M', "b64 dec M");

    dlen = base64_decode("SGVsbG8=", dec, 256);
    check(dlen == 5 && memcmp(dec, "Hello", 5) == 0, "b64 dec Hello");

    /* Round-trip */
    {
        const char* orig = "The quick brown fox";
        int olen = (int)strlen(orig);
        base64_encode((const unsigned char*)orig, olen, enc, 256);
        dlen = base64_decode(enc, dec, 256);
        dec[dlen] = '\0';
        check(dlen == olen && strcmp((char*)dec, orig) == 0, "b64 roundtrip");
    }

    /* Empty */
    base64_encode((const unsigned char*)"", 0, enc, 256);
    check(strcmp(enc, "") == 0, "b64 enc empty");

    /* Binary data */
    {
        unsigned char bin[] = {0, 1, 2, 255, 254, 253};
        base64_encode(bin, 6, enc, 256);
        dlen = base64_decode(enc, dec, 256);
        check(dlen == 6 && memcmp(dec, bin, 6) == 0, "b64 roundtrip binary");
    }
}

/* --- Test 18: Trie --- */
static void test_trie(void) {
    TrieNode* root;
    write_str("[test_trie]\n");

    root = trie_create_node();
    trie_insert(root, "apple");
    trie_insert(root, "app");
    trie_insert(root, "application");
    trie_insert(root, "banana");
    trie_insert(root, "band");
    trie_insert(root, "ban");

    check(trie_search(root, "apple") == 1, "trie find apple");
    check(trie_search(root, "app") == 1, "trie find app");
    check(trie_search(root, "application") == 1, "trie find application");
    check(trie_search(root, "ap") == 0, "trie no ap (prefix only)");
    check(trie_search(root, "banana") == 1, "trie find banana");
    check(trie_search(root, "band") == 1, "trie find band");
    check(trie_search(root, "ban") == 1, "trie find ban");
    check(trie_search(root, "bane") == 0, "trie no bane");
    check(trie_search(root, "xyz") == 0, "trie no xyz");
    check(trie_search(root, "") == 0, "trie no empty");

    check(trie_starts_with(root, "app") == 1, "trie prefix app");
    check(trie_starts_with(root, "ban") == 1, "trie prefix ban");
    check(trie_starts_with(root, "xyz") == 0, "trie no prefix xyz");
    check(trie_starts_with(root, "a") == 1, "trie prefix a");
    check(trie_starts_with(root, "b") == 1, "trie prefix b");
    check(trie_starts_with(root, "c") == 0, "trie no prefix c");

    check(trie_count_words(root) == 6, "trie 6 words");

    /* Add more words */
    trie_insert(root, "bandana");
    trie_insert(root, "apply");
    check(trie_count_words(root) == 8, "trie 8 words");
    check(trie_search(root, "bandana") == 1, "trie find bandana");
    check(trie_search(root, "apply") == 1, "trie find apply");

    trie_free(root);
}

/* --- Test 19: Edge cases for all search algorithms --- */
static void test_search_edge_cases(void) {
    write_str("[test_search_edge_cases]\n");

    /* Single character text and pattern */
    check(naive_search("x", "x") == 0, "edge naive x in x");
    check(kmp_search("x", "x") == 0, "edge kmp x in x");
    check(bm_search("x", "x") == 0, "edge bm x in x");
    check(rk_search("x", "x") == 0, "edge rk x in x");

    /* Pattern longer than text */
    check(naive_search("ab", "abc") == -1, "edge naive pat>text");
    check(kmp_search("ab", "abc") == -1, "edge kmp pat>text");
    check(bm_search("ab", "abc") == -1, "edge bm pat>text");
    check(rk_search("ab", "abc") == -1, "edge rk pat>text");

    /* Pattern at end */
    check(naive_search("foobar", "bar") == 3, "edge naive at end");
    check(kmp_search("foobar", "bar") == 3, "edge kmp at end");
    check(bm_search("foobar", "bar") == 3, "edge bm at end");
    check(rk_search("foobar", "bar") == 3, "edge rk at end");

    /* Pattern equals text */
    check(naive_search("exact", "exact") == 0, "edge naive exact");
    check(kmp_search("exact", "exact") == 0, "edge kmp exact");
    check(bm_search("exact", "exact") == 0, "edge bm exact");
    check(rk_search("exact", "exact") == 0, "edge rk exact");
}

/* --- Test 20: Comprehensive edit distance --- */
static void test_edit_distance_comprehensive(void) {
    write_str("[test_edit_distance_comprehensive]\n");

    /* Single operations */
    check(edit_distance("a", "b") == 1, "ed single replace");
    check(edit_distance("a", "ab") == 1, "ed single insert");
    check(edit_distance("ab", "a") == 1, "ed single delete");
    check(edit_distance("a", "a") == 0, "ed single same");

    /* Known values */
    check(edit_distance("horse", "ros") == 3, "ed horse->ros=3");
    check(edit_distance("flaw", "lawn") == 2, "ed flaw->lawn=2");
    check(edit_distance("gumbo", "gambol") == 2, "ed gumbo->gambol=2");

    /* All same length */
    check(edit_distance("abc", "axc") == 1, "ed abc->axc=1");
    check(edit_distance("abc", "xyz") == 3, "ed abc->xyz=3");
    check(edit_distance("abcd", "abce") == 1, "ed abcd->abce=1");

    /* Longer strings */
    check(edit_distance("algorithm", "altruistic") == 6, "ed algorithm->altruistic=6");
    check(edit_distance("abcdefghij", "abcdefghij") == 0, "ed 10char same=0");
}

/* --- Test 21: LCS comprehensive --- */
static void test_lcs_comprehensive(void) {
    char buf[64];
    write_str("[test_lcs_comprehensive]\n");

    check(lcs_length("a", "a") == 1, "lcs single same=1");
    check(lcs_length("a", "b") == 0, "lcs single diff=0");
    check(lcs_length("abcde", "ace") == 3, "lcs abcde,ace=3");
    check(lcs_length("abcde", "abcde") == 5, "lcs same=5");

    /* LCS(reverse(s), s) gives longest palindromic subsequence */
    {
        int lps;
        char rev[32];
        strcpy(rev, "character");
        str_reverse(rev);
        lps = lcs_length("character", rev);
        check(lps == 5, "lps character=5 (carac)");
    }

    /* Empty cases */
    check(lcs_length("", "") == 0, "lcs empty,empty=0");

    /* Subsequence reconstruction */
    lcs_string("abcde", "ace", buf, 64);
    check(strcmp(buf, "ace") == 0, "lcs string ace");

    lcs_string("XMJYAUZ", "MZJAWXU", buf, 64);
    /* LCS length should be 4 */
    check(lcs_length("XMJYAUZ", "MZJAWXU") == 4, "lcs XMJYAUZ,MZJAWXU=4");
}

/* --- Test 22: Regex edge cases --- */
static void test_regex_edge_cases(void) {
    write_str("[test_regex_edge_cases]\n");

    check(regex_match("mississippi", "mis*is*ip*.") == 1, "regex mississippi");
    check(regex_match("ab", ".*..") == 1, "regex .*..");
    check(regex_match("a", ".*..") == 0, "regex .*.. too short");
    check(regex_match("aaa", "a*a") == 1, "regex a*a on aaa");
    check(regex_match("aaab", "a*b") == 1, "regex a*b on aaab");
    check(regex_match("b", "a*b") == 1, "regex a*b on b");
    check(regex_match("", "a*b*") == 1, "regex a*b* on empty");
    check(regex_match("c", "a*b*c") == 1, "regex a*b*c on c");
    check(regex_match("abc", "a.c") == 1, "regex a.c");
    check(regex_match("adc", "a.c") == 1, "regex a.c with d");
    check(regex_match("ac", "a.c") == 0, "regex a.c too short");
}

/* --- Test 23: Multiple palindrome tests --- */
static void test_palindrome_comprehensive(void) {
    write_str("[test_palindrome_comprehensive]\n");

    check(is_palindrome("abcdefedcba") == 1, "pal abcdefedcba");
    check(is_palindrome("amanaplanacanalpanama") == 1, "pal panama");
    check(is_palindrome("noon") == 1, "pal noon");
    check(is_palindrome("level") == 1, "pal level");
    check(is_palindrome("deified") == 1, "pal deified");
    check(is_palindrome("hello") == 0, "not pal hello");

    check(longest_palindrome("abaxyzzyxf") == 6, "longest pal xyzzyxf=6");
    check(longest_palindrome("aaaa") == 4, "longest pal aaaa=4");
    check(longest_palindrome("abc") == 1, "longest pal abc=1");
    check(longest_palindrome("") == 0, "longest pal empty=0");
    check(longest_palindrome("abacabadabacaba") == 15, "longest pal long=15");
}

/* --- Test 24: Stress test with longer strings --- */
static void test_stress_strings(void) {
    char long1[128], long2[128];
    int i;
    write_str("[test_stress_strings]\n");

    /* Build repetitive strings */
    for (i = 0; i < 100; i++) long1[i] = 'a' + (i % 3);
    long1[100] = '\0';
    for (i = 0; i < 100; i++) long2[i] = 'a' + (i % 3);
    long2[100] = '\0';

    check(edit_distance(long1, long2) == 0, "stress ed same=0");
    check(lcs_length(long1, long2) == 100, "stress lcs same=100");

    /* Shift by 1 */
    for (i = 0; i < 100; i++) long2[i] = 'a' + ((i + 1) % 3);
    long2[100] = '\0';
    check(edit_distance(long1, long2) > 0, "stress ed shifted>0");

    /* All same char */
    for (i = 0; i < 50; i++) long1[i] = 'x';
    long1[50] = '\0';
    for (i = 0; i < 50; i++) long2[i] = 'x';
    long2[50] = '\0';
    check(edit_distance(long1, long2) == 0, "stress ed 50x same");
    check(lcs_length(long1, long2) == 50, "stress lcs 50x same");
    check(is_palindrome(long1) == 1, "stress pal 50x");
}

/* --- Test 25: Trie comprehensive --- */
static void test_trie_comprehensive(void) {
    TrieNode* root;
    const char* words[] = {
        "cat", "car", "card", "care", "careful",
        "dog", "do", "doe", "done",
        "the", "them", "then", "there", "these",
        "to", "too", "top"
    };
    int nwords = 17;
    int i;
    write_str("[test_trie_comprehensive]\n");

    root = trie_create_node();
    for (i = 0; i < nwords; i++) trie_insert(root, words[i]);

    check(trie_count_words(root) == nwords, "trie 17 words");

    /* All should be found */
    for (i = 0; i < nwords; i++) {
        check(trie_search(root, words[i]) == 1, "trie find each word");
    }

    /* Prefixes that are not words */
    check(trie_search(root, "ca") == 0, "trie ca not a word");
    check(trie_search(root, "th") == 0, "trie th not a word");
    check(trie_search(root, "don") == 0, "trie don not a word");

    /* Prefix checks */
    check(trie_starts_with(root, "ca") == 1, "trie prefix ca");
    check(trie_starts_with(root, "do") == 1, "trie prefix do");
    check(trie_starts_with(root, "th") == 1, "trie prefix th");
    check(trie_starts_with(root, "z") == 0, "trie no prefix z");
    check(trie_starts_with(root, "careful") == 1, "trie prefix careful");
    check(trie_starts_with(root, "carefully") == 0, "trie no prefix carefully");

    trie_free(root);
}

/* --- Test 26: Anagram comprehensive --- */
static void test_anagram_comprehensive(void) {
    write_str("[test_anagram_comprehensive]\n");

    check(are_anagrams("dusty", "study") == 1, "anagram dusty/study");
    check(are_anagrams("night", "thing") == 1, "anagram night/thing");
    check(are_anagrams("astronomer", "moonrstare") == 1, "anagram astronomer/moonrstare");
    check(are_anagrams("eleven", "twelve") == 0, "not anagram eleven/twelve");
    check(are_anagrams("aab", "aba") == 1, "anagram aab/aba");
    check(are_anagrams("aab", "bba") == 0, "not anagram aab/bba");
    check(are_anagrams("a", "a") == 1, "anagram single a/a");
    check(are_anagrams("ab", "ba") == 1, "anagram ab/ba");
    check(are_anagrams("aaaa", "aaaa") == 1, "anagram aaaa/aaaa");
    check(are_anagrams("aaaa", "aaab") == 0, "not anagram aaaa/aaab");
}

/* --- Test 27: Base64 comprehensive --- */
static void test_base64_comprehensive(void) {
    char enc[512];
    unsigned char dec[512];
    int dlen;
    write_str("[test_base64_comprehensive]\n");

    /* Standard test vectors */
    base64_encode((const unsigned char*)"f", 1, enc, 512);
    check(strcmp(enc, "Zg==") == 0, "b64 f");

    base64_encode((const unsigned char*)"fo", 2, enc, 512);
    check(strcmp(enc, "Zm8=") == 0, "b64 fo");

    base64_encode((const unsigned char*)"foo", 3, enc, 512);
    check(strcmp(enc, "Zm9v") == 0, "b64 foo");

    base64_encode((const unsigned char*)"foob", 4, enc, 512);
    check(strcmp(enc, "Zm9vYg==") == 0, "b64 foob");

    base64_encode((const unsigned char*)"fooba", 5, enc, 512);
    check(strcmp(enc, "Zm9vYmE=") == 0, "b64 fooba");

    base64_encode((const unsigned char*)"foobar", 6, enc, 512);
    check(strcmp(enc, "Zm9vYmFy") == 0, "b64 foobar");

    /* Decode all back */
    dlen = base64_decode("Zg==", dec, 512);
    check(dlen == 1 && dec[0] == 'f', "b64 dec f");

    dlen = base64_decode("Zm8=", dec, 512);
    check(dlen == 2 && memcmp(dec, "fo", 2) == 0, "b64 dec fo");

    dlen = base64_decode("Zm9v", dec, 512);
    check(dlen == 3 && memcmp(dec, "foo", 3) == 0, "b64 dec foo");

    dlen = base64_decode("Zm9vYmFy", dec, 512);
    check(dlen == 6 && memcmp(dec, "foobar", 6) == 0, "b64 dec foobar");

    /* Longer string round-trip */
    {
        const char* longstr = "The quick brown fox jumps over the lazy dog. 0123456789!";
        int olen = (int)strlen(longstr);
        base64_encode((const unsigned char*)longstr, olen, enc, 512);
        dlen = base64_decode(enc, dec, 512);
        dec[dlen] = '\0';
        check(dlen == olen && strcmp((char*)dec, longstr) == 0, "b64 roundtrip long");
    }
}

/* --- Test 28: Common substring comprehensive --- */
static void test_lc_substring_comprehensive(void) {
    char buf[128];
    int len;
    write_str("[test_lc_substring_comprehensive]\n");

    len = longest_common_substring("ABABC", "BABCBA", buf, 128);
    check(len == 4, "lcsub ABABC,BABCBA=4");
    check(strcmp(buf, "BABC") == 0, "lcsub string BABC");

    len = longest_common_substring("abcdefg", "xyzabcxyz", buf, 128);
    check(len == 3, "lcsub abcdefg,xyzabcxyz=3");
    check(strcmp(buf, "abc") == 0, "lcsub string abc");

    len = longest_common_substring("a", "a", buf, 128);
    check(len == 1, "lcsub single same=1");

    len = longest_common_substring("a", "b", buf, 128);
    check(len == 0, "lcsub single diff=0");

    len = longest_common_substring("abcdefgh", "abcdefgh", buf, 128);
    check(len == 8, "lcsub identical=8");

    len = longest_common_substring("xxhelloxx", "yyhelloyy", buf, 128);
    check(len == 5, "lcsub hello=5");
    check(strcmp(buf, "hello") == 0, "lcsub string hello");
}

/* --- Test 29: String rotation comprehensive --- */
static void test_rotation_comprehensive(void) {
    char buf[64];
    write_str("[test_rotation_comprehensive]\n");

    /* All rotations of "abcd" */
    check(is_rotation("abcd", "abcd") == 1, "rot abcd/abcd");
    check(is_rotation("abcd", "bcda") == 1, "rot abcd/bcda");
    check(is_rotation("abcd", "cdab") == 1, "rot abcd/cdab");
    check(is_rotation("abcd", "dabc") == 1, "rot abcd/dabc");
    check(is_rotation("abcd", "abdc") == 0, "not rot abcd/abdc");

    /* Rotate by all amounts */
    strcpy(buf, "hello");
    str_rotate_left(buf, 1);
    check(strcmp(buf, "elloh") == 0, "rotate hello by 1");

    strcpy(buf, "hello");
    str_rotate_left(buf, 2);
    check(strcmp(buf, "llohe") == 0, "rotate hello by 2");

    strcpy(buf, "hello");
    str_rotate_left(buf, 3);
    check(strcmp(buf, "lohel") == 0, "rotate hello by 3");

    strcpy(buf, "hello");
    str_rotate_left(buf, 4);
    check(strcmp(buf, "ohell") == 0, "rotate hello by 4");
}

/* --- Test 30: RLE stress test --- */
static void test_rle_stress(void) {
    char enc[512], dec[512];
    char input[256];
    int i;
    write_str("[test_rle_stress]\n");

    /* Long run of single char */
    for (i = 0; i < 100; i++) input[i] = 'z';
    input[100] = '\0';
    rle_encode(input, enc, 512);
    check(strcmp(enc, "100z") == 0, "rle 100 z's");
    rle_decode(enc, dec, 512);
    check(strcmp(dec, input) == 0, "rle roundtrip 100 z's");

    /* Alternating chars */
    for (i = 0; i < 50; i++) { input[2*i] = 'a'; input[2*i+1] = 'b'; }
    input[100] = '\0';
    rle_encode(input, enc, 512);
    rle_decode(enc, dec, 512);
    check(strcmp(dec, input) == 0, "rle roundtrip alternating");

    /* Mixed runs */
    strcpy(input, "aaabbbcccdddeee");
    rle_encode(input, enc, 512);
    check(strcmp(enc, "3a3b3c3d3e") == 0, "rle mixed 3s");
    rle_decode(enc, dec, 512);
    check(strcmp(dec, input) == 0, "rle roundtrip mixed 3s");
}

/* --- Test 31: KMP failure function patterns --- */
static void test_kmp_failure_patterns(void) {
    int fail[64];
    write_str("[test_kmp_failure_patterns]\n");

    /* Pattern "aaaa" -> fail = [0,1,2,3] */
    kmp_failure("aaaa", 4, fail);
    check(fail[0] == 0 && fail[1] == 1 && fail[2] == 2 && fail[3] == 3, "kmp fail aaaa");

    /* Pattern "abab" -> fail = [0,0,1,2] */
    kmp_failure("abab", 4, fail);
    check(fail[0] == 0 && fail[1] == 0 && fail[2] == 1 && fail[3] == 2, "kmp fail abab");

    /* Pattern "abcabd" -> fail = [0,0,0,1,2,0] */
    kmp_failure("abcabd", 6, fail);
    check(fail[0] == 0 && fail[1] == 0 && fail[2] == 0, "kmp fail abcabd first 3");
    check(fail[3] == 1 && fail[4] == 2 && fail[5] == 0, "kmp fail abcabd last 3");

    /* Pattern "a" -> fail = [0] */
    kmp_failure("a", 1, fail);
    check(fail[0] == 0, "kmp fail single");
}

/* --- Test 32: Caesar with all shifts --- */
static void test_caesar_all_shifts(void) {
    char enc[64], dec[64];
    const char* orig = "hello";
    int shift;
    write_str("[test_caesar_all_shifts]\n");

    for (shift = 0; shift < 26; shift++) {
        caesar_encode(orig, enc, shift);
        caesar_decode(enc, dec, shift);
        check(strcmp(dec, orig) == 0, "caesar roundtrip all shifts");
    }
}

/* --- Test 33: Edit distance symmetry and identity --- */
static void test_edit_distance_properties(void) {
    write_str("[test_edit_distance_properties]\n");

    /* d(a,a) = 0 */
    check(edit_distance("hello", "hello") == 0, "ed identity");
    check(edit_distance("", "") == 0, "ed identity empty");

    /* d(a,b) = d(b,a) */
    check(edit_distance("abc", "def") == edit_distance("def", "abc"), "ed symmetric 1");
    check(edit_distance("kitten", "sitting") == edit_distance("sitting", "kitten"), "ed symmetric 2");
    check(edit_distance("hello", "world") == edit_distance("world", "hello"), "ed symmetric 3");

    /* d(a,b) >= |len(a)-len(b)| */
    {
        int d = edit_distance("abc", "abcdef");
        int diff = 3;
        check(d >= diff, "ed >= len diff");
    }

    /* d(a,b) <= max(len(a), len(b)) */
    {
        int d = edit_distance("abc", "xyz");
        check(d <= 3, "ed <= max len");
    }
}

/* --- Test 34: Mixed algorithm integration --- */
static void test_integration(void) {
    char reversed[64], encoded[64], decoded[64];
    char b64[128];
    unsigned char b64dec[128];
    int dlen;
    write_str("[test_integration]\n");

    /* Reverse then palindrome check */
    strcpy(reversed, "racecar");
    str_reverse(reversed);
    check(strcmp(reversed, "racecar") == 0, "reverse palindrome unchanged");
    check(is_palindrome(reversed) == 1, "reversed palindrome still palindrome");

    /* Caesar encode then search */
    caesar_encode("attack at dawn", encoded, 3);
    check(naive_search(encoded, "dwwdfn") >= 0, "search in caesar text");

    /* Base64 round-trip with search */
    base64_encode((const unsigned char*)"needle in haystack", 18, b64, 128);
    dlen = base64_decode(b64, b64dec, 128);
    b64dec[dlen] = '\0';
    check(naive_search((char*)b64dec, "needle") == 0, "search after b64 roundtrip");

    /* ROT13 then anagram */
    {
        char r1[32], r2[32];
        rot13("abc", r1);
        rot13("bca", r2);
        /* rot13(abc) = nop, rot13(bca) = opn */
        check(are_anagrams(r1, r2) == 1, "rot13 preserves anagram");
    }
}

/* --- Test 35: Long pattern search --- */
static void test_long_pattern_search(void) {
    char text[256], pat[64];
    int i;
    write_str("[test_long_pattern_search]\n");

    /* Build text: "ababababab...ababc" */
    for (i = 0; i < 200; i += 2) { text[i] = 'a'; text[i+1] = 'b'; }
    text[198] = 'c';
    text[199] = '\0';

    /* Pattern: "ababc" should be near the end */
    check(naive_search(text, "ababc") == 194, "long naive ababc");
    check(kmp_search(text, "ababc") == 194, "long kmp ababc");
    check(rk_search(text, "ababc") == 194, "long rk ababc");

    /* Pattern not present */
    check(naive_search(text, "xyz") == -1, "long naive xyz missing");
    check(kmp_search(text, "xyz") == -1, "long kmp xyz missing");
    check(rk_search(text, "xyz") == -1, "long rk xyz missing");

    /* All 'a' text, search for 'b' */
    for (i = 0; i < 100; i++) text[i] = 'a';
    text[100] = '\0';
    check(naive_search(text, "b") == -1, "100a no b naive");
    check(kmp_search(text, "b") == -1, "100a no b kmp");
    check(rk_search(text, "b") == -1, "100a no b rk");
}

/* --- Test 36: Regex stars chain --- */
static void test_regex_stars(void) {
    write_str("[test_regex_stars]\n");

    check(regex_match("", "a*b*c*d*") == 1, "regex many stars empty");
    check(regex_match("abcd", "a*b*c*d*") == 1, "regex many stars abcd");
    check(regex_match("d", "a*b*c*d*") == 1, "regex many stars d");
    check(regex_match("aaaa", "a*") == 1, "regex a* on aaaa");
    check(regex_match("aaaa", "a*a*a*a*") == 1, "regex a*a*a*a* on aaaa");
    check(regex_match("b", "a*b*c*") == 1, "regex a*b*c* on b");
    check(regex_match("abc", ".*.*.*") == 1, "regex .*.*.* on abc");
    check(regex_match("xyz", "x.*z") == 1, "regex x.*z on xyz");
    check(regex_match("xz", "x.*z") == 1, "regex x.*z on xz");
    check(regex_match("x", "x.*z") == 0, "regex x.*z on x fails");
}

/* --- Test 37: Comprehensive common substring with equal strings --- */
static void test_common_substring_equal(void) {
    char buf[64];
    int len;
    write_str("[test_common_substring_equal]\n");

    /* Two identical strings */
    len = longest_common_substring("hello", "hello", buf, 64);
    check(len == 5 && strcmp(buf, "hello") == 0, "lcsub identical hello");

    /* One char overlap */
    len = longest_common_substring("abc", "cde", buf, 64);
    check(len == 1, "lcsub one char overlap=1");

    /* Substring at start */
    len = longest_common_substring("abcdef", "abcxyz", buf, 64);
    check(len == 3 && strcmp(buf, "abc") == 0, "lcsub at start");

    /* Substring at end */
    len = longest_common_substring("xyzdef", "abcdef", buf, 64);
    check(len == 3 && strcmp(buf, "def") == 0, "lcsub at end");
}

/* --- Test 38: Trie with overlapping prefixes --- */
static void test_trie_prefixes(void) {
    TrieNode* root;
    write_str("[test_trie_prefixes]\n");

    root = trie_create_node();
    trie_insert(root, "a");
    trie_insert(root, "ab");
    trie_insert(root, "abc");
    trie_insert(root, "abcd");
    trie_insert(root, "abcde");

    check(trie_count_words(root) == 5, "trie nested 5");
    check(trie_search(root, "a") == 1, "trie nested a");
    check(trie_search(root, "ab") == 1, "trie nested ab");
    check(trie_search(root, "abc") == 1, "trie nested abc");
    check(trie_search(root, "abcd") == 1, "trie nested abcd");
    check(trie_search(root, "abcde") == 1, "trie nested abcde");
    check(trie_search(root, "abcdef") == 0, "trie nested no abcdef");
    check(trie_starts_with(root, "") == 1, "trie empty prefix");
    check(trie_starts_with(root, "abcde") == 1, "trie prefix abcde");
    check(trie_starts_with(root, "abcdef") == 0, "trie no prefix abcdef");

    trie_free(root);
}

/* --- Test 39: Edit distance with repetitions --- */
static void test_edit_distance_repetitions(void) {
    write_str("[test_edit_distance_repetitions]\n");

    check(edit_distance("aaa", "aaa") == 0, "ed aaa,aaa=0");
    check(edit_distance("aaa", "aa") == 1, "ed aaa,aa=1");
    check(edit_distance("aa", "aaa") == 1, "ed aa,aaa=1");
    check(edit_distance("aaa", "bbb") == 3, "ed aaa,bbb=3");
    check(edit_distance("abab", "baba") == 2, "ed abab,baba=2");
    check(edit_distance("aaaa", "bbbb") == 4, "ed aaaa,bbbb=4");
    check(edit_distance("abcabc", "abcabc") == 0, "ed abcabc same=0");
    check(edit_distance("abcabc", "cbacba") == 4, "ed abcabc,cbacba=4");
}

/* --- Test 40: Final sanity checks --- */
static void test_final_sanity(void) {
    char buf[256];
    write_str("[test_final_sanity]\n");

    /* Reverse of reverse = original */
    strcpy(buf, "abcdefghijklmnop");
    str_reverse(buf);
    str_reverse(buf);
    check(strcmp(buf, "abcdefghijklmnop") == 0, "double reverse long");

    /* Rotation by length = identity */
    strcpy(buf, "rotation");
    str_rotate_left(buf, 8);
    check(strcmp(buf, "rotation") == 0, "rotate by length");

    /* Empty string is palindrome */
    check(is_palindrome("") == 1, "empty palindrome");

    /* ROT13 self-inverse */
    {
        char r1[64], r2[64];
        rot13("The Quick Brown Fox!", r1);
        rot13(r1, r2);
        check(strcmp(r2, "The Quick Brown Fox!") == 0, "rot13 self-inverse");
    }

    /* Edit distance to self is always 0 */
    check(edit_distance("supercalifragilistic", "supercalifragilistic") == 0, "ed long self=0");

    /* KMP finds same as naive for tricky pattern */
    {
        int n = naive_search("aabaabaab", "aab");
        int k = kmp_search("aabaabaab", "aab");
        check(n == k && n == 0, "kmp==naive tricky");
    }

    /* Anagram is reflexive */
    check(are_anagrams("test", "test") == 1, "anagram reflexive");

    /* LCS of string with itself = length */
    check(lcs_length("abcdef", "abcdef") == 6, "lcs self=len");
}

/* =========================================================================
 * MAIN
 * ========================================================================= */

int main(void) {
    init_io();
    g_errs = 0;

    write_str("=== victim_string.c test suite ===\n");

    test_naive_search();
    test_kmp_search();
    test_bm_search();
    test_rk_search();
    test_search_agreement();
    test_edit_distance();
    test_lcs();
    test_lc_substring();
    test_reversal();
    test_rotation();
    test_rle();
    test_regex();
    test_palindrome();
    test_anagram();
    test_caesar();
    test_rot13();
    test_base64();
    test_trie();
    test_search_edge_cases();
    test_edit_distance_comprehensive();
    test_lcs_comprehensive();
    test_regex_edge_cases();
    test_palindrome_comprehensive();
    test_stress_strings();
    test_trie_comprehensive();
    test_anagram_comprehensive();
    test_base64_comprehensive();
    test_lc_substring_comprehensive();
    test_rotation_comprehensive();
    test_rle_stress();
    test_kmp_failure_patterns();
    test_caesar_all_shifts();
    test_edit_distance_properties();
    test_integration();
    test_long_pattern_search();
    test_regex_stars();
    test_common_substring_equal();
    test_trie_prefixes();
    test_edit_distance_repetitions();
    test_final_sanity();

    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
