@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat" x86
if errorlevel 1 exit /b 1
cd /d C:\Users\stard\Desktop\Personal\Mystique\tests\victims

for %%f in (sort crypto matrix string graph compress math tree hash state) do (
    echo Building victim_%%f.c...
    cl /nologo /O1 victim_%%f.c /Fe:victim_%%f.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
    if errorlevel 1 echo   FAILED: victim_%%f.c
)
echo Done.
