#!/bin/bash
# Compile all victim_*.c sources to 32-bit PIE ELFs for the lacrimystique
# test suite. Run once on Linux/WSL; commit the resulting victim_*.elf32
# files alongside the .c sources. Tests prefer the precompiled ELFs and
# fall back to gcc only if they're missing.
#
# Mirrors build_all.bat (which produces .exe for mystiquefall tests).

set -e
cd "$(dirname "$0")"

for f in sort crypto matrix string graph compress math tree state; do
    echo "Building victim_$f.c..."
    if ! gcc -m32 -pie -fpie -O2 -Wl,--hash-style=sysv -z lazy \
            -o "victim_$f.elf32" "victim_$f.c" 2>/dev/null; then
        echo "  FAILED: victim_$f.c"
        exit 1
    fi
done
echo "Done."
