/* victim_sort.c - Sorting algorithms stress test for MystiqueFall
 * Build: cl /nologo /O1 victim_sort.c /Fe:victim_sort.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * All output is deterministic.
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ================================================================
 * Utility: deterministic LCG PRNG
 * ================================================================ */
static unsigned int lcg_state;
static void lcg_seed(unsigned int s) { lcg_state = s; }
static unsigned int lcg_next(void) {
    lcg_state = lcg_state * 1103515245u + 12345u;
    return (lcg_state >> 16) & 0x7FFF;
}
static int lcg_next_range(int lo, int hi) {
    return lo + (int)(lcg_next() % (unsigned int)(hi - lo + 1));
}

/* ================================================================
 * Array helpers
 * ================================================================ */
static int array_is_sorted(int *a, int n) {
    int i;
    for (i = 1; i < n; i++) {
        if (a[i-1] > a[i]) return 0;
    }
    return 1;
}

static void array_copy(int *dst, const int *src, int n) {
    int i;
    for (i = 0; i < n; i++) dst[i] = src[i];
}

static void array_reverse(int *a, int n) {
    int i, j, t;
    i = 0; j = n - 1;
    while (i < j) {
        t = a[i]; a[i] = a[j]; a[j] = t;
        i++; j--;
    }
}

static void array_fill_random(int *a, int n, unsigned int seed) {
    int i;
    lcg_seed(seed);
    for (i = 0; i < n; i++) {
        a[i] = lcg_next_range(-10000, 10000);
    }
}

static void array_fill_sorted(int *a, int n) {
    int i;
    for (i = 0; i < n; i++) a[i] = i;
}

static void array_fill_reverse(int *a, int n) {
    int i;
    for (i = 0; i < n; i++) a[i] = n - 1 - i;
}

static void array_fill_same(int *a, int n) {
    int i;
    for (i = 0; i < n; i++) a[i] = 42;
}

static void array_fill_few_unique(int *a, int n, unsigned int seed) {
    int i;
    int vals[5];
    lcg_seed(seed);
    vals[0] = -100; vals[1] = 0; vals[2] = 7; vals[3] = 42; vals[4] = 999;
    for (i = 0; i < n; i++) {
        a[i] = vals[lcg_next() % 5];
    }
}

static int arrays_equal(const int *a, const int *b, int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (a[i] != b[i]) return 0;
    }
    return 1;
}

static int array_sum(const int *a, int n) {
    int i, s = 0;
    for (i = 0; i < n; i++) s += a[i];
    return s;
}

/* ================================================================
 * Bubble sort
 * ================================================================ */
static void bubble_sort(int *a, int n) {
    int i, j, t, swapped;
    for (i = 0; i < n - 1; i++) {
        swapped = 0;
        for (j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j+1]) {
                t = a[j]; a[j] = a[j+1]; a[j+1] = t;
                swapped = 1;
            }
        }
        if (!swapped) break;
    }
}

/* ================================================================
 * Selection sort
 * ================================================================ */
static void selection_sort(int *a, int n) {
    int i, j, min_idx, t;
    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (a[j] < a[min_idx]) min_idx = j;
        }
        if (min_idx != i) {
            t = a[i]; a[i] = a[min_idx]; a[min_idx] = t;
        }
    }
}

/* ================================================================
 * Insertion sort
 * ================================================================ */
static void insertion_sort(int *a, int n) {
    int i, j, key;
    for (i = 1; i < n; i++) {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key) {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = key;
    }
}

/* ================================================================
 * Shell sort (Knuth gap sequence: 1, 4, 13, 40, 121, ...)
 * ================================================================ */
static void shell_sort(int *a, int n) {
    int gap, i, j, temp;
    /* Compute starting gap using Knuth sequence */
    gap = 1;
    while (gap < n / 3) gap = gap * 3 + 1;
    while (gap >= 1) {
        for (i = gap; i < n; i++) {
            temp = a[i];
            j = i;
            while (j >= gap && a[j - gap] > temp) {
                a[j] = a[j - gap];
                j -= gap;
            }
            a[j] = temp;
        }
        gap /= 3;
    }
}

/* ================================================================
 * Merge sort (with auxiliary array)
 * ================================================================ */
static int merge_aux[1024];

static void merge(int *a, int lo, int mid, int hi) {
    int i, j, k;
    for (i = lo; i <= hi; i++) merge_aux[i] = a[i];
    i = lo; j = mid + 1; k = lo;
    while (i <= mid && j <= hi) {
        if (merge_aux[i] <= merge_aux[j]) {
            a[k++] = merge_aux[i++];
        } else {
            a[k++] = merge_aux[j++];
        }
    }
    while (i <= mid) a[k++] = merge_aux[i++];
    while (j <= hi)  a[k++] = merge_aux[j++];
}

static void merge_sort_rec(int *a, int lo, int hi) {
    int mid;
    if (lo >= hi) return;
    mid = lo + (hi - lo) / 2;
    merge_sort_rec(a, lo, mid);
    merge_sort_rec(a, mid + 1, hi);
    merge(a, lo, mid, hi);
}

static void merge_sort(int *a, int n) {
    if (n <= 1) return;
    merge_sort_rec(a, 0, n - 1);
}

/* ================================================================
 * Quicksort with Lomuto partition
 * ================================================================ */
static int lomuto_partition(int *a, int lo, int hi) {
    int pivot, i, j, t;
    pivot = a[hi];
    i = lo - 1;
    for (j = lo; j < hi; j++) {
        if (a[j] <= pivot) {
            i++;
            t = a[i]; a[i] = a[j]; a[j] = t;
        }
    }
    t = a[i+1]; a[i+1] = a[hi]; a[hi] = t;
    return i + 1;
}

static void quicksort_lomuto_rec(int *a, int lo, int hi) {
    int p;
    if (lo < hi) {
        p = lomuto_partition(a, lo, hi);
        quicksort_lomuto_rec(a, lo, p - 1);
        quicksort_lomuto_rec(a, p + 1, hi);
    }
}

static void quicksort_lomuto(int *a, int n) {
    if (n <= 1) return;
    quicksort_lomuto_rec(a, 0, n - 1);
}

/* ================================================================
 * Quicksort with Hoare partition
 * ================================================================ */
static int hoare_partition(int *a, int lo, int hi) {
    int pivot, i, j, t;
    pivot = a[lo + (hi - lo) / 2];
    i = lo - 1;
    j = hi + 1;
    for (;;) {
        do { i++; } while (a[i] < pivot);
        do { j--; } while (a[j] > pivot);
        if (i >= j) return j;
        t = a[i]; a[i] = a[j]; a[j] = t;
    }
}

static void quicksort_hoare_rec(int *a, int lo, int hi) {
    int p;
    if (lo < hi) {
        p = hoare_partition(a, lo, hi);
        quicksort_hoare_rec(a, lo, p);
        quicksort_hoare_rec(a, p + 1, hi);
    }
}

static void quicksort_hoare(int *a, int n) {
    if (n <= 1) return;
    quicksort_hoare_rec(a, 0, n - 1);
}

/* ================================================================
 * Heap sort (max-heap with sift_down)
 * ================================================================ */
static void sift_down(int *a, int start, int end) {
    int root, child, t;
    root = start;
    while (root * 2 + 1 <= end) {
        child = root * 2 + 1;
        if (child + 1 <= end && a[child] < a[child + 1]) {
            child++;
        }
        if (a[root] < a[child]) {
            t = a[root]; a[root] = a[child]; a[child] = t;
            root = child;
        } else {
            return;
        }
    }
}

static void heap_sort(int *a, int n) {
    int i, t;
    /* Build max-heap */
    for (i = (n - 2) / 2; i >= 0; i--) {
        sift_down(a, i, n - 1);
    }
    /* Extract elements */
    for (i = n - 1; i > 0; i--) {
        t = a[0]; a[0] = a[i]; a[i] = t;
        sift_down(a, 0, i - 1);
    }
}

/* ================================================================
 * Radix sort (LSD base-10, handles negatives by offset)
 * ================================================================ */
static void radix_sort(int *a, int n) {
    int i, exp, max_val, min_val, range;
    int *output;
    int count[10];
    int idx;

    if (n <= 1) return;

    /* Find min to offset negatives */
    min_val = a[0]; max_val = a[0];
    for (i = 1; i < n; i++) {
        if (a[i] < min_val) min_val = a[i];
        if (a[i] > max_val) max_val = a[i];
    }
    /* Offset all values to be non-negative */
    for (i = 0; i < n; i++) a[i] -= min_val;
    range = max_val - min_val;

    output = (int*)malloc(n * sizeof(int));
    if (!output) return;

    for (exp = 1; range / exp > 0; exp *= 10) {
        for (i = 0; i < 10; i++) count[i] = 0;
        for (i = 0; i < n; i++) {
            idx = (a[i] / exp) % 10;
            count[idx]++;
        }
        for (i = 1; i < 10; i++) count[i] += count[i-1];
        for (i = n - 1; i >= 0; i--) {
            idx = (a[i] / exp) % 10;
            output[count[idx] - 1] = a[i];
            count[idx]--;
        }
        for (i = 0; i < n; i++) a[i] = output[i];
    }

    free(output);

    /* Restore original values */
    for (i = 0; i < n; i++) a[i] += min_val;
}

/* ================================================================
 * Counting sort (handles negatives by offset)
 * ================================================================ */
static void counting_sort(int *a, int n) {
    int i, min_val, max_val, range;
    int *count_arr;
    int *output;
    int pos;

    if (n <= 1) return;

    min_val = a[0]; max_val = a[0];
    for (i = 1; i < n; i++) {
        if (a[i] < min_val) min_val = a[i];
        if (a[i] > max_val) max_val = a[i];
    }
    range = max_val - min_val + 1;

    count_arr = (int*)calloc(range, sizeof(int));
    output = (int*)malloc(n * sizeof(int));
    if (!count_arr || !output) {
        if (count_arr) free(count_arr);
        if (output) free(output);
        return;
    }

    for (i = 0; i < n; i++) {
        count_arr[a[i] - min_val]++;
    }

    pos = 0;
    for (i = 0; i < range; i++) {
        while (count_arr[i] > 0) {
            output[pos++] = i + min_val;
            count_arr[i]--;
        }
    }

    for (i = 0; i < n; i++) a[i] = output[i];

    free(count_arr);
    free(output);
}

/* ================================================================
 * Binary search on sorted array
 * ================================================================ */
static int binary_search(const int *a, int n, int target) {
    int lo, hi, mid;
    lo = 0; hi = n - 1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) return mid;
        if (a[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

static int binary_search_first(const int *a, int n, int target) {
    int lo, hi, mid, result;
    lo = 0; hi = n - 1; result = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) {
            result = mid;
            hi = mid - 1;
        } else if (a[mid] < target) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return result;
}

static int binary_search_last(const int *a, int n, int target) {
    int lo, hi, mid, result;
    lo = 0; hi = n - 1; result = -1;
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        if (a[mid] == target) {
            result = mid;
            lo = mid + 1;
        } else if (a[mid] < target) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return result;
}

/* ================================================================
 * Test data buffers (static, max 1024 for merge sort aux)
 * ================================================================ */
static int test_arr[1024];
static int ref_arr[1024];
static int work_arr[1024];

/* ================================================================
 * Generic sort tester
 * ================================================================ */
typedef void (*sort_fn)(int*, int);

static void test_sort_one(sort_fn fn, const char* name, int *src, int n, const char* pattern) {
    char label[128];
    int sum_before, sum_after;
    int k;

    array_copy(work_arr, src, n);
    sum_before = array_sum(work_arr, n);
    fn(work_arr, n);
    sum_after = array_sum(work_arr, n);

    /* Build label: "name/pattern/n" */
    k = 0;
    { const char *p = name; while (*p && k < 60) label[k++] = *p++; }
    label[k++] = '/';
    { const char *p = pattern; while (*p && k < 90) label[k++] = *p++; }
    label[k++] = '/';
    label[k] = 0;

    check(array_is_sorted(work_arr, n), label);

    /* Verify element preservation via sum */
    {
        char label2[140];
        int m = 0;
        const char *p = label;
        while (*p && m < 120) label2[m++] = *p++;
        { const char *s = "sum"; while (*s) label2[m++] = *s++; }
        label2[m] = 0;
        check(sum_before == sum_after, label2);
    }
}

static void test_sort_all_patterns(sort_fn fn, const char* name, int max_n) {
    /* Sizes to test */
    int sizes[5];
    int ns, si;
    sizes[0] = 1; sizes[1] = 7; sizes[2] = 100; sizes[3] = 500; sizes[4] = 1000;

    for (si = 0; si < 5; si++) {
        ns = sizes[si];
        if (ns > max_n) ns = max_n;
        if (ns > 1024) ns = 1024;

        /* Sorted */
        array_fill_sorted(test_arr, ns);
        test_sort_one(fn, name, test_arr, ns, "sorted");

        /* Reverse */
        array_fill_reverse(test_arr, ns);
        test_sort_one(fn, name, test_arr, ns, "reverse");

        /* Random (seed = size for determinism) */
        array_fill_random(test_arr, ns, (unsigned int)(ns * 17 + 31));
        test_sort_one(fn, name, test_arr, ns, "random");

        /* All same */
        array_fill_same(test_arr, ns);
        test_sort_one(fn, name, test_arr, ns, "same");

        /* Few unique */
        array_fill_few_unique(test_arr, ns, (unsigned int)(ns * 13 + 7));
        test_sort_one(fn, name, test_arr, ns, "few_unique");
    }
}

/* ================================================================
 * Additional sort correctness tests
 * ================================================================ */
static void test_sort_stability_check(void) {
    /* Verify specific known sequences sort correctly */
    int a1[10] = {5, 3, 8, 1, 9, 2, 7, 4, 6, 0};
    int a2[10];
    int expected[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    write_str("  Stability/correctness spot checks...\n");

    /* Bubble */
    array_copy(a2, a1, 10);
    bubble_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "bubble/exact10");

    /* Selection */
    array_copy(a2, a1, 10);
    selection_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "selection/exact10");

    /* Insertion */
    array_copy(a2, a1, 10);
    insertion_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "insertion/exact10");

    /* Shell */
    array_copy(a2, a1, 10);
    shell_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "shell/exact10");

    /* Merge */
    array_copy(a2, a1, 10);
    merge_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "merge/exact10");

    /* Quick Lomuto */
    array_copy(a2, a1, 10);
    quicksort_lomuto(a2, 10);
    check(arrays_equal(a2, expected, 10), "qlomuto/exact10");

    /* Quick Hoare */
    array_copy(a2, a1, 10);
    quicksort_hoare(a2, 10);
    check(arrays_equal(a2, expected, 10), "qhoare/exact10");

    /* Heap */
    array_copy(a2, a1, 10);
    heap_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "heap/exact10");

    /* Radix */
    array_copy(a2, a1, 10);
    radix_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "radix/exact10");

    /* Counting */
    array_copy(a2, a1, 10);
    counting_sort(a2, 10);
    check(arrays_equal(a2, expected, 10), "counting/exact10");
}

static void test_sort_negative_values(void) {
    int a[8] = {-5, 3, -1, 0, -8, 7, 2, -3};
    int expected[8] = {-8, -5, -3, -1, 0, 2, 3, 7};
    int w[8];

    write_str("  Negative value tests...\n");

    array_copy(w, a, 8);
    bubble_sort(w, 8);
    check(arrays_equal(w, expected, 8), "bubble/neg");

    array_copy(w, a, 8);
    selection_sort(w, 8);
    check(arrays_equal(w, expected, 8), "selection/neg");

    array_copy(w, a, 8);
    insertion_sort(w, 8);
    check(arrays_equal(w, expected, 8), "insertion/neg");

    array_copy(w, a, 8);
    shell_sort(w, 8);
    check(arrays_equal(w, expected, 8), "shell/neg");

    array_copy(w, a, 8);
    merge_sort(w, 8);
    check(arrays_equal(w, expected, 8), "merge/neg");

    array_copy(w, a, 8);
    quicksort_lomuto(w, 8);
    check(arrays_equal(w, expected, 8), "qlomuto/neg");

    array_copy(w, a, 8);
    quicksort_hoare(w, 8);
    check(arrays_equal(w, expected, 8), "qhoare/neg");

    array_copy(w, a, 8);
    heap_sort(w, 8);
    check(arrays_equal(w, expected, 8), "heap/neg");

    array_copy(w, a, 8);
    radix_sort(w, 8);
    check(arrays_equal(w, expected, 8), "radix/neg");

    array_copy(w, a, 8);
    counting_sort(w, 8);
    check(arrays_equal(w, expected, 8), "counting/neg");
}

static void test_sort_single_element(void) {
    int a[1] = {42};

    write_str("  Single element tests...\n");

    bubble_sort(a, 1);
    check(a[0] == 42, "bubble/single");

    selection_sort(a, 1);
    check(a[0] == 42, "selection/single");

    insertion_sort(a, 1);
    check(a[0] == 42, "insertion/single");

    shell_sort(a, 1);
    check(a[0] == 42, "shell/single");

    merge_sort(a, 1);
    check(a[0] == 42, "merge/single");

    quicksort_lomuto(a, 1);
    check(a[0] == 42, "qlomuto/single");

    quicksort_hoare(a, 1);
    check(a[0] == 42, "qhoare/single");

    heap_sort(a, 1);
    check(a[0] == 42, "heap/single");

    radix_sort(a, 1);
    check(a[0] == 42, "radix/single");

    counting_sort(a, 1);
    check(a[0] == 42, "counting/single");
}

static void test_sort_two_elements(void) {
    int a[2], b[2];

    write_str("  Two element tests...\n");

    /* Already sorted */
    a[0] = 1; a[1] = 2;
    b[0] = 1; b[1] = 2;

    array_copy(work_arr, a, 2); bubble_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "bubble/two_sorted");

    array_copy(work_arr, a, 2); selection_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "selection/two_sorted");

    array_copy(work_arr, a, 2); insertion_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "insertion/two_sorted");

    array_copy(work_arr, a, 2); shell_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "shell/two_sorted");

    array_copy(work_arr, a, 2); merge_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "merge/two_sorted");

    array_copy(work_arr, a, 2); quicksort_lomuto(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "qlomuto/two_sorted");

    array_copy(work_arr, a, 2); quicksort_hoare(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "qhoare/two_sorted");

    array_copy(work_arr, a, 2); heap_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "heap/two_sorted");

    /* Reverse */
    a[0] = 9; a[1] = 1;
    b[0] = 1; b[1] = 9;

    array_copy(work_arr, a, 2); bubble_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "bubble/two_rev");

    array_copy(work_arr, a, 2); selection_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "selection/two_rev");

    array_copy(work_arr, a, 2); insertion_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "insertion/two_rev");

    array_copy(work_arr, a, 2); shell_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "shell/two_rev");

    array_copy(work_arr, a, 2); merge_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "merge/two_rev");

    array_copy(work_arr, a, 2); quicksort_lomuto(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "qlomuto/two_rev");

    array_copy(work_arr, a, 2); quicksort_hoare(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "qhoare/two_rev");

    array_copy(work_arr, a, 2); heap_sort(work_arr, 2);
    check(arrays_equal(work_arr, b, 2), "heap/two_rev");
}

static void test_sort_duplicates(void) {
    int a[6] = {3, 1, 4, 1, 5, 9};
    int expected[6] = {1, 1, 3, 4, 5, 9};
    int w[6];

    write_str("  Duplicate value tests...\n");

    array_copy(w, a, 6); bubble_sort(w, 6);
    check(arrays_equal(w, expected, 6), "bubble/dup");

    array_copy(w, a, 6); selection_sort(w, 6);
    check(arrays_equal(w, expected, 6), "selection/dup");

    array_copy(w, a, 6); insertion_sort(w, 6);
    check(arrays_equal(w, expected, 6), "insertion/dup");

    array_copy(w, a, 6); shell_sort(w, 6);
    check(arrays_equal(w, expected, 6), "shell/dup");

    array_copy(w, a, 6); merge_sort(w, 6);
    check(arrays_equal(w, expected, 6), "merge/dup");

    array_copy(w, a, 6); quicksort_lomuto(w, 6);
    check(arrays_equal(w, expected, 6), "qlomuto/dup");

    array_copy(w, a, 6); quicksort_hoare(w, 6);
    check(arrays_equal(w, expected, 6), "qhoare/dup");

    array_copy(w, a, 6); heap_sort(w, 6);
    check(arrays_equal(w, expected, 6), "heap/dup");

    array_copy(w, a, 6); radix_sort(w, 6);
    check(arrays_equal(w, expected, 6), "radix/dup");

    array_copy(w, a, 6); counting_sort(w, 6);
    check(arrays_equal(w, expected, 6), "counting/dup");
}

/* ================================================================
 * Binary search tests
 * ================================================================ */
static void test_binary_search(void) {
    int a[10] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    int idx;

    write_str("  Binary search tests...\n");

    /* Find existing elements */
    idx = binary_search(a, 10, 2);
    check(idx == 0, "bsearch/first");

    idx = binary_search(a, 10, 91);
    check(idx == 9, "bsearch/last");

    idx = binary_search(a, 10, 23);
    check(idx == 5, "bsearch/mid");

    /* Not found */
    idx = binary_search(a, 10, 1);
    check(idx == -1, "bsearch/notfound_lo");

    idx = binary_search(a, 10, 100);
    check(idx == -1, "bsearch/notfound_hi");

    idx = binary_search(a, 10, 10);
    check(idx == -1, "bsearch/notfound_mid");

    /* Empty array */
    idx = binary_search(a, 0, 5);
    check(idx == -1, "bsearch/empty");

    /* Single element */
    idx = binary_search(a, 1, 2);
    check(idx == 0, "bsearch/single_found");

    idx = binary_search(a, 1, 99);
    check(idx == -1, "bsearch/single_notfound");
}

static void test_binary_search_first_last(void) {
    int a[10] = {1, 3, 3, 3, 5, 5, 7, 7, 7, 9};
    int idx;

    write_str("  Binary search first/last tests...\n");

    idx = binary_search_first(a, 10, 3);
    check(idx == 1, "bsearch_first/3");

    idx = binary_search_last(a, 10, 3);
    check(idx == 3, "bsearch_last/3");

    idx = binary_search_first(a, 10, 7);
    check(idx == 6, "bsearch_first/7");

    idx = binary_search_last(a, 10, 7);
    check(idx == 8, "bsearch_last/7");

    idx = binary_search_first(a, 10, 5);
    check(idx == 4, "bsearch_first/5");

    idx = binary_search_last(a, 10, 5);
    check(idx == 5, "bsearch_last/5");

    idx = binary_search_first(a, 10, 1);
    check(idx == 0, "bsearch_first/1");

    idx = binary_search_last(a, 10, 9);
    check(idx == 9, "bsearch_last/9");

    idx = binary_search_first(a, 10, 4);
    check(idx == -1, "bsearch_first/notfound");

    idx = binary_search_last(a, 10, 4);
    check(idx == -1, "bsearch_last/notfound");
}

/* ================================================================
 * Binary search on large sorted arrays (post-sort verification)
 * ================================================================ */
static void test_binary_search_large(void) {
    int a[1000];
    int i, idx;

    write_str("  Binary search on large sorted array...\n");

    /* Fill with even numbers: 0, 2, 4, ..., 1998 */
    for (i = 0; i < 1000; i++) a[i] = i * 2;

    /* Search for every element */
    for (i = 0; i < 1000; i++) {
        idx = binary_search(a, 1000, i * 2);
        if (idx != i) {
            check(0, "bsearch_large/find_all");
            return;
        }
    }
    check(1, "bsearch_large/find_all");

    /* Search for odd numbers (not present) */
    for (i = 0; i < 100; i++) {
        idx = binary_search(a, 1000, i * 2 + 1);
        if (idx != -1) {
            check(0, "bsearch_large/miss_all");
            return;
        }
    }
    check(1, "bsearch_large/miss_all");
}

/* ================================================================
 * Array helper tests
 * ================================================================ */
static void test_array_helpers(void) {
    int a[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    int b[8];
    int rev[8] = {8, 7, 6, 5, 4, 3, 2, 1};

    write_str("  Array helper tests...\n");

    /* Copy */
    array_copy(b, a, 8);
    check(arrays_equal(a, b, 8), "copy/basic");

    /* Reverse */
    array_reverse(b, 8);
    check(arrays_equal(b, rev, 8), "reverse/basic");

    /* Reverse of reverse */
    array_reverse(b, 8);
    check(arrays_equal(a, b, 8), "reverse/double");

    /* is_sorted */
    check(array_is_sorted(a, 8), "is_sorted/sorted");
    check(!array_is_sorted(rev, 8), "is_sorted/reverse");

    /* Single element always sorted */
    check(array_is_sorted(a, 1), "is_sorted/single");

    /* Empty always sorted */
    check(array_is_sorted(a, 0), "is_sorted/empty");

    /* Deterministic random fill */
    array_fill_random(a, 8, 12345);
    array_fill_random(b, 8, 12345);
    check(arrays_equal(a, b, 8), "fill_random/deterministic");

    /* Different seeds give different arrays */
    array_fill_random(b, 8, 54321);
    check(!arrays_equal(a, b, 8), "fill_random/diff_seed");
}

/* ================================================================
 * Cross-sort agreement test: all sorts should produce same output
 * ================================================================ */
static void test_cross_sort_agreement(void) {
    int orig[256];
    int results[10][256];
    int n = 256;
    int i, j, ok;

    write_str("  Cross-sort agreement test...\n");

    array_fill_random(orig, n, 99999);

    array_copy(results[0], orig, n); bubble_sort(results[0], n);
    array_copy(results[1], orig, n); selection_sort(results[1], n);
    array_copy(results[2], orig, n); insertion_sort(results[2], n);
    array_copy(results[3], orig, n); shell_sort(results[3], n);
    array_copy(results[4], orig, n); merge_sort(results[4], n);
    array_copy(results[5], orig, n); quicksort_lomuto(results[5], n);
    array_copy(results[6], orig, n); quicksort_hoare(results[6], n);
    array_copy(results[7], orig, n); heap_sort(results[7], n);
    array_copy(results[8], orig, n); radix_sort(results[8], n);
    array_copy(results[9], orig, n); counting_sort(results[9], n);

    ok = 1;
    for (i = 1; i < 10; i++) {
        for (j = 0; j < n; j++) {
            if (results[i][j] != results[0][j]) {
                ok = 0;
                break;
            }
        }
        if (!ok) break;
    }
    check(ok, "cross_agreement/256");
}

static void test_cross_sort_agreement_large(void) {
    int n = 1000;
    int orig[1000];
    int r0[1000], r1[1000], r2[1000], r3[1000], r4[1000];
    int r5[1000], r6[1000], r7[1000], r8[1000], r9[1000];
    int ok, i;

    write_str("  Cross-sort agreement test (1000 elements)...\n");

    array_fill_random(orig, n, 77777);

    array_copy(r0, orig, n); bubble_sort(r0, n);
    array_copy(r1, orig, n); selection_sort(r1, n);
    array_copy(r2, orig, n); insertion_sort(r2, n);
    array_copy(r3, orig, n); shell_sort(r3, n);
    array_copy(r4, orig, n); merge_sort(r4, n);
    array_copy(r5, orig, n); quicksort_lomuto(r5, n);
    array_copy(r6, orig, n); quicksort_hoare(r6, n);
    array_copy(r7, orig, n); heap_sort(r7, n);
    array_copy(r8, orig, n); radix_sort(r8, n);
    array_copy(r9, orig, n); counting_sort(r9, n);

    ok = 1;
    for (i = 0; i < n && ok; i++) {
        if (r0[i] != r1[i] || r0[i] != r2[i] || r0[i] != r3[i] ||
            r0[i] != r4[i] || r0[i] != r5[i] || r0[i] != r6[i] ||
            r0[i] != r7[i] || r0[i] != r8[i] || r0[i] != r9[i]) {
            ok = 0;
        }
    }
    check(ok, "cross_agreement/1000");
}

/* ================================================================
 * Sort + binary search integration test
 * ================================================================ */
static void test_sort_then_search(void) {
    int a[500];
    int i, idx, ok;

    write_str("  Sort-then-search integration test...\n");

    array_fill_random(a, 500, 42424);
    heap_sort(a, 500);

    /* Every element should be findable */
    ok = 1;
    for (i = 0; i < 500; i++) {
        idx = binary_search(a, 500, a[i]);
        if (idx == -1) { ok = 0; break; }
        if (a[idx] != a[i]) { ok = 0; break; }
    }
    check(ok, "sort_search/heap_then_bsearch");

    /* Different sort, same test */
    array_fill_random(a, 500, 42424);
    quicksort_hoare(a, 500);

    ok = 1;
    for (i = 0; i < 500; i++) {
        idx = binary_search(a, 500, a[i]);
        if (idx == -1) { ok = 0; break; }
        if (a[idx] != a[i]) { ok = 0; break; }
    }
    check(ok, "sort_search/qhoare_then_bsearch");
}

/* ================================================================
 * Stress: sort large random arrays and verify
 * ================================================================ */
static void test_sort_stress(void) {
    int a[1024];
    int n, seed;

    write_str("  Stress test (various seeds)...\n");

    for (seed = 1; seed <= 10; seed++) {
        n = 1024;
        array_fill_random(a, n, (unsigned int)(seed * 7919));

        /* Use a different sort for each seed */
        switch (seed % 10) {
            case 1: bubble_sort(a, 200); n = 200; break;    /* bubble on smaller slice */
            case 2: selection_sort(a, 300); n = 300; break;
            case 3: insertion_sort(a, 400); n = 400; break;
            case 4: shell_sort(a, n); break;
            case 5: merge_sort(a, n); break;
            case 6: quicksort_lomuto(a, n); break;
            case 7: quicksort_hoare(a, n); break;
            case 8: heap_sort(a, n); break;
            case 9: radix_sort(a, n); break;
            case 0: counting_sort(a, n); break;
        }
        {
            char label[32];
            label[0] = 's'; label[1] = 't'; label[2] = 'r'; label[3] = 'e';
            label[4] = 's'; label[5] = 's'; label[6] = '/';
            label[7] = (char)('0' + seed / 10);
            label[8] = (char)('0' + seed % 10);
            label[9] = 0;
            check(array_is_sorted(a, n), label);
        }
    }
}

/* ================================================================
 * Edge cases: already sorted input for quicksort (worst case)
 * ================================================================ */
static void test_quicksort_worst_case(void) {
    int a[200];
    int i;

    write_str("  Quicksort worst-case tests...\n");

    /* Lomuto with sorted input (worst case for naive Lomuto) */
    for (i = 0; i < 200; i++) a[i] = i;
    quicksort_lomuto(a, 200);
    check(array_is_sorted(a, 200), "qlomuto/worst_sorted");

    /* Lomuto with reverse input */
    for (i = 0; i < 200; i++) a[i] = 200 - i;
    quicksort_lomuto(a, 200);
    check(array_is_sorted(a, 200), "qlomuto/worst_reverse");

    /* Hoare with sorted input */
    for (i = 0; i < 200; i++) a[i] = i;
    quicksort_hoare(a, 200);
    check(array_is_sorted(a, 200), "qhoare/worst_sorted");

    /* Hoare with all duplicates */
    for (i = 0; i < 200; i++) a[i] = 7;
    quicksort_hoare(a, 200);
    check(array_is_sorted(a, 200), "qhoare/worst_allsame");
}

/* ================================================================
 * Heap operations: verify max-heap property
 * ================================================================ */
static void test_heap_property(void) {
    int a[100];
    int i, ok;

    write_str("  Heap property tests...\n");

    /* Build array and heapify */
    array_fill_random(a, 100, 55555);

    /* Build max-heap */
    for (i = (100 - 2) / 2; i >= 0; i--) {
        sift_down(a, i, 99);
    }

    /* Verify max-heap property: parent >= children */
    ok = 1;
    for (i = 0; i < 50; i++) {
        if (2*i+1 < 100 && a[i] < a[2*i+1]) ok = 0;
        if (2*i+2 < 100 && a[i] < a[2*i+2]) ok = 0;
    }
    check(ok, "heap/property");

    /* Root should be maximum */
    {
        int max_val = a[0];
        ok = 1;
        for (i = 1; i < 100; i++) {
            if (a[i] > max_val) { ok = 0; break; }
        }
        check(ok, "heap/root_is_max");
    }
}

/* ================================================================
 * Counting sort / radix sort with narrow range
 * ================================================================ */
static void test_counting_narrow(void) {
    int a[50];
    int i;

    write_str("  Counting sort narrow range tests...\n");

    /* All zeros */
    for (i = 0; i < 50; i++) a[i] = 0;
    counting_sort(a, 50);
    check(array_is_sorted(a, 50), "counting/all_zero");

    /* Range [0,1] */
    lcg_seed(11111);
    for (i = 0; i < 50; i++) a[i] = lcg_next() % 2;
    counting_sort(a, 50);
    check(array_is_sorted(a, 50), "counting/binary");

    /* Negative range only */
    for (i = 0; i < 50; i++) a[i] = -50 + i;
    array_reverse(a, 50);
    counting_sort(a, 50);
    check(array_is_sorted(a, 50), "counting/negative_only");
}

static void test_radix_narrow(void) {
    int a[50];
    int i;

    write_str("  Radix sort narrow range tests...\n");

    for (i = 0; i < 50; i++) a[i] = 0;
    radix_sort(a, 50);
    check(array_is_sorted(a, 50), "radix/all_zero");

    lcg_seed(22222);
    for (i = 0; i < 50; i++) a[i] = lcg_next() % 2;
    radix_sort(a, 50);
    check(array_is_sorted(a, 50), "radix/binary");

    for (i = 0; i < 50; i++) a[i] = -50 + i;
    array_reverse(a, 50);
    radix_sort(a, 50);
    check(array_is_sorted(a, 50), "radix/negative_only");
}

/* ================================================================
 * Shell sort gap sequence verification
 * ================================================================ */
static void test_shell_sort_specific(void) {
    int a[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int expected[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

    write_str("  Shell sort specific tests...\n");

    shell_sort(a, 16);
    check(arrays_equal(a, expected, 16), "shell/reverse16");

    /* Already sorted */
    shell_sort(a, 16);
    check(arrays_equal(a, expected, 16), "shell/already_sorted");
}

/* ================================================================
 * Merge sort stability-like test (verifying aux array works)
 * ================================================================ */
static void test_merge_sort_specific(void) {
    int a[8] = {38, 27, 43, 3, 9, 82, 10, 1};
    int expected[8] = {1, 3, 9, 10, 27, 38, 43, 82};

    write_str("  Merge sort specific tests...\n");

    merge_sort(a, 8);
    check(arrays_equal(a, expected, 8), "merge/specific8");

    /* Power of 2 size */
    {
        int b[16];
        int i;
        for (i = 0; i < 16; i++) b[i] = 16 - i;
        merge_sort(b, 16);
        check(array_is_sorted(b, 16), "merge/pow2_16");
    }

    /* Non-power of 2 size */
    {
        int c[13];
        int i;
        for (i = 0; i < 13; i++) c[i] = 13 - i;
        merge_sort(c, 13);
        check(array_is_sorted(c, 13), "merge/nonpow2_13");
    }
}

/* ================================================================
 * Large array sort tests (500-1000 elements)
 * ================================================================ */
static void test_large_sorts(void) {
    int a[1000];
    int seed;

    write_str("  Large array sort tests...\n");

    /* Shell sort on 1000 elements, multiple seeds */
    for (seed = 100; seed <= 105; seed++) {
        array_fill_random(a, 1000, (unsigned int)seed);
        shell_sort(a, 1000);
        {
            char label[32];
            int k = 0;
            const char *p = "shell/large/";
            while (*p) label[k++] = *p++;
            label[k++] = (char)('0' + seed - 100);
            label[k] = 0;
            check(array_is_sorted(a, 1000), label);
        }
    }

    /* Merge sort on 1000 elements */
    for (seed = 200; seed <= 205; seed++) {
        array_fill_random(a, 1000, (unsigned int)seed);
        merge_sort(a, 1000);
        {
            char label[32];
            int k = 0;
            const char *p = "merge/large/";
            while (*p) label[k++] = *p++;
            label[k++] = (char)('0' + seed - 200);
            label[k] = 0;
            check(array_is_sorted(a, 1000), label);
        }
    }

    /* Heap sort on 1000 elements */
    for (seed = 300; seed <= 305; seed++) {
        array_fill_random(a, 1000, (unsigned int)seed);
        heap_sort(a, 1000);
        {
            char label[32];
            int k = 0;
            const char *p = "heap/large/";
            while (*p) label[k++] = *p++;
            label[k++] = (char)('0' + seed - 300);
            label[k] = 0;
            check(array_is_sorted(a, 1000), label);
        }
    }

    /* Radix sort on 1000 elements */
    for (seed = 400; seed <= 405; seed++) {
        array_fill_random(a, 1000, (unsigned int)seed);
        radix_sort(a, 1000);
        {
            char label[32];
            int k = 0;
            const char *p = "radix/large/";
            while (*p) label[k++] = *p++;
            label[k++] = (char)('0' + seed - 400);
            label[k] = 0;
            check(array_is_sorted(a, 1000), label);
        }
    }

    /* Counting sort on 1000 elements */
    for (seed = 500; seed <= 505; seed++) {
        array_fill_random(a, 1000, (unsigned int)seed);
        counting_sort(a, 1000);
        {
            char label[32];
            int k = 0;
            const char *p = "counting/large/";
            while (*p) label[k++] = *p++;
            label[k++] = (char)('0' + seed - 500);
            label[k] = 0;
            check(array_is_sorted(a, 1000), label);
        }
    }
}

/* ================================================================
 * Exhaustive small array permutation test (insertion sort, n=5)
 * ================================================================ */
static void test_exhaustive_small(void) {
    int a[5], perm[5];
    int i, j, k, l, m, ok;

    write_str("  Exhaustive permutation test (n=5, insertion sort)...\n");

    ok = 1;
    for (i = 0; i < 5 && ok; i++) {
    for (j = 0; j < 5 && ok; j++) { if (j==i) continue;
    for (k = 0; k < 5 && ok; k++) { if (k==i||k==j) continue;
    for (l = 0; l < 5 && ok; l++) { if (l==i||l==j||l==k) continue;
    for (m = 0; m < 5 && ok; m++) { if (m==i||m==j||m==k||m==l) continue;
        a[0]=i; a[1]=j; a[2]=k; a[3]=l; a[4]=m;
        array_copy(perm, a, 5);
        insertion_sort(perm, 5);
        if (!array_is_sorted(perm, 5)) ok = 0;
    }}}}}
    check(ok, "exhaustive/insertion5");
}

/* ================================================================
 * Idempotency: sorting an already-sorted array
 * ================================================================ */
static void test_idempotency(void) {
    int a[100], b[100];
    int i;

    write_str("  Idempotency tests...\n");

    for (i = 0; i < 100; i++) a[i] = i * 3;

    array_copy(b, a, 100); bubble_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/bubble");

    array_copy(b, a, 100); selection_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/selection");

    array_copy(b, a, 100); insertion_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/insertion");

    array_copy(b, a, 100); shell_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/shell");

    array_copy(b, a, 100); merge_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/merge");

    array_copy(b, a, 100); quicksort_lomuto(b, 100);
    check(arrays_equal(a, b, 100), "idem/qlomuto");

    array_copy(b, a, 100); quicksort_hoare(b, 100);
    check(arrays_equal(a, b, 100), "idem/qhoare");

    array_copy(b, a, 100); heap_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/heap");

    array_copy(b, a, 100); radix_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/radix");

    array_copy(b, a, 100); counting_sort(b, 100);
    check(arrays_equal(a, b, 100), "idem/counting");
}

/* ================================================================
 * Reverse-then-sort consistency test
 * ================================================================ */
static void test_reverse_sort(void) {
    int a[200], b[200];

    write_str("  Reverse-then-sort consistency...\n");

    array_fill_random(a, 200, 31337);
    array_copy(b, a, 200);

    /* Sort a normally */
    heap_sort(a, 200);

    /* Reverse b, then sort */
    array_reverse(b, 200);
    heap_sort(b, 200);

    check(arrays_equal(a, b, 200), "rev_sort/heap");

    /* Same with merge sort */
    array_fill_random(a, 200, 31337);
    array_copy(b, a, 200);
    merge_sort(a, 200);
    array_reverse(b, 200);
    merge_sort(b, 200);
    check(arrays_equal(a, b, 200), "rev_sort/merge");
}

/* ================================================================
 * Partition correctness test
 * ================================================================ */
static void test_partition_correctness(void) {
    int a[20] = {15, 3, 9, 8, 2, 7, 1, 6, 10, 14, 4, 11, 5, 12, 0, 13, 19, 16, 17, 18};
    int b[20];
    int pivot_idx, i, ok;

    write_str("  Partition correctness tests...\n");

    /* Lomuto partition */
    array_copy(b, a, 20);
    pivot_idx = lomuto_partition(b, 0, 19);
    ok = 1;
    for (i = 0; i < pivot_idx; i++) {
        if (b[i] > b[pivot_idx]) { ok = 0; break; }
    }
    for (i = pivot_idx + 1; i < 20; i++) {
        if (b[i] < b[pivot_idx]) { ok = 0; break; }
    }
    check(ok, "partition/lomuto_correct");

    /* Hoare partition */
    array_copy(b, a, 20);
    pivot_idx = hoare_partition(b, 0, 19);
    ok = 1;
    /* Hoare: everything at or left of pivot_idx <= everything right of pivot_idx */
    {
        int max_left = b[0];
        int min_right = b[pivot_idx + 1];
        for (i = 1; i <= pivot_idx; i++) {
            if (b[i] > max_left) max_left = b[i];
        }
        for (i = pivot_idx + 2; i < 20; i++) {
            if (b[i] < min_right) min_right = b[i];
        }
        if (max_left > min_right) ok = 0;
    }
    check(ok, "partition/hoare_correct");
}

/* ================================================================
 * Sorting preserves multiset (count each element)
 * ================================================================ */
static void test_sort_preserves_multiset(void) {
    int orig[100];
    int sorted[100];
    int count_orig[201]; /* values in [-100, 100] */
    int count_sorted[201];
    int i, ok;

    write_str("  Sort preserves multiset tests...\n");

    lcg_seed(77777);
    for (i = 0; i < 100; i++) {
        orig[i] = lcg_next_range(-100, 100);
    }
    array_copy(sorted, orig, 100);
    merge_sort(sorted, 100);

    /* Count elements in both */
    for (i = 0; i < 201; i++) { count_orig[i] = 0; count_sorted[i] = 0; }
    for (i = 0; i < 100; i++) {
        count_orig[orig[i] + 100]++;
        count_sorted[sorted[i] + 100]++;
    }

    ok = 1;
    for (i = 0; i < 201; i++) {
        if (count_orig[i] != count_sorted[i]) { ok = 0; break; }
    }
    check(ok, "multiset/merge");

    /* Same test with quicksort Hoare */
    array_copy(sorted, orig, 100);
    quicksort_hoare(sorted, 100);

    for (i = 0; i < 201; i++) count_sorted[i] = 0;
    for (i = 0; i < 100; i++) count_sorted[sorted[i] + 100]++;

    ok = 1;
    for (i = 0; i < 201; i++) {
        if (count_orig[i] != count_sorted[i]) { ok = 0; break; }
    }
    check(ok, "multiset/qhoare");

    /* Same test with radix sort */
    array_copy(sorted, orig, 100);
    radix_sort(sorted, 100);

    for (i = 0; i < 201; i++) count_sorted[i] = 0;
    for (i = 0; i < 100; i++) count_sorted[sorted[i] + 100]++;

    ok = 1;
    for (i = 0; i < 201; i++) {
        if (count_orig[i] != count_sorted[i]) { ok = 0; break; }
    }
    check(ok, "multiset/radix");

    /* Same test with heap sort */
    array_copy(sorted, orig, 100);
    heap_sort(sorted, 100);

    for (i = 0; i < 201; i++) count_sorted[i] = 0;
    for (i = 0; i < 100; i++) count_sorted[sorted[i] + 100]++;

    ok = 1;
    for (i = 0; i < 201; i++) {
        if (count_orig[i] != count_sorted[i]) { ok = 0; break; }
    }
    check(ok, "multiset/heap");
}

/* ================================================================
 * Sorting stability indicator (insertion sort is stable)
 * ================================================================ */
static void test_insertion_sort_stability(void) {
    /* Use pairs: sort by first element, check second preserves order */
    int keys[8] = {3, 1, 4, 1, 5, 9, 2, 6};
    int vals[8] = {0, 1, 2, 3, 4, 5, 6, 7};
    int i, j, t;

    write_str("  Insertion sort stability test...\n");

    /* Stable sort by keys using insertion sort */
    for (i = 1; i < 8; i++) {
        int kk = keys[i], vv = vals[i];
        j = i - 1;
        while (j >= 0 && keys[j] > kk) {
            keys[j+1] = keys[j];
            vals[j+1] = vals[j];
            j--;
        }
        keys[j+1] = kk;
        vals[j+1] = vv;
    }

    /* Check keys are sorted */
    check(array_is_sorted(keys, 8), "stability/keys_sorted");

    /* Check stability: for equal keys, vals should be in original order */
    /* keys[1] and keys[2] should both be 1, with vals 1 then 3 */
    {
        int stable = 1;
        for (i = 0; i < 7; i++) {
            if (keys[i] == keys[i+1] && vals[i] > vals[i+1]) {
                stable = 0;
                break;
            }
        }
        check(stable, "stability/insertion_stable");
    }
}

/* ================================================================
 * Large descending sort test (selection sort, limited size)
 * ================================================================ */
static void test_selection_sort_descending(void) {
    int a[300];
    int i;

    write_str("  Selection sort descending tests...\n");

    for (i = 0; i < 300; i++) a[i] = 300 - i;
    selection_sort(a, 300);
    check(array_is_sorted(a, 300), "selection/desc300");

    /* Verify first and last */
    check(a[0] == 1, "selection/desc300_first");
    check(a[299] == 300, "selection/desc300_last");
}

/* ================================================================
 * Alternating pattern sort test
 * ================================================================ */
static void test_alternating_pattern(void) {
    int a[100];
    int i;

    write_str("  Alternating pattern sort tests...\n");

    /* Sawtooth: 0,99,1,98,2,97,... */
    for (i = 0; i < 100; i++) {
        if (i % 2 == 0) a[i] = i / 2;
        else a[i] = 99 - i / 2;
    }

    {
        int b[100];
        array_copy(b, a, 100); shell_sort(b, 100);
        check(array_is_sorted(b, 100), "alternating/shell");

        array_copy(b, a, 100); merge_sort(b, 100);
        check(array_is_sorted(b, 100), "alternating/merge");

        array_copy(b, a, 100); quicksort_lomuto(b, 100);
        check(array_is_sorted(b, 100), "alternating/qlomuto");

        array_copy(b, a, 100); quicksort_hoare(b, 100);
        check(array_is_sorted(b, 100), "alternating/qhoare");

        array_copy(b, a, 100); heap_sort(b, 100);
        check(array_is_sorted(b, 100), "alternating/heap");

        array_copy(b, a, 100); radix_sort(b, 100);
        check(array_is_sorted(b, 100), "alternating/radix");

        array_copy(b, a, 100); counting_sort(b, 100);
        check(array_is_sorted(b, 100), "alternating/counting");
    }

    /* Organ pipe: 0,1,2,...,49,49,...,2,1,0 */
    for (i = 0; i < 50; i++) a[i] = i;
    for (i = 50; i < 100; i++) a[i] = 99 - i;
    {
        int b[100];
        array_copy(b, a, 100); shell_sort(b, 100);
        check(array_is_sorted(b, 100), "organ_pipe/shell");

        array_copy(b, a, 100); heap_sort(b, 100);
        check(array_is_sorted(b, 100), "organ_pipe/heap");

        array_copy(b, a, 100); merge_sort(b, 100);
        check(array_is_sorted(b, 100), "organ_pipe/merge");

        array_copy(b, a, 100); quicksort_hoare(b, 100);
        check(array_is_sorted(b, 100), "organ_pipe/qhoare");
    }
}

/* ================================================================
 * Binary search edge: search in 2-element array
 * ================================================================ */
static void test_binary_search_edge(void) {
    int a2[2] = {10, 20};
    int idx;

    write_str("  Binary search edge cases...\n");

    idx = binary_search(a2, 2, 10);
    check(idx == 0, "bsearch_edge/find_first");

    idx = binary_search(a2, 2, 20);
    check(idx == 1, "bsearch_edge/find_second");

    idx = binary_search(a2, 2, 5);
    check(idx == -1, "bsearch_edge/miss_lo");

    idx = binary_search(a2, 2, 15);
    check(idx == -1, "bsearch_edge/miss_mid");

    idx = binary_search(a2, 2, 25);
    check(idx == -1, "bsearch_edge/miss_hi");

    /* Search in 3-element array */
    {
        int a3[3] = {1, 1, 1};
        idx = binary_search(a3, 3, 1);
        check(idx >= 0 && idx <= 2, "bsearch_edge/all_same");

        idx = binary_search(a3, 3, 0);
        check(idx == -1, "bsearch_edge/all_same_miss");
    }
}

/* ================================================================
 * Counting sort with large range
 * ================================================================ */
static void test_counting_large_range(void) {
    int a[50];
    int i;

    write_str("  Counting sort large range...\n");

    /* Values spread from -5000 to 5000 */
    lcg_seed(88888);
    for (i = 0; i < 50; i++) a[i] = lcg_next_range(-5000, 5000);
    counting_sort(a, 50);
    check(array_is_sorted(a, 50), "counting/large_range");
}

/* ================================================================
 * main
 * ================================================================ */
int main(void) {
    g_errs = 0;
    init_io();

    write_str("=== victim_sort.c test suite ===\n\n");

    /* Section 1: Bubble sort full pattern tests */
    write_str("[Bubble sort]\n");
    test_sort_all_patterns(bubble_sort, "bubble", 500);

    /* Section 2: Selection sort full pattern tests */
    write_str("[Selection sort]\n");
    test_sort_all_patterns(selection_sort, "selection", 500);

    /* Section 3: Insertion sort full pattern tests */
    write_str("[Insertion sort]\n");
    test_sort_all_patterns(insertion_sort, "insertion", 1000);

    /* Section 4: Shell sort full pattern tests */
    write_str("[Shell sort]\n");
    test_sort_all_patterns(shell_sort, "shell", 1000);

    /* Section 5: Merge sort full pattern tests */
    write_str("[Merge sort]\n");
    test_sort_all_patterns(merge_sort, "merge", 1000);

    /* Section 6: Quicksort Lomuto full pattern tests */
    write_str("[Quicksort Lomuto]\n");
    test_sort_all_patterns(quicksort_lomuto, "qlomuto", 1000);

    /* Section 7: Quicksort Hoare full pattern tests */
    write_str("[Quicksort Hoare]\n");
    test_sort_all_patterns(quicksort_hoare, "qhoare", 1000);

    /* Section 8: Heap sort full pattern tests */
    write_str("[Heap sort]\n");
    test_sort_all_patterns(heap_sort, "heap", 1000);

    /* Section 9: Radix sort full pattern tests */
    write_str("[Radix sort]\n");
    test_sort_all_patterns(radix_sort, "radix", 1000);

    /* Section 10: Counting sort full pattern tests */
    write_str("[Counting sort]\n");
    test_sort_all_patterns(counting_sort, "counting", 1000);

    /* Section 11: Specific correctness checks */
    write_str("\n[Specific correctness checks]\n");
    test_sort_stability_check();
    test_sort_negative_values();
    test_sort_single_element();
    test_sort_two_elements();
    test_sort_duplicates();

    /* Section 12: Binary search */
    write_str("\n[Binary search]\n");
    test_binary_search();
    test_binary_search_first_last();
    test_binary_search_large();

    /* Section 13: Array helpers */
    write_str("\n[Array helpers]\n");
    test_array_helpers();

    /* Section 14: Cross-sort agreement */
    write_str("\n[Cross-sort agreement]\n");
    test_cross_sort_agreement();
    test_cross_sort_agreement_large();

    /* Section 15: Sort + search integration */
    write_str("\n[Sort + search integration]\n");
    test_sort_then_search();

    /* Section 16: Stress tests */
    write_str("\n[Stress tests]\n");
    test_sort_stress();

    /* Section 17: Quicksort worst-case */
    write_str("\n[Quicksort worst-case]\n");
    test_quicksort_worst_case();

    /* Section 18: Heap property */
    write_str("\n[Heap property]\n");
    test_heap_property();

    /* Section 19: Narrow range sorts */
    write_str("\n[Narrow range sorts]\n");
    test_counting_narrow();
    test_radix_narrow();

    /* Section 20: Shell sort specific */
    write_str("\n[Shell sort specific]\n");
    test_shell_sort_specific();

    /* Section 21: Merge sort specific */
    write_str("\n[Merge sort specific]\n");
    test_merge_sort_specific();

    /* Section 22: Large array sorts */
    write_str("\n[Large array sorts]\n");
    test_large_sorts();

    /* Section 23: Exhaustive small permutation */
    write_str("\n[Exhaustive small permutation]\n");
    test_exhaustive_small();

    /* Section 24: Idempotency */
    write_str("\n[Idempotency]\n");
    test_idempotency();

    /* Section 25: Reverse-sort consistency */
    write_str("\n[Reverse-sort consistency]\n");
    test_reverse_sort();

    /* Section 26: Partition correctness */
    write_str("\n[Partition correctness]\n");
    test_partition_correctness();

    /* Section 27: Multiset preservation */
    write_str("\n[Multiset preservation]\n");
    test_sort_preserves_multiset();

    /* Section 28: Insertion sort stability */
    write_str("\n[Insertion sort stability]\n");
    test_insertion_sort_stability();

    /* Section 29: Selection sort descending */
    write_str("\n[Selection sort descending]\n");
    test_selection_sort_descending();

    /* Section 30: Alternating patterns */
    write_str("\n[Alternating patterns]\n");
    test_alternating_pattern();

    /* Section 31: Binary search edges */
    write_str("\n[Binary search edges]\n");
    test_binary_search_edge();

    /* Section 32: Counting sort large range */
    write_str("\n[Counting sort large range]\n");
    test_counting_large_range();

    write_str("\n=== Done ===\n");
    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
