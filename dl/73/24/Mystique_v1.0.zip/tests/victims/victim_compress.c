/*
 * victim_compress.c - Compression and encoding stress test (Windows x86-32, MSVC)
 * Build: cl /nologo /O1 victim_compress.c /Fe:victim_compress.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 *
 * All algorithms fully implemented with round-trip tests.
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ========================================================================
 * LCG-based PRNG for deterministic test data
 * ======================================================================== */

static unsigned int lcg_state;
static void lcg_seed(unsigned int s) { lcg_state = s; }
static unsigned int lcg_next(void) {
    lcg_state = lcg_state * 1103515245u + 12345u;
    return (lcg_state >> 16) & 0x7fff;
}
static unsigned char lcg_byte(void) { return (unsigned char)(lcg_next() & 0xff); }

/* ========================================================================
 * Utility: compare byte arrays
 * ======================================================================== */

static int mem_eq(const unsigned char* a, const unsigned char* b, int len) {
    int i;
    for (i = 0; i < len; i++)
        if (a[i] != b[i]) return 0;
    return 1;
}

/* Maximum buffer sizes for tests */
#define MAX_BUF 4096
#define MAX_DATA 512

/* ========================================================================
 * 1. Run-Length Encoding (RLE)
 * Format: [count][byte] pairs. Count is 1-255.
 * ======================================================================== */

static int rle_encode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i < in_len) {
        unsigned char val = in[i];
        int count = 1;
        while (i + count < in_len && in[i + count] == val && count < 255)
            count++;
        if (o + 2 > out_max) return -1;
        out[o++] = (unsigned char)count;
        out[o++] = val;
        i += count;
    }
    return o;
}

static int rle_decode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i + 1 < in_len) {
        int count = in[i];
        unsigned char val = in[i + 1];
        int j;
        if (o + count > out_max) return -1;
        for (j = 0; j < count; j++)
            out[o++] = val;
        i += 2;
    }
    return o;
}

/* ========================================================================
 * 2. LZ77-like Compression (sliding window)
 * Token format: [flag_byte] then either:
 *   flag=0: [literal_byte]
 *   flag=1: [offset_hi][offset_lo][length] (offset as 16-bit, length 8-bit)
 * Window size: 256 bytes, max match: 255
 * ======================================================================== */

static int lz77_encode(const unsigned char* in, int in_len,
                       unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i < in_len) {
        int best_off = 0, best_len = 0;
        int win_start = (i > 256) ? i - 256 : 0;
        int j;

        /* Find longest match in window */
        for (j = win_start; j < i; j++) {
            int k = 0;
            while (i + k < in_len && k < 255 && in[j + k] == in[i + k])
                k++;
            if (k > best_len && k >= 3) {
                best_len = k;
                best_off = i - j;
            }
        }

        if (best_len >= 3) {
            if (o + 4 > out_max) return -1;
            out[o++] = 1; /* match flag */
            out[o++] = (unsigned char)((best_off >> 8) & 0xff);
            out[o++] = (unsigned char)(best_off & 0xff);
            out[o++] = (unsigned char)best_len;
            i += best_len;
        } else {
            if (o + 2 > out_max) return -1;
            out[o++] = 0; /* literal flag */
            out[o++] = in[i];
            i++;
        }
    }
    return o;
}

static int lz77_decode(const unsigned char* in, int in_len,
                       unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i < in_len) {
        if (in[i] == 0) {
            /* Literal */
            if (i + 1 >= in_len || o >= out_max) return -1;
            out[o++] = in[i + 1];
            i += 2;
        } else if (in[i] == 1) {
            /* Match */
            int offset, length, j;
            if (i + 3 >= in_len) return -1;
            offset = (in[i + 1] << 8) | in[i + 2];
            length = in[i + 3];
            if (o + length > out_max || offset > o || offset <= 0) return -1;
            for (j = 0; j < length; j++)
                out[o + j] = out[o - offset + j];
            o += length;
            i += 4;
        } else {
            return -1;
        }
    }
    return o;
}

/* ========================================================================
 * 3. Huffman Coding
 * Simplified: uses frequency-based tree, max 256 symbols.
 * Encodes to bit stream packed in bytes.
 * ======================================================================== */

#define HUFF_MAX_SYMBOLS 256
#define HUFF_MAX_NODES 512
#define HUFF_MAX_CODE_LEN 32

typedef struct {
    int freq;
    int left, right;    /* child indices, -1 = leaf */
    int symbol;         /* valid for leaves */
    int parent;
} HuffNode;

typedef struct {
    unsigned char bits[HUFF_MAX_CODE_LEN];
    int length;
} HuffCode;

static int huff_build_tree(const unsigned char* data, int data_len,
                           HuffNode nodes[HUFF_MAX_NODES], int* root) {
    int freq[HUFF_MAX_SYMBOLS];
    int node_count = 0;
    int active[HUFF_MAX_NODES]; /* indices of active nodes */
    int active_count = 0;
    int i, j;

    memset(freq, 0, sizeof(freq));
    for (i = 0; i < data_len; i++)
        freq[data[i]]++;

    /* Create leaf nodes for each symbol with non-zero frequency */
    for (i = 0; i < HUFF_MAX_SYMBOLS; i++) {
        if (freq[i] > 0) {
            nodes[node_count].freq = freq[i];
            nodes[node_count].left = -1;
            nodes[node_count].right = -1;
            nodes[node_count].symbol = i;
            nodes[node_count].parent = -1;
            active[active_count++] = node_count;
            node_count++;
        }
    }

    if (active_count == 0) { *root = -1; return 0; }
    if (active_count == 1) {
        /* Single symbol: create a dummy parent */
        nodes[node_count].freq = nodes[active[0]].freq;
        nodes[node_count].left = active[0];
        nodes[node_count].right = -1;
        nodes[node_count].symbol = -1;
        nodes[node_count].parent = -1;
        nodes[active[0]].parent = node_count;
        *root = node_count;
        node_count++;
        return node_count;
    }

    /* Build tree by repeatedly combining two lowest-frequency nodes */
    while (active_count > 1) {
        int min1 = -1, min2 = -1;
        int min1_idx = -1, min2_idx = -1;

        /* Find two nodes with smallest frequency */
        for (i = 0; i < active_count; i++) {
            int f = nodes[active[i]].freq;
            if (min1 == -1 || f < nodes[active[min1_idx]].freq) {
                min2 = min1; min2_idx = min1_idx;
                min1 = active[i]; min1_idx = i;
            } else if (min2 == -1 || f < nodes[active[min2_idx]].freq) {
                min2 = active[i]; min2_idx = i;
            }
        }

        /* Create new internal node */
        nodes[node_count].freq = nodes[min1].freq + nodes[min2].freq;
        nodes[node_count].left = min1;
        nodes[node_count].right = min2;
        nodes[node_count].symbol = -1;
        nodes[node_count].parent = -1;
        nodes[min1].parent = node_count;
        nodes[min2].parent = node_count;

        /* Remove min1 and min2, add new node */
        /* Remove higher index first to not invalidate lower */
        if (min1_idx > min2_idx) {
            active[min1_idx] = active[--active_count];
            active[min2_idx] = active[--active_count];
        } else {
            active[min2_idx] = active[--active_count];
            active[min1_idx] = active[--active_count];
        }
        active[active_count++] = node_count;
        node_count++;
    }

    *root = active[0];
    return node_count;
}

static void huff_build_codes(HuffNode nodes[HUFF_MAX_NODES], int node_idx,
                              HuffCode codes[HUFF_MAX_SYMBOLS],
                              unsigned char path[], int depth) {
    if (node_idx < 0) return;
    if (nodes[node_idx].left == -1 && nodes[node_idx].right == -1) {
        /* Leaf */
        int sym = nodes[node_idx].symbol;
        int i;
        codes[sym].length = (depth == 0) ? 1 : depth;
        for (i = 0; i < depth; i++)
            codes[sym].bits[i] = path[i];
        if (depth == 0)
            codes[sym].bits[0] = 0; /* single symbol case */
        return;
    }
    if (nodes[node_idx].left >= 0) {
        path[depth] = 0;
        huff_build_codes(nodes, nodes[node_idx].left, codes, path, depth + 1);
    }
    if (nodes[node_idx].right >= 0) {
        path[depth] = 1;
        huff_build_codes(nodes, nodes[node_idx].right, codes, path, depth + 1);
    }
}

static int huff_encode(const unsigned char* data, int data_len,
                       HuffCode codes[HUFF_MAX_SYMBOLS],
                       unsigned char* out, int out_max) {
    int o = 0;
    int bit_pos = 0;
    int i, j;

    memset(out, 0, out_max);
    for (i = 0; i < data_len; i++) {
        HuffCode* c = &codes[data[i]];
        for (j = 0; j < c->length; j++) {
            int byte_idx = bit_pos / 8;
            int bit_idx = bit_pos % 8;
            if (byte_idx >= out_max) return -1;
            if (c->bits[j])
                out[byte_idx] |= (unsigned char)(1 << bit_idx);
            bit_pos++;
        }
    }
    o = (bit_pos + 7) / 8;
    return o;
}

static int huff_decode(const unsigned char* bits, int total_bits,
                       HuffNode nodes[HUFF_MAX_NODES], int root,
                       unsigned char* out, int out_max) {
    int o = 0, bp = 0;
    int cur;

    if (root < 0) return 0;

    /* Single-symbol tree */
    if (nodes[root].left >= 0 && nodes[root].right < 0) {
        int sym = nodes[nodes[root].left].symbol;
        while (bp < total_bits) {
            if (o >= out_max) return -1;
            out[o++] = (unsigned char)sym;
            bp++;
        }
        return o;
    }

    cur = root;
    while (bp < total_bits) {
        int byte_idx = bp / 8;
        int bit_idx = bp % 8;
        int bit = (bits[byte_idx] >> bit_idx) & 1;
        bp++;

        if (bit == 0) cur = nodes[cur].left;
        else cur = nodes[cur].right;

        if (cur < 0) return -1;

        if (nodes[cur].left == -1 && nodes[cur].right == -1) {
            if (o >= out_max) return -1;
            out[o++] = (unsigned char)nodes[cur].symbol;
            cur = root;
        }
    }
    return o;
}

/* ========================================================================
 * 4. Delta Encoding
 * First byte stored as-is, then differences.
 * ======================================================================== */

static int delta_encode(const unsigned char* in, int in_len,
                        unsigned char* out, int out_max) {
    int i;
    if (in_len == 0) return 0;
    if (in_len > out_max) return -1;
    out[0] = in[0];
    for (i = 1; i < in_len; i++)
        out[i] = (unsigned char)(in[i] - in[i - 1]);
    return in_len;
}

static int delta_decode(const unsigned char* in, int in_len,
                        unsigned char* out, int out_max) {
    int i;
    if (in_len == 0) return 0;
    if (in_len > out_max) return -1;
    out[0] = in[0];
    for (i = 1; i < in_len; i++)
        out[i] = (unsigned char)(in[i] + out[i - 1]);
    return in_len;
}

/* ========================================================================
 * 5. Bit-Packing (N-bit values into byte stream)
 * ======================================================================== */

static int bitpack_encode(const unsigned char* values, int count, int bits_per_val,
                          unsigned char* out, int out_max) {
    int bp = 0, i, j;
    int total_bytes;

    memset(out, 0, out_max);
    for (i = 0; i < count; i++) {
        int val = values[i] & ((1 << bits_per_val) - 1);
        for (j = 0; j < bits_per_val; j++) {
            int byte_idx = bp / 8;
            int bit_idx = bp % 8;
            if (byte_idx >= out_max) return -1;
            if ((val >> j) & 1)
                out[byte_idx] |= (unsigned char)(1 << bit_idx);
            bp++;
        }
    }
    total_bytes = (bp + 7) / 8;
    return total_bytes;
}

static int bitpack_decode(const unsigned char* in, int count, int bits_per_val,
                          unsigned char* out, int out_max) {
    int bp = 0, i, j;
    if (count > out_max) return -1;
    for (i = 0; i < count; i++) {
        int val = 0;
        for (j = 0; j < bits_per_val; j++) {
            int byte_idx = bp / 8;
            int bit_idx = bp % 8;
            if ((in[byte_idx] >> bit_idx) & 1)
                val |= (1 << j);
            bp++;
        }
        out[i] = (unsigned char)val;
    }
    return count;
}

/* ========================================================================
 * 6. Move-to-Front Transform
 * ======================================================================== */

static int mtf_encode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max) {
    unsigned char alphabet[256];
    int i, j;

    if (in_len > out_max) return -1;
    for (i = 0; i < 256; i++) alphabet[i] = (unsigned char)i;

    for (i = 0; i < in_len; i++) {
        unsigned char ch = in[i];
        int pos = 0;
        /* Find position of ch in alphabet */
        for (j = 0; j < 256; j++) {
            if (alphabet[j] == ch) { pos = j; break; }
        }
        out[i] = (unsigned char)pos;
        /* Move to front */
        for (j = pos; j > 0; j--)
            alphabet[j] = alphabet[j - 1];
        alphabet[0] = ch;
    }
    return in_len;
}

static int mtf_decode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max) {
    unsigned char alphabet[256];
    int i, j;

    if (in_len > out_max) return -1;
    for (i = 0; i < 256; i++) alphabet[i] = (unsigned char)i;

    for (i = 0; i < in_len; i++) {
        int pos = in[i];
        unsigned char ch = alphabet[pos];
        out[i] = ch;
        /* Move to front */
        for (j = pos; j > 0; j--)
            alphabet[j] = alphabet[j - 1];
        alphabet[0] = ch;
    }
    return in_len;
}

/* ========================================================================
 * 7. Burrows-Wheeler-like Transform (simplified, for short strings)
 * Max input: 64 bytes
 * ======================================================================== */

#define BWT_MAX 64

static void bwt_get_rotation(const unsigned char* in, int n, int start,
                              unsigned char* rot) {
    int i;
    for (i = 0; i < n; i++)
        rot[i] = in[(start + i) % n];
}

static int bwt_compare_rotations(const unsigned char* in, int n, int a, int b) {
    int i;
    for (i = 0; i < n; i++) {
        int ca = in[(a + i) % n];
        int cb = in[(b + i) % n];
        if (ca < cb) return -1;
        if (ca > cb) return 1;
    }
    return 0;
}

static int bwt_encode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max, int* orig_index) {
    int indices[BWT_MAX];
    int i, j, tmp;

    if (in_len > BWT_MAX || in_len > out_max || in_len == 0) return -1;

    /* Initialize rotation indices */
    for (i = 0; i < in_len; i++) indices[i] = i;

    /* Sort rotations (insertion sort for simplicity) */
    for (i = 1; i < in_len; i++) {
        tmp = indices[i];
        j = i - 1;
        while (j >= 0 && bwt_compare_rotations(in, in_len, indices[j], tmp) > 0) {
            indices[j + 1] = indices[j];
            j--;
        }
        indices[j + 1] = tmp;
    }

    /* Output: last column of sorted rotation matrix */
    *orig_index = -1;
    for (i = 0; i < in_len; i++) {
        out[i] = in[(indices[i] + in_len - 1) % in_len];
        if (indices[i] == 0) *orig_index = i;
    }

    return in_len;
}

static int bwt_decode(const unsigned char* in, int in_len,
                      unsigned char* out, int out_max, int orig_index) {
    /* Reconstruct using the "inverse BWT" algorithm */
    int count[256];
    int cumul[256];
    int transform[BWT_MAX];
    int i, idx;

    if (in_len > BWT_MAX || in_len > out_max || in_len == 0) return -1;

    memset(count, 0, sizeof(count));
    for (i = 0; i < in_len; i++)
        count[in[i]]++;

    /* Cumulative counts */
    cumul[0] = 0;
    for (i = 1; i < 256; i++)
        cumul[i] = cumul[i - 1] + count[i - 1];

    /* Build transform vector (LF-mapping: last column -> first column) */
    for (i = 0; i < in_len; i++) {
        transform[i] = cumul[in[i]];
        cumul[in[i]]++;
    }

    /* Reconstruct original string */
    idx = orig_index;
    for (i = in_len - 1; i >= 0; i--) {
        out[i] = in[idx];
        idx = transform[idx];
    }

    return in_len;
}

/* ========================================================================
 * 8. Arithmetic-coding-like Range Encoder (simplified integer version)
 * Uses 32-bit integer ranges. Simplified: binary alphabet (0/1).
 * p0 = probability of 0 in 1/256 units.
 * ======================================================================== */

#define RANGE_TOP (1u << 24)
#define RANGE_BOT (1u << 16)

typedef struct {
    unsigned int low, range;
    unsigned char out[MAX_BUF];
    int out_len;
} RangeEncoder;

static void range_enc_init(RangeEncoder* e) {
    e->low = 0;
    e->range = 0xFFFFFFFFu;
    e->out_len = 0;
}

static void range_enc_normalize(RangeEncoder* e) {
    while (e->range < RANGE_BOT) {
        if (e->out_len < MAX_BUF)
            e->out[e->out_len++] = (unsigned char)(e->low >> 24);
        e->low <<= 8;
        e->range <<= 8;
    }
}

static void range_enc_encode_bit(RangeEncoder* e, int bit, int p0_256) {
    unsigned int split;
    if (p0_256 < 1) p0_256 = 1;
    if (p0_256 > 255) p0_256 = 255;
    split = (e->range / 256) * (unsigned int)p0_256;
    if (bit == 0) {
        e->range = split;
    } else {
        e->low += split;
        e->range -= split;
    }
    range_enc_normalize(e);
}

static void range_enc_finish(RangeEncoder* e) {
    int i;
    for (i = 0; i < 4; i++) {
        if (e->out_len < MAX_BUF)
            e->out[e->out_len++] = (unsigned char)(e->low >> 24);
        e->low <<= 8;
    }
}

typedef struct {
    unsigned int low, range, code;
    const unsigned char* in;
    int in_len, in_pos;
} RangeDecoder;

static void range_dec_init(RangeDecoder* d, const unsigned char* data, int len) {
    int i;
    d->low = 0;
    d->range = 0xFFFFFFFFu;
    d->code = 0;
    d->in = data;
    d->in_len = len;
    d->in_pos = 0;
    for (i = 0; i < 4; i++) {
        d->code = (d->code << 8);
        if (d->in_pos < d->in_len)
            d->code |= d->in[d->in_pos++];
    }
}

static void range_dec_normalize(RangeDecoder* d) {
    while (d->range < RANGE_BOT) {
        d->code = (d->code << 8);
        if (d->in_pos < d->in_len)
            d->code |= d->in[d->in_pos++];
        d->low <<= 8;
        d->range <<= 8;
    }
}

static int range_dec_decode_bit(RangeDecoder* d, int p0_256) {
    unsigned int split;
    int bit;
    if (p0_256 < 1) p0_256 = 1;
    if (p0_256 > 255) p0_256 = 255;
    split = (d->range / 256) * (unsigned int)p0_256;
    if (d->code - d->low < split) {
        d->range = split;
        bit = 0;
    } else {
        d->low += split;
        d->range -= split;
        bit = 1;
    }
    range_dec_normalize(d);
    return bit;
}

/* Encode byte array as bit stream with fixed probability */
static int range_encode_bytes(const unsigned char* data, int data_len,
                              unsigned char* out, int out_max, int p0_256) {
    RangeEncoder enc;
    int i, b;

    range_enc_init(&enc);
    for (i = 0; i < data_len; i++) {
        for (b = 7; b >= 0; b--) {
            int bit = (data[i] >> b) & 1;
            range_enc_encode_bit(&enc, bit, p0_256);
        }
    }
    range_enc_finish(&enc);

    if (enc.out_len > out_max) return -1;
    memcpy(out, enc.out, enc.out_len);
    return enc.out_len;
}

static int range_decode_bytes(const unsigned char* encoded, int enc_len,
                              unsigned char* out, int data_len, int p0_256) {
    RangeDecoder dec;
    int i, b;

    range_dec_init(&dec, encoded, enc_len);
    for (i = 0; i < data_len; i++) {
        unsigned char byte_val = 0;
        for (b = 7; b >= 0; b--) {
            int bit = range_dec_decode_bit(&dec, p0_256);
            if (bit) byte_val |= (unsigned char)(1 << b);
        }
        out[i] = byte_val;
    }
    return data_len;
}

/* ========================================================================
 * 9. Simple Dictionary Compression
 * Fixed dictionary of 16 common byte patterns (4 bytes each).
 * Token: [flag] then:
 *   flag bit 7 set: dict index (bits 0-3), copy 4 bytes from dict
 *   flag bit 7 clear: literal count (bits 0-6), followed by that many literal bytes
 * ======================================================================== */

static const unsigned char g_dict[16][4] = {
    {0x00,0x00,0x00,0x00}, {0xFF,0xFF,0xFF,0xFF},
    {0x01,0x02,0x03,0x04}, {0x04,0x03,0x02,0x01},
    {0x0A,0x0B,0x0C,0x0D}, {0x10,0x20,0x30,0x40},
    {0x41,0x42,0x43,0x44}, {0x61,0x62,0x63,0x64},
    {0x30,0x31,0x32,0x33}, {0x20,0x20,0x20,0x20},
    {0x0D,0x0A,0x0D,0x0A}, {0x48,0x65,0x6C,0x6C},
    {0x6F,0x20,0x57,0x6F}, {0x72,0x6C,0x64,0x21},
    {0x54,0x68,0x65,0x20}, {0x69,0x6E,0x67,0x20}
};

static int dict_match(const unsigned char* data, int pos, int len) {
    int i;
    if (pos + 4 > len) return -1;
    for (i = 0; i < 16; i++) {
        if (data[pos] == g_dict[i][0] && data[pos+1] == g_dict[i][1] &&
            data[pos+2] == g_dict[i][2] && data[pos+3] == g_dict[i][3])
            return i;
    }
    return -1;
}

static int dict_encode(const unsigned char* in, int in_len,
                       unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i < in_len) {
        int match = dict_match(in, i, in_len);
        if (match >= 0) {
            if (o >= out_max) return -1;
            out[o++] = (unsigned char)(0x80 | match);
            i += 4;
        } else {
            /* Count consecutive non-matching bytes */
            int start = i;
            int count;
            while (i < in_len && dict_match(in, i, in_len) < 0) {
                i++;
                if (i - start >= 127) break;
            }
            count = i - start;
            if (o + 1 + count > out_max) return -1;
            out[o++] = (unsigned char)count;
            memcpy(&out[o], &in[start], count);
            o += count;
        }
    }
    return o;
}

static int dict_decode(const unsigned char* in, int in_len,
                       unsigned char* out, int out_max) {
    int i = 0, o = 0;
    while (i < in_len) {
        unsigned char flag = in[i++];
        if (flag & 0x80) {
            /* Dictionary reference */
            int idx = flag & 0x0F;
            if (o + 4 > out_max) return -1;
            memcpy(&out[o], g_dict[idx], 4);
            o += 4;
        } else {
            /* Literal bytes */
            int count = flag;
            if (i + count > in_len || o + count > out_max) return -1;
            memcpy(&out[o], &in[i], count);
            o += count;
            i += count;
        }
    }
    return o;
}

/* ========================================================================
 * 10. Golomb-Rice Coding
 * Parameter M (power of 2). Encode non-negative integers.
 * Quotient in unary, remainder in binary (log2(M) bits).
 * ======================================================================== */

typedef struct {
    unsigned char data[MAX_BUF];
    int byte_pos;
    int bit_pos;
} BitStream;

static void bs_init(BitStream* bs) {
    memset(bs->data, 0, MAX_BUF);
    bs->byte_pos = 0;
    bs->bit_pos = 0;
}

static void bs_write_bit(BitStream* bs, int bit) {
    int idx = bs->byte_pos;
    if (idx < MAX_BUF) {
        if (bit) bs->data[idx] |= (unsigned char)(1 << bs->bit_pos);
        bs->bit_pos++;
        if (bs->bit_pos == 8) {
            bs->bit_pos = 0;
            bs->byte_pos++;
        }
    }
}

static int bs_read_bit(BitStream* bs) {
    int idx = bs->byte_pos;
    int bit;
    if (idx >= MAX_BUF) return 0;
    bit = (bs->data[idx] >> bs->bit_pos) & 1;
    bs->bit_pos++;
    if (bs->bit_pos == 8) {
        bs->bit_pos = 0;
        bs->byte_pos++;
    }
    return bit;
}

static int bs_total_bytes(BitStream* bs) {
    return bs->byte_pos + (bs->bit_pos > 0 ? 1 : 0);
}

static void golomb_rice_encode_val(BitStream* bs, int val, int k) {
    int q = val >> k;
    int r = val & ((1 << k) - 1);
    int i;
    /* Unary: q ones followed by a zero */
    for (i = 0; i < q; i++) bs_write_bit(bs, 1);
    bs_write_bit(bs, 0);
    /* Binary: k bits for remainder */
    for (i = 0; i < k; i++)
        bs_write_bit(bs, (r >> i) & 1);
}

static int golomb_rice_decode_val(BitStream* bs, int k) {
    int q = 0, r = 0, i;
    /* Read unary (count ones until zero) */
    while (bs_read_bit(bs) == 1) q++;
    /* Read k bits for remainder */
    for (i = 0; i < k; i++)
        if (bs_read_bit(bs)) r |= (1 << i);
    return (q << k) | r;
}

static int golomb_rice_encode(const int* values, int count, int k,
                              unsigned char* out, int out_max) {
    BitStream bs;
    int i, total;
    bs_init(&bs);
    for (i = 0; i < count; i++)
        golomb_rice_encode_val(&bs, values[i], k);
    total = bs_total_bytes(&bs);
    if (total > out_max) return -1;
    memcpy(out, bs.data, total);
    return total;
}

static int golomb_rice_decode(const unsigned char* in, int in_len, int k,
                              int* values, int count) {
    BitStream bs;
    int i;
    bs_init(&bs);
    memcpy(bs.data, in, in_len < MAX_BUF ? in_len : MAX_BUF);
    for (i = 0; i < count; i++)
        values[i] = golomb_rice_decode_val(&bs, k);
    return count;
}

/* ========================================================================
 * TEST DATA GENERATORS
 * ======================================================================== */

static void gen_all_zeros(unsigned char* buf, int len) {
    memset(buf, 0, len);
}

static void gen_sequential(unsigned char* buf, int len) {
    int i;
    for (i = 0; i < len; i++) buf[i] = (unsigned char)(i & 0xff);
}

static void gen_random(unsigned char* buf, int len, unsigned int seed) {
    int i;
    lcg_seed(seed);
    for (i = 0; i < len; i++) buf[i] = lcg_byte();
}

static void gen_text_like(unsigned char* buf, int len) {
    /* Letters, spaces, some punctuation */
    const char* alphabet = "abcdefghijklmnopqrstuvwxyz      ABCDEFGHIJKLM.,;!?";
    int alen = (int)strlen(alphabet);
    int i;
    lcg_seed(54321);
    for (i = 0; i < len; i++)
        buf[i] = (unsigned char)alphabet[lcg_next() % alen];
}

static void gen_runs(unsigned char* buf, int len) {
    /* Long runs of same byte */
    int i = 0;
    unsigned char val = 0;
    lcg_seed(77);
    while (i < len) {
        int run = (lcg_next() % 20) + 1;
        int j;
        val = lcg_byte();
        for (j = 0; j < run && i < len; j++)
            buf[i++] = val;
    }
}

static void gen_alternating(unsigned char* buf, int len) {
    int i;
    for (i = 0; i < len; i++)
        buf[i] = (unsigned char)((i & 1) ? 0xFF : 0x00);
}

static void gen_dict_friendly(unsigned char* buf, int len) {
    /* Data containing dictionary patterns */
    int i = 0;
    lcg_seed(42);
    while (i < len) {
        if (i + 4 <= len && (lcg_next() % 3) == 0) {
            int idx = lcg_next() % 16;
            memcpy(&buf[i], g_dict[idx], 4);
            i += 4;
        } else {
            buf[i++] = lcg_byte();
        }
    }
}

static void gen_small_values(unsigned char* buf, int len) {
    /* Values 0-15 only (good for bit-packing) */
    int i;
    lcg_seed(999);
    for (i = 0; i < len; i++)
        buf[i] = (unsigned char)(lcg_next() & 0x0f);
}

/* ========================================================================
 * TEST SECTIONS
 * ======================================================================== */

static void test_rle_basic(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[rle_basic]\n");

    /* All zeros */
    gen_all_zeros(data, 100);
    elen = rle_encode(data, 100, enc, MAX_BUF);
    check(elen > 0, "rle_zeros_enc");
    check(elen == 2, "rle_zeros_compact"); /* 1 run */
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 100, "rle_zeros_dec_len");
    check(mem_eq(data, dec, 100), "rle_zeros_roundtrip");

    /* Single byte */
    data[0] = 42;
    elen = rle_encode(data, 1, enc, MAX_BUF);
    check(elen == 2, "rle_single_enc");
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 1, "rle_single_dec");
    check(dec[0] == 42, "rle_single_val");

    /* Alternating */
    gen_alternating(data, 64);
    elen = rle_encode(data, 64, enc, MAX_BUF);
    check(elen > 0, "rle_alt_enc");
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 64, "rle_alt_dec_len");
    check(mem_eq(data, dec, 64), "rle_alt_roundtrip");
}

static void test_rle_runs(void) {
    unsigned char data[256], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[rle_runs]\n");

    gen_runs(data, 200);
    elen = rle_encode(data, 200, enc, MAX_BUF);
    check(elen > 0, "rle_runs_enc");
    check(elen < 200, "rle_runs_compressed"); /* runs should compress */
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 200, "rle_runs_dec_len");
    check(mem_eq(data, dec, 200), "rle_runs_roundtrip");
}

static void test_rle_random(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[rle_random]\n");

    gen_random(data, 128, 12345);
    elen = rle_encode(data, 128, enc, MAX_BUF);
    check(elen > 0, "rle_rand_enc");
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "rle_rand_dec_len");
    check(mem_eq(data, dec, 128), "rle_rand_roundtrip");
}

static void test_rle_long_run(void) {
    unsigned char data[512], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[rle_long_run]\n");

    /* 300 bytes of same value: should split into 255+45 */
    memset(data, 0xAB, 300);
    elen = rle_encode(data, 300, enc, MAX_BUF);
    check(elen == 4, "rle_long_enc_4"); /* 2 runs: (255,0xAB)(45,0xAB) */
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 300, "rle_long_dec_300");
    check(mem_eq(data, dec, 300), "rle_long_roundtrip");
}

static void test_lz77_basic(void) {
    unsigned char data[256], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[lz77_basic]\n");

    /* Repeating pattern */
    {
        int i;
        for (i = 0; i < 100; i++) data[i] = (unsigned char)(i % 10);
    }
    elen = lz77_encode(data, 100, enc, MAX_BUF);
    check(elen > 0, "lz77_repeat_enc");
    check(elen < 100, "lz77_repeat_compressed");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 100, "lz77_repeat_dec_len");
    check(mem_eq(data, dec, 100), "lz77_repeat_roundtrip");
}

static void test_lz77_zeros(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[lz77_zeros]\n");

    gen_all_zeros(data, 128);
    elen = lz77_encode(data, 128, enc, MAX_BUF);
    check(elen > 0, "lz77_zeros_enc");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "lz77_zeros_dec_len");
    check(mem_eq(data, dec, 128), "lz77_zeros_roundtrip");
}

static void test_lz77_random(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[lz77_random]\n");

    gen_random(data, 128, 67890);
    elen = lz77_encode(data, 128, enc, MAX_BUF);
    check(elen > 0, "lz77_rand_enc");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "lz77_rand_dec_len");
    check(mem_eq(data, dec, 128), "lz77_rand_roundtrip");
}

static void test_lz77_text(void) {
    unsigned char data[200], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[lz77_text]\n");

    gen_text_like(data, 200);
    elen = lz77_encode(data, 200, enc, MAX_BUF);
    check(elen > 0, "lz77_text_enc");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 200, "lz77_text_dec_len");
    check(mem_eq(data, dec, 200), "lz77_text_roundtrip");
}

static void test_lz77_short(void) {
    unsigned char data[8], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[lz77_short]\n");

    /* Very short input */
    data[0] = 'H'; data[1] = 'i'; data[2] = '!';
    elen = lz77_encode(data, 3, enc, MAX_BUF);
    check(elen > 0, "lz77_short_enc");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 3, "lz77_short_dec_len");
    check(mem_eq(data, dec, 3), "lz77_short_roundtrip");
}

static void test_huffman_basic(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen;
    int total_bits, i;

    write_str("[huffman_basic]\n");

    /* Simple data with known frequency distribution */
    memset(data, 'A', 30);
    memset(data + 30, 'B', 20);
    memset(data + 50, 'C', 10);
    memset(data + 60, 'D', 4);

    memset(codes, 0, sizeof(codes));
    huff_build_tree(data, 64, nodes, &root);
    check(root >= 0, "huff_basic_root");
    huff_build_codes(nodes, root, codes, path, 0);

    /* Most frequent symbol should have shortest code */
    check(codes['A'].length <= codes['D'].length, "huff_basic_a_short");

    /* Encode */
    total_bits = 0;
    for (i = 0; i < 64; i++) total_bits += codes[data[i]].length;
    elen = huff_encode(data, 64, codes, enc, MAX_BUF);
    check(elen > 0, "huff_basic_enc");
    check(elen < 64, "huff_basic_compressed"); /* should compress */

    /* Decode */
    dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
    check(dlen == 64, "huff_basic_dec_len");
    check(mem_eq(data, dec, 64), "huff_basic_roundtrip");
}

static void test_huffman_single_symbol(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[32], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen, total_bits;

    write_str("[huffman_single]\n");

    memset(data, 'X', 32);
    memset(codes, 0, sizeof(codes));
    huff_build_tree(data, 32, nodes, &root);
    check(root >= 0, "huff_single_root");
    huff_build_codes(nodes, root, codes, path, 0);
    check(codes['X'].length == 1, "huff_single_len_1");

    total_bits = 32 * codes['X'].length;
    elen = huff_encode(data, 32, codes, enc, MAX_BUF);
    check(elen > 0, "huff_single_enc");

    dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
    check(dlen == 32, "huff_single_dec_len");
    check(mem_eq(data, dec, 32), "huff_single_roundtrip");
}

static void test_huffman_random(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[100], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen, total_bits, i;

    write_str("[huffman_random]\n");

    gen_random(data, 100, 11111);
    memset(codes, 0, sizeof(codes));
    huff_build_tree(data, 100, nodes, &root);
    check(root >= 0, "huff_rand_root");
    huff_build_codes(nodes, root, codes, path, 0);

    total_bits = 0;
    for (i = 0; i < 100; i++) total_bits += codes[data[i]].length;
    elen = huff_encode(data, 100, codes, enc, MAX_BUF);
    check(elen > 0, "huff_rand_enc");

    dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
    check(dlen == 100, "huff_rand_dec_len");
    check(mem_eq(data, dec, 100), "huff_rand_roundtrip");
}

static void test_huffman_two_symbols(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[40], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen, total_bits, i;

    write_str("[huffman_two_symbols]\n");

    /* 30 A's, 10 B's */
    memset(data, 'A', 30);
    memset(data + 30, 'B', 10);

    memset(codes, 0, sizeof(codes));
    huff_build_tree(data, 40, nodes, &root);
    huff_build_codes(nodes, root, codes, path, 0);

    check(codes['A'].length == 1, "huff_two_a_len_1");
    check(codes['B'].length == 1, "huff_two_b_len_1");

    total_bits = 0;
    for (i = 0; i < 40; i++) total_bits += codes[data[i]].length;
    elen = huff_encode(data, 40, codes, enc, MAX_BUF);
    check(elen > 0, "huff_two_enc");

    dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
    check(dlen == 40, "huff_two_dec_len");
    check(mem_eq(data, dec, 40), "huff_two_roundtrip");
}

static void test_huffman_text(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[150], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen, total_bits, i;

    write_str("[huffman_text]\n");

    gen_text_like(data, 150);
    memset(codes, 0, sizeof(codes));
    huff_build_tree(data, 150, nodes, &root);
    huff_build_codes(nodes, root, codes, path, 0);

    total_bits = 0;
    for (i = 0; i < 150; i++) total_bits += codes[data[i]].length;
    elen = huff_encode(data, 150, codes, enc, MAX_BUF);
    check(elen > 0, "huff_text_enc");

    dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
    check(dlen == 150, "huff_text_dec_len");
    check(mem_eq(data, dec, 150), "huff_text_roundtrip");
}

static void test_delta_basic(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[delta_basic]\n");

    /* Sequential */
    gen_sequential(data, 64);
    elen = delta_encode(data, 64, enc, MAX_BUF);
    check(elen == 64, "delta_seq_enc_len");
    check(enc[0] == 0, "delta_seq_first");
    check(enc[1] == 1, "delta_seq_delta_1");
    dlen = delta_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 64, "delta_seq_dec_len");
    check(mem_eq(data, dec, 64), "delta_seq_roundtrip");
}

static void test_delta_zeros(void) {
    unsigned char data[50], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i, all_zero;

    write_str("[delta_zeros]\n");

    gen_all_zeros(data, 50);
    elen = delta_encode(data, 50, enc, MAX_BUF);
    check(elen == 50, "delta_zeros_enc_len");
    all_zero = 1;
    for (i = 0; i < 50; i++) if (enc[i] != 0) all_zero = 0;
    check(all_zero, "delta_zeros_all_zero");
    dlen = delta_decode(enc, elen, dec, MAX_BUF);
    check(mem_eq(data, dec, 50), "delta_zeros_roundtrip");
}

static void test_delta_random(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[delta_random]\n");

    gen_random(data, 128, 55555);
    elen = delta_encode(data, 128, enc, MAX_BUF);
    check(elen == 128, "delta_rand_enc_len");
    dlen = delta_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "delta_rand_dec_len");
    check(mem_eq(data, dec, 128), "delta_rand_roundtrip");
}

static void test_delta_alternating(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[delta_alternating]\n");

    gen_alternating(data, 64);
    elen = delta_encode(data, 64, enc, MAX_BUF);
    check(elen == 64, "delta_alt_enc_len");
    /* Deltas should alternate between 255 and 1 (mod 256) */
    check(enc[0] == 0, "delta_alt_first");
    check(enc[1] == 255, "delta_alt_d1"); /* 0xFF - 0x00 = 0xFF */
    check(enc[2] == 1, "delta_alt_d2");   /* 0x00 - 0xFF = 0x01 (mod 256) */
    dlen = delta_decode(enc, elen, dec, MAX_BUF);
    check(mem_eq(data, dec, 64), "delta_alt_roundtrip");
}

static void test_delta_single(void) {
    unsigned char data[1], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[delta_single]\n");

    data[0] = 123;
    elen = delta_encode(data, 1, enc, MAX_BUF);
    check(elen == 1, "delta_single_enc_len");
    check(enc[0] == 123, "delta_single_val");
    dlen = delta_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 1 && dec[0] == 123, "delta_single_roundtrip");
}

static void test_bitpack_basic(void) {
    unsigned char data[32], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[bitpack_basic]\n");

    /* 4-bit values */
    gen_small_values(data, 32);
    elen = bitpack_encode(data, 32, 4, enc, MAX_BUF);
    check(elen == 16, "bp4_enc_len"); /* 32 * 4 bits = 128 bits = 16 bytes */
    dlen = bitpack_decode(enc, 32, 4, dec, MAX_BUF);
    check(dlen == 32, "bp4_dec_len");
    check(mem_eq(data, dec, 32), "bp4_roundtrip");

    /* 3-bit values (0-7) */
    for (i = 0; i < 24; i++) data[i] = (unsigned char)(i % 8);
    elen = bitpack_encode(data, 24, 3, enc, MAX_BUF);
    check(elen == 9, "bp3_enc_len"); /* 24 * 3 = 72 bits = 9 bytes */
    dlen = bitpack_decode(enc, 24, 3, dec, MAX_BUF);
    check(dlen == 24, "bp3_dec_len");
    check(mem_eq(data, dec, 24), "bp3_roundtrip");
}

static void test_bitpack_1bit(void) {
    unsigned char data[16], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[bitpack_1bit]\n");

    for (i = 0; i < 16; i++) data[i] = (unsigned char)(i & 1);
    elen = bitpack_encode(data, 16, 1, enc, MAX_BUF);
    check(elen == 2, "bp1_enc_len"); /* 16 bits = 2 bytes */
    dlen = bitpack_decode(enc, 16, 1, dec, MAX_BUF);
    check(dlen == 16, "bp1_dec_len");
    check(mem_eq(data, dec, 16), "bp1_roundtrip");
}

static void test_bitpack_8bit(void) {
    unsigned char data[20], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[bitpack_8bit]\n");

    gen_random(data, 20, 33333);
    elen = bitpack_encode(data, 20, 8, enc, MAX_BUF);
    check(elen == 20, "bp8_enc_len"); /* identity */
    dlen = bitpack_decode(enc, 20, 8, dec, MAX_BUF);
    check(dlen == 20, "bp8_dec_len");
    check(mem_eq(data, dec, 20), "bp8_roundtrip");
}

static void test_bitpack_5bit(void) {
    unsigned char data[40], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[bitpack_5bit]\n");

    for (i = 0; i < 40; i++) data[i] = (unsigned char)(i % 32);
    elen = bitpack_encode(data, 40, 5, enc, MAX_BUF);
    check(elen == 25, "bp5_enc_len"); /* 40 * 5 = 200 bits = 25 bytes */
    dlen = bitpack_decode(enc, 40, 5, dec, MAX_BUF);
    check(dlen == 40, "bp5_dec_len");
    check(mem_eq(data, dec, 40), "bp5_roundtrip");
}

static void test_mtf_basic(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[mtf_basic]\n");

    /* Repeated characters (should produce many zeros) */
    memset(data, 'A', 30);
    memset(data + 30, 'B', 20);
    memset(data + 50, 'A', 14);

    elen = mtf_encode(data, 64, enc, MAX_BUF);
    check(elen == 64, "mtf_basic_enc_len");
    /* First 'A' should map to 65 (its position), subsequent to 0 */
    check(enc[0] == 65, "mtf_basic_first_A");
    check(enc[1] == 0, "mtf_basic_second_A");
    check(enc[29] == 0, "mtf_basic_30th_A");

    dlen = mtf_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 64, "mtf_basic_dec_len");
    check(mem_eq(data, dec, 64), "mtf_basic_roundtrip");
}

static void test_mtf_random(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[mtf_random]\n");

    gen_random(data, 128, 44444);
    elen = mtf_encode(data, 128, enc, MAX_BUF);
    check(elen == 128, "mtf_rand_enc_len");
    dlen = mtf_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "mtf_rand_dec_len");
    check(mem_eq(data, dec, 128), "mtf_rand_roundtrip");
}

static void test_mtf_sequential(void) {
    unsigned char data[50], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[mtf_sequential]\n");

    gen_sequential(data, 50);
    elen = mtf_encode(data, 50, enc, MAX_BUF);
    check(elen == 50, "mtf_seq_enc_len");
    dlen = mtf_decode(enc, elen, dec, MAX_BUF);
    check(mem_eq(data, dec, 50), "mtf_seq_roundtrip");
}

static void test_mtf_single(void) {
    unsigned char data[1], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[mtf_single]\n");

    data[0] = 200;
    elen = mtf_encode(data, 1, enc, MAX_BUF);
    check(elen == 1, "mtf_single_enc_len");
    check(enc[0] == 200, "mtf_single_val");
    dlen = mtf_decode(enc, elen, dec, MAX_BUF);
    check(dec[0] == 200, "mtf_single_roundtrip");
}

static void test_bwt_basic(void) {
    unsigned char data[16], enc[BWT_MAX], dec[BWT_MAX];
    int elen, dlen, orig;

    write_str("[bwt_basic]\n");

    /* "banana" */
    memcpy(data, "banana", 6);
    elen = bwt_encode(data, 6, enc, BWT_MAX, &orig);
    check(elen == 6, "bwt_banana_enc_len");
    check(orig >= 0 && orig < 6, "bwt_banana_orig");
    dlen = bwt_decode(enc, 6, dec, BWT_MAX, orig);
    check(dlen == 6, "bwt_banana_dec_len");
    check(mem_eq(data, dec, 6), "bwt_banana_roundtrip");
}

static void test_bwt_all_same(void) {
    unsigned char data[8], enc[BWT_MAX], dec[BWT_MAX];
    int elen, dlen, orig;

    write_str("[bwt_all_same]\n");

    memset(data, 'Z', 8);
    elen = bwt_encode(data, 8, enc, BWT_MAX, &orig);
    check(elen == 8, "bwt_same_enc_len");
    dlen = bwt_decode(enc, 8, dec, BWT_MAX, orig);
    check(dlen == 8, "bwt_same_dec_len");
    check(mem_eq(data, dec, 8), "bwt_same_roundtrip");
}

static void test_bwt_short_strings(void) {
    unsigned char data[BWT_MAX], enc[BWT_MAX], dec[BWT_MAX];
    int elen, dlen, orig;

    write_str("[bwt_short_strings]\n");

    /* "abcabc" */
    memcpy(data, "abcabc", 6);
    elen = bwt_encode(data, 6, enc, BWT_MAX, &orig);
    check(elen == 6, "bwt_abc_enc");
    dlen = bwt_decode(enc, 6, dec, BWT_MAX, orig);
    check(mem_eq(data, dec, 6), "bwt_abc_roundtrip");

    /* "mississippi" */
    memcpy(data, "mississippi", 11);
    elen = bwt_encode(data, 11, enc, BWT_MAX, &orig);
    check(elen == 11, "bwt_miss_enc");
    dlen = bwt_decode(enc, 11, dec, BWT_MAX, orig);
    check(mem_eq(data, dec, 11), "bwt_miss_roundtrip");

    /* "abracadabra" */
    memcpy(data, "abracadabra", 11);
    elen = bwt_encode(data, 11, enc, BWT_MAX, &orig);
    check(elen == 11, "bwt_abra_enc");
    dlen = bwt_decode(enc, 11, dec, BWT_MAX, orig);
    check(mem_eq(data, dec, 11), "bwt_abra_roundtrip");

    /* Single char */
    data[0] = 'Q';
    elen = bwt_encode(data, 1, enc, BWT_MAX, &orig);
    check(elen == 1, "bwt_single_enc");
    dlen = bwt_decode(enc, 1, dec, BWT_MAX, orig);
    check(dec[0] == 'Q', "bwt_single_roundtrip");
}

static void test_bwt_random(void) {
    unsigned char data[32], enc[BWT_MAX], dec[BWT_MAX];
    int elen, dlen, orig;

    write_str("[bwt_random]\n");

    gen_random(data, 32, 77777);
    elen = bwt_encode(data, 32, enc, BWT_MAX, &orig);
    check(elen == 32, "bwt_rand_enc");
    dlen = bwt_decode(enc, 32, dec, BWT_MAX, orig);
    check(dlen == 32, "bwt_rand_dec_len");
    check(mem_eq(data, dec, 32), "bwt_rand_roundtrip");
}

static void test_bwt_longer(void) {
    unsigned char data[BWT_MAX], enc[BWT_MAX], dec[BWT_MAX];
    int elen, dlen, orig;

    write_str("[bwt_longer]\n");

    /* 48-byte random data */
    gen_random(data, 48, 88888);
    elen = bwt_encode(data, 48, enc, BWT_MAX, &orig);
    check(elen == 48, "bwt_48_enc");
    dlen = bwt_decode(enc, 48, dec, BWT_MAX, orig);
    check(dlen == 48, "bwt_48_dec_len");
    check(mem_eq(data, dec, 48), "bwt_48_roundtrip");
}

static void test_range_coder_basic(void) {
    unsigned char data[32], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[range_coder_basic]\n");

    /* All zeros (biased toward 0, p0 high) */
    gen_all_zeros(data, 32);
    elen = range_encode_bytes(data, 32, enc, MAX_BUF, 240);
    check(elen > 0, "rc_zeros_enc");
    dlen = range_decode_bytes(enc, elen, dec, 32, 240);
    check(dlen == 32, "rc_zeros_dec_len");
    check(mem_eq(data, dec, 32), "rc_zeros_roundtrip");
}

static void test_range_coder_random(void) {
    unsigned char data[24], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[range_coder_random]\n");

    gen_random(data, 24, 99999);
    elen = range_encode_bytes(data, 24, enc, MAX_BUF, 128);
    check(elen > 0, "rc_rand_enc");
    dlen = range_decode_bytes(enc, elen, dec, 24, 128);
    check(dlen == 24, "rc_rand_dec_len");
    check(mem_eq(data, dec, 24), "rc_rand_roundtrip");
}

static void test_range_coder_biased(void) {
    unsigned char data[40], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[range_coder_biased]\n");

    /* Mostly zeros with a few ones */
    memset(data, 0, 40);
    data[5] = 1; data[15] = 3; data[25] = 7;
    elen = range_encode_bytes(data, 40, enc, MAX_BUF, 220);
    check(elen > 0, "rc_biased_enc");
    dlen = range_decode_bytes(enc, elen, dec, 40, 220);
    check(dlen == 40, "rc_biased_dec_len");
    check(mem_eq(data, dec, 40), "rc_biased_roundtrip");
}

static void test_range_coder_all_ones(void) {
    unsigned char data[16], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[range_coder_all_ones]\n");

    memset(data, 0xFF, 16);
    elen = range_encode_bytes(data, 16, enc, MAX_BUF, 20);
    check(elen > 0, "rc_ones_enc");
    dlen = range_decode_bytes(enc, elen, dec, 16, 20);
    check(dlen == 16, "rc_ones_dec_len");
    check(mem_eq(data, dec, 16), "rc_ones_roundtrip");
}

static void test_dict_basic(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[dict_basic]\n");

    /* Data containing dictionary patterns */
    memcpy(data, g_dict[0], 4);       /* 0x00000000 */
    memcpy(data + 4, g_dict[1], 4);   /* 0xFFFFFFFF */
    memcpy(data + 8, g_dict[2], 4);   /* 01020304 */
    data[12] = 0x99; data[13] = 0x98; /* 2 literals */
    memcpy(data + 14, g_dict[6], 4);  /* ABCD */

    elen = dict_encode(data, 18, enc, MAX_BUF);
    check(elen > 0, "dict_basic_enc");
    check(elen < 18, "dict_basic_compressed");
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 18, "dict_basic_dec_len");
    check(mem_eq(data, dec, 18), "dict_basic_roundtrip");
}

static void test_dict_no_matches(void) {
    unsigned char data[32], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[dict_no_matches]\n");

    /* Data with no dictionary patterns */
    gen_sequential(data, 32);
    /* Modify to avoid accidental matches */
    data[0] = 0x77; data[1] = 0x88;
    elen = dict_encode(data, 32, enc, MAX_BUF);
    check(elen > 0, "dict_no_match_enc");
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 32, "dict_no_match_dec_len");
    check(mem_eq(data, dec, 32), "dict_no_match_roundtrip");
}

static void test_dict_all_patterns(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[dict_all_patterns]\n");

    /* All 16 dictionary entries in sequence */
    for (i = 0; i < 16; i++)
        memcpy(data + i * 4, g_dict[i], 4);
    elen = dict_encode(data, 64, enc, MAX_BUF);
    check(elen > 0, "dict_all_enc");
    check(elen == 16, "dict_all_compact"); /* 16 single-byte tokens */
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 64, "dict_all_dec_len");
    check(mem_eq(data, dec, 64), "dict_all_roundtrip");
}

static void test_dict_friendly(void) {
    unsigned char data[200], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[dict_friendly]\n");

    gen_dict_friendly(data, 200);
    elen = dict_encode(data, 200, enc, MAX_BUF);
    check(elen > 0, "dict_friendly_enc");
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 200, "dict_friendly_dec_len");
    check(mem_eq(data, dec, 200), "dict_friendly_roundtrip");
}

static void test_golomb_basic(void) {
    int values[32], decoded[32];
    unsigned char enc[MAX_BUF];
    int elen, i;

    write_str("[golomb_basic]\n");

    /* Small values, k=2 */
    for (i = 0; i < 20; i++) values[i] = i;
    elen = golomb_rice_encode(values, 20, 2, enc, MAX_BUF);
    check(elen > 0, "golomb_basic_enc");
    golomb_rice_decode(enc, elen, 2, decoded, 20);
    {
        int ok = 1;
        for (i = 0; i < 20; i++) if (values[i] != decoded[i]) ok = 0;
        check(ok, "golomb_basic_roundtrip");
    }
}

static void test_golomb_k1(void) {
    int values[16], decoded[16];
    unsigned char enc[MAX_BUF];
    int elen, i;

    write_str("[golomb_k1]\n");

    for (i = 0; i < 16; i++) values[i] = i * 2;
    elen = golomb_rice_encode(values, 16, 1, enc, MAX_BUF);
    check(elen > 0, "golomb_k1_enc");
    golomb_rice_decode(enc, elen, 1, decoded, 16);
    {
        int ok = 1;
        for (i = 0; i < 16; i++) if (values[i] != decoded[i]) ok = 0;
        check(ok, "golomb_k1_roundtrip");
    }
}

static void test_golomb_k3(void) {
    int values[32], decoded[32];
    unsigned char enc[MAX_BUF];
    int elen, i;

    write_str("[golomb_k3]\n");

    lcg_seed(22222);
    for (i = 0; i < 32; i++) values[i] = lcg_next() % 50;
    elen = golomb_rice_encode(values, 32, 3, enc, MAX_BUF);
    check(elen > 0, "golomb_k3_enc");
    golomb_rice_decode(enc, elen, 3, decoded, 32);
    {
        int ok = 1;
        for (i = 0; i < 32; i++) if (values[i] != decoded[i]) ok = 0;
        check(ok, "golomb_k3_roundtrip");
    }
}

static void test_golomb_zeros(void) {
    int values[24], decoded[24];
    unsigned char enc[MAX_BUF];
    int elen, i;

    write_str("[golomb_zeros]\n");

    for (i = 0; i < 24; i++) values[i] = 0;
    elen = golomb_rice_encode(values, 24, 2, enc, MAX_BUF);
    check(elen > 0, "golomb_zeros_enc");
    golomb_rice_decode(enc, elen, 2, decoded, 24);
    {
        int ok = 1;
        for (i = 0; i < 24; i++) if (decoded[i] != 0) ok = 0;
        check(ok, "golomb_zeros_roundtrip");
    }
}

static void test_golomb_large_values(void) {
    int values[8], decoded[8];
    unsigned char enc[MAX_BUF];
    int elen, i;

    write_str("[golomb_large_values]\n");

    values[0] = 100; values[1] = 200; values[2] = 50;
    values[3] = 0; values[4] = 255; values[5] = 1;
    values[6] = 128; values[7] = 64;
    elen = golomb_rice_encode(values, 8, 4, enc, MAX_BUF);
    check(elen > 0, "golomb_large_enc");
    golomb_rice_decode(enc, elen, 4, decoded, 8);
    {
        int ok = 1;
        for (i = 0; i < 8; i++) if (values[i] != decoded[i]) ok = 0;
        check(ok, "golomb_large_roundtrip");
    }
}

/* ========================================================================
 * Combined / Pipeline Tests
 * ======================================================================== */

static void test_delta_then_rle(void) {
    unsigned char data[64], d1[MAX_BUF], d2[MAX_BUF];
    unsigned char r1[MAX_BUF], r2[MAX_BUF];
    int dlen, rlen, rlen2, dlen2;

    write_str("[delta_then_rle]\n");

    /* Sequential data: delta produces constants, which RLE compresses well */
    gen_sequential(data, 64);
    dlen = delta_encode(data, 64, d1, MAX_BUF);
    rlen = rle_encode(d1, dlen, d2, MAX_BUF);
    check(rlen > 0, "delta_rle_enc");
    check(rlen < 64, "delta_rle_compressed");

    /* Decode: RLE first, then delta */
    rlen2 = rle_decode(d2, rlen, r1, MAX_BUF);
    check(rlen2 == dlen, "delta_rle_rle_dec_len");
    dlen2 = delta_decode(r1, rlen2, r2, MAX_BUF);
    check(dlen2 == 64, "delta_rle_delta_dec_len");
    check(mem_eq(data, r2, 64), "delta_rle_roundtrip");
}

static void test_mtf_then_rle(void) {
    unsigned char data[64], m1[MAX_BUF], r1[MAX_BUF];
    unsigned char r2[MAX_BUF], m2[MAX_BUF];
    int mlen, rlen, rlen2, mlen2;

    write_str("[mtf_then_rle]\n");

    /* Runs of same byte: MTF produces zeros, RLE compresses zeros */
    gen_runs(data, 64);
    mlen = mtf_encode(data, 64, m1, MAX_BUF);
    rlen = rle_encode(m1, mlen, r1, MAX_BUF);
    check(rlen > 0, "mtf_rle_enc");

    rlen2 = rle_decode(r1, rlen, r2, MAX_BUF);
    mlen2 = mtf_decode(r2, rlen2, m2, MAX_BUF);
    check(mlen2 == 64, "mtf_rle_dec_len");
    check(mem_eq(data, m2, 64), "mtf_rle_roundtrip");
}

static void test_bwt_then_mtf(void) {
    unsigned char data[24], b1[BWT_MAX], m1[MAX_BUF];
    unsigned char m2[MAX_BUF], b2[BWT_MAX];
    int blen, mlen, mlen2, blen2, orig;

    write_str("[bwt_then_mtf]\n");

    memcpy(data, "abracadabra_abracadabr", 22);
    blen = bwt_encode(data, 22, b1, BWT_MAX, &orig);
    check(blen == 22, "bwt_mtf_bwt_enc");
    mlen = mtf_encode(b1, 22, m1, MAX_BUF);
    check(mlen == 22, "bwt_mtf_mtf_enc");

    /* Decode: MTF then BWT */
    mlen2 = mtf_decode(m1, mlen, m2, MAX_BUF);
    blen2 = bwt_decode(m2, mlen2, b2, BWT_MAX, orig);
    check(blen2 == 22, "bwt_mtf_dec_len");
    check(mem_eq(data, b2, 22), "bwt_mtf_roundtrip");
}

static void test_delta_then_huffman(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[80], d1[MAX_BUF], enc[MAX_BUF], dec_huff[MAX_BUF], dec_delta[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int dlen, root, elen, hlen, dlen2, total_bits, i;

    write_str("[delta_then_huffman]\n");

    gen_sequential(data, 80);
    dlen = delta_encode(data, 80, d1, MAX_BUF);

    memset(codes, 0, sizeof(codes));
    huff_build_tree(d1, dlen, nodes, &root);
    huff_build_codes(nodes, root, codes, path, 0);

    total_bits = 0;
    for (i = 0; i < dlen; i++) total_bits += codes[d1[i]].length;
    elen = huff_encode(d1, dlen, codes, enc, MAX_BUF);
    check(elen > 0, "delta_huff_enc");

    hlen = huff_decode(enc, total_bits, nodes, root, dec_huff, MAX_BUF);
    check(hlen == dlen, "delta_huff_huff_dec_len");
    dlen2 = delta_decode(dec_huff, hlen, dec_delta, MAX_BUF);
    check(dlen2 == 80, "delta_huff_delta_dec_len");
    check(mem_eq(data, dec_delta, 80), "delta_huff_roundtrip");
}

static void test_lz77_various_sizes(void) {
    unsigned char data[MAX_DATA], enc[MAX_BUF], dec[MAX_BUF];
    int sizes[] = {1, 2, 5, 10, 50, 100, 200, 300};
    int ns = 8;
    int i;

    write_str("[lz77_various_sizes]\n");

    for (i = 0; i < ns; i++) {
        int sz = sizes[i];
        int elen, dlen;
        gen_random(data, sz, 10000 + i);
        elen = lz77_encode(data, sz, enc, MAX_BUF);
        check(elen > 0, "lz77_vsz_enc");
        dlen = lz77_decode(enc, elen, dec, MAX_BUF);
        check(dlen == sz, "lz77_vsz_dec_len");
        check(mem_eq(data, dec, sz), "lz77_vsz_roundtrip");
    }
}

static void test_rle_various_sizes(void) {
    unsigned char data[MAX_DATA], enc[MAX_BUF], dec[MAX_BUF];
    int sizes[] = {1, 2, 3, 10, 50, 100, 255, 256, 300};
    int ns = 9;
    int i;

    write_str("[rle_various_sizes]\n");

    for (i = 0; i < ns; i++) {
        int sz = sizes[i];
        int elen, dlen;
        gen_runs(data, sz);
        elen = rle_encode(data, sz, enc, MAX_BUF);
        check(elen > 0, "rle_vsz_enc");
        dlen = rle_decode(enc, elen, dec, MAX_BUF);
        check(dlen == sz, "rle_vsz_dec_len");
        check(mem_eq(data, dec, sz), "rle_vsz_roundtrip");
    }
}

static void test_all_encoders_on_data(const unsigned char* data, int len,
                                       const char* label) {
    unsigned char enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;
    char name[64];

    /* RLE */
    elen = rle_encode(data, len, enc, MAX_BUF);
    if (elen > 0) {
        dlen = rle_decode(enc, elen, dec, MAX_BUF);
        strcpy(name, "all_rle_"); strcat(name, label);
        check(dlen == len && mem_eq(data, dec, len), name);
    }

    /* Delta */
    elen = delta_encode(data, len, enc, MAX_BUF);
    if (elen > 0) {
        dlen = delta_decode(enc, elen, dec, MAX_BUF);
        strcpy(name, "all_delta_"); strcat(name, label);
        check(dlen == len && mem_eq(data, dec, len), name);
    }

    /* MTF */
    elen = mtf_encode(data, len, enc, MAX_BUF);
    if (elen > 0) {
        dlen = mtf_decode(enc, elen, dec, MAX_BUF);
        strcpy(name, "all_mtf_"); strcat(name, label);
        check(dlen == len && mem_eq(data, dec, len), name);
    }

    /* LZ77 */
    elen = lz77_encode(data, len, enc, MAX_BUF);
    if (elen > 0) {
        dlen = lz77_decode(enc, elen, dec, MAX_BUF);
        strcpy(name, "all_lz77_"); strcat(name, label);
        check(dlen == len && mem_eq(data, dec, len), name);
    }

    /* Dict */
    elen = dict_encode(data, len, enc, MAX_BUF);
    if (elen > 0) {
        dlen = dict_decode(enc, elen, dec, MAX_BUF);
        strcpy(name, "all_dict_"); strcat(name, label);
        check(dlen == len && mem_eq(data, dec, len), name);
    }
}

static void test_all_encoders_stress(void) {
    unsigned char data[128];

    write_str("[all_encoders_stress]\n");

    gen_all_zeros(data, 100);
    test_all_encoders_on_data(data, 100, "zeros");

    gen_sequential(data, 100);
    test_all_encoders_on_data(data, 100, "seq");

    gen_random(data, 100, 31337);
    test_all_encoders_on_data(data, 100, "rand");

    gen_text_like(data, 100);
    test_all_encoders_on_data(data, 100, "text");

    gen_runs(data, 100);
    test_all_encoders_on_data(data, 100, "runs");

    gen_alternating(data, 100);
    test_all_encoders_on_data(data, 100, "alt");
}

static void test_bitpack_stress(void) {
    unsigned char data[64], enc[MAX_BUF], dec[MAX_BUF];
    int bits, i;

    write_str("[bitpack_stress]\n");

    /* Test all bit widths 1-8 */
    for (bits = 1; bits <= 8; bits++) {
        int mask = (1 << bits) - 1;
        int elen, dlen, ok;
        lcg_seed(bits * 1000);
        for (i = 0; i < 48; i++) data[i] = (unsigned char)(lcg_next() & mask);
        elen = bitpack_encode(data, 48, bits, enc, MAX_BUF);
        check(elen > 0, "bp_stress_enc");
        dlen = bitpack_decode(enc, 48, bits, dec, MAX_BUF);
        check(dlen == 48, "bp_stress_dec_len");
        ok = 1;
        for (i = 0; i < 48; i++) if (data[i] != dec[i]) ok = 0;
        check(ok, "bp_stress_roundtrip");
    }
}

static void test_golomb_stress(void) {
    int values[64], decoded[64];
    unsigned char enc[MAX_BUF];
    int k, i;

    write_str("[golomb_stress]\n");

    /* Test k=0,1,2,3,4,5 */
    for (k = 0; k <= 5; k++) {
        int elen, ok;
        lcg_seed(k * 7777);
        for (i = 0; i < 40; i++) values[i] = lcg_next() % 100;
        elen = golomb_rice_encode(values, 40, k, enc, MAX_BUF);
        check(elen > 0, "golomb_stress_enc");
        golomb_rice_decode(enc, elen, k, decoded, 40);
        ok = 1;
        for (i = 0; i < 40; i++) if (values[i] != decoded[i]) ok = 0;
        check(ok, "golomb_stress_roundtrip");
    }
}

static void test_bwt_multiple(void) {
    unsigned char data[BWT_MAX], enc[BWT_MAX], dec[BWT_MAX];
    int orig, i;

    write_str("[bwt_multiple]\n");

    /* Test multiple random strings of varying lengths */
    {
        int lengths[] = {2, 3, 5, 8, 13, 21, 34, 50, 64};
        int nl = 9;
        for (i = 0; i < nl; i++) {
            int len = lengths[i];
            int elen, dlen;
            gen_random(data, len, 50000 + i);
            elen = bwt_encode(data, len, enc, BWT_MAX, &orig);
            check(elen == len, "bwt_multi_enc");
            dlen = bwt_decode(enc, len, dec, BWT_MAX, orig);
            check(dlen == len, "bwt_multi_dec_len");
            check(mem_eq(data, dec, len), "bwt_multi_roundtrip");
        }
    }
}

static void test_range_coder_various_probs(void) {
    unsigned char data[20], enc[MAX_BUF], dec[MAX_BUF];
    int probs[] = {10, 50, 100, 128, 200, 245};
    int np = 6;
    int i;

    write_str("[range_coder_various_probs]\n");

    gen_random(data, 20, 60606);
    for (i = 0; i < np; i++) {
        int elen = range_encode_bytes(data, 20, enc, MAX_BUF, probs[i]);
        int dlen;
        check(elen > 0, "rc_vp_enc");
        dlen = range_decode_bytes(enc, elen, dec, 20, probs[i]);
        check(dlen == 20, "rc_vp_dec_len");
        check(mem_eq(data, dec, 20), "rc_vp_roundtrip");
    }
}

static void test_dict_edge_cases(void) {
    unsigned char data[8], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[dict_edge_cases]\n");

    /* Single byte */
    data[0] = 0x55;
    elen = dict_encode(data, 1, enc, MAX_BUF);
    check(elen > 0, "dict_single_enc");
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 1 && dec[0] == 0x55, "dict_single_roundtrip");

    /* Exactly one dictionary pattern */
    memcpy(data, g_dict[5], 4);
    elen = dict_encode(data, 4, enc, MAX_BUF);
    check(elen == 1, "dict_one_pattern_enc"); /* single token */
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 4 && mem_eq(data, dec, 4), "dict_one_pattern_roundtrip");

    /* Two bytes */
    data[0] = 0xAA; data[1] = 0xBB;
    elen = dict_encode(data, 2, enc, MAX_BUF);
    dlen = dict_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 2 && mem_eq(data, dec, 2), "dict_two_bytes_roundtrip");
}

static void test_rle_edge_pattern(void) {
    unsigned char data[256], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[rle_edge_pattern]\n");

    /* Pattern: each byte appears exactly once (worst case for RLE) */
    for (i = 0; i < 256; i++) data[i] = (unsigned char)i;
    elen = rle_encode(data, 256, enc, MAX_BUF);
    check(elen > 0, "rle_worst_enc");
    check(elen == 512, "rle_worst_expansion"); /* expands 2x */
    dlen = rle_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 256, "rle_worst_dec_len");
    check(mem_eq(data, dec, 256), "rle_worst_roundtrip");
}

static void test_lz77_repeated_pattern(void) {
    unsigned char data[256], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[lz77_repeated_pattern]\n");

    /* "ABCDABCDABCD..." - highly compressible */
    for (i = 0; i < 256; i++) data[i] = (unsigned char)('A' + (i % 4));
    elen = lz77_encode(data, 256, enc, MAX_BUF);
    check(elen > 0, "lz77_rep4_enc");
    check(elen < 256, "lz77_rep4_compressed");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 256, "lz77_rep4_dec_len");
    check(mem_eq(data, dec, 256), "lz77_rep4_roundtrip");
}

static void test_combined_pipeline(void) {
    unsigned char data[64], buf1[MAX_BUF], buf2[MAX_BUF], buf3[MAX_BUF];
    unsigned char r3[MAX_BUF], r2[MAX_BUF], r1[MAX_BUF];
    int l1, l2, l3, rl3, rl2, rl1;

    write_str("[combined_pipeline]\n");

    /* Pipeline: delta -> MTF -> RLE */
    gen_sequential(data, 64);

    l1 = delta_encode(data, 64, buf1, MAX_BUF);
    l2 = mtf_encode(buf1, l1, buf2, MAX_BUF);
    l3 = rle_encode(buf2, l2, buf3, MAX_BUF);
    check(l3 > 0, "pipeline_enc");

    /* Reverse: RLE -> MTF -> delta */
    rl3 = rle_decode(buf3, l3, r3, MAX_BUF);
    check(rl3 == l2, "pipeline_rle_dec");
    rl2 = mtf_decode(r3, rl3, r2, MAX_BUF);
    check(rl2 == l1, "pipeline_mtf_dec");
    rl1 = delta_decode(r2, rl2, r1, MAX_BUF);
    check(rl1 == 64, "pipeline_delta_dec");
    check(mem_eq(data, r1, 64), "pipeline_roundtrip");
}

static void test_empty_inputs(void) {
    unsigned char enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[empty_inputs]\n");

    /* Delta empty */
    elen = delta_encode(NULL, 0, enc, MAX_BUF);
    check(elen == 0, "empty_delta_enc");
    dlen = delta_decode(NULL, 0, dec, MAX_BUF);
    check(dlen == 0, "empty_delta_dec");

    /* RLE empty */
    elen = rle_encode(NULL, 0, enc, MAX_BUF);
    check(elen == 0, "empty_rle_enc");
    dlen = rle_decode(NULL, 0, dec, MAX_BUF);
    check(dlen == 0, "empty_rle_dec");

    /* LZ77 empty */
    elen = lz77_encode(NULL, 0, enc, MAX_BUF);
    check(elen == 0, "empty_lz77_enc");
    dlen = lz77_decode(NULL, 0, dec, MAX_BUF);
    check(dlen == 0, "empty_lz77_dec");
}

static void test_huffman_stress(void) {
    HuffNode nodes[HUFF_MAX_NODES];
    HuffCode codes[HUFF_MAX_SYMBOLS];
    unsigned char data[200], enc[MAX_BUF], dec[MAX_BUF];
    unsigned char path[HUFF_MAX_CODE_LEN];
    int root, elen, dlen, total_bits, i;
    unsigned int seeds[] = {1111, 2222, 3333, 4444, 5555};
    int ns = 5;
    int test;

    write_str("[huffman_stress]\n");

    for (test = 0; test < ns; test++) {
        gen_random(data, 150, seeds[test]);
        memset(codes, 0, sizeof(codes));
        huff_build_tree(data, 150, nodes, &root);
        check(root >= 0, "huff_stress_root");
        huff_build_codes(nodes, root, codes, path, 0);

        total_bits = 0;
        for (i = 0; i < 150; i++) total_bits += codes[data[i]].length;
        elen = huff_encode(data, 150, codes, enc, MAX_BUF);
        check(elen > 0, "huff_stress_enc");

        dlen = huff_decode(enc, total_bits, nodes, root, dec, MAX_BUF);
        check(dlen == 150, "huff_stress_dec_len");
        check(mem_eq(data, dec, 150), "huff_stress_roundtrip");
    }
}

static void test_compression_ratios(void) {
    unsigned char data[256], enc[MAX_BUF];
    int elen;

    write_str("[compression_ratios]\n");

    /* RLE on all-zeros: should compress very well */
    gen_all_zeros(data, 256);
    elen = rle_encode(data, 256, enc, MAX_BUF);
    check(elen <= 4, "ratio_rle_zeros"); /* 256 zeros -> (255,0)(1,0) = 4 bytes */

    /* LZ77 on repeated pattern: should compress */
    {
        int i;
        for (i = 0; i < 256; i++) data[i] = (unsigned char)(i % 4);
    }
    elen = lz77_encode(data, 256, enc, MAX_BUF);
    check(elen < 128, "ratio_lz77_repeat");

    /* Delta on sequential: produces constants */
    gen_sequential(data, 256);
    elen = delta_encode(data, 256, enc, MAX_BUF);
    {
        /* Delta of sequential produces: 0,1,1,1,...
         * Then RLE of that is very small */
        unsigned char rle_buf[MAX_BUF];
        int rle_len = rle_encode(enc, elen, rle_buf, MAX_BUF);
        check(rle_len <= 6, "ratio_delta_rle_seq");
    }
}

static void test_bitstream_operations(void) {
    BitStream bs;
    int i, ok;

    write_str("[bitstream_ops]\n");

    /* Write and read back individual bits */
    bs_init(&bs);
    bs_write_bit(&bs, 1);
    bs_write_bit(&bs, 0);
    bs_write_bit(&bs, 1);
    bs_write_bit(&bs, 1);
    bs_write_bit(&bs, 0);
    bs_write_bit(&bs, 0);
    bs_write_bit(&bs, 1);
    bs_write_bit(&bs, 0);

    /* Reset read position */
    bs.byte_pos = 0; bs.bit_pos = 0;
    check(bs_read_bit(&bs) == 1, "bs_bit0");
    check(bs_read_bit(&bs) == 0, "bs_bit1");
    check(bs_read_bit(&bs) == 1, "bs_bit2");
    check(bs_read_bit(&bs) == 1, "bs_bit3");
    check(bs_read_bit(&bs) == 0, "bs_bit4");
    check(bs_read_bit(&bs) == 0, "bs_bit5");
    check(bs_read_bit(&bs) == 1, "bs_bit6");
    check(bs_read_bit(&bs) == 0, "bs_bit7");

    /* Write 16 alternating bits */
    bs_init(&bs);
    for (i = 0; i < 16; i++) bs_write_bit(&bs, i & 1);
    check(bs_total_bytes(&bs) == 2, "bs_16bits_2bytes");

    bs.byte_pos = 0; bs.bit_pos = 0;
    ok = 1;
    for (i = 0; i < 16; i++)
        if (bs_read_bit(&bs) != (i & 1)) ok = 0;
    check(ok, "bs_16bits_roundtrip");
}

static void test_mtf_with_rle_compression(void) {
    unsigned char data[100], mtf_out[MAX_BUF], rle_out[MAX_BUF];
    unsigned char rle_dec[MAX_BUF], mtf_dec[MAX_BUF];
    int mlen, rlen, rdlen, mdlen;
    int zeros_mtf, zeros_raw, i;

    write_str("[mtf_rle_compression]\n");

    /* Data with runs: MTF should produce many zeros */
    gen_runs(data, 100);
    mlen = mtf_encode(data, 100, mtf_out, MAX_BUF);

    /* Count zeros in MTF output vs original */
    zeros_mtf = 0; zeros_raw = 0;
    for (i = 0; i < 100; i++) {
        if (mtf_out[i] == 0) zeros_mtf++;
        if (data[i] == 0) zeros_raw++;
    }
    check(zeros_mtf >= zeros_raw, "mtf_more_zeros");

    /* RLE after MTF */
    rlen = rle_encode(mtf_out, mlen, rle_out, MAX_BUF);
    check(rlen > 0, "mtf_rle_enc");

    /* Decode */
    rdlen = rle_decode(rle_out, rlen, rle_dec, MAX_BUF);
    mdlen = mtf_decode(rle_dec, rdlen, mtf_dec, MAX_BUF);
    check(mdlen == 100, "mtf_rle_dec_len");
    check(mem_eq(data, mtf_dec, 100), "mtf_rle_roundtrip");
}

static void test_lz77_worst_case(void) {
    unsigned char data[128], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen, i;

    write_str("[lz77_worst_case]\n");

    /* No repeated patterns: each byte unique */
    for (i = 0; i < 128; i++) data[i] = (unsigned char)i;
    elen = lz77_encode(data, 128, enc, MAX_BUF);
    check(elen > 0, "lz77_worst_enc");
    /* Should expand (all literals) */
    check(elen >= 128, "lz77_worst_expansion");
    dlen = lz77_decode(enc, elen, dec, MAX_BUF);
    check(dlen == 128, "lz77_worst_dec_len");
    check(mem_eq(data, dec, 128), "lz77_worst_roundtrip");
}

static void test_range_coder_short(void) {
    unsigned char data[4], enc[MAX_BUF], dec[MAX_BUF];
    int elen, dlen;

    write_str("[range_coder_short]\n");

    data[0] = 0xAB; data[1] = 0xCD; data[2] = 0xEF; data[3] = 0x01;
    elen = range_encode_bytes(data, 4, enc, MAX_BUF, 128);
    check(elen > 0, "rc_short_enc");
    dlen = range_decode_bytes(enc, elen, dec, 4, 128);
    check(dlen == 4, "rc_short_dec_len");
    check(mem_eq(data, dec, 4), "rc_short_roundtrip");
}

static void test_golomb_single_value(void) {
    int values[1], decoded[1];
    unsigned char enc[MAX_BUF];
    int elen;

    write_str("[golomb_single_value]\n");

    values[0] = 42;
    elen = golomb_rice_encode(values, 1, 3, enc, MAX_BUF);
    check(elen > 0, "golomb_single_enc");
    golomb_rice_decode(enc, elen, 3, decoded, 1);
    check(decoded[0] == 42, "golomb_single_roundtrip");

    values[0] = 0;
    elen = golomb_rice_encode(values, 1, 2, enc, MAX_BUF);
    golomb_rice_decode(enc, elen, 2, decoded, 1);
    check(decoded[0] == 0, "golomb_zero_roundtrip");
}

static void test_bwt_property(void) {
    unsigned char data[16], enc[BWT_MAX];
    int orig, i;
    int freq_in[256], freq_out[256];
    int ok;

    write_str("[bwt_property]\n");

    /* BWT preserves character frequencies */
    memcpy(data, "abcabcabcabcabca", 16);
    bwt_encode(data, 16, enc, BWT_MAX, &orig);

    memset(freq_in, 0, sizeof(freq_in));
    memset(freq_out, 0, sizeof(freq_out));
    for (i = 0; i < 16; i++) {
        freq_in[data[i]]++;
        freq_out[enc[i]]++;
    }

    ok = 1;
    for (i = 0; i < 256; i++)
        if (freq_in[i] != freq_out[i]) ok = 0;
    check(ok, "bwt_freq_preserved");
}

static void test_delta_double(void) {
    unsigned char data[64], d1[MAX_BUF], d2[MAX_BUF];
    unsigned char r2[MAX_BUF], r1[MAX_BUF];
    int l1, l2, rl2, rl1;

    write_str("[delta_double]\n");

    /* Double delta encoding: for quadratic data this creates constants */
    {
        int i;
        for (i = 0; i < 64; i++) data[i] = (unsigned char)((i * i) & 0xFF);
    }
    l1 = delta_encode(data, 64, d1, MAX_BUF);
    l2 = delta_encode(d1, l1, d2, MAX_BUF);
    check(l2 == 64, "double_delta_enc");

    rl2 = delta_decode(d2, l2, r2, MAX_BUF);
    rl1 = delta_decode(r2, rl2, r1, MAX_BUF);
    check(rl1 == 64, "double_delta_dec_len");
    check(mem_eq(data, r1, 64), "double_delta_roundtrip");
}

/* ========================================================================
 * MAIN
 * ======================================================================== */

int main(void) {
    g_errs = 0;
    init_io();

    write_str("=== victim_compress tests ===\n");

    /* RLE tests */
    test_rle_basic();
    test_rle_runs();
    test_rle_random();
    test_rle_long_run();
    test_rle_edge_pattern();
    test_rle_various_sizes();

    /* LZ77 tests */
    test_lz77_basic();
    test_lz77_zeros();
    test_lz77_random();
    test_lz77_text();
    test_lz77_short();
    test_lz77_repeated_pattern();
    test_lz77_worst_case();
    test_lz77_various_sizes();

    /* Huffman tests */
    test_huffman_basic();
    test_huffman_single_symbol();
    test_huffman_random();
    test_huffman_two_symbols();
    test_huffman_text();
    test_huffman_stress();

    /* Delta tests */
    test_delta_basic();
    test_delta_zeros();
    test_delta_random();
    test_delta_alternating();
    test_delta_single();
    test_delta_double();

    /* Bit-packing tests */
    test_bitpack_basic();
    test_bitpack_1bit();
    test_bitpack_8bit();
    test_bitpack_5bit();
    test_bitpack_stress();

    /* MTF tests */
    test_mtf_basic();
    test_mtf_random();
    test_mtf_sequential();
    test_mtf_single();

    /* BWT tests */
    test_bwt_basic();
    test_bwt_all_same();
    test_bwt_short_strings();
    test_bwt_random();
    test_bwt_longer();
    test_bwt_multiple();
    test_bwt_property();

    /* Range coder tests */
    test_range_coder_basic();
    test_range_coder_random();
    test_range_coder_biased();
    test_range_coder_all_ones();
    test_range_coder_various_probs();
    test_range_coder_short();

    /* Dictionary compression tests */
    test_dict_basic();
    test_dict_no_matches();
    test_dict_all_patterns();
    test_dict_friendly();
    test_dict_edge_cases();

    /* Golomb-Rice tests */
    test_golomb_basic();
    test_golomb_k1();
    test_golomb_k3();
    test_golomb_zeros();
    test_golomb_large_values();
    test_golomb_single_value();
    test_golomb_stress();

    /* Combined/pipeline tests */
    test_delta_then_rle();
    test_mtf_then_rle();
    test_bwt_then_mtf();
    test_delta_then_huffman();
    test_combined_pipeline();
    test_all_encoders_stress();
    test_compression_ratios();
    test_mtf_with_rle_compression();

    /* Misc tests */
    test_bitstream_operations();
    test_empty_inputs();

    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
