// stress_victim.c - Standard C version of compiler_stress.mc
// Windows: cl /nologo /O1 stress_victim.c /link /SUBSYSTEM:CONSOLE kernel32.lib
// Linux:   gcc -m32 -pie -fpie -O2 -o stress_victim stress_victim.c
// Expected exit code: 0 (all 22 sections pass)

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

// ============================================================
// Struct definitions
// ============================================================

typedef struct Point {
    int x;
    int y;
} Point;

typedef struct ListNode {
    int val;
    struct ListNode* next;
} ListNode;

// ============================================================
// Globals
// ============================================================

int g_counter;
int g_accum;
#ifdef _WIN32
HANDLE g_stdout;
#endif

// ============================================================
// Forward declarations (mutual recursion)
// ============================================================

int is_even(int n);
int is_odd(int n);

// ============================================================
// I/O helpers
// ============================================================

void init_io(void) {
#ifdef _WIN32
    g_stdout = GetStdHandle(STD_OUTPUT_HANDLE);
#endif
}

void write_str(const char* s) {
#ifdef _WIN32
    DWORD written;
    WriteFile(g_stdout, s, (DWORD)strlen(s), &written, NULL);
#else
    write(1, s, strlen(s));
#endif
}

void write_int(int n) {
    char buf[20];
    int i, neg;
    if (n == 0) { write_str("0"); return; }
    neg = 0;
    if (n < 0) { neg = 1; n = -n; }
    i = 19;
    buf[i] = 0;
    while (n > 0) {
        i--;
        buf[i] = (char)((n % 10) + 48);
        n = n / 10;
    }
    if (neg) { i--; buf[i] = '-'; }
    write_str(&buf[i]);
}

void write_section(int n, const char* name) {
    write_str("[");
    write_int(n);
    write_str("] ");
    write_str(name);
    write_str(" ... ");
}

void write_result(int errs) {
    if (errs == 0) {
        write_str("PASS\n");
    } else {
        write_str("FAIL (");
        write_int(errs);
        write_str(" errors)\n");
    }
}

// ============================================================
// Section 1: Arithmetic
// ============================================================

int test_arith(void) {
    int a, b, err = 0;
    a = 17; b = 5;
    if (a + b != 22)            err++;
    if (a - b != 12)            err++;
    if (a * b != 85)            err++;
    if (a / b != 3)             err++;
    if (a % b != 2)             err++;
    if (-a != -17)              err++;
    if (a * -1 != -17)          err++;
    if (-b * -b != 25)          err++;
    if (100 / 10 / 2 != 5)     err++;
    if (100 % 30 != 10)        err++;
    if (a + b * 2 != 27)       err++;
    if ((a + b) * 2 != 44)     err++;
    if (a - b - 2 != 10)       err++;
    if (1000 * 1000 != 1000000) err++;
    return err;
}

// ============================================================
// Section 2: Bitwise Operations
// ============================================================

int test_bitwise(void) {
    int a, b, err = 0;
    a = 0xFF; b = 0x0F;
    if ((a & b) != 15)           err++;
    if ((a | b) != 255)          err++;
    if ((a ^ b) != 240)          err++;
    if (~0 != -1)                err++;
    if ((~a & 0xFF) != 0)        err++;
    if ((0xAA & 0x55) != 0)      err++;
    if ((0xAA | 0x55) != 255)    err++;
    if ((0xAA ^ 0xAA) != 0)      err++;
    if ((0xF0 & 0x0F) != 0)      err++;
    if ((0xF0 | 0x0F) != 0xFF)   err++;
    if ((~255 & 0xFFFF) != 0xFF00) err++;
    return err;
}

// ============================================================
// Section 3: Shift Operations
// ============================================================

int test_shifts(void) {
    int a, err = 0;
    a = 1;
    if ((a << 0)  != 1)     err++;
    if ((a << 1)  != 2)     err++;
    if ((a << 8)  != 256)   err++;
    if ((a << 16) != 65536) err++;
    if ((256 >> 1) != 128)  err++;
    if ((256 >> 8) != 1)    err++;
    if ((0xFF << 4)  != 0xFF0) err++;
    if ((0xFF0 >> 4) != 0xFF)  err++;
    a = 3;
    if ((8 >> a) != 1)  err++;
    if ((1 << a) != 8)  err++;
    if ((64 >> a) != 8) err++;
    if ((128 >> a) != 16) err++;
    if ((16 << a) != 128) err++;
    return err;
}

// ============================================================
// Section 4: All Comparison Operators
// ============================================================

int test_compare(void) {
    int a, b, err = 0;
    a = 10; b = 20;
    if (!(a < b))  err++;
    if (!(a <= b)) err++;
    if (a > b)     err++;
    if (a >= b)    err++;
    if (!(a != b)) err++;
    if (a == b)    err++;
    if (!(a == 10)) err++;
    a = 7; b = 7;
    if (!(a == b)) err++;
    if (!(a >= b)) err++;
    if (!(a <= b)) err++;
    if (a != b)    err++;
    if (a > b)     err++;
    if (a < b)     err++;
    a = -10; b = 10;
    if (!(a < b))  err++;
    if (!(a < 0))  err++;
    if (!(b > 0))  err++;
    if (!(a != b)) err++;
    if (a > 0)     err++;
    return err;
}

// ============================================================
// Section 5: Logical Operators
// ============================================================

int test_logical(void) {
    int a, b, err = 0;
    a = 1; b = 0;
    if (!(a && a))  err++;
    if (a && b)     err++;
    if (!(a || b))  err++;
    if (b || b)     err++;
    if (!a)         err++;
    if (!!b)        err++;
    if (!(!b))      err++;
    a = 5; b = 10;
    if (!(a > 0 && b > 0))    err++;
    if (!(a < b || b < a))    err++;
    if (a < 0 || b < 0)       err++;
    if (!(a == 5 && b == 10)) err++;
    return err;
}

// ============================================================
// Section 6: If/else chains
// ============================================================

int classify(int n) {
    if (n < 0) return -1;
    else if (n == 0) return 0;
    else if (n < 10) return 1;
    else if (n < 100) return 2;
    else return 3;
}

int test_if(void) {
    int err = 0, x;
    if (classify(-5)  != -1) err++;
    if (classify(0)   !=  0) err++;
    if (classify(5)   !=  1) err++;
    if (classify(50)  !=  2) err++;
    if (classify(500) !=  3) err++;
    x = 7;
    if (x > 0) { if (x < 10) { if (x == 7) { x = 42; } } }
    if (x != 42) err++;
    x = 0;
    if (1) x = 1;
    if (x != 1) err++;
    if (0) { x = 99; } else { x = 55; }
    if (x != 55) err++;
    return err;
}

// ============================================================
// Section 7: While loops with break and continue
// ============================================================

int test_while(void) {
    int err = 0, i, sum, j;
    sum = 0; i = 1;
    while (i <= 10) { sum += i; i++; }
    if (sum != 55) err++;
    sum = 0; i = 0;
    while (1) { i++; if (i > 5) break; sum += i; }
    if (sum != 15) err++;
    sum = 0; i = 0;
    while (i < 10) { i++; if (i % 2 == 0) continue; sum += i; }
    if (sum != 25) err++;
    sum = 0; i = 1;
    while (i <= 4) { j = 1; while (j <= 4) { sum++; j++; } i++; }
    if (sum != 16) err++;
    return err;
}

// ============================================================
// Section 8: For loops
// ============================================================

int test_for(void) {
    int err = 0, i, sum, j;
    sum = 0;
    for (i = 0; i < 10; i++) sum += i;
    if (sum != 45) err++;
    sum = 0;
    for (i = 1; i <= 5; i++) sum += i;
    if (sum != 15) err++;
    sum = 0;
    for (i = 0; i < 100; i++) { if (i >= 5) break; sum += i; }
    if (sum != 10) err++;
    sum = 0;
    for (i = 1; i <= 10; i++) { if (i % 3 == 0) continue; sum += i; }
    if (sum != 37) err++;
    sum = 0;
    for (i = 0; i < 5; i++) for (j = 0; j < 5; j++) sum++;
    if (sum != 25) err++;
    sum = 0;
    for (i = 10; i >= 1; i--) sum += i;
    if (sum != 55) err++;
    return err;
}

// ============================================================
// Section 9: Recursion
// ============================================================

int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int fib_rec(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return fib_rec(n - 1) + fib_rec(n - 2);
}

int power(int base, int exp) {
    if (exp == 0) return 1;
    return base * power(base, exp - 1);
}

int test_recursion(void) {
    int err = 0;
    if (factorial(0)  != 1)       err++;
    if (factorial(1)  != 1)       err++;
    if (factorial(5)  != 120)     err++;
    if (factorial(10) != 3628800) err++;
    if (fib_rec(0)  != 0)   err++;
    if (fib_rec(1)  != 1)   err++;
    if (fib_rec(10) != 55)  err++;
    if (fib_rec(15) != 610) err++;
    if (power(2, 0)  != 1)     err++;
    if (power(2, 10) != 1024)  err++;
    if (power(3, 5)  != 243)   err++;
    if (power(10, 4) != 10000) err++;
    return err;
}

// ============================================================
// Section 10: Mutual Recursion
// ============================================================

int is_even(int n) {
    if (n == 0) return 1;
    return is_odd(n - 1);
}

int is_odd(int n) {
    if (n == 0) return 0;
    return is_even(n - 1);
}

int test_mutual(void) {
    int err = 0;
    if (!is_even(0))   err++;
    if ( is_odd(0))    err++;
    if (!is_even(10))  err++;
    if (!is_odd(7))    err++;
    if ( is_even(3))   err++;
    if (!is_odd(99))   err++;
    if (!is_even(100)) err++;
    if ( is_odd(100))  err++;
    return err;
}

// ============================================================
// Section 11: Global Variables
// ============================================================

void g_inc(void) {
    g_counter++;
    g_accum += g_counter;
}

int test_globals(void) {
    int err = 0, i;
    g_counter = 0; g_accum = 0;
    for (i = 0; i < 5; i++) g_inc();
    if (g_counter != 5)  err++;
    if (g_accum   != 15) err++;
    g_counter = 100;
    g_counter = g_counter * 2 + g_accum;
    if (g_counter != 215) err++;
    g_counter = 0; g_accum = 0;
    for (i = 0; i < 10; i++) g_inc();
    if (g_counter != 10) err++;
    if (g_accum != 55)   err++;
    return err;
}

// ============================================================
// Section 12: Pointers and Address-of
// ============================================================

void swap(int* a, int* b) {
    int tmp = *a; *a = *b; *b = tmp;
}

int sum_via_ptr(int* arr, int n) {
    int sum = 0, i;
    for (i = 0; i < n; i++) sum += arr[i];
    return sum;
}

int test_pointers(void) {
    int err = 0, x, y;
    int* p;
    int** pp;
    int arr[5];
    x = 10; y = 20;
    swap(&x, &y);
    if (x != 20) err++;
    if (y != 10) err++;
    p = &x;
    if (*p != 20) err++;
    *p = 99;
    if (x != 99) err++;
    pp = &p;
    **pp = 77;
    if (x != 77) err++;
    arr[0]=1; arr[1]=2; arr[2]=3; arr[3]=4; arr[4]=5;
    if (sum_via_ptr(arr, 5) != 15) err++;
    return err;
}

// ============================================================
// Section 13: Arrays
// ============================================================

int str_len(const char* s) {
    int len = 0;
    while (s[len] != 0) len++;
    return len;
}

int test_arrays(void) {
    int err = 0, i, sum;
    char buf[20];
    int arr[10];
    buf[0]='H'; buf[1]='e'; buf[2]='l'; buf[3]='l'; buf[4]='o'; buf[5]=0;
    if (str_len(buf) != 5) err++;
    if (buf[0] != 72) err++;
    for (i = 0; i < 10; i++) buf[i] = (char)(48 + i);
    buf[10] = 0;
    if (str_len(buf) != 10) err++;
    if (buf[0] != '0') err++;
    if (buf[9] != '9') err++;
    sum = 0;
    for (i = 0; i < 10; i++) { arr[i] = i * 2; sum += arr[i]; }
    if (sum != 90) err++;
    sum = 0;
    for (i = 9; i >= 0; i--) sum += arr[i];
    if (sum != 90) err++;
    for (i = 0; i < 10; i++) arr[i]++;
    if (arr[0] != 1) err++;
    if (arr[9] != 19) err++;
    return err;
}

// ============================================================
// Section 14: Structs
// ============================================================

void point_set(Point* p, int x, int y) { p->x = x; p->y = y; }
int point_dist_sq(Point* p) { return p->x * p->x + p->y * p->y; }
void point_scale(Point* p, int factor) { p->x *= factor; p->y *= factor; }

int test_structs(void) {
    int err = 0;
    Point* pt = (Point*)malloc(sizeof(Point));
    Point* a  = (Point*)malloc(sizeof(Point));
    Point* b  = (Point*)malloc(sizeof(Point));
    Point* pp;
    point_set(pt, 3, 4);
    if (pt->x != 3) err++;
    if (pt->y != 4) err++;
    if (point_dist_sq(pt) != 25) err++;
    pp = pt;
    if (pp->x != 3) err++;
    pp->x = 6; pp->y = 8;
    if (point_dist_sq(pp) != 100) err++;
    point_scale(pt, 2);
    if (pt->x != 12) err++;
    if (pt->y != 16) err++;
    point_set(a, 1, 2);
    point_set(b, 3, 4);
    if (a->x + b->x != 4) err++;
    if (a->y + b->y != 6) err++;
    if (point_dist_sq(a) != 5) err++;
    if (point_dist_sq(b) != 25) err++;
    free(pt); free(a); free(b);
    return err;
}

// ============================================================
// Section 15: Linked list
// ============================================================

ListNode* node_new(int val) {
    ListNode* n = (ListNode*)malloc(sizeof(ListNode));
    n->val = val;
    n->next = NULL;
    return n;
}

int list_sum(ListNode* head) {
    int sum = 0;
    while (head) { sum += head->val; head = head->next; }
    return sum;
}

int list_len(ListNode* head) {
    int len = 0;
    while (head) { len++; head = head->next; }
    return len;
}

ListNode* list_prepend(ListNode* head, int val) {
    ListNode* n = node_new(val);
    n->next = head;
    return n;
}

int test_list(void) {
    int err = 0, i;
    ListNode* head = NULL;
    head = list_prepend(head, 5);
    head = list_prepend(head, 4);
    head = list_prepend(head, 3);
    head = list_prepend(head, 2);
    head = list_prepend(head, 1);
    if (list_len(head) != 5) err++;
    if (list_sum(head) != 15) err++;
    if (head->val != 1) err++;
    head = NULL;
    for (i = 10; i >= 1; i--) head = list_prepend(head, i);
    if (list_len(head) != 10) err++;
    if (list_sum(head) != 55) err++;
    return err;
}

// ============================================================
// Section 16: sizeof
// ============================================================

int test_sizeof(void) {
    int err = 0;
    if (sizeof(int) != 4) err++;
    if (sizeof(char) != 1) err++;
    if (sizeof(int*) != 4) err++;
    if (sizeof(Point) != 8) err++;
    if (sizeof(ListNode) != 8) err++;
    return err;
}

// ============================================================
// Section 17: Compound Assignment
// ============================================================

int test_compound(void) {
    int a, err = 0, i;
    a = 10;
    a += 5;  if (a != 15) err++;
    a -= 3;  if (a != 12) err++;
    a += a;  if (a != 24) err++;
    a = 0;
    for (i = 1; i <= 10; i++) a += i;
    if (a != 55) err++;
    a = 100;
    for (i = 1; i <= 10; i++) a -= i;
    if (a != 45) err++;
    return err;
}

// ============================================================
// Section 18: Register Pressure
// ============================================================

int reg_helper(int a, int b, int c, int d) {
    return a * b + c * d;
}

int test_regpressure(void) {
    int a=1,b=2,c=3,d=4,e=5,f=6,g=7,h=8;
    int sum, r1, r2, r3, x, y, z, q;
    int err = 0;
    sum = a+b+c+d+e+f+g+h;
    if (sum != 36) err++;
    r1 = a*b + c*d;
    r2 = e*f - g*h;
    r3 = r1 + r2;
    if (r1 != 14) err++;
    if (r2 != -26) err++;
    if (r3 != -12) err++;
    x = a << b;
    y = c | (d << e);
    z = (g & h) ^ f;
    if (x != 4) err++;
    if (y != 131) err++;
    if (z != 6) err++;
    q = reg_helper(a+b, c+d, e+f, g+h);
    if (q != 186) err++;
    if (a+b+c+d+e+f+g+h != 36) err++;
    return err;
}

// ============================================================
// Section 19: Char literals and XOR checksum
// ============================================================

int test_chars(void) {
    int err = 0, n, cs, i;
    char buf[8];
    buf[0]='A'; buf[1]='B'; buf[2]='C'; buf[3]='D'; buf[4]='E'; buf[5]=0;
    if (buf[0] != 65) err++;
    if (buf[4] != 69) err++;
    n = 0;
    while (buf[n] != 0) n++;
    if (n != 5) err++;
    cs = 0;
    for (i = 0; i < n; i++) cs ^= buf[i];
    if (cs != 65) err++;
    buf[0]='a'; buf[1]='z';
    if (buf[0] != 97) err++;
    if (buf[1] != 122) err++;
    if (buf[1]-buf[0] != 25) err++;
    buf[2] = 0;
    n = 0;
    while (buf[n] != 0) n++;
    if (n != 2) err++;
    return err;
}

// ============================================================
// Section 20: Nested function calls
// ============================================================

int add2(int a, int b) { return a + b; }
int mul2(int a, int b) { return a * b; }
int sub2(int a, int b) { return a - b; }
int max2(int a, int b) { return a > b ? a : b; }
int min2(int a, int b) { return a < b ? a : b; }

int test_nested(void) {
    int err = 0;
    if (add2(mul2(3,4), sub2(10,3)) != 19) err++;
    if (mul2(add2(1,2), add2(3,4)) != 21) err++;
    if (add2(add2(add2(1,2),add2(3,4)), add2(add2(5,6),add2(7,8))) != 36) err++;
    if (max2(max2(3,7), max2(1,5)) != 7) err++;
    if (min2(min2(8,3), min2(6,2)) != 2) err++;
    if (mul2(add2(2,3), sub2(10,4)) - 1 != 29) err++;
    return err;
}

// ============================================================
// Section 21: Array computation
// ============================================================

int test_loop_array(void) {
    int arr[16], i, sum, mx, err = 0;
    for (i = 0; i < 16; i++) arr[i] = i * i;
    sum = 0;
    for (i = 0; i < 16; i++) sum += arr[i];
    if (sum != 1240) err++;
    sum = 0;
    for (i = 15; i >= 0; i--) sum += arr[i];
    if (sum != 1240) err++;
    mx = arr[0];
    for (i = 1; i < 16; i++) if (arr[i] > mx) mx = arr[i];
    if (mx != 225) err++;
    for (i = 0; i < 16; i++) arr[i] = -arr[i];
    sum = 0;
    for (i = 0; i < 16; i++) sum += arr[i];
    if (sum != -1240) err++;
    return err;
}

// ============================================================
// Section 22: Inc/Dec
// ============================================================

int test_incdec(void) {
    int err = 0, a, r, sum, i;
    a = 5; r = ++a;
    if (r != 6) err++;
    if (a != 6) err++;
    a = 5; r = a++;
    if (r != 5) err++;
    if (a != 6) err++;
    a = 5; r = --a;
    if (r != 4) err++;
    if (a != 4) err++;
    a = 5; r = a--;
    if (r != 5) err++;
    if (a != 4) err++;
    sum = 0;
    for (i = 0; i < 5; i++) sum += i;
    if (sum != 10) err++;
    sum = 0;
    for (i = 4; i >= 0; i--) sum += i;
    if (sum != 10) err++;
    return err;
}

// ============================================================
// Main
// ============================================================

int main(void) {
    int errors = 0, n;

    init_io();
    write_str("=== stress_victim: 22 sections ===\n");

    write_section(1,  "arithmetic");
    n = test_arith();       errors += n; write_result(n);

    write_section(2,  "bitwise");
    n = test_bitwise();     errors += n; write_result(n);

    write_section(3,  "shifts");
    n = test_shifts();      errors += n; write_result(n);

    write_section(4,  "comparisons");
    n = test_compare();     errors += n; write_result(n);

    write_section(5,  "logical ops");
    n = test_logical();     errors += n; write_result(n);

    write_section(6,  "if/else");
    n = test_if();          errors += n; write_result(n);

    write_section(7,  "while loops");
    n = test_while();       errors += n; write_result(n);

    write_section(8,  "for loops");
    n = test_for();         errors += n; write_result(n);

    write_section(9,  "recursion");
    n = test_recursion();   errors += n; write_result(n);

    write_section(10, "mutual recursion");
    n = test_mutual();      errors += n; write_result(n);

    write_section(11, "globals");
    n = test_globals();     errors += n; write_result(n);

    write_section(12, "pointers");
    n = test_pointers();    errors += n; write_result(n);

    write_section(13, "arrays");
    n = test_arrays();      errors += n; write_result(n);

    write_section(14, "structs");
    n = test_structs();     errors += n; write_result(n);

    write_section(15, "linked list");
    n = test_list();        errors += n; write_result(n);

    write_section(16, "sizeof");
    n = test_sizeof();      errors += n; write_result(n);

    write_section(17, "compound assign");
    n = test_compound();    errors += n; write_result(n);

    write_section(18, "register pressure");
    n = test_regpressure(); errors += n; write_result(n);

    write_section(19, "char literals");
    n = test_chars();       errors += n; write_result(n);

    write_section(20, "nested calls");
    n = test_nested();      errors += n; write_result(n);

    write_section(21, "array computation");
    n = test_loop_array();  errors += n; write_result(n);

    write_section(22, "inc/dec");
    n = test_incdec();      errors += n; write_result(n);

    write_str("=== Total errors: ");
    write_int(errors);
    write_str(" ===\n");

    return errors;
}
