/*
 * victim_tree.c - Tree data structures stress test
 * Build: cl /nologo /O1 victim_tree.c /Fe:victim_tree.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * Deterministic output, self-contained, Windows x86-32 (MSVC)
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ========================================================================
 * Memory pool (static allocation, no malloc)
 * ======================================================================== */
#define POOL_SIZE 16384
#define POOL_BYTES (POOL_SIZE * 64)
static char *g_pool;
static int g_pool_used;

static void pool_init(void) {
    if (!g_pool) g_pool = (char *)malloc(POOL_BYTES);
}
static void pool_reset(void) { g_pool_used = 0; }

static void* pool_alloc(int size) {
    void *p;
    /* Align to 4 bytes */
    size = (size + 3) & ~3;
    if (g_pool_used + size > POOL_BYTES) return NULL;
    p = &g_pool[g_pool_used];
    g_pool_used += size;
    memset(p, 0, size);
    return p;
}

/* ========================================================================
 * BST (Binary Search Tree)
 * ======================================================================== */
typedef struct BSTNode {
    int key;
    struct BSTNode *left, *right, *parent;
} BSTNode;

static BSTNode* bst_new_node(int key) {
    BSTNode *n = (BSTNode*)pool_alloc(sizeof(BSTNode));
    if (n) { n->key = key; n->left = n->right = n->parent = NULL; }
    return n;
}

static BSTNode* bst_insert(BSTNode *root, int key) {
    BSTNode *node = bst_new_node(key);
    BSTNode *y = NULL, *x = root;
    while (x != NULL) {
        y = x;
        if (key < x->key) x = x->left;
        else x = x->right;
    }
    node->parent = y;
    if (y == NULL) return node;
    if (key < y->key) y->left = node;
    else y->right = node;
    return root;
}

static BSTNode* bst_search(BSTNode *root, int key) {
    while (root != NULL && root->key != key) {
        if (key < root->key) root = root->left;
        else root = root->right;
    }
    return root;
}

static BSTNode* bst_min(BSTNode *root) {
    if (root == NULL) return NULL;
    while (root->left != NULL) root = root->left;
    return root;
}

static BSTNode* bst_max(BSTNode *root) {
    if (root == NULL) return NULL;
    while (root->right != NULL) root = root->right;
    return root;
}

static BSTNode* bst_successor(BSTNode *node) {
    BSTNode *p;
    if (node->right != NULL) return bst_min(node->right);
    p = node->parent;
    while (p != NULL && node == p->right) {
        node = p;
        p = p->parent;
    }
    return p;
}

static BSTNode* bst_predecessor(BSTNode *node) {
    BSTNode *p;
    if (node->left != NULL) return bst_max(node->left);
    p = node->parent;
    while (p != NULL && node == p->left) {
        node = p;
        p = p->parent;
    }
    return p;
}

static void bst_transplant(BSTNode **root, BSTNode *u, BSTNode *v) {
    if (u->parent == NULL) {
        *root = v;
    } else if (u == u->parent->left) {
        u->parent->left = v;
    } else {
        u->parent->right = v;
    }
    if (v != NULL) v->parent = u->parent;
}

static void bst_delete(BSTNode **root, int key) {
    BSTNode *z = bst_search(*root, key);
    BSTNode *y;
    if (z == NULL) return;
    if (z->left == NULL) {
        bst_transplant(root, z, z->right);
    } else if (z->right == NULL) {
        bst_transplant(root, z, z->left);
    } else {
        y = bst_min(z->right);
        if (y->parent != z) {
            bst_transplant(root, y, y->right);
            y->right = z->right;
            y->right->parent = y;
        }
        bst_transplant(root, z, y);
        y->left = z->left;
        y->left->parent = y;
    }
}

/* ========================================================================
 * BST Traversals (iterative using explicit stack)
 * ======================================================================== */
#define STACK_MAX 256

static int g_traversal[256];
static int g_trav_len;

static void bst_inorder_iterative(BSTNode *root) {
    BSTNode *stack[STACK_MAX];
    int top = 0;
    BSTNode *curr = root;
    g_trav_len = 0;
    while (curr != NULL || top > 0) {
        while (curr != NULL) {
            stack[top++] = curr;
            curr = curr->left;
        }
        curr = stack[--top];
        g_traversal[g_trav_len++] = curr->key;
        curr = curr->right;
    }
}

static void bst_preorder_iterative(BSTNode *root) {
    BSTNode *stack[STACK_MAX];
    int top = 0;
    g_trav_len = 0;
    if (root == NULL) return;
    stack[top++] = root;
    while (top > 0) {
        BSTNode *node = stack[--top];
        g_traversal[g_trav_len++] = node->key;
        if (node->right) stack[top++] = node->right;
        if (node->left) stack[top++] = node->left;
    }
}

static void bst_postorder_iterative(BSTNode *root) {
    BSTNode *stack1[STACK_MAX], *stack2[STACK_MAX];
    int top1 = 0, top2 = 0;
    g_trav_len = 0;
    if (root == NULL) return;
    stack1[top1++] = root;
    while (top1 > 0) {
        BSTNode *node = stack1[--top1];
        stack2[top2++] = node;
        if (node->left) stack1[top1++] = node->left;
        if (node->right) stack1[top1++] = node->right;
    }
    while (top2 > 0) {
        g_traversal[g_trav_len++] = stack2[--top2]->key;
    }
}

/* BST to sorted array */
static void bst_to_sorted_array(BSTNode *root, int *arr, int *count) {
    *count = 0;
    bst_inorder_iterative(root);
    memcpy(arr, g_traversal, g_trav_len * sizeof(int));
    *count = g_trav_len;
}

static int is_sorted(const int *arr, int len) {
    int i;
    for (i = 1; i < len; i++) {
        if (arr[i] < arr[i - 1]) return 0;
    }
    return 1;
}

static int bst_count(BSTNode *root) {
    if (root == NULL) return 0;
    return 1 + bst_count(root->left) + bst_count(root->right);
}

static void test_bst(void) {
    BSTNode *root = NULL;
    int arr[64], count;
    int i;

    write_str("[BST Basic Operations]\n");
    pool_reset();

    /* Insert 1-20 in scrambled order */
    {
        int order[] = {10, 5, 15, 3, 7, 12, 18, 1, 4, 6, 8, 11, 13, 16, 19, 2, 9, 14, 17, 20};
        for (i = 0; i < 20; i++) {
            root = bst_insert(root, order[i]);
        }
    }

    check(bst_count(root) == 20, "BST has 20 nodes");

    /* Search */
    check(bst_search(root, 1) != NULL, "find 1");
    check(bst_search(root, 10) != NULL, "find 10");
    check(bst_search(root, 20) != NULL, "find 20");
    check(bst_search(root, 0) == NULL, "not find 0");
    check(bst_search(root, 21) == NULL, "not find 21");
    check(bst_search(root, 100) == NULL, "not find 100");

    /* Min/Max */
    check(bst_min(root)->key == 1, "min==1");
    check(bst_max(root)->key == 20, "max==20");

    /* Successor/Predecessor */
    {
        BSTNode *n = bst_search(root, 5);
        check(bst_successor(n)->key == 6, "succ(5)==6");
        check(bst_predecessor(n)->key == 4, "pred(5)==4");
    }
    {
        BSTNode *n = bst_search(root, 1);
        check(bst_predecessor(n) == NULL, "pred(1)==NULL");
        check(bst_successor(n)->key == 2, "succ(1)==2");
    }
    {
        BSTNode *n = bst_search(root, 20);
        check(bst_successor(n) == NULL, "succ(20)==NULL");
        check(bst_predecessor(n)->key == 19, "pred(20)==19");
    }

    /* Inorder = sorted */
    bst_to_sorted_array(root, arr, &count);
    check(count == 20, "inorder count==20");
    check(is_sorted(arr, count), "inorder is sorted");
    check(arr[0] == 1, "inorder first==1");
    check(arr[19] == 20, "inorder last==20");

    /* Delete leaf */
    bst_delete(&root, 2);
    check(bst_search(root, 2) == NULL, "deleted 2");
    check(bst_count(root) == 19, "count after delete leaf");

    /* Delete node with one child */
    bst_delete(&root, 1);
    check(bst_search(root, 1) == NULL, "deleted 1");
    check(bst_count(root) == 18, "count after delete 1-child");

    /* Delete node with two children */
    bst_delete(&root, 10);
    check(bst_search(root, 10) == NULL, "deleted 10 (root)");
    check(bst_count(root) == 17, "count after delete 2-child");

    /* Verify still sorted after deletions */
    bst_to_sorted_array(root, arr, &count);
    check(is_sorted(arr, count), "still sorted after deletions");

    /* Delete all remaining */
    for (i = 3; i <= 20; i++) {
        bst_delete(&root, i);
    }
    check(root == NULL || bst_count(root) == 0, "tree empty after all deletes");
}

static void test_bst_traversals(void) {
    BSTNode *root = NULL;
    int i;

    write_str("[BST Traversals]\n");
    pool_reset();

    /*
     *        4
     *       / \
     *      2   6
     *     / \ / \
     *    1  3 5  7
     */
    root = bst_insert(root, 4);
    root = bst_insert(root, 2);
    root = bst_insert(root, 6);
    root = bst_insert(root, 1);
    root = bst_insert(root, 3);
    root = bst_insert(root, 5);
    root = bst_insert(root, 7);

    /* Inorder: 1 2 3 4 5 6 7 */
    bst_inorder_iterative(root);
    check(g_trav_len == 7, "inorder len==7");
    check(g_traversal[0] == 1, "inorder[0]==1");
    check(g_traversal[1] == 2, "inorder[1]==2");
    check(g_traversal[2] == 3, "inorder[2]==3");
    check(g_traversal[3] == 4, "inorder[3]==4");
    check(g_traversal[4] == 5, "inorder[4]==5");
    check(g_traversal[5] == 6, "inorder[5]==6");
    check(g_traversal[6] == 7, "inorder[6]==7");

    /* Preorder: 4 2 1 3 6 5 7 */
    bst_preorder_iterative(root);
    check(g_trav_len == 7, "preorder len==7");
    check(g_traversal[0] == 4, "preorder[0]==4");
    check(g_traversal[1] == 2, "preorder[1]==2");
    check(g_traversal[2] == 1, "preorder[2]==1");
    check(g_traversal[3] == 3, "preorder[3]==3");
    check(g_traversal[4] == 6, "preorder[4]==6");
    check(g_traversal[5] == 5, "preorder[5]==5");
    check(g_traversal[6] == 7, "preorder[6]==7");

    /* Postorder: 1 3 2 5 7 6 4 */
    bst_postorder_iterative(root);
    check(g_trav_len == 7, "postorder len==7");
    check(g_traversal[0] == 1, "postorder[0]==1");
    check(g_traversal[1] == 3, "postorder[1]==3");
    check(g_traversal[2] == 2, "postorder[2]==2");
    check(g_traversal[3] == 5, "postorder[3]==5");
    check(g_traversal[4] == 7, "postorder[4]==7");
    check(g_traversal[5] == 6, "postorder[5]==6");
    check(g_traversal[6] == 4, "postorder[6]==4");

    /* Larger tree: insert 1-20, inorder must be sorted */
    pool_reset();
    root = NULL;
    {
        int order[] = {15, 8, 20, 3, 12, 17, 1, 5, 10, 14, 16, 19, 2, 4, 6, 9, 11, 13, 18, 7};
        for (i = 0; i < 20; i++) {
            root = bst_insert(root, order[i]);
        }
    }
    bst_inorder_iterative(root);
    check(g_trav_len == 20, "large inorder len==20");
    check(is_sorted(g_traversal, g_trav_len), "large inorder sorted");
}

/* ========================================================================
 * AVL Tree
 * ======================================================================== */
typedef struct AVLNode {
    int key;
    int height;
    struct AVLNode *left, *right;
} AVLNode;

static AVLNode* avl_new_node(int key) {
    AVLNode *n = (AVLNode*)pool_alloc(sizeof(AVLNode));
    if (n) { n->key = key; n->height = 1; n->left = n->right = NULL; }
    return n;
}

static int avl_height(AVLNode *n) {
    return n ? n->height : 0;
}

static int avl_balance(AVLNode *n) {
    return n ? avl_height(n->left) - avl_height(n->right) : 0;
}

static void avl_update_height(AVLNode *n) {
    int hl = avl_height(n->left);
    int hr = avl_height(n->right);
    n->height = 1 + (hl > hr ? hl : hr);
}

/* Right rotation (LL case) */
static AVLNode* avl_rotate_right(AVLNode *y) {
    AVLNode *x = y->left;
    AVLNode *t2 = x->right;
    x->right = y;
    y->left = t2;
    avl_update_height(y);
    avl_update_height(x);
    return x;
}

/* Left rotation (RR case) */
static AVLNode* avl_rotate_left(AVLNode *x) {
    AVLNode *y = x->right;
    AVLNode *t2 = y->left;
    y->left = x;
    x->right = t2;
    avl_update_height(x);
    avl_update_height(y);
    return y;
}

static AVLNode* avl_insert(AVLNode *root, int key) {
    int balance;
    if (root == NULL) return avl_new_node(key);

    if (key < root->key)
        root->left = avl_insert(root->left, key);
    else if (key > root->key)
        root->right = avl_insert(root->right, key);
    else
        return root; /* duplicate */

    avl_update_height(root);
    balance = avl_balance(root);

    /* LL */
    if (balance > 1 && key < root->left->key)
        return avl_rotate_right(root);
    /* RR */
    if (balance < -1 && key > root->right->key)
        return avl_rotate_left(root);
    /* LR */
    if (balance > 1 && key > root->left->key) {
        root->left = avl_rotate_left(root->left);
        return avl_rotate_right(root);
    }
    /* RL */
    if (balance < -1 && key < root->right->key) {
        root->right = avl_rotate_right(root->right);
        return avl_rotate_left(root);
    }

    return root;
}

static AVLNode* avl_min_node(AVLNode *n) {
    while (n && n->left) n = n->left;
    return n;
}

static AVLNode* avl_delete(AVLNode *root, int key) {
    int balance;
    if (root == NULL) return NULL;

    if (key < root->key)
        root->left = avl_delete(root->left, key);
    else if (key > root->key)
        root->right = avl_delete(root->right, key);
    else {
        /* Found node to delete */
        if (root->left == NULL || root->right == NULL) {
            AVLNode *temp = root->left ? root->left : root->right;
            if (temp == NULL) {
                root = NULL;
            } else {
                *root = *temp;
            }
        } else {
            AVLNode *temp = avl_min_node(root->right);
            root->key = temp->key;
            root->right = avl_delete(root->right, temp->key);
        }
    }

    if (root == NULL) return NULL;

    avl_update_height(root);
    balance = avl_balance(root);

    /* LL */
    if (balance > 1 && avl_balance(root->left) >= 0)
        return avl_rotate_right(root);
    /* LR */
    if (balance > 1 && avl_balance(root->left) < 0) {
        root->left = avl_rotate_left(root->left);
        return avl_rotate_right(root);
    }
    /* RR */
    if (balance < -1 && avl_balance(root->right) <= 0)
        return avl_rotate_left(root);
    /* RL */
    if (balance < -1 && avl_balance(root->right) > 0) {
        root->right = avl_rotate_right(root->right);
        return avl_rotate_left(root);
    }

    return root;
}

static int avl_count(AVLNode *root) {
    if (root == NULL) return 0;
    return 1 + avl_count(root->left) + avl_count(root->right);
}

static void avl_inorder(AVLNode *root, int *arr, int *idx) {
    if (root == NULL) return;
    avl_inorder(root->left, arr, idx);
    arr[(*idx)++] = root->key;
    avl_inorder(root->right, arr, idx);
}

static int avl_is_balanced(AVLNode *root) {
    int b;
    if (root == NULL) return 1;
    b = avl_balance(root);
    if (b < -1 || b > 1) return 0;
    return avl_is_balanced(root->left) && avl_is_balanced(root->right);
}

static int avl_verify_heights(AVLNode *root) {
    int lh, rh, expected;
    if (root == NULL) return 1;
    if (!avl_verify_heights(root->left)) return 0;
    if (!avl_verify_heights(root->right)) return 0;
    lh = avl_height(root->left);
    rh = avl_height(root->right);
    expected = 1 + (lh > rh ? lh : rh);
    return root->height == expected;
}

static AVLNode* avl_search(AVLNode *root, int key) {
    while (root != NULL) {
        if (key < root->key) root = root->left;
        else if (key > root->key) root = root->right;
        else return root;
    }
    return NULL;
}

static void test_avl(void) {
    AVLNode *root = NULL;
    int arr[256], idx, i;

    write_str("[AVL Tree Insert]\n");
    pool_reset();

    /* Insert 1-20 in order (worst case for BST, AVL should balance) */
    for (i = 1; i <= 20; i++) {
        root = avl_insert(root, i);
    }

    check(avl_count(root) == 20, "AVL has 20 nodes");
    check(avl_is_balanced(root), "AVL balanced after sequential insert");
    check(avl_verify_heights(root), "AVL heights correct");

    /* Height should be at most ceil(1.44 * log2(20+2)) - 1 ~ 6 */
    check(avl_height(root) <= 6, "AVL height <= 6 for 20 nodes");

    /* Inorder should be sorted */
    idx = 0;
    avl_inorder(root, arr, &idx);
    check(idx == 20, "AVL inorder count==20");
    check(is_sorted(arr, idx), "AVL inorder sorted");
    check(arr[0] == 1, "AVL inorder first==1");
    check(arr[19] == 20, "AVL inorder last==20");

    /* Search */
    for (i = 1; i <= 20; i++) {
        check(avl_search(root, i) != NULL, "AVL find node");
    }
    check(avl_search(root, 0) == NULL, "AVL not find 0");
    check(avl_search(root, 21) == NULL, "AVL not find 21");

    /* Insert 100 more in reverse order */
    pool_reset();
    root = NULL;
    for (i = 100; i >= 1; i--) {
        root = avl_insert(root, i);
    }
    check(avl_count(root) == 100, "AVL has 100 nodes");
    check(avl_is_balanced(root), "AVL balanced after 100 reverse inserts");
    check(avl_verify_heights(root), "AVL heights correct after 100");
    check(avl_height(root) <= 8, "AVL height <= 8 for 100 nodes");

    idx = 0;
    avl_inorder(root, arr, &idx);
    check(is_sorted(arr, idx), "AVL 100 inorder sorted");
}

static void test_avl_delete(void) {
    AVLNode *root = NULL;
    int arr[256], idx, i;

    write_str("[AVL Tree Delete]\n");
    pool_reset();

    /* Insert 1-50 */
    for (i = 1; i <= 50; i++) {
        root = avl_insert(root, i);
    }
    check(avl_count(root) == 50, "AVL 50 nodes before delete");
    check(avl_is_balanced(root), "AVL balanced before delete");

    /* Delete leaves */
    root = avl_delete(root, 1);
    check(avl_search(root, 1) == NULL, "AVL deleted 1");
    check(avl_is_balanced(root), "balanced after delete 1");
    check(avl_verify_heights(root), "heights ok after delete 1");

    root = avl_delete(root, 50);
    check(avl_search(root, 50) == NULL, "AVL deleted 50");
    check(avl_is_balanced(root), "balanced after delete 50");

    /* Delete internal node */
    root = avl_delete(root, 25);
    check(avl_search(root, 25) == NULL, "AVL deleted 25");
    check(avl_is_balanced(root), "balanced after delete 25");
    check(avl_verify_heights(root), "heights ok after delete 25");

    /* Delete every other node */
    for (i = 2; i <= 48; i += 2) {
        root = avl_delete(root, i);
    }
    check(avl_is_balanced(root), "balanced after bulk delete");
    check(avl_verify_heights(root), "heights ok after bulk delete");

    /* Remaining should be odd numbers 3,5,7,...,49 */
    idx = 0;
    avl_inorder(root, arr, &idx);
    check(is_sorted(arr, idx), "remaining inorder sorted");

    {
        int ok = 1;
        for (i = 0; i < idx; i++) {
            if (arr[i] % 2 == 0) { ok = 0; break; }
        }
        check(ok, "only odd numbers remain");
    }

    /* Delete all remaining */
    for (i = 3; i <= 49; i += 2) {
        root = avl_delete(root, i);
    }
    check(root == NULL, "AVL empty after all deletes");
}

/* ========================================================================
 * Red-Black Tree (simplified insert with color flips and rotations)
 * ======================================================================== */
#define RB_RED   0
#define RB_BLACK 1

typedef struct RBNode {
    int key;
    int color;
    struct RBNode *left, *right, *parent;
} RBNode;

static RBNode *rb_nil_storage;
static RBNode *RB_NIL;

static void rb_init_nil(void) {
    rb_nil_storage = (RBNode*)pool_alloc(sizeof(RBNode));
    rb_nil_storage->color = RB_BLACK;
    rb_nil_storage->left = rb_nil_storage->right = rb_nil_storage->parent = NULL;
    rb_nil_storage->key = 0;
    RB_NIL = rb_nil_storage;
}

static RBNode* rb_new_node(int key) {
    RBNode *n = (RBNode*)pool_alloc(sizeof(RBNode));
    n->key = key;
    n->color = RB_RED;
    n->left = n->right = n->parent = RB_NIL;
    return n;
}

static void rb_rotate_left(RBNode **root, RBNode *x) {
    RBNode *y = x->right;
    x->right = y->left;
    if (y->left != RB_NIL) y->left->parent = x;
    y->parent = x->parent;
    if (x->parent == RB_NIL) *root = y;
    else if (x == x->parent->left) x->parent->left = y;
    else x->parent->right = y;
    y->left = x;
    x->parent = y;
}

static void rb_rotate_right(RBNode **root, RBNode *x) {
    RBNode *y = x->left;
    x->left = y->right;
    if (y->right != RB_NIL) y->right->parent = x;
    y->parent = x->parent;
    if (x->parent == RB_NIL) *root = y;
    else if (x == x->parent->right) x->parent->right = y;
    else x->parent->left = y;
    y->right = x;
    x->parent = y;
}

static void rb_insert_fixup(RBNode **root, RBNode *z) {
    while (z->parent->color == RB_RED) {
        if (z->parent == z->parent->parent->left) {
            RBNode *y = z->parent->parent->right; /* uncle */
            if (y->color == RB_RED) {
                /* Case 1: uncle is red - color flip */
                z->parent->color = RB_BLACK;
                y->color = RB_BLACK;
                z->parent->parent->color = RB_RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->right) {
                    /* Case 2: LR */
                    z = z->parent;
                    rb_rotate_left(root, z);
                }
                /* Case 3: LL */
                z->parent->color = RB_BLACK;
                z->parent->parent->color = RB_RED;
                rb_rotate_right(root, z->parent->parent);
            }
        } else {
            RBNode *y = z->parent->parent->left; /* uncle */
            if (y->color == RB_RED) {
                z->parent->color = RB_BLACK;
                y->color = RB_BLACK;
                z->parent->parent->color = RB_RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->left) {
                    z = z->parent;
                    rb_rotate_right(root, z);
                }
                z->parent->color = RB_BLACK;
                z->parent->parent->color = RB_RED;
                rb_rotate_left(root, z->parent->parent);
            }
        }
    }
    (*root)->color = RB_BLACK;
}

static RBNode* rb_insert(RBNode *root, int key) {
    RBNode *z = rb_new_node(key);
    RBNode *y = RB_NIL, *x = root;

    while (x != RB_NIL) {
        y = x;
        if (key < x->key) x = x->left;
        else if (key > x->key) x = x->right;
        else return root; /* duplicate */
    }
    z->parent = y;
    if (y == RB_NIL) root = z;
    else if (key < y->key) y->left = z;
    else y->right = z;

    rb_insert_fixup(&root, z);
    return root;
}

static int rb_count(RBNode *root) {
    if (root == RB_NIL) return 0;
    return 1 + rb_count(root->left) + rb_count(root->right);
}

static void rb_inorder(RBNode *root, int *arr, int *idx) {
    if (root == RB_NIL) return;
    rb_inorder(root->left, arr, idx);
    arr[(*idx)++] = root->key;
    rb_inorder(root->right, arr, idx);
}

static int rb_black_height(RBNode *root) {
    int lh, rh;
    if (root == RB_NIL) return 1;
    lh = rb_black_height(root->left);
    rh = rb_black_height(root->right);
    if (lh < 0 || rh < 0 || lh != rh) return -1;
    return lh + (root->color == RB_BLACK ? 1 : 0);
}

static int rb_verify_no_red_red(RBNode *root) {
    if (root == RB_NIL) return 1;
    if (root->color == RB_RED) {
        if (root->left->color == RB_RED || root->right->color == RB_RED) return 0;
    }
    return rb_verify_no_red_red(root->left) && rb_verify_no_red_red(root->right);
}

static void test_rbtree(void) {
    RBNode *root;
    int arr[256], idx, i;

    write_str("[Red-Black Tree Insert]\n");
    pool_reset();
    rb_init_nil();

    root = RB_NIL;

    /* Insert 1-50 in order */
    for (i = 1; i <= 50; i++) {
        root = rb_insert(root, i);
    }

    check(rb_count(root) == 50, "RB has 50 nodes");
    check(root->color == RB_BLACK, "RB root is black");
    check(rb_verify_no_red_red(root), "no red-red parent-child");
    check(rb_black_height(root) > 0, "uniform black height");

    /* Inorder should be sorted */
    idx = 0;
    rb_inorder(root, arr, &idx);
    check(idx == 50, "RB inorder count==50");
    check(is_sorted(arr, idx), "RB inorder sorted");
    check(arr[0] == 1, "RB first==1");
    check(arr[49] == 50, "RB last==50");

    /* Insert in reverse order */
    pool_reset();
    rb_init_nil();
    root = RB_NIL;
    for (i = 100; i >= 1; i--) {
        root = rb_insert(root, i);
    }

    check(rb_count(root) == 100, "RB has 100 nodes (reverse)");
    check(root->color == RB_BLACK, "RB root black (reverse)");
    check(rb_verify_no_red_red(root), "no red-red (reverse)");
    check(rb_black_height(root) > 0, "uniform bh (reverse)");

    idx = 0;
    rb_inorder(root, arr, &idx);
    check(is_sorted(arr, idx), "RB 100 inorder sorted");

    /* Insert alternating */
    pool_reset();
    rb_init_nil();
    root = RB_NIL;
    for (i = 0; i < 50; i++) {
        root = rb_insert(root, i * 2 + 1);  /* odds first */
    }
    for (i = 0; i < 50; i++) {
        root = rb_insert(root, i * 2);  /* then evens */
    }
    check(rb_count(root) == 100, "RB has 100 (alternating)");
    check(rb_verify_no_red_red(root), "no red-red (alternating)");
    check(rb_black_height(root) > 0, "uniform bh (alternating)");

    idx = 0;
    rb_inorder(root, arr, &idx);
    check(is_sorted(arr, idx), "RB alternating inorder sorted");
}

/* ========================================================================
 * Min-Heap
 * ======================================================================== */
typedef struct {
    int data[512];
    int size;
} MinHeap;

static void heap_init(MinHeap *h) { h->size = 0; }

static void heap_swap(int *a, int *b) { int t = *a; *a = *b; *b = t; }

static void heap_sift_up(MinHeap *h, int i) {
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (h->data[parent] > h->data[i]) {
            heap_swap(&h->data[parent], &h->data[i]);
            i = parent;
        } else break;
    }
}

static void heap_sift_down(MinHeap *h, int i) {
    while (1) {
        int smallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        if (left < h->size && h->data[left] < h->data[smallest]) smallest = left;
        if (right < h->size && h->data[right] < h->data[smallest]) smallest = right;
        if (smallest != i) {
            heap_swap(&h->data[i], &h->data[smallest]);
            i = smallest;
        } else break;
    }
}

static void heap_insert(MinHeap *h, int val) {
    h->data[h->size] = val;
    heap_sift_up(h, h->size);
    h->size++;
}

static int heap_extract_min(MinHeap *h) {
    int min_val;
    if (h->size == 0) return -1;
    min_val = h->data[0];
    h->data[0] = h->data[h->size - 1];
    h->size--;
    heap_sift_down(h, 0);
    return min_val;
}

static int heap_peek(MinHeap *h) {
    if (h->size == 0) return -1;
    return h->data[0];
}

static void heap_build(MinHeap *h, int *arr, int n) {
    int i;
    h->size = n;
    memcpy(h->data, arr, n * sizeof(int));
    for (i = n / 2 - 1; i >= 0; i--) {
        heap_sift_down(h, i);
    }
}

static int heap_is_valid(MinHeap *h) {
    int i;
    for (i = 0; i < h->size; i++) {
        int left = 2 * i + 1, right = 2 * i + 2;
        if (left < h->size && h->data[i] > h->data[left]) return 0;
        if (right < h->size && h->data[i] > h->data[right]) return 0;
    }
    return 1;
}

static void heap_sort(int *arr, int n) {
    MinHeap h;
    int i;
    heap_build(&h, arr, n);
    for (i = 0; i < n; i++) {
        arr[i] = heap_extract_min(&h);
    }
}

static void test_heap(void) {
    MinHeap h;
    int arr[64], i;

    write_str("[Min-Heap]\n");

    /* Basic insert and extract */
    heap_init(&h);
    heap_insert(&h, 5);
    heap_insert(&h, 3);
    heap_insert(&h, 8);
    heap_insert(&h, 1);
    heap_insert(&h, 4);

    check(h.size == 5, "heap size==5");
    check(heap_peek(&h) == 1, "heap min==1");
    check(heap_is_valid(&h), "heap valid after inserts");

    check(heap_extract_min(&h) == 1, "extract 1");
    check(heap_extract_min(&h) == 3, "extract 3");
    check(heap_extract_min(&h) == 4, "extract 4");
    check(heap_extract_min(&h) == 5, "extract 5");
    check(heap_extract_min(&h) == 8, "extract 8");
    check(h.size == 0, "heap empty");

    /* Insert in reverse order */
    heap_init(&h);
    for (i = 20; i >= 1; i--) {
        heap_insert(&h, i);
    }
    check(heap_peek(&h) == 1, "reverse insert min==1");
    check(heap_is_valid(&h), "valid after reverse inserts");
    for (i = 1; i <= 20; i++) {
        check(heap_extract_min(&h) == i, "extract in order");
    }

    /* Build-heap */
    {
        int data[] = {9, 7, 5, 3, 1, 8, 6, 4, 2, 0};
        heap_build(&h, data, 10);
        check(h.size == 10, "build size==10");
        check(heap_peek(&h) == 0, "build min==0");
        check(heap_is_valid(&h), "build valid");
        for (i = 0; i < 10; i++) {
            check(heap_extract_min(&h) == i, "build extract order");
        }
    }

    /* Heap sort */
    {
        int data[] = {38, 27, 43, 3, 9, 82, 10};
        int sorted[] = {3, 9, 10, 27, 38, 43, 82};
        heap_sort(data, 7);
        {
            int ok = 1;
            for (i = 0; i < 7; i++) {
                if (data[i] != sorted[i]) { ok = 0; break; }
            }
            check(ok, "heap sort correct");
        }
    }

    /* Heap sort larger */
    for (i = 0; i < 50; i++) arr[i] = 50 - i;
    heap_sort(arr, 50);
    check(is_sorted(arr, 50), "heap sort 50 elements sorted");

    /* Duplicates */
    heap_init(&h);
    for (i = 0; i < 10; i++) {
        heap_insert(&h, 5);
    }
    check(heap_peek(&h) == 5, "duplicate min==5");
    check(heap_is_valid(&h), "valid with duplicates");
    for (i = 0; i < 10; i++) {
        check(heap_extract_min(&h) == 5, "extract duplicate");
    }
}

/* ========================================================================
 * Priority Queue using Min-Heap
 * ======================================================================== */
typedef struct {
    int priority;
    int value;
} PQEntry;

typedef struct {
    PQEntry data[512];
    int size;
} PriorityQueue;

static void pq_init(PriorityQueue *pq) { pq->size = 0; }

static void pq_swap_entries(PQEntry *a, PQEntry *b) {
    PQEntry t = *a; *a = *b; *b = t;
}

static void pq_sift_up(PriorityQueue *pq, int i) {
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (pq->data[parent].priority > pq->data[i].priority) {
            pq_swap_entries(&pq->data[parent], &pq->data[i]);
            i = parent;
        } else break;
    }
}

static void pq_sift_down(PriorityQueue *pq, int i) {
    while (1) {
        int smallest = i;
        int left = 2 * i + 1, right = 2 * i + 2;
        if (left < pq->size && pq->data[left].priority < pq->data[smallest].priority)
            smallest = left;
        if (right < pq->size && pq->data[right].priority < pq->data[smallest].priority)
            smallest = right;
        if (smallest != i) {
            pq_swap_entries(&pq->data[i], &pq->data[smallest]);
            i = smallest;
        } else break;
    }
}

static void pq_push(PriorityQueue *pq, int priority, int value) {
    pq->data[pq->size].priority = priority;
    pq->data[pq->size].value = value;
    pq_sift_up(pq, pq->size);
    pq->size++;
}

static PQEntry pq_pop(PriorityQueue *pq) {
    PQEntry min_entry = pq->data[0];
    pq->data[0] = pq->data[pq->size - 1];
    pq->size--;
    if (pq->size > 0) pq_sift_down(pq, 0);
    return min_entry;
}

static void test_priority_queue(void) {
    PriorityQueue pq;
    PQEntry e;
    int i;

    write_str("[Priority Queue]\n");

    pq_init(&pq);
    pq_push(&pq, 5, 100);
    pq_push(&pq, 1, 200);
    pq_push(&pq, 3, 300);
    pq_push(&pq, 2, 400);
    pq_push(&pq, 4, 500);

    e = pq_pop(&pq);
    check(e.priority == 1 && e.value == 200, "pq pop priority 1");
    e = pq_pop(&pq);
    check(e.priority == 2 && e.value == 400, "pq pop priority 2");
    e = pq_pop(&pq);
    check(e.priority == 3 && e.value == 300, "pq pop priority 3");
    e = pq_pop(&pq);
    check(e.priority == 4 && e.value == 500, "pq pop priority 4");
    e = pq_pop(&pq);
    check(e.priority == 5 && e.value == 100, "pq pop priority 5");

    /* Insert 100 items in reverse priority */
    pq_init(&pq);
    for (i = 100; i >= 1; i--) {
        pq_push(&pq, i, i * 10);
    }
    for (i = 1; i <= 100; i++) {
        e = pq_pop(&pq);
        check(e.priority == i, "pq 100 extract order");
    }
    check(pq.size == 0, "pq empty after 100");
}

/* ========================================================================
 * Trie
 * ======================================================================== */
#define TRIE_ALPHA 26

typedef struct TrieNode {
    struct TrieNode *children[TRIE_ALPHA];
    int is_end;
    int prefix_count;
} TrieNode;

static TrieNode* trie_new_node(void) {
    TrieNode *n = (TrieNode*)pool_alloc(sizeof(TrieNode));
    n->is_end = 0;
    n->prefix_count = 0;
    memset(n->children, 0, sizeof(n->children));
    return n;
}

static void trie_insert(TrieNode *root, const char *word) {
    TrieNode *curr = root;
    while (*word) {
        int idx = *word - 'a';
        if (idx < 0 || idx >= TRIE_ALPHA) { word++; continue; }
        if (curr->children[idx] == NULL) {
            curr->children[idx] = trie_new_node();
        }
        curr = curr->children[idx];
        curr->prefix_count++;
        word++;
    }
    curr->is_end = 1;
}

static int trie_search(TrieNode *root, const char *word) {
    TrieNode *curr = root;
    while (*word) {
        int idx = *word - 'a';
        if (idx < 0 || idx >= TRIE_ALPHA) return 0;
        if (curr->children[idx] == NULL) return 0;
        curr = curr->children[idx];
        word++;
    }
    return curr->is_end;
}

static int trie_starts_with(TrieNode *root, const char *prefix) {
    TrieNode *curr = root;
    while (*prefix) {
        int idx = *prefix - 'a';
        if (idx < 0 || idx >= TRIE_ALPHA) return 0;
        if (curr->children[idx] == NULL) return 0;
        curr = curr->children[idx];
        prefix++;
    }
    return curr->prefix_count;
}

static int trie_count_words_helper(TrieNode *root) {
    int count = 0, i;
    if (root == NULL) return 0;
    if (root->is_end) count++;
    for (i = 0; i < TRIE_ALPHA; i++) {
        count += trie_count_words_helper(root->children[i]);
    }
    return count;
}

static void test_trie(void) {
    TrieNode *root;
    static const char *words[] = {
        "apple", "app", "application", "apply", "apt",
        "banana", "band", "ban", "bat", "bath",
        "cat", "car", "card", "care", "cart",
        "dog", "dot", "dome", "done", "door",
        "egg", "edge", "edit", "end", "ear"
    };
    int i, n_words = 25;

    write_str("[Trie]\n");
    pool_reset();

    root = trie_new_node();

    /* Insert all words */
    for (i = 0; i < n_words; i++) {
        trie_insert(root, words[i]);
    }

    /* Search all inserted words */
    for (i = 0; i < n_words; i++) {
        check(trie_search(root, words[i]), "trie find inserted word");
    }

    /* Search non-existent words */
    check(!trie_search(root, "applee"), "trie not find 'applee'");
    check(!trie_search(root, "ap"), "trie not find 'ap' (prefix only)");
    check(!trie_search(root, "bane"), "trie not find 'bane'");
    check(!trie_search(root, "xyz"), "trie not find 'xyz'");
    check(!trie_search(root, ""), "trie not find empty");
    check(!trie_search(root, "dogs"), "trie not find 'dogs'");
    check(!trie_search(root, "do"), "trie not find 'do'");
    check(!trie_search(root, "ca"), "trie not find 'ca'");

    /* Prefix search */
    check(trie_starts_with(root, "app") > 0, "prefix 'app' exists");
    check(trie_starts_with(root, "ba") > 0, "prefix 'ba' exists");
    check(trie_starts_with(root, "do") > 0, "prefix 'do' exists");
    check(trie_starts_with(root, "ca") > 0, "prefix 'ca' exists");
    check(trie_starts_with(root, "xyz") == 0, "prefix 'xyz' not found");
    check(trie_starts_with(root, "z") == 0, "prefix 'z' not found");

    /* Count words with prefix */
    check(trie_starts_with(root, "app") == 4, "4 words start with 'app'");
    check(trie_starts_with(root, "ba") == 5, "5 words start with 'ba'");
    check(trie_starts_with(root, "do") == 5, "5 words start with 'do'");
    check(trie_starts_with(root, "e") == 5, "5 words start with 'e'");

    /* Total word count */
    check(trie_count_words_helper(root) == 25, "trie has 25 words total");

    /* Insert duplicate */
    trie_insert(root, "apple");
    check(trie_search(root, "apple"), "apple still found after dup insert");
    check(trie_count_words_helper(root) == 25, "count unchanged after dup");
}

/* ========================================================================
 * Segment Tree (range sum queries)
 * ======================================================================== */
#define SEG_MAX 256

typedef struct {
    int tree[4 * SEG_MAX];
    int n;
} SegTree;

static void seg_build(SegTree *st, int *arr, int node, int start, int end) {
    if (start == end) {
        st->tree[node] = arr[start];
    } else {
        int mid = (start + end) / 2;
        seg_build(st, arr, 2 * node, start, mid);
        seg_build(st, arr, 2 * node + 1, mid + 1, end);
        st->tree[node] = st->tree[2 * node] + st->tree[2 * node + 1];
    }
}

static void seg_init(SegTree *st, int *arr, int n) {
    st->n = n;
    memset(st->tree, 0, sizeof(st->tree));
    seg_build(st, arr, 1, 0, n - 1);
}

static void seg_update(SegTree *st, int node, int start, int end, int idx, int val) {
    if (start == end) {
        st->tree[node] = val;
    } else {
        int mid = (start + end) / 2;
        if (idx <= mid)
            seg_update(st, 2 * node, start, mid, idx, val);
        else
            seg_update(st, 2 * node + 1, mid + 1, end, idx, val);
        st->tree[node] = st->tree[2 * node] + st->tree[2 * node + 1];
    }
}

static int seg_query(SegTree *st, int node, int start, int end, int l, int r) {
    if (r < start || end < l) return 0;
    if (l <= start && end <= r) return st->tree[node];
    {
        int mid = (start + end) / 2;
        return seg_query(st, 2 * node, start, mid, l, r) +
               seg_query(st, 2 * node + 1, mid + 1, end, l, r);
    }
}

static int brute_range_sum(int *arr, int l, int r) {
    int sum = 0, i;
    for (i = l; i <= r; i++) sum += arr[i];
    return sum;
}

static void test_segment_tree(void) {
    SegTree st;
    int arr[64];
    int i, j;

    write_str("[Segment Tree]\n");

    /* Basic test */
    {
        int data[] = {1, 3, 5, 7, 9, 11};
        seg_init(&st, data, 6);

        check(seg_query(&st, 1, 0, 5, 0, 5) == 36, "sum [0,5]==36");
        check(seg_query(&st, 1, 0, 5, 0, 0) == 1, "sum [0,0]==1");
        check(seg_query(&st, 1, 0, 5, 1, 3) == 15, "sum [1,3]==15");
        check(seg_query(&st, 1, 0, 5, 2, 4) == 21, "sum [2,4]==21");
        check(seg_query(&st, 1, 0, 5, 5, 5) == 11, "sum [5,5]==11");
        check(seg_query(&st, 1, 0, 5, 0, 2) == 9, "sum [0,2]==9");
        check(seg_query(&st, 1, 0, 5, 3, 5) == 27, "sum [3,5]==27");

        /* Update */
        seg_update(&st, 1, 0, 5, 2, 10); /* arr[2] = 10 instead of 5 */
        check(seg_query(&st, 1, 0, 5, 0, 5) == 41, "sum after update==41");
        check(seg_query(&st, 1, 0, 5, 2, 2) == 10, "updated element==10");
        check(seg_query(&st, 1, 0, 5, 1, 3) == 20, "sum [1,3] after update==20");
    }

    /* Cross-check with brute force */
    for (i = 0; i < 50; i++) arr[i] = (i * 7 + 3) % 20;
    seg_init(&st, arr, 50);

    {
        int ok = 1;
        for (i = 0; i < 50; i++) {
            for (j = i; j < 50; j++) {
                if (seg_query(&st, 1, 0, 49, i, j) != brute_range_sum(arr, i, j)) {
                    ok = 0;
                    break;
                }
            }
            if (!ok) break;
        }
        check(ok, "seg tree matches brute force for 50-elem all ranges");
    }

    /* Update and re-check */
    arr[25] = 100;
    seg_update(&st, 1, 0, 49, 25, 100);
    check(seg_query(&st, 1, 0, 49, 0, 49) == brute_range_sum(arr, 0, 49), "after update total");
    check(seg_query(&st, 1, 0, 49, 20, 30) == brute_range_sum(arr, 20, 30), "after update range");

    /* Multiple updates */
    for (i = 0; i < 50; i++) {
        arr[i] = i * i;
        seg_update(&st, 1, 0, 49, i, i * i);
    }
    check(seg_query(&st, 1, 0, 49, 0, 49) == brute_range_sum(arr, 0, 49), "after all-update total");
    check(seg_query(&st, 1, 0, 49, 10, 20) == brute_range_sum(arr, 10, 20), "after all-update subrange");
}

/* ========================================================================
 * Binary Indexed Tree (Fenwick Tree)
 * ======================================================================== */
typedef struct {
    int tree[SEG_MAX + 1]; /* 1-indexed */
    int n;
} FenwickTree;

static void fenwick_init(FenwickTree *ft, int n) {
    ft->n = n;
    memset(ft->tree, 0, sizeof(ft->tree));
}

static void fenwick_update(FenwickTree *ft, int i, int delta) {
    for (i++; i <= ft->n; i += i & (-i))
        ft->tree[i] += delta;
}

static int fenwick_prefix_sum(FenwickTree *ft, int i) {
    int sum = 0;
    for (i++; i > 0; i -= i & (-i))
        sum += ft->tree[i];
    return sum;
}

static int fenwick_range_sum(FenwickTree *ft, int l, int r) {
    int s = fenwick_prefix_sum(ft, r);
    if (l > 0) s -= fenwick_prefix_sum(ft, l - 1);
    return s;
}

static void test_fenwick(void) {
    FenwickTree ft;
    int arr[64];
    int i, j;

    write_str("[Fenwick Tree]\n");

    /* Basic test */
    fenwick_init(&ft, 10);
    {
        int data[] = {1, 3, 5, 7, 9, 2, 4, 6, 8, 10};
        for (i = 0; i < 10; i++) {
            fenwick_update(&ft, i, data[i]);
        }

        check(fenwick_prefix_sum(&ft, 0) == 1, "prefix[0]==1");
        check(fenwick_prefix_sum(&ft, 4) == 25, "prefix[4]==25");
        check(fenwick_prefix_sum(&ft, 9) == 55, "prefix[9]==55");
        check(fenwick_range_sum(&ft, 2, 5) == 23, "range[2,5]==23");
        check(fenwick_range_sum(&ft, 0, 9) == 55, "range[0,9]==55");

        /* Update: add 5 to index 3 */
        fenwick_update(&ft, 3, 5);
        check(fenwick_prefix_sum(&ft, 9) == 60, "after update prefix[9]==60");
        check(fenwick_range_sum(&ft, 3, 3) == 12, "updated element range==12");
    }

    /* Cross-check with brute force */
    fenwick_init(&ft, 50);
    for (i = 0; i < 50; i++) {
        arr[i] = (i * 13 + 5) % 30;
        fenwick_update(&ft, i, arr[i]);
    }

    {
        int ok = 1;
        for (i = 0; i < 50; i++) {
            for (j = i; j < 50; j++) {
                if (fenwick_range_sum(&ft, i, j) != brute_range_sum(arr, i, j)) {
                    ok = 0;
                    break;
                }
            }
            if (!ok) break;
        }
        check(ok, "fenwick matches brute force for 50-elem all ranges");
    }

    /* Point query via range */
    {
        int ok = 1;
        for (i = 0; i < 50; i++) {
            if (fenwick_range_sum(&ft, i, i) != arr[i]) {
                ok = 0; break;
            }
        }
        check(ok, "fenwick point queries correct");
    }
}

/* ========================================================================
 * Additional BST tests for coverage/line count
 * ======================================================================== */
static void test_bst_edge_cases(void) {
    BSTNode *root = NULL;
    int arr[64], count;
    int i;

    write_str("[BST Edge Cases]\n");
    pool_reset();

    /* Single node */
    root = bst_insert(root, 42);
    check(bst_count(root) == 1, "single node count==1");
    check(bst_min(root)->key == 42, "single min==42");
    check(bst_max(root)->key == 42, "single max==42");
    check(bst_search(root, 42) != NULL, "single find 42");
    check(bst_successor(bst_search(root, 42)) == NULL, "single no successor");
    check(bst_predecessor(bst_search(root, 42)) == NULL, "single no predecessor");

    bst_delete(&root, 42);
    check(root == NULL, "delete only node -> empty");

    /* Sequential insert (degenerate) */
    pool_reset();
    root = NULL;
    for (i = 1; i <= 20; i++) {
        root = bst_insert(root, i);
    }
    bst_to_sorted_array(root, arr, &count);
    check(count == 20, "degenerate count==20");
    check(is_sorted(arr, count), "degenerate sorted");

    /* Delete from middle of degenerate tree */
    bst_delete(&root, 10);
    bst_delete(&root, 11);
    bst_delete(&root, 12);
    bst_to_sorted_array(root, arr, &count);
    check(count == 17, "after 3 deletes count==17");
    check(is_sorted(arr, count), "still sorted after middle deletes");

    /* Reverse sequential */
    pool_reset();
    root = NULL;
    for (i = 20; i >= 1; i--) {
        root = bst_insert(root, i);
    }
    bst_to_sorted_array(root, arr, &count);
    check(count == 20, "reverse degenerate count==20");
    check(is_sorted(arr, count), "reverse degenerate sorted");
    check(arr[0] == 1, "reverse first==1");
    check(arr[19] == 20, "reverse last==20");

    /* All same keys */
    pool_reset();
    root = NULL;
    for (i = 0; i < 10; i++) {
        root = bst_insert(root, 5);
    }
    bst_to_sorted_array(root, arr, &count);
    check(count == 10, "duplicate count==10");
    {
        int ok = 1;
        for (i = 0; i < count; i++) {
            if (arr[i] != 5) { ok = 0; break; }
        }
        check(ok, "all duplicates are 5");
    }
}

/* ========================================================================
 * Additional AVL rotation tests
 * ======================================================================== */
static void test_avl_rotations(void) {
    AVLNode *root = NULL;
    int arr[64], idx;

    write_str("[AVL Rotations]\n");
    pool_reset();

    /* LL case: insert 3, 2, 1 */
    root = NULL;
    root = avl_insert(root, 3);
    root = avl_insert(root, 2);
    root = avl_insert(root, 1);
    check(root->key == 2, "LL rotation: root==2");
    check(root->left->key == 1, "LL: left==1");
    check(root->right->key == 3, "LL: right==3");
    check(avl_is_balanced(root), "LL balanced");

    /* RR case: insert 1, 2, 3 */
    pool_reset();
    root = NULL;
    root = avl_insert(root, 1);
    root = avl_insert(root, 2);
    root = avl_insert(root, 3);
    check(root->key == 2, "RR rotation: root==2");
    check(root->left->key == 1, "RR: left==1");
    check(root->right->key == 3, "RR: right==3");
    check(avl_is_balanced(root), "RR balanced");

    /* LR case: insert 3, 1, 2 */
    pool_reset();
    root = NULL;
    root = avl_insert(root, 3);
    root = avl_insert(root, 1);
    root = avl_insert(root, 2);
    check(root->key == 2, "LR rotation: root==2");
    check(root->left->key == 1, "LR: left==1");
    check(root->right->key == 3, "LR: right==3");
    check(avl_is_balanced(root), "LR balanced");

    /* RL case: insert 1, 3, 2 */
    pool_reset();
    root = NULL;
    root = avl_insert(root, 1);
    root = avl_insert(root, 3);
    root = avl_insert(root, 2);
    check(root->key == 2, "RL rotation: root==2");
    check(root->left->key == 1, "RL: left==1");
    check(root->right->key == 3, "RL: right==3");
    check(avl_is_balanced(root), "RL balanced");

    /* Complex: zigzag insertions */
    pool_reset();
    root = NULL;
    {
        int vals[] = {10, 20, 5, 15, 25, 3, 7, 12, 18, 22, 28, 1};
        int i;
        for (i = 0; i < 12; i++) {
            root = avl_insert(root, vals[i]);
        }
    }
    check(avl_is_balanced(root), "complex zigzag balanced");
    check(avl_verify_heights(root), "complex zigzag heights ok");
    idx = 0;
    avl_inorder(root, arr, &idx);
    check(is_sorted(arr, idx), "complex zigzag sorted");
    check(idx == 12, "complex zigzag count==12");
}

/* ========================================================================
 * Additional Heap tests
 * ======================================================================== */
static void test_heap_advanced(void) {
    MinHeap h;
    int i;

    write_str("[Heap Advanced]\n");

    /* Already sorted input */
    heap_init(&h);
    for (i = 1; i <= 30; i++) {
        heap_insert(&h, i);
    }
    check(heap_is_valid(&h), "sorted input valid");
    for (i = 1; i <= 30; i++) {
        check(heap_extract_min(&h) == i, "sorted extract");
    }

    /* Reverse sorted */
    heap_init(&h);
    for (i = 30; i >= 1; i--) {
        heap_insert(&h, i);
    }
    check(heap_is_valid(&h), "reverse input valid");
    for (i = 1; i <= 30; i++) {
        check(heap_extract_min(&h) == i, "reverse extract");
    }

    /* Mixed operations */
    heap_init(&h);
    heap_insert(&h, 10);
    heap_insert(&h, 20);
    heap_insert(&h, 5);
    check(heap_extract_min(&h) == 5, "mixed 1");
    heap_insert(&h, 3);
    heap_insert(&h, 15);
    check(heap_extract_min(&h) == 3, "mixed 2");
    check(heap_extract_min(&h) == 10, "mixed 3");
    heap_insert(&h, 1);
    check(heap_extract_min(&h) == 1, "mixed 4");
    check(heap_extract_min(&h) == 15, "mixed 5");
    check(heap_extract_min(&h) == 20, "mixed 6");
    check(h.size == 0, "mixed empty");

    /* Heap sort stability with many duplicates */
    {
        int data[100];
        for (i = 0; i < 100; i++) data[i] = i % 5;
        heap_sort(data, 100);
        check(is_sorted(data, 100), "heap sort duplicates sorted");
    }
}

/* ========================================================================
 * Additional Trie tests
 * ======================================================================== */
static void test_trie_advanced(void) {
    TrieNode *root;

    write_str("[Trie Advanced]\n");
    pool_reset();

    root = trie_new_node();

    /* Single character words */
    trie_insert(root, "a");
    trie_insert(root, "b");
    trie_insert(root, "c");
    check(trie_search(root, "a"), "find 'a'");
    check(trie_search(root, "b"), "find 'b'");
    check(trie_search(root, "c"), "find 'c'");
    check(!trie_search(root, "d"), "not find 'd'");

    /* Prefix is not a word unless explicitly inserted */
    trie_insert(root, "abc");
    check(trie_search(root, "abc"), "find 'abc'");
    check(!trie_search(root, "ab"), "'ab' not a word");

    /* Insert 'ab' */
    trie_insert(root, "ab");
    check(trie_search(root, "ab"), "now find 'ab'");
    check(trie_search(root, "a"), "still find 'a'");
    check(trie_search(root, "abc"), "still find 'abc'");

    /* Long word */
    trie_insert(root, "abcdefghijklmnopqrstuvwxyz");
    check(trie_search(root, "abcdefghijklmnopqrstuvwxyz"), "find 26-letter word");
    check(!trie_search(root, "abcdefghijklmnopqrstuvwxy"), "25-letter prefix not found");

    /* Words sharing no prefix */
    pool_reset();
    root = trie_new_node();
    trie_insert(root, "alpha");
    trie_insert(root, "beta");
    trie_insert(root, "gamma");
    trie_insert(root, "delta");
    trie_insert(root, "epsilon");
    check(trie_count_words_helper(root) == 5, "5 disjoint words");
    check(trie_starts_with(root, "al") > 0, "prefix 'al'");
    check(trie_starts_with(root, "be") > 0, "prefix 'be'");
    check(trie_starts_with(root, "ga") > 0, "prefix 'ga'");
    check(trie_starts_with(root, "de") > 0, "prefix 'de'");
    check(trie_starts_with(root, "ep") > 0, "prefix 'ep'");
    check(trie_starts_with(root, "ze") == 0, "prefix 'ze' not found");
}

/* ========================================================================
 * Additional Segment Tree / Fenwick cross-check
 * ======================================================================== */
static void test_seg_fenwick_cross(void) {
    SegTree st;
    FenwickTree ft;
    int arr[64];
    int i, j;

    write_str("[Seg/Fenwick Cross-Check]\n");

    /* Initialize both with same data */
    for (i = 0; i < 40; i++) arr[i] = (i * 17 + 11) % 50;

    seg_init(&st, arr, 40);
    fenwick_init(&ft, 40);
    for (i = 0; i < 40; i++) fenwick_update(&ft, i, arr[i]);

    /* Compare all range sums */
    {
        int ok = 1;
        for (i = 0; i < 40; i++) {
            for (j = i; j < 40; j++) {
                int s1 = seg_query(&st, 1, 0, 39, i, j);
                int s2 = fenwick_range_sum(&ft, i, j);
                if (s1 != s2) { ok = 0; break; }
            }
            if (!ok) break;
        }
        check(ok, "seg tree == fenwick for all ranges (40 elem)");
    }

    /* Update both and re-check */
    for (i = 0; i < 40; i++) {
        int new_val = (i * 31 + 7) % 100;
        int delta = new_val - arr[i];
        arr[i] = new_val;
        seg_update(&st, 1, 0, 39, i, new_val);
        fenwick_update(&ft, i, delta);
    }

    {
        int ok = 1;
        for (i = 0; i < 40; i++) {
            for (j = i; j < 40; j++) {
                int s1 = seg_query(&st, 1, 0, 39, i, j);
                int s2 = fenwick_range_sum(&ft, i, j);
                if (s1 != s2) { ok = 0; break; }
            }
            if (!ok) break;
        }
        check(ok, "seg == fenwick after updates");
    }
}

/* ========================================================================
 * Max-Heap (for additional coverage)
 * ======================================================================== */
typedef struct {
    int data[512];
    int size;
} MaxHeap;

static void maxheap_init(MaxHeap *h) { h->size = 0; }

static void maxheap_sift_up(MaxHeap *h, int i) {
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (h->data[parent] < h->data[i]) {
            heap_swap(&h->data[parent], &h->data[i]);
            i = parent;
        } else break;
    }
}

static void maxheap_sift_down(MaxHeap *h, int i) {
    while (1) {
        int largest = i;
        int left = 2 * i + 1, right = 2 * i + 2;
        if (left < h->size && h->data[left] > h->data[largest]) largest = left;
        if (right < h->size && h->data[right] > h->data[largest]) largest = right;
        if (largest != i) {
            heap_swap(&h->data[i], &h->data[largest]);
            i = largest;
        } else break;
    }
}

static void maxheap_insert(MaxHeap *h, int val) {
    h->data[h->size] = val;
    maxheap_sift_up(h, h->size);
    h->size++;
}

static int maxheap_extract_max(MaxHeap *h) {
    int max_val;
    if (h->size == 0) return -1;
    max_val = h->data[0];
    h->data[0] = h->data[h->size - 1];
    h->size--;
    maxheap_sift_down(h, 0);
    return max_val;
}

static int maxheap_is_valid(MaxHeap *h) {
    int i;
    for (i = 0; i < h->size; i++) {
        int left = 2 * i + 1, right = 2 * i + 2;
        if (left < h->size && h->data[i] < h->data[left]) return 0;
        if (right < h->size && h->data[i] < h->data[right]) return 0;
    }
    return 1;
}

static void test_maxheap(void) {
    MaxHeap h;
    int i;

    write_str("[Max-Heap]\n");

    maxheap_init(&h);
    for (i = 1; i <= 20; i++) {
        maxheap_insert(&h, i);
    }
    check(maxheap_is_valid(&h), "max heap valid");
    check(h.data[0] == 20, "max == 20");

    for (i = 20; i >= 1; i--) {
        check(maxheap_extract_max(&h) == i, "max extract order");
    }
    check(h.size == 0, "max heap empty");

    /* Reverse insert */
    maxheap_init(&h);
    for (i = 20; i >= 1; i--) {
        maxheap_insert(&h, i);
    }
    check(maxheap_is_valid(&h), "max heap reverse valid");
    for (i = 20; i >= 1; i--) {
        check(maxheap_extract_max(&h) == i, "max reverse extract");
    }

    /* Mixed */
    maxheap_init(&h);
    maxheap_insert(&h, 5);
    maxheap_insert(&h, 10);
    maxheap_insert(&h, 3);
    check(maxheap_extract_max(&h) == 10, "max mixed 1");
    maxheap_insert(&h, 7);
    check(maxheap_extract_max(&h) == 7, "max mixed 2");
    check(maxheap_extract_max(&h) == 5, "max mixed 3");
    check(maxheap_extract_max(&h) == 3, "max mixed 4");
}

/* ========================================================================
 * BST count nodes in range
 * ======================================================================== */
static int bst_count_in_range(BSTNode *root, int lo, int hi) {
    int count;
    if (root == NULL) return 0;
    count = 0;
    if (root->key >= lo && root->key <= hi) count = 1;
    if (root->key > lo) count += bst_count_in_range(root->left, lo, hi);
    if (root->key < hi) count += bst_count_in_range(root->right, lo, hi);
    return count;
}

static int bst_height(BSTNode *root) {
    int lh, rh;
    if (root == NULL) return 0;
    lh = bst_height(root->left);
    rh = bst_height(root->right);
    return 1 + (lh > rh ? lh : rh);
}

static void test_bst_range_and_height(void) {
    BSTNode *root = NULL;
    int i;

    write_str("[BST Range Count & Height]\n");
    pool_reset();

    /* Build a balanced-ish tree */
    {
        int order[] = {8, 4, 12, 2, 6, 10, 14, 1, 3, 5, 7, 9, 11, 13, 15};
        for (i = 0; i < 15; i++) {
            root = bst_insert(root, order[i]);
        }
    }

    check(bst_count_in_range(root, 1, 15) == 15, "range [1,15] == 15");
    check(bst_count_in_range(root, 5, 10) == 6, "range [5,10] == 6");
    check(bst_count_in_range(root, 1, 1) == 1, "range [1,1] == 1");
    check(bst_count_in_range(root, 0, 0) == 0, "range [0,0] == 0");
    check(bst_count_in_range(root, 16, 20) == 0, "range [16,20] == 0");
    check(bst_count_in_range(root, 7, 9) == 3, "range [7,9] == 3");

    check(bst_height(root) == 4, "balanced BST height==4");

    /* Degenerate tree height */
    pool_reset();
    root = NULL;
    for (i = 1; i <= 10; i++) root = bst_insert(root, i);
    check(bst_height(root) == 10, "degenerate height==10");
}

/* ========================================================================
 * Combined stress test: build, destroy, rebuild
 * ======================================================================== */
static void test_rebuild_stress(void) {
    int round, i;

    write_str("[Rebuild Stress Test]\n");

    for (round = 0; round < 5; round++) {
        AVLNode *avl_root = NULL;
        int arr[128], idx;

        pool_reset();

        /* Insert 50 elements with varying patterns */
        for (i = 0; i < 50; i++) {
            int val = ((i * 37 + round * 13 + 7) % 200);
            avl_root = avl_insert(avl_root, val);
        }

        check(avl_is_balanced(avl_root), "stress AVL balanced");
        check(avl_verify_heights(avl_root), "stress AVL heights ok");

        idx = 0;
        avl_inorder(avl_root, arr, &idx);
        check(is_sorted(arr, idx), "stress AVL sorted");

        /* Delete half */
        for (i = 0; i < 25; i++) {
            int val = ((i * 37 + round * 13 + 7) % 200);
            avl_root = avl_delete(avl_root, val);
        }

        check(avl_is_balanced(avl_root), "stress after delete balanced");
        check(avl_verify_heights(avl_root), "stress after delete heights ok");

        idx = 0;
        avl_inorder(avl_root, arr, &idx);
        check(is_sorted(arr, idx), "stress after delete sorted");
    }
}

/* ========================================================================
 * Fenwick tree: find kth smallest
 * ======================================================================== */
static int fenwick_find_kth(FenwickTree *ft, int k) {
    /* Find smallest index i such that prefix_sum(i) >= k */
    /* Assumes tree stores frequency counts */
    int pos = 0, bitmask;
    for (bitmask = ft->n; bitmask > 0; bitmask >>= 1) {
        /* nothing */
    }
    /* Use bit walking */
    bitmask = 1;
    while (bitmask <= ft->n) bitmask <<= 1;
    bitmask >>= 1;

    pos = 0;
    while (bitmask > 0) {
        int next = pos + bitmask;
        if (next <= ft->n && ft->tree[next] < k) {
            k -= ft->tree[next];
            pos = next;
        }
        bitmask >>= 1;
    }
    return pos; /* 0-indexed result */
}

static void test_fenwick_kth(void) {
    FenwickTree ft;
    int i;

    write_str("[Fenwick Kth Element]\n");

    /* Use as frequency array: values 0-9 */
    fenwick_init(&ft, 10);

    /* Insert: 3 twos, 2 fives, 1 seven */
    fenwick_update(&ft, 2, 3);
    fenwick_update(&ft, 5, 2);
    fenwick_update(&ft, 7, 1);

    /* Total elements: 6 */
    check(fenwick_prefix_sum(&ft, 9) == 6, "total freq==6");

    /* kth smallest: k=1 -> 2, k=2 -> 2, k=3 -> 2, k=4 -> 5, k=5 -> 5, k=6 -> 7 */
    check(fenwick_find_kth(&ft, 1) == 2, "1st smallest == 2");
    check(fenwick_find_kth(&ft, 3) == 2, "3rd smallest == 2");
    check(fenwick_find_kth(&ft, 4) == 5, "4th smallest == 5");
    check(fenwick_find_kth(&ft, 6) == 7, "6th smallest == 7");

    /* Add more elements */
    fenwick_update(&ft, 0, 2); /* 2 zeros */
    check(fenwick_find_kth(&ft, 1) == 0, "after add: 1st == 0");
    check(fenwick_find_kth(&ft, 2) == 0, "after add: 2nd == 0");
    check(fenwick_find_kth(&ft, 3) == 2, "after add: 3rd == 2");

    /* Dense: all values 0-9 have count 1 */
    fenwick_init(&ft, 10);
    for (i = 0; i < 10; i++) fenwick_update(&ft, i, 1);
    for (i = 0; i < 10; i++) {
        check(fenwick_find_kth(&ft, i + 1) == i, "dense kth");
    }
}

/* ========================================================================
 * Segment tree: range minimum query variant
 * ======================================================================== */
typedef struct {
    int tree[4 * SEG_MAX];
    int n;
} SegTreeMin;

static void segmin_build(SegTreeMin *st, int *arr, int node, int start, int end) {
    if (start == end) {
        st->tree[node] = arr[start];
    } else {
        int mid = (start + end) / 2;
        int lv, rv;
        segmin_build(st, arr, 2 * node, start, mid);
        segmin_build(st, arr, 2 * node + 1, mid + 1, end);
        lv = st->tree[2 * node];
        rv = st->tree[2 * node + 1];
        st->tree[node] = (lv < rv) ? lv : rv;
    }
}

static void segmin_init(SegTreeMin *st, int *arr, int n) {
    st->n = n;
    memset(st->tree, 0x7f, sizeof(st->tree));
    segmin_build(st, arr, 1, 0, n - 1);
}

static int segmin_query(SegTreeMin *st, int node, int start, int end, int l, int r) {
    int mid, lv, rv;
    if (r < start || end < l) return 0x7fffffff;
    if (l <= start && end <= r) return st->tree[node];
    mid = (start + end) / 2;
    lv = segmin_query(st, 2 * node, start, mid, l, r);
    rv = segmin_query(st, 2 * node + 1, mid + 1, end, l, r);
    return (lv < rv) ? lv : rv;
}

static void segmin_update(SegTreeMin *st, int node, int start, int end, int idx, int val) {
    int mid, lv, rv;
    if (start == end) {
        st->tree[node] = val;
        return;
    }
    mid = (start + end) / 2;
    if (idx <= mid)
        segmin_update(st, 2 * node, start, mid, idx, val);
    else
        segmin_update(st, 2 * node + 1, mid + 1, end, idx, val);
    lv = st->tree[2 * node];
    rv = st->tree[2 * node + 1];
    st->tree[node] = (lv < rv) ? lv : rv;
}

static int brute_range_min(int *arr, int l, int r) {
    int mn = arr[l], i;
    for (i = l + 1; i <= r; i++) {
        if (arr[i] < mn) mn = arr[i];
    }
    return mn;
}

static void test_segment_tree_min(void) {
    SegTreeMin st;
    int arr[64];
    int i, j;

    write_str("[Segment Tree Min Query]\n");

    for (i = 0; i < 30; i++) arr[i] = (i * 11 + 7) % 50;
    segmin_init(&st, arr, 30);

    /* Cross-check all ranges */
    {
        int ok = 1;
        for (i = 0; i < 30; i++) {
            for (j = i; j < 30; j++) {
                if (segmin_query(&st, 1, 0, 29, i, j) != brute_range_min(arr, i, j)) {
                    ok = 0; break;
                }
            }
            if (!ok) break;
        }
        check(ok, "segmin matches brute force 30 elem");
    }

    /* Point query */
    for (i = 0; i < 30; i++) {
        check(segmin_query(&st, 1, 0, 29, i, i) == arr[i], "segmin point query");
    }

    /* Update and re-check */
    arr[15] = -100;
    segmin_update(&st, 1, 0, 29, 15, -100);
    check(segmin_query(&st, 1, 0, 29, 0, 29) == -100, "segmin after update");
    check(segmin_query(&st, 1, 0, 29, 10, 20) == -100, "segmin range with updated");
    check(segmin_query(&st, 1, 0, 29, 0, 14) == brute_range_min(arr, 0, 14), "segmin range without updated");
}

/* ========================================================================
 * BST: Level-order traversal (BFS using queue)
 * ======================================================================== */
static void bst_level_order(BSTNode *root, int *arr, int *count) {
    BSTNode *queue[256];
    int front = 0, back = 0;
    *count = 0;
    if (root == NULL) return;
    queue[back++] = root;
    while (front < back) {
        BSTNode *node = queue[front++];
        arr[(*count)++] = node->key;
        if (node->left) queue[back++] = node->left;
        if (node->right) queue[back++] = node->right;
    }
}

static void test_bst_level_order(void) {
    BSTNode *root = NULL;
    int arr[32], count;

    write_str("[BST Level Order]\n");
    pool_reset();

    /*
     *        4
     *       / \
     *      2   6
     *     / \ / \
     *    1  3 5  7
     */
    root = bst_insert(root, 4);
    root = bst_insert(root, 2);
    root = bst_insert(root, 6);
    root = bst_insert(root, 1);
    root = bst_insert(root, 3);
    root = bst_insert(root, 5);
    root = bst_insert(root, 7);

    bst_level_order(root, arr, &count);
    check(count == 7, "level order count==7");
    /* Level order: 4, 2, 6, 1, 3, 5, 7 */
    check(arr[0] == 4, "level[0]==4");
    check(arr[1] == 2, "level[1]==2");
    check(arr[2] == 6, "level[2]==6");
    check(arr[3] == 1, "level[3]==1");
    check(arr[4] == 3, "level[4]==3");
    check(arr[5] == 5, "level[5]==5");
    check(arr[6] == 7, "level[6]==7");

    /* Empty tree */
    bst_level_order(NULL, arr, &count);
    check(count == 0, "level order empty==0");

    /* Single node */
    pool_reset();
    root = bst_insert(NULL, 42);
    bst_level_order(root, arr, &count);
    check(count == 1 && arr[0] == 42, "level order single==42");
}

/* ========================================================================
 * Tree diameter (longest path in BST)
 * ======================================================================== */
static int bst_diameter_helper(BSTNode *root, int *diameter) {
    int lh, rh;
    if (root == NULL) return 0;
    lh = bst_diameter_helper(root->left, diameter);
    rh = bst_diameter_helper(root->right, diameter);
    if (lh + rh > *diameter) *diameter = lh + rh;
    return 1 + (lh > rh ? lh : rh);
}

static int bst_diameter(BSTNode *root) {
    int diameter = 0;
    bst_diameter_helper(root, &diameter);
    return diameter;
}

static void test_bst_diameter(void) {
    BSTNode *root = NULL;
    int i;

    write_str("[BST Diameter]\n");
    pool_reset();

    /* Empty tree */
    check(bst_diameter(NULL) == 0, "diameter empty==0");

    /* Single node */
    root = bst_insert(NULL, 1);
    check(bst_diameter(root) == 0, "diameter single==0");

    /* Balanced tree of 7 nodes: diameter should be 4 (e.g., 1->2->4->6->7) */
    pool_reset();
    root = NULL;
    root = bst_insert(root, 4);
    root = bst_insert(root, 2);
    root = bst_insert(root, 6);
    root = bst_insert(root, 1);
    root = bst_insert(root, 3);
    root = bst_insert(root, 5);
    root = bst_insert(root, 7);
    check(bst_diameter(root) == 4, "balanced 7-node diameter==4");

    /* Degenerate (linked list): diameter == n-1 */
    pool_reset();
    root = NULL;
    for (i = 1; i <= 10; i++) root = bst_insert(root, i);
    check(bst_diameter(root) == 9, "degenerate 10-node diameter==9");
}

/* ========================================================================
 * Tree path sum check
 * ======================================================================== */
static int bst_has_path_sum(BSTNode *root, int target) {
    if (root == NULL) return (target == 0) ? 1 : 0;
    if (root->left == NULL && root->right == NULL) {
        return (target == root->key) ? 1 : 0;
    }
    return bst_has_path_sum(root->left, target - root->key) ||
           bst_has_path_sum(root->right, target - root->key);
}

static void test_path_sum(void) {
    BSTNode *root = NULL;

    write_str("[Path Sum]\n");
    pool_reset();

    /*
     *        10
     *       /  \
     *      5    15
     *     / \     \
     *    3   7    20
     */
    root = bst_insert(root, 10);
    root = bst_insert(root, 5);
    root = bst_insert(root, 15);
    root = bst_insert(root, 3);
    root = bst_insert(root, 7);
    root = bst_insert(root, 20);

    /* Paths: 10->5->3 = 18, 10->5->7 = 22, 10->15->20 = 45 */
    check(bst_has_path_sum(root, 18), "path sum 18 (10->5->3)");
    check(bst_has_path_sum(root, 22), "path sum 22 (10->5->7)");
    check(bst_has_path_sum(root, 45), "path sum 45 (10->15->20)");
    check(!bst_has_path_sum(root, 10), "no path sum 10");
    check(!bst_has_path_sum(root, 15), "no path sum 15");
    check(!bst_has_path_sum(root, 100), "no path sum 100");
}

/* ========================================================================
 * main
 * ======================================================================== */
int main(void) {
    g_errs = 0;
    init_io();
    pool_init();

    write_str("=== victim_tree: Tree Data Structures Stress Test ===\n\n");

    test_bst();
    test_bst_traversals();
    test_avl();
    test_avl_delete();
    test_avl_rotations();
    test_rbtree();
    test_heap();
    test_heap_advanced();
    test_maxheap();
    test_priority_queue();
    test_trie();
    test_trie_advanced();
    test_segment_tree();
    test_fenwick();
    test_seg_fenwick_cross();
    test_bst_edge_cases();
    test_bst_range_and_height();
    test_rebuild_stress();
    test_fenwick_kth();
    test_segment_tree_min();
    test_bst_level_order();
    test_bst_diameter();
    test_path_sum();

    write_str("\nTotal errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
