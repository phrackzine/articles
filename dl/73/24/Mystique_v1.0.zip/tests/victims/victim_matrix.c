/*
 * victim_matrix.c -- Matrix math stress test (Windows x86-32 MSVC)
 * Build: cl /nologo /O1 victim_matrix.c /Fe:victim_matrix.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 * Deterministic output. All integer arithmetic; fixed-point scaled by 1000 where noted.
 */
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* =========================================================================
 * Matrix representation: flat int array, row-major, rows x cols
 * ========================================================================= */

typedef struct {
    int rows;
    int cols;
    int* data;
} Matrix;

static Matrix* mat_create(int rows, int cols) {
    Matrix* m = (Matrix*)malloc(sizeof(Matrix));
    m->rows = rows;
    m->cols = cols;
    m->data = (int*)malloc(rows * cols * sizeof(int));
    memset(m->data, 0, rows * cols * sizeof(int));
    return m;
}

static void mat_free(Matrix* m) {
    if (m) { free(m->data); free(m); }
}

static int mat_get(const Matrix* m, int r, int c) {
    return m->data[r * m->cols + c];
}

static void mat_set(Matrix* m, int r, int c, int val) {
    m->data[r * m->cols + c] = val;
}

static Matrix* mat_copy(const Matrix* m) {
    Matrix* c = mat_create(m->rows, m->cols);
    memcpy(c->data, m->data, m->rows * m->cols * sizeof(int));
    return c;
}

/* =========================================================================
 * Matrix identity
 * ========================================================================= */

static Matrix* mat_identity(int n) {
    Matrix* m = mat_create(n, n);
    int i;
    for (i = 0; i < n; i++) mat_set(m, i, i, 1);
    return m;
}

/* Identity scaled by factor (for fixed-point) */
static Matrix* mat_identity_scaled(int n, int scale) {
    Matrix* m = mat_create(n, n);
    int i;
    for (i = 0; i < n; i++) mat_set(m, i, i, scale);
    return m;
}

/* =========================================================================
 * Matrix equality
 * ========================================================================= */

static int mat_equal(const Matrix* a, const Matrix* b) {
    int i;
    if (a->rows != b->rows || a->cols != b->cols) return 0;
    for (i = 0; i < a->rows * a->cols; i++) {
        if (a->data[i] != b->data[i]) return 0;
    }
    return 1;
}

/* Approximate equality (within tolerance) */
static int mat_approx_equal(const Matrix* a, const Matrix* b, int tol) {
    int i, d;
    if (a->rows != b->rows || a->cols != b->cols) return 0;
    for (i = 0; i < a->rows * a->cols; i++) {
        d = a->data[i] - b->data[i];
        if (d < 0) d = -d;
        if (d > tol) return 0;
    }
    return 1;
}

/* =========================================================================
 * Matrix add
 * ========================================================================= */

static Matrix* mat_add(const Matrix* a, const Matrix* b) {
    Matrix* r;
    int i;
    if (a->rows != b->rows || a->cols != b->cols) return NULL;
    r = mat_create(a->rows, a->cols);
    for (i = 0; i < a->rows * a->cols; i++)
        r->data[i] = a->data[i] + b->data[i];
    return r;
}

/* =========================================================================
 * Matrix subtract
 * ========================================================================= */

static Matrix* mat_sub(const Matrix* a, const Matrix* b) {
    Matrix* r;
    int i;
    if (a->rows != b->rows || a->cols != b->cols) return NULL;
    r = mat_create(a->rows, a->cols);
    for (i = 0; i < a->rows * a->cols; i++)
        r->data[i] = a->data[i] - b->data[i];
    return r;
}

/* =========================================================================
 * Matrix scalar multiply
 * ========================================================================= */

static Matrix* mat_scalar_mul(const Matrix* m, int s) {
    Matrix* r = mat_create(m->rows, m->cols);
    int i;
    for (i = 0; i < m->rows * m->cols; i++)
        r->data[i] = m->data[i] * s;
    return r;
}

/* =========================================================================
 * Matrix multiply (NxM * MxP = NxP)
 * ========================================================================= */

static Matrix* mat_mul(const Matrix* a, const Matrix* b) {
    Matrix* r;
    int i, j, k, sum;
    if (a->cols != b->rows) return NULL;
    r = mat_create(a->rows, b->cols);
    for (i = 0; i < a->rows; i++) {
        for (j = 0; j < b->cols; j++) {
            sum = 0;
            for (k = 0; k < a->cols; k++)
                sum += mat_get(a, i, k) * mat_get(b, k, j);
            mat_set(r, i, j, sum);
        }
    }
    return r;
}

/* =========================================================================
 * Matrix transpose
 * ========================================================================= */

static Matrix* mat_transpose(const Matrix* m) {
    Matrix* r = mat_create(m->cols, m->rows);
    int i, j;
    for (i = 0; i < m->rows; i++)
        for (j = 0; j < m->cols; j++)
            mat_set(r, j, i, mat_get(m, i, j));
    return r;
}

/* =========================================================================
 * Matrix trace
 * ========================================================================= */

static int mat_trace(const Matrix* m) {
    int i, t = 0;
    int n = (m->rows < m->cols) ? m->rows : m->cols;
    for (i = 0; i < n; i++) t += mat_get(m, i, i);
    return t;
}

/* =========================================================================
 * Matrix determinant (recursive cofactor expansion, up to 6x6)
 * ========================================================================= */

static Matrix* mat_submatrix(const Matrix* m, int skip_r, int skip_c) {
    Matrix* s = mat_create(m->rows - 1, m->cols - 1);
    int i, j, di, dj;
    di = 0;
    for (i = 0; i < m->rows; i++) {
        if (i == skip_r) continue;
        dj = 0;
        for (j = 0; j < m->cols; j++) {
            if (j == skip_c) continue;
            mat_set(s, di, dj, mat_get(m, i, j));
            dj++;
        }
        di++;
    }
    return s;
}

static int mat_det(const Matrix* m) {
    int n, j, sign, det;
    Matrix* sub;
    n = m->rows;
    if (n != m->cols) return 0;
    if (n == 1) return mat_get(m, 0, 0);
    if (n == 2) return mat_get(m, 0, 0) * mat_get(m, 1, 1) - mat_get(m, 0, 1) * mat_get(m, 1, 0);
    det = 0;
    sign = 1;
    for (j = 0; j < n; j++) {
        sub = mat_submatrix(m, 0, j);
        det += sign * mat_get(m, 0, j) * mat_det(sub);
        mat_free(sub);
        sign = -sign;
    }
    return det;
}

/* =========================================================================
 * Strassen-like 2x2 multiply (7 multiplications)
 * ========================================================================= */

static Matrix* mat_strassen2x2(const Matrix* a, const Matrix* b) {
    int a00, a01, a10, a11;
    int b00, b01, b10, b11;
    int m1, m2, m3, m4, m5, m6, m7;
    Matrix* r;
    if (a->rows != 2 || a->cols != 2 || b->rows != 2 || b->cols != 2) return NULL;
    a00 = mat_get(a, 0, 0); a01 = mat_get(a, 0, 1);
    a10 = mat_get(a, 1, 0); a11 = mat_get(a, 1, 1);
    b00 = mat_get(b, 0, 0); b01 = mat_get(b, 0, 1);
    b10 = mat_get(b, 1, 0); b11 = mat_get(b, 1, 1);
    m1 = (a00 + a11) * (b00 + b11);
    m2 = (a10 + a11) * b00;
    m3 = a00 * (b01 - b11);
    m4 = a11 * (b10 - b00);
    m5 = (a00 + a01) * b11;
    m6 = (a10 - a00) * (b00 + b01);
    m7 = (a01 - a11) * (b10 + b11);
    r = mat_create(2, 2);
    mat_set(r, 0, 0, m1 + m4 - m5 + m7);
    mat_set(r, 0, 1, m3 + m5);
    mat_set(r, 1, 0, m2 + m4);
    mat_set(r, 1, 1, m1 - m2 + m3 + m6);
    return r;
}

/* =========================================================================
 * LU decomposition (Crout's method, fixed-point scaled by 1000)
 * Input matrix values are plain integers; L and U are scaled by 1000.
 * L * U (with division by 1000) should approximate original * 1000.
 * ========================================================================= */

static void mat_lu_crout(const Matrix* a, Matrix** out_l, Matrix** out_u) {
    int n = a->rows;
    Matrix* L = mat_create(n, n);
    Matrix* U = mat_create(n, n);
    int i, j, k, sum;
    /* U diagonal = 1000 (fixed-point 1.0) */
    for (i = 0; i < n; i++) mat_set(U, i, i, 1000);
    for (j = 0; j < n; j++) {
        /* L column */
        for (i = j; i < n; i++) {
            sum = mat_get(a, i, j) * 1000;
            for (k = 0; k < j; k++) {
                sum -= (mat_get(L, i, k) * mat_get(U, k, j)) / 1000;
            }
            mat_set(L, i, j, sum);
        }
        /* U row */
        for (i = j + 1; i < n; i++) {
            sum = mat_get(a, j, i) * 1000;
            for (k = 0; k < j; k++) {
                sum -= (mat_get(L, j, k) * mat_get(U, k, i)) / 1000;
            }
            if (mat_get(L, j, j) != 0)
                mat_set(U, j, i, (sum * 1000) / mat_get(L, j, j));
            else
                mat_set(U, j, i, 0);
        }
    }
    *out_l = L;
    *out_u = U;
}

/* Multiply L*U with fixed-point division by 1000 */
static Matrix* mat_lu_product(const Matrix* L, const Matrix* U) {
    int n = L->rows;
    Matrix* r = mat_create(n, n);
    int i, j, k, sum;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            sum = 0;
            for (k = 0; k < n; k++) {
                sum += (mat_get(L, i, k) * mat_get(U, k, j)) / 1000;
            }
            mat_set(r, i, j, sum);
        }
    }
    return r;
}

/* =========================================================================
 * Matrix power (repeated squaring)
 * ========================================================================= */

static Matrix* mat_pow(const Matrix* m, int exp) {
    Matrix* result;
    Matrix* base;
    Matrix* tmp;
    int n = m->rows;
    if (exp == 0) return mat_identity(n);
    if (exp == 1) return mat_copy(m);
    result = mat_identity(n);
    base = mat_copy(m);
    while (exp > 0) {
        if (exp & 1) {
            tmp = mat_mul(result, base);
            mat_free(result);
            result = tmp;
        }
        exp >>= 1;
        if (exp > 0) {
            tmp = mat_mul(base, base);
            mat_free(base);
            base = tmp;
        }
    }
    mat_free(base);
    return result;
}

/* =========================================================================
 * Gaussian elimination (integer with scaling)
 * Returns the matrix in row echelon form (scaled by 'scale' to avoid fractions).
 * Also returns determinant approximation.
 * ========================================================================= */

static Matrix* mat_gaussian_elim(const Matrix* m, int* out_det_sign) {
    Matrix* g = mat_copy(m);
    int n = g->rows;
    int i, j, k, pivot_row, tmp, factor, pivot_val;
    int sign = 1;
    for (i = 0; i < n; i++) {
        /* Find pivot */
        pivot_row = -1;
        for (j = i; j < n; j++) {
            if (mat_get(g, j, i) != 0) { pivot_row = j; break; }
        }
        if (pivot_row == -1) { sign = 0; continue; }
        /* Swap rows if needed */
        if (pivot_row != i) {
            for (k = 0; k < g->cols; k++) {
                tmp = mat_get(g, i, k);
                mat_set(g, i, k, mat_get(g, pivot_row, k));
                mat_set(g, pivot_row, k, tmp);
            }
            sign = -sign;
        }
        /* Eliminate below */
        pivot_val = mat_get(g, i, i);
        for (j = i + 1; j < n; j++) {
            factor = mat_get(g, j, i);
            if (factor == 0) continue;
            for (k = i; k < g->cols; k++) {
                mat_set(g, j, k, mat_get(g, j, k) * pivot_val - mat_get(g, i, k) * factor);
            }
        }
    }
    if (out_det_sign) *out_det_sign = sign;
    return g;
}

/* =========================================================================
 * Matrix from array helper
 * ========================================================================= */

static Matrix* mat_from_array(int rows, int cols, const int* arr) {
    Matrix* m = mat_create(rows, cols);
    memcpy(m->data, arr, rows * cols * sizeof(int));
    return m;
}

/* =========================================================================
 * Print matrix (for debugging, also used in output)
 * ========================================================================= */

static void mat_print(const Matrix* m, const char* label) {
    int i, j;
    write_str("  ");
    write_str(label);
    write_str(" (");
    write_int(m->rows);
    write_str("x");
    write_int(m->cols);
    write_str("):\n");
    for (i = 0; i < m->rows; i++) {
        write_str("    [");
        for (j = 0; j < m->cols; j++) {
            if (j > 0) write_str(", ");
            write_int(mat_get(m, i, j));
        }
        write_str("]\n");
    }
}

/* =========================================================================
 *  TEST SECTIONS
 * ========================================================================= */

/* --- Test 1: Create and free, basic properties --- */
static void test_create_free(void) {
    Matrix *m1, *m2, *m3;
    int i;
    write_str("[test_create_free]\n");

    m1 = mat_create(1, 1);
    check(m1->rows == 1 && m1->cols == 1, "1x1 create size");
    check(mat_get(m1, 0, 0) == 0, "1x1 init zero");
    mat_set(m1, 0, 0, 42);
    check(mat_get(m1, 0, 0) == 42, "1x1 set/get");
    mat_free(m1);

    m2 = mat_create(3, 4);
    check(m2->rows == 3 && m2->cols == 4, "3x4 create size");
    for (i = 0; i < 12; i++) check(m2->data[i] == 0, "3x4 init zero");
    mat_free(m2);

    m3 = mat_create(6, 6);
    check(m3->rows == 6 && m3->cols == 6, "6x6 create size");
    mat_set(m3, 5, 5, -99);
    check(mat_get(m3, 5, 5) == -99, "6x6 corner set/get");
    mat_free(m3);
}

/* --- Test 2: Identity creation and properties --- */
static void test_identity(void) {
    Matrix *id1, *id2, *id3, *id5;
    int i, j, ok;
    write_str("[test_identity]\n");

    id1 = mat_identity(1);
    check(mat_get(id1, 0, 0) == 1, "1x1 identity");
    mat_free(id1);

    id2 = mat_identity(2);
    check(mat_get(id2, 0, 0) == 1 && mat_get(id2, 0, 1) == 0, "2x2 identity row0");
    check(mat_get(id2, 1, 0) == 0 && mat_get(id2, 1, 1) == 1, "2x2 identity row1");
    mat_free(id2);

    id3 = mat_identity(3);
    check(mat_trace(id3) == 3, "3x3 identity trace");
    mat_free(id3);

    id5 = mat_identity(5);
    ok = 1;
    for (i = 0; i < 5 && ok; i++)
        for (j = 0; j < 5 && ok; j++) {
            if (i == j) { if (mat_get(id5, i, j) != 1) ok = 0; }
            else { if (mat_get(id5, i, j) != 0) ok = 0; }
        }
    check(ok, "5x5 identity structure");
    check(mat_trace(id5) == 5, "5x5 identity trace");
    mat_free(id5);
}

/* --- Test 3: Addition and subtraction --- */
static void test_add_sub(void) {
    int a2[] = {1, 2, 3, 4};
    int b2[] = {5, 6, 7, 8};
    int sum2[] = {6, 8, 10, 12};
    int diff2[] = {-4, -4, -4, -4};
    int a3[] = {1,0,0, 0,2,0, 0,0,3};
    int b3[] = {0,1,1, 1,0,1, 1,1,0};
    Matrix *ma, *mb, *ms, *md, *mexp, *ma3, *mb3, *ms3;
    write_str("[test_add_sub]\n");

    ma = mat_from_array(2, 2, a2);
    mb = mat_from_array(2, 2, b2);
    ms = mat_add(ma, mb);
    mexp = mat_from_array(2, 2, sum2);
    check(mat_equal(ms, mexp), "2x2 add");
    mat_free(mexp);
    mat_free(ms);

    md = mat_sub(ma, mb);
    mexp = mat_from_array(2, 2, diff2);
    check(mat_equal(md, mexp), "2x2 sub");
    mat_free(mexp);
    mat_free(md);
    mat_free(ma);
    mat_free(mb);

    /* A + 0 = A */
    ma3 = mat_from_array(3, 3, a3);
    mb3 = mat_create(3, 3);
    ms3 = mat_add(ma3, mb3);
    check(mat_equal(ms3, ma3), "3x3 add zero");
    mat_free(ms3);
    mat_free(mb3);

    /* A - A = 0 */
    mb3 = mat_from_array(3, 3, b3);
    ms3 = mat_sub(mb3, mb3);
    {
        Matrix* z = mat_create(3, 3);
        check(mat_equal(ms3, z), "3x3 A-A=0");
        mat_free(z);
    }
    mat_free(ms3);
    mat_free(mb3);
    mat_free(ma3);
}

/* --- Test 4: Scalar multiply --- */
static void test_scalar_mul(void) {
    int a[] = {1, 2, 3, 4, 5, 6};
    int e3[] = {3, 6, 9, 12, 15, 18};
    Matrix *ma, *ms, *mexp, *mz;
    write_str("[test_scalar_mul]\n");

    ma = mat_from_array(2, 3, a);
    ms = mat_scalar_mul(ma, 3);
    mexp = mat_from_array(2, 3, e3);
    check(mat_equal(ms, mexp), "2x3 scalar*3");
    mat_free(mexp);
    mat_free(ms);

    ms = mat_scalar_mul(ma, 0);
    mz = mat_create(2, 3);
    check(mat_equal(ms, mz), "2x3 scalar*0");
    mat_free(mz);
    mat_free(ms);

    ms = mat_scalar_mul(ma, -1);
    {
        int en[] = {-1, -2, -3, -4, -5, -6};
        mexp = mat_from_array(2, 3, en);
        check(mat_equal(ms, mexp), "2x3 scalar*(-1)");
        mat_free(mexp);
    }
    mat_free(ms);

    ms = mat_scalar_mul(ma, 1);
    check(mat_equal(ms, ma), "2x3 scalar*1");
    mat_free(ms);
    mat_free(ma);
}

/* --- Test 5: Matrix multiply --- */
static void test_multiply(void) {
    int a[] = {1, 2, 3, 4};
    int b[] = {5, 6, 7, 8};
    int ab[] = {19, 22, 43, 50};
    int c23[] = {1, 2, 3, 4, 5, 6};
    int c32[] = {7, 8, 9, 10, 11, 12};
    int c22_exp[] = {58, 64, 139, 154};
    Matrix *ma, *mb, *mp, *mexp;
    Matrix *mc23, *mc32, *mc22;
    Matrix *id, *ai;
    write_str("[test_multiply]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    mp = mat_mul(ma, mb);
    mexp = mat_from_array(2, 2, ab);
    check(mat_equal(mp, mexp), "2x2 mul");
    mat_free(mexp);
    mat_free(mp);

    /* I * A = A */
    id = mat_identity(2);
    ai = mat_mul(id, ma);
    check(mat_equal(ai, ma), "I*A=A 2x2");
    mat_free(ai);

    /* A * I = A */
    ai = mat_mul(ma, id);
    check(mat_equal(ai, ma), "A*I=A 2x2");
    mat_free(ai);
    mat_free(id);
    mat_free(ma);
    mat_free(mb);

    /* 2x3 * 3x2 = 2x2 */
    mc23 = mat_from_array(2, 3, c23);
    mc32 = mat_from_array(3, 2, c32);
    mc22 = mat_mul(mc23, mc32);
    mexp = mat_from_array(2, 2, c22_exp);
    check(mat_equal(mc22, mexp), "2x3 * 3x2");
    mat_free(mexp);
    mat_free(mc22);
    mat_free(mc23);
    mat_free(mc32);

    /* 1x1 multiply */
    {
        Matrix* x = mat_create(1, 1);
        Matrix* y = mat_create(1, 1);
        Matrix* z;
        mat_set(x, 0, 0, 7);
        mat_set(y, 0, 0, 6);
        z = mat_mul(x, y);
        check(mat_get(z, 0, 0) == 42, "1x1 mul");
        mat_free(z);
        mat_free(y);
        mat_free(x);
    }
}

/* --- Test 6: I*A=A for various sizes --- */
static void test_identity_multiply(void) {
    int vals3[] = {2,7,3, 1,5,8, 4,6,9};
    int vals4[] = {1,2,3,4, 5,6,7,8, 9,10,11,12, 13,14,15,16};
    Matrix *a3, *id3, *p3, *a4, *id4, *p4;
    write_str("[test_identity_multiply]\n");

    a3 = mat_from_array(3, 3, vals3);
    id3 = mat_identity(3);
    p3 = mat_mul(id3, a3);
    check(mat_equal(p3, a3), "I*A=A 3x3");
    mat_free(p3);
    p3 = mat_mul(a3, id3);
    check(mat_equal(p3, a3), "A*I=A 3x3");
    mat_free(p3);
    mat_free(id3);
    mat_free(a3);

    a4 = mat_from_array(4, 4, vals4);
    id4 = mat_identity(4);
    p4 = mat_mul(id4, a4);
    check(mat_equal(p4, a4), "I*A=A 4x4");
    mat_free(p4);
    p4 = mat_mul(a4, id4);
    check(mat_equal(p4, a4), "A*I=A 4x4");
    mat_free(p4);
    mat_free(id4);
    mat_free(a4);
}

/* --- Test 7: Transpose --- */
static void test_transpose(void) {
    int a23[] = {1,2,3, 4,5,6};
    int t32[] = {1,4, 2,5, 3,6};
    Matrix *ma, *mt, *mexp, *mtt;
    Matrix *sym, *sym_t;
    write_str("[test_transpose]\n");

    ma = mat_from_array(2, 3, a23);
    mt = mat_transpose(ma);
    mexp = mat_from_array(3, 2, t32);
    check(mat_equal(mt, mexp), "2x3 transpose");
    mat_free(mexp);

    /* (A^T)^T = A */
    mtt = mat_transpose(mt);
    check(mat_equal(mtt, ma), "(A^T)^T = A");
    mat_free(mtt);
    mat_free(mt);
    mat_free(ma);

    /* Symmetric matrix: A^T = A */
    {
        int s[] = {1,2,3, 2,4,5, 3,5,6};
        sym = mat_from_array(3, 3, s);
        sym_t = mat_transpose(sym);
        check(mat_equal(sym, sym_t), "symmetric A^T=A");
        mat_free(sym_t);
        mat_free(sym);
    }

    /* 1x1 transpose */
    {
        Matrix* m1 = mat_create(1, 1);
        Matrix* t1;
        mat_set(m1, 0, 0, 99);
        t1 = mat_transpose(m1);
        check(mat_get(t1, 0, 0) == 99, "1x1 transpose");
        mat_free(t1);
        mat_free(m1);
    }
}

/* --- Test 8: (A*B)^T = B^T * A^T --- */
static void test_transpose_product(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    int a3[] = {1,2,3, 4,5,6, 7,8,9};
    int b3[] = {9,8,7, 6,5,4, 3,2,1};
    Matrix *ma, *mb, *ab, *abt, *at, *bt, *btat;
    Matrix *ma3, *mb3, *ab3, *ab3t, *at3, *bt3, *bt3at3;
    write_str("[test_transpose_product]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    ab = mat_mul(ma, mb);
    abt = mat_transpose(ab);
    at = mat_transpose(ma);
    bt = mat_transpose(mb);
    btat = mat_mul(bt, at);
    check(mat_equal(abt, btat), "(AB)^T=B^T*A^T 2x2");
    mat_free(btat); mat_free(bt); mat_free(at);
    mat_free(abt); mat_free(ab);
    mat_free(mb); mat_free(ma);

    /* 3x3 version */
    ma3 = mat_from_array(3, 3, a3);
    mb3 = mat_from_array(3, 3, b3);
    ab3 = mat_mul(ma3, mb3);
    ab3t = mat_transpose(ab3);
    at3 = mat_transpose(ma3);
    bt3 = mat_transpose(mb3);
    bt3at3 = mat_mul(bt3, at3);
    check(mat_equal(ab3t, bt3at3), "(AB)^T=B^T*A^T 3x3");
    mat_free(bt3at3); mat_free(bt3); mat_free(at3);
    mat_free(ab3t); mat_free(ab3);
    mat_free(mb3); mat_free(ma3);
}

/* --- Test 9: Determinant --- */
static void test_determinant(void) {
    Matrix *m1, *m2, *m3, *m4, *m5, *id;
    write_str("[test_determinant]\n");

    /* 1x1 */
    m1 = mat_create(1, 1);
    mat_set(m1, 0, 0, 7);
    check(mat_det(m1) == 7, "det 1x1");
    mat_free(m1);

    /* 2x2: ad-bc = 1*4-2*3 = -2 */
    {
        int d2[] = {1,2, 3,4};
        m2 = mat_from_array(2, 2, d2);
        check(mat_det(m2) == -2, "det 2x2 = -2");
        mat_free(m2);
    }

    /* 2x2 identity: det = 1 */
    id = mat_identity(2);
    check(mat_det(id) == 1, "det I(2) = 1");
    mat_free(id);

    /* 3x3 identity: det = 1 */
    id = mat_identity(3);
    check(mat_det(id) == 1, "det I(3) = 1");
    mat_free(id);

    /* 3x3 known: det([[1,2,3],[4,5,6],[7,8,9]]) = 0 */
    {
        int d3[] = {1,2,3, 4,5,6, 7,8,9};
        m3 = mat_from_array(3, 3, d3);
        check(mat_det(m3) == 0, "det 3x3 singular = 0");
        mat_free(m3);
    }

    /* 3x3: det([[2,1,1],[1,3,2],[1,0,0]]) = 2*(0-0)-1*(0-2)+1*(0-3) = 0+2-3 = -1 */
    {
        int d3b[] = {2,1,1, 1,3,2, 1,0,0};
        m3 = mat_from_array(3, 3, d3b);
        check(mat_det(m3) == -1, "det 3x3 = -1");
        mat_free(m3);
    }

    /* 4x4 identity */
    id = mat_identity(4);
    check(mat_det(id) == 1, "det I(4) = 1");
    mat_free(id);

    /* 4x4 known */
    {
        int d4[] = {1,0,2,-1, 3,0,0,5, 2,1,4,-3, 1,0,5,0};
        m4 = mat_from_array(4, 4, d4);
        check(mat_det(m4) == 30, "det 4x4 = 30");
        mat_free(m4);
    }

    /* 5x5 identity */
    id = mat_identity(5);
    check(mat_det(id) == 1, "det I(5) = 1");
    mat_free(id);

    /* 5x5 upper triangular: det = product of diagonal */
    {
        int d5[] = {2,1,3,0,1, 0,3,0,2,0, 0,0,1,4,2, 0,0,0,2,5, 0,0,0,0,4};
        m5 = mat_from_array(5, 5, d5);
        /* det = 2*3*1*2*4 = 48 */
        check(mat_det(m5) == 48, "det 5x5 upper tri = 48");
        mat_free(m5);
    }

    /* det(scalar * I) = scalar^n for nxn */
    {
        Matrix* s2 = mat_scalar_mul(mat_identity(2), 3);
        /* Actually need to be careful: mat_scalar_mul returns new matrix */
        /* 3I_2 det = 9 */
        check(mat_det(s2) == 9, "det(3*I2)=9");
        mat_free(s2);
    }
    {
        Matrix* i3 = mat_identity(3);
        Matrix* s3 = mat_scalar_mul(i3, 2);
        check(mat_det(s3) == 8, "det(2*I3)=8");
        mat_free(s3);
        mat_free(i3);
    }
}

/* --- Test 10: Trace --- */
static void test_trace(void) {
    int a[] = {1,2,3, 4,5,6, 7,8,9};
    int b[] = {10,20, 30,40};
    Matrix *ma, *mb, *ms;
    write_str("[test_trace]\n");

    ma = mat_from_array(3, 3, a);
    check(mat_trace(ma) == 15, "trace 3x3 = 15");

    mb = mat_from_array(2, 2, b);
    check(mat_trace(mb) == 50, "trace 2x2 = 50");

    /* trace(A+B) = trace(A) + trace(B) */
    {
        int c[] = {9,8,7, 6,5,4, 3,2,1};
        Matrix* mc = mat_from_array(3, 3, c);
        ms = mat_add(ma, mc);
        check(mat_trace(ms) == mat_trace(ma) + mat_trace(mc), "trace(A+B)=trace(A)+trace(B)");
        mat_free(ms);
        mat_free(mc);
    }

    /* trace(kA) = k*trace(A) */
    ms = mat_scalar_mul(ma, 5);
    check(mat_trace(ms) == 75, "trace(5A) = 5*trace(A)");
    mat_free(ms);

    mat_free(mb);
    mat_free(ma);

    /* 1x1 trace */
    {
        Matrix* m1 = mat_create(1, 1);
        mat_set(m1, 0, 0, 42);
        check(mat_trace(m1) == 42, "trace 1x1 = 42");
        mat_free(m1);
    }
}

/* --- Test 11: Strassen 2x2 --- */
static void test_strassen(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    Matrix *ma, *mb, *ms, *mn;
    int a2[] = {10, -3, 7, 2};
    int b2[] = {-1, 4, 0, 5};
    Matrix *ma2, *mb2, *ms2, *mn2;
    write_str("[test_strassen]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    ms = mat_strassen2x2(ma, mb);
    mn = mat_mul(ma, mb);
    check(mat_equal(ms, mn), "strassen vs naive 2x2 #1");
    mat_free(mn);
    mat_free(ms);
    mat_free(mb);
    mat_free(ma);

    ma2 = mat_from_array(2, 2, a2);
    mb2 = mat_from_array(2, 2, b2);
    ms2 = mat_strassen2x2(ma2, mb2);
    mn2 = mat_mul(ma2, mb2);
    check(mat_equal(ms2, mn2), "strassen vs naive 2x2 #2");
    mat_free(mn2);
    mat_free(ms2);
    mat_free(mb2);
    mat_free(ma2);

    /* Identity * Identity via Strassen */
    {
        Matrix* i2 = mat_identity(2);
        Matrix* si = mat_strassen2x2(i2, i2);
        check(mat_equal(si, i2), "strassen I*I=I");
        mat_free(si);
        mat_free(i2);
    }
}

/* --- Test 12: LU decomposition --- */
static void test_lu(void) {
    int a2[] = {4,3, 6,3};
    int a3[] = {2,1,1, 4,3,3, 8,7,9};
    Matrix *ma, *L, *U, *prod, *scaled_a;
    write_str("[test_lu]\n");

    /* 2x2 LU */
    ma = mat_from_array(2, 2, a2);
    mat_lu_crout(ma, &L, &U);
    prod = mat_lu_product(L, U);
    /* prod should be close to a * 1000 */
    scaled_a = mat_scalar_mul(ma, 1000);
    check(mat_approx_equal(prod, scaled_a, 5), "LU 2x2 reconstruct");
    mat_free(scaled_a);
    mat_free(prod);
    mat_free(U);
    mat_free(L);
    mat_free(ma);

    /* 3x3 LU */
    ma = mat_from_array(3, 3, a3);
    mat_lu_crout(ma, &L, &U);
    prod = mat_lu_product(L, U);
    scaled_a = mat_scalar_mul(ma, 1000);
    check(mat_approx_equal(prod, scaled_a, 5), "LU 3x3 reconstruct");
    mat_free(scaled_a);
    mat_free(prod);
    mat_free(U);
    mat_free(L);
    mat_free(ma);

    /* LU of identity */
    {
        Matrix *id3 = mat_identity(3);
        Matrix *Lid, *Uid, *pid, *sid;
        mat_lu_crout(id3, &Lid, &Uid);
        pid = mat_lu_product(Lid, Uid);
        sid = mat_scalar_mul(id3, 1000);
        check(mat_approx_equal(pid, sid, 5), "LU I(3) reconstruct");
        mat_free(sid);
        mat_free(pid);
        mat_free(Uid);
        mat_free(Lid);
        mat_free(id3);
    }

    /* 4x4 LU */
    {
        int a4[] = {1,2,3,4, 2,5,7,3, 3,7,12,5, 4,3,5,10};
        Matrix *m4 = mat_from_array(4, 4, a4);
        Matrix *L4, *U4, *p4, *s4;
        mat_lu_crout(m4, &L4, &U4);
        p4 = mat_lu_product(L4, U4);
        s4 = mat_scalar_mul(m4, 1000);
        check(mat_approx_equal(p4, s4, 10), "LU 4x4 reconstruct");
        mat_free(s4);
        mat_free(p4);
        mat_free(U4);
        mat_free(L4);
        mat_free(m4);
    }
}

/* --- Test 13: Matrix power --- */
static void test_power(void) {
    int a[] = {1,1, 1,0};
    int a3[] = {1,0,0, 0,1,0, 0,0,1};
    Matrix *ma, *mp, *mp2, *expected, *mfib;
    write_str("[test_power]\n");

    /* A^0 = I */
    ma = mat_from_array(2, 2, a);
    mp = mat_pow(ma, 0);
    expected = mat_identity(2);
    check(mat_equal(mp, expected), "A^0 = I");
    mat_free(expected);
    mat_free(mp);

    /* A^1 = A */
    mp = mat_pow(ma, 1);
    check(mat_equal(mp, ma), "A^1 = A");
    mat_free(mp);

    /* Fibonacci matrix: [[1,1],[1,0]]^n gives fib(n+1),fib(n),fib(n),fib(n-1)
       F^2 = [[2,1],[1,1]] */
    mp = mat_pow(ma, 2);
    {
        int f2[] = {2,1, 1,1};
        expected = mat_from_array(2, 2, f2);
        check(mat_equal(mp, expected), "fib^2");
        mat_free(expected);
    }
    mat_free(mp);

    /* F^5 should have fib(6)=8 at [0][0] */
    mp = mat_pow(ma, 5);
    check(mat_get(mp, 0, 0) == 8, "fib^5 [0][0]=8");
    check(mat_get(mp, 0, 1) == 5, "fib^5 [0][1]=5");
    mat_free(mp);

    /* F^10: fib(11)=89 */
    mp = mat_pow(ma, 10);
    check(mat_get(mp, 0, 0) == 89, "fib^10 [0][0]=89");
    mat_free(mp);

    mat_free(ma);

    /* I^n = I */
    {
        Matrix *id3 = mat_identity(3);
        Matrix *ip = mat_pow(id3, 100);
        check(mat_equal(ip, id3), "I^100=I");
        mat_free(ip);
        mat_free(id3);
    }

    /* A^2 = A*A for 3x3 */
    {
        int v[] = {2,0,1, 0,1,0, 1,0,2};
        Matrix *m3 = mat_from_array(3, 3, v);
        Matrix *p2 = mat_pow(m3, 2);
        Matrix *mm = mat_mul(m3, m3);
        check(mat_equal(p2, mm), "A^2=A*A 3x3");
        mat_free(mm);
        mat_free(p2);
        mat_free(m3);
    }

    /* A^4 via repeated squaring check */
    {
        int v[] = {1,2, 0,1};
        Matrix *m2 = mat_from_array(2, 2, v);
        Matrix *p4 = mat_pow(m2, 4);
        /* [[1,2],[0,1]]^4 = [[1,8],[0,1]] */
        check(mat_get(p4, 0, 0) == 1, "upper tri ^4 [0][0]");
        check(mat_get(p4, 0, 1) == 8, "upper tri ^4 [0][1]");
        check(mat_get(p4, 1, 0) == 0, "upper tri ^4 [1][0]");
        check(mat_get(p4, 1, 1) == 1, "upper tri ^4 [1][1]");
        mat_free(p4);
        mat_free(m2);
    }
}

/* --- Test 14: Gaussian elimination --- */
static void test_gaussian(void) {
    int a[] = {2,1, 4,3};
    int a3[] = {1,2,3, 4,5,6, 7,8,9};
    int a4[] = {1,0,2,-1, 3,0,0,5, 2,1,4,-3, 1,0,5,0};
    Matrix *ma, *mg, *ma3, *mg3, *ma4, *mg4;
    int sign;
    write_str("[test_gaussian]\n");

    /* 2x2 elimination: after elim, upper triangular */
    ma = mat_from_array(2, 2, a);
    mg = mat_gaussian_elim(ma, &sign);
    check(mat_get(mg, 1, 0) == 0, "gauss 2x2 lower-left zero");
    check(sign == 1, "gauss 2x2 no swap");
    mat_free(mg);
    mat_free(ma);

    /* 3x3 singular */
    ma3 = mat_from_array(3, 3, a3);
    mg3 = mat_gaussian_elim(ma3, &sign);
    /* Last row should be all zeros */
    check(mat_get(mg3, 2, 0) == 0, "gauss 3x3 singular [2][0]=0");
    check(mat_get(mg3, 2, 1) == 0, "gauss 3x3 singular [2][1]=0");
    check(mat_get(mg3, 2, 2) == 0, "gauss 3x3 singular [2][2]=0");
    mat_free(mg3);
    mat_free(ma3);

    /* 4x4 non-singular */
    ma4 = mat_from_array(4, 4, a4);
    mg4 = mat_gaussian_elim(ma4, &sign);
    check(mat_get(mg4, 1, 0) == 0, "gauss 4x4 [1][0]=0");
    check(mat_get(mg4, 2, 0) == 0, "gauss 4x4 [2][0]=0");
    check(mat_get(mg4, 2, 1) == 0, "gauss 4x4 [2][1]=0");
    check(mat_get(mg4, 3, 0) == 0, "gauss 4x4 [3][0]=0");
    mat_free(mg4);
    mat_free(ma4);

    /* Identity should remain unchanged */
    {
        Matrix *id3 = mat_identity(3);
        Matrix *gid = mat_gaussian_elim(id3, &sign);
        check(mat_equal(gid, id3), "gauss I(3)=I(3)");
        check(sign == 1, "gauss I(3) sign=1");
        mat_free(gid);
        mat_free(id3);
    }
}

/* --- Test 15: Equality and copy --- */
static void test_equality_copy(void) {
    int a[] = {1,2,3, 4,5,6};
    int b[] = {1,2,3, 4,5,7};
    Matrix *ma, *mb, *mc;
    write_str("[test_equality_copy]\n");

    ma = mat_from_array(2, 3, a);
    mb = mat_from_array(2, 3, b);
    mc = mat_copy(ma);

    check(mat_equal(ma, mc), "copy equals original");
    check(!mat_equal(ma, mb), "different not equal");
    check(ma->data != mc->data, "copy is deep");

    mat_set(mc, 0, 0, 999);
    check(!mat_equal(ma, mc), "modified copy not equal");

    mat_free(mc);
    mat_free(mb);
    mat_free(ma);

    /* Different dimensions not equal */
    {
        Matrix *x = mat_create(2, 3);
        Matrix *y = mat_create(3, 2);
        check(!mat_equal(x, y), "diff dims not equal");
        mat_free(y);
        mat_free(x);
    }
}

/* --- Test 16: Submatrix extraction --- */
static void test_submatrix(void) {
    int a[] = {1,2,3, 4,5,6, 7,8,9};
    int e1[] = {5,6, 8,9};
    int e2[] = {1,3, 7,9};
    Matrix *ma, *sub, *mexp;
    write_str("[test_submatrix]\n");

    ma = mat_from_array(3, 3, a);

    sub = mat_submatrix(ma, 0, 0);
    mexp = mat_from_array(2, 2, e1);
    check(mat_equal(sub, mexp), "submatrix skip(0,0)");
    mat_free(mexp);
    mat_free(sub);

    sub = mat_submatrix(ma, 0, 1);
    mexp = mat_from_array(2, 2, e2);
    /* skip row 0, col 1: [[4,6],[7,9]] */
    {
        int e3[] = {4,6, 7,9};
        mat_free(mexp);
        mexp = mat_from_array(2, 2, e3);
        check(mat_equal(sub, mexp), "submatrix skip(0,1)");
    }
    mat_free(mexp);
    mat_free(sub);

    /* skip middle */
    sub = mat_submatrix(ma, 1, 1);
    {
        int e4[] = {1,3, 7,9};
        mexp = mat_from_array(2, 2, e4);
        check(mat_equal(sub, mexp), "submatrix skip(1,1)");
        mat_free(mexp);
    }
    mat_free(sub);
    mat_free(ma);
}

/* --- Test 17: Large matrix operations (6x6) --- */
static void test_large_matrix(void) {
    int vals6[] = {
        3,1,4,1,5,9,
        2,6,5,3,5,8,
        9,7,9,3,2,3,
        8,4,6,2,6,4,
        3,3,8,3,2,7,
        9,5,0,2,8,8
    };
    Matrix *m6, *id6, *p6, *t6, *tt6;
    write_str("[test_large_matrix]\n");

    m6 = mat_from_array(6, 6, vals6);
    id6 = mat_identity(6);

    /* I*A = A */
    p6 = mat_mul(id6, m6);
    check(mat_equal(p6, m6), "I*A=A 6x6");
    mat_free(p6);

    /* A*I = A */
    p6 = mat_mul(m6, id6);
    check(mat_equal(p6, m6), "A*I=A 6x6");
    mat_free(p6);

    /* (A^T)^T = A */
    t6 = mat_transpose(m6);
    tt6 = mat_transpose(t6);
    check(mat_equal(tt6, m6), "(A^T)^T=A 6x6");
    mat_free(tt6);
    mat_free(t6);

    /* trace */
    check(mat_trace(m6) == 3+6+9+2+2+8, "trace 6x6 = 30");

    mat_free(id6);
    mat_free(m6);
}

/* --- Test 18: Distributive property A*(B+C) = A*B + A*C --- */
static void test_distributive(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    int c[] = {2,0, 1,3};
    Matrix *ma, *mb, *mc, *bc, *abc, *ab, *ac, *abpac;
    write_str("[test_distributive]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    mc = mat_from_array(2, 2, c);

    bc = mat_add(mb, mc);
    abc = mat_mul(ma, bc);
    ab = mat_mul(ma, mb);
    ac = mat_mul(ma, mc);
    abpac = mat_add(ab, ac);
    check(mat_equal(abc, abpac), "A(B+C)=AB+AC 2x2");

    mat_free(abpac);
    mat_free(ac);
    mat_free(ab);
    mat_free(abc);
    mat_free(bc);

    /* 3x3 version */
    {
        int va[] = {1,0,2, 0,1,0, 2,0,1};
        int vb[] = {3,1,0, 1,3,1, 0,1,3};
        int vc[] = {1,1,1, 1,1,1, 1,1,1};
        Matrix *a3 = mat_from_array(3, 3, va);
        Matrix *b3 = mat_from_array(3, 3, vb);
        Matrix *c3 = mat_from_array(3, 3, vc);
        Matrix *bc3 = mat_add(b3, c3);
        Matrix *abc3 = mat_mul(a3, bc3);
        Matrix *ab3 = mat_mul(a3, b3);
        Matrix *ac3 = mat_mul(a3, c3);
        Matrix *sum3 = mat_add(ab3, ac3);
        check(mat_equal(abc3, sum3), "A(B+C)=AB+AC 3x3");
        mat_free(sum3); mat_free(ac3); mat_free(ab3);
        mat_free(abc3); mat_free(bc3);
        mat_free(c3); mat_free(b3); mat_free(a3);
    }

    mat_free(mc);
    mat_free(mb);
    mat_free(ma);
}

/* --- Test 19: det(A*B) = det(A) * det(B) --- */
static void test_det_product(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    Matrix *ma, *mb, *mab;
    int da, db, dab;
    write_str("[test_det_product]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    mab = mat_mul(ma, mb);
    da = mat_det(ma);
    db = mat_det(mb);
    dab = mat_det(mab);
    check(dab == da * db, "det(AB)=det(A)*det(B) 2x2");
    mat_free(mab);
    mat_free(mb);
    mat_free(ma);

    /* 3x3 */
    {
        int va[] = {2,1,0, 0,3,1, 1,0,2};
        int vb[] = {1,0,1, 0,2,0, 1,0,1};
        Matrix *a3 = mat_from_array(3, 3, va);
        Matrix *b3 = mat_from_array(3, 3, vb);
        Matrix *ab3 = mat_mul(a3, b3);
        int da3 = mat_det(a3);
        int db3 = mat_det(b3);
        int dab3 = mat_det(ab3);
        check(dab3 == da3 * db3, "det(AB)=det(A)*det(B) 3x3");
        mat_free(ab3);
        mat_free(b3);
        mat_free(a3);
    }
}

/* --- Test 20: det(A^T) = det(A) --- */
static void test_det_transpose(void) {
    int a[] = {3,1,4, 1,5,9, 2,6,5};
    Matrix *ma, *mt;
    write_str("[test_det_transpose]\n");

    ma = mat_from_array(3, 3, a);
    mt = mat_transpose(ma);
    check(mat_det(ma) == mat_det(mt), "det(A^T)=det(A) 3x3");
    mat_free(mt);
    mat_free(ma);

    /* 4x4 */
    {
        int v[] = {1,0,2,-1, 3,0,0,5, 2,1,4,-3, 1,0,5,0};
        Matrix *m4 = mat_from_array(4, 4, v);
        Matrix *t4 = mat_transpose(m4);
        check(mat_det(m4) == mat_det(t4), "det(A^T)=det(A) 4x4");
        mat_free(t4);
        mat_free(m4);
    }
}

/* --- Test 21: Trace properties --- */
static void test_trace_properties(void) {
    int a[] = {1,2,3, 4,5,6, 7,8,9};
    int b[] = {9,8,7, 6,5,4, 3,2,1};
    Matrix *ma, *mb, *mab, *mba;
    write_str("[test_trace_properties]\n");

    ma = mat_from_array(3, 3, a);
    mb = mat_from_array(3, 3, b);
    mab = mat_mul(ma, mb);
    mba = mat_mul(mb, ma);

    /* trace(AB) = trace(BA) */
    check(mat_trace(mab) == mat_trace(mba), "trace(AB)=trace(BA)");

    /* trace(A^T) = trace(A) */
    {
        Matrix *at = mat_transpose(ma);
        check(mat_trace(at) == mat_trace(ma), "trace(A^T)=trace(A)");
        mat_free(at);
    }

    mat_free(mba);
    mat_free(mab);
    mat_free(mb);
    mat_free(ma);
}

/* --- Test 22: Power associativity A^(m+n) = A^m * A^n --- */
static void test_power_assoc(void) {
    int a[] = {1,1, 0,1};
    Matrix *ma, *p3, *p5, *p8, *p3p5;
    write_str("[test_power_assoc]\n");

    ma = mat_from_array(2, 2, a);
    p3 = mat_pow(ma, 3);
    p5 = mat_pow(ma, 5);
    p8 = mat_pow(ma, 8);
    p3p5 = mat_mul(p3, p5);
    check(mat_equal(p8, p3p5), "A^8=A^3*A^5");

    mat_free(p3p5);
    mat_free(p8);
    mat_free(p5);
    mat_free(p3);
    mat_free(ma);

    /* 3x3 */
    {
        int v[] = {1,0,0, 0,2,0, 0,0,3};
        Matrix *m3 = mat_from_array(3, 3, v);
        Matrix *q2 = mat_pow(m3, 2);
        Matrix *q3 = mat_pow(m3, 3);
        Matrix *q5 = mat_pow(m3, 5);
        Matrix *q2q3 = mat_mul(q2, q3);
        check(mat_equal(q5, q2q3), "diag A^5=A^2*A^3");
        /* Diagonal power check: diag(1,2,3)^3 = diag(1,8,27) */
        check(mat_get(q3, 0, 0) == 1, "diag^3 [0][0]=1");
        check(mat_get(q3, 1, 1) == 8, "diag^3 [1][1]=8");
        check(mat_get(q3, 2, 2) == 27, "diag^3 [2][2]=27");
        mat_free(q2q3);
        mat_free(q5);
        mat_free(q3);
        mat_free(q2);
        mat_free(m3);
    }
}

/* --- Test 23: Scalar multiply distributes over add --- */
static void test_scalar_distribute(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    Matrix *ma, *mb, *apb, *sapb, *sa, *sb, *sapsb;
    write_str("[test_scalar_distribute]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    apb = mat_add(ma, mb);
    sapb = mat_scalar_mul(apb, 3);
    sa = mat_scalar_mul(ma, 3);
    sb = mat_scalar_mul(mb, 3);
    sapsb = mat_add(sa, sb);
    check(mat_equal(sapb, sapsb), "k(A+B) = kA+kB");

    mat_free(sapsb);
    mat_free(sb);
    mat_free(sa);
    mat_free(sapb);
    mat_free(apb);
    mat_free(mb);
    mat_free(ma);
}

/* --- Test 24: Additional determinant tests --- */
static void test_det_additional(void) {
    write_str("[test_det_additional]\n");

    /* Lower triangular */
    {
        int lt[] = {2,0,0, 3,5,0, 1,4,7};
        Matrix* m = mat_from_array(3, 3, lt);
        check(mat_det(m) == 70, "det lower tri 3x3 = 70");
        mat_free(m);
    }

    /* det of a matrix with a zero row = 0 */
    {
        int zr[] = {1,2,3, 0,0,0, 4,5,6};
        Matrix* m = mat_from_array(3, 3, zr);
        check(mat_det(m) == 0, "det zero row = 0");
        mat_free(m);
    }

    /* det of a matrix with two equal rows = 0 */
    {
        int er[] = {1,2,3, 4,5,6, 1,2,3};
        Matrix* m = mat_from_array(3, 3, er);
        check(mat_det(m) == 0, "det equal rows = 0");
        mat_free(m);
    }

    /* det negated when two rows swapped */
    {
        int a[] = {1,2, 3,4};
        int b[] = {3,4, 1,2};
        Matrix* ma = mat_from_array(2, 2, a);
        Matrix* mb = mat_from_array(2, 2, b);
        check(mat_det(ma) == -mat_det(mb), "det sign flip on row swap");
        mat_free(mb);
        mat_free(ma);
    }

    /* 5x5 with known value */
    {
        int v[] = {
            1,0,0,0,0,
            0,2,0,0,0,
            0,0,3,0,0,
            0,0,0,4,0,
            0,0,0,0,5
        };
        Matrix* m = mat_from_array(5, 5, v);
        check(mat_det(m) == 120, "det diag(1..5)=120");
        mat_free(m);
    }
}

/* --- Test 25: Matrix rotation-like power --- */
static void test_rotation_power(void) {
    /* 90-degree rotation matrix (integer): [[0,-1],[1,0]] */
    /* R^4 should be identity */
    int r[] = {0, -1, 1, 0};
    Matrix *mr, *mr2, *mr4;
    Matrix *id2;
    write_str("[test_rotation_power]\n");

    mr = mat_from_array(2, 2, r);
    id2 = mat_identity(2);

    /* R^2 = [[-1,0],[0,-1]] = -I */
    mr2 = mat_pow(mr, 2);
    check(mat_get(mr2, 0, 0) == -1, "R^2 [0][0]=-1");
    check(mat_get(mr2, 0, 1) == 0, "R^2 [0][1]=0");
    check(mat_get(mr2, 1, 0) == 0, "R^2 [1][0]=0");
    check(mat_get(mr2, 1, 1) == -1, "R^2 [1][1]=-1");

    /* R^4 = I */
    mr4 = mat_pow(mr, 4);
    check(mat_equal(mr4, id2), "R^4 = I");

    /* det(R) = 0*0 - (-1)*1 = 1 */
    check(mat_det(mr) == 1, "det(R)=1");

    /* det(R^n) = 1 for all n */
    check(mat_det(mr2) == 1, "det(R^2)=1");
    check(mat_det(mr4) == 1, "det(R^4)=1");

    mat_free(mr4);
    mat_free(mr2);
    mat_free(id2);
    mat_free(mr);
}

/* --- Test 26: Nilpotent matrix --- */
static void test_nilpotent(void) {
    /* [[0,1,0],[0,0,1],[0,0,0]] is nilpotent: N^3 = 0 */
    int n[] = {0,1,0, 0,0,1, 0,0,0};
    Matrix *mn, *mn2, *mn3, *zero;
    write_str("[test_nilpotent]\n");

    mn = mat_from_array(3, 3, n);
    zero = mat_create(3, 3);

    mn2 = mat_pow(mn, 2);
    /* N^2 = [[0,0,1],[0,0,0],[0,0,0]] */
    check(mat_get(mn2, 0, 2) == 1, "N^2 [0][2]=1");
    check(mat_get(mn2, 0, 0) == 0 && mat_get(mn2, 1, 1) == 0, "N^2 diag=0");

    mn3 = mat_pow(mn, 3);
    check(mat_equal(mn3, zero), "N^3 = 0");

    check(mat_det(mn) == 0, "det(nilpotent)=0");

    mat_free(mn3);
    mat_free(mn2);
    mat_free(zero);
    mat_free(mn);
}

/* --- Test 27: Mixed operations chain --- */
static void test_mixed_chain(void) {
    /* (A + B)^T = A^T + B^T */
    int a[] = {1,2,3, 4,5,6};
    int b[] = {7,8,9, 10,11,12};
    Matrix *ma, *mb, *apb, *apbt, *at, *bt, *atpbt;
    write_str("[test_mixed_chain]\n");

    ma = mat_from_array(2, 3, a);
    mb = mat_from_array(2, 3, b);
    apb = mat_add(ma, mb);
    apbt = mat_transpose(apb);
    at = mat_transpose(ma);
    bt = mat_transpose(mb);
    atpbt = mat_add(at, bt);
    check(mat_equal(apbt, atpbt), "(A+B)^T = A^T+B^T");

    mat_free(atpbt);
    mat_free(bt);
    mat_free(at);
    mat_free(apbt);
    mat_free(apb);
    mat_free(mb);
    mat_free(ma);

    /* (kA)^T = k(A^T) */
    {
        int v[] = {1,2,3, 4,5,6, 7,8,9};
        Matrix *m = mat_from_array(3, 3, v);
        Matrix *km = mat_scalar_mul(m, 5);
        Matrix *kmt = mat_transpose(km);
        Matrix *mt = mat_transpose(m);
        Matrix *kmt2 = mat_scalar_mul(mt, 5);
        check(mat_equal(kmt, kmt2), "(kA)^T = k(A^T)");
        mat_free(kmt2);
        mat_free(mt);
        mat_free(kmt);
        mat_free(km);
        mat_free(m);
    }
}

/* --- Test 28: Edge cases --- */
static void test_edge_cases(void) {
    Matrix *m, *t, *p;
    write_str("[test_edge_cases]\n");

    /* 1x1 multiply */
    {
        Matrix *a = mat_create(1, 1);
        Matrix *b = mat_create(1, 1);
        Matrix *c;
        mat_set(a, 0, 0, -5);
        mat_set(b, 0, 0, 3);
        c = mat_mul(a, b);
        check(mat_get(c, 0, 0) == -15, "1x1 mul -5*3");
        mat_free(c);
        mat_free(b);
        mat_free(a);
    }

    /* Large values */
    {
        Matrix *a = mat_create(2, 2);
        Matrix *b;
        mat_set(a, 0, 0, 10000);
        mat_set(a, 0, 1, 20000);
        mat_set(a, 1, 0, 30000);
        mat_set(a, 1, 1, 40000);
        b = mat_scalar_mul(a, 2);
        check(mat_get(b, 0, 0) == 20000, "large val scalar");
        check(mat_get(b, 1, 1) == 80000, "large val scalar 2");
        mat_free(b);
        mat_free(a);
    }

    /* Negative values */
    {
        int v[] = {-1, -2, -3, -4};
        Matrix *a = mat_from_array(2, 2, v);
        check(mat_det(a) == -2, "det neg vals");
        check(mat_trace(a) == -5, "trace neg vals");
        mat_free(a);
    }

    /* All zeros */
    {
        Matrix *z = mat_create(3, 3);
        check(mat_det(z) == 0, "det all zeros");
        check(mat_trace(z) == 0, "trace all zeros");
        {
            Matrix *zp = mat_pow(z, 2);
            check(mat_equal(zp, z), "0^2 = 0");
            mat_free(zp);
        }
        mat_free(z);
    }
}

/* --- Test 29: Idempotent matrix --- */
static void test_idempotent(void) {
    /* P = [[1,0],[0,0]] is idempotent: P^2 = P */
    int p[] = {1,0, 0,0};
    Matrix *mp, *mp2;
    write_str("[test_idempotent]\n");

    mp = mat_from_array(2, 2, p);
    mp2 = mat_pow(mp, 2);
    check(mat_equal(mp, mp2), "P^2=P idempotent");
    mat_free(mp2);

    mp2 = mat_pow(mp, 10);
    check(mat_equal(mp, mp2), "P^10=P idempotent");
    mat_free(mp2);
    mat_free(mp);

    /* 3x3 projection */
    {
        int q[] = {1,0,0, 0,1,0, 0,0,0};
        Matrix *mq = mat_from_array(3, 3, q);
        Matrix *mq2 = mat_pow(mq, 2);
        check(mat_equal(mq, mq2), "3x3 projection^2=proj");
        mat_free(mq2);
        mat_free(mq);
    }
}

/* --- Test 30: Comprehensive 5x5 test --- */
static void test_5x5_comprehensive(void) {
    int vals[] = {
        2, 1, 0, 0, 0,
        1, 3, 1, 0, 0,
        0, 1, 4, 1, 0,
        0, 0, 1, 5, 1,
        0, 0, 0, 1, 6
    };
    Matrix *m, *id5, *p, *mt, *mmt;
    int d;
    write_str("[test_5x5_comprehensive]\n");

    m = mat_from_array(5, 5, vals);
    id5 = mat_identity(5);

    /* I*A = A */
    p = mat_mul(id5, m);
    check(mat_equal(p, m), "I*A=A 5x5");
    mat_free(p);

    /* trace */
    check(mat_trace(m) == 2+3+4+5+6, "trace 5x5 tridiag = 20");

    /* symmetric: A^T = A */
    mt = mat_transpose(m);
    check(mat_equal(m, mt), "5x5 tridiag symmetric");
    mat_free(mt);

    /* det */
    d = mat_det(m);
    /* This is a tridiagonal matrix. det can be computed by recurrence:
       d1=2, d2=2*3-1=5, d3=4*5-1*2=18, d4=5*18-1*5=85, d5=6*85-1*18=492 */
    check(d == 492, "det 5x5 tridiag = 492");

    /* A^2 */
    {
        Matrix *a2 = mat_pow(m, 2);
        Matrix *mm = mat_mul(m, m);
        check(mat_equal(a2, mm), "A^2=A*A 5x5");
        mat_free(mm);
        mat_free(a2);
    }

    /* LU decomposition */
    {
        Matrix *L, *U, *prod, *scaled;
        mat_lu_crout(m, &L, &U);
        prod = mat_lu_product(L, U);
        scaled = mat_scalar_mul(m, 1000);
        check(mat_approx_equal(prod, scaled, 10), "LU 5x5 tridiag reconstruct");
        mat_free(scaled);
        mat_free(prod);
        mat_free(U);
        mat_free(L);
    }

    mat_free(id5);
    mat_free(m);
}

/* --- Test 31: Non-square multiplication chains --- */
static void test_nonsquare_chains(void) {
    /* (2x3) * (3x4) = (2x4) then (2x4) * (4x1) = (2x1) */
    int a[] = {1,2,3, 4,5,6};
    int b[] = {1,0,0,1, 0,1,0,1, 0,0,1,1};
    int c[] = {1, 1, 1, 1};
    Matrix *ma, *mb, *mc, *ab, *abc;
    write_str("[test_nonsquare_chains]\n");

    ma = mat_from_array(2, 3, a);
    mb = mat_from_array(3, 4, b);
    mc = mat_from_array(4, 1, c);

    ab = mat_mul(ma, mb);
    check(ab->rows == 2 && ab->cols == 4, "2x3 * 3x4 = 2x4");

    abc = mat_mul(ab, mc);
    check(abc->rows == 2 && abc->cols == 1, "2x4 * 4x1 = 2x1");

    /* Manual check: A*B = [[1,2,3,6],[4,5,6,15]], (A*B)*C = [[12],[30]] */
    check(mat_get(abc, 0, 0) == 12, "chain [0][0]=12");
    check(mat_get(abc, 1, 0) == 30, "chain [1][0]=30");

    mat_free(abc);
    mat_free(ab);
    mat_free(mc);
    mat_free(mb);
    mat_free(ma);
}

/* --- Test 32: Associativity (A*B)*C = A*(B*C) --- */
static void test_associativity(void) {
    int a[] = {1,2, 3,4};
    int b[] = {5,6, 7,8};
    int c[] = {2,0, 1,3};
    Matrix *ma, *mb, *mc, *ab, *abc1, *bc, *abc2;
    write_str("[test_associativity]\n");

    ma = mat_from_array(2, 2, a);
    mb = mat_from_array(2, 2, b);
    mc = mat_from_array(2, 2, c);

    ab = mat_mul(ma, mb);
    abc1 = mat_mul(ab, mc);
    bc = mat_mul(mb, mc);
    abc2 = mat_mul(ma, bc);
    check(mat_equal(abc1, abc2), "(AB)C=A(BC)");

    mat_free(abc2);
    mat_free(bc);
    mat_free(abc1);
    mat_free(ab);
    mat_free(mc);
    mat_free(mb);
    mat_free(ma);

    /* 3x3 */
    {
        int va[] = {2,0,1, 0,3,0, 1,0,2};
        int vb[] = {1,1,0, 0,1,1, 1,0,1};
        int vc[] = {0,1,2, 1,0,1, 2,1,0};
        Matrix *a3 = mat_from_array(3, 3, va);
        Matrix *b3 = mat_from_array(3, 3, vb);
        Matrix *c3 = mat_from_array(3, 3, vc);
        Matrix *ab3 = mat_mul(a3, b3);
        Matrix *abc13 = mat_mul(ab3, c3);
        Matrix *bc3 = mat_mul(b3, c3);
        Matrix *abc23 = mat_mul(a3, bc3);
        check(mat_equal(abc13, abc23), "(AB)C=A(BC) 3x3");
        mat_free(abc23); mat_free(bc3);
        mat_free(abc13); mat_free(ab3);
        mat_free(c3); mat_free(b3); mat_free(a3);
    }
}

/* --- Test 33: Gaussian elimination with pivoting --- */
static void test_gaussian_pivoting(void) {
    /* Matrix requiring row swap */
    int a[] = {0,1, 2,3};
    Matrix *ma, *mg;
    int sign;
    write_str("[test_gaussian_pivoting]\n");

    ma = mat_from_array(2, 2, a);
    mg = mat_gaussian_elim(ma, &sign);
    check(sign == -1, "gauss 2x2 swap sign=-1");
    /* After swap: [[2,3],[0,?]] */
    check(mat_get(mg, 0, 0) == 2, "gauss pivot [0][0]=2");
    check(mat_get(mg, 1, 0) == 0, "gauss pivot [1][0]=0");
    mat_free(mg);
    mat_free(ma);

    /* 3x3 requiring swap */
    {
        int v[] = {0,0,1, 0,2,3, 4,5,6};
        Matrix *m = mat_from_array(3, 3, v);
        Matrix *g = mat_gaussian_elim(m, &sign);
        check(mat_get(g, 0, 0) == 4, "gauss 3x3 pivot [0][0]=4");
        check(mat_get(g, 1, 0) == 0, "gauss 3x3 pivot [1][0]=0");
        check(mat_get(g, 2, 0) == 0, "gauss 3x3 pivot [2][0]=0");
        mat_free(g);
        mat_free(m);
    }
}

/* --- Test 34: Involution matrix (A^2 = I) --- */
static void test_involution(void) {
    /* [[0,1],[1,0]] swap matrix: A^2 = I */
    int s[] = {0,1, 1,0};
    Matrix *ms, *ms2, *id2;
    write_str("[test_involution]\n");

    ms = mat_from_array(2, 2, s);
    id2 = mat_identity(2);
    ms2 = mat_pow(ms, 2);
    check(mat_equal(ms2, id2), "swap^2=I");

    /* det(swap) = -1 */
    check(mat_det(ms) == -1, "det(swap)=-1");

    mat_free(ms2);
    mat_free(id2);
    mat_free(ms);

    /* 3x3 involution */
    {
        int v[] = {1,0,0, 0,0,1, 0,1,0};
        Matrix *m3 = mat_from_array(3, 3, v);
        Matrix *m3sq = mat_pow(m3, 2);
        Matrix *id3 = mat_identity(3);
        check(mat_equal(m3sq, id3), "3x3 involution^2=I");
        mat_free(id3);
        mat_free(m3sq);
        mat_free(m3);
    }
}

/* --- Test 35: Stress multiply accuracy --- */
static void test_stress_multiply(void) {
    /* Build a 4x4 from known values and check multiply chain */
    int a[] = {1,2,3,4, 2,3,4,1, 3,4,1,2, 4,1,2,3};
    int b[] = {1,0,1,0, 0,1,0,1, 1,1,0,0, 0,0,1,1};
    Matrix *ma, *mb, *mab, *mba;
    write_str("[test_stress_multiply]\n");

    ma = mat_from_array(4, 4, a);
    mb = mat_from_array(4, 4, b);
    mab = mat_mul(ma, mb);
    mba = mat_mul(mb, ma);

    /* A*B != B*A in general */
    check(!mat_equal(mab, mba), "AB != BA 4x4");

    /* Verify specific element of A*B */
    /* Row 0 of A = [1,2,3,4], cols of B: */
    /* [0][0] = 1*1+2*0+3*1+4*0 = 4 */
    check(mat_get(mab, 0, 0) == 4, "AB[0][0]=4");
    /* [0][1] = 1*0+2*1+3*1+4*0 = 5 */
    check(mat_get(mab, 0, 1) == 5, "AB[0][1]=5");
    /* [0][2] = 1*1+2*0+3*0+4*1 = 5 */
    check(mat_get(mab, 0, 2) == 5, "AB[0][2]=5");
    /* [0][3] = 1*0+2*1+3*0+4*1 = 6 */
    check(mat_get(mab, 0, 3) == 6, "AB[0][3]=6");

    mat_free(mba);
    mat_free(mab);
    mat_free(mb);
    mat_free(ma);

    /* Chain: A*A*A for circulant */
    {
        int v[] = {0,1, 1,0};
        Matrix *m = mat_from_array(2, 2, v);
        Matrix *m2 = mat_pow(m, 2);
        Matrix *m3 = mat_pow(m, 3);
        Matrix *m2m = mat_mul(m2, m);
        check(mat_equal(m3, m2m), "A^3=A^2*A");
        mat_free(m2m);
        mat_free(m3);
        mat_free(m2);
        mat_free(m);
    }
}

/* --- Test 36: Additional LU tests --- */
static void test_lu_additional(void) {
    write_str("[test_lu_additional]\n");

    /* Diagonal matrix LU */
    {
        int v[] = {3,0,0, 0,5,0, 0,0,7};
        Matrix *m = mat_from_array(3, 3, v);
        Matrix *L, *U, *prod, *scaled;
        mat_lu_crout(m, &L, &U);
        prod = mat_lu_product(L, U);
        scaled = mat_scalar_mul(m, 1000);
        check(mat_approx_equal(prod, scaled, 5), "LU diagonal reconstruct");
        mat_free(scaled);
        mat_free(prod);
        mat_free(U);
        mat_free(L);
        mat_free(m);
    }

    /* Upper triangular LU */
    {
        int v[] = {1,2,3, 0,4,5, 0,0,6};
        Matrix *m = mat_from_array(3, 3, v);
        Matrix *L, *U, *prod, *scaled;
        mat_lu_crout(m, &L, &U);
        prod = mat_lu_product(L, U);
        scaled = mat_scalar_mul(m, 1000);
        check(mat_approx_equal(prod, scaled, 5), "LU upper tri reconstruct");
        mat_free(scaled);
        mat_free(prod);
        mat_free(U);
        mat_free(L);
        mat_free(m);
    }
}

/* --- Test 37: Commutative special cases --- */
static void test_commutative_special(void) {
    write_str("[test_commutative_special]\n");

    /* Diagonal matrices commute */
    {
        int a[] = {2,0,0, 0,3,0, 0,0,5};
        int b[] = {7,0,0, 0,11,0, 0,0,13};
        Matrix *ma = mat_from_array(3, 3, a);
        Matrix *mb = mat_from_array(3, 3, b);
        Matrix *ab = mat_mul(ma, mb);
        Matrix *ba = mat_mul(mb, ma);
        check(mat_equal(ab, ba), "diag commute");
        /* Product of diag = diag of products */
        check(mat_get(ab, 0, 0) == 14, "diag prod [0][0]=14");
        check(mat_get(ab, 1, 1) == 33, "diag prod [1][1]=33");
        check(mat_get(ab, 2, 2) == 65, "diag prod [2][2]=65");
        mat_free(ba);
        mat_free(ab);
        mat_free(mb);
        mat_free(ma);
    }

    /* A and I commute */
    {
        int a[] = {1,2,3, 4,5,6, 7,8,9};
        Matrix *ma = mat_from_array(3, 3, a);
        Matrix *id = mat_identity(3);
        Matrix *ai = mat_mul(ma, id);
        Matrix *ia = mat_mul(id, ma);
        check(mat_equal(ai, ia), "A*I=I*A");
        mat_free(ia);
        mat_free(ai);
        mat_free(id);
        mat_free(ma);
    }
}

/* --- Test 38: Hadamard-like (element-wise) verification --- */
static void test_element_ops(void) {
    /* Not traditional Hadamard product, but element-level checks */
    int a[] = {1,2,3,4,5,6,7,8,9};
    int b[] = {9,8,7,6,5,4,3,2,1};
    Matrix *ma, *mb, *ms, *md;
    int i, ok;
    write_str("[test_element_ops]\n");

    ma = mat_from_array(3, 3, a);
    mb = mat_from_array(3, 3, b);
    ms = mat_add(ma, mb);
    md = mat_sub(ma, mb);

    /* Each element of sum should be 10 */
    ok = 1;
    for (i = 0; i < 9; i++) if (ms->data[i] != 10) ok = 0;
    check(ok, "a[i]+b[i]=10 for all i");

    /* Differences: 1-9=-8, 2-8=-6, ..., 9-1=8 */
    check(md->data[0] == -8, "diff [0]=-8");
    check(md->data[4] == 0, "diff [4]=0");
    check(md->data[8] == 8, "diff [8]=8");

    mat_free(md);
    mat_free(ms);
    mat_free(mb);
    mat_free(ma);
}

/* --- Test 39: Block-diagonal properties --- */
static void test_block_diagonal(void) {
    /* A block diagonal 4x4 = [[A,0],[0,B]] where A,B are 2x2 */
    /* det = det(A)*det(B) */
    int bd[] = {
        2, 3, 0, 0,
        1, 4, 0, 0,
        0, 0, 5, 6,
        0, 0, 7, 8
    };
    Matrix *m;
    int d;
    write_str("[test_block_diagonal]\n");

    m = mat_from_array(4, 4, bd);
    d = mat_det(m);
    /* det(A)=2*4-3*1=5, det(B)=5*8-6*7=-2, product=-10 */
    check(d == -10, "block diag det = -10");
    check(mat_trace(m) == 2+4+5+8, "block diag trace = 19");
    mat_free(m);
}

/* --- Test 40: Power of diagonal matrix --- */
static void test_diagonal_power(void) {
    int v[] = {2,0,0,0, 0,3,0,0, 0,0,-1,0, 0,0,0,4};
    Matrix *m, *p;
    write_str("[test_diagonal_power]\n");

    m = mat_from_array(4, 4, v);

    /* D^3 = diag(8,27,-1,64) */
    p = mat_pow(m, 3);
    check(mat_get(p, 0, 0) == 8, "diag^3 [0]=8");
    check(mat_get(p, 1, 1) == 27, "diag^3 [1]=27");
    check(mat_get(p, 2, 2) == -1, "diag^3 [2]=-1");
    check(mat_get(p, 3, 3) == 64, "diag^3 [3]=64");
    mat_free(p);

    /* D^0 = I */
    p = mat_pow(m, 0);
    {
        Matrix *id4 = mat_identity(4);
        check(mat_equal(p, id4), "diag^0=I");
        mat_free(id4);
    }
    mat_free(p);

    mat_free(m);
}

/* =========================================================================
 * MAIN
 * ========================================================================= */

int main(void) {
    init_io();
    g_errs = 0;

    write_str("=== victim_matrix.c test suite ===\n");

    test_create_free();
    test_identity();
    test_add_sub();
    test_scalar_mul();
    test_multiply();
    test_identity_multiply();
    test_transpose();
    test_transpose_product();
    test_determinant();
    test_trace();
    test_strassen();
    test_lu();
    test_power();
    test_gaussian();
    test_equality_copy();
    test_submatrix();
    test_large_matrix();
    test_distributive();
    test_det_product();
    test_det_transpose();
    test_trace_properties();
    test_power_assoc();
    test_scalar_distribute();
    test_det_additional();
    test_rotation_power();
    test_nilpotent();
    test_mixed_chain();
    test_edge_cases();
    test_idempotent();
    test_5x5_comprehensive();
    test_nonsquare_chains();
    test_associativity();
    test_gaussian_pivoting();
    test_involution();
    test_stress_multiply();
    test_lu_additional();
    test_commutative_special();
    test_element_ops();
    test_block_diagonal();
    test_diagonal_power();

    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
