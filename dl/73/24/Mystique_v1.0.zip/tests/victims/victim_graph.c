/*
 * victim_graph.c - Graph algorithms stress test (Windows x86-32, MSVC)
 * Build: cl /nologo /O1 victim_graph.c /Fe:victim_graph.exe /link /SUBSYSTEM:CONSOLE kernel32.lib
 *
 * Adjacency matrix representation, max 32 vertices.
 * All algorithms fully implemented with deterministic tests.
 */

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
static HANDLE g_stdout;
static void init_io(void) { g_stdout = GetStdHandle(STD_OUTPUT_HANDLE); }
static void write_str(const char* s) { DWORD w; WriteFile(g_stdout, s, (DWORD)strlen(s), &w, NULL); }
#else
static void init_io(void) { }
static void write_str(const char* s) { write(1, s, strlen(s)); }
#endif
static void write_int(int n) {
    char buf[20]; int i, neg=0;
    if (n==0) { write_str("0"); return; }
    if (n<0) { neg=1; n=-n; } i=19; buf[i]=0;
    while(n>0) { i--; buf[i]=(char)((n%10)+48); n/=10; }
    if (neg) { i--; buf[i]='-'; } write_str(&buf[i]);
}
static int g_errs;
static void check(int cond, const char* name) { if (!cond) { write_str("  FAIL: "); write_str(name); write_str("\n"); g_errs++; } }

/* ========================================================================
 * Graph data structures
 * ======================================================================== */

#define MAX_V 32
#define INF 999999999

typedef struct {
    int n;                        /* number of vertices */
    int adj[MAX_V][MAX_V];        /* adjacency matrix (weights, 0 = no edge) */
    int directed;                 /* 1 = directed, 0 = undirected */
} Graph;

static void graph_init(Graph* g, int n, int directed) {
    int i, j;
    g->n = n;
    g->directed = directed;
    for (i = 0; i < MAX_V; i++)
        for (j = 0; j < MAX_V; j++)
            g->adj[i][j] = 0;
}

static void graph_add_edge(Graph* g, int u, int v, int w) {
    g->adj[u][v] = w;
    if (!g->directed)
        g->adj[v][u] = w;
}

static void graph_add_directed_edge(Graph* g, int u, int v, int w) {
    g->adj[u][v] = w;
}

static void graph_free(Graph* g) {
    /* Stack-allocated, nothing to free. Zero it out for safety. */
    memset(g, 0, sizeof(Graph));
}

/* ========================================================================
 * BFS - Breadth-First Search
 * Returns distances from source in dist[]. -1 = unreachable.
 * ======================================================================== */

static void bfs(Graph* g, int src, int dist[MAX_V], int parent[MAX_V]) {
    int queue[MAX_V];
    int front = 0, back = 0;
    int visited[MAX_V];
    int i, u, v;

    for (i = 0; i < g->n; i++) {
        dist[i] = -1;
        parent[i] = -1;
        visited[i] = 0;
    }

    dist[src] = 0;
    visited[src] = 1;
    queue[back++] = src;

    while (front < back) {
        u = queue[front++];
        for (v = 0; v < g->n; v++) {
            if (g->adj[u][v] != 0 && !visited[v]) {
                visited[v] = 1;
                dist[v] = dist[u] + 1;
                parent[v] = u;
                queue[back++] = v;
            }
        }
    }
}

/* ========================================================================
 * DFS - Depth-First Search with timestamps
 * ======================================================================== */

static int dfs_time;

static void dfs_visit(Graph* g, int u, int visited[MAX_V],
                       int discover[MAX_V], int finish[MAX_V],
                       int parent[MAX_V]) {
    int v;
    visited[u] = 1;
    discover[u] = dfs_time++;
    for (v = 0; v < g->n; v++) {
        if (g->adj[u][v] != 0 && !visited[v]) {
            parent[v] = u;
            dfs_visit(g, v, visited, discover, finish, parent);
        }
    }
    finish[u] = dfs_time++;
}

static void dfs(Graph* g, int discover[MAX_V], int finish[MAX_V],
                int parent[MAX_V]) {
    int visited[MAX_V];
    int i;

    dfs_time = 0;
    for (i = 0; i < g->n; i++) {
        visited[i] = 0;
        discover[i] = -1;
        finish[i] = -1;
        parent[i] = -1;
    }

    for (i = 0; i < g->n; i++) {
        if (!visited[i])
            dfs_visit(g, i, visited, discover, finish, parent);
    }
}

/* ========================================================================
 * Topological Sort - Kahn's Algorithm
 * Returns number of vertices in sorted order. If < g->n, cycle exists.
 * ======================================================================== */

static int topological_sort(Graph* g, int result[MAX_V]) {
    int in_degree[MAX_V];
    int queue[MAX_V];
    int front = 0, back = 0;
    int count = 0;
    int i, j, u, v;

    for (i = 0; i < g->n; i++)
        in_degree[i] = 0;

    for (i = 0; i < g->n; i++)
        for (j = 0; j < g->n; j++)
            if (g->adj[i][j] != 0)
                in_degree[j]++;

    for (i = 0; i < g->n; i++)
        if (in_degree[i] == 0)
            queue[back++] = i;

    while (front < back) {
        u = queue[front++];
        result[count++] = u;
        for (v = 0; v < g->n; v++) {
            if (g->adj[u][v] != 0) {
                in_degree[v]--;
                if (in_degree[v] == 0)
                    queue[back++] = v;
            }
        }
    }

    return count;
}

/* ========================================================================
 * Dijkstra's Shortest Path (array-based min extraction)
 * ======================================================================== */

static void dijkstra(Graph* g, int src, int dist[MAX_V], int parent[MAX_V]) {
    int visited[MAX_V];
    int i, u, v, min_d, min_u;

    for (i = 0; i < g->n; i++) {
        dist[i] = INF;
        parent[i] = -1;
        visited[i] = 0;
    }
    dist[src] = 0;

    for (i = 0; i < g->n; i++) {
        /* Find unvisited vertex with minimum distance */
        min_d = INF + 1;
        min_u = -1;
        for (u = 0; u < g->n; u++) {
            if (!visited[u] && dist[u] < min_d) {
                min_d = dist[u];
                min_u = u;
            }
        }
        if (min_u == -1) break;

        visited[min_u] = 1;
        for (v = 0; v < g->n; v++) {
            if (g->adj[min_u][v] != 0 && !visited[v]) {
                int nd = dist[min_u] + g->adj[min_u][v];
                if (nd < dist[v]) {
                    dist[v] = nd;
                    parent[v] = min_u;
                }
            }
        }
    }
}

/* ========================================================================
 * Floyd-Warshall All-Pairs Shortest Path
 * ======================================================================== */

static void floyd_warshall(Graph* g, int dist[MAX_V][MAX_V]) {
    int i, j, k;

    for (i = 0; i < g->n; i++) {
        for (j = 0; j < g->n; j++) {
            if (i == j)
                dist[i][j] = 0;
            else if (g->adj[i][j] != 0)
                dist[i][j] = g->adj[i][j];
            else
                dist[i][j] = INF;
        }
    }

    for (k = 0; k < g->n; k++) {
        for (i = 0; i < g->n; i++) {
            for (j = 0; j < g->n; j++) {
                if (dist[i][k] != INF && dist[k][j] != INF) {
                    int through_k = dist[i][k] + dist[k][j];
                    if (through_k < dist[i][j])
                        dist[i][j] = through_k;
                }
            }
        }
    }
}

/* ========================================================================
 * Bellman-Ford Single-Source Shortest Path
 * Returns 1 on success, 0 if negative cycle detected.
 * ======================================================================== */

static int bellman_ford(Graph* g, int src, int dist[MAX_V], int parent[MAX_V]) {
    int i, u, v, iter;
    int changed;

    for (i = 0; i < g->n; i++) {
        dist[i] = INF;
        parent[i] = -1;
    }
    dist[src] = 0;

    /* Relax edges n-1 times */
    for (iter = 0; iter < g->n - 1; iter++) {
        changed = 0;
        for (u = 0; u < g->n; u++) {
            if (dist[u] == INF) continue;
            for (v = 0; v < g->n; v++) {
                if (g->adj[u][v] != 0) {
                    int nd = dist[u] + g->adj[u][v];
                    if (nd < dist[v]) {
                        dist[v] = nd;
                        parent[v] = u;
                        changed = 1;
                    }
                }
            }
        }
        if (!changed) break;
    }

    /* Check for negative cycles */
    for (u = 0; u < g->n; u++) {
        if (dist[u] == INF) continue;
        for (v = 0; v < g->n; v++) {
            if (g->adj[u][v] != 0) {
                if (dist[u] + g->adj[u][v] < dist[v])
                    return 0; /* negative cycle */
            }
        }
    }

    return 1;
}

/* ========================================================================
 * Cycle Detection (directed graph, DFS coloring)
 * Colors: 0=white, 1=gray, 2=black
 * ======================================================================== */

static int cycle_dfs(Graph* g, int u, int color[MAX_V]) {
    int v;
    color[u] = 1; /* gray */
    for (v = 0; v < g->n; v++) {
        if (g->adj[u][v] != 0) {
            if (color[v] == 1) return 1; /* back edge = cycle */
            if (color[v] == 0 && cycle_dfs(g, v, color)) return 1;
        }
    }
    color[u] = 2; /* black */
    return 0;
}

static int has_cycle(Graph* g) {
    int color[MAX_V];
    int i;
    for (i = 0; i < g->n; i++) color[i] = 0;
    for (i = 0; i < g->n; i++) {
        if (color[i] == 0 && cycle_dfs(g, i, color))
            return 1;
    }
    return 0;
}

/* ========================================================================
 * Connected Components (undirected, DFS)
 * Returns number of components. comp[v] = component id for each vertex.
 * ======================================================================== */

static void cc_dfs(Graph* g, int u, int comp[MAX_V], int comp_id) {
    int v;
    comp[u] = comp_id;
    for (v = 0; v < g->n; v++) {
        if (g->adj[u][v] != 0 && comp[v] == -1)
            cc_dfs(g, v, comp, comp_id);
    }
}

static int connected_components(Graph* g, int comp[MAX_V]) {
    int i;
    int num_comp = 0;
    for (i = 0; i < g->n; i++) comp[i] = -1;
    for (i = 0; i < g->n; i++) {
        if (comp[i] == -1) {
            cc_dfs(g, i, comp, num_comp);
            num_comp++;
        }
    }
    return num_comp;
}

/* ========================================================================
 * Minimum Spanning Tree - Prim's Algorithm
 * Returns total weight. mst_parent[v] = parent in MST (-1 for root).
 * ======================================================================== */

static int prim_mst(Graph* g, int mst_parent[MAX_V]) {
    int key[MAX_V];
    int in_mst[MAX_V];
    int i, u, v, min_key, min_u;
    int total = 0;

    for (i = 0; i < g->n; i++) {
        key[i] = INF;
        in_mst[i] = 0;
        mst_parent[i] = -1;
    }
    key[0] = 0;

    for (i = 0; i < g->n; i++) {
        min_key = INF + 1;
        min_u = -1;
        for (u = 0; u < g->n; u++) {
            if (!in_mst[u] && key[u] < min_key) {
                min_key = key[u];
                min_u = u;
            }
        }
        if (min_u == -1) break;

        in_mst[min_u] = 1;
        total += key[min_u];

        for (v = 0; v < g->n; v++) {
            if (g->adj[min_u][v] != 0 && !in_mst[v] && g->adj[min_u][v] < key[v]) {
                key[v] = g->adj[min_u][v];
                mst_parent[v] = min_u;
            }
        }
    }

    return total;
}

/* ========================================================================
 * In-degree / Out-degree computation
 * ======================================================================== */

static void compute_in_degree(Graph* g, int in_deg[MAX_V]) {
    int i, j;
    for (i = 0; i < g->n; i++) in_deg[i] = 0;
    for (i = 0; i < g->n; i++)
        for (j = 0; j < g->n; j++)
            if (g->adj[i][j] != 0)
                in_deg[j]++;
}

static void compute_out_degree(Graph* g, int out_deg[MAX_V]) {
    int i, j;
    for (i = 0; i < g->n; i++) out_deg[i] = 0;
    for (i = 0; i < g->n; i++)
        for (j = 0; j < g->n; j++)
            if (g->adj[i][j] != 0)
                out_deg[i]++;
}

/* ========================================================================
 * Graph Transpose (reverse all edges)
 * ======================================================================== */

static void graph_transpose(Graph* src, Graph* dst) {
    int i, j;
    graph_init(dst, src->n, src->directed);
    for (i = 0; i < src->n; i++)
        for (j = 0; j < src->n; j++)
            dst->adj[j][i] = src->adj[i][j];
}

/* ========================================================================
 * Utility: verify topological ordering is valid
 * ======================================================================== */

static int verify_topo_order(Graph* g, int order[MAX_V], int count) {
    int pos[MAX_V]; /* pos[v] = position in ordering */
    int i, u, v;
    if (count != g->n) return 0;
    for (i = 0; i < count; i++) pos[order[i]] = i;
    for (u = 0; u < g->n; u++)
        for (v = 0; v < g->n; v++)
            if (g->adj[u][v] != 0 && pos[u] >= pos[v])
                return 0;
    return 1;
}

/* ========================================================================
 * Utility: reconstruct path from parent array
 * ======================================================================== */

static int reconstruct_path(int parent[MAX_V], int src, int dst, int path[MAX_V]) {
    int len = 0;
    int v = dst;
    int i, j, tmp;
    if (parent[dst] == -1 && src != dst) return 0;
    while (v != -1) {
        path[len++] = v;
        if (v == src) break;
        v = parent[v];
        if (len > MAX_V) return 0; /* safety */
    }
    /* Reverse */
    for (i = 0, j = len - 1; i < j; i++, j--) {
        tmp = path[i]; path[i] = path[j]; path[j] = tmp;
    }
    return len;
}

/* ========================================================================
 * Utility: count edges
 * ======================================================================== */

static int count_edges(Graph* g) {
    int i, j, count = 0;
    for (i = 0; i < g->n; i++)
        for (j = 0; j < g->n; j++)
            if (g->adj[i][j] != 0) count++;
    if (!g->directed) count /= 2;
    return count;
}

/* ========================================================================
 * Utility: check if graph is connected (undirected)
 * ======================================================================== */

static int is_connected(Graph* g) {
    int comp[MAX_V];
    return connected_components(g, comp) == 1;
}

/* ========================================================================
 * Utility: compute sum of all edge weights
 * ======================================================================== */

static int sum_edge_weights(Graph* g) {
    int i, j, s = 0;
    for (i = 0; i < g->n; i++)
        for (j = 0; j < g->n; j++)
            s += g->adj[i][j];
    if (!g->directed) s /= 2;
    return s;
}

/* ========================================================================
 * Test helpers: graph builders
 * ======================================================================== */

/* Chain: 0->1->2->...->n-1, weight=1 */
static void build_chain(Graph* g, int n, int directed) {
    int i;
    graph_init(g, n, directed);
    for (i = 0; i < n - 1; i++)
        graph_add_edge(g, i, i + 1, 1);
}

/* Complete graph K_n, weight = u*n + v + 1 (distinct) for undirected */
static void build_complete(Graph* g, int n, int directed) {
    int i, j;
    graph_init(g, n, directed);
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++) {
            int w = i * n + j + 1;
            if (directed) {
                graph_add_directed_edge(g, i, j, w);
                graph_add_directed_edge(g, j, i, w + n * n);
            } else {
                graph_add_edge(g, i, j, w);
            }
        }
}

/*
 * Tree:
 *       0
 *      / \
 *     1   2
 *    / \
 *   3   4
 */
static void build_tree(Graph* g) {
    graph_init(g, 5, 0);
    graph_add_edge(g, 0, 1, 2);
    graph_add_edge(g, 0, 2, 3);
    graph_add_edge(g, 1, 3, 1);
    graph_add_edge(g, 1, 4, 4);
}

/*
 * DAG:
 *   0 -> 1 -> 3
 *   0 -> 2 -> 3
 *   1 -> 2
 *   3 -> 4
 */
static void build_dag(Graph* g) {
    graph_init(g, 5, 1);
    graph_add_directed_edge(g, 0, 1, 1);
    graph_add_directed_edge(g, 0, 2, 2);
    graph_add_directed_edge(g, 1, 2, 3);
    graph_add_directed_edge(g, 1, 3, 4);
    graph_add_directed_edge(g, 2, 3, 5);
    graph_add_directed_edge(g, 3, 4, 6);
}

/*
 * Graph with negative edges (no negative cycles):
 *   0 --(5)--> 1 --(-2)--> 2
 *   0 --(2)--> 2
 *   1 --(1)--> 3
 *   2 --(3)--> 3
 *   Shortest 0->3: 0->1->3 = 6 or 0->2->3 = 5 or 0->1->2->3 = 5-2+3 = 6
 *   Actually: 0->1->(-2)->2->(3)->3 = 5+(-2)+3 = 6
 *   0->2->3 = 2+3 = 5 <-- shortest
 */
static void build_negative_edges(Graph* g) {
    graph_init(g, 4, 1);
    graph_add_directed_edge(g, 0, 1, 5);
    graph_add_directed_edge(g, 0, 2, 2);
    graph_add_directed_edge(g, 1, 2, -2);
    graph_add_directed_edge(g, 1, 3, 1);
    graph_add_directed_edge(g, 2, 3, 3);
}

/* Disconnected: 3 components {0,1}, {2,3}, {4} */
static void build_disconnected(Graph* g) {
    graph_init(g, 5, 0);
    graph_add_edge(g, 0, 1, 1);
    graph_add_edge(g, 2, 3, 2);
}

/* Single vertex */
static void build_single(Graph* g) {
    graph_init(g, 1, 0);
}

/*
 * Weighted directed graph for Dijkstra:
 *   0 --(10)--> 1
 *   0 --(3)---> 2
 *   1 --(1)---> 2
 *   2 --(4)---> 1
 *   2 --(2)---> 3
 *   1 --(5)---> 3
 *   3 --(7)---> 4
 *   2 --(8)---> 4
 *
 * Shortest from 0:
 *   0->0 = 0
 *   0->2 = 3
 *   0->2->1 = 3+4 = 7
 *   0->2->3 = 3+2 = 5
 *   0->2->3->4 = 3+2+7 = 12 or 0->2->4 = 3+8 = 11
 */
static void build_dijkstra_graph(Graph* g) {
    graph_init(g, 5, 1);
    graph_add_directed_edge(g, 0, 1, 10);
    graph_add_directed_edge(g, 0, 2, 3);
    graph_add_directed_edge(g, 1, 2, 1);
    graph_add_directed_edge(g, 2, 1, 4);
    graph_add_directed_edge(g, 2, 3, 2);
    graph_add_directed_edge(g, 1, 3, 5);
    graph_add_directed_edge(g, 3, 4, 7);
    graph_add_directed_edge(g, 2, 4, 8);
}

/* Graph with a cycle: 0->1->2->0 */
static void build_cycle_graph(Graph* g) {
    graph_init(g, 3, 1);
    graph_add_directed_edge(g, 0, 1, 1);
    graph_add_directed_edge(g, 1, 2, 1);
    graph_add_directed_edge(g, 2, 0, 1);
}

/* Negative cycle: 0->1(1), 1->2(-3), 2->0(1), total = -1 */
static void build_negative_cycle(Graph* g) {
    graph_init(g, 3, 1);
    graph_add_directed_edge(g, 0, 1, 1);
    graph_add_directed_edge(g, 1, 2, -3);
    graph_add_directed_edge(g, 2, 0, 1);
}

/*
 * Larger weighted graph (8 nodes) for Floyd-Warshall:
 *   Various edges with known shortest paths.
 */
static void build_fw_graph(Graph* g) {
    graph_init(g, 8, 1);
    graph_add_directed_edge(g, 0, 1, 4);
    graph_add_directed_edge(g, 0, 2, 1);
    graph_add_directed_edge(g, 1, 3, 1);
    graph_add_directed_edge(g, 2, 1, 2);
    graph_add_directed_edge(g, 2, 3, 5);
    graph_add_directed_edge(g, 3, 4, 3);
    graph_add_directed_edge(g, 4, 5, 1);
    graph_add_directed_edge(g, 5, 6, 2);
    graph_add_directed_edge(g, 6, 7, 1);
    graph_add_directed_edge(g, 3, 6, 8);
    graph_add_directed_edge(g, 0, 7, 20);
    graph_add_directed_edge(g, 1, 5, 7);
    graph_add_directed_edge(g, 2, 4, 10);
}

/*
 * Diamond DAG:
 *   0->1, 0->2, 1->3, 2->3
 */
static void build_diamond_dag(Graph* g) {
    graph_init(g, 4, 1);
    graph_add_directed_edge(g, 0, 1, 1);
    graph_add_directed_edge(g, 0, 2, 1);
    graph_add_directed_edge(g, 1, 3, 1);
    graph_add_directed_edge(g, 2, 3, 1);
}

/*
 * Larger tree (10 nodes) for MST testing:
 *       0
 *      /|\
 *     1  2  3
 *    /|  |
 *   4  5 6
 *   |    |
 *   7    8
 *         \
 *          9
 */
static void build_large_tree(Graph* g) {
    graph_init(g, 10, 0);
    graph_add_edge(g, 0, 1, 3);
    graph_add_edge(g, 0, 2, 5);
    graph_add_edge(g, 0, 3, 7);
    graph_add_edge(g, 1, 4, 2);
    graph_add_edge(g, 1, 5, 4);
    graph_add_edge(g, 2, 6, 1);
    graph_add_edge(g, 4, 7, 6);
    graph_add_edge(g, 6, 8, 3);
    graph_add_edge(g, 8, 9, 2);
}

/*
 * MST test graph (undirected, with redundant edges):
 * 6 vertices, several edges, known MST weight.
 *   0--1(1), 0--2(5), 1--2(3), 1--3(6), 2--3(2), 2--4(4), 3--4(7), 3--5(8), 4--5(9)
 *   MST edges: 0-1(1), 2-3(2), 1-2(3), 2-4(4), 3-5(8) = 18
 */
static void build_mst_graph(Graph* g) {
    graph_init(g, 6, 0);
    graph_add_edge(g, 0, 1, 1);
    graph_add_edge(g, 0, 2, 5);
    graph_add_edge(g, 1, 2, 3);
    graph_add_edge(g, 1, 3, 6);
    graph_add_edge(g, 2, 3, 2);
    graph_add_edge(g, 2, 4, 4);
    graph_add_edge(g, 3, 4, 7);
    graph_add_edge(g, 3, 5, 8);
    graph_add_edge(g, 4, 5, 9);
}

/* ========================================================================
 * TEST SECTIONS
 * ======================================================================== */

static void test_chain_bfs(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int path[MAX_V], plen;

    write_str("[chain_bfs]\n");
    build_chain(&g, 5, 0);

    check(count_edges(&g) == 4, "chain_5_edges");
    check(g.n == 5, "chain_5_vertices");

    bfs(&g, 0, dist, parent);
    check(dist[0] == 0, "bfs_chain_d0");
    check(dist[1] == 1, "bfs_chain_d1");
    check(dist[2] == 2, "bfs_chain_d2");
    check(dist[3] == 3, "bfs_chain_d3");
    check(dist[4] == 4, "bfs_chain_d4");

    plen = reconstruct_path(parent, 0, 4, path);
    check(plen == 5, "bfs_chain_path_len");
    check(path[0] == 0 && path[1] == 1 && path[2] == 2
       && path[3] == 3 && path[4] == 4, "bfs_chain_path");

    /* BFS from middle */
    bfs(&g, 2, dist, parent);
    check(dist[0] == 2, "bfs_chain_mid_d0");
    check(dist[2] == 0, "bfs_chain_mid_d2");
    check(dist[4] == 2, "bfs_chain_mid_d4");

    graph_free(&g);
}

static void test_chain_dfs(void) {
    Graph g;
    int discover[MAX_V], finish[MAX_V], parent[MAX_V];

    write_str("[chain_dfs]\n");
    build_chain(&g, 5, 1);

    dfs(&g, discover, finish, parent);
    /* In directed chain 0->1->2->3->4, DFS from 0 should reach all */
    check(discover[0] < discover[4], "dfs_chain_order");
    check(finish[4] < finish[0], "dfs_chain_finish_order");
    check(parent[1] == 0, "dfs_chain_parent_1");
    check(parent[2] == 1, "dfs_chain_parent_2");

    /* Verify timestamps are all distinct */
    {
        int ts[10], i, j, ok = 1;
        for (i = 0; i < 5; i++) { ts[2*i] = discover[i]; ts[2*i+1] = finish[i]; }
        for (i = 0; i < 10; i++)
            for (j = i+1; j < 10; j++)
                if (ts[i] == ts[j]) ok = 0;
        check(ok, "dfs_chain_distinct_timestamps");
    }

    graph_free(&g);
}

static void test_dag_topo(void) {
    Graph g;
    int result[MAX_V];
    int count;

    write_str("[dag_topo]\n");
    build_dag(&g);

    count = topological_sort(&g, result);
    check(count == 5, "topo_dag_count");
    check(verify_topo_order(&g, result, count), "topo_dag_valid");

    /* DAG should have no cycle */
    check(!has_cycle(&g), "dag_no_cycle");

    graph_free(&g);
}

static void test_diamond_topo(void) {
    Graph g;
    int result[MAX_V];
    int count;

    write_str("[diamond_topo]\n");
    build_diamond_dag(&g);

    count = topological_sort(&g, result);
    check(count == 4, "topo_diamond_count");
    check(verify_topo_order(&g, result, count), "topo_diamond_valid");
    check(result[0] == 0, "topo_diamond_first");
    check(result[3] == 3, "topo_diamond_last");

    graph_free(&g);
}

static void test_cycle_detection(void) {
    Graph g;

    write_str("[cycle_detection]\n");

    /* Cycle graph */
    build_cycle_graph(&g);
    check(has_cycle(&g), "cycle_detect_yes");
    graph_free(&g);

    /* DAG - no cycle */
    build_dag(&g);
    check(!has_cycle(&g), "cycle_detect_dag_no");
    graph_free(&g);

    /* Single vertex - no cycle */
    build_single(&g);
    check(!has_cycle(&g), "cycle_detect_single_no");
    graph_free(&g);

    /* Chain directed - no cycle */
    build_chain(&g, 5, 1);
    check(!has_cycle(&g), "cycle_detect_chain_no");
    graph_free(&g);

    /* K5 directed - has cycle (0->1->0 via edges) */
    build_complete(&g, 5, 1);
    check(has_cycle(&g), "cycle_detect_k5_yes");
    graph_free(&g);
}

static void test_topo_cycle(void) {
    Graph g;
    int result[MAX_V];
    int count;

    write_str("[topo_cycle]\n");
    build_cycle_graph(&g);

    /* Kahn's should return fewer than n vertices when cycle exists */
    count = topological_sort(&g, result);
    check(count < g.n, "topo_cycle_incomplete");

    graph_free(&g);
}

static void test_dijkstra_simple(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[dijkstra_simple]\n");
    build_dijkstra_graph(&g);

    dijkstra(&g, 0, dist, parent);
    check(dist[0] == 0, "dijk_d0");
    check(dist[1] == 7, "dijk_d1");   /* 0->2->1 = 3+4=7 */
    check(dist[2] == 3, "dijk_d2");   /* 0->2 = 3 */
    check(dist[3] == 5, "dijk_d3");   /* 0->2->3 = 3+2=5 */
    check(dist[4] == 11, "dijk_d4");  /* 0->2->4 = 3+8=11 */

    /* Verify path to 3 */
    {
        int path[MAX_V], plen;
        plen = reconstruct_path(parent, 0, 3, path);
        check(plen == 3, "dijk_path_len");
        check(path[0] == 0 && path[1] == 2 && path[2] == 3, "dijk_path_023");
    }

    graph_free(&g);
}

static void test_dijkstra_chain(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[dijkstra_chain]\n");
    build_chain(&g, 5, 1);

    dijkstra(&g, 0, dist, parent);
    check(dist[0] == 0, "dijk_chain_d0");
    check(dist[1] == 1, "dijk_chain_d1");
    check(dist[2] == 2, "dijk_chain_d2");
    check(dist[3] == 3, "dijk_chain_d3");
    check(dist[4] == 4, "dijk_chain_d4");

    /* From node 2 */
    dijkstra(&g, 2, dist, parent);
    check(dist[0] == INF, "dijk_chain_rev_d0");
    check(dist[3] == 1, "dijk_chain_rev_d3");
    check(dist[4] == 2, "dijk_chain_rev_d4");

    graph_free(&g);
}

static void test_floyd_warshall_simple(void) {
    Graph g;
    int dist[MAX_V][MAX_V];

    write_str("[floyd_warshall_simple]\n");
    build_dijkstra_graph(&g);

    floyd_warshall(&g, dist);
    check(dist[0][0] == 0, "fw_d00");
    check(dist[0][1] == 7, "fw_d01");
    check(dist[0][2] == 3, "fw_d02");
    check(dist[0][3] == 5, "fw_d03");
    check(dist[0][4] == 11, "fw_d04");

    /* Other pairs */
    check(dist[1][2] == 1, "fw_d12");     /* 1->2 */
    check(dist[1][3] == 3, "fw_d13");     /* 1->2->3 = 1+2=3 */
    check(dist[2][1] == 4, "fw_d21");     /* 2->1 */
    check(dist[3][4] == 7, "fw_d34");     /* 3->4 direct, weight 7 */
    check(dist[4][0] == INF, "fw_d40");   /* no path */

    graph_free(&g);
}

static void test_floyd_warshall_large(void) {
    Graph g;
    int dist[MAX_V][MAX_V];

    write_str("[floyd_warshall_large]\n");
    build_fw_graph(&g);

    floyd_warshall(&g, dist);
    /* 0->1: min(4, 0->2->1=1+2=3) = 3 */
    check(dist[0][1] == 3, "fw8_d01");
    /* 0->3: 0->2->1->3 = 1+2+1=4 */
    check(dist[0][3] == 4, "fw8_d03");
    /* 0->4: 0->2->1->3->4 = 1+2+1+3=7 */
    check(dist[0][4] == 7, "fw8_d04");
    /* 0->5: 0->2->1->3->4->5 = 1+2+1+3+1=8 */
    check(dist[0][5] == 8, "fw8_d05");
    /* 0->6: via 5 = 8+2=10, or 0->2->1->3->6 = 4+8=12. So 10. */
    check(dist[0][6] == 10, "fw8_d06");
    /* 0->7: via 6 = 10+1=11, or direct 20. So 11. */
    check(dist[0][7] == 11, "fw8_d07");

    graph_free(&g);
}

static void test_bellman_ford_simple(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int ok;

    write_str("[bellman_ford_simple]\n");
    build_negative_edges(&g);

    ok = bellman_ford(&g, 0, dist, parent);
    check(ok == 1, "bf_no_neg_cycle");
    check(dist[0] == 0, "bf_d0");
    check(dist[1] == 5, "bf_d1");
    /* 0->1->2 = 5+(-2)=3, but 0->2=2 is shorter */
    check(dist[2] == 2, "bf_d2");
    /* 0->2->3 = 2+3=5, 0->1->3=5+1=6 */
    check(dist[3] == 5, "bf_d3");

    graph_free(&g);
}

static void test_bellman_ford_negative_cycle(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int ok;

    write_str("[bellman_ford_neg_cycle]\n");
    build_negative_cycle(&g);

    ok = bellman_ford(&g, 0, dist, parent);
    check(ok == 0, "bf_neg_cycle_detected");

    graph_free(&g);
}

static void test_bellman_ford_chain(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int ok;

    write_str("[bellman_ford_chain]\n");
    build_chain(&g, 5, 1);

    ok = bellman_ford(&g, 0, dist, parent);
    check(ok == 1, "bf_chain_ok");
    check(dist[0] == 0, "bf_chain_d0");
    check(dist[4] == 4, "bf_chain_d4");

    graph_free(&g);
}

static void test_connected_components(void) {
    Graph g;
    int comp[MAX_V];
    int nc;

    write_str("[connected_components]\n");

    /* Disconnected: 3 components */
    build_disconnected(&g);
    nc = connected_components(&g, comp);
    check(nc == 3, "cc_disconn_3");
    check(comp[0] == comp[1], "cc_01_same");
    check(comp[2] == comp[3], "cc_23_same");
    check(comp[0] != comp[2], "cc_01_ne_23");
    check(comp[0] != comp[4], "cc_01_ne_4");
    check(comp[2] != comp[4], "cc_23_ne_4");
    graph_free(&g);

    /* Chain undirected: 1 component */
    build_chain(&g, 5, 0);
    nc = connected_components(&g, comp);
    check(nc == 1, "cc_chain_1");
    graph_free(&g);

    /* Single: 1 component */
    build_single(&g);
    nc = connected_components(&g, comp);
    check(nc == 1, "cc_single_1");
    graph_free(&g);

    /* Complete K5: 1 component */
    build_complete(&g, 5, 0);
    nc = connected_components(&g, comp);
    check(nc == 1, "cc_k5_1");
    graph_free(&g);

    /* Tree: 1 component */
    build_tree(&g);
    nc = connected_components(&g, comp);
    check(nc == 1, "cc_tree_1");
    graph_free(&g);
}

static void test_prim_mst(void) {
    Graph g;
    int mst_parent[MAX_V];
    int total;

    write_str("[prim_mst]\n");

    /* MST test graph, expected weight = 18 */
    build_mst_graph(&g);
    total = prim_mst(&g, mst_parent);
    check(total == 18, "prim_mst_total_18");
    check(mst_parent[0] == -1, "prim_mst_root");
    graph_free(&g);

    /* Tree: MST = the tree itself, weight = 2+3+1+4 = 10 */
    build_tree(&g);
    total = prim_mst(&g, mst_parent);
    check(total == 10, "prim_mst_tree_10");
    graph_free(&g);

    /* Chain undirected: MST = the chain, weight = 4 */
    build_chain(&g, 5, 0);
    total = prim_mst(&g, mst_parent);
    check(total == 4, "prim_mst_chain_4");
    graph_free(&g);

    /* Single vertex: MST weight = 0 */
    build_single(&g);
    total = prim_mst(&g, mst_parent);
    check(total == 0, "prim_mst_single_0");
    graph_free(&g);

    /* Large tree: MST = tree itself, weight = 3+5+7+2+4+1+6+3+2 = 33 */
    build_large_tree(&g);
    total = prim_mst(&g, mst_parent);
    check(total == 33, "prim_mst_large_tree_33");
    graph_free(&g);
}

static void test_degrees(void) {
    Graph g;
    int in_deg[MAX_V], out_deg[MAX_V];

    write_str("[degrees]\n");

    /* DAG */
    build_dag(&g);
    compute_in_degree(&g, in_deg);
    compute_out_degree(&g, out_deg);
    check(in_deg[0] == 0, "dag_indeg_0");
    check(in_deg[1] == 1, "dag_indeg_1");  /* from 0 */
    check(in_deg[2] == 2, "dag_indeg_2");  /* from 0,1 */
    check(in_deg[3] == 2, "dag_indeg_3");  /* from 1,2 */
    check(in_deg[4] == 1, "dag_indeg_4");  /* from 3 */
    check(out_deg[0] == 2, "dag_outdeg_0"); /* to 1,2 */
    check(out_deg[1] == 2, "dag_outdeg_1"); /* to 2,3 */
    check(out_deg[2] == 1, "dag_outdeg_2"); /* to 3 */
    check(out_deg[3] == 1, "dag_outdeg_3"); /* to 4 */
    check(out_deg[4] == 0, "dag_outdeg_4");
    graph_free(&g);

    /* Chain directed */
    build_chain(&g, 5, 1);
    compute_in_degree(&g, in_deg);
    compute_out_degree(&g, out_deg);
    check(in_deg[0] == 0, "chain_indeg_0");
    check(out_deg[0] == 1, "chain_outdeg_0");
    check(in_deg[4] == 1, "chain_indeg_4");
    check(out_deg[4] == 0, "chain_outdeg_4");
    check(in_deg[2] == 1, "chain_indeg_2");
    check(out_deg[2] == 1, "chain_outdeg_2");
    graph_free(&g);

    /* Single */
    build_single(&g);
    compute_in_degree(&g, in_deg);
    compute_out_degree(&g, out_deg);
    check(in_deg[0] == 0, "single_indeg_0");
    check(out_deg[0] == 0, "single_outdeg_0");
    graph_free(&g);
}

static void test_transpose(void) {
    Graph g, gt;
    int i, j;

    write_str("[transpose]\n");

    /* DAG transpose */
    build_dag(&g);
    graph_transpose(&g, &gt);
    check(gt.n == g.n, "transpose_n");
    check(gt.directed == g.directed, "transpose_directed");

    /* Check all edges reversed */
    for (i = 0; i < g.n; i++)
        for (j = 0; j < g.n; j++)
            if (g.adj[i][j] != gt.adj[j][i]) {
                check(0, "transpose_edge_mismatch");
                goto done_transpose_dag;
            }
    check(1, "transpose_all_edges_ok");
done_transpose_dag:

    /* Double transpose should equal original */
    {
        Graph gtt;
        int ok = 1;
        graph_transpose(&gt, &gtt);
        for (i = 0; i < g.n; i++)
            for (j = 0; j < g.n; j++)
                if (g.adj[i][j] != gtt.adj[i][j]) { ok = 0; break; }
        check(ok, "double_transpose_identity");
        graph_free(&gtt);
    }

    /* Transpose of chain: reversed chain */
    graph_free(&g);
    graph_free(&gt);

    build_chain(&g, 5, 1);
    graph_transpose(&g, &gt);
    check(gt.adj[1][0] == 1, "transpose_chain_10");
    check(gt.adj[0][1] == 0, "transpose_chain_01_zero");
    check(gt.adj[4][3] == 1, "transpose_chain_43");

    /* Transpose degrees: in/out swap */
    {
        int in_g[MAX_V], out_g[MAX_V], in_gt[MAX_V], out_gt[MAX_V];
        int ok2 = 1;
        compute_in_degree(&g, in_g);
        compute_out_degree(&g, out_g);
        compute_in_degree(&gt, in_gt);
        compute_out_degree(&gt, out_gt);
        for (i = 0; i < g.n; i++) {
            if (in_g[i] != out_gt[i]) ok2 = 0;
            if (out_g[i] != in_gt[i]) ok2 = 0;
        }
        check(ok2, "transpose_degree_swap");
    }

    graph_free(&g);
    graph_free(&gt);
}

static void test_complete_k5(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int comp[MAX_V];

    write_str("[complete_k5]\n");
    build_complete(&g, 5, 0);

    check(count_edges(&g) == 10, "k5_edges_10");
    check(is_connected(&g), "k5_connected");

    /* BFS from 0: all at distance 1 */
    bfs(&g, 0, dist, parent);
    check(dist[1] == 1, "k5_bfs_d1");
    check(dist[2] == 1, "k5_bfs_d2");
    check(dist[3] == 1, "k5_bfs_d3");
    check(dist[4] == 1, "k5_bfs_d4");

    /* Connected components */
    check(connected_components(&g, comp) == 1, "k5_cc_1");

    graph_free(&g);
}

static void test_complete_k5_directed(void) {
    Graph g;
    int in_deg[MAX_V], out_deg[MAX_V];
    int i;

    write_str("[complete_k5_directed]\n");
    build_complete(&g, 5, 1);

    /* Each vertex has 4 outgoing and 4 incoming edges */
    compute_in_degree(&g, in_deg);
    compute_out_degree(&g, out_deg);
    for (i = 0; i < 5; i++) {
        check(in_deg[i] == 4, "k5d_indeg_4");
        check(out_deg[i] == 4, "k5d_outdeg_4");
    }

    /* Should have cycle */
    check(has_cycle(&g), "k5d_has_cycle");

    /* Topo sort should fail (cycle) */
    {
        int result[MAX_V];
        int count = topological_sort(&g, result);
        check(count < g.n, "k5d_topo_fail");
    }

    graph_free(&g);
}

static void test_tree_properties(void) {
    Graph g;
    int mst_parent[MAX_V];
    int dist[MAX_V], parent[MAX_V];
    int total;

    write_str("[tree_properties]\n");
    build_tree(&g);

    check(count_edges(&g) == 4, "tree_edges_4"); /* n-1 */
    check(is_connected(&g), "tree_connected");

    /* MST of a tree = the tree itself */
    total = prim_mst(&g, mst_parent);
    check(total == sum_edge_weights(&g), "tree_mst_eq_total");

    /* BFS from root */
    bfs(&g, 0, dist, parent);
    check(dist[0] == 0, "tree_bfs_d0");
    check(dist[1] == 1, "tree_bfs_d1");
    check(dist[2] == 1, "tree_bfs_d2");
    check(dist[3] == 2, "tree_bfs_d3");
    check(dist[4] == 2, "tree_bfs_d4");

    graph_free(&g);
}

static void test_single_vertex(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int discover[MAX_V], finish[MAX_V];
    int result[MAX_V];
    int comp[MAX_V];

    write_str("[single_vertex]\n");
    build_single(&g);

    check(count_edges(&g) == 0, "single_edges_0");

    /* BFS */
    bfs(&g, 0, dist, parent);
    check(dist[0] == 0, "single_bfs_d0");

    /* DFS */
    dfs(&g, discover, finish, parent);
    check(discover[0] == 0, "single_dfs_disc");
    check(finish[0] == 1, "single_dfs_fin");

    /* Topo */
    check(topological_sort(&g, result) == 1, "single_topo_1");

    /* CC */
    check(connected_components(&g, comp) == 1, "single_cc_1");

    /* Dijkstra */
    dijkstra(&g, 0, dist, parent);
    check(dist[0] == 0, "single_dijk_d0");

    /* Bellman-Ford */
    check(bellman_ford(&g, 0, dist, parent) == 1, "single_bf_ok");

    graph_free(&g);
}

static void test_disconnected_bfs(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[disconnected_bfs]\n");
    build_disconnected(&g);

    bfs(&g, 0, dist, parent);
    check(dist[0] == 0, "disc_bfs_d0");
    check(dist[1] == 1, "disc_bfs_d1");
    check(dist[2] == -1, "disc_bfs_d2_unreachable");
    check(dist[3] == -1, "disc_bfs_d3_unreachable");
    check(dist[4] == -1, "disc_bfs_d4_unreachable");

    bfs(&g, 2, dist, parent);
    check(dist[2] == 0, "disc_bfs2_d2");
    check(dist[3] == 1, "disc_bfs2_d3");
    check(dist[0] == -1, "disc_bfs2_d0_unreachable");

    graph_free(&g);
}

static void test_disconnected_dijkstra(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[disconnected_dijkstra]\n");
    build_disconnected(&g);

    dijkstra(&g, 0, dist, parent);
    check(dist[0] == 0, "disc_dijk_d0");
    check(dist[1] == 1, "disc_dijk_d1");
    check(dist[2] == INF, "disc_dijk_d2_inf");
    check(dist[3] == INF, "disc_dijk_d3_inf");
    check(dist[4] == INF, "disc_dijk_d4_inf");

    graph_free(&g);
}

static void test_fw_vs_dijkstra(void) {
    Graph g;
    int dijk_dist[MAX_V], dijk_parent[MAX_V];
    int fw_dist[MAX_V][MAX_V];
    int i, ok;

    write_str("[fw_vs_dijkstra]\n");
    build_dijkstra_graph(&g);

    dijkstra(&g, 0, dijk_dist, dijk_parent);
    floyd_warshall(&g, fw_dist);

    ok = 1;
    for (i = 0; i < g.n; i++) {
        int fd = fw_dist[0][i];
        int dd = dijk_dist[i];
        if (dd == INF && fd == INF) continue;
        if (fd != dd) { ok = 0; break; }
    }
    check(ok, "fw_eq_dijkstra_from_0");

    /* Compare from node 1 */
    dijkstra(&g, 1, dijk_dist, dijk_parent);
    ok = 1;
    for (i = 0; i < g.n; i++) {
        int fd = fw_dist[1][i];
        int dd = dijk_dist[i];
        if (dd == INF && fd == INF) continue;
        if (fd != dd) { ok = 0; break; }
    }
    check(ok, "fw_eq_dijkstra_from_1");

    graph_free(&g);
}

static void test_bf_vs_dijkstra(void) {
    Graph g;
    int bf_dist[MAX_V], bf_parent[MAX_V];
    int dijk_dist[MAX_V], dijk_parent[MAX_V];
    int i, ok;

    write_str("[bf_vs_dijkstra]\n");
    /* Use a graph with non-negative weights */
    build_dijkstra_graph(&g);

    bellman_ford(&g, 0, bf_dist, bf_parent);
    dijkstra(&g, 0, dijk_dist, dijk_parent);

    ok = 1;
    for (i = 0; i < g.n; i++) {
        int bd = bf_dist[i];
        int dd = dijk_dist[i];
        if (bd == INF && dd == INF) continue;
        if (bd != dd) { ok = 0; break; }
    }
    check(ok, "bf_eq_dijkstra");

    graph_free(&g);
}

static void test_fw_chain(void) {
    Graph g;
    int dist[MAX_V][MAX_V];

    write_str("[fw_chain]\n");
    build_chain(&g, 5, 1);

    floyd_warshall(&g, dist);
    check(dist[0][4] == 4, "fw_chain_d04");
    check(dist[0][2] == 2, "fw_chain_d02");
    check(dist[3][4] == 1, "fw_chain_d34");
    check(dist[4][0] == INF, "fw_chain_d40_inf"); /* directed, no reverse */
    check(dist[2][0] == INF, "fw_chain_d20_inf");

    graph_free(&g);
}

static void test_fw_undirected_chain(void) {
    Graph g;
    int dist[MAX_V][MAX_V];

    write_str("[fw_undirected_chain]\n");
    build_chain(&g, 5, 0);

    floyd_warshall(&g, dist);
    check(dist[0][4] == 4, "fw_uchain_d04");
    check(dist[4][0] == 4, "fw_uchain_d40");
    check(dist[1][3] == 2, "fw_uchain_d13");
    check(dist[2][2] == 0, "fw_uchain_d22");

    graph_free(&g);
}

static void test_bf_chain_negative(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int ok;

    write_str("[bf_chain_negative]\n");
    /* Build: 0--(3)-->1--(-1)-->2--(2)-->3--(-1)-->4 */
    graph_init(&g, 5, 1);
    graph_add_directed_edge(&g, 0, 1, 3);
    graph_add_directed_edge(&g, 1, 2, -1);
    graph_add_directed_edge(&g, 2, 3, 2);
    graph_add_directed_edge(&g, 3, 4, -1);

    ok = bellman_ford(&g, 0, dist, parent);
    check(ok == 1, "bf_neg_chain_ok");
    check(dist[0] == 0, "bf_neg_d0");
    check(dist[1] == 3, "bf_neg_d1");
    check(dist[2] == 2, "bf_neg_d2");
    check(dist[3] == 4, "bf_neg_d3");
    check(dist[4] == 3, "bf_neg_d4");

    graph_free(&g);
}

static void test_large_dag_topo(void) {
    Graph g;
    int result[MAX_V];
    int count, i;

    write_str("[large_dag_topo]\n");
    /* Build a 10-node DAG: edges i->j for all i<j with j-i<=3 */
    graph_init(&g, 10, 1);
    for (i = 0; i < 10; i++) {
        if (i + 1 < 10) graph_add_directed_edge(&g, i, i + 1, 1);
        if (i + 2 < 10) graph_add_directed_edge(&g, i, i + 2, 2);
        if (i + 3 < 10) graph_add_directed_edge(&g, i, i + 3, 3);
    }

    count = topological_sort(&g, result);
    check(count == 10, "large_dag_topo_count");
    check(verify_topo_order(&g, result, count), "large_dag_topo_valid");
    check(!has_cycle(&g), "large_dag_no_cycle");

    graph_free(&g);
}

static void test_dijkstra_large(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int fw_dist[MAX_V][MAX_V];
    int i, ok;

    write_str("[dijkstra_large]\n");
    build_fw_graph(&g);

    /* Test Dijkstra from each source against Floyd-Warshall */
    floyd_warshall(&g, fw_dist);

    ok = 1;
    for (i = 0; i < g.n && ok; i++) {
        int j;
        dijkstra(&g, i, dist, parent);
        for (j = 0; j < g.n; j++) {
            int dd = dist[j];
            int fd = fw_dist[i][j];
            if (dd == INF && fd == INF) continue;
            if (dd != fd) { ok = 0; break; }
        }
    }
    check(ok, "dijkstra_eq_fw_all_sources");

    graph_free(&g);
}

static void test_bf_large(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int fw_dist[MAX_V][MAX_V];
    int i, ok;

    write_str("[bellman_ford_large]\n");
    build_fw_graph(&g);

    floyd_warshall(&g, fw_dist);

    ok = 1;
    for (i = 0; i < g.n && ok; i++) {
        int j;
        int ret = bellman_ford(&g, i, dist, parent);
        check(ret == 1, "bf_large_no_neg_cycle");
        for (j = 0; j < g.n; j++) {
            int bd = dist[j];
            int fd = fw_dist[i][j];
            if (bd == INF && fd == INF) continue;
            if (bd != fd) { ok = 0; break; }
        }
    }
    check(ok, "bf_eq_fw_all_sources");

    graph_free(&g);
}

static void test_mst_complete(void) {
    Graph g;
    int mst_parent[MAX_V];
    int total;

    write_str("[mst_complete]\n");
    /* Complete K4 undirected with weights: i*n+j+1 */
    build_complete(&g, 4, 0);
    total = prim_mst(&g, mst_parent);

    /* K4 edges (sorted by weight, w = i*n+j+1, n=4):
     * 0-1: 2, 0-2: 3, 0-3: 4, 1-2: 7, 1-3: 8, 2-3: 12
     * Kruskal/Prim MST: 0-1(2), 0-2(3), 0-3(4) = 9 */
    check(total == 9, "mst_k4_total_8");

    /* Verify parent: root=0, all others connect to 0 */
    check(mst_parent[0] == -1, "mst_k4_root");

    graph_free(&g);
}

static void test_dfs_timestamps(void) {
    Graph g;
    int discover[MAX_V], finish[MAX_V], parent[MAX_V];
    int i;

    write_str("[dfs_timestamps]\n");
    build_dag(&g);

    dfs(&g, discover, finish, parent);

    /* Parenthesis theorem: for each pair (u,v):
     * either [disc[u], fin[u]] and [disc[v], fin[v]] are disjoint
     * or one is entirely contained in the other */
    {
        int ok = 1;
        for (i = 0; i < g.n && ok; i++) {
            int j;
            for (j = i + 1; j < g.n && ok; j++) {
                int di = discover[i], fi = finish[i];
                int dj = discover[j], fj = finish[j];
                /* i contains j? */
                int i_contains_j = (di < dj && fj < fi);
                /* j contains i? */
                int j_contains_i = (dj < di && fi < fj);
                /* disjoint? */
                int disjoint = (fi < dj || fj < di);
                if (!i_contains_j && !j_contains_i && !disjoint) ok = 0;
            }
        }
        check(ok, "dfs_parenthesis_theorem");
    }

    /* All discover < finish */
    {
        int ok = 1;
        for (i = 0; i < g.n; i++)
            if (discover[i] >= finish[i]) ok = 0;
        check(ok, "dfs_disc_lt_fin");
    }

    graph_free(&g);
}

static void test_dfs_disconnected(void) {
    Graph g;
    int discover[MAX_V], finish[MAX_V], parent[MAX_V];

    write_str("[dfs_disconnected]\n");
    build_disconnected(&g);

    /* For undirected disconnected, need to use directed=0 graph but
     * we'll just verify DFS visits all vertices */
    dfs(&g, discover, finish, parent);
    check(discover[0] >= 0, "dfs_disc_v0_visited");
    check(discover[4] >= 0, "dfs_disc_v4_visited");
    check(finish[0] >= 0, "dfs_disc_v0_finished");
    check(finish[4] >= 0, "dfs_disc_v4_finished");

    /* Roots should have parent = -1 */
    {
        int roots = 0, i;
        for (i = 0; i < g.n; i++)
            if (parent[i] == -1) roots++;
        check(roots >= 3, "dfs_disc_3_roots"); /* 3 components */
    }

    graph_free(&g);
}

/*
 * Build a grid-like directed graph for stress testing:
 * 4x4 grid, edges right and down.
 */
static void test_grid_graph(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int fw_dist[MAX_V][MAX_V];
    int i, j, idx, ok;
    int n = 4; /* 4x4 grid = 16 nodes */

    write_str("[grid_graph]\n");
    graph_init(&g, n * n, 1);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            idx = i * n + j;
            if (j + 1 < n) graph_add_directed_edge(&g, idx, idx + 1, 1);
            if (i + 1 < n) graph_add_directed_edge(&g, idx, idx + n, 1);
        }
    }

    /* Shortest path from top-left to bottom-right = (n-1)*2 */
    dijkstra(&g, 0, dist, parent);
    check(dist[n * n - 1] == (n - 1) * 2, "grid_shortest");
    check(dist[0] == 0, "grid_src_0");
    check(dist[n - 1] == n - 1, "grid_top_right");
    check(dist[(n - 1) * n] == n - 1, "grid_bot_left");

    /* No cycles in grid DAG */
    check(!has_cycle(&g), "grid_no_cycle");

    /* Topo sort should work */
    {
        int result[MAX_V];
        int count = topological_sort(&g, result);
        check(count == n * n, "grid_topo_complete");
        check(verify_topo_order(&g, result, count), "grid_topo_valid");
    }

    /* Floyd-Warshall vs Dijkstra */
    floyd_warshall(&g, fw_dist);
    ok = 1;
    for (i = 0; i < n * n && ok; i++) {
        dijkstra(&g, i, dist, parent);
        for (j = 0; j < n * n; j++) {
            if (dist[j] == INF && fw_dist[i][j] == INF) continue;
            if (dist[j] != fw_dist[i][j]) { ok = 0; break; }
        }
    }
    check(ok, "grid_dijk_eq_fw");

    graph_free(&g);
}

/*
 * Star graph: center vertex 0 connected to all others.
 */
static void test_star_graph(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int comp[MAX_V];
    int mst_parent[MAX_V];
    int total, i;

    write_str("[star_graph]\n");
    graph_init(&g, 8, 0);
    for (i = 1; i < 8; i++)
        graph_add_edge(&g, 0, i, i);

    check(count_edges(&g) == 7, "star_edges");
    check(is_connected(&g), "star_connected");
    check(connected_components(&g, comp) == 1, "star_cc_1");

    /* BFS from center: all at distance 1 */
    bfs(&g, 0, dist, parent);
    for (i = 1; i < 8; i++)
        check(dist[i] == 1, "star_bfs_dist_1");

    /* BFS from leaf: center at 1, other leaves at 2 */
    bfs(&g, 3, dist, parent);
    check(dist[0] == 1, "star_bfs_leaf_to_center");
    check(dist[1] == 2, "star_bfs_leaf_to_leaf");

    /* MST of star = star itself, weight = 1+2+...+7 = 28 */
    total = prim_mst(&g, mst_parent);
    check(total == 28, "star_mst_28");

    /* Dijkstra from center */
    dijkstra(&g, 0, dist, parent);
    for (i = 1; i < 8; i++)
        check(dist[i] == i, "star_dijk_dist");

    graph_free(&g);
}

/*
 * Bipartite-like graph for testing various properties.
 */
static void test_bipartite_graph(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int comp[MAX_V];
    int i, j;

    write_str("[bipartite_graph]\n");
    /* L = {0,1,2}, R = {3,4,5}, all L->R edges */
    graph_init(&g, 6, 0);
    for (i = 0; i < 3; i++)
        for (j = 3; j < 6; j++)
            graph_add_edge(&g, i, j, i * 3 + j);

    check(count_edges(&g) == 9, "bipartite_edges_9");
    check(is_connected(&g), "bipartite_connected");
    check(connected_components(&g, comp) == 1, "bipartite_cc_1");

    /* BFS from 0 */
    bfs(&g, 0, dist, parent);
    check(dist[0] == 0, "bip_bfs_d0");
    check(dist[3] == 1, "bip_bfs_d3");
    check(dist[1] == 2, "bip_bfs_d1"); /* 0->3->1 or 0->4->1, etc. */
    check(dist[2] == 2, "bip_bfs_d2");

    graph_free(&g);
}

/*
 * Test Bellman-Ford with positive and negative edges systematically.
 */
static void test_bf_systematic(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int ok;

    write_str("[bf_systematic]\n");

    /* Graph: 5 nodes, mix of positive/negative edges, no neg cycle.
     * 0--(4)-->1, 0--(8)-->2, 1--(-3)-->2, 1--(5)-->3,
     * 2--(2)-->4, 3--(-1)-->4, 2--(1)-->3
     * From 0:
     *   d[0]=0
     *   d[1]=4
     *   d[2]=min(8, 4+(-3))=1
     *   d[3]=min(inf, 4+5, 1+1)=2
     *   d[4]=min(inf, 1+2, 2+(-1))=1
     */
    graph_init(&g, 5, 1);
    graph_add_directed_edge(&g, 0, 1, 4);
    graph_add_directed_edge(&g, 0, 2, 8);
    graph_add_directed_edge(&g, 1, 2, -3);
    graph_add_directed_edge(&g, 1, 3, 5);
    graph_add_directed_edge(&g, 2, 4, 2);
    graph_add_directed_edge(&g, 3, 4, -1);
    graph_add_directed_edge(&g, 2, 3, 1);

    ok = bellman_ford(&g, 0, dist, parent);
    check(ok == 1, "bf_sys_no_neg_cycle");
    check(dist[0] == 0, "bf_sys_d0");
    check(dist[1] == 4, "bf_sys_d1");
    check(dist[2] == 1, "bf_sys_d2");
    check(dist[3] == 2, "bf_sys_d3");
    check(dist[4] == 1, "bf_sys_d4");

    graph_free(&g);
}

/*
 * Test dense graph (K8 directed) various algorithms.
 */
static void test_dense_k8(void) {
    Graph g;
    int in_deg[MAX_V], out_deg[MAX_V];
    int i;

    write_str("[dense_k8]\n");
    build_complete(&g, 8, 1);

    /* Degrees */
    compute_in_degree(&g, in_deg);
    compute_out_degree(&g, out_deg);
    for (i = 0; i < 8; i++) {
        check(in_deg[i] == 7, "k8_indeg_7");
        check(out_deg[i] == 7, "k8_outdeg_7");
    }

    /* Has cycle */
    check(has_cycle(&g), "k8_has_cycle");

    /* Transpose symmetry check */
    {
        Graph gt;
        int ok = 1, j;
        graph_transpose(&g, &gt);
        for (i = 0; i < 8 && ok; i++)
            for (j = 0; j < 8 && ok; j++)
                if (g.adj[i][j] != gt.adj[j][i]) ok = 0;
        check(ok, "k8_transpose_ok");
        graph_free(&gt);
    }

    graph_free(&g);
}

/*
 * Test MST with several edge configurations.
 */
static void test_mst_various(void) {
    Graph g;
    int mst_parent[MAX_V];
    int total;

    write_str("[mst_various]\n");

    /* Triangle: edges (0,1,3), (1,2,1), (0,2,2)
     * MST: 1-2(1), 0-2(2) = 3 */
    graph_init(&g, 3, 0);
    graph_add_edge(&g, 0, 1, 3);
    graph_add_edge(&g, 1, 2, 1);
    graph_add_edge(&g, 0, 2, 2);
    total = prim_mst(&g, mst_parent);
    check(total == 3, "mst_tri_3");
    graph_free(&g);

    /* Two triangles sharing an edge:
     * 0-1(1), 1-2(2), 0-2(4), 2-3(3), 1-3(5)
     * MST: 0-1(1), 1-2(2), 2-3(3) = 6 */
    graph_init(&g, 4, 0);
    graph_add_edge(&g, 0, 1, 1);
    graph_add_edge(&g, 1, 2, 2);
    graph_add_edge(&g, 0, 2, 4);
    graph_add_edge(&g, 2, 3, 3);
    graph_add_edge(&g, 1, 3, 5);
    total = prim_mst(&g, mst_parent);
    check(total == 6, "mst_double_tri_6");
    graph_free(&g);

    /* Square with diagonal:
     * 0-1(1), 1-2(2), 2-3(3), 3-0(4), 0-2(10)
     * MST: 0-1(1), 1-2(2), 2-3(3) = 6 */
    graph_init(&g, 4, 0);
    graph_add_edge(&g, 0, 1, 1);
    graph_add_edge(&g, 1, 2, 2);
    graph_add_edge(&g, 2, 3, 3);
    graph_add_edge(&g, 3, 0, 4);
    graph_add_edge(&g, 0, 2, 10);
    total = prim_mst(&g, mst_parent);
    check(total == 6, "mst_square_diag_6");
    graph_free(&g);
}

/*
 * Test cycle detection edge cases.
 */
static void test_cycle_edge_cases(void) {
    Graph g;

    write_str("[cycle_edge_cases]\n");

    /* Self-loop */
    graph_init(&g, 2, 1);
    graph_add_directed_edge(&g, 0, 0, 1);
    graph_add_directed_edge(&g, 0, 1, 2);
    check(has_cycle(&g), "cycle_self_loop");
    graph_free(&g);

    /* Two separate cycles */
    graph_init(&g, 6, 1);
    graph_add_directed_edge(&g, 0, 1, 1);
    graph_add_directed_edge(&g, 1, 0, 1);
    graph_add_directed_edge(&g, 2, 3, 1);
    graph_add_directed_edge(&g, 3, 4, 1);
    graph_add_directed_edge(&g, 4, 2, 1);
    check(has_cycle(&g), "cycle_two_cycles");
    graph_free(&g);

    /* Tree-shaped directed (no cycle) */
    graph_init(&g, 7, 1);
    graph_add_directed_edge(&g, 0, 1, 1);
    graph_add_directed_edge(&g, 0, 2, 1);
    graph_add_directed_edge(&g, 1, 3, 1);
    graph_add_directed_edge(&g, 1, 4, 1);
    graph_add_directed_edge(&g, 2, 5, 1);
    graph_add_directed_edge(&g, 2, 6, 1);
    check(!has_cycle(&g), "no_cycle_directed_tree");
    graph_free(&g);

    /* Diamond with converging edges (no cycle):
     * 0->1, 0->2, 1->3, 2->3 */
    graph_init(&g, 4, 1);
    graph_add_directed_edge(&g, 0, 1, 1);
    graph_add_directed_edge(&g, 0, 2, 1);
    graph_add_directed_edge(&g, 1, 3, 1);
    graph_add_directed_edge(&g, 2, 3, 1);
    check(!has_cycle(&g), "no_cycle_diamond");
    graph_free(&g);
}

/*
 * BFS and DFS on complete graph.
 */
static void test_complete_traversal(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int discover[MAX_V], finish[MAX_V];
    int i;

    write_str("[complete_traversal]\n");
    build_complete(&g, 6, 0);

    /* BFS: all vertices at distance 1 from any source */
    bfs(&g, 0, dist, parent);
    for (i = 1; i < 6; i++)
        check(dist[i] == 1, "k6_bfs_d1");

    /* DFS: all vertices discovered and finished */
    dfs(&g, discover, finish, parent);
    {
        int ok = 1;
        for (i = 0; i < 6; i++)
            if (discover[i] < 0 || finish[i] < 0) ok = 0;
        check(ok, "k6_dfs_all_visited");
    }

    graph_free(&g);
}

/*
 * Test path reconstruction on various graphs.
 */
static void test_path_reconstruction(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int path[MAX_V], plen;

    write_str("[path_reconstruction]\n");

    /* Dijkstra path on weighted graph */
    build_fw_graph(&g);
    dijkstra(&g, 0, dist, parent);

    /* Path 0->7: should be 0->2->1->3->4->5->6->7 */
    plen = reconstruct_path(parent, 0, 7, path);
    check(plen > 0, "path_07_exists");
    check(path[0] == 0, "path_07_start");
    check(path[plen - 1] == 7, "path_07_end");

    /* Verify path weight equals distance */
    {
        int weight = 0, ok = 1, k;
        for (k = 0; k < plen - 1; k++) {
            if (g.adj[path[k]][path[k + 1]] == 0) { ok = 0; break; }
            weight += g.adj[path[k]][path[k + 1]];
        }
        check(ok, "path_07_valid_edges");
        check(weight == dist[7], "path_07_weight_eq_dist");
    }

    graph_free(&g);

    /* BFS path on tree */
    build_tree(&g);
    bfs(&g, 0, dist, parent);
    plen = reconstruct_path(parent, 0, 3, path);
    check(plen == 3, "tree_path_03_len");
    check(path[0] == 0 && path[1] == 1 && path[2] == 3, "tree_path_03");

    graph_free(&g);
}

/*
 * Stress: build a 20-node directed graph and verify BF == FW.
 */
static void test_stress_20_bf_fw(void) {
    Graph g;
    int dist_bf[MAX_V], parent_bf[MAX_V];
    int dist_fw[MAX_V][MAX_V];
    int i, j, ok;
    int lcg = 42; /* LCG PRNG seed */

    write_str("[stress_20_bf_fw]\n");
    graph_init(&g, 20, 1);

    /* Add ~60 random edges with weights 1-20 */
    for (i = 0; i < 20; i++) {
        for (j = 0; j < 20; j++) {
            if (i == j) continue;
            lcg = (lcg * 1103515245 + 12345) & 0x7fffffff;
            if ((lcg % 6) == 0) { /* ~16% probability */
                int w = (lcg % 20) + 1;
                graph_add_directed_edge(&g, i, j, w);
            }
        }
    }

    floyd_warshall(&g, dist_fw);

    ok = 1;
    for (i = 0; i < 20 && ok; i++) {
        int ret = bellman_ford(&g, i, dist_bf, parent_bf);
        check(ret == 1, "stress20_no_neg_cycle");
        for (j = 0; j < 20; j++) {
            if (dist_bf[j] == INF && dist_fw[i][j] == INF) continue;
            if (dist_bf[j] != dist_fw[i][j]) { ok = 0; break; }
        }
    }
    check(ok, "stress20_bf_eq_fw");

    graph_free(&g);
}

/*
 * Stress: build a 20-node undirected graph and verify MST properties.
 */
static void test_stress_20_mst(void) {
    Graph g;
    int mst_parent[MAX_V];
    int total;
    int lcg = 99;
    int i, j;

    write_str("[stress_20_mst]\n");
    graph_init(&g, 20, 0);

    /* Ensure connected by building a chain first */
    for (i = 0; i < 19; i++)
        graph_add_edge(&g, i, i + 1, 100 + i);

    /* Add random extra edges */
    for (i = 0; i < 20; i++) {
        for (j = i + 1; j < 20; j++) {
            if (j == i + 1) continue; /* already have chain edge */
            lcg = (lcg * 1103515245 + 12345) & 0x7fffffff;
            if ((lcg % 4) == 0) {
                int w = (lcg % 50) + 1;
                graph_add_edge(&g, i, j, w);
            }
        }
    }

    total = prim_mst(&g, mst_parent);
    check(total > 0, "stress20_mst_positive");

    /* MST has exactly n-1 edges (check via parent: exactly 1 root) */
    {
        int roots = 0, edges = 0;
        for (i = 0; i < 20; i++) {
            if (mst_parent[i] == -1) roots++;
            else edges++;
        }
        check(roots == 1, "stress20_mst_1_root");
        check(edges == 19, "stress20_mst_19_edges");
    }

    /* Verify MST weight <= chain weight (since chain = spanning tree) */
    {
        int chain_w = 0;
        for (i = 0; i < 19; i++) chain_w += 100 + i;
        check(total <= chain_w, "stress20_mst_le_chain");
    }

    graph_free(&g);
}

/*
 * Stress: BFS distances satisfy triangle inequality.
 */
static void test_bfs_triangle_inequality(void) {
    Graph g;
    int dist0[MAX_V], dist1[MAX_V], parent[MAX_V];
    int i;

    write_str("[bfs_triangle_inequality]\n");
    build_complete(&g, 8, 0);

    bfs(&g, 0, dist0, parent);
    bfs(&g, 1, dist1, parent);

    /* |d(0,v) - d(1,v)| <= d(0,1) for all v */
    for (i = 0; i < 8; i++) {
        int diff = dist0[i] - dist1[i];
        if (diff < 0) diff = -diff;
        check(diff <= dist0[1], "bfs_tri_ineq");
    }

    graph_free(&g);
}

/*
 * Test Dijkstra on a graph where greedy approach matters.
 * This tests that the algorithm correctly processes vertices in order.
 *   0 --(1)--> 1 --(1)--> 3
 *   0 --(3)--> 3
 * Shortest to 3: via 1, cost 2 (not direct cost 3).
 */
static void test_dijkstra_greedy(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[dijkstra_greedy]\n");
    graph_init(&g, 4, 1);
    graph_add_directed_edge(&g, 0, 1, 1);
    graph_add_directed_edge(&g, 1, 3, 1);
    graph_add_directed_edge(&g, 0, 3, 3);
    graph_add_directed_edge(&g, 0, 2, 2);
    graph_add_directed_edge(&g, 2, 3, 5);

    dijkstra(&g, 0, dist, parent);
    check(dist[3] == 2, "dijk_greedy_d3");
    check(dist[1] == 1, "dijk_greedy_d1");
    check(dist[2] == 2, "dijk_greedy_d2");

    graph_free(&g);
}

/*
 * Two-node graphs.
 */
static void test_two_nodes(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int comp[MAX_V];
    int result[MAX_V];

    write_str("[two_nodes]\n");

    /* Directed 0->1 */
    graph_init(&g, 2, 1);
    graph_add_directed_edge(&g, 0, 1, 5);
    dijkstra(&g, 0, dist, parent);
    check(dist[1] == 5, "two_dijk_01");
    dijkstra(&g, 1, dist, parent);
    check(dist[0] == INF, "two_dijk_10_inf");
    check(!has_cycle(&g), "two_no_cycle");
    check(topological_sort(&g, result) == 2, "two_topo_2");
    graph_free(&g);

    /* Undirected 0--1 */
    graph_init(&g, 2, 0);
    graph_add_edge(&g, 0, 1, 3);
    check(connected_components(&g, comp) == 1, "two_undir_cc_1");
    bfs(&g, 0, dist, parent);
    check(dist[1] == 1, "two_undir_bfs");
    graph_free(&g);

    /* Two disconnected */
    graph_init(&g, 2, 0);
    check(connected_components(&g, comp) == 2, "two_disconn_cc_2");
    graph_free(&g);
}

/*
 * Edge weight boundary cases.
 */
static void test_weight_boundaries(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];

    write_str("[weight_boundaries]\n");

    /* Very large weights */
    graph_init(&g, 3, 1);
    graph_add_directed_edge(&g, 0, 1, 100000);
    graph_add_directed_edge(&g, 1, 2, 200000);
    graph_add_directed_edge(&g, 0, 2, 400000);

    dijkstra(&g, 0, dist, parent);
    check(dist[2] == 300000, "weight_large_d2");
    graph_free(&g);

    /* Weight = 1 everywhere (BFS equivalence) */
    graph_init(&g, 4, 1);
    graph_add_directed_edge(&g, 0, 1, 1);
    graph_add_directed_edge(&g, 0, 2, 1);
    graph_add_directed_edge(&g, 1, 3, 1);
    graph_add_directed_edge(&g, 2, 3, 1);

    dijkstra(&g, 0, dist, parent);
    check(dist[3] == 2, "weight_unit_d3");

    {
        int bfs_dist[MAX_V], bfs_par[MAX_V];
        bfs(&g, 0, bfs_dist, bfs_par);
        check(bfs_dist[3] == dist[3], "weight_unit_bfs_eq_dijk");
    }

    graph_free(&g);
}

/*
 * Verify edge counts and basic graph properties.
 */
static void test_graph_properties(void) {
    Graph g;

    write_str("[graph_properties]\n");

    /* Empty graph (no edges) */
    graph_init(&g, 5, 0);
    check(count_edges(&g) == 0, "empty_edges_0");
    check(!is_connected(&g), "empty_not_connected");
    graph_free(&g);

    /* Full undirected K_n: n*(n-1)/2 edges */
    build_complete(&g, 5, 0);
    check(count_edges(&g) == 10, "k5_edges");
    check(sum_edge_weights(&g) > 0, "k5_positive_weight");
    graph_free(&g);

    /* Chain: n-1 edges */
    build_chain(&g, 8, 0);
    check(count_edges(&g) == 7, "chain8_edges_7");
    check(is_connected(&g), "chain8_connected");
    graph_free(&g);

    /* Disconnected: not connected */
    build_disconnected(&g);
    check(!is_connected(&g), "disconn_not_connected");
    graph_free(&g);

    /* Tree: n-1 edges, connected */
    build_tree(&g);
    check(count_edges(&g) == 4, "tree5_edges_4");
    check(is_connected(&g), "tree5_connected");
    graph_free(&g);
}

/*
 * Final stress: 16-node dense graph, all algorithms.
 */
static void test_stress_16_all(void) {
    Graph g;
    int dist[MAX_V], parent[MAX_V];
    int dist_bf[MAX_V], parent_bf[MAX_V];
    int fw_dist[MAX_V][MAX_V];
    int discover[MAX_V], finish[MAX_V], dfs_parent[MAX_V];
    int i, j, ok;
    int lcg = 137;

    write_str("[stress_16_all]\n");

    /* Build directed graph with positive weights */
    graph_init(&g, 16, 1);
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            if (i == j) continue;
            lcg = (lcg * 1103515245 + 12345) & 0x7fffffff;
            if ((lcg % 5) == 0) {
                int w = (lcg % 30) + 1;
                graph_add_directed_edge(&g, i, j, w);
            }
        }
    }

    /* DFS - just verify timestamps valid */
    dfs(&g, discover, finish, dfs_parent);
    {
        int ok2 = 1;
        for (i = 0; i < 16; i++)
            if (discover[i] < 0 || finish[i] < 0 || discover[i] >= finish[i])
                ok2 = 0;
        check(ok2, "stress16_dfs_valid");
    }

    /* Floyd-Warshall */
    floyd_warshall(&g, fw_dist);

    /* Dijkstra vs FW for all sources */
    ok = 1;
    for (i = 0; i < 16 && ok; i++) {
        dijkstra(&g, i, dist, parent);
        for (j = 0; j < 16; j++) {
            if (dist[j] == INF && fw_dist[i][j] == INF) continue;
            if (dist[j] != fw_dist[i][j]) { ok = 0; break; }
        }
    }
    check(ok, "stress16_dijk_eq_fw");

    /* Bellman-Ford vs FW for all sources */
    ok = 1;
    for (i = 0; i < 16 && ok; i++) {
        int ret = bellman_ford(&g, i, dist_bf, parent_bf);
        if (!ret) { ok = 0; break; }
        for (j = 0; j < 16; j++) {
            if (dist_bf[j] == INF && fw_dist[i][j] == INF) continue;
            if (dist_bf[j] != fw_dist[i][j]) { ok = 0; break; }
        }
    }
    check(ok, "stress16_bf_eq_fw");

    /* Degree check: sum of out-degrees = number of edges */
    {
        int out_deg[MAX_V], in_deg[MAX_V];
        int sum_out = 0, sum_in = 0, edge_count = 0;
        compute_out_degree(&g, out_deg);
        compute_in_degree(&g, in_deg);
        for (i = 0; i < 16; i++) { sum_out += out_deg[i]; sum_in += in_deg[i]; }
        for (i = 0; i < 16; i++)
            for (j = 0; j < 16; j++)
                if (g.adj[i][j] != 0) edge_count++;
        check(sum_out == edge_count, "stress16_sum_outdeg");
        check(sum_in == edge_count, "stress16_sum_indeg");
        check(sum_out == sum_in, "stress16_out_eq_in");
    }

    graph_free(&g);
}

/* ========================================================================
 * MAIN
 * ======================================================================== */

int main(void) {
    g_errs = 0;
    init_io();

    write_str("=== victim_graph tests ===\n");

    test_chain_bfs();
    test_chain_dfs();
    test_dag_topo();
    test_diamond_topo();
    test_cycle_detection();
    test_topo_cycle();
    test_dijkstra_simple();
    test_dijkstra_chain();
    test_floyd_warshall_simple();
    test_floyd_warshall_large();
    test_bellman_ford_simple();
    test_bellman_ford_negative_cycle();
    test_bellman_ford_chain();
    test_connected_components();
    test_prim_mst();
    test_degrees();
    test_transpose();
    test_complete_k5();
    test_complete_k5_directed();
    test_tree_properties();
    test_single_vertex();
    test_disconnected_bfs();
    test_disconnected_dijkstra();
    test_fw_vs_dijkstra();
    test_bf_vs_dijkstra();
    test_fw_chain();
    test_fw_undirected_chain();
    test_bf_chain_negative();
    test_large_dag_topo();
    test_dijkstra_large();
    test_bf_large();
    test_mst_complete();
    test_dfs_timestamps();
    test_dfs_disconnected();
    test_grid_graph();
    test_star_graph();
    test_bipartite_graph();
    test_bf_systematic();
    test_dense_k8();
    test_stress_20_bf_fw();
    test_stress_20_mst();
    test_bfs_triangle_inequality();
    test_dijkstra_greedy();
    test_two_nodes();
    test_weight_boundaries();
    test_graph_properties();
    test_path_reconstruction();
    test_stress_16_all();

    write_str("Total errors: ");
    write_int(g_errs);
    write_str("\n");

    return g_errs;
}
