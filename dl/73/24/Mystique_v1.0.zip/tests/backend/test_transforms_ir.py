"""Test each IR transform flag individually and all combined across multiple seeds."""
import sys
import pytest
from tests.backend.conftest import compile_backend, run_loader, IR_FLAGS, IS_WINDOWS

EXPECTED_EXIT = 0 if IS_WINDOWS else 42
SEEDS = [1001, 1002, 1003]


@pytest.mark.backend
@pytest.mark.parametrize("flag", IR_FLAGS, ids=[f.lstrip("-") for f in IR_FLAGS])
@pytest.mark.parametrize("seed", SEEDS)
def test_ir_transform_individual(backend_exe, loader_exe, stress_mcb, tmp_path, flag, seed):
    """Compile with a single IR flag at a given seed, run, check exit code."""
    safe_name = flag.lstrip("-").replace("-", "_")
    bin_out = tmp_path / f"stress_{safe_name}_s{seed}.bin"
    compile_backend(backend_exe, stress_mcb, bin_out, seed=seed, flags=[flag])
    rc = run_loader(loader_exe, bin_out)
    assert rc == EXPECTED_EXIT, (
        f"{flag} seed={seed} exited {rc}, expected {EXPECTED_EXIT}"
    )


@pytest.mark.backend
@pytest.mark.parametrize("seed", SEEDS)
def test_ir_transforms_all_combined(backend_exe, loader_exe, stress_mcb, tmp_path, seed):
    """Compile with ALL IR flags at a given seed, run, check exit code."""
    bin_out = tmp_path / f"stress_all_ir_s{seed}.bin"
    compile_backend(backend_exe, stress_mcb, bin_out, seed=seed, flags=list(IR_FLAGS))
    rc = run_loader(loader_exe, bin_out)
    assert rc == EXPECTED_EXIT, (
        f"all IR flags seed={seed} exited {rc}, expected {EXPECTED_EXIT}"
    )
