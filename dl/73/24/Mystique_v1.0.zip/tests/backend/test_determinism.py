"""Verify polymorphism properties of the backend.

Same seed + flags must produce identical output (determinism).
Different seeds or different transform flags must produce different output (polymorphism).
All polymorphic variants must remain valid executables.
"""
import hashlib

import pytest

from tests.backend.conftest import compile_backend, run_loader, ALL_FLAGS, IS_WINDOWS


def _sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------------------
# 1. Same seed, same flags -> identical binary
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_same_seed_same_flags_identical(backend_exe, stress_mcb, tmp_path):
    a = compile_backend(backend_exe, stress_mcb, tmp_path / "a.bin",
                        seed=1001, flags=ALL_FLAGS)
    b = compile_backend(backend_exe, stress_mcb, tmp_path / "b.bin",
                        seed=1001, flags=ALL_FLAGS)
    assert _sha256(a) == _sha256(b), "Same seed + flags must produce identical output"


# ---------------------------------------------------------------------------
# 2. Different seeds with transforms -> different binary
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_different_seeds_with_transforms(backend_exe, stress_mcb, tmp_path):
    flags = ["--ir-unfold", "--x86-poly-instrs"]
    a = compile_backend(backend_exe, stress_mcb, tmp_path / "a.bin",
                        seed=1001, flags=flags)
    b = compile_backend(backend_exe, stress_mcb, tmp_path / "b.bin",
                        seed=1002, flags=flags)
    assert _sha256(a) != _sha256(b), "Different seeds with transforms must differ"


# ---------------------------------------------------------------------------
# 3. No transforms, same seed -> identical binary (deterministic baseline)
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_no_transforms_same_seed_identical(backend_exe, stress_mcb, tmp_path):
    a = compile_backend(backend_exe, stress_mcb, tmp_path / "a.bin",
                        seed=1001, flags=None)
    b = compile_backend(backend_exe, stress_mcb, tmp_path / "b.bin",
                        seed=1001, flags=None)
    assert _sha256(a) == _sha256(b), \
        "Same seed without transforms must produce identical output"


# ---------------------------------------------------------------------------
# 4. 10 seeds, all transforms -> 10 unique hashes
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_ten_seeds_all_unique(backend_exe, stress_mcb, tmp_path):
    hashes = set()
    for seed in range(1001, 1011):
        out = compile_backend(backend_exe, stress_mcb,
                              tmp_path / f"s{seed}.bin",
                              seed=seed, flags=ALL_FLAGS)
        hashes.add(_sha256(out))
    assert len(hashes) == 10, (
        f"Expected 10 unique binaries, got {len(hashes)}")


# ---------------------------------------------------------------------------
# 5. Different IR flags -> different output
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_different_ir_flags(backend_exe, stress_mcb, tmp_path):
    a = compile_backend(backend_exe, stress_mcb, tmp_path / "a.bin",
                        seed=1001, flags=["--ir-unfold"])
    b = compile_backend(backend_exe, stress_mcb, tmp_path / "b.bin",
                        seed=1001, flags=["--ir-substitute"])
    assert _sha256(a) != _sha256(b), \
        "--ir-unfold and --ir-substitute should produce different output"


# ---------------------------------------------------------------------------
# 6. Different x86 flags -> different output
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_different_x86_flags(backend_exe, stress_mcb, tmp_path):
    a = compile_backend(backend_exe, stress_mcb, tmp_path / "a.bin",
                        seed=1001, flags=["--x86-dead-code"])
    b = compile_backend(backend_exe, stress_mcb, tmp_path / "b.bin",
                        seed=1001, flags=["--x86-poly-instrs"])
    assert _sha256(a) != _sha256(b), \
        "--x86-dead-code and --x86-poly-instrs should produce different output"


# ---------------------------------------------------------------------------
# 7. Transforms produce larger output
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_transforms_produce_larger_output(backend_exe, stress_mcb, tmp_path):
    plain = compile_backend(backend_exe, stress_mcb, tmp_path / "plain.bin",
                            seed=1001, flags=None)
    full = compile_backend(backend_exe, stress_mcb, tmp_path / "full.bin",
                           seed=1001, flags=ALL_FLAGS)
    assert full.stat().st_size > plain.stat().st_size, \
        "All-transforms binary should be larger than the plain binary"


# ---------------------------------------------------------------------------
# 8. All 10 variants are valid executables
# ---------------------------------------------------------------------------
@pytest.mark.backend
def test_all_variants_execute(backend_exe, loader_exe, stress_mcb, tmp_path):
    expected_rc = 0 if IS_WINDOWS else 42
    for seed in range(1001, 1011):
        out = compile_backend(backend_exe, stress_mcb,
                              tmp_path / f"s{seed}.bin",
                              seed=seed, flags=ALL_FLAGS)
        rc = run_loader(loader_exe, out)
        assert rc == expected_rc, (
            f"Seed {seed}: expected exit code {expected_rc}, got {rc}")
