"""Backend test fixtures: pre-built binaries, compile helpers."""
import subprocess
import sys
import os
from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent.parent
BACKEND_DIR = ROOT / "compiler" / "backend"
LOADERS_DIR = ROOT / "compiler" / "loaders"
BUNDLES_DIR = ROOT / "bundles"
EXAMPLES_DIR = ROOT / "docs" / "examples"
TESTS_DIR = ROOT / "tests"

IS_WINDOWS = sys.platform == "win32"

BACKEND_EXE = BACKEND_DIR / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")
LOADER_EXE = LOADERS_DIR / ("loader_win32.exe" if IS_WINDOWS else "loader_linux")

IR_FLAGS = [
    "--ir-obfuscate-names", "--ir-unfold", "--ir-substitute", "--ir-deadcode",
    "--ir-nops", "--ir-reorder-instrs", "--ir-reorder-locals", "--ir-reorder-blocks",
    "--ir-reorder-funcs",
]

X86_FLAGS = [
    "--x86-poly-instrs", "--x86-dead-code", "--x86-opaque", "--x86-junk-funcs",
    "--x86-harmless-calls", "--x86-shuffle-funcs",
]

ALL_FLAGS = IR_FLAGS + X86_FLAGS


@pytest.fixture(scope="session")
def backend_exe():
    """Path to pre-built backend_mystc.exe. Must run 'python build.py build' first."""
    assert BACKEND_EXE.exists(), (
        f"Backend not found at {BACKEND_EXE} -- run 'python build.py build' first")
    return BACKEND_EXE


@pytest.fixture(scope="session")
def loader_exe():
    """Path to pre-built loader stub. Must run 'python build.py build' first."""
    assert LOADER_EXE.exists(), (
        f"Loader not found at {LOADER_EXE} -- run 'python build.py build' first")
    return LOADER_EXE


def compile_mc(source_path, mcb_path, defines=None):
    """Frontend: .mc -> .mcb bytecode."""
    cmd = [sys.executable, "-m", "compiler.frontend.mystcc",
           str(source_path), "-o", str(mcb_path)]
    # Auto-detect platform define if none specified
    if defines is None:
        defines = ["WIN32"] if sys.platform == "win32" else ["LINUX"]
    for d in defines:
        cmd.append(f"-D{d}")
    r = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Frontend failed on {source_path}:\n{r.stderr}")
    return mcb_path


def compile_backend(backend_exe, mcb, bin_out, seed=1001, flags=None):
    """Backend: .mcb -> .bin PIC shellcode."""
    cmd = [str(backend_exe), str(mcb), "--pic", str(bin_out),
           "--seed", str(seed)]
    if flags:
        cmd.extend(flags)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(
            f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}")
    return bin_out


def run_loader(loader_exe, bin_path, timeout=30):
    """Run the loader on a .bin file, return exit code."""
    r = subprocess.run(
        [str(loader_exe), str(bin_path)],
        capture_output=True, text=True, timeout=timeout
    )
    return r.returncode


@pytest.fixture(scope="session")
def stress_mcb(backend_exe, tmp_path_factory):
    """Compile compiler_stress.mc -> .mcb once for the session."""
    if IS_WINDOWS:
        src = TESTS_DIR / "programs" / "compiler_stress.mc"
    else:
        src = TESTS_DIR / "programs" / "test_linux.mc"
    if not src.exists():
        pytest.skip(f"Test payload not found: {src}")
    d = tmp_path_factory.mktemp("stress_mcb")
    mcb = d / "stress.mcb"
    compile_mc(src, mcb)
    return mcb
