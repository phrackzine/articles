"""Tests for the various output formats the backend can produce."""
import subprocess
import sys

import pytest

from tests.backend.conftest import compile_backend, run_loader, BUNDLES_DIR, IS_WINDOWS

pytestmark = pytest.mark.backend


def test_pic_produces_valid_bin(backend_exe, loader_exe, stress_mcb, tmp_path):
    """--pic produces a loadable .bin shellcode file."""
    bin_path = tmp_path / "out.bin"
    compile_backend(backend_exe, stress_mcb, bin_path)
    assert bin_path.exists()
    assert bin_path.stat().st_size > 0
    rc = run_loader(loader_exe, bin_path)
    expected = 0 if IS_WINDOWS else 42
    assert rc == expected, f"Loader returned {rc}, expected {expected}"


@pytest.mark.skipif(sys.platform != "win32", reason="PE output is Windows-only")
def test_pe_produces_valid_executable(backend_exe, stress_mcb, tmp_path):
    """--pe-standalone produces a file starting with the MZ signature."""
    pe_path = tmp_path / "out.exe"
    r = subprocess.run(
        [str(backend_exe), str(stress_mcb),
         "--pe-standalone", str(pe_path)],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"
    assert pe_path.exists()
    header = pe_path.read_bytes()[:2]
    assert header == b"MZ", f"Expected MZ header, got {header!r}"


def test_transform_ir_produces_valid_mcb(backend_exe, stress_mcb, tmp_path):
    """--transform-ir produces a file with the MCBN magic header."""
    mcb2_path = tmp_path / "transformed.mcb"
    r = subprocess.run(
        [str(backend_exe), str(stress_mcb),
         "--transform-ir", str(mcb2_path),
         "--ir-unfold", "--seed", "1001"],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"
    assert mcb2_path.exists()
    header = mcb2_path.read_bytes()[:4]
    assert header == b"MCBN", f"Expected MCBN header, got {header!r}"


def test_transform_ir_roundtrip(backend_exe, loader_exe, stress_mcb, tmp_path):
    """transform-ir output can be re-compiled to PIC and executed."""
    mcb2_path = tmp_path / "transformed.mcb"
    r = subprocess.run(
        [str(backend_exe), str(stress_mcb),
         "--transform-ir", str(mcb2_path),
         "--ir-unfold", "--seed", "1001"],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"transform-ir failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"
    assert mcb2_path.exists()

    bin_path = tmp_path / "roundtrip.bin"
    compile_backend(backend_exe, mcb2_path, bin_path)
    assert bin_path.exists()
    assert bin_path.stat().st_size > 0

    rc = run_loader(loader_exe, bin_path)
    expected = 0 if IS_WINDOWS else 42
    assert rc == expected, f"Loader returned {rc} after roundtrip, expected {expected}"


def test_multiple_outputs_in_one_run(backend_exe, stress_mcb, tmp_path):
    """Multiple output flags in a single invocation produce all requested files."""
    bin_path = tmp_path / "multi.bin"
    mcb2_path = tmp_path / "multi.mcb"
    r = subprocess.run(
        [str(backend_exe), str(stress_mcb),
         "--pic", str(bin_path),
         "--transform-ir", str(mcb2_path),
         "--seed", "1001"],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"Backend failed (exit {r.returncode}):\n{r.stderr}\n{r.stdout}"
    assert bin_path.exists(), "--pic output not created"
    assert bin_path.stat().st_size > 0
    assert mcb2_path.exists(), "--transform-ir output not created"
    assert mcb2_path.stat().st_size > 0
