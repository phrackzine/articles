"""Test combined transform modes across multiple seeds."""
import pytest
from tests.backend.conftest import (
    compile_backend, run_loader, IR_FLAGS, X86_FLAGS, ALL_FLAGS, IS_WINDOWS,
)

EXPECTED_EXIT = 0 if IS_WINDOWS else 42
SEEDS = [1001, 1002, 1003]

COMBOS = {
    "all_ir":               IR_FLAGS,
    "all_x86":              X86_FLAGS,
    "all_ir_all_x86":       ALL_FLAGS,
    "x86_junk_and_shuffle": ["--x86-junk-funcs", "--x86-shuffle-funcs"],
    "x86_dead_and_opaque":  ["--x86-dead-code", "--x86-opaque"],
}


@pytest.mark.backend
@pytest.mark.parametrize("combo_name, flags", COMBOS.items(), ids=COMBOS.keys())
@pytest.mark.parametrize("seed", SEEDS)
def test_combo(backend_exe, loader_exe, stress_mcb, tmp_path, combo_name, flags, seed):
    """Compile stress_mcb with a combined set of flags at a given seed, run, check exit code."""
    bin_out = tmp_path / f"stress_{combo_name}_s{seed}.bin"
    compile_backend(backend_exe, stress_mcb, bin_out, seed=seed, flags=list(flags))
    rc = run_loader(loader_exe, bin_out)
    assert rc == EXPECTED_EXIT, (
        f"{combo_name} seed={seed} exited {rc}, expected {EXPECTED_EXIT}"
    )
