"""Register allocator stress tests.

Reorder-locals and reorder-blocks change register allocation patterns in ways
that expose RA bugs (different temp usage order, different block layout affecting
spill/unspill).  Combined with x86 transforms that insert junk code, they
stress the RA's spill/unspill logic across multiple PRNG seeds.
"""
import pytest

from tests.backend.conftest import compile_backend, run_loader, IS_WINDOWS

REGALLOC_FLAGS = [
    ["--ir-reorder-locals"],
    ["--ir-reorder-blocks"],
    ["--ir-reorder-locals", "--ir-reorder-blocks"],
    ["--ir-reorder-locals", "--x86-dead-code"],
    ["--ir-reorder-blocks", "--x86-poly-instrs"],
    ["--ir-reorder-locals", "--ir-reorder-blocks", "--x86-dead-code", "--x86-poly-instrs"],
]

SEEDS = [1001, 1002]

EXPECTED_EXIT = 0 if IS_WINDOWS else 42


def _flags_id(flags):
    """Short human-readable id for a flag combination."""
    return "+".join(f.lstrip("-") for f in flags)


@pytest.mark.backend
@pytest.mark.parametrize("seed", SEEDS, ids=[f"seed{s}" for s in SEEDS])
@pytest.mark.parametrize("flags", REGALLOC_FLAGS, ids=[_flags_id(f) for f in REGALLOC_FLAGS])
def test_regalloc_stress(backend_exe, loader_exe, stress_mcb, flags, seed, tmp_path):
    """Compile stress payload with RA-stressing flags, run, verify exit code."""
    bin_out = tmp_path / f"stress_s{seed}.bin"
    compile_backend(backend_exe, stress_mcb, bin_out, seed=seed, flags=flags)
    assert bin_out.exists(), f"Backend produced no output: {bin_out}"
    assert bin_out.stat().st_size > 0, "Backend produced empty .bin"

    rc = run_loader(loader_exe, bin_out)
    assert rc == EXPECTED_EXIT, (
        f"Loader exit {rc}, expected {EXPECTED_EXIT} "
        f"(seed={seed}, flags={flags})"
    )
