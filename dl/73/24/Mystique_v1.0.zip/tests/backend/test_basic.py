"""Basic backend tests: no transforms, baseline compilation and execution."""
import subprocess
import sys
from pathlib import Path

import pytest

from tests.backend.conftest import (
    compile_mc, compile_backend, run_loader,
    EXAMPLES_DIR, TESTS_DIR, ROOT, IS_WINDOWS,
)

pytestmark = pytest.mark.backend

# (source filename, expected exit code)
EXAMPLE_PROGRAMS = [
    ("simple_test.mc", 23),
    ("factorial.mc", 120),
    ("globals.mc", 50),
    ("linked_list.mc", 60),
]


# ---------- 1. Parametrized: compile and run each example ----------

@pytest.mark.parametrize("mc_file,expected_exit", EXAMPLE_PROGRAMS,
                         ids=[p[0] for p in EXAMPLE_PROGRAMS])
def test_example_compile_and_run(mc_file, expected_exit, backend_exe,
                                 loader_exe, tmp_path):
    """Compile .mc -> .mcb -> .bin (no transforms, seed=1001), run via loader."""
    src = EXAMPLES_DIR / mc_file
    mcb = tmp_path / mc_file.replace(".mc", ".mcb")
    bin_out = tmp_path / mc_file.replace(".mc", ".bin")

    compile_mc(src, mcb)
    compile_backend(backend_exe, mcb, bin_out, seed=1001)
    rc = run_loader(loader_exe, bin_out)
    assert rc == expected_exit, (
        f"{mc_file}: expected exit {expected_exit}, got {rc}")


# ---------- 2. .bin file is produced with non-zero size ----------

def test_bin_file_nonzero(backend_exe, tmp_path):
    """Backend produces a .bin file with non-zero size."""
    src = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"
    bin_out = tmp_path / "simple_test.bin"

    compile_mc(src, mcb)
    compile_backend(backend_exe, mcb, bin_out, seed=1001)

    assert bin_out.exists(), ".bin file was not created"
    assert bin_out.stat().st_size > 0, ".bin file is empty"


# ---------- 3. .mcb starts with magic bytes b'MCBN' ----------

def test_mcb_magic_bytes(tmp_path):
    """Frontend-produced .mcb file starts with the MCBN magic header."""
    src = EXAMPLES_DIR / "factorial.mc"
    mcb = tmp_path / "factorial.mcb"

    compile_mc(src, mcb)

    data = mcb.read_bytes()
    assert len(data) >= 4, ".mcb file is too small for a header"
    assert data[:4] == b"MCBN", (
        f"Expected magic b'MCBN', got {data[:4]!r}")


# ---------- 4. Stress test compiles and runs ----------

def test_stress_compile_and_run(backend_exe, loader_exe, stress_mcb, tmp_path):
    """compiler_stress.mc (Win) / test_linux.mc (Linux) compiles and runs."""
    bin_out = tmp_path / "stress.bin"
    compile_backend(backend_exe, stress_mcb, bin_out, seed=1001)

    rc = run_loader(loader_exe, bin_out)
    expected = 0 if IS_WINDOWS else 42
    assert rc == expected, (
        f"Stress test: expected exit {expected}, got {rc}")


# ---------- 5. No transforms still varies output via RA register-order shuffle ----------

def test_no_transforms_seed_varies_via_ra_shuffle(backend_exe, tmp_path):
    """Without IR/x86 transforms, different seeds still produce different bytes:
    the register allocator's PRNG-shuffled register preference order is
    unconditional, providing baseline polymorphism even with everything off."""
    src = EXAMPLES_DIR / "simple_test.mc"
    mcb = tmp_path / "simple_test.mcb"
    compile_mc(src, mcb)

    bin_a = tmp_path / "seed1001.bin"
    bin_b = tmp_path / "seed1002.bin"

    compile_backend(backend_exe, mcb, bin_a, seed=1001)
    compile_backend(backend_exe, mcb, bin_b, seed=1002)

    data_a = bin_a.read_bytes()
    data_b = bin_b.read_bytes()

    assert data_a != data_b, (
        f"Bins identical with no transforms — RA shuffle regressed? "
        f"seed 1001 = {len(data_a)} bytes, seed 1002 = {len(data_b)} bytes")


# ---------- 6. Nonexistent .mcb gives error exit ----------

def test_backend_error_on_missing_mcb(backend_exe, tmp_path):
    """Backend returns non-zero exit code for a nonexistent .mcb file."""
    fake_mcb = tmp_path / "does_not_exist.mcb"
    bin_out = tmp_path / "output.bin"

    r = subprocess.run(
        [str(backend_exe), str(fake_mcb), "--pic", str(bin_out),
         "--seed", "1001"],
        capture_output=True, text=True
    )
    assert r.returncode != 0, (
        "Backend should fail on nonexistent .mcb but exited 0")
