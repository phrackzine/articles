"""Tests for ide/bridge.py -- CompilerBridge class."""
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.tools

ROOT = Path(__file__).parent.parent.parent

# Ensure project root is on sys.path for imports
sys.path.insert(0, str(ROOT))

# Skip all tests if flask is not installed (bridge depends on it indirectly
# through the ide package, but the bridge itself only needs subprocess/pathlib)
# We try importing the bridge directly; skip if anything required is missing.
try:
    from ide.bridge import CompilerBridge
except ImportError as exc:
    pytest.skip(f"Cannot import CompilerBridge: {exc}", allow_module_level=True)

IS_WINDOWS = sys.platform == "win32"
BACKEND_EXE = ROOT / "compiler" / "backend" / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")

TEST_SOURCE = "int main() { return 42; }"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def bridge():
    """Instantiate a CompilerBridge. Skip if backend binary is missing."""
    if not BACKEND_EXE.exists():
        pytest.skip(f"Backend binary not found: {BACKEND_EXE}")
    return CompilerBridge(ROOT)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_bridge_instantiation(bridge):
    """CompilerBridge can be instantiated without error."""
    assert bridge is not None
    assert bridge.root == ROOT


def test_compile_to_ir_returns_dict(bridge):
    """compile_to_ir returns a dict with expected keys."""
    result = bridge.compile_to_ir(TEST_SOURCE)
    assert isinstance(result, dict), f"Expected dict, got {type(result).__name__}"
    # Should have at least mct, ir, mc_path
    assert "mct" in result, f"Missing 'mct' key. Keys: {list(result.keys())}"
    assert "mc_path" in result, f"Missing 'mc_path' key. Keys: {list(result.keys())}"


def test_compile_variants_returns_variants(bridge):
    """compile_variants with n=1 returns a dict with 'variants' key."""
    result = bridge.compile_variants(TEST_SOURCE, n=1, seed=1001,
                                     transform_flags=[])
    assert isinstance(result, dict), f"Expected dict, got {type(result).__name__}"
    assert "variants" in result, f"Missing 'variants' key. Keys: {list(result.keys())}"
    assert len(result["variants"]) == 1, (
        f"Expected 1 variant, got {len(result['variants'])}"
    )


def test_compile_variants_n3_returns_three(bridge):
    """compile_variants with n=3 returns 3 variants."""
    result = bridge.compile_variants(TEST_SOURCE, n=3, seed=1001,
                                     transform_flags=[])
    assert "variants" in result
    assert len(result["variants"]) == 3, (
        f"Expected 3 variants, got {len(result['variants'])}"
    )


def test_variant_has_bin_hex(bridge):
    """Each variant has a 'bin_hex' key with a hex string."""
    result = bridge.compile_variants(TEST_SOURCE, n=1, seed=1001,
                                     transform_flags=[])
    variant = result["variants"][0]
    assert "bin_hex" in variant, f"Missing 'bin_hex'. Keys: {list(variant.keys())}"
    hex_str = variant["bin_hex"]
    assert isinstance(hex_str, str), f"bin_hex should be str, got {type(hex_str).__name__}"
    assert len(hex_str) > 0, "bin_hex is empty"
    # Verify it's valid hex
    try:
        bytes.fromhex(hex_str)
    except ValueError:
        pytest.fail(f"bin_hex is not valid hex: {hex_str[:80]}...")


ALL_FLAGS = [
    "--ir-obfuscate-names", "--ir-unfold", "--ir-substitute", "--ir-deadcode",
    "--ir-nops", "--ir-reorder-instrs", "--ir-reorder-locals", "--ir-reorder-blocks",
    "--ir-reorder-funcs", "--x86-poly-instrs", "--x86-dead-code", "--x86-opaque",
    "--x86-junk-funcs", "--x86-harmless-calls", "--x86-shuffle-funcs",
]


def test_multiple_variants_differ_with_transforms(bridge):
    """Multiple variants with all transforms produce different hex (polymorphism)."""
    result = bridge.compile_variants(
        TEST_SOURCE, n=3, seed=1001,
        transform_flags=ALL_FLAGS,
    )
    variants = result["variants"]
    assert len(variants) == 3

    hex_values = [v.get("bin_hex", "") for v in variants]
    # At least two of the three should differ
    unique = set(hex_values)
    assert len(unique) >= 2, (
        f"Expected polymorphic variants to differ, but all {len(variants)} "
        f"are identical (len={len(hex_values[0])} chars)"
    )
