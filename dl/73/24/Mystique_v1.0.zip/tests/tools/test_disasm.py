"""Tests for utils/disasm.py -- x86 disassembler script."""
import json
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.tools

ROOT = Path(__file__).parent.parent.parent
UTILS_DIR = ROOT / "utils"
EXAMPLES_DIR = ROOT / "docs" / "examples"
BACKEND_DIR = ROOT / "compiler" / "backend"
BUNDLES_DIR = ROOT / "bundles"

IS_WINDOWS = sys.platform == "win32"
BACKEND_EXE = BACKEND_DIR / ("backend_mystc.exe" if IS_WINDOWS else "backend_mystc")


# ---------------------------------------------------------------------------
# Helper: compile a .mc example to .bin via frontend + backend
# ---------------------------------------------------------------------------

def _compile_to_bin(mc_name, tmp_path):
    """Compile docs/examples/<mc_name> -> .mcb -> .bin, return bin path."""
    src = EXAMPLES_DIR / mc_name
    if not src.exists():
        pytest.skip(f"Example source not found: {src}")
    if not BACKEND_EXE.exists():
        pytest.skip(f"Backend not found: {BACKEND_EXE}")

    mcb = tmp_path / "prog.mcb"
    bin_path = tmp_path / "prog.bin"

    platform_def = "WIN32" if sys.platform == "win32" else "LINUX"
    subprocess.run(
        [sys.executable, "-m", "compiler.frontend.mystcc",
         str(src), "-o", str(mcb), f"-D{platform_def}"],
        cwd=str(ROOT), check=True, capture_output=True,
    )
    subprocess.run(
        [str(BACKEND_EXE), str(mcb), "--pic", str(bin_path),
         "--seed", "1001"],
        check=True, capture_output=True,
    )
    return bin_path


def _run_disasm(bin_path, extra_args=None):
    """Run disasm.py on a .bin file, return CompletedProcess."""
    # disasm.py expects: disasm.py <file.bin> [--json|-j]  (path first)
    cmd = [sys.executable, str(UTILS_DIR / "disasm.py"), str(bin_path)]
    if extra_args:
        cmd.extend(extra_args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=30)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_text_output_nonempty_and_has_mnemonics(tmp_path):
    """Text output is non-empty and contains common x86 mnemonics."""
    bin_path = _compile_to_bin("simple_test.mc", tmp_path)
    r = _run_disasm(bin_path)
    assert r.returncode == 0, f"disasm.py failed: {r.stderr}"

    out = r.stdout.lower()
    assert len(out) > 0, "Disassembly output is empty"

    # Expect at least one common mnemonic
    common = ["push", "mov", "ret", "call", "sub", "add"]
    found = [m for m in common if m in out]
    assert len(found) >= 1, (
        f"Expected at least one common mnemonic from {common} in output, "
        f"but found none. First 500 chars:\n{r.stdout[:500]}"
    )


def test_json_output_is_valid(tmp_path):
    """JSON output (--json flag) parses as valid JSON."""
    bin_path = _compile_to_bin("simple_test.mc", tmp_path)
    r = _run_disasm(bin_path, extra_args=["--json"])
    assert r.returncode == 0, f"disasm.py --json failed: {r.stderr}"

    try:
        data = json.loads(r.stdout)
    except json.JSONDecodeError as e:
        pytest.fail(f"JSON output is not valid JSON: {e}\nFirst 500 chars:\n{r.stdout[:500]}")

    assert isinstance(data, dict), f"Expected top-level dict, got {type(data).__name__}"


def test_json_output_has_expected_fields(tmp_path):
    """JSON output contains expected fields on instructions."""
    bin_path = _compile_to_bin("simple_test.mc", tmp_path)
    r = _run_disasm(bin_path, extra_args=["--json"])
    assert r.returncode == 0, f"disasm.py --json failed: {r.stderr}"

    data = json.loads(r.stdout)
    assert "instructions" in data, "JSON missing 'instructions' key"

    instrs = data["instructions"]
    assert len(instrs) > 0, "No instructions in JSON output"

    first = instrs[0]
    # Check for expected fields: offset, bytes, text (as per disasm.py _instr())
    assert "offset" in first, f"Instruction missing 'offset': {first}"
    assert "bytes" in first, f"Instruction missing 'bytes': {first}"
    assert "text" in first, f"Instruction missing 'text': {first}"


def test_empty_file_does_not_crash(tmp_path):
    """Disassembling a minimal/empty file doesn't crash (may error gracefully)."""
    # Create a minimal file with just the 20-byte header (zeros)
    minimal_bin = tmp_path / "empty.bin"
    # The .bin format has a 20-byte header; create one with code_size=0
    import struct
    header = struct.pack('<IIIII', 0, 0, 0, 0, 0)  # entry, code_size, data_size, extern_count, extern_info_size
    minimal_bin.write_bytes(header)

    r = _run_disasm(minimal_bin)
    # Should not crash with a traceback (returncode 0 or at least not a signal)
    # We just verify it ran without a Python exception (returncode != negative signal)
    assert r.returncode >= 0 or r.returncode == 0, (
        f"disasm.py crashed on empty file: exit={r.returncode}\n{r.stderr}"
    )


def test_multiple_instructions_in_output(tmp_path):
    """Disassembly of a real program has more than 5 lines of instructions."""
    bin_path = _compile_to_bin("simple_test.mc", tmp_path)
    r = _run_disasm(bin_path)
    assert r.returncode == 0, f"disasm.py failed: {r.stderr}"

    # Count lines that look like disassembly (have hex offset at start)
    lines = [l for l in r.stdout.splitlines() if l.strip()]
    # The text output has header lines + instruction lines; instructions are indented with hex offset
    instr_lines = [l for l in lines if l.strip() and ":" in l.split()[0] if l.strip()[0].isdigit()]
    # Fallback: just count all non-empty lines
    total_lines = len(lines)
    assert total_lines > 5, (
        f"Expected more than 5 lines of output, got {total_lines}"
    )


def test_factorial_disasm_contains_call(tmp_path):
    """Disassembly of factorial.mc contains CALL (recursive function)."""
    bin_path = _compile_to_bin("factorial.mc", tmp_path)
    r = _run_disasm(bin_path)
    assert r.returncode == 0, f"disasm.py failed: {r.stderr}"

    out = r.stdout.upper()
    assert "CALL" in out, (
        f"Expected 'CALL' in factorial disassembly (recursion), "
        f"but not found. First 500 chars:\n{r.stdout[:500]}"
    )


def _make_bin_with_code(code_bytes, tmp_path, name="raw.bin"):
    """Write a minimal .bin containing only the given code bytes.

    Header is 20 bytes: entry=0, code_size=len(code), data/extern counts=0.
    """
    import struct
    header = struct.pack("<IIIII", 0, len(code_bytes), 0, 0, 0)
    path = tmp_path / name
    path.write_bytes(header + bytes(code_bytes))
    return path


def test_syscall_opcodes_decoded(tmp_path):
    """INT 0x80, SYSCALL (0F 05), SYSENTER (0F 34) all decode correctly."""
    # CD 80    INT 0x80   (Linux 32-bit syscall)
    # 0F 05    SYSCALL    (x86-64; decoder still recognizes it)
    # 0F 34    SYSENTER
    # C3       RET        (terminator so the walker stops cleanly)
    bin_path = _make_bin_with_code([0xCD, 0x80, 0x0F, 0x05, 0x0F, 0x34, 0xC3], tmp_path)
    r = _run_disasm(bin_path)
    assert r.returncode == 0, f"disasm.py failed: {r.stderr}"

    out = r.stdout.upper()
    assert "INT 0X80" in out, f"INT 0x80 not decoded:\n{r.stdout}"
    assert "SYSCALL" in out, f"SYSCALL not decoded:\n{r.stdout}"
    assert "SYSENTER" in out, f"SYSENTER not decoded:\n{r.stdout}"


def test_int_imm8_non_0x80(tmp_path):
    """INT with imm8 != 0x80 decodes as `INT 0xNN`, not `INT 0x80 ; syscall`."""
    # CD 03    INT 0x03
    # C3       RET
    bin_path = _make_bin_with_code([0xCD, 0x03, 0xC3], tmp_path)
    r = _run_disasm(bin_path)
    assert r.returncode == 0, f"disasm.py failed: {r.stderr}"

    out = r.stdout.upper()
    assert "INT 0X03" in out, f"INT 0x03 not decoded:\n{r.stdout}"
    assert "SYSCALL" not in out, f"Non-0x80 INT should not be labeled syscall:\n{r.stdout}"


def test_syscall_opcodes_in_json(tmp_path):
    """Syscall mnemonics also appear in --json instruction text fields."""
    bin_path = _make_bin_with_code([0xCD, 0x80, 0x0F, 0x05, 0x0F, 0x34, 0xC3], tmp_path)
    r = _run_disasm(bin_path, extra_args=["--json"])
    assert r.returncode == 0, f"disasm.py --json failed: {r.stderr}"

    data = json.loads(r.stdout)
    texts = " ".join(ins["text"].upper() for ins in data["instructions"])
    assert "INT 0X80" in texts
    assert "SYSCALL" in texts
    assert "SYSENTER" in texts
