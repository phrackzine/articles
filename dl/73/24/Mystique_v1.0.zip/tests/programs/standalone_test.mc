// standalone_test.mc - Exercises all stdlib functions for standalone PE/ELF
//
// Tests: malloc, free, write(fd=1), open, read, close, exit
// Also: global variables, string literals, pointer arithmetic
//
// Expected exit code: 42

#include "../../compiler/backend/stdlib.mc"

int g_pass_count;
int g_fail_count;

void print_str(char* s) {
    int len;
    len = 0;
    while (s[len] != 0) {
        len = len + 1;
    }
    write(1, s, len);
}

void t_print_int(int n) {
    char buf[16];
    int i;
    int neg;

    if (n == 0) {
        print_str("0");
        return;
    }
    neg = 0;
    if (n < 0) {
        neg = 1;
        n = 0 - n;
    }
    i = 0;
    while (n > 0) {
        buf[i] = (n % 10) + 48;
        n = n / 10;
        i = i + 1;
    }
    if (neg != 0) {
        buf[i] = 45;
        i = i + 1;
    }
    // Reverse
    int lo;
    int hi;
    char tmp;
    lo = 0;
    hi = i - 1;
    while (lo < hi) {
        tmp = buf[lo];
        buf[lo] = buf[hi];
        buf[hi] = tmp;
        lo = lo + 1;
        hi = hi - 1;
    }
    write(1, buf, i);
}

void check(char* name, int cond) {
    if (cond != 0) {
        print_str("  PASS ");
        print_str(name);
        print_str("\n");
        g_pass_count = g_pass_count + 1;
    } else {
        print_str("  FAIL ");
        print_str(name);
        print_str("\n");
        g_fail_count = g_fail_count + 1;
    }
}

int main() {
    int* p;
    int* q;
    int i;
    int fd;
    char rbuf[64];
    char wbuf[4];
    int n;

    g_pass_count = 0;
    g_fail_count = 0;

    print_str("=== standalone_test ===\n");

    // --- Test 1: malloc + write + read back + free ---
    print_str("[1] malloc/free\n");
    p = malloc(100);
    check("malloc returned non-null", p != 0);
    p[0] = 12345;
    p[24] = 99999;
    check("write/read p[0]", p[0] == 12345);
    check("write/read p[24]", p[24] == 99999);
    free(p);
    check("free completed", 1);

    // --- Test 2: multiple allocations ---
    print_str("[2] multiple allocs\n");
    p = malloc(40);
    q = malloc(40);
    check("two allocs differ", p != q);
    p[0] = 111;
    q[0] = 222;
    check("no overlap", p[0] == 111);
    check("no overlap q", q[0] == 222);
    free(q);
    free(p);

    // --- Test 3: write to stdout (fd=1) ---
    print_str("[3] write stdout\n");
    check("write stdout works", 1);  // if we got here, it works

    // --- Test 4: global variables ---
    print_str("[4] globals\n");
    check("g_pass_count > 0", g_pass_count > 0);

    // --- Test 5: string literals ---
    print_str("[5] strings\n");
    char* s;
    s = "hello";
    check("string[0]='h'", s[0] == 104);
    check("string[4]='o'", s[4] == 111);
    check("string[5]=0", s[5] == 0);

    // --- Test 6: file I/O round-trip ---
    print_str("[6] file I/O\n");
    fd = open("_standalone_test_tmp.bin", 1);  // write mode
    check("open write", fd != -1);
    if (fd != -1) {
        wbuf[0] = 65;  // 'A'
        wbuf[1] = 66;  // 'B'
        wbuf[2] = 67;  // 'C'
        wbuf[3] = 0;
        n = write(fd, wbuf, 3);
        check("write 3 bytes", n == 3);
        close(fd);

        fd = open("_standalone_test_tmp.bin", 0);  // read mode
        check("open read", fd != -1);
        if (fd != -1) {
            rbuf[0] = 0;
            rbuf[1] = 0;
            rbuf[2] = 0;
            n = read(fd, rbuf, 3);
            check("read 3 bytes", n == 3);
            check("read content[0]='A'", rbuf[0] == 65);
            check("read content[1]='B'", rbuf[1] == 66);
            check("read content[2]='C'", rbuf[2] == 67);
            close(fd);
        }
    }

    // --- Summary ---
    print_str("=== ");
    t_print_int(g_pass_count);
    print_str(" passed, ");
    t_print_int(g_fail_count);
    print_str(" failed ===\n");

    // Clean up temp file (best effort - no unlink, but that's ok)

    if (g_fail_count != 0) {
        exit(1);
    }
    exit(42);
    return 0;
}
