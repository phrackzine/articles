// test_linux.mc - Linux-compatible compiler stress test
//
// Uses stdlib functions:
//   write(fd, buf, count), malloc, free, exit
//
// Expected exit code: 42

#include "../../compiler/backend/stdlib.mc"

int g_fd;

void print_str(char* s) {
    int len;
    len = 0;
    while (s[len] != 0) {
        len = len + 1;
    }
    write(g_fd, s, len);
}

void t_print_int(int n) {
    char buf[16];
    int i;
    int neg;

    if (n == 0) {
        print_str("0");
        return;
    }
    neg = 0;
    if (n < 0) {
        neg = 1;
        n = 0 - n;
    }
    i = 15;
    buf[i] = 0;
    while (n > 0) {
        i = i - 1;
        buf[i] = 48 + (n - ((n / 10) * 10));
        n = n / 10;
    }
    if (neg != 0) {
        i = i - 1;
        buf[i] = 45;
    }
    print_str(&buf[i]);
}

// Section 1: arithmetic
int test_arithmetic() {
    int a;
    int b;
    int ok;
    a = 17;
    b = 5;
    ok = 1;
    if (a + b != 22)  { ok = 0; }
    if (a - b != 12)  { ok = 0; }
    if (a * b != 85)  { ok = 0; }
    if (a / b != 3)   { ok = 0; }
    if (a - (a / b) * b != 2) { ok = 0; }  // a % b
    return ok;
}

// Section 2: bitwise and shifts
int test_bitwise() {
    int x;
    int ok;
    x = 0xA5;
    ok = 1;
    if ((x & 0x0F) != 5)    { ok = 0; }
    if ((x | 0x0F) != 0xAF) { ok = 0; }
    if ((x ^ 0xFF) != 0x5A) { ok = 0; }
    if ((x << 2) != 0x294)  { ok = 0; }
    if ((x >> 2) != 0x29)   { ok = 0; }
    return ok;
}

// Section 3: loops
int test_loops() {
    int sum;
    int i;
    sum = 0;
    i = 1;
    while (i <= 100) {
        sum = sum + i;
        i = i + 1;
    }
    if (sum != 5050) {
        return 0;
    }
    // break/continue
    sum = 0;
    i = 0;
    while (i < 20) {
        i = i + 1;
        if (i - ((i / 2) * 2) == 0) {
            continue;
        }
        if (i > 9) {
            break;
        }
        sum = sum + i;
    }
    if (sum != 25) {  // 1+3+5+7+9
        return 0;
    }
    return 1;
}

// Section 4: recursion
int fib(int n) {
    if (n <= 1) {
        return n;
    }
    return fib(n - 1) + fib(n - 2);
}

int test_recursion() {
    if (fib(10) != 55)  { return 0; }
    if (fib(15) != 610) { return 0; }
    return 1;
}

// Section 5: pointers and arrays
int test_pointers() {
    int arr[8];
    int* p;
    int i;
    int sum;

    i = 0;
    while (i < 8) {
        arr[i] = i * i;
        i = i + 1;
    }
    sum = 0;
    p = &arr[0];
    i = 0;
    while (i < 8) {
        sum = sum + p[i];
        i = i + 1;
    }
    // 0+1+4+9+16+25+36+49 = 140
    if (sum != 140) { return 0; }
    return 1;
}

// Section 6: structs
struct Point {
    int x;
    int y;
};

int test_structs() {
    struct Point p;
    struct Point* q;
    p.x = 3;
    p.y = 4;
    q = &p;
    if (q->x != 3) { return 0; }
    if (q->y != 4) { return 0; }
    q->x = 10;
    if (p.x != 10) { return 0; }
    return 1;
}

// Section 7: malloc/free
int test_malloc() {
    int* buf;
    int i;
    int sum;

    buf = malloc(40);
    if (buf == 0) { return 0; }
    i = 0;
    while (i < 10) {
        buf[i] = i + 1;
        i = i + 1;
    }
    sum = 0;
    i = 0;
    while (i < 10) {
        sum = sum + buf[i];
        i = i + 1;
    }
    free(buf);
    if (sum != 55) { return 0; }
    return 1;
}

int main(int _api) {
    int pass;
    int fail;

    g_fd = 1;  // stdout fd on Linux (and Windows HANDLE 1 is also stdout by coincidence)

    print_str("Linux loader test\n");

    pass = 0;
    fail = 0;

    print_str("  [1] arithmetic   ");
    if (test_arithmetic()) { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [2] bitwise      ");
    if (test_bitwise())    { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [3] loops        ");
    if (test_loops())      { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [4] recursion    ");
    if (test_recursion())  { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [5] pointers     ");
    if (test_pointers())   { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [6] structs      ");
    if (test_structs())    { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("  [7] malloc/free  ");
    if (test_malloc())     { print_str("PASS\n"); pass = pass + 1; }
    else                   { print_str("FAIL\n"); fail = fail + 1; }

    print_str("Result: ");
    t_print_int(pass);
    print_str("/7 pass");
    if (fail != 0) {
        print_str(", ");
        t_print_int(fail);
        print_str(" FAIL");
    }
    print_str("\n");

    if (fail != 0) {
        return 1;
    }
    return 42;
}
