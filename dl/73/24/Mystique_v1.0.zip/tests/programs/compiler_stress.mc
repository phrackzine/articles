// compiler_stress.mc - Comprehensive MystC compiler stress test
//
// Exercises every language feature:
//   arithmetic, bitwise, shifts, comparisons, logical ops,
//   if/else chains, while, for, break, continue,
//   recursion, mutual recursion, global variables,
//   pointers, double pointers, arrays, structs, linked lists,
//   sizeof, compound assignment (+=/-=), register pressure.
//
// Output: prints section-by-section progress via WriteFile.
// Expected exit code: 0  (all 22 sections pass)

// ============================================================
// Platform APIs via stdlib.mc
// ============================================================

#include "../../compiler/backend/stdlib.mc"

// ============================================================
// Struct definitions
// ============================================================

struct Point {
    int x;
    int y;
};

struct ListNode {
    int val;
    struct ListNode* next;
};

// ============================================================
// Globals
// ============================================================

int g_counter;
int g_accum;

// ============================================================
// I/O helpers (WriteFile to stdout)
// g_stdout, init_io, str_len come from stdlib.mc
// ============================================================

void write_str(char* s) {
    int len;
    int written;
    len = 0;
    while (s[len] != 0) { len = len + 1; }
    WriteFile(g_stdout, s, len, &written, 0);
}

void write_int(int n) {
    char buf[20];
    int i;
    int neg;
    if (n == 0) { write_str("0"); return; }
    neg = 0;
    if (n < 0) { neg = 1; n = 0 - n; }
    i = 19;
    buf[i] = 0;
    while (n > 0) {
        i = i - 1;
        buf[i] = (n - (n / 10) * 10) + 48;
        n = n / 10;
    }
    if (neg != 0) { i = i - 1; buf[i] = 45; }
    write_str(&buf[i]);
}

void write_section(int n, char* name) {
    write_str("[");
    write_int(n);
    write_str("] ");
    write_str(name);
    write_str(" ... ");
}

void write_result(int errs) {
    if (errs == 0) {
        write_str("PASS\n");
    } else {
        write_str("FAIL (");
        write_int(errs);
        write_str(" errors)\n");
    }
}

// ============================================================
// Section 1: Arithmetic
// ============================================================

int test_arith() {
    int a;
    int b;
    int err;
    err = 0;
    a = 17;
    b = 5;
    if (a + b != 22)            err = err + 1;
    if (a - b != 12)            err = err + 1;
    if (a * b != 85)            err = err + 1;
    if (a / b != 3)             err = err + 1;  // truncates toward zero
    if (a % b != 2)             err = err + 1;
    if (-a != -17)              err = err + 1;
    if (a * -1 != -17)          err = err + 1;
    if (-b * -b != 25)          err = err + 1;
    if (100 / 10 / 2 != 5)      err = err + 1;  // left-associative
    if (100 % 30 != 10)         err = err + 1;
    if (a + b * 2 != 27)        err = err + 1;  // precedence: a+(b*2)
    if ((a + b) * 2 != 44)      err = err + 1;  // explicit grouping
    if (a - b - 2 != 10)        err = err + 1;  // left-assoc sub
    if (1000 * 1000 != 1000000) err = err + 1;
    return err;
}

// ============================================================
// Section 2: Bitwise Operations
// ============================================================

int test_bitwise() {
    int a;
    int b;
    int err;
    err = 0;
    a = 0xFF;
    b = 0x0F;
    if ((a & b) != 15)           err = err + 1;
    if ((a | b) != 255)          err = err + 1;
    if ((a ^ b) != 240)          err = err + 1;   // 0xFF ^ 0x0F = 0xF0
    if (~0 != -1)                err = err + 1;
    if ((~a & 0xFF) != 0)        err = err + 1;
    if ((0xAA & 0x55) != 0)      err = err + 1;
    if ((0xAA | 0x55) != 255)    err = err + 1;
    if ((0xAA ^ 0xAA) != 0)      err = err + 1;
    if ((0xF0 & 0x0F) != 0)      err = err + 1;
    if ((0xF0 | 0x0F) != 0xFF)   err = err + 1;
    if ((~255 & 0xFFFF) != 0xFF00) err = err + 1;
    return err;
}

// ============================================================
// Section 3: Shift Operations
// ============================================================

int test_shifts() {
    int a;
    int neg;
    int err;
    err = 0;
    a = 1;
    if ((a << 0)  != 1)     err = err + 1;
    if ((a << 1)  != 2)     err = err + 1;
    if ((a << 8)  != 256)   err = err + 1;
    if ((a << 16) != 65536) err = err + 1;
    if ((256 >> 1) != 128)  err = err + 1;
    if ((256 >> 8) != 1)    err = err + 1;
    if ((0xFF << 4)  != 0xFF0) err = err + 1;
    if ((0xFF0 >> 4) != 0xFF)  err = err + 1;
    a = 3;
    if ((8 >> a) != 1)  err = err + 1;
    if ((1 << a) != 8)  err = err + 1;
    if ((64 >> a) != 8) err = err + 1;
    // Variable-amount shift round-trip
    if ((128 >> a) != 16) err = err + 1;  // 128 >> 3 = 16
    if ((16 << a) != 128) err = err + 1;  // 16 << 3 = 128
    return err;
}

// ============================================================
// Section 4: All Comparison Operators
// ============================================================

int test_compare() {
    int a;
    int b;
    int err;
    err = 0;
    a = 10;
    b = 20;
    if (!(a < b))  err = err + 1;
    if (!(a <= b)) err = err + 1;
    if (a > b)     err = err + 1;
    if (a >= b)    err = err + 1;
    if (!(a != b)) err = err + 1;
    if (a == b)    err = err + 1;
    if (!(a == 10)) err = err + 1;
    a = 7;
    b = 7;
    if (!(a == b)) err = err + 1;
    if (!(a >= b)) err = err + 1;
    if (!(a <= b)) err = err + 1;
    if (a != b)    err = err + 1;
    if (a > b)     err = err + 1;
    if (a < b)     err = err + 1;
    a = -10;
    b = 10;
    if (!(a < b))  err = err + 1;
    if (!(a < 0))  err = err + 1;
    if (!(b > 0))  err = err + 1;
    if (!(a != b)) err = err + 1;
    if (a > 0)     err = err + 1;
    return err;
}

// ============================================================
// Section 5: Logical Operators (&&, ||, !)
// ============================================================

int test_logical() {
    int a;
    int b;
    int err;
    err = 0;
    a = 1;
    b = 0;
    if (!(a && a))  err = err + 1;
    if (a && b)     err = err + 1;
    if (!(a || b))  err = err + 1;
    if (b || b)     err = err + 1;
    if (!a)         err = err + 1;
    if (!!b)        err = err + 1;
    if (!(!b))      err = err + 1;
    a = 5;
    b = 10;
    if (!(a > 0 && b > 0))    err = err + 1;
    if (!(a < b || b < a))    err = err + 1;
    if (a < 0 || b < 0)       err = err + 1;
    if (!(a == 5 && b == 10)) err = err + 1;
    return err;
}

// ============================================================
// Section 6: If/else chains
// ============================================================

int classify(int n) {
    if (n < 0) {
        return -1;
    } else if (n == 0) {
        return 0;
    } else if (n < 10) {
        return 1;
    } else if (n < 100) {
        return 2;
    } else {
        return 3;
    }
}

int test_if() {
    int err;
    int x;
    err = 0;
    if (classify(-5)  != -1) err = err + 1;
    if (classify(0)   !=  0) err = err + 1;
    if (classify(5)   !=  1) err = err + 1;
    if (classify(50)  !=  2) err = err + 1;
    if (classify(500) !=  3) err = err + 1;
    x = 7;
    if (x > 0) {
        if (x < 10) {
            if (x == 7) {
                x = 42;
            }
        }
    }
    if (x != 42) err = err + 1;
    x = 0;
    if (1) x = 1;
    if (x != 1) err = err + 1;
    if (0) {
        x = 99;
    } else {
        x = 55;
    }
    if (x != 55) err = err + 1;
    return err;
}

// ============================================================
// Section 7: While loops with break and continue
// ============================================================

int test_while() {
    int err;
    int i;
    int sum;
    err = 0;

    // Sum 1..10 = 55
    sum = 0;
    i = 1;
    while (i <= 10) {
        sum = sum + i;
        i = i + 1;
    }
    if (sum != 55) err = err + 1;

    // Break: accumulate 1..5
    sum = 0;
    i = 0;
    while (1) {
        i = i + 1;
        if (i > 5) break;
        sum = sum + i;
    }
    if (sum != 15) err = err + 1;

    // Continue: skip evens, sum odd 1..9 = 25
    sum = 0;
    i = 0;
    while (i < 10) {
        i = i + 1;
        if (i % 2 == 0) continue;
        sum = sum + i;
    }
    if (sum != 25) err = err + 1;

    // Nested while: 4*4 = 16
    sum = 0;
    i = 1;
    while (i <= 4) {
        int j;
        j = 1;
        while (j <= 4) {
            sum = sum + 1;
            j = j + 1;
        }
        i = i + 1;
    }
    if (sum != 16) err = err + 1;

    return err;
}

// ============================================================
// Section 8: For loops
// ============================================================

int test_for() {
    int err;
    int i;
    int sum;
    err = 0;

    // Sum 0..9 = 45
    sum = 0;
    for (i = 0; i < 10; i = i + 1) {
        sum = sum + i;
    }
    if (sum != 45) err = err + 1;

    // Step variant: sum 1..5 = 15
    sum = 0;
    for (i = 1; i <= 5; i = i + 1) {
        sum = sum + i;
    }
    if (sum != 15) err = err + 1;

    // Break: 0+1+2+3+4 = 10
    sum = 0;
    for (i = 0; i < 100; i = i + 1) {
        if (i >= 5) break;
        sum = sum + i;
    }
    if (sum != 10) err = err + 1;

    // Continue: skip multiples of 3 in 1..10 → 1+2+4+5+7+8+10 = 37
    sum = 0;
    for (i = 1; i <= 10; i = i + 1) {
        if (i % 3 == 0) continue;
        sum = sum + i;
    }
    if (sum != 37) err = err + 1;

    // Nested: 5*5 = 25 iterations
    sum = 0;
    for (i = 0; i < 5; i = i + 1) {
        int j;
        for (j = 0; j < 5; j = j + 1) {
            sum = sum + 1;
        }
    }
    if (sum != 25) err = err + 1;

    // Decrement step: sum 10..1 = 55
    sum = 0;
    for (i = 10; i >= 1; i = i - 1) {
        sum = sum + i;
    }
    if (sum != 55) err = err + 1;

    return err;
}

// ============================================================
// Section 9: Recursion (factorial, Fibonacci, power)
// ============================================================

int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int fib_rec(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return fib_rec(n - 1) + fib_rec(n - 2);
}

int power(int base, int exp) {
    if (exp == 0) return 1;
    return base * power(base, exp - 1);
}

int test_recursion() {
    int err;
    err = 0;
    if (factorial(0)  != 1)       err = err + 1;
    if (factorial(1)  != 1)       err = err + 1;
    if (factorial(5)  != 120)     err = err + 1;
    if (factorial(10) != 3628800) err = err + 1;
    if (fib_rec(0)  != 0)   err = err + 1;
    if (fib_rec(1)  != 1)   err = err + 1;
    if (fib_rec(10) != 55)  err = err + 1;
    if (fib_rec(15) != 610) err = err + 1;
    if (power(2, 0)  != 1)     err = err + 1;
    if (power(2, 10) != 1024)  err = err + 1;
    if (power(3, 5)  != 243)   err = err + 1;
    if (power(10, 4) != 10000) err = err + 1;
    return err;
}

// ============================================================
// Section 10: Mutual Recursion
// ============================================================

int is_even(int n) {
    if (n == 0) return 1;
    return is_odd(n - 1);
}

int is_odd(int n) {
    if (n == 0) return 0;
    return is_even(n - 1);
}

int test_mutual() {
    int err;
    err = 0;
    if (!is_even(0))   err = err + 1;
    if ( is_odd(0))    err = err + 1;
    if (!is_even(10))  err = err + 1;
    if (!is_odd(7))    err = err + 1;
    if ( is_even(3))   err = err + 1;
    if (!is_odd(99))   err = err + 1;
    if (!is_even(100)) err = err + 1;
    if ( is_odd(100))  err = err + 1;
    return err;
}

// ============================================================
// Section 11: Global Variables
// ============================================================

void g_inc() {
    g_counter = g_counter + 1;
    g_accum = g_accum + g_counter;
}

int test_globals() {
    int err;
    int i;
    err = 0;
    g_counter = 0;
    g_accum = 0;
    for (i = 0; i < 5; i = i + 1) {
        g_inc();
    }
    // g_counter=5, g_accum=1+2+3+4+5=15
    if (g_counter != 5)  err = err + 1;
    if (g_accum   != 15) err = err + 1;
    g_counter = 100;
    g_counter = g_counter * 2 + g_accum;  // 215
    if (g_counter != 215) err = err + 1;
    // Second run: 10 calls, g_accum = 1+2+...+10 = 55
    g_counter = 0;
    g_accum = 0;
    for (i = 0; i < 10; i = i + 1) {
        g_inc();
    }
    if (g_counter != 10) err = err + 1;
    if (g_accum != 55)   err = err + 1;
    return err;
}

// ============================================================
// Section 12: Pointers and Address-of
// ============================================================

void swap(int* a, int* b) {
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

int sum_via_ptr(int* arr, int n) {
    int sum;
    int i;
    sum = 0;
    i = 0;
    while (i < n) {
        sum = sum + arr[i];
        i = i + 1;
    }
    return sum;
}

int test_pointers() {
    int err;
    int x;
    int y;
    int* p;
    int arr[5];
    err = 0;
    x = 10;
    y = 20;
    swap(&x, &y);
    if (x != 20) err = err + 1;
    if (y != 10) err = err + 1;
    p = &x;
    if (*p != 20) err = err + 1;
    *p = 99;
    if (x != 99) err = err + 1;
    // Double pointer
    int** pp;
    pp = &p;
    **pp = 77;
    if (x != 77) err = err + 1;
    // Array passed as pointer
    arr[0] = 1;
    arr[1] = 2;
    arr[2] = 3;
    arr[3] = 4;
    arr[4] = 5;
    if (sum_via_ptr(arr, 5) != 15) err = err + 1;
    return err;
}

// ============================================================
// Section 13: Arrays (char and int)
// ============================================================

int test_arrays() {
    int err;
    char buf[20];
    int arr[10];
    int i;
    int sum;
    err = 0;

    // Build "Hello\0" manually
    buf[0] = 'H'; buf[1] = 'e'; buf[2] = 'l';
    buf[3] = 'l'; buf[4] = 'o'; buf[5] = 0;
    if (str_len(buf) != 5) err = err + 1;
    if (buf[0] != 72) err = err + 1;  // 'H' = 72

    // Digit chars '0'..'9'
    for (i = 0; i < 10; i = i + 1) { buf[i] = 48 + i; }
    buf[10] = 0;
    if (str_len(buf) != 10) err = err + 1;
    if (buf[0] != '0') err = err + 1;
    if (buf[9] != '9') err = err + 1;

    // int array: arr[i]=i*2, sum=0+2+...+18=90
    sum = 0;
    for (i = 0; i < 10; i = i + 1) {
        arr[i] = i * 2;
        sum = sum + arr[i];
    }
    if (sum != 90) err = err + 1;

    // Reverse traversal (same sum)
    sum = 0;
    for (i = 9; i >= 0; i = i - 1) {
        sum = sum + arr[i];
    }
    if (sum != 90) err = err + 1;

    // Modify in-place
    for (i = 0; i < 10; i = i + 1) { arr[i] = arr[i] + 1; }
    if (arr[0] != 1)  err = err + 1;
    if (arr[9] != 19) err = err + 1;

    return err;
}

// ============================================================
// Section 14: Structs (value and pointer access)
// ============================================================

void point_set(struct Point* p, int x, int y) {
    p->x = x;
    p->y = y;
}

int point_dist_sq(struct Point* p) {
    return p->x * p->x + p->y * p->y;
}

void point_scale(struct Point* p, int factor) {
    p->x = p->x * factor;
    p->y = p->y * factor;
}

int test_structs() {
    int err;
    struct Point* pt;
    struct Point* pp;
    struct Point* a;
    struct Point* b;
    err = 0;
    pt = malloc(sizeof(struct Point));
    a  = malloc(sizeof(struct Point));
    b  = malloc(sizeof(struct Point));
    point_set(pt, 3, 4);
    if (pt->x != 3)  err = err + 1;
    if (pt->y != 4)  err = err + 1;
    if (point_dist_sq(pt) != 25) err = err + 1;
    pp = pt;
    if (pp->x != 3) err = err + 1;
    pp->x = 6;
    pp->y = 8;
    if (point_dist_sq(pp) != 100) err = err + 1;
    point_scale(pt, 2);
    if (pt->x != 12) err = err + 1;
    if (pt->y != 16) err = err + 1;
    point_set(a, 1, 2);
    point_set(b, 3, 4);
    if (a->x + b->x != 4) err = err + 1;
    if (a->y + b->y != 6) err = err + 1;
    if (point_dist_sq(a) != 5)  err = err + 1;
    if (point_dist_sq(b) != 25) err = err + 1;
    return err;
}

// ============================================================
// Section 15: Linked list (malloc + pointer chains)
// ============================================================

struct ListNode* node_new(int val) {
    struct ListNode* n;
    n = malloc(8);
    n->val = val;
    n->next = 0;
    return n;
}

int list_sum(struct ListNode* head) {
    int sum;
    sum = 0;
    while (head != 0) {
        sum = sum + head->val;
        head = head->next;
    }
    return sum;
}

int list_len(struct ListNode* head) {
    int len;
    len = 0;
    while (head != 0) { len = len + 1; head = head->next; }
    return len;
}

struct ListNode* list_prepend(struct ListNode* head, int val) {
    struct ListNode* n;
    n = node_new(val);
    n->next = head;
    return n;
}

int test_list() {
    int err;
    int i;
    struct ListNode* head;
    err = 0;
    // Build 1->2->3->4->5
    head = 0;
    head = list_prepend(head, 5);
    head = list_prepend(head, 4);
    head = list_prepend(head, 3);
    head = list_prepend(head, 2);
    head = list_prepend(head, 1);
    if (list_len(head) != 5)  err = err + 1;
    if (list_sum(head) != 15) err = err + 1;
    if (head->val != 1)       err = err + 1;
    // Build 1->2->...->10 via loop
    head = 0;
    for (i = 10; i >= 1; i = i - 1) {
        head = list_prepend(head, i);
    }
    if (list_len(head) != 10) err = err + 1;
    if (list_sum(head) != 55) err = err + 1;
    return err;
}

// ============================================================
// Section 16: sizeof operator
// ============================================================

int test_sizeof() {
    int err;
    err = 0;
    if (sizeof(int)  != 4) err = err + 1;
    if (sizeof(char) != 1) err = err + 1;
    if (sizeof(int*) != 4) err = err + 1;
    if (sizeof(struct Point)    != 8) err = err + 1;
    if (sizeof(struct ListNode) != 8) err = err + 1;
    return err;
}

// ============================================================
// Section 17: Compound Assignment (+=, -=)
// ============================================================

int test_compound() {
    int a;
    int err;
    int i;
    err = 0;
    a = 10;
    a += 5;
    if (a != 15) err = err + 1;
    a -= 3;
    if (a != 12) err = err + 1;
    a += a;     // 24
    if (a != 24) err = err + 1;
    // Loop with +=: sum 1..10 = 55
    a = 0;
    for (i = 1; i <= 10; i = i + 1) { a += i; }
    if (a != 55) err = err + 1;
    // Loop with -=: 100 - 55 = 45
    a = 100;
    for (i = 1; i <= 10; i = i + 1) { a -= i; }
    if (a != 45) err = err + 1;
    return err;
}

// ============================================================
// Section 18: Register Pressure
// ============================================================

int reg_helper(int a, int b, int c, int d) {
    return a * b + c * d;
}

int test_regpressure() {
    int a; int b; int c; int d;
    int e; int f; int g; int h;
    int sum; int r1; int r2; int r3;
    int x; int y; int z; int q;
    int err;
    err = 0;
    a = 1; b = 2; c = 3; d = 4;
    e = 5; f = 6; g = 7; h = 8;
    // All live simultaneously
    sum = a + b + c + d + e + f + g + h;
    if (sum != 36) err = err + 1;
    // Cross-products
    r1 = a * b + c * d;      // 2 + 12 = 14
    r2 = e * f - g * h;      // 30 - 56 = -26
    r3 = r1 + r2;            // -12
    if (r1 != 14)  err = err + 1;
    if (r2 != -26) err = err + 1;
    if (r3 != -12) err = err + 1;
    // Shift + bitwise
    x = a << b;           // 1<<2 = 4
    y = c | (d << e);     // 3|(4<<5)=3|128=131
    z = (g & h) ^ f;      // (7&8)^6=0^6=6
    if (x != 4)   err = err + 1;
    if (y != 131) err = err + 1;
    if (z != 6)   err = err + 1;
    // Multi-arg call: reg_helper(3,7,11,15)=3*7+11*15=21+165=186
    q = reg_helper(a + b, c + d, e + f, g + h);
    if (q != 186) err = err + 1;
    // Verify originals intact after call
    if (a + b + c + d + e + f + g + h != 36) err = err + 1;
    return err;
}

// ============================================================
// Section 19: Char literals and XOR checksum
// ============================================================

int test_chars() {
    int err;
    char buf[8];
    int i;
    int n;
    int cs;
    err = 0;
    buf[0] = 'A'; buf[1] = 'B'; buf[2] = 'C';
    buf[3] = 'D'; buf[4] = 'E'; buf[5] = 0;
    if (buf[0] != 65) err = err + 1;
    if (buf[4] != 69) err = err + 1;
    n = 0;
    while (buf[n] != 0) { n = n + 1; }
    if (n != 5) err = err + 1;
    // XOR checksum of 'A'..'E' = 65^66^67^68^69 = 65
    cs = 0;
    for (i = 0; i < n; i = i + 1) { cs = cs ^ buf[i]; }
    if (cs != 65) err = err + 1;
    buf[0] = 'a'; buf[1] = 'z';
    if (buf[0] != 97)  err = err + 1;
    if (buf[1] != 122) err = err + 1;
    if (buf[1] - buf[0] != 25) err = err + 1;
    buf[2] = 0;
    n = 0;
    while (buf[n] != 0) { n = n + 1; }
    if (n != 2) err = err + 1;
    return err;
}

// ============================================================
// Section 20: Nested function calls
// ============================================================

int add2(int a, int b) { return a + b; }
int mul2(int a, int b) { return a * b; }
int sub2(int a, int b) { return a - b; }

int max2(int a, int b) { if (a > b) return a; return b; }
int min2(int a, int b) { if (a < b) return a; return b; }

int test_nested() {
    int err;
    err = 0;
    if (add2(mul2(3, 4), sub2(10, 3)) != 19) err = err + 1;  // 12+7=19
    if (mul2(add2(1, 2), add2(3, 4))  != 21) err = err + 1;  // 3*7=21
    // Four-level: add2(add2(1,2),add2(3,4)) + add2(add2(5,6),add2(7,8)) = 10+26=36
    if (add2(add2(add2(1,2), add2(3,4)), add2(add2(5,6), add2(7,8))) != 36)
        err = err + 1;
    if (max2(max2(3, 7), max2(1, 5)) != 7) err = err + 1;
    if (min2(min2(8, 3), min2(6, 2)) != 2) err = err + 1;
    // mul2(add2(2,3), sub2(10,4)) - 1 = 30 - 1 = 29
    if (mul2(add2(2, 3), sub2(10, 4)) - 1 != 29) err = err + 1;
    return err;
}

// ============================================================
// Section 21: Array computation (squares, max, negate)
// ============================================================

int test_loop_array() {
    int arr[16];
    int i;
    int sum;
    int mx;
    int err;
    err = 0;
    // arr[i] = i*i
    for (i = 0; i < 16; i = i + 1) { arr[i] = i * i; }
    // Forward sum: 0^2+...+15^2 = 1240
    sum = 0;
    for (i = 0; i < 16; i = i + 1) { sum = sum + arr[i]; }
    if (sum != 1240) err = err + 1;
    // Reverse sum (same)
    sum = 0;
    for (i = 15; i >= 0; i = i - 1) { sum = sum + arr[i]; }
    if (sum != 1240) err = err + 1;
    // Max = arr[15] = 225
    mx = arr[0];
    for (i = 1; i < 16; i = i + 1) { if (arr[i] > mx) mx = arr[i]; }
    if (mx != 225) err = err + 1;
    // Negate in-place, re-sum = -1240
    for (i = 0; i < 16; i = i + 1) { arr[i] = -arr[i]; }
    sum = 0;
    for (i = 0; i < 16; i = i + 1) { sum = sum + arr[i]; }
    if (sum != -1240) err = err + 1;
    return err;
}

// ============================================================
// Section 22: pre/post increment and decrement
// ============================================================

int test_incdec() {
    int err;
    int a;
    int r;
    int sum;
    int i;
    err = 0;

    // pre-increment: returns new value, variable updated
    a = 5;
    r = ++a;
    if (r != 6) err = err + 1;
    if (a != 6) err = err + 1;

    // post-increment: returns old value, variable updated
    a = 5;
    r = a++;
    if (r != 5) err = err + 1;
    if (a != 6) err = err + 1;

    // pre-decrement: returns new value, variable updated
    a = 5;
    r = --a;
    if (r != 4) err = err + 1;
    if (a != 4) err = err + 1;

    // post-decrement: returns old value, variable updated
    a = 5;
    r = a--;
    if (r != 5) err = err + 1;
    if (a != 4) err = err + 1;

    // for-loop with ++ step: sum 0..4 = 10
    sum = 0;
    for (i = 0; i < 5; i++) { sum = sum + i; }
    if (sum != 10) err = err + 1;

    // for-loop with -- step: sum 4..0 = 10
    sum = 0;
    for (i = 4; i >= 0; i--) { sum = sum + i; }
    if (sum != 10) err = err + 1;

    return err;
}

// ============================================================
// Main: run all 22 sections, print per-section results
// ============================================================

int main() {
    int errors;
    int n;
    errors = 0;

    init_io();
    write_str("=== compiler_stress: 22 sections ===\n");

    write_section(1,  "arithmetic");
    n = test_arith();       errors = errors + n; write_result(n);

    write_section(2,  "bitwise");
    n = test_bitwise();     errors = errors + n; write_result(n);

    write_section(3,  "shifts");
    n = test_shifts();      errors = errors + n; write_result(n);

    write_section(4,  "comparisons");
    n = test_compare();     errors = errors + n; write_result(n);

    write_section(5,  "logical ops");
    n = test_logical();     errors = errors + n; write_result(n);

    write_section(6,  "if/else");
    n = test_if();          errors = errors + n; write_result(n);

    write_section(7,  "while loops");
    n = test_while();       errors = errors + n; write_result(n);

    write_section(8,  "for loops");
    n = test_for();         errors = errors + n; write_result(n);

    write_section(9,  "recursion");
    n = test_recursion();   errors = errors + n; write_result(n);

    write_section(10, "mutual recursion");
    n = test_mutual();      errors = errors + n; write_result(n);

    write_section(11, "globals");
    n = test_globals();     errors = errors + n; write_result(n);

    write_section(12, "pointers");
    n = test_pointers();    errors = errors + n; write_result(n);

    write_section(13, "arrays");
    n = test_arrays();      errors = errors + n; write_result(n);

    write_section(14, "structs");
    n = test_structs();     errors = errors + n; write_result(n);

    write_section(15, "linked list");
    n = test_list();        errors = errors + n; write_result(n);

    write_section(16, "sizeof");
    n = test_sizeof();      errors = errors + n; write_result(n);

    write_section(17, "compound assign");
    n = test_compound();    errors = errors + n; write_result(n);

    write_section(18, "register pressure");
    n = test_regpressure(); errors = errors + n; write_result(n);

    write_section(19, "char literals");
    n = test_chars();       errors = errors + n; write_result(n);

    write_section(20, "nested calls");
    n = test_nested();      errors = errors + n; write_result(n);

    write_section(21, "array computation");
    n = test_loop_array();  errors = errors + n; write_result(n);

    write_section(22, "inc/dec");
    n = test_incdec();      errors = errors + n; write_result(n);

    write_str("=== Total errors: ");
    write_int(errors);
    write_str(" ===\n");

    return errors;
}
