// extern_stress_linux.mc - Stress test for extern (libc) function resolution
//
// Exercises: extern declarations, libc function calls with various arg counts,
//   return value handling, mixing externs with internal functions, all language
//   features with I/O via externs.
//
// Expected exit code: 0 (all sections pass)

#include "../../compiler/backend/stdlib.mc"

int g_fd;
int g_fail;

void t_print(char* s) {
    int len;
    len = 0;
    while (s[len] != 0) {
        len = len + 1;
    }
    write(g_fd, s, len);
}

void print_num(int n) {
    char buf[16];
    int i;
    int neg;
    int digit;

    if (n == 0) {
        t_print("0");
        return;
    }

    neg = 0;
    if (n < 0) {
        neg = 1;
        n = 0 - n;
    }

    i = 15;
    buf[i] = 0;
    while (n > 0) {
        i = i - 1;
        digit = n - (n / 10) * 10;
        buf[i] = digit + 48;
        n = n / 10;
    }

    if (neg != 0) {
        i = i - 1;
        buf[i] = 45;
    }

    t_print(&buf[i]);
}

void check(char* label, int got, int expected) {
    t_print(label);
    if (got == expected) {
        t_print(" PASS\n");
    } else {
        t_print(" FAIL got=");
        print_num(got);
        t_print(" expected=");
        print_num(expected);
        t_print("\n");
        g_fail = g_fail + 1;
    }
}

// --- Section 1: basic extern calls with various arg counts ---

void test_externs() {
    int pid;
    int ppid;
    int clk;

    // 0-arg externs resolved via dlsym
    pid = getpid();
    ppid = getppid();
    clk = clock();

    // pid and ppid should be nonzero
    check("  pid!=0", pid != 0, 1);
    check("  ppid!=0", ppid != 0, 1);
    // clock() returns >= 0
    check("  clock>=0", clk >= 0, 1);
}

// --- Section 2: fibonacci ---

int fibonacci(int n) {
    int a;
    int b;
    int temp;
    int i;

    if (n <= 0) { return 0; }
    if (n == 1) { return 1; }

    a = 0;
    b = 1;
    i = 2;
    while (i <= n) {
        temp = a + b;
        a = b;
        b = temp;
        i = i + 1;
    }
    return b;
}

void test_fibonacci() {
    int checksum;
    int i;

    checksum = 0;
    i = 1;
    while (i <= 20) {
        checksum = checksum + fibonacci(i);
        i = i + 1;
    }
    check("  fib_checksum", checksum, 17710);
}

// --- Section 3: recursion + externs interleaved ---

int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

void test_recursion() {
    check("  fact(10)", factorial(10), 3628800);
    check("  fact(1)", factorial(1), 1);
    check("  fact(0)", factorial(0), 1);
}

// --- Section 4: struct + pointer ---

struct Point {
    int x;
    int y;
};

void test_structs() {
    struct Point p;
    struct Point* pp;
    p.x = 100;
    p.y = 200;
    pp = &p;
    check("  struct.x", pp->x, 100);
    check("  struct.y", pp->y, 200);
    pp->x = pp->x + pp->y;
    check("  struct.x+y", p.x, 300);
}

// --- Section 5: arrays + register pressure ---

void test_arrays() {
    int arr[10];
    int i;
    int sum;

    i = 0;
    while (i < 10) {
        arr[i] = i * i;
        i = i + 1;
    }

    sum = 0;
    i = 0;
    while (i < 10) {
        sum = sum + arr[i];
        i = i + 1;
    }
    // 0+1+4+9+16+25+36+49+64+81 = 285
    check("  arr_sum", sum, 285);
}

// --- Section 6: bitwise + shifts ---

void test_bitwise() {
    int a;
    int b;
    a = 0xFF00;
    b = 0x0FF0;
    check("  and", a & b, 0x0F00);
    check("  or", a | b, 0xFFF0);
    check("  xor", a ^ b, 0xF0F0);
    check("  shl", 1 << 10, 1024);
    check("  shr", 1024 >> 3, 128);
}

// --- Section 7: globals + control flow ---

int g_counter;

void increment() {
    g_counter = g_counter + 1;
}

void test_globals() {
    int i;
    g_counter = 0;
    i = 0;
    while (i < 100) {
        increment();
        i = i + 1;
    }
    check("  global_count", g_counter, 100);
}

// --- Section 8: malloc + free + pointer chains ---

void test_heap() {
    int* p;
    int* q;
    p = malloc(16);
    q = malloc(16);
    *p = 42;
    *q = 99;
    check("  heap_p", *p, 42);
    check("  heap_q", *q, 99);
    free(q);
    free(p);
}

// --- Main ---

int main() {
    g_fd = 1;
    g_fail = 0;

    t_print("=== extern_stress_linux ===\n");

    t_print("[1] externs\n");
    test_externs();

    t_print("[2] fibonacci\n");
    test_fibonacci();

    t_print("[3] recursion\n");
    test_recursion();

    t_print("[4] structs\n");
    test_structs();

    t_print("[5] arrays\n");
    test_arrays();

    t_print("[6] bitwise\n");
    test_bitwise();

    t_print("[7] globals\n");
    test_globals();

    t_print("[8] heap\n");
    test_heap();

    t_print("=== ");
    print_num(g_fail);
    t_print(" failures ===\n");

    return g_fail;
}
