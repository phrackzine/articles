"""
Token types for MystC lexer.
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Any


class TokenType(Enum):
    # Literals
    IDENT = auto()
    INT_LIT = auto()
    CHAR_LIT = auto()
    STRING_LIT = auto()

    # Keywords
    INT = auto()
    CHAR = auto()
    VOID = auto()
    STRUCT = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    RETURN = auto()
    BREAK = auto()
    CONTINUE = auto()
    SIZEOF = auto()
    EXTERN = auto()
    EMIT = auto()

    # Operators
    PLUS = auto()       # +
    MINUS = auto()      # -
    STAR = auto()       # *
    SLASH = auto()      # /
    PERCENT = auto()    # %
    AMP = auto()        # &
    PIPE = auto()       # |
    CARET = auto()      # ^
    TILDE = auto()      # ~
    BANG = auto()       # !
    LT = auto()         # <
    GT = auto()         # >
    EQ = auto()         # =
    DOT = auto()        # .
    ARROW = auto()      # ->
    PLUS_PLUS = auto()  # ++
    MINUS_MINUS = auto() # --
    LT_LT = auto()      # <<
    GT_GT = auto()      # >>
    AMP_AMP = auto()    # &&
    PIPE_PIPE = auto()  # ||
    EQ_EQ = auto()      # ==
    BANG_EQ = auto()    # !=
    LT_EQ = auto()      # <=
    GT_EQ = auto()      # >=
    PLUS_EQ = auto()    # +=
    MINUS_EQ = auto()   # -=

    # Punctuation
    LPAREN = auto()     # (
    RPAREN = auto()     # )
    LBRACKET = auto()   # [
    RBRACKET = auto()   # ]
    LBRACE = auto()     # {
    RBRACE = auto()     # }
    SEMICOLON = auto()  # ;
    COMMA = auto()      # ,

    # Special
    EOF = auto()
    ERROR = auto()


KEYWORDS = {
    'int': TokenType.INT,
    'char': TokenType.CHAR,
    'void': TokenType.VOID,
    'struct': TokenType.STRUCT,
    'if': TokenType.IF,
    'else': TokenType.ELSE,
    'while': TokenType.WHILE,
    'for': TokenType.FOR,
    'return': TokenType.RETURN,
    'break': TokenType.BREAK,
    'continue': TokenType.CONTINUE,
    'sizeof': TokenType.SIZEOF,
    'extern': TokenType.EXTERN,
    'emit': TokenType.EMIT,
}


@dataclass
class Token:
    type: TokenType
    value: Any          # The actual value (string for IDENT, int for INT_LIT, etc.)
    line: int
    column: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, {self.line}:{self.column})"
