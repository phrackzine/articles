"""
Symbol table for MystC type checker.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from . import mystc_ast as ast


@dataclass
class StructInfo:
    """Information about a struct type."""
    name: str
    fields: Dict[str, ast.Type]  # field_name -> type
    field_offsets: Dict[str, int]  # field_name -> byte offset
    size: int
    align: int


@dataclass
class FuncInfo:
    """Information about a function."""
    name: str
    return_type: ast.Type
    param_types: List[ast.Type]
    param_names: List[str]
    is_extern: bool = False  # True for extern function declarations
    dll: str = ""  # DLL name for extern functions (e.g., "user32.dll")


@dataclass
class VarInfo:
    """Information about a variable."""
    name: str
    type: ast.Type
    is_global: bool = False
    is_param: bool = False
    param_index: int = -1
    local_index: int = -1


class Scope:
    """A single scope in the symbol table."""

    def __init__(self, parent: Optional['Scope'] = None):
        self.parent = parent
        self.variables: Dict[str, VarInfo] = {}

    def define(self, name: str, info: VarInfo) -> bool:
        """Define a variable in this scope. Returns False if already defined."""
        if name in self.variables:
            return False
        self.variables[name] = info
        return True

    def lookup(self, name: str) -> Optional[VarInfo]:
        """Look up a variable, searching parent scopes."""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def lookup_local(self, name: str) -> Optional[VarInfo]:
        """Look up a variable only in this scope."""
        return self.variables.get(name)


class SymbolTable:
    """Symbol table managing all scopes, structs, and functions."""

    def __init__(self):
        self.structs: Dict[str, StructInfo] = {}
        self.functions: Dict[str, FuncInfo] = {}
        self.global_scope = Scope()
        self.current_scope = self.global_scope
        self.scope_stack: List[Scope] = [self.global_scope]

        # Track local variable indices per function
        self.local_counter = 0

    def enter_scope(self):
        """Enter a new scope."""
        new_scope = Scope(self.current_scope)
        self.scope_stack.append(new_scope)
        self.current_scope = new_scope

    def exit_scope(self):
        """Exit the current scope."""
        if len(self.scope_stack) > 1:
            self.scope_stack.pop()
            self.current_scope = self.scope_stack[-1]

    def define_struct(self, info: StructInfo) -> bool:
        """Define a struct. Returns False if already defined."""
        if info.name in self.structs:
            return False
        self.structs[info.name] = info
        return True

    def lookup_struct(self, name: str) -> Optional[StructInfo]:
        """Look up a struct by name."""
        return self.structs.get(name)

    def define_function(self, info: FuncInfo) -> bool:
        """Define a function. Returns False if already defined."""
        if info.name in self.functions:
            return False
        self.functions[info.name] = info
        return True

    def lookup_function(self, name: str) -> Optional[FuncInfo]:
        """Look up a function by name."""
        return self.functions.get(name)

    def define_var(self, name: str, type_: ast.Type,
                   is_global: bool = False, is_param: bool = False,
                   param_index: int = -1) -> Optional[VarInfo]:
        """Define a variable in the current scope."""
        local_index = -1
        if not is_global and not is_param:
            local_index = self.local_counter
            self.local_counter += 1

        info = VarInfo(name, type_, is_global, is_param, param_index, local_index)

        if is_global:
            if not self.global_scope.define(name, info):
                return None
        else:
            if not self.current_scope.define(name, info):
                return None

        return info

    def lookup_var(self, name: str) -> Optional[VarInfo]:
        """Look up a variable by name."""
        return self.current_scope.lookup(name)

    def reset_locals(self):
        """Reset local variable counter (call when entering a new function)."""
        self.local_counter = 0


def compute_struct_layout(struct_def: ast.StructDef,
                          symbols: 'SymbolTable') -> StructInfo:
    """Compute the memory layout of a struct."""
    fields: Dict[str, ast.Type] = {}
    offsets: Dict[str, int] = {}
    current_offset = 0
    max_align = 1

    for field in struct_def.fields:
        field_type = field.type
        if field.array_size is not None:
            field_type = ast.ArrayType(field.type, field.array_size)

        size, align = get_type_size_align(field_type, symbols)

        # Align the field
        if current_offset % align != 0:
            current_offset += align - (current_offset % align)

        fields[field.name] = field_type
        offsets[field.name] = current_offset
        current_offset += size
        max_align = max(max_align, align)

    # Pad struct to alignment
    if current_offset % max_align != 0:
        current_offset += max_align - (current_offset % max_align)

    return StructInfo(struct_def.name, fields, offsets, current_offset, max_align)


def get_type_size_align(type_: ast.Type, symbols: 'SymbolTable') -> tuple:
    """Get the size and alignment of a type. Returns (size, align)."""
    if isinstance(type_, ast.PrimitiveType):
        if type_.base == ast.BaseType.CHAR:
            return (1, 1)
        elif type_.base == ast.BaseType.INT:
            return (4, 4)
        elif type_.base == ast.BaseType.VOID:
            return (0, 1)

    elif isinstance(type_, ast.PointerType):
        return (4, 4)  # 32-bit pointers

    elif isinstance(type_, ast.ArrayType):
        elem_size, elem_align = get_type_size_align(type_.element, symbols)
        return (elem_size * type_.size, elem_align)

    elif isinstance(type_, ast.StructType):
        struct_info = symbols.lookup_struct(type_.name)
        if struct_info:
            return (struct_info.size, struct_info.align)
        return (0, 1)  # Unknown struct

    return (0, 1)


def types_equal(a: ast.Type, b: ast.Type) -> bool:
    """Check if two types are equal."""
    if type(a) != type(b):
        return False

    if isinstance(a, ast.PrimitiveType):
        return a.base == b.base

    if isinstance(a, ast.PointerType):
        return types_equal(a.pointee, b.pointee)

    if isinstance(a, ast.ArrayType):
        return types_equal(a.element, b.element) and a.size == b.size

    if isinstance(a, ast.StructType):
        return a.name == b.name

    return False


def is_pointer_type(t: ast.Type) -> bool:
    """Check if a type is a pointer."""
    return isinstance(t, ast.PointerType)


def is_integer_type(t: ast.Type) -> bool:
    """Check if a type is an integer (int or char)."""
    if isinstance(t, ast.PrimitiveType):
        return t.base in (ast.BaseType.INT, ast.BaseType.CHAR)
    return False


def is_arithmetic_type(t: ast.Type) -> bool:
    """Check if a type supports arithmetic operations."""
    return is_integer_type(t)


def is_scalar_type(t: ast.Type) -> bool:
    """Check if a type is a scalar (integer or pointer)."""
    return is_integer_type(t) or is_pointer_type(t)


def get_pointer_base(t: ast.Type) -> Optional[ast.Type]:
    """Get the base type of a pointer, or None if not a pointer."""
    if isinstance(t, ast.PointerType):
        return t.pointee
    if isinstance(t, ast.ArrayType):
        return t.element
    return None


def can_convert(from_type: ast.Type, to_type: ast.Type) -> bool:
    """Check if from_type can be implicitly converted to to_type."""
    if types_equal(from_type, to_type):
        return True

    # int <-> char
    if is_integer_type(from_type) and is_integer_type(to_type):
        return True

    # Any pointer to void*
    if isinstance(to_type, ast.PointerType):
        if isinstance(to_type.pointee, ast.PrimitiveType):
            if to_type.pointee.base == ast.BaseType.VOID:
                if is_pointer_type(from_type):
                    return True

    # void* to any pointer
    if isinstance(from_type, ast.PointerType):
        if isinstance(from_type.pointee, ast.PrimitiveType):
            if from_type.pointee.base == ast.BaseType.VOID:
                if is_pointer_type(to_type):
                    return True

    # Array to pointer
    if isinstance(from_type, ast.ArrayType) and isinstance(to_type, ast.PointerType):
        return types_equal(from_type.element, to_type.pointee)

    # Integer 0 to pointer (null)
    if isinstance(from_type, ast.PrimitiveType) and is_pointer_type(to_type):
        return True  # We'll check for literal 0 in the type checker

    # Pointer to integer (for passing pointers as int arguments)
    if is_pointer_type(from_type) and is_integer_type(to_type):
        return True

    return False
