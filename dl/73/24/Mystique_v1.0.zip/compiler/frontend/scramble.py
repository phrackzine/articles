"""
scramble.py — Frontend pass: demote integer-literal global initializers into a
generated __init_globals function and scramble the original .data init values.

Effect on the .mcb:
  - Every global with init_kind == 1 (integer literal) gets its init_value
    replaced by a CRC32-derived scramble value of its name.
  - A new void function __init_globals is appended, containing one CONST+STORE
    pair per demoted global that restores the real init value at runtime.
  - A CALLV __init_globals is inserted at the head of the program's entry
    function (matching the backend's main-by-name entry convention).

Triggered by --scramble-globals on the frontend CLI. No-op if the compilation
unit has no entry function (library compile). Pure IR-level pass — no changes
to the bytecode format, no new opcodes, no new flags. Pointer/string/
uninitialized globals are left untouched (see filter rationale in
scramble_globals docstring).
"""

import zlib
from typing import Optional

from compiler.frontend.bytecode import (
    MCProgram, MCFunction, Block, Instruction,
    Opcode, TypeCode, Value, ValueKind,
)


ENTRY_FUNC_NAME = "main"
INIT_FUNC_NAME = "__init_globals"


def _scramble_value(name: str) -> int:
    """Deterministic per-name scramble value in signed-int32 range."""
    h = zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF
    if h & 0x80000000:
        h -= 0x100000000
    return h


def find_entry_function(program: MCProgram) -> Optional[MCFunction]:
    # Convention matches the Backend's entry detection (backend_mystc.c:2558).
    for func in program.functions:
        if func.name == ENTRY_FUNC_NAME and not func.is_extern:
            return func
    return None


def scramble_globals(program: MCProgram) -> int:
    """Demote integer-literal global initializers into __init_globals and
    scramble the .data init values. Returns the number of globals demoted.

    Filter: only globals with init_kind == 1 (integer literal) are eligible.
      - init_kind == 0 (uninitialized) → already zero in .data, nothing to do.
      - init_kind == 2 (string ref) → relocation-backed; demoting would move
        the same relocation from data init to code with no benefit.
    """
    entry = find_entry_function(program)
    if entry is None:
        return 0

    demoted = []  # (global_index, real_value, type_code)
    for idx, g in enumerate(program.globals):
        if g.init_kind != 1:
            continue
        demoted.append((idx, g.init_value, g.type_code))
        g.init_value = _scramble_value(g.name)
        # init_kind stays at 1 — still a constant initializer, just a different value.

    if not demoted:
        return 0

    # Build __init_globals body: CONST + STORE per demoted global, then RETV.
    block = Block(label="entry")
    program.add_string("entry")

    next_temp = 0
    for g_idx, real_value, tc in demoted:
        temp = Value(ValueKind.TEMP, index=next_temp)
        next_temp += 1
        block.instructions.append(Instruction(
            Opcode.CONST,
            dest=temp,
            arg1=Value(ValueKind.CONST_IMM, imm_value=real_value),
            type_code=TypeCode(tc),
        ))
        block.instructions.append(Instruction(
            Opcode.STORE,
            arg1=Value(ValueKind.GLOBAL, index=g_idx),
            arg2=temp,
            type_code=TypeCode(tc),
        ))
    block.instructions.append(Instruction(Opcode.RETV))

    init_func = MCFunction(
        name=INIT_FUNC_NAME,
        return_type=TypeCode.VOID,
        blocks=[block],
        num_temps=next_temp,
    )
    program.functions.append(init_func)
    program.add_string(INIT_FUNC_NAME)

    init_func_idx = len(program.functions) - 1
    if entry.blocks:
        entry.blocks[0].instructions.insert(0, Instruction(
            Opcode.CALLV,
            func_index=init_func_idx,
            nargs=0,
        ))

    program.build_indices()
    return len(demoted)
