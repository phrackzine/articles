"""
Abstract Syntax Tree node definitions for MystC.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any
from enum import Enum, auto


# ============================================================================
# Types
# ============================================================================

class BaseType(Enum):
    INT = auto()
    CHAR = auto()
    VOID = auto()


@dataclass
class Type:
    """Base class for types."""
    pass


@dataclass
class PrimitiveType(Type):
    base: BaseType

    def __repr__(self):
        return self.base.name.lower()


@dataclass
class PointerType(Type):
    pointee: Type

    def __repr__(self):
        return f"{self.pointee}*"


@dataclass
class ArrayType(Type):
    element: Type
    size: int

    def __repr__(self):
        return f"{self.element}[{self.size}]"


@dataclass
class StructType(Type):
    name: str

    def __repr__(self):
        return f"struct {self.name}"


# Convenience type constructors
INT_TYPE = PrimitiveType(BaseType.INT)
CHAR_TYPE = PrimitiveType(BaseType.CHAR)
VOID_TYPE = PrimitiveType(BaseType.VOID)


def ptr_to(t: Type) -> PointerType:
    return PointerType(t)


# ============================================================================
# AST Nodes
# ============================================================================

@dataclass
class Node:
    """Base class for all AST nodes."""
    pass


# ----------------------------------------------------------------------------
# Declarations
# ----------------------------------------------------------------------------

@dataclass
class StructField(Node):
    name: str
    type: Type
    array_size: Optional[int] = None  # None if not an array
    line: int = 0
    column: int = 0


@dataclass
class StructDef(Node):
    name: str
    fields: List['StructField'] = field(default_factory=list)
    line: int = 0
    column: int = 0


@dataclass
class VarDecl(Node):
    name: str
    type: Type
    init: Optional['Expr'] = None
    array_size: Optional[int] = None  # For local arrays
    line: int = 0
    column: int = 0


@dataclass
class ParamDecl(Node):
    name: str
    type: Type
    line: int = 0
    column: int = 0


@dataclass
class FuncDef(Node):
    name: str
    return_type: Type
    params: List['ParamDecl'] = field(default_factory=list)
    body: Optional['Block'] = None  # None for forward declarations
    line: int = 0
    column: int = 0


@dataclass
class ExternDecl(Node):
    """External function declaration for Win32 API calls."""
    name: str
    dll: str  # DLL name (e.g., "user32.dll", "kernel32.dll")
    return_type: Type
    params: List['ParamDecl'] = field(default_factory=list)
    line: int = 0
    column: int = 0


@dataclass
class Program(Node):
    structs: List['StructDef'] = field(default_factory=list)
    globals: List['VarDecl'] = field(default_factory=list)
    functions: List['FuncDef'] = field(default_factory=list)
    externs: List['ExternDecl'] = field(default_factory=list)
    line: int = 0
    column: int = 0


# ----------------------------------------------------------------------------
# Statements
# ----------------------------------------------------------------------------

@dataclass
class Stmt(Node):
    """Base class for statements."""
    pass


@dataclass
class Block(Stmt):
    stmts: List['Stmt'] = field(default_factory=list)
    line: int = 0
    column: int = 0


@dataclass
class ExprStmt(Stmt):
    expr: 'Expr'
    line: int = 0
    column: int = 0


@dataclass
class IfStmt(Stmt):
    cond: 'Expr'
    then_branch: 'Stmt'
    else_branch: Optional['Stmt'] = None
    line: int = 0
    column: int = 0


@dataclass
class WhileStmt(Stmt):
    cond: 'Expr'
    body: 'Stmt'
    line: int = 0
    column: int = 0


@dataclass
class ForStmt(Stmt):
    init: Optional['Expr']
    cond: Optional['Expr']
    step: Optional['Expr']
    body: 'Stmt'
    line: int = 0
    column: int = 0


@dataclass
class ReturnStmt(Stmt):
    value: Optional['Expr'] = None
    line: int = 0
    column: int = 0


@dataclass
class BreakStmt(Stmt):
    line: int = 0
    column: int = 0


@dataclass
class ContinueStmt(Stmt):
    line: int = 0
    column: int = 0


@dataclass
class DeclStmt(Stmt):
    """Local variable declaration as a statement."""
    decl: 'VarDecl'
    line: int = 0
    column: int = 0


@dataclass
class EmitStmt(Stmt):
    """Inline byte emission: emit 0x90, 0xCC, ... ;"""
    emit_bytes: List[int]
    line: int = 0
    column: int = 0


# ----------------------------------------------------------------------------
# Expressions
# ----------------------------------------------------------------------------

class BinOp(Enum):
    ADD = '+'
    SUB = '-'
    MUL = '*'
    DIV = '/'
    MOD = '%'
    AND = '&'
    OR = '|'
    XOR = '^'
    SHL = '<<'
    SHR = '>>'
    LAND = '&&'
    LOR = '||'
    EQ = '=='
    NE = '!='
    LT = '<'
    LE = '<='
    GT = '>'
    GE = '>='
    ASSIGN = '='
    ADD_ASSIGN = '+='
    SUB_ASSIGN = '-='


class UnaryOp(Enum):
    NEG = '-'
    NOT = '!'
    BNOT = '~'
    ADDR = '&'
    DEREF = '*'
    PRE_INC = '++pre'
    PRE_DEC = '--pre'
    POST_INC = 'post++'
    POST_DEC = 'post--'


@dataclass
class Expr(Node):
    """Base class for expressions."""
    pass


@dataclass
class IntLiteral(Expr):
    value: int
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class CharLiteral(Expr):
    value: int  # ASCII value
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class StringLiteral(Expr):
    value: str
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class Identifier(Expr):
    name: str
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class BinaryExpr(Expr):
    op: BinOp
    left: 'Expr'
    right: 'Expr'
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class UnaryExpr(Expr):
    op: UnaryOp
    operand: 'Expr'
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class CallExpr(Expr):
    func: str  # Function name (or variable name for indirect calls)
    args: List['Expr'] = field(default_factory=list)
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)
    is_indirect: bool = field(default=False, repr=False)  # True when calling through an int variable


@dataclass
class IndexExpr(Expr):
    base: 'Expr'
    index: 'Expr'
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class MemberExpr(Expr):
    base: 'Expr'
    member: str
    is_arrow: bool = False  # True for ->, False for .
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class SizeofExpr(Expr):
    target_type: Type
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


@dataclass
class CastExpr(Expr):
    target_type: Type
    expr: 'Expr'
    line: int = 0
    column: int = 0
    resolved_type: Optional[Type] = field(default=None, repr=False)


# ============================================================================
# AST Printer (for debugging)
# ============================================================================

class ASTPrinter:
    def __init__(self):
        self.indent = 0

    def print(self, node: Node) -> str:
        lines = []
        self._print(node, lines)
        return '\n'.join(lines)

    def _print(self, node: Any, lines: List[str], prefix: str = ""):
        indent_str = "  " * self.indent

        if node is None:
            lines.append(f"{indent_str}{prefix}None")
            return

        if isinstance(node, list):
            if not node:
                lines.append(f"{indent_str}{prefix}[]")
            else:
                lines.append(f"{indent_str}{prefix}[")
                self.indent += 1
                for item in node:
                    self._print(item, lines)
                self.indent -= 1
                lines.append(f"{indent_str}]")
            return

        if isinstance(node, (int, str, bool, BinOp, UnaryOp, BaseType)):
            lines.append(f"{indent_str}{prefix}{node!r}")
            return

        if isinstance(node, Type):
            lines.append(f"{indent_str}{prefix}{node}")
            return

        if isinstance(node, Node):
            name = node.__class__.__name__
            lines.append(f"{indent_str}{prefix}{name}:")
            self.indent += 1
            for field_name, field_value in node.__dict__.items():
                if field_name in ('line', 'column', 'resolved_type'):
                    continue
                self._print(field_value, lines, f"{field_name}: ")
            self.indent -= 1
            return

        lines.append(f"{indent_str}{prefix}{node!r}")


def print_ast(node: Node) -> str:
    """Pretty-print an AST node."""
    printer = ASTPrinter()
    return printer.print(node)
