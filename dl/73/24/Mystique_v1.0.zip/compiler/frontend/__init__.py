"""
MystC Frontend - Python compiler front-end for MystC language.

Outputs .mcb bytecode for the polymorphic back-end.
"""

from .tokens import Token, TokenType
from .lexer import Lexer, tokenize
from .parser import Parser, parse, ParseError
from .mystc_ast import *
from .symbols import SymbolTable
from .typecheck import TypeChecker, typecheck, TypeError
from .bytecode import MCProgram, write_bytecode, write_text
from .irgen import generate_ir

__all__ = [
    'Token', 'TokenType',
    'Lexer', 'tokenize',
    'Parser', 'parse', 'ParseError',
    'SymbolTable',
    'TypeChecker', 'typecheck', 'TypeError',
    'MCProgram', 'write_bytecode', 'write_text',
    'generate_ir',
]
