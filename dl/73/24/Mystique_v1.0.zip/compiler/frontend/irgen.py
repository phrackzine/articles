"""
IR Generator - converts type-checked AST to bytecode.
"""

from typing import List, Dict, Optional, Tuple
from . import mystc_ast as ast
from .symbols import SymbolTable, get_type_size_align
from .bytecode import (
    MCProgram, MCFunction, MCStruct, MCGlobal, Block, Instruction,
    Value, ValueKind, TypeCode, Opcode
)


def type_to_code(t: ast.Type) -> TypeCode:
    """Convert AST type to TypeCode."""
    if isinstance(t, ast.PrimitiveType):
        if t.base == ast.BaseType.VOID:
            return TypeCode.VOID
        elif t.base == ast.BaseType.CHAR:
            return TypeCode.I8
        elif t.base == ast.BaseType.INT:
            return TypeCode.I32
    elif isinstance(t, ast.PointerType):
        return TypeCode.PTR
    elif isinstance(t, ast.ArrayType):
        return TypeCode.PTR  # Arrays decay to pointers
    elif isinstance(t, ast.StructType):
        return TypeCode.PTR  # Struct values are passed by pointer in IR
    return TypeCode.I32


class IRGenerator:
    """Generates bytecode IR from AST."""

    def __init__(self, symbols: SymbolTable):
        self.symbols = symbols
        self.program = MCProgram()

        # Current function state
        self.current_func: Optional[MCFunction] = None
        self.current_block: Optional[Block] = None
        self.blocks: List[Block] = []
        self.block_indices: Dict[str, int] = {}

        # Temp counter
        self.temp_counter = 0

        # Loop context for break/continue
        self.loop_stack: List[Tuple[int, int]] = []  # (continue_block, break_block)

        # Variable mappings
        self.local_indices: Dict[str, int] = {}
        self.param_indices: Dict[str, int] = {}

    def generate(self, program: ast.Program) -> MCProgram:
        """Generate bytecode for the entire program."""
        # Add extern functions
        for extern in program.externs:
            self.program.add_string(extern.name)
            self.program.add_string(extern.dll)  # Store DLL name
            func_info = self.symbols.lookup_function(extern.name)
            if func_info:
                mc_func = MCFunction(
                    name=extern.name,
                    return_type=type_to_code(func_info.return_type),
                    param_types=[type_to_code(pt) for pt in func_info.param_types],
                    is_extern=True,
                    dll=extern.dll
                )
                self.program.functions.append(mc_func)
                self.program.func_indices[extern.name] = len(self.program.functions) - 1

        # Add struct names as strings
        for struct in program.structs:
            self.program.add_string(struct.name)
            for field in struct.fields:
                self.program.add_string(field.name)

        # Generate structs
        for struct in program.structs:
            self.gen_struct(struct)

        # Add function names and register indices BEFORE generating code
        # Note: self.program.functions already contains builtins + externs at this point
        for func in program.functions:
            self.program.add_string(func.name)
            # Reserve index for user-defined functions (after builtins and externs)
            self.program.func_indices[func.name] = len(self.program.functions) + list(f.name for f in program.functions).index(func.name)

        # Add global names and register indices
        for i, var in enumerate(program.globals):
            self.program.add_string(var.name)
            self.program.global_indices[var.name] = i

        # Generate globals
        for var in program.globals:
            self.gen_global(var)

        # Generate functions
        for func in program.functions:
            self.gen_function(func)

        self.program.build_indices()
        return self.program

    def gen_struct(self, struct: ast.StructDef):
        """Generate struct definition."""
        info = self.symbols.lookup_struct(struct.name)
        if not info:
            return

        mc_struct = MCStruct(
            name=struct.name,
            size=info.size,
            align=info.align,
            fields=[]
        )

        for field_name, field_type in info.fields.items():
            tc = type_to_code(field_type)
            offset = info.field_offsets[field_name]
            mc_struct.fields.append((field_name, tc, offset))

        self.program.structs.append(mc_struct)

    def gen_global(self, var: ast.VarDecl):
        """Generate global variable."""
        tc = type_to_code(var.type)

        init_kind = 0
        init_value = 0

        if var.init:
            if isinstance(var.init, ast.IntLiteral):
                init_kind = 1
                init_value = var.init.value
            elif isinstance(var.init, ast.UnaryExpr) and var.init.op == ast.UnaryOp.NEG and isinstance(var.init.operand, ast.IntLiteral):
                init_kind = 1
                init_value = -var.init.operand.value
            elif isinstance(var.init, ast.StringLiteral):
                init_kind = 2
                init_value = self.program.add_string(var.init.value)

        mc_global = MCGlobal(
            name=var.name,
            type_code=tc,
            init_kind=init_kind,
            init_value=init_value
        )

        self.program.globals.append(mc_global)

    def gen_function(self, func: ast.FuncDef):
        """Generate a function."""
        self.temp_counter = 0
        self.blocks = []
        self.block_indices = {}
        self.local_indices = {}
        self.param_indices = {}

        # Create function
        mc_func = MCFunction(
            name=func.name,
            return_type=type_to_code(func.return_type)
        )

        # Parameters
        for i, param in enumerate(func.params):
            mc_func.param_types.append(type_to_code(param.type))
            self.param_indices[param.name] = i

        self.current_func = mc_func

        # Entry block
        self.new_block("entry")

        # Collect locals from body
        if func.body:
            self.collect_locals(func.body, mc_func)

        # Generate body
        if func.body:
            self.gen_block_stmt(func.body)

        # Add implicit return for void functions
        if mc_func.return_type == TypeCode.VOID:
            if not self.current_block.instructions or \
               self.current_block.instructions[-1].opcode not in (Opcode.RET, Opcode.RETV):
                self.emit(Instruction(Opcode.RETV))

        mc_func.blocks = self.blocks
        mc_func.num_temps = self.temp_counter
        self.program.functions.append(mc_func)
        self.current_func = None

    def collect_locals(self, stmt: ast.Stmt, mc_func: MCFunction):
        """Collect local variable declarations from a statement."""
        if isinstance(stmt, ast.Block):
            for s in stmt.stmts:
                self.collect_locals(s, mc_func)
        elif isinstance(stmt, ast.DeclStmt):
            var = stmt.decl
            idx = len(mc_func.local_types)
            self.local_indices[var.name] = idx
            mc_func.local_types.append(type_to_code(var.type))

            size = 0
            if isinstance(var.type, ast.ArrayType):
                elem_size, _ = get_type_size_align(var.type.element, self.symbols)
                size = elem_size * var.type.size
            elif isinstance(var.type, ast.StructType):
                size, _ = get_type_size_align(var.type, self.symbols)
            mc_func.local_sizes.append(size)
        elif isinstance(stmt, ast.IfStmt):
            self.collect_locals(stmt.then_branch, mc_func)
            if stmt.else_branch:
                self.collect_locals(stmt.else_branch, mc_func)
        elif isinstance(stmt, ast.WhileStmt):
            self.collect_locals(stmt.body, mc_func)
        elif isinstance(stmt, ast.ForStmt):
            self.collect_locals(stmt.body, mc_func)

    # ========================================================================
    # Helpers
    # ========================================================================

    def new_temp(self) -> Value:
        """Allocate a new temporary."""
        idx = self.temp_counter
        self.temp_counter += 1
        return Value(ValueKind.TEMP, idx)

    def new_block(self, name: str) -> int:
        """Create a new basic block and return its index."""
        # Make unique name
        base_name = name
        counter = 0
        while name in self.block_indices:
            counter += 1
            name = f"{base_name}_{counter}"

        block = Block(name)
        idx = len(self.blocks)
        self.blocks.append(block)
        self.block_indices[name] = idx
        self.current_block = block

        # Add label string
        self.program.add_string(name)

        return idx

    def switch_block(self, idx: int):
        """Switch to an existing block."""
        self.current_block = self.blocks[idx]

    def emit(self, instr: Instruction):
        """Emit an instruction to the current block."""
        self.current_block.instructions.append(instr)

    def const(self, value: int, tc: TypeCode = TypeCode.I32) -> Value:
        """Create a constant value in a temp."""
        dest = self.new_temp()
        self.emit(Instruction(
            Opcode.CONST,
            dest=dest,
            arg1=Value(ValueKind.CONST_IMM, imm_value=value),
            type_code=tc
        ))
        return dest

    def lookup_var(self, name: str) -> Value:
        """Look up a variable and return its Value."""
        if name in self.param_indices:
            return Value(ValueKind.PARAM, self.param_indices[name])
        if name in self.local_indices:
            return Value(ValueKind.LOCAL, self.local_indices[name])

        # Check globals
        var_info = self.symbols.lookup_var(name)
        if var_info and var_info.is_global:
            idx = self.program.global_indices.get(name)
            if idx is not None:
                return Value(ValueKind.GLOBAL, idx)

        # Should not happen if type checking passed
        return Value(ValueKind.CONST_IMM, 0)

    # ========================================================================
    # Statements
    # ========================================================================

    def gen_stmt(self, stmt: ast.Stmt):
        """Generate code for a statement."""
        if isinstance(stmt, ast.Block):
            self.gen_block_stmt(stmt)
        elif isinstance(stmt, ast.ExprStmt):
            self.gen_expr(stmt.expr)
        elif isinstance(stmt, ast.IfStmt):
            self.gen_if_stmt(stmt)
        elif isinstance(stmt, ast.WhileStmt):
            self.gen_while_stmt(stmt)
        elif isinstance(stmt, ast.ForStmt):
            self.gen_for_stmt(stmt)
        elif isinstance(stmt, ast.ReturnStmt):
            self.gen_return_stmt(stmt)
        elif isinstance(stmt, ast.BreakStmt):
            if self.loop_stack:
                _, break_block = self.loop_stack[-1]
                self.emit(Instruction(Opcode.JMP, target_block=break_block))
        elif isinstance(stmt, ast.ContinueStmt):
            if self.loop_stack:
                cont_block, _ = self.loop_stack[-1]
                self.emit(Instruction(Opcode.JMP, target_block=cont_block))
        elif isinstance(stmt, ast.DeclStmt):
            self.gen_decl_stmt(stmt)
        elif isinstance(stmt, ast.EmitStmt):
            self.emit(Instruction(Opcode.EMIT, emit_bytes=list(stmt.emit_bytes)))

    def gen_block_stmt(self, block: ast.Block):
        """Generate code for a block."""
        for stmt in block.stmts:
            self.gen_stmt(stmt)

    def gen_if_stmt(self, stmt: ast.IfStmt):
        """Generate code for an if statement."""
        cond = self.gen_expr(stmt.cond)

        # Save the block where condition was generated
        cond_block_idx = self.blocks.index(self.current_block)

        then_block = self.new_block("then")
        else_block = self.new_block("else") if stmt.else_branch else None
        end_block_idx = None

        # Jump to else or end if condition is false
        if else_block is not None:
            self.switch_block(cond_block_idx)
            self.emit(Instruction(Opcode.JZ, arg1=cond, target_block=else_block))
            self.emit(Instruction(Opcode.JMP, target_block=then_block))
        else:
            end_block_idx = self.new_block("endif")
            self.switch_block(cond_block_idx)
            self.emit(Instruction(Opcode.JZ, arg1=cond, target_block=end_block_idx))
            self.emit(Instruction(Opcode.JMP, target_block=then_block))

        # Generate then branch
        self.switch_block(then_block)
        self.gen_stmt(stmt.then_branch)
        # After generating then branch, current_block is where the then branch ends
        # (may differ from then_block if branch contained loops/ifs)
        then_end_idx = self.blocks.index(self.current_block)

        if stmt.else_branch:
            end_block_idx = self.new_block("endif")
            self.switch_block(then_end_idx)
            if not self.current_block.instructions or \
               self.current_block.instructions[-1].opcode != Opcode.JMP:
                self.emit(Instruction(Opcode.JMP, target_block=end_block_idx))

            # Generate else branch
            self.switch_block(else_block)
            self.gen_stmt(stmt.else_branch)
            if not self.current_block.instructions or \
               self.current_block.instructions[-1].opcode != Opcode.JMP:
                self.emit(Instruction(Opcode.JMP, target_block=end_block_idx))
        else:
            # No else branch - emit JMP from then end to endif if needed
            self.switch_block(then_end_idx)
            if not self.current_block.instructions or \
               self.current_block.instructions[-1].opcode != Opcode.JMP:
                self.emit(Instruction(Opcode.JMP, target_block=end_block_idx))

        self.switch_block(end_block_idx)

    def gen_while_stmt(self, stmt: ast.WhileStmt):
        """Generate code for a while statement."""
        # Save predecessor block index before creating new blocks
        pred_idx = self.blocks.index(self.current_block)

        cond_block = self.new_block("while_cond")
        body_block = self.new_block("while_body")
        end_block = self.new_block("while_end")

        # Jump to condition from predecessor
        self.switch_block(pred_idx)
        self.emit(Instruction(Opcode.JMP, target_block=cond_block))

        # Condition
        self.switch_block(cond_block)
        cond = self.gen_expr(stmt.cond)
        self.emit(Instruction(Opcode.JZ, arg1=cond, target_block=end_block))
        self.emit(Instruction(Opcode.JMP, target_block=body_block))

        # Body
        self.switch_block(body_block)
        self.loop_stack.append((cond_block, end_block))
        self.gen_stmt(stmt.body)
        self.loop_stack.pop()
        self.emit(Instruction(Opcode.JMP, target_block=cond_block))

        self.switch_block(end_block)

    def gen_for_stmt(self, stmt: ast.ForStmt):
        """Generate code for a for statement."""
        # Init
        if stmt.init:
            self.gen_expr(stmt.init)

        # Save predecessor block index before creating new blocks
        pred_idx = self.blocks.index(self.current_block)

        cond_block = self.new_block("for_cond")
        body_block = self.new_block("for_body")
        step_block = self.new_block("for_step")
        end_block = self.new_block("for_end")

        # Jump to condition from predecessor
        self.switch_block(pred_idx)
        self.emit(Instruction(Opcode.JMP, target_block=cond_block))

        # Condition
        self.switch_block(cond_block)
        if stmt.cond:
            cond = self.gen_expr(stmt.cond)
            self.emit(Instruction(Opcode.JZ, arg1=cond, target_block=end_block))
        self.emit(Instruction(Opcode.JMP, target_block=body_block))

        # Body
        self.switch_block(body_block)
        self.loop_stack.append((step_block, end_block))
        self.gen_stmt(stmt.body)
        self.loop_stack.pop()
        self.emit(Instruction(Opcode.JMP, target_block=step_block))

        # Step
        self.switch_block(step_block)
        if stmt.step:
            self.gen_expr(stmt.step)
        self.emit(Instruction(Opcode.JMP, target_block=cond_block))

        self.switch_block(end_block)

    def gen_return_stmt(self, stmt: ast.ReturnStmt):
        """Generate code for a return statement."""
        if stmt.value:
            value = self.gen_expr(stmt.value)
            self.emit(Instruction(Opcode.RET, arg1=value))
        else:
            self.emit(Instruction(Opcode.RETV))

    def gen_decl_stmt(self, stmt: ast.DeclStmt):
        """Generate code for a local variable declaration."""
        var = stmt.decl

        if var.init:
            init_val = self.gen_expr(var.init)
            local = Value(ValueKind.LOCAL, self.local_indices[var.name])

            # Store init value
            tc = type_to_code(var.type)
            self.emit(Instruction(Opcode.STORE, arg1=local, arg2=init_val, type_code=tc))

    # ========================================================================
    # Expressions
    # ========================================================================

    def gen_expr(self, expr: ast.Expr) -> Value:
        """Generate code for an expression and return its value."""
        if isinstance(expr, ast.IntLiteral):
            return self.const(expr.value, TypeCode.I32)

        elif isinstance(expr, ast.CharLiteral):
            return self.const(expr.value, TypeCode.I8)

        elif isinstance(expr, ast.StringLiteral):
            idx = self.program.add_string(expr.value)
            return Value(ValueKind.STRING, idx)

        elif isinstance(expr, ast.Identifier):
            return self.gen_identifier(expr)

        elif isinstance(expr, ast.BinaryExpr):
            return self.gen_binary_expr(expr)

        elif isinstance(expr, ast.UnaryExpr):
            return self.gen_unary_expr(expr)

        elif isinstance(expr, ast.CallExpr):
            return self.gen_call_expr(expr)

        elif isinstance(expr, ast.IndexExpr):
            return self.gen_index_expr(expr)

        elif isinstance(expr, ast.MemberExpr):
            return self.gen_member_expr(expr)

        elif isinstance(expr, ast.SizeofExpr):
            size, _ = get_type_size_align(expr.target_type, self.symbols)
            return self.const(size)

        return self.const(0)

    def gen_identifier(self, expr: ast.Identifier) -> Value:
        """Generate code to load an identifier."""
        var = self.lookup_var(expr.name)

        # Array-to-pointer decay: an array name evaluates to its address, not the bytes at it.
        if isinstance(expr.resolved_type, ast.ArrayType):
            dest = self.new_temp()
            self.emit(Instruction(Opcode.ADDR, dest=dest, arg1=var))
            return dest

        tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32
        dest = self.new_temp()
        self.emit(Instruction(Opcode.LOAD, dest=dest, arg1=var, type_code=tc))
        return dest

    def gen_binary_expr(self, expr: ast.BinaryExpr) -> Value:
        """Generate code for a binary expression."""
        op = expr.op

        # Handle assignment
        if op == ast.BinOp.ASSIGN:
            return self.gen_assignment(expr.left, expr.right)

        if op == ast.BinOp.ADD_ASSIGN:
            # a += b  =>  a = a + b
            right = ast.BinaryExpr(ast.BinOp.ADD, expr.left, expr.right)
            return self.gen_assignment(expr.left, right)

        if op == ast.BinOp.SUB_ASSIGN:
            right = ast.BinaryExpr(ast.BinOp.SUB, expr.left, expr.right)
            return self.gen_assignment(expr.left, right)

        # Short-circuit logical operators
        if op == ast.BinOp.LAND:
            return self.gen_logical_and(expr)
        if op == ast.BinOp.LOR:
            return self.gen_logical_or(expr)

        # Regular binary operations
        left = self.gen_expr(expr.left)
        right = self.gen_expr(expr.right)
        dest = self.new_temp()

        tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32

        op_map = {
            ast.BinOp.ADD: Opcode.ADD,
            ast.BinOp.SUB: Opcode.SUB,
            ast.BinOp.MUL: Opcode.MUL,
            ast.BinOp.DIV: Opcode.DIV,
            ast.BinOp.MOD: Opcode.MOD,
            ast.BinOp.AND: Opcode.AND,
            ast.BinOp.OR: Opcode.OR,
            ast.BinOp.XOR: Opcode.XOR,
            ast.BinOp.SHL: Opcode.SHL,
            ast.BinOp.SHR: Opcode.SHR,
            ast.BinOp.EQ: Opcode.EQ,
            ast.BinOp.NE: Opcode.NE,
            ast.BinOp.LT: Opcode.LT,
            ast.BinOp.LE: Opcode.LE,
            ast.BinOp.GT: Opcode.GT,
            ast.BinOp.GE: Opcode.GE,
        }

        opcode = op_map.get(op, Opcode.ADD)
        self.emit(Instruction(opcode, dest=dest, arg1=left, arg2=right, type_code=tc))
        return dest

    def gen_logical_and(self, expr: ast.BinaryExpr) -> Value:
        """Generate short-circuit logical AND."""
        result = self.new_temp()

        left = self.gen_expr(expr.left)

        # Save current block index before creating new blocks
        pred_idx = self.blocks.index(self.current_block)

        # If left is false, short-circuit
        right_block = self.new_block("and_right")
        end_block = self.new_block("and_end")

        self.switch_block(pred_idx)
        # Set result = left before branch (so short-circuit path has result = 0)
        self.emit(Instruction(Opcode.COPY, dest=result, arg1=left, type_code=TypeCode.I32))
        self.emit(Instruction(Opcode.JZ, arg1=left, target_block=end_block))
        self.emit(Instruction(Opcode.JMP, target_block=right_block))

        # Evaluate right
        self.switch_block(right_block)
        right = self.gen_expr(expr.right)
        self.emit(Instruction(Opcode.COPY, dest=result, arg1=right, type_code=TypeCode.I32))
        self.emit(Instruction(Opcode.JMP, target_block=end_block))

        self.switch_block(end_block)

        return result

    def gen_logical_or(self, expr: ast.BinaryExpr) -> Value:
        """Generate short-circuit logical OR."""
        result = self.new_temp()

        left = self.gen_expr(expr.left)

        # Save current block index before creating new blocks
        pred_idx = self.blocks.index(self.current_block)

        # If left is true, short-circuit
        right_block = self.new_block("or_right")
        end_block = self.new_block("or_end")

        self.switch_block(pred_idx)
        # Set result = left before branch (so short-circuit path has result = left = truthy)
        self.emit(Instruction(Opcode.COPY, dest=result, arg1=left, type_code=TypeCode.I32))
        self.emit(Instruction(Opcode.JNZ, arg1=left, target_block=end_block))
        self.emit(Instruction(Opcode.JMP, target_block=right_block))

        # Evaluate right
        self.switch_block(right_block)
        right = self.gen_expr(expr.right)
        self.emit(Instruction(Opcode.COPY, dest=result, arg1=right, type_code=TypeCode.I32))
        self.emit(Instruction(Opcode.JMP, target_block=end_block))

        self.switch_block(end_block)

        return result

    def gen_assignment(self, target: ast.Expr, value: ast.Expr) -> Value:
        """Generate code for an assignment."""
        val = self.gen_expr(value)

        # Get target address
        if isinstance(target, ast.Identifier):
            addr = self.lookup_var(target.name)
        elif isinstance(target, ast.UnaryExpr) and target.op == ast.UnaryOp.DEREF:
            addr = self.gen_expr(target.operand)
        elif isinstance(target, ast.IndexExpr):
            addr = self.gen_addr_of_index(target)
        elif isinstance(target, ast.MemberExpr):
            addr = self.gen_addr_of_member(target)
        else:
            addr = self.const(0)

        tc = type_to_code(target.resolved_type) if target.resolved_type else TypeCode.I32
        self.emit(Instruction(Opcode.STORE, arg1=addr, arg2=val, type_code=tc))

        return val

    def _get_lvalue_addr(self, expr: ast.Expr) -> Value:
        """Return the address Value for an lvalue (for use in STORE)."""
        if isinstance(expr, ast.Identifier):
            return self.lookup_var(expr.name)
        elif isinstance(expr, ast.UnaryExpr) and expr.op == ast.UnaryOp.DEREF:
            return self.gen_expr(expr.operand)
        elif isinstance(expr, ast.IndexExpr):
            return self.gen_addr_of_index(expr)
        elif isinstance(expr, ast.MemberExpr):
            return self.gen_addr_of_member(expr)
        else:
            return self.const(0)

    def gen_unary_expr(self, expr: ast.UnaryExpr) -> Value:
        """Generate code for a unary expression."""
        op = expr.op

        if op == ast.UnaryOp.ADDR:
            return self.gen_addr_of(expr.operand)

        if op == ast.UnaryOp.DEREF:
            addr = self.gen_expr(expr.operand)
            dest = self.new_temp()
            tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32
            self.emit(Instruction(Opcode.LOAD, dest=dest, arg1=addr, type_code=tc))
            return dest

        operand = self.gen_expr(expr.operand)
        dest = self.new_temp()
        tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32

        if op == ast.UnaryOp.NEG:
            self.emit(Instruction(Opcode.NEG, dest=dest, arg1=operand, type_code=tc))
        elif op == ast.UnaryOp.NOT:
            # !x  =>  x == 0
            zero = self.const(0)
            self.emit(Instruction(Opcode.EQ, dest=dest, arg1=operand, arg2=zero, type_code=tc))
        elif op == ast.UnaryOp.BNOT:
            self.emit(Instruction(Opcode.NOT, dest=dest, arg1=operand, type_code=tc))
        elif op == ast.UnaryOp.PRE_INC:
            one = self.const(1)
            self.emit(Instruction(Opcode.ADD, dest=dest, arg1=operand, arg2=one, type_code=tc))
            addr = self._get_lvalue_addr(expr.operand)
            self.emit(Instruction(Opcode.STORE, arg1=addr, arg2=dest, type_code=tc))
        elif op == ast.UnaryOp.POST_INC:
            one = self.const(1)
            self.emit(Instruction(Opcode.ADD, dest=dest, arg1=operand, arg2=one, type_code=tc))
            addr = self._get_lvalue_addr(expr.operand)
            self.emit(Instruction(Opcode.STORE, arg1=addr, arg2=dest, type_code=tc))
            dest = operand  # return original value
        elif op == ast.UnaryOp.PRE_DEC:
            one = self.const(1)
            self.emit(Instruction(Opcode.SUB, dest=dest, arg1=operand, arg2=one, type_code=tc))
            addr = self._get_lvalue_addr(expr.operand)
            self.emit(Instruction(Opcode.STORE, arg1=addr, arg2=dest, type_code=tc))
        elif op == ast.UnaryOp.POST_DEC:
            one = self.const(1)
            self.emit(Instruction(Opcode.SUB, dest=dest, arg1=operand, arg2=one, type_code=tc))
            addr = self._get_lvalue_addr(expr.operand)
            self.emit(Instruction(Opcode.STORE, arg1=addr, arg2=dest, type_code=tc))
            dest = operand  # return original value

        return dest

    def gen_addr_of(self, expr: ast.Expr) -> Value:
        """Generate code to get the address of an expression."""
        if isinstance(expr, ast.Identifier):
            # Check if it's a function name first
            func_idx = self.program.func_indices.get(expr.name)
            if func_idx is not None and expr.name not in self.local_indices \
               and expr.name not in self.param_indices:
                dest = self.new_temp()
                self.emit(Instruction(Opcode.FUNC_ADDR, dest=dest, func_index=func_idx))
                return dest
            var = self.lookup_var(expr.name)
            dest = self.new_temp()
            self.emit(Instruction(Opcode.ADDR, dest=dest, arg1=var))
            return dest

        elif isinstance(expr, ast.IndexExpr):
            return self.gen_addr_of_index(expr)

        elif isinstance(expr, ast.MemberExpr):
            return self.gen_addr_of_member(expr)

        return self.const(0)

    def gen_addr_of_index(self, expr: ast.IndexExpr) -> Value:
        """Generate address of array element."""
        base = self.gen_expr(expr.base)
        index = self.gen_expr(expr.index)

        # Get element size
        elem_type = expr.resolved_type
        elem_size, _ = get_type_size_align(elem_type, self.symbols) if elem_type else (4, 4)

        dest = self.new_temp()
        self.emit(Instruction(Opcode.PTRADD, dest=dest, arg1=base, arg2=index, elem_size=elem_size))
        return dest

    def gen_addr_of_member(self, expr: ast.MemberExpr) -> Value:
        """Generate address of struct member."""
        # Get base address
        if expr.is_arrow:
            base = self.gen_expr(expr.base)
        else:
            base = self.gen_addr_of(expr.base)

        # Get field offset
        base_type = expr.base.resolved_type
        if expr.is_arrow and isinstance(base_type, ast.PointerType):
            base_type = base_type.pointee

        offset = 0
        if isinstance(base_type, ast.StructType):
            struct_info = self.symbols.lookup_struct(base_type.name)
            if struct_info and expr.member in struct_info.field_offsets:
                offset = struct_info.field_offsets[expr.member]

        dest = self.new_temp()
        self.emit(Instruction(Opcode.FIELDPTR, dest=dest, arg1=base, offset=offset))
        return dest

    def gen_call_expr(self, expr: ast.CallExpr) -> Value:
        """Generate code for a function call."""
        # Generate arguments
        args = [self.gen_expr(arg) for arg in expr.args]

        # __syscall is a backend-recognized Linux primitive (INT 0x80).
        if expr.func == "__syscall":
            assert len(args) == 6, "__syscall must have 6 args (typecheck enforced)"
            dest = self.new_temp()
            self.emit(Instruction(Opcode.SYSCALL, dest=dest, nargs=6, args=args))
            return dest

        if getattr(expr, 'is_indirect', False):
            # Indirect call through a variable holding a function address
            target = self.lookup_var(expr.func)
            dest = self.new_temp()
            self.emit(Instruction(Opcode.ICALL, dest=dest, arg1=target,
                                   nargs=len(args), args=args))
            return dest

        # Look up function index
        func_idx = self.program.func_indices.get(expr.func, 0)

        func_info = self.symbols.lookup_function(expr.func)
        is_void = func_info and isinstance(func_info.return_type, ast.PrimitiveType) and \
                  func_info.return_type.base == ast.BaseType.VOID

        if is_void:
            self.emit(Instruction(Opcode.CALLV, func_index=func_idx, nargs=len(args), args=args))
            return self.const(0)
        else:
            dest = self.new_temp()
            tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32
            self.emit(Instruction(Opcode.CALL, dest=dest, func_index=func_idx,
                                   nargs=len(args), args=args, type_code=tc))
            return dest

    def gen_index_expr(self, expr: ast.IndexExpr) -> Value:
        """Generate code for array indexing."""
        addr = self.gen_addr_of_index(expr)
        dest = self.new_temp()
        tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32
        self.emit(Instruction(Opcode.LOAD, dest=dest, arg1=addr, type_code=tc))
        return dest

    def gen_member_expr(self, expr: ast.MemberExpr) -> Value:
        """Generate code for member access."""
        addr = self.gen_addr_of_member(expr)
        dest = self.new_temp()
        tc = type_to_code(expr.resolved_type) if expr.resolved_type else TypeCode.I32
        self.emit(Instruction(Opcode.LOAD, dest=dest, arg1=addr, type_code=tc))
        return dest


def generate_ir(program: ast.Program, symbols: SymbolTable) -> MCProgram:
    """Generate bytecode IR from AST."""
    gen = IRGenerator(symbols)
    return gen.generate(program)
