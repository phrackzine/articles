#!/usr/bin/env python3
"""
Simple bytecode interpreter for .mcb files. Parses via canonical
bytecode.py reader and executes IR directly without generating native code.
"""

import sys
from typing import List, Dict, Any

from .bytecode import (
    Opcode, ValueKind,
    Value, Instruction, Block, MCFunction, MCGlobal, MCProgram,
    read_bytecode,
)

# Aliases so the execution loop below reads naturally.
OP_NOP = Opcode.NOP
OP_CONST = Opcode.CONST
OP_COPY = Opcode.COPY
OP_ADD = Opcode.ADD
OP_SUB = Opcode.SUB
OP_MUL = Opcode.MUL
OP_DIV = Opcode.DIV
OP_MOD = Opcode.MOD
OP_NEG = Opcode.NEG
OP_AND = Opcode.AND
OP_OR = Opcode.OR
OP_XOR = Opcode.XOR
OP_NOT = Opcode.NOT
OP_SHL = Opcode.SHL
OP_SHR = Opcode.SHR
OP_EQ = Opcode.EQ
OP_NE = Opcode.NE
OP_LT = Opcode.LT
OP_LE = Opcode.LE
OP_GT = Opcode.GT
OP_GE = Opcode.GE
OP_LOAD = Opcode.LOAD
OP_STORE = Opcode.STORE
OP_ADDR = Opcode.ADDR
OP_PTRADD = Opcode.PTRADD
OP_FIELDPTR = Opcode.FIELDPTR
OP_ALLOCA = Opcode.ALLOCA
OP_JMP = Opcode.JMP
OP_JZ = Opcode.JZ
OP_JNZ = Opcode.JNZ
OP_CALL = Opcode.CALL
OP_CALLV = Opcode.CALLV
OP_RET = Opcode.RET
OP_RETV = Opcode.RETV

VK_TEMP = ValueKind.TEMP
VK_PARAM = ValueKind.PARAM
VK_LOCAL = ValueKind.LOCAL
VK_GLOBAL = ValueKind.GLOBAL
VK_CONST = ValueKind.CONST_IMM
VK_STRING = ValueKind.STRING


class Interpreter:
    """Simple stack-based interpreter for the bytecode."""

    def __init__(self, program: MCProgram, verbose: bool = False):
        self.program = program
        self.verbose = verbose
        self.globals: Dict[int, int] = {}
        self.heap: Dict[int, bytearray] = {}
        self.next_heap_addr = 0x10000

        # Initialize globals
        for i, g in enumerate(program.globals):
            self.globals[i] = g.init_value

    def run(self, func_name: str = "main", args: List[int] = None) -> int:
        """Run a function and return its result."""
        if args is None:
            args = []

        func_idx = None
        for i, f in enumerate(self.program.functions):
            if f.name == func_name:
                func_idx = i
                break

        if func_idx is None:
            raise ValueError(f"Function not found: {func_name}")

        return self._call_function(func_idx, args)

    def _call_function(self, func_idx: int, args: List[int]) -> int:
        func = self.program.functions[func_idx]

        if self.verbose:
            print(f"Calling {func.name}({args})")

        # Builtins
        if func.name == "malloc":
            size = args[0] if args else 0
            addr = self.next_heap_addr
            self.heap[addr] = bytearray(size)
            self.next_heap_addr += size + 16
            return addr
        if func.name == "free":
            return 0
        if func.name == "exit":
            code = args[0] if args else 0
            if self.verbose:
                print(f"exit({code})")
            sys.exit(code)
        if func.name in ("read", "write", "open", "close"):
            return 0

        if not func.blocks:
            return 0

        temps: Dict[int, int] = {}
        params: Dict[int, int] = {
            i: (args[i] if i < len(args) else 0)
            for i in range(len(func.param_types))
        }
        locals_: Dict[int, int] = {i: 0 for i in range(len(func.local_types))}

        current_block = 0
        while True:
            if current_block >= len(func.blocks):
                return 0
            block = func.blocks[current_block]
            next_block = current_block + 1
            for instr in block.instructions:
                result = self._execute_instr(instr, temps, params, locals_, func)
                if result is not None:
                    if isinstance(result, tuple):
                        if result[0] == 'jump':
                            next_block = result[1]
                            break
                        elif result[0] == 'return':
                            if self.verbose:
                                print(f"  {func.name} returns {result[1]}")
                            return result[1]
                    else:
                        if instr.dest is not None and instr.dest.kind == VK_TEMP:
                            temps[instr.dest.index] = result
            current_block = next_block

    def _get_operand_value(self, op: Value, temps: Dict, params: Dict, locals_: Dict) -> int:
        if op.kind == VK_TEMP:
            return temps.get(op.index, 0)
        elif op.kind == VK_PARAM:
            return params.get(op.index, 0)
        elif op.kind == VK_LOCAL:
            return locals_.get(op.index, 0)
        elif op.kind == VK_GLOBAL:
            return self.globals.get(op.index, 0)
        elif op.kind == VK_CONST:
            return op.imm_value
        elif op.kind == VK_STRING:
            return 0x1000 + op.index
        return 0

    def _to_signed(self, val: int) -> int:
        """Convert unsigned to signed 32-bit."""
        if val & 0x80000000:
            return val - 0x100000000
        return val

    def _execute_instr(self, instr: Instruction, temps: Dict, params: Dict,
                       locals_: Dict, func: MCFunction) -> Any:
        op = instr.opcode

        if op == OP_NOP:
            return None

        elif op == OP_CONST:
            return instr.arg1.imm_value

        elif op == OP_COPY:
            return self._get_operand_value(instr.arg1, temps, params, locals_)

        elif op == OP_LOAD:
            return self._get_operand_value(instr.arg1, temps, params, locals_)

        elif op == OP_STORE:
            val = self._get_operand_value(instr.arg1, temps, params, locals_)
            if instr.dest.kind == VK_LOCAL:
                locals_[instr.dest.index] = val
            elif instr.dest.kind == VK_PARAM:
                params[instr.dest.index] = val
            elif instr.dest.kind == VK_GLOBAL:
                self.globals[instr.dest.index] = val
            return None

        elif op == OP_ADD:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return (a + b) & 0xFFFFFFFF
        elif op == OP_SUB:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return (a - b) & 0xFFFFFFFF
        elif op == OP_MUL:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return (a * b) & 0xFFFFFFFF
        elif op == OP_DIV:
            a = self._to_signed(self._get_operand_value(instr.arg1, temps, params, locals_))
            b = self._to_signed(self._get_operand_value(instr.arg2, temps, params, locals_))
            if b == 0:
                return 0
            return int(a / b) & 0xFFFFFFFF
        elif op == OP_MOD:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            if b == 0:
                return 0
            return (a % b) & 0xFFFFFFFF
        elif op == OP_NEG:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            return (-a) & 0xFFFFFFFF

        elif op == OP_AND:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return a & b
        elif op == OP_OR:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return a | b
        elif op == OP_XOR:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return a ^ b
        elif op == OP_NOT:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            return (~a) & 0xFFFFFFFF
        elif op == OP_SHL:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return (a << (b & 31)) & 0xFFFFFFFF
        elif op == OP_SHR:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return (a >> (b & 31)) & 0xFFFFFFFF

        elif op == OP_EQ:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return 1 if a == b else 0
        elif op == OP_NE:
            a = self._get_operand_value(instr.arg1, temps, params, locals_)
            b = self._get_operand_value(instr.arg2, temps, params, locals_)
            return 1 if a != b else 0
        elif op == OP_LT:
            a = self._to_signed(self._get_operand_value(instr.arg1, temps, params, locals_))
            b = self._to_signed(self._get_operand_value(instr.arg2, temps, params, locals_))
            return 1 if a < b else 0
        elif op == OP_LE:
            a = self._to_signed(self._get_operand_value(instr.arg1, temps, params, locals_))
            b = self._to_signed(self._get_operand_value(instr.arg2, temps, params, locals_))
            return 1 if a <= b else 0
        elif op == OP_GT:
            a = self._to_signed(self._get_operand_value(instr.arg1, temps, params, locals_))
            b = self._to_signed(self._get_operand_value(instr.arg2, temps, params, locals_))
            return 1 if a > b else 0
        elif op == OP_GE:
            a = self._to_signed(self._get_operand_value(instr.arg1, temps, params, locals_))
            b = self._to_signed(self._get_operand_value(instr.arg2, temps, params, locals_))
            return 1 if a >= b else 0

        elif op == OP_JMP:
            return ('jump', instr.target_block)
        elif op == OP_JZ:
            cond = self._get_operand_value(instr.arg1, temps, params, locals_)
            if cond == 0:
                return ('jump', instr.target_block)
            return None
        elif op == OP_JNZ:
            cond = self._get_operand_value(instr.arg1, temps, params, locals_)
            if cond != 0:
                return ('jump', instr.target_block)
            return None

        elif op == OP_CALL:
            args = [self._get_operand_value(a, temps, params, locals_) for a in instr.args]
            return self._call_function(instr.func_index, args)
        elif op == OP_CALLV:
            args = [self._get_operand_value(a, temps, params, locals_) for a in instr.args]
            self._call_function(instr.func_index, args)
            return None

        elif op == OP_RET:
            val = self._get_operand_value(instr.arg1, temps, params, locals_)
            return ('return', val)
        elif op == OP_RETV:
            return ('return', 0)

        return None


def main():
    if len(sys.argv) < 2:
        print("Usage: interpreter.py <file.mcb> [function] [args...] [-v]")
        sys.exit(1)

    filename = sys.argv[1]
    func_name = "main"
    args = []
    verbose = False

    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == '-v':
            verbose = True
        elif func_name == "main" and not sys.argv[i].isdigit() and sys.argv[i] != '-v':
            func_name = sys.argv[i]
        else:
            try:
                args.append(int(sys.argv[i]))
            except ValueError:
                pass
        i += 1

    try:
        program = read_bytecode(filename)
        print(f"Loaded module with {len(program.functions)} functions")

        if verbose:
            print("\nFunctions:")
            for i, f in enumerate(program.functions):
                print(f"  {i}: {f.name} ({len(f.param_types)} params, {len(f.blocks)} blocks)")

        print(f"\nRunning {func_name}({args})...")
        interp = Interpreter(program, verbose)
        result = interp.run(func_name, args)

        signed_result = result if result < 0x80000000 else result - 0x100000000
        print(f"Result: {result} (0x{result:08X}) [signed: {signed_result}]")
        return result

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
