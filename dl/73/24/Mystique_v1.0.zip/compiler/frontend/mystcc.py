#!/usr/bin/env python3
"""
MystC Compiler Frontend

Compiles MystC source code to .mcb bytecode.

Usage:
    python -m compiler.frontend.mystcc <source.c> [-o output.mcb] [--text]
"""

import sys
import os
import argparse

# Handle running as script or module
if __name__ == '__main__' and __package__ is None:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from compiler.frontend.lexer import tokenize
from compiler.frontend.parser import Parser
from compiler.frontend.typecheck import typecheck
from compiler.frontend.irgen import generate_ir
from compiler.frontend.bytecode import write_bytecode, write_text, write_expr
from compiler.frontend.mystc_ast import print_ast
from compiler.frontend.strip_debug import strip_debug_calls
from compiler.frontend.scramble import scramble_globals as scramble_globals_pass


def preprocess(source: str, source_path: str,
               defines: set = None, included: set = None) -> str:
    """
    Preprocess MystC source: #include, #define, #ifdef/#ifndef/#else/#endif.

    Args:
        source: Source text
        source_path: Path to the source file (for relative #include resolution)
        defines: Set of defined symbols (e.g. {'WIN32'})
        included: Set of already-included absolute paths (cycle/diamond guard)

    Returns preprocessed source text.
    """
    if defines is None:
        defines = set()
    if included is None:
        included = set()

    abs_path = os.path.abspath(source_path)
    included.add(abs_path)
    base_dir = os.path.dirname(abs_path)

    lines = source.split('\n')
    result = []
    cond_stack = []  # stack of bools: True = emit lines, False = skip

    for line in lines:
        stripped = line.strip()

        # #define SYMBOL
        if stripped.startswith('#define '):
            if not cond_stack or all(cond_stack):
                sym = stripped[8:].strip()
                if sym:
                    defines.add(sym)
            result.append('')
            continue

        # #ifdef SYMBOL
        if stripped.startswith('#ifdef '):
            sym = stripped[7:].strip()
            parent_active = not cond_stack or all(cond_stack)
            cond_stack.append(parent_active and sym in defines)
            result.append('')
            continue

        # #ifndef SYMBOL
        if stripped.startswith('#ifndef '):
            sym = stripped[8:].strip()
            parent_active = not cond_stack or all(cond_stack)
            cond_stack.append(parent_active and sym not in defines)
            result.append('')
            continue

        # #else
        if stripped == '#else':
            if cond_stack:
                # Flip, but only if parent is active
                parent_active = all(cond_stack[:-1]) if len(cond_stack) > 1 else True
                cond_stack[-1] = parent_active and not cond_stack[-1]
            result.append('')
            continue

        # #endif
        if stripped == '#endif':
            if cond_stack:
                cond_stack.pop()
            result.append('')
            continue

        # Skip lines in false branches
        if cond_stack and not all(cond_stack):
            result.append('')
            continue

        # #include "file.mc"
        if stripped.startswith('#include "') and stripped.endswith('"'):
            inc_name = stripped[10:-1]
            inc_path = os.path.join(base_dir, inc_name)
            inc_abs = os.path.abspath(inc_path)

            # Diamond/cycle guard
            if inc_abs in included:
                result.append('')
                continue

            try:
                with open(inc_path, 'r') as f:
                    inc_source = f.read()
            except IOError:
                raise RuntimeError(
                    f"#include error: cannot find '{inc_name}' "
                    f"(searched in {base_dir})")

            inc_processed = preprocess(inc_source, inc_path, defines, included)
            result.append(inc_processed)
            continue

        # Regular line
        result.append(line)

    return '\n'.join(result)


def compile_file(source_path: str, output_path: str, text_output: str = None,
                 expr_output: str = None,
                 dump_tokens: bool = False, dump_ast: bool = False,
                 verbose: bool = False, defines: set = None,
                 strip_debug: bool = False,
                 scramble_globals: bool = False) -> bool:
    """
    Compile a MystC source file to bytecode.

    Returns True on success, False on error.
    """
    # Read source
    try:
        with open(source_path, 'r') as f:
            source = f.read()
    except IOError as e:
        print(f"Error: Cannot read '{source_path}': {e}", file=sys.stderr)
        return False

    if verbose:
        print(f"Compiling {source_path}...")

    # Preprocess (#include, #ifdef, #define)
    try:
        source = preprocess(source, source_path, defines=defines)
    except RuntimeError as e:
        print(f"Preprocessor error: {e}", file=sys.stderr)
        return False

    # Tokenize
    tokens = tokenize(source, source_path)

    if dump_tokens:
        print("=== Tokens ===")
        for tok in tokens:
            print(f"  {tok}")
        print()

    # Check for lexer errors
    for tok in tokens:
        if tok.type.name == 'ERROR':
            print(f"Lexer error: {tok.value}", file=sys.stderr)
            return False

    # Parse
    parser = Parser(tokens, source_path)
    program = parser.parse_program()

    if parser.errors:
        for err in parser.errors:
            print(f"Parse error: {err}", file=sys.stderr)
        return False

    if dump_ast:
        print("=== AST ===")
        print(print_ast(program))
        print()

    # Type check
    success, symbols, errors = typecheck(program)

    if not success:
        for err in errors:
            print(f"Type error: {err}", file=sys.stderr)
        return False

    if verbose:
        print(f"  Type checking passed")

    # Strip debug-print call sites for release builds
    if strip_debug:
        n_stripped = strip_debug_calls(program)
        if verbose:
            print(f"  Stripped {n_stripped} debug-print call(s)")

    # Generate IR
    mc_program = generate_ir(program, symbols)

    if scramble_globals:
        n_demoted = scramble_globals_pass(mc_program)
        if verbose:
            print(f"  Demoted {n_demoted} global initializer(s) into __init_globals")

    if verbose:
        print(f"  Generated {len(mc_program.functions)} functions")
        print(f"  Generated {len(mc_program.globals)} globals")
        print(f"  Generated {len(mc_program.strings)} strings")

    # Write output
    try:
        write_bytecode(mc_program, output_path)
        if verbose:
            print(f"  Wrote bytecode to {output_path}")
    except IOError as e:
        print(f"Error: Cannot write '{output_path}': {e}", file=sys.stderr)
        return False

    # Write text output if requested
    if text_output:
        try:
            write_text(mc_program, text_output)
            if verbose:
                print(f"  Wrote text IR to {text_output}")
        except IOError as e:
            print(f"Error: Cannot write '{text_output}': {e}", file=sys.stderr)
            return False

    # Write expression-style output if requested
    if expr_output:
        try:
            write_expr(mc_program, expr_output)
            if verbose:
                print(f"  Wrote expr IR to {expr_output}")
        except Exception as e:
            print(f"Error: Cannot write expr IR '{expr_output}': {e}", file=sys.stderr)
            return False

    return True


def main():
    parser = argparse.ArgumentParser(
        description='MystC Compiler Frontend - Compiles MystC to .mcb bytecode'
    )
    parser.add_argument('source', help='Source file to compile')
    parser.add_argument('-o', '--output', help='Output bytecode file (default: <source>.mcb)')
    parser.add_argument('--text', help='Also output text IR to this file')
    parser.add_argument('--expr', help='Also output expression-style IR to this file (.mce)')
    parser.add_argument('--dump-tokens', action='store_true', help='Dump tokens')
    parser.add_argument('--dump-ast', action='store_true', help='Dump AST')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    parser.add_argument('-D', action='append', default=[], dest='defines',
                        help='Define preprocessor symbol (e.g. -DWIN32)')
    parser.add_argument('--strip-debug', action='store_true',
                        help='Elide print/print_int/print_hex/print_err/print_int_err call sites '
                             '(unreferenced string literals drop out of the string table)')
    parser.add_argument('--scramble-globals', action='store_true',
                        help='Demote integer-literal global initializers into a generated '
                             '__init_globals function and scramble the .data init values. '
                             'No-op for library compiles (no main).')

    args = parser.parse_args()

    # Determine output path
    if args.output:
        output_path = args.output
    else:
        base = os.path.splitext(args.source)[0]
        output_path = base + '.mcb'

    # Parse -D flags
    defines = set(args.defines) if args.defines else None

    # Compile
    success = compile_file(
        args.source,
        output_path,
        text_output=args.text,
        expr_output=args.expr,
        dump_tokens=args.dump_tokens,
        dump_ast=args.dump_ast,
        verbose=args.verbose,
        defines=defines,
        strip_debug=args.strip_debug,
        scramble_globals=args.scramble_globals,
    )

    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
