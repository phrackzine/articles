"""
Bytecode format definitions for .mcb files.
Matches MC_BYTECODE_SPECIFICATION.md
"""

import struct
from enum import IntEnum
from dataclasses import dataclass, field
from typing import List, Dict, Optional, BinaryIO


# Magic number: "MCBN" (MystC ByteCode Notation)
MC_MAGIC = b'MCBN'
MC_VERSION = 1
TARGET_X86_32 = 1
TARGET_X86_64 = 2


class TypeCode(IntEnum):
    VOID = 0x00
    I8 = 0x01
    I32 = 0x02
    PTR = 0x03


class Opcode(IntEnum):
    NOP = 0x00
    CONST = 0x01
    COPY = 0x02

    # Arithmetic
    ADD = 0x10
    SUB = 0x11
    MUL = 0x12
    DIV = 0x13
    MOD = 0x14
    NEG = 0x15

    # Bitwise
    AND = 0x20
    OR = 0x21
    XOR = 0x22
    NOT = 0x23
    SHL = 0x24
    SHR = 0x25

    # Comparison
    EQ = 0x30
    NE = 0x31
    LT = 0x32
    LE = 0x33
    GT = 0x34
    GE = 0x35

    # Memory
    LOAD = 0x40
    STORE = 0x41
    ADDR = 0x42
    PTRADD = 0x43
    FIELDPTR = 0x44
    ALLOCA = 0x45

    # Control flow
    JMP = 0x50
    JZ = 0x51
    JNZ = 0x52

    # Function
    CALL = 0x60
    CALLV = 0x61
    RET = 0x62
    RETV = 0x63
    ICALL = 0x64   # Indirect call through variable (function pointer)
    ICALLV = 0x65  # Indirect void call through variable
    FUNC_ADDR = 0x66  # Get code address of a function
    SYSCALL = 0x67    # Linux INT 0x80 syscall: dest, num, a1..a5

    # Inline bytes
    EMIT = 0x70


class ValueKind(IntEnum):
    TEMP = 0x00
    PARAM = 0x01
    LOCAL = 0x02
    GLOBAL = 0x03
    CONST_IMM = 0x04
    STRING = 0x05
    TEMP_EXT = 0x80  # For temps > 255


class LocationKind(IntEnum):
    LOCAL = 0x00
    GLOBAL = 0x01


@dataclass
class Value:
    """Represents an operand value."""
    kind: ValueKind
    index: int = 0
    imm_value: int = 0  # For CONST_IMM

    def encode(self) -> bytes:
        if self.kind == ValueKind.CONST_IMM:
            return bytes([self.kind]) + struct.pack('<i', self.imm_value)
        else:
            # All non-const operands: kind (1 byte) + index (2 bytes, u16)
            return bytes([self.kind]) + struct.pack('<H', self.index)


@dataclass
class Instruction:
    """Represents a bytecode instruction."""
    opcode: Opcode
    dest: Optional[Value] = None
    arg1: Optional[Value] = None
    arg2: Optional[Value] = None
    type_code: TypeCode = TypeCode.I32
    # For jumps
    target_block: int = 0
    # For calls
    func_index: int = 0
    nargs: int = 0
    args: List[Value] = field(default_factory=list)
    # For fieldptr/ptradd
    offset: int = 0
    elem_size: int = 0
    # For EMIT
    emit_bytes: List[int] = field(default_factory=list)

    def encode(self) -> bytes:
        data = bytes([self.opcode])

        if self.opcode == Opcode.NOP:
            return data

        elif self.opcode == Opcode.CONST:
            data += self.dest.encode()
            data += struct.pack('<I', self.arg1.imm_value & 0xFFFFFFFF)
            data += bytes([self.type_code])

        elif self.opcode in (Opcode.ADD, Opcode.SUB, Opcode.MUL, Opcode.DIV, Opcode.MOD,
                              Opcode.AND, Opcode.OR, Opcode.XOR, Opcode.SHL, Opcode.SHR,
                              Opcode.EQ, Opcode.NE, Opcode.LT, Opcode.LE, Opcode.GT, Opcode.GE):
            data += self.dest.encode()
            data += self.arg1.encode()
            data += self.arg2.encode()
            data += bytes([self.type_code])

        elif self.opcode in (Opcode.NEG, Opcode.NOT, Opcode.COPY):
            data += self.dest.encode()
            data += self.arg1.encode()
            data += bytes([self.type_code])

        elif self.opcode == Opcode.LOAD:
            data += self.dest.encode()
            data += self.arg1.encode()
            data += bytes([self.type_code])

        elif self.opcode == Opcode.STORE:
            data += self.arg1.encode()  # addr
            data += self.arg2.encode()  # value
            data += bytes([self.type_code])

        elif self.opcode == Opcode.ADDR:
            data += self.dest.encode()
            data += bytes([LocationKind.LOCAL if self.arg1.kind == ValueKind.LOCAL else LocationKind.GLOBAL])
            data += bytes([self.arg1.index & 0xFF])
            if self.arg1.kind == ValueKind.GLOBAL:
                data += bytes([(self.arg1.index >> 8) & 0xFF])

        elif self.opcode == Opcode.PTRADD:
            data += self.dest.encode()
            data += self.arg1.encode()  # base
            data += self.arg2.encode()  # offset
            data += struct.pack('<H', self.elem_size)

        elif self.opcode == Opcode.FIELDPTR:
            data += self.dest.encode()
            data += self.arg1.encode()  # base
            data += struct.pack('<H', self.offset)

        elif self.opcode == Opcode.ALLOCA:
            data += self.dest.encode()
            data += struct.pack('<H', self.offset)  # size
            data += bytes([self.elem_size])  # align

        elif self.opcode == Opcode.JMP:
            data += struct.pack('<H', self.target_block)

        elif self.opcode in (Opcode.JZ, Opcode.JNZ):
            data += self.arg1.encode()
            data += struct.pack('<H', self.target_block)

        elif self.opcode == Opcode.CALL:
            data += self.dest.encode()
            data += struct.pack('<H', self.func_index)
            data += bytes([self.nargs])
            for arg in self.args:
                data += arg.encode()

        elif self.opcode == Opcode.CALLV:
            data += struct.pack('<H', self.func_index)
            data += bytes([self.nargs])
            for arg in self.args:
                data += arg.encode()

        elif self.opcode == Opcode.ICALL:
            data += self.dest.encode()
            data += self.arg1.encode()  # target address (variable)
            data += bytes([self.nargs])
            for arg in self.args:
                data += arg.encode()

        elif self.opcode == Opcode.ICALLV:
            data += self.arg1.encode()  # target address (variable)
            data += bytes([self.nargs])
            for arg in self.args:
                data += arg.encode()

        elif self.opcode == Opcode.FUNC_ADDR:
            data += self.dest.encode()
            data += struct.pack('<H', self.func_index)

        elif self.opcode == Opcode.SYSCALL:
            # dest + 6 fixed args (num, a1..a5)
            data += self.dest.encode()
            assert len(self.args) == 6, f"SYSCALL must have 6 args, got {len(self.args)}"
            for arg in self.args:
                data += arg.encode()

        elif self.opcode == Opcode.RET:
            data += self.arg1.encode()

        elif self.opcode == Opcode.RETV:
            pass  # No operands

        elif self.opcode == Opcode.EMIT:
            data += bytes([len(self.emit_bytes)])
            data += bytes(self.emit_bytes)

        return data


@dataclass
class Block:
    """A basic block."""
    label: str
    instructions: List[Instruction] = field(default_factory=list)


@dataclass
class MCFunction:
    """A function in the bytecode."""
    name: str
    return_type: TypeCode
    param_types: List[TypeCode] = field(default_factory=list)
    local_types: List[TypeCode] = field(default_factory=list)
    local_sizes: List[int] = field(default_factory=list)  # For arrays
    blocks: List[Block] = field(default_factory=list)
    num_temps: int = 0
    is_extern: bool = False  # True for extern function declarations
    dll: str = ""  # DLL name for extern functions (e.g., "user32.dll")


@dataclass
class MCStruct:
    """A struct definition."""
    name: str
    size: int
    align: int
    fields: List[tuple] = field(default_factory=list)  # (name, type_code, offset)


@dataclass
class MCGlobal:
    """A global variable."""
    name: str
    type_code: TypeCode
    init_kind: int = 0  # 0=zero, 1=const, 2=string_ref
    init_value: int = 0


@dataclass
class MCProgram:
    """Complete bytecode program."""
    strings: List[str] = field(default_factory=list)
    structs: List[MCStruct] = field(default_factory=list)
    globals: List[MCGlobal] = field(default_factory=list)
    functions: List[MCFunction] = field(default_factory=list)

    # Lookup tables (built during serialization)
    string_indices: Dict[str, int] = field(default_factory=dict)
    func_indices: Dict[str, int] = field(default_factory=dict)
    global_indices: Dict[str, int] = field(default_factory=dict)

    def add_string(self, s: str) -> int:
        """Add a string literal, return its index."""
        if s in self.string_indices:
            return self.string_indices[s]
        idx = len(self.strings)
        self.strings.append(s)
        self.string_indices[s] = idx
        return idx

    def build_indices(self):
        """Build lookup indices."""
        self.string_indices = {s: i for i, s in enumerate(self.strings)}
        self.func_indices = {f.name: i for i, f in enumerate(self.functions)}
        self.global_indices = {g.name: i for i, g in enumerate(self.globals)}


class BytecodeWriter:
    """Writes MCProgram to binary .mcb file."""

    def __init__(self, program: MCProgram):
        self.program = program
        self.program.build_indices()

    def write(self, f: BinaryIO):
        """Write the complete bytecode file."""
        self._write_header(f)
        self._write_strings(f)
        self._write_structs(f)
        self._write_globals(f)
        self._write_functions(f)

    def _write_header(self, f: BinaryIO):
        f.write(MC_MAGIC)
        f.write(struct.pack('<H', MC_VERSION))
        f.write(bytes([TARGET_X86_32, 0]))  # target, flags
        f.write(struct.pack('<H', len(self.program.strings)))
        f.write(struct.pack('<H', len(self.program.structs)))
        f.write(struct.pack('<H', len(self.program.globals)))
        f.write(struct.pack('<H', len(self.program.functions)))

    def _write_strings(self, f: BinaryIO):
        # Calculate offsets and total size
        offsets = []
        offset = 0
        for s in self.program.strings:
            offsets.append(offset)
            offset += len(s.encode('utf-8')) + 1  # +1 for null terminator

        f.write(struct.pack('<I', offset))  # total size

        for off in offsets:
            f.write(struct.pack('<I', off))

        for s in self.program.strings:
            f.write(s.encode('utf-8'))
            f.write(b'\x00')

    def _write_structs(self, f: BinaryIO):
        for struct_def in self.program.structs:
            name_idx = self.program.string_indices.get(struct_def.name, 0)
            f.write(struct.pack('<H', name_idx))
            f.write(struct.pack('<H', struct_def.size))
            f.write(bytes([struct_def.align]))
            f.write(bytes([len(struct_def.fields)]))

            for field_name, field_type, field_offset in struct_def.fields:
                field_name_idx = self.program.string_indices.get(field_name, 0)
                f.write(struct.pack('<H', field_name_idx))
                f.write(bytes([field_type]))
                f.write(struct.pack('<H', field_offset))

    def _write_globals(self, f: BinaryIO):
        for g in self.program.globals:
            name_idx = self.program.string_indices.get(g.name, 0)
            f.write(struct.pack('<H', name_idx))
            f.write(bytes([g.type_code]))
            f.write(bytes([g.init_kind]))
            f.write(struct.pack('<i', g.init_value))

    def _write_functions(self, f: BinaryIO):
        for func in self.program.functions:
            name_idx = self.program.string_indices.get(func.name, 0)
            f.write(struct.pack('<H', name_idx))
            f.write(bytes([func.return_type]))
            f.write(bytes([len(func.param_types)]))
            f.write(bytes([len(func.local_types)]))
            f.write(struct.pack('<H', len(func.blocks)))
            f.write(struct.pack('<H', func.num_temps))
            # Write DLL name index for extern functions (0 = no DLL/builtin)
            dll_idx = self.program.string_indices.get(func.dll, 0) if func.is_extern and func.dll else 0
            f.write(struct.pack('<H', dll_idx))

            for pt in func.param_types:
                f.write(bytes([pt]))

            for i, lt in enumerate(func.local_types):
                f.write(bytes([lt]))
                f.write(struct.pack('<H', func.local_sizes[i] if i < len(func.local_sizes) else 0))

            for block in func.blocks:
                label_idx = self.program.string_indices.get(block.label, 0)
                f.write(struct.pack('<H', label_idx))
                f.write(struct.pack('<H', len(block.instructions)))

                for instr in block.instructions:
                    f.write(instr.encode())


def write_bytecode(program: MCProgram, filename: str):
    """Write bytecode program to file."""
    with open(filename, 'wb') as f:
        writer = BytecodeWriter(program)
        writer.write(f)


# ============================================================================
# Text format writer (for debugging)
# ============================================================================

class _ProgramWalker:
    """Shared walk for text-style IR writers.

    Subclasses override the formatting hooks; the `write()` method drives the
    header → strings → structs → globals → functions traversal once.
    """

    def __init__(self, program: MCProgram):
        self.program = program
        self._current_blocks: List[Block] = []

    def write(self, f):
        hdr = self._fmt_header()
        if hdr:
            f.write(hdr)

        for i, s in enumerate(self.program.strings):
            f.write(self._fmt_string(i, s) + "\n")
        if self.program.strings:
            f.write("\n")

        for st in self.program.structs:
            self._write_struct(f, st)

        for g in self.program.globals:
            f.write(self._fmt_global(g) + "\n")
        if self.program.globals:
            f.write("\n")

        for func in self.program.functions:
            self._write_function(f, func)

    # ── hooks ───────────────────────────────────────────────────────────────
    def _fmt_header(self) -> str: return ""
    def _fmt_string(self, i: int, s: str) -> str: raise NotImplementedError
    def _write_struct(self, f, st: "MCStruct") -> None: raise NotImplementedError
    def _fmt_global(self, g: "MCGlobal") -> str: raise NotImplementedError
    def _write_function(self, f, func: MCFunction) -> None: raise NotImplementedError

    # ── shared helpers ──────────────────────────────────────────────────────
    @staticmethod
    def _escape(s: str) -> str:
        return (s.replace('\\', '\\\\').replace('"', '\\"')
                 .replace('\n', '\\n').replace('\t', '\\t'))

    def _global_name(self, idx: int) -> str:
        if idx < len(self.program.globals):
            return self.program.globals[idx].name
        return f"global{idx}"

    def _func_name(self, idx: int) -> str:
        if idx < len(self.program.functions):
            return self.program.functions[idx].name
        return f"func{idx}"

    def _block_label(self, idx: int) -> str:
        if idx < len(self._current_blocks):
            return self._current_blocks[idx].label
        return f"block{idx}"


class TextWriter(_ProgramWalker):
    """Writes MCProgram to text .mct file."""

    def _fmt_header(self) -> str:
        return f".version {MC_VERSION}\n.target x86-32\n\n"

    def _fmt_string(self, i: int, s: str) -> str:
        return f'.string {i} "{self._escape(s)}"'

    def _write_struct(self, f, st) -> None:
        f.write(f".struct {st.name} {st.size} {st.align}\n")
        for name, type_code, offset in st.fields:
            f.write(f"    .field {name} {self._type_name(type_code)} {offset}\n")
        f.write(".end\n\n")

    def _fmt_global(self, g) -> str:
        return f".global @{g.name} {self._type_name(g.type_code)} {g.init_value}"

    def _type_name(self, tc: TypeCode) -> str:
        return {TypeCode.VOID: 'void', TypeCode.I8: 'i8', TypeCode.I32: 'i32', TypeCode.PTR: 'ptr'}[tc]

    def _write_function(self, f, func: MCFunction):
        params = ' '.join(f"${i}:{self._type_name(pt)}" for i, pt in enumerate(func.param_types))
        ret = f" -> {self._type_name(func.return_type)}" if func.return_type != TypeCode.VOID else ""
        f.write(f".func @{func.name} {params}{ret}\n")

        for i, lt in enumerate(func.local_types):
            size = func.local_sizes[i] if i < len(func.local_sizes) else 0
            if size > 0:
                f.write(f"    .local !{i} {self._type_name(lt)} {size}\n")
            else:
                f.write(f"    .local !{i} {self._type_name(lt)}\n")

        self._current_blocks = func.blocks

        for block in func.blocks:
            f.write(f".{block.label}:\n")
            for instr in block.instructions:
                f.write(f"    {self._format_instruction(instr)}\n")

        f.write(".end\n\n")

    def _format_instruction(self, instr: Instruction) -> str:
        def val(v: Value) -> str:
            if v is None:
                return "_"
            if v.kind == ValueKind.TEMP or v.kind == ValueKind.TEMP_EXT:
                return f"%{v.index}"
            elif v.kind == ValueKind.PARAM:
                return f"${v.index}"
            elif v.kind == ValueKind.LOCAL:
                return f"!{v.index}"
            elif v.kind == ValueKind.GLOBAL:
                return f"@{self._global_name(v.index)}"
            elif v.kind == ValueKind.CONST_IMM:
                return str(v.imm_value)
            elif v.kind == ValueKind.STRING:
                return f".string:{v.index}"
            return "?"

        op_names = {
            Opcode.NOP: "nop", Opcode.CONST: "const", Opcode.COPY: "copy",
            Opcode.ADD: "add", Opcode.SUB: "sub", Opcode.MUL: "mul",
            Opcode.DIV: "div", Opcode.MOD: "mod", Opcode.NEG: "neg",
            Opcode.AND: "and", Opcode.OR: "or", Opcode.XOR: "xor",
            Opcode.NOT: "not", Opcode.SHL: "shl", Opcode.SHR: "shr",
            Opcode.EQ: "eq", Opcode.NE: "ne", Opcode.LT: "lt",
            Opcode.LE: "le", Opcode.GT: "gt", Opcode.GE: "ge",
            Opcode.LOAD: "load", Opcode.STORE: "store", Opcode.ADDR: "addr",
            Opcode.PTRADD: "ptradd", Opcode.FIELDPTR: "fieldptr", Opcode.ALLOCA: "alloca",
            Opcode.JMP: "jmp", Opcode.JZ: "jz", Opcode.JNZ: "jnz",
            Opcode.CALL: "call", Opcode.CALLV: "call", Opcode.RET: "ret", Opcode.RETV: "ret",
        }

        name = op_names.get(instr.opcode, "???")
        tn = {TypeCode.VOID: 'void', TypeCode.I8: 'i8', TypeCode.I32: 'i32', TypeCode.PTR: 'ptr'}[instr.type_code]

        if instr.opcode == Opcode.NOP:
            return "nop"
        elif instr.opcode == Opcode.CONST:
            return f"{val(instr.dest)} = const {instr.arg1.imm_value} {tn}"
        elif instr.opcode in (Opcode.ADD, Opcode.SUB, Opcode.MUL, Opcode.DIV, Opcode.MOD,
                               Opcode.AND, Opcode.OR, Opcode.XOR, Opcode.SHL, Opcode.SHR,
                               Opcode.EQ, Opcode.NE, Opcode.LT, Opcode.LE, Opcode.GT, Opcode.GE):
            return f"{val(instr.dest)} = {name} {val(instr.arg1)} {val(instr.arg2)} {tn}"
        elif instr.opcode in (Opcode.NEG, Opcode.NOT, Opcode.COPY):
            return f"{val(instr.dest)} = {name} {val(instr.arg1)} {tn}"
        elif instr.opcode == Opcode.LOAD:
            return f"{val(instr.dest)} = load {val(instr.arg1)} {tn}"
        elif instr.opcode == Opcode.STORE:
            return f"store {val(instr.arg1)} {val(instr.arg2)} {tn}"
        elif instr.opcode == Opcode.ADDR:
            return f"{val(instr.dest)} = addr {val(instr.arg1)}"
        elif instr.opcode == Opcode.PTRADD:
            return f"{val(instr.dest)} = ptradd {val(instr.arg1)} {val(instr.arg2)} {instr.elem_size}"
        elif instr.opcode == Opcode.FIELDPTR:
            return f"{val(instr.dest)} = fieldptr {val(instr.arg1)} {instr.offset}"
        elif instr.opcode == Opcode.ALLOCA:
            return f"{val(instr.dest)} = alloca {instr.offset} {instr.elem_size}"
        elif instr.opcode == Opcode.JMP:
            return f"jmp .{self._block_label(instr.target_block)}"
        elif instr.opcode == Opcode.JZ:
            return f"jz {val(instr.arg1)} .{self._block_label(instr.target_block)}"
        elif instr.opcode == Opcode.JNZ:
            return f"jnz {val(instr.arg1)} .{self._block_label(instr.target_block)}"
        elif instr.opcode == Opcode.CALL:
            args = ' '.join(val(a) for a in instr.args)
            return f"{val(instr.dest)} = call @{self._func_name(instr.func_index)} {args} {tn}"
        elif instr.opcode == Opcode.CALLV:
            args = ' '.join(val(a) for a in instr.args)
            return f"call @{self._func_name(instr.func_index)} {args}"
        elif instr.opcode == Opcode.ICALL:
            args = ' '.join(val(a) for a in instr.args)
            return f"{val(instr.dest)} = icall {val(instr.arg1)} {args} {tn}"
        elif instr.opcode == Opcode.ICALLV:
            args = ' '.join(val(a) for a in instr.args)
            return f"icall {val(instr.arg1)} {args}"
        elif instr.opcode == Opcode.FUNC_ADDR:
            return f"{val(instr.dest)} = func_addr @{self._func_name(instr.func_index)}"
        elif instr.opcode == Opcode.SYSCALL:
            args = ' '.join(val(a) for a in instr.args)
            return f"{val(instr.dest)} = syscall {args} {tn}"
        elif instr.opcode == Opcode.RET:
            return f"ret {val(instr.arg1)}"
        elif instr.opcode == Opcode.RETV:
            return "ret"

        elif instr.opcode == Opcode.EMIT:
            hex_bytes = ' '.join(f'0x{b:02x}' for b in instr.emit_bytes)
            return f"emit {hex_bytes}"

        return f"??? {instr.opcode}"


def write_text(program: MCProgram, filename: str):
    """Write text IR to file."""
    with open(filename, 'w') as f:
        writer = TextWriter(program)
        writer.write(f)


# ============================================================================
# Expression-style IR writer (.mce)
# ============================================================================

class ExprWriter(_ProgramWalker):
    """
    Writes MCProgram to a readable expression-style .mce file.

    Operand naming:
      %N (temp)   -> tN
      $N (param)  -> pN
      !N (local)  -> lN
      @name (global) -> name
      constant    -> literal number
      .string:N   -> sN

    Instruction style:
      assignment  -> tX = expr
      void call   -> func(a, b)
      jumps       -> goto label / if (cond) goto label
      return      -> return val
    """

    _BIN_OPS = {
        Opcode.ADD: '+',  Opcode.SUB: '-',  Opcode.MUL: '*',
        Opcode.DIV: '/',  Opcode.MOD: '%',
        Opcode.AND: '&',  Opcode.OR:  '|',  Opcode.XOR: '^',
        Opcode.SHL: '<<', Opcode.SHR: '>>',
        Opcode.EQ:  '==', Opcode.NE:  '!=',
        Opcode.LT:  '<',  Opcode.LE:  '<=',
        Opcode.GT:  '>',  Opcode.GE:  '>=',
    }

    def _fmt_string(self, i: int, s: str) -> str:
        return f'str s{i} = "{self._escape(s)}"'

    def _write_struct(self, f, st) -> None:
        f.write(f'struct {st.name} ({st.size} bytes, align {st.align}) {{\n')
        for fname, ftype, foffset in st.fields:
            f.write(f'    +{foffset}: {self._tn(ftype)} {fname}\n')
        f.write('}\n\n')

    def _fmt_global(self, g) -> str:
        return f'global {g.name}: {self._tn(g.type_code)} = {g.init_value}'

    def _tn(self, tc: TypeCode) -> str:
        return {TypeCode.VOID: 'void', TypeCode.I8: 'char',
                TypeCode.I32: 'int', TypeCode.PTR: 'ptr'}[tc]

    def _write_function(self, f, func: MCFunction):
        params = ', '.join(f'{self._tn(pt)} arg{i}' for i, pt in enumerate(func.param_types))
        ret = self._tn(func.return_type)

        if func.is_extern:
            dll_note = f'  // dll: "{func.dll}"' if func.dll else ''
            f.write(f'extern {ret} {func.name}({params});{dll_note}\n\n')
            return

        f.write(f'{ret} {func.name}({params}) {{\n')

        for i, lt in enumerate(func.local_types):
            size = func.local_sizes[i] if i < len(func.local_sizes) else 0
            suffix = f'[{size}]' if size > 0 else ''
            f.write(f'    {self._tn(lt)} l{i}{suffix};\n')
        if func.local_types:
            f.write('\n')

        self._current_blocks = func.blocks
        for block in func.blocks:
            f.write(f'  {block.label}:\n')
            for instr in block.instructions:
                line = self._fmt(instr)
                if line:
                    f.write(f'    {line}\n')

        f.write('}\n\n')

    # _global_name / _func_name / _block_label provided by _ProgramWalker base.

    def _v(self, v: Value) -> str:
        if v is None:
            return '_'
        if v.kind in (ValueKind.TEMP, ValueKind.TEMP_EXT):
            return f't{v.index}'
        if v.kind == ValueKind.PARAM:
            return f'arg{v.index}'
        if v.kind == ValueKind.LOCAL:
            return f'l{v.index}'
        if v.kind == ValueKind.GLOBAL:
            return self._global_name(v.index)
        if v.kind == ValueKind.CONST_IMM:
            return str(v.imm_value)
        if v.kind == ValueKind.STRING:
            return f's{v.index}'
        return '?'

    def _fmt(self, instr: Instruction) -> str:
        v = self._v
        d = v(instr.dest)

        if instr.opcode == Opcode.NOP:
            return 'nop'

        if instr.opcode == Opcode.CONST:
            return f'{d} = {instr.arg1.imm_value}'

        if instr.opcode in self._BIN_OPS:
            op = self._BIN_OPS[instr.opcode]
            rhs = f'{v(instr.arg1)} {op} {v(instr.arg2)}'
            if instr.opcode in (Opcode.EQ, Opcode.NE, Opcode.LT,
                                Opcode.LE, Opcode.GT, Opcode.GE):
                rhs = f'({rhs})'
            return f'{d} = {rhs}'

        if instr.opcode == Opcode.NEG:
            return f'{d} = -{v(instr.arg1)}'
        if instr.opcode == Opcode.NOT:
            return f'{d} = ~{v(instr.arg1)}'
        if instr.opcode == Opcode.COPY:
            return f'{d} = {v(instr.arg1)}'

        if instr.opcode == Opcode.LOAD:
            return f'{d} = *{v(instr.arg1)}'
        if instr.opcode == Opcode.STORE:
            return f'*{v(instr.arg1)} = {v(instr.arg2)}'
        if instr.opcode == Opcode.ADDR:
            return f'{d} = &{v(instr.arg1)}'

        if instr.opcode == Opcode.PTRADD:
            stride = instr.elem_size
            idx = v(instr.arg2)
            scale = f'{idx}*{stride}' if stride != 1 else idx
            return f'{d} = {v(instr.arg1)} + {scale}'
        if instr.opcode == Opcode.FIELDPTR:
            return f'{d} = {v(instr.arg1)} + {instr.offset}'
        if instr.opcode == Opcode.ALLOCA:
            return f'{d} = alloca({instr.offset}, {instr.elem_size})'

        if instr.opcode == Opcode.JMP:
            return f'goto {self._block_label(instr.target_block)}'
        if instr.opcode == Opcode.JZ:
            return f'if (!{v(instr.arg1)}) goto {self._block_label(instr.target_block)}'
        if instr.opcode == Opcode.JNZ:
            return f'if ({v(instr.arg1)}) goto {self._block_label(instr.target_block)}'

        if instr.opcode == Opcode.CALL:
            args = ', '.join(v(a) for a in instr.args)
            return f'{d} = {self._func_name(instr.func_index)}({args})'
        if instr.opcode == Opcode.CALLV:
            args = ', '.join(v(a) for a in instr.args)
            return f'{self._func_name(instr.func_index)}({args})'
        if instr.opcode == Opcode.ICALL:
            args = ', '.join(v(a) for a in instr.args)
            return f'{d} = (*{v(instr.arg1)})({args})'
        if instr.opcode == Opcode.ICALLV:
            args = ', '.join(v(a) for a in instr.args)
            return f'(*{v(instr.arg1)})({args})'
        if instr.opcode == Opcode.FUNC_ADDR:
            return f'{d} = &{self._func_name(instr.func_index)}'
        if instr.opcode == Opcode.SYSCALL:
            args = ', '.join(v(a) for a in instr.args)
            return f'{d} = syscall({args})'

        if instr.opcode == Opcode.RET:
            return f'return {v(instr.arg1)}'
        if instr.opcode == Opcode.RETV:
            return 'return'

        if instr.opcode == Opcode.EMIT:
            hex_bytes = ', '.join(f'0x{b:02x}' for b in instr.emit_bytes)
            return f'emit({hex_bytes})'

        return f'??? {instr.opcode}'


def write_expr(program: MCProgram, filename: str):
    """Write expression-style IR to .mce file."""
    with open(filename, 'w') as f:
        writer = ExprWriter(program)
        writer.write(f)


def expr_ir_text(program: MCProgram) -> str:
    """Return expression-style IR as a string (no file I/O)."""
    import io
    f = io.StringIO()
    ExprWriter(program).write(f)
    return f.getvalue()


def text_ir_text(program: MCProgram) -> str:
    """Return classic text IR as a string (no file I/O)."""
    import io
    f = io.StringIO()
    TextWriter(program).write(f)
    return f.getvalue()


# ============================================================================
# Bytecode reader (.mcb → MCProgram)
# ============================================================================

class BytecodeReader:
    """Reads a .mcb binary file back into an MCProgram object."""

    def __init__(self, data: bytes):
        self.data = data
        self.pos  = 0

    # ── Low-level I/O ────────────────────────────────────────────────────────

    def _read(self, n: int) -> bytes:
        b = self.data[self.pos : self.pos + n]
        if len(b) < n:
            raise EOFError(f"Unexpected EOF at pos {self.pos} (wanted {n}, got {len(b)})")
        self.pos += n
        return b

    def _u8(self)  -> int: return self._read(1)[0]
    def _u16(self) -> int: return struct.unpack('<H', self._read(2))[0]
    def _u32(self) -> int: return struct.unpack('<I', self._read(4))[0]
    def _i32(self) -> int: return struct.unpack('<i', self._read(4))[0]

    def _read_value(self) -> Value:
        kind_byte = self._u8()
        try:
            kind = ValueKind(kind_byte)
        except ValueError:
            kind = ValueKind.TEMP
        if kind == ValueKind.CONST_IMM:
            imm = self._i32()
            return Value(kind=kind, imm_value=imm)
        idx = self._u16()
        return Value(kind=kind, index=idx)

    # ── Top-level entry ──────────────────────────────────────────────────────

    def read(self) -> MCProgram:
        magic = self._read(4)
        if magic != MC_MAGIC:
            raise ValueError(f"Bad magic: {magic!r}")
        _version = self._u16()
        _target  = self._u8()
        _flags   = self._u8()
        n_strings   = self._u16()
        n_structs   = self._u16()
        n_globals   = self._u16()
        n_functions = self._u16()

        strings   = self._read_strings(n_strings)
        structs   = [self._read_struct(strings)   for _ in range(n_structs)]
        globals_  = [self._read_global(strings)   for _ in range(n_globals)]
        functions = [self._read_function(strings) for _ in range(n_functions)]

        return MCProgram(strings=strings, structs=structs,
                         globals=globals_, functions=functions)

    # ── Sections ─────────────────────────────────────────────────────────────

    def _read_strings(self, n: int) -> List[str]:
        total_size = self._u32()          # always present, even when n==0
        if n == 0:
            return []
        offsets = [self._u32() for _ in range(n)]
        raw = self._read(total_size)
        result = []
        for off in offsets:
            end = raw.index(0, off)
            result.append(raw[off:end].decode('utf-8', errors='replace'))
        return result

    def _read_struct(self, strings: List[str]) -> MCStruct:
        name_idx = self._u16()
        size     = self._u16()
        align    = self._u8()
        n_fields = self._u8()
        name = strings[name_idx] if name_idx < len(strings) else ''
        fields = []
        for _ in range(n_fields):
            fn_idx  = self._u16()
            ftype   = TypeCode(self._u8())
            foffset = self._u16()
            fname   = strings[fn_idx] if fn_idx < len(strings) else ''
            fields.append((fname, ftype, foffset))
        return MCStruct(name=name, size=size, align=align, fields=fields)

    def _read_global(self, strings: List[str]) -> MCGlobal:
        name_idx  = self._u16()
        type_code = TypeCode(self._u8())
        init_kind = self._u8()
        init_val  = self._u32()          # C emitter writes u32; cast to signed if needed
        name = strings[name_idx] if name_idx < len(strings) else ''
        return MCGlobal(name=name, type_code=type_code,
                        init_kind=init_kind, init_value=init_val)

    def _read_function(self, strings: List[str]) -> MCFunction:
        name_idx    = self._u16()
        return_type = TypeCode(self._u8())
        n_params    = self._u8()
        n_locals    = self._u8()
        n_blocks    = self._u16()
        num_temps   = self._u16()
        dll_idx     = self._u16()

        name = strings[name_idx] if name_idx < len(strings) else ''

        param_types = [TypeCode(self._u8()) for _ in range(n_params)]
        local_types, local_sizes = [], []
        for _ in range(n_locals):
            local_types.append(TypeCode(self._u8()))
            local_sizes.append(self._u16())

        is_extern = (n_blocks == 0)
        dll = strings[dll_idx] if (dll_idx and dll_idx < len(strings)) else ''

        blocks = [self._read_block(strings) for _ in range(n_blocks)]

        return MCFunction(name=name, return_type=return_type,
                          param_types=param_types, local_types=local_types,
                          local_sizes=local_sizes, blocks=blocks,
                          num_temps=num_temps, is_extern=is_extern, dll=dll)

    def _read_block(self, strings: List[str]) -> Block:
        label_idx = self._u16()
        n_instrs  = self._u16()
        label = strings[label_idx] if label_idx < len(strings) else 'blk'
        instructions = [self._read_instruction() for _ in range(n_instrs)]
        return Block(label=label, instructions=instructions)

    def _read_instruction(self) -> Instruction:  # noqa: C901
        op_byte = self._u8()
        try:
            opcode = Opcode(op_byte)
        except ValueError:
            raise ValueError(f"Unknown opcode 0x{op_byte:02x} at pos {self.pos-1}")

        if opcode == Opcode.NOP:
            return Instruction(opcode=opcode)

        if opcode == Opcode.CONST:
            dest = self._read_value()
            imm  = self._i32()
            tc   = TypeCode(self._u8())
            return Instruction(opcode=opcode, dest=dest,
                               arg1=Value(kind=ValueKind.CONST_IMM, imm_value=imm),
                               type_code=tc)

        if opcode in (Opcode.ADD, Opcode.SUB, Opcode.MUL, Opcode.DIV, Opcode.MOD,
                      Opcode.AND, Opcode.OR,  Opcode.XOR, Opcode.SHL, Opcode.SHR,
                      Opcode.EQ,  Opcode.NE,  Opcode.LT,  Opcode.LE,
                      Opcode.GT,  Opcode.GE):
            dest = self._read_value()
            arg1 = self._read_value()
            arg2 = self._read_value()
            tc   = TypeCode(self._u8())
            return Instruction(opcode=opcode, dest=dest, arg1=arg1, arg2=arg2, type_code=tc)

        if opcode in (Opcode.NEG, Opcode.NOT, Opcode.COPY):
            dest = self._read_value()
            arg1 = self._read_value()
            tc   = TypeCode(self._u8())
            return Instruction(opcode=opcode, dest=dest, arg1=arg1, type_code=tc)

        if opcode == Opcode.LOAD:
            dest = self._read_value()
            arg1 = self._read_value()
            tc   = TypeCode(self._u8())
            return Instruction(opcode=opcode, dest=dest, arg1=arg1, type_code=tc)

        if opcode == Opcode.STORE:
            # Both Python writer and C emitter write (addr, value, type_code).
            # Python: arg1=addr, arg2=value.  C: dest=addr, src1=value.
            arg1 = self._read_value()   # address
            arg2 = self._read_value()   # value
            tc   = TypeCode(self._u8())
            return Instruction(opcode=opcode, arg1=arg1, arg2=arg2, type_code=tc)

        if opcode == Opcode.ADDR:
            dest     = self._read_value()
            loc_kind = LocationKind(self._u8())
            idx_low  = self._u8()
            if loc_kind == LocationKind.GLOBAL:
                idx_high = self._u8()
                idx = idx_low | (idx_high << 8)
                vk = ValueKind.GLOBAL
            else:
                idx = idx_low
                vk = ValueKind.LOCAL
            return Instruction(opcode=opcode, dest=dest,
                               arg1=Value(kind=vk, index=idx))

        if opcode == Opcode.PTRADD:
            dest      = self._read_value()
            arg1      = self._read_value()
            arg2      = self._read_value()
            elem_size = self._u16()
            return Instruction(opcode=opcode, dest=dest, arg1=arg1, arg2=arg2,
                               elem_size=elem_size)

        if opcode == Opcode.FIELDPTR:
            dest   = self._read_value()
            arg1   = self._read_value()
            offset = self._u16()
            return Instruction(opcode=opcode, dest=dest, arg1=arg1, offset=offset)

        if opcode == Opcode.ALLOCA:
            dest  = self._read_value()
            size  = self._u16()
            align = self._u8()
            return Instruction(opcode=opcode, dest=dest, offset=size, elem_size=align)

        if opcode == Opcode.JMP:
            target = self._u16()
            return Instruction(opcode=opcode, target_block=target)

        if opcode in (Opcode.JZ, Opcode.JNZ):
            arg1   = self._read_value()
            target = self._u16()
            return Instruction(opcode=opcode, arg1=arg1, target_block=target)

        if opcode == Opcode.CALL:
            dest       = self._read_value()
            func_index = self._u16()
            nargs      = self._u8()
            args       = [self._read_value() for _ in range(nargs)]
            return Instruction(opcode=opcode, dest=dest, func_index=func_index,
                               nargs=nargs, args=args)

        if opcode == Opcode.CALLV:
            func_index = self._u16()
            nargs      = self._u8()
            args       = [self._read_value() for _ in range(nargs)]
            return Instruction(opcode=opcode, func_index=func_index,
                               nargs=nargs, args=args)

        if opcode == Opcode.ICALL:
            dest   = self._read_value()
            arg1   = self._read_value()  # target address
            nargs  = self._u8()
            args   = [self._read_value() for _ in range(nargs)]
            return Instruction(opcode=opcode, dest=dest, arg1=arg1,
                               nargs=nargs, args=args)

        if opcode == Opcode.ICALLV:
            arg1   = self._read_value()  # target address
            nargs  = self._u8()
            args   = [self._read_value() for _ in range(nargs)]
            return Instruction(opcode=opcode, arg1=arg1,
                               nargs=nargs, args=args)

        if opcode == Opcode.FUNC_ADDR:
            dest       = self._read_value()
            func_index = self._u16()
            return Instruction(opcode=opcode, dest=dest, func_index=func_index)

        if opcode == Opcode.SYSCALL:
            dest = self._read_value()
            args = [self._read_value() for _ in range(6)]
            return Instruction(opcode=opcode, dest=dest, nargs=6, args=args)

        if opcode == Opcode.RET:
            arg1 = self._read_value()
            return Instruction(opcode=opcode, arg1=arg1)

        if opcode == Opcode.RETV:
            return Instruction(opcode=opcode)

        if opcode == Opcode.EMIT:
            count = self._u8()
            raw = [self._u8() for _ in range(count)]
            return Instruction(opcode=opcode, emit_bytes=raw)

        raise ValueError(f"Unhandled opcode {opcode}")


def read_bytecode(filename: str) -> MCProgram:
    """Read a .mcb binary file and return an MCProgram."""
    with open(filename, 'rb') as f:
        data = f.read()
    return BytecodeReader(data).read()
