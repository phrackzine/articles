"""Strip debug-print call statements from the AST for release builds.

Removes top-level `ExprStmt` nodes whose expression is a direct call to one
of the debug-print functions. Indirect calls (function pointers) are left
alone since the target is not known statically. Function definitions
themselves are kept — only the call sites are removed; unreferenced string
literals naturally drop out at IR generation.
"""
from . import mystc_ast as ast

DEBUG_FUNCS = frozenset([
    "print", "print_int", "print_hex",
    "print_err", "print_int_err",
])


def _is_debug_call_stmt(stmt: ast.Stmt) -> bool:
    if not isinstance(stmt, ast.ExprStmt):
        return False
    e = stmt.expr
    if not isinstance(e, ast.CallExpr):
        return False
    if e.is_indirect:
        return False
    return e.func in DEBUG_FUNCS


def _strip_block(block: ast.Block) -> int:
    n = 0
    new_stmts = []
    for s in block.stmts:
        if _is_debug_call_stmt(s):
            n += 1
            continue
        n += _strip_stmt(s)
        new_stmts.append(s)
    block.stmts = new_stmts
    return n


def _strip_branch(stmt: ast.Stmt) -> tuple[ast.Stmt, int]:
    """Strip a branch stmt; if the whole branch is a stripped debug call,
    return an empty Block in its place (preserves grammar)."""
    if _is_debug_call_stmt(stmt):
        return ast.Block(stmts=[], line=stmt.line, column=stmt.column), 1
    return stmt, _strip_stmt(stmt)


def _strip_stmt(stmt: ast.Stmt) -> int:
    if isinstance(stmt, ast.Block):
        return _strip_block(stmt)
    if isinstance(stmt, ast.IfStmt):
        stmt.then_branch, n1 = _strip_branch(stmt.then_branch)
        n2 = 0
        if stmt.else_branch is not None:
            stmt.else_branch, n2 = _strip_branch(stmt.else_branch)
        return n1 + n2
    if isinstance(stmt, ast.WhileStmt):
        stmt.body, n = _strip_branch(stmt.body)
        return n
    if isinstance(stmt, ast.ForStmt):
        stmt.body, n = _strip_branch(stmt.body)
        return n
    return 0


def strip_debug_calls(program: ast.Program) -> int:
    """Walk every function body and remove debug-print call statements.
    Returns the number of stripped call sites."""
    total = 0
    for func in program.functions:
        if func.body is not None:
            total += _strip_block(func.body)
    return total
