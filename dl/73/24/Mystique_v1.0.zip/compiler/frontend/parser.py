"""
Recursive descent parser for MystC.
"""

from typing import List, Optional
from .tokens import Token, TokenType
from .lexer import Lexer
from . import mystc_ast as ast


class ParseError(Exception):
    def __init__(self, message: str, token: Token):
        self.message = message
        self.token = token
        super().__init__(f"{token.line}:{token.column}: {message}")


class Parser:
    def __init__(self, tokens: List[Token], filename: str = "<stdin>"):
        self.tokens = tokens
        self.filename = filename
        self.pos = 0
        self.errors: List[ParseError] = []

    def peek(self, offset: int = 0) -> Token:
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]  # Return EOF
        return self.tokens[pos]

    def current(self) -> Token:
        return self.peek(0)

    def advance(self) -> Token:
        tok = self.current()
        if tok.type != TokenType.EOF:
            self.pos += 1
        return tok

    def check(self, *types: TokenType) -> bool:
        return self.current().type in types

    def match(self, *types: TokenType) -> Optional[Token]:
        if self.check(*types):
            return self.advance()
        return None

    def expect(self, type: TokenType, msg: str = None) -> Token:
        if self.check(type):
            return self.advance()
        if msg is None:
            msg = f"Expected {type.name}, got {self.current().type.name}"
        raise ParseError(msg, self.current())

    def error(self, msg: str) -> ParseError:
        return ParseError(msg, self.current())

    def synchronize(self):
        """Skip tokens until we find a synchronization point."""
        self.advance()
        while not self.check(TokenType.EOF):
            if self.peek(-1).type == TokenType.SEMICOLON:
                return
            if self.check(TokenType.STRUCT, TokenType.INT, TokenType.CHAR,
                          TokenType.VOID, TokenType.IF, TokenType.WHILE,
                          TokenType.FOR, TokenType.RETURN, TokenType.RBRACE,
                          TokenType.EXTERN):
                return
            self.advance()

    # ========================================================================
    # Type parsing
    # ========================================================================

    def parse_base_type(self) -> ast.Type:
        """Parse a base type (int, char, void, struct name)."""
        tok = self.current()

        if self.match(TokenType.INT):
            return ast.INT_TYPE
        elif self.match(TokenType.CHAR):
            return ast.CHAR_TYPE
        elif self.match(TokenType.VOID):
            return ast.VOID_TYPE
        elif self.match(TokenType.STRUCT):
            name_tok = self.expect(TokenType.IDENT, "Expected struct name")
            return ast.StructType(name_tok.value)
        else:
            raise self.error(f"Expected type, got {tok.type.name}")

    def parse_type(self) -> ast.Type:
        """Parse a type with pointer modifiers."""
        base = self.parse_base_type()

        # Parse pointer modifiers
        while self.match(TokenType.STAR):
            base = ast.PointerType(base)

        return base

    # ========================================================================
    # Declarations
    # ========================================================================

    def parse_program(self) -> ast.Program:
        """Parse the entire program."""
        program = ast.Program()

        while not self.check(TokenType.EOF):
            try:
                decl = self.parse_top_level_decl()
                if isinstance(decl, ast.StructDef):
                    program.structs.append(decl)
                elif isinstance(decl, ast.FuncDef):
                    program.functions.append(decl)
                elif isinstance(decl, ast.VarDecl):
                    program.globals.append(decl)
                elif isinstance(decl, ast.ExternDecl):
                    program.externs.append(decl)
            except ParseError as e:
                self.errors.append(e)
                self.synchronize()

        return program

    def parse_top_level_decl(self):
        """Parse a top-level declaration (struct, function, global var, or extern)."""
        tok = self.current()

        # Extern declaration
        if self.check(TokenType.EXTERN):
            return self.parse_extern_decl()

        # Struct definition
        if self.check(TokenType.STRUCT) and self.peek(1).type == TokenType.IDENT:
            if self.peek(2).type == TokenType.LBRACE:
                return self.parse_struct_def()

        # Function or global variable
        type_ = self.parse_type()
        name_tok = self.expect(TokenType.IDENT, "Expected identifier")
        name = name_tok.value

        # Function
        if self.check(TokenType.LPAREN):
            return self.parse_function_def(type_, name, tok.line, tok.column)

        # Global variable
        return self.parse_global_var(type_, name, tok.line, tok.column)

    def parse_extern_decl(self) -> ast.ExternDecl:
        """Parse extern function declaration.

        Syntax:
            extern "dll.dll" return_type name(params);
            extern return_type name(params);  // defaults to kernel32.dll
        """
        tok = self.expect(TokenType.EXTERN)

        # Optional DLL name
        dll = "kernel32.dll"
        if self.check(TokenType.STRING_LIT):
            dll_tok = self.advance()
            dll = dll_tok.value

        # Return type
        return_type = self.parse_type()

        # Function name
        name_tok = self.expect(TokenType.IDENT, "Expected function name")
        name = name_tok.value

        # Parameter list
        self.expect(TokenType.LPAREN)
        params = []
        if not self.check(TokenType.RPAREN):
            params = self.parse_param_list()
        self.expect(TokenType.RPAREN)

        self.expect(TokenType.SEMICOLON)

        return ast.ExternDecl(name, dll, return_type, params, tok.line, tok.column)

    def parse_struct_def(self) -> ast.StructDef:
        """Parse struct definition."""
        tok = self.expect(TokenType.STRUCT)
        name_tok = self.expect(TokenType.IDENT)
        self.expect(TokenType.LBRACE)

        fields = []
        while not self.check(TokenType.RBRACE, TokenType.EOF):
            field = self.parse_struct_field()
            fields.append(field)

        self.expect(TokenType.RBRACE)
        self.expect(TokenType.SEMICOLON)

        return ast.StructDef(name_tok.value, fields, tok.line, tok.column)

    def parse_struct_field(self) -> ast.StructField:
        """Parse a struct field."""
        tok = self.current()
        type_ = self.parse_type()
        name_tok = self.expect(TokenType.IDENT)

        array_size = None
        if self.match(TokenType.LBRACKET):
            size_tok = self.expect(TokenType.INT_LIT, "Expected array size")
            array_size = size_tok.value
            self.expect(TokenType.RBRACKET)

        self.expect(TokenType.SEMICOLON)

        return ast.StructField(name_tok.value, type_, array_size, tok.line, tok.column)

    def parse_function_def(self, return_type: ast.Type, name: str,
                            line: int, column: int) -> ast.FuncDef:
        """Parse function definition."""
        self.expect(TokenType.LPAREN)

        params = []
        if not self.check(TokenType.RPAREN):
            params = self.parse_param_list()

        self.expect(TokenType.RPAREN)

        body = self.parse_block()

        return ast.FuncDef(name, return_type, params, body, line, column)

    def parse_param_list(self) -> List[ast.ParamDecl]:
        """Parse function parameter list."""
        params = []

        while True:
            tok = self.current()
            type_ = self.parse_type()
            name_tok = self.expect(TokenType.IDENT)
            params.append(ast.ParamDecl(name_tok.value, type_, tok.line, tok.column))

            if not self.match(TokenType.COMMA):
                break

        return params

    def parse_global_var(self, type_: ast.Type, name: str,
                         line: int, column: int) -> ast.VarDecl:
        """Parse global variable declaration."""
        init = None

        # Check for array
        array_size = None
        if self.match(TokenType.LBRACKET):
            size_tok = self.expect(TokenType.INT_LIT, "Expected array size")
            array_size = size_tok.value
            self.expect(TokenType.RBRACKET)
            type_ = ast.ArrayType(type_, array_size)

        if self.match(TokenType.EQ):
            init = self.parse_expr()

        self.expect(TokenType.SEMICOLON)

        return ast.VarDecl(name, type_, init, array_size, line, column)

    # ========================================================================
    # Statements
    # ========================================================================

    def parse_block(self) -> ast.Block:
        """Parse a block of statements."""
        tok = self.expect(TokenType.LBRACE)
        stmts = []

        while not self.check(TokenType.RBRACE, TokenType.EOF):
            stmt = self.parse_stmt()
            stmts.append(stmt)

        self.expect(TokenType.RBRACE)

        return ast.Block(stmts, tok.line, tok.column)

    def parse_stmt(self) -> ast.Stmt:
        """Parse a statement."""
        tok = self.current()

        # Block
        if self.check(TokenType.LBRACE):
            return self.parse_block()

        # If statement
        if self.match(TokenType.IF):
            return self.parse_if_stmt(tok.line, tok.column)

        # While statement
        if self.match(TokenType.WHILE):
            return self.parse_while_stmt(tok.line, tok.column)

        # For statement
        if self.match(TokenType.FOR):
            return self.parse_for_stmt(tok.line, tok.column)

        # Return statement
        if self.match(TokenType.RETURN):
            return self.parse_return_stmt(tok.line, tok.column)

        # Emit statement
        if self.match(TokenType.EMIT):
            return self.parse_emit_stmt(tok.line, tok.column)

        # Break statement
        if self.match(TokenType.BREAK):
            self.expect(TokenType.SEMICOLON)
            return ast.BreakStmt(tok.line, tok.column)

        # Continue statement
        if self.match(TokenType.CONTINUE):
            self.expect(TokenType.SEMICOLON)
            return ast.ContinueStmt(tok.line, tok.column)

        # Local variable declaration
        if self.check(TokenType.INT, TokenType.CHAR, TokenType.VOID, TokenType.STRUCT):
            return self.parse_local_decl()

        # Expression statement
        expr = self.parse_expr()
        self.expect(TokenType.SEMICOLON)
        return ast.ExprStmt(expr, tok.line, tok.column)

    def parse_if_stmt(self, line: int, column: int) -> ast.IfStmt:
        """Parse if statement."""
        self.expect(TokenType.LPAREN)
        cond = self.parse_expr()
        self.expect(TokenType.RPAREN)

        then_branch = self.parse_stmt()

        else_branch = None
        if self.match(TokenType.ELSE):
            else_branch = self.parse_stmt()

        return ast.IfStmt(cond, then_branch, else_branch, line, column)

    def parse_while_stmt(self, line: int, column: int) -> ast.WhileStmt:
        """Parse while statement."""
        self.expect(TokenType.LPAREN)
        cond = self.parse_expr()
        self.expect(TokenType.RPAREN)

        body = self.parse_stmt()

        return ast.WhileStmt(cond, body, line, column)

    def parse_for_stmt(self, line: int, column: int) -> ast.ForStmt:
        """Parse for statement."""
        self.expect(TokenType.LPAREN)

        # Init
        init = None
        if not self.check(TokenType.SEMICOLON):
            init = self.parse_expr()
        self.expect(TokenType.SEMICOLON)

        # Condition
        cond = None
        if not self.check(TokenType.SEMICOLON):
            cond = self.parse_expr()
        self.expect(TokenType.SEMICOLON)

        # Step
        step = None
        if not self.check(TokenType.RPAREN):
            step = self.parse_expr()
        self.expect(TokenType.RPAREN)

        body = self.parse_stmt()

        return ast.ForStmt(init, cond, step, body, line, column)

    def parse_return_stmt(self, line: int, column: int) -> ast.ReturnStmt:
        """Parse return statement."""
        value = None
        if not self.check(TokenType.SEMICOLON):
            value = self.parse_expr()
        self.expect(TokenType.SEMICOLON)
        return ast.ReturnStmt(value, line, column)

    def parse_emit_stmt(self, line: int, column: int) -> ast.EmitStmt:
        """Parse emit statement: emit <byte>, ... ;"""
        bytes_list = []
        b = self.expect(TokenType.INT_LIT, "expected byte value after 'emit'")
        bytes_list.append(b.value & 0xFF)
        while self.match(TokenType.COMMA):
            b = self.expect(TokenType.INT_LIT, "expected byte value after ','")
            bytes_list.append(b.value & 0xFF)
        self.expect(TokenType.SEMICOLON, "expected ';' after emit bytes")
        return ast.EmitStmt(bytes_list, line, column)

    def parse_local_decl(self) -> ast.DeclStmt:
        """Parse local variable declaration."""
        tok = self.current()
        type_ = self.parse_type()
        name_tok = self.expect(TokenType.IDENT)

        array_size = None
        if self.match(TokenType.LBRACKET):
            size_tok = self.expect(TokenType.INT_LIT, "Expected array size")
            array_size = size_tok.value
            self.expect(TokenType.RBRACKET)
            type_ = ast.ArrayType(type_, array_size)

        init = None
        if self.match(TokenType.EQ):
            init = self.parse_expr()

        self.expect(TokenType.SEMICOLON)

        decl = ast.VarDecl(name_tok.value, type_, init, array_size, tok.line, tok.column)
        return ast.DeclStmt(decl, tok.line, tok.column)

    # ========================================================================
    # Expressions (precedence climbing)
    # ========================================================================

    def parse_expr(self) -> ast.Expr:
        """Parse an expression."""
        return self.parse_assignment()

    def parse_assignment(self) -> ast.Expr:
        """Parse assignment expression."""
        left = self.parse_logical_or()

        if self.match(TokenType.EQ):
            right = self.parse_assignment()
            return ast.BinaryExpr(ast.BinOp.ASSIGN, left, right, left.line, left.column)
        elif self.match(TokenType.PLUS_EQ):
            right = self.parse_assignment()
            return ast.BinaryExpr(ast.BinOp.ADD_ASSIGN, left, right, left.line, left.column)
        elif self.match(TokenType.MINUS_EQ):
            right = self.parse_assignment()
            return ast.BinaryExpr(ast.BinOp.SUB_ASSIGN, left, right, left.line, left.column)

        return left

    def parse_logical_or(self) -> ast.Expr:
        """Parse logical OR expression."""
        left = self.parse_logical_and()

        while self.match(TokenType.PIPE_PIPE):
            right = self.parse_logical_and()
            left = ast.BinaryExpr(ast.BinOp.LOR, left, right, left.line, left.column)

        return left

    def parse_logical_and(self) -> ast.Expr:
        """Parse logical AND expression."""
        left = self.parse_bitwise_or()

        while self.match(TokenType.AMP_AMP):
            right = self.parse_bitwise_or()
            left = ast.BinaryExpr(ast.BinOp.LAND, left, right, left.line, left.column)

        return left

    def parse_bitwise_or(self) -> ast.Expr:
        """Parse bitwise OR expression."""
        left = self.parse_bitwise_xor()

        while self.match(TokenType.PIPE):
            right = self.parse_bitwise_xor()
            left = ast.BinaryExpr(ast.BinOp.OR, left, right, left.line, left.column)

        return left

    def parse_bitwise_xor(self) -> ast.Expr:
        """Parse bitwise XOR expression."""
        left = self.parse_bitwise_and()

        while self.match(TokenType.CARET):
            right = self.parse_bitwise_and()
            left = ast.BinaryExpr(ast.BinOp.XOR, left, right, left.line, left.column)

        return left

    def parse_bitwise_and(self) -> ast.Expr:
        """Parse bitwise AND expression."""
        left = self.parse_equality()

        while self.match(TokenType.AMP):
            right = self.parse_equality()
            left = ast.BinaryExpr(ast.BinOp.AND, left, right, left.line, left.column)

        return left

    def parse_equality(self) -> ast.Expr:
        """Parse equality expression."""
        left = self.parse_relational()

        while True:
            if self.match(TokenType.EQ_EQ):
                right = self.parse_relational()
                left = ast.BinaryExpr(ast.BinOp.EQ, left, right, left.line, left.column)
            elif self.match(TokenType.BANG_EQ):
                right = self.parse_relational()
                left = ast.BinaryExpr(ast.BinOp.NE, left, right, left.line, left.column)
            else:
                break

        return left

    def parse_relational(self) -> ast.Expr:
        """Parse relational expression."""
        left = self.parse_shift()

        while True:
            if self.match(TokenType.LT):
                right = self.parse_shift()
                left = ast.BinaryExpr(ast.BinOp.LT, left, right, left.line, left.column)
            elif self.match(TokenType.GT):
                right = self.parse_shift()
                left = ast.BinaryExpr(ast.BinOp.GT, left, right, left.line, left.column)
            elif self.match(TokenType.LT_EQ):
                right = self.parse_shift()
                left = ast.BinaryExpr(ast.BinOp.LE, left, right, left.line, left.column)
            elif self.match(TokenType.GT_EQ):
                right = self.parse_shift()
                left = ast.BinaryExpr(ast.BinOp.GE, left, right, left.line, left.column)
            else:
                break

        return left

    def parse_shift(self) -> ast.Expr:
        """Parse shift expression."""
        left = self.parse_additive()

        while True:
            if self.match(TokenType.LT_LT):
                right = self.parse_additive()
                left = ast.BinaryExpr(ast.BinOp.SHL, left, right, left.line, left.column)
            elif self.match(TokenType.GT_GT):
                right = self.parse_additive()
                left = ast.BinaryExpr(ast.BinOp.SHR, left, right, left.line, left.column)
            else:
                break

        return left

    def parse_additive(self) -> ast.Expr:
        """Parse additive expression."""
        left = self.parse_multiplicative()

        while True:
            if self.match(TokenType.PLUS):
                right = self.parse_multiplicative()
                left = ast.BinaryExpr(ast.BinOp.ADD, left, right, left.line, left.column)
            elif self.match(TokenType.MINUS):
                right = self.parse_multiplicative()
                left = ast.BinaryExpr(ast.BinOp.SUB, left, right, left.line, left.column)
            else:
                break

        return left

    def parse_multiplicative(self) -> ast.Expr:
        """Parse multiplicative expression."""
        left = self.parse_unary()

        while True:
            if self.match(TokenType.STAR):
                right = self.parse_unary()
                left = ast.BinaryExpr(ast.BinOp.MUL, left, right, left.line, left.column)
            elif self.match(TokenType.SLASH):
                right = self.parse_unary()
                left = ast.BinaryExpr(ast.BinOp.DIV, left, right, left.line, left.column)
            elif self.match(TokenType.PERCENT):
                right = self.parse_unary()
                left = ast.BinaryExpr(ast.BinOp.MOD, left, right, left.line, left.column)
            else:
                break

        return left

    def parse_unary(self) -> ast.Expr:
        """Parse unary expression."""
        tok = self.current()

        if self.match(TokenType.MINUS):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.NEG, operand, tok.line, tok.column)
        elif self.match(TokenType.BANG):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.NOT, operand, tok.line, tok.column)
        elif self.match(TokenType.TILDE):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.BNOT, operand, tok.line, tok.column)
        elif self.match(TokenType.AMP):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.ADDR, operand, tok.line, tok.column)
        elif self.match(TokenType.STAR):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.DEREF, operand, tok.line, tok.column)
        elif self.match(TokenType.PLUS_PLUS):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.PRE_INC, operand, tok.line, tok.column)
        elif self.match(TokenType.MINUS_MINUS):
            operand = self.parse_unary()
            return ast.UnaryExpr(ast.UnaryOp.PRE_DEC, operand, tok.line, tok.column)

        return self.parse_postfix()

    def parse_postfix(self) -> ast.Expr:
        """Parse postfix expression."""
        left = self.parse_primary()

        while True:
            if self.match(TokenType.LBRACKET):
                # Array indexing
                index = self.parse_expr()
                self.expect(TokenType.RBRACKET)
                left = ast.IndexExpr(left, index, left.line, left.column)
            elif self.match(TokenType.LPAREN):
                # Function call
                if not isinstance(left, ast.Identifier):
                    raise self.error("Expected function name")
                args = []
                if not self.check(TokenType.RPAREN):
                    args = self.parse_arg_list()
                self.expect(TokenType.RPAREN)
                left = ast.CallExpr(left.name, args, left.line, left.column)
            elif self.match(TokenType.DOT):
                # Member access
                member = self.expect(TokenType.IDENT)
                left = ast.MemberExpr(left, member.value, False, left.line, left.column)
            elif self.match(TokenType.ARROW):
                # Pointer member access
                member = self.expect(TokenType.IDENT)
                left = ast.MemberExpr(left, member.value, True, left.line, left.column)
            elif self.match(TokenType.PLUS_PLUS):
                left = ast.UnaryExpr(ast.UnaryOp.POST_INC, left, left.line, left.column)
            elif self.match(TokenType.MINUS_MINUS):
                left = ast.UnaryExpr(ast.UnaryOp.POST_DEC, left, left.line, left.column)
            else:
                break

        return left

    def parse_primary(self) -> ast.Expr:
        """Parse primary expression."""
        tok = self.current()

        if self.match(TokenType.INT_LIT):
            return ast.IntLiteral(tok.value, tok.line, tok.column)

        if self.match(TokenType.CHAR_LIT):
            return ast.CharLiteral(tok.value, tok.line, tok.column)

        if self.match(TokenType.STRING_LIT):
            return ast.StringLiteral(tok.value, tok.line, tok.column)

        if self.match(TokenType.IDENT):
            return ast.Identifier(tok.value, tok.line, tok.column)

        if self.match(TokenType.SIZEOF):
            self.expect(TokenType.LPAREN)
            type_ = self.parse_type()
            self.expect(TokenType.RPAREN)
            return ast.SizeofExpr(type_, tok.line, tok.column)

        if self.match(TokenType.LPAREN):
            expr = self.parse_expr()
            self.expect(TokenType.RPAREN)
            return expr

        raise self.error(f"Unexpected token: {tok.type.name}")

    def parse_arg_list(self) -> List[ast.Expr]:
        """Parse function argument list."""
        args = []

        while True:
            args.append(self.parse_expr())
            if not self.match(TokenType.COMMA):
                break

        return args


def parse(source: str, filename: str = "<stdin>") -> ast.Program:
    """Convenience function to parse source code."""
    lexer = Lexer(source, filename)
    tokens = lexer.tokenize()
    parser = Parser(tokens, filename)
    program = parser.parse_program()

    if parser.errors:
        for err in parser.errors:
            print(f"Error: {err}")

    return program
