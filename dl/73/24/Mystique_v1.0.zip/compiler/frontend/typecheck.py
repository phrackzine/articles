"""
Type checker for MystC.
"""

from typing import List, Optional
from . import mystc_ast as ast
from .symbols import (
    SymbolTable, StructInfo, FuncInfo, VarInfo,
    compute_struct_layout, get_type_size_align,
    types_equal, is_pointer_type, is_integer_type,
    is_arithmetic_type, is_scalar_type, get_pointer_base, can_convert
)


class TypeError(Exception):
    def __init__(self, message: str, line: int, column: int):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"{line}:{column}: {message}")


class TypeChecker:
    def __init__(self):
        self.symbols = SymbolTable()
        self.errors: List[TypeError] = []
        self.current_function: Optional[FuncInfo] = None
        self.in_loop = False

    def error(self, msg: str, node: ast.Node):
        """Record a type error."""
        err = TypeError(msg, node.line, node.column)
        self.errors.append(err)

    def check(self, program: ast.Program) -> bool:
        """Type check a program. Returns True if no errors."""
        # First pass: register struct names (for forward references)
        for struct in program.structs:
            # Pre-register with dummy info
            dummy_info = StructInfo(struct.name, {}, {}, 0, 1)
            self.symbols.define_struct(dummy_info)

        # Second pass: fully process struct definitions
        for struct in program.structs:
            self.check_struct_def(struct)

        # Register extern functions
        for extern in program.externs:
            self.collect_extern_signature(extern)

        # Third pass: collect function signatures
        for func in program.functions:
            self.collect_function_signature(func)

        # Third pass: collect global variables
        for var in program.globals:
            self.check_global_var(var)

        # Fourth pass: check function bodies
        for func in program.functions:
            self.check_function_body(func)

        return len(self.errors) == 0

    def collect_extern_signature(self, extern: ast.ExternDecl):
        """Collect extern function signature."""
        param_types = [p.type for p in extern.params]
        param_names = [p.name for p in extern.params]

        # Check return type
        self.check_type_exists(extern.return_type, extern)

        # Check parameter types
        for param in extern.params:
            self.check_type_exists(param.type, param)

        info = FuncInfo(extern.name, extern.return_type, param_types, param_names, is_extern=True, dll=extern.dll)
        if not self.symbols.define_function(info):
            self.error(f"Function '{extern.name}' already defined", extern)

    def check_struct_def(self, struct: ast.StructDef):
        """Check and register a struct definition."""
        # Check for duplicate field names
        seen_fields = set()
        for field in struct.fields:
            if field.name in seen_fields:
                self.error(f"Duplicate field '{field.name}' in struct '{struct.name}'", field)
            seen_fields.add(field.name)

            # Check field type
            self.check_type_exists(field.type, field)

        # Compute layout and update the existing entry
        info = compute_struct_layout(struct, self.symbols)
        # Update the pre-registered struct with actual info
        self.symbols.structs[struct.name] = info

    def collect_function_signature(self, func: ast.FuncDef):
        """Collect function signature (first pass)."""
        param_types = [p.type for p in func.params]
        param_names = [p.name for p in func.params]

        # Check return type
        self.check_type_exists(func.return_type, func)

        # Check parameter types
        for param in func.params:
            self.check_type_exists(param.type, param)

        info = FuncInfo(func.name, func.return_type, param_types, param_names)
        if not self.symbols.define_function(info):
            self.error(f"Function '{func.name}' already defined", func)

    def check_global_var(self, var: ast.VarDecl):
        """Check a global variable declaration."""
        self.check_type_exists(var.type, var)

        if var.init:
            init_type = self.check_expr(var.init)
            if init_type and not can_convert(init_type, var.type):
                self.error(f"Cannot initialize '{var.name}' of type {var.type} with {init_type}", var)

        if not self.symbols.define_var(var.name, var.type, is_global=True):
            self.error(f"Global variable '{var.name}' already defined", var)

    def check_function_body(self, func: ast.FuncDef):
        """Check a function body (second pass)."""
        self.current_function = self.symbols.lookup_function(func.name)
        self.symbols.reset_locals()
        self.symbols.enter_scope()

        # Add parameters to scope
        for i, param in enumerate(func.params):
            self.symbols.define_var(param.name, param.type, is_param=True, param_index=i)

        # Check body
        if func.body:
            self.check_block(func.body)

        self.symbols.exit_scope()
        self.current_function = None

    def check_type_exists(self, type_: ast.Type, node: ast.Node):
        """Check that a type is valid."""
        if isinstance(type_, ast.StructType):
            if not self.symbols.lookup_struct(type_.name):
                self.error(f"Unknown struct '{type_.name}'", node)
        elif isinstance(type_, ast.PointerType):
            self.check_type_exists(type_.pointee, node)
        elif isinstance(type_, ast.ArrayType):
            self.check_type_exists(type_.element, node)
            if type_.size <= 0:
                self.error("Array size must be positive", node)

    # ========================================================================
    # Statements
    # ========================================================================

    def check_stmt(self, stmt: ast.Stmt):
        """Check a statement."""
        if isinstance(stmt, ast.Block):
            self.check_block(stmt)
        elif isinstance(stmt, ast.ExprStmt):
            self.check_expr(stmt.expr)
        elif isinstance(stmt, ast.IfStmt):
            self.check_if_stmt(stmt)
        elif isinstance(stmt, ast.WhileStmt):
            self.check_while_stmt(stmt)
        elif isinstance(stmt, ast.ForStmt):
            self.check_for_stmt(stmt)
        elif isinstance(stmt, ast.ReturnStmt):
            self.check_return_stmt(stmt)
        elif isinstance(stmt, ast.BreakStmt):
            if not self.in_loop:
                self.error("'break' outside of loop", stmt)
        elif isinstance(stmt, ast.ContinueStmt):
            if not self.in_loop:
                self.error("'continue' outside of loop", stmt)
        elif isinstance(stmt, ast.DeclStmt):
            self.check_local_decl(stmt.decl)

    def check_block(self, block: ast.Block):
        """Check a block of statements."""
        self.symbols.enter_scope()
        for stmt in block.stmts:
            self.check_stmt(stmt)
        self.symbols.exit_scope()

    def check_if_stmt(self, stmt: ast.IfStmt):
        """Check an if statement."""
        cond_type = self.check_expr(stmt.cond)
        if cond_type and not is_scalar_type(cond_type):
            self.error("Condition must be scalar type", stmt.cond)

        self.check_stmt(stmt.then_branch)
        if stmt.else_branch:
            self.check_stmt(stmt.else_branch)

    def check_while_stmt(self, stmt: ast.WhileStmt):
        """Check a while statement."""
        cond_type = self.check_expr(stmt.cond)
        if cond_type and not is_scalar_type(cond_type):
            self.error("Condition must be scalar type", stmt.cond)

        old_in_loop = self.in_loop
        self.in_loop = True
        self.check_stmt(stmt.body)
        self.in_loop = old_in_loop

    def check_for_stmt(self, stmt: ast.ForStmt):
        """Check a for statement."""
        if stmt.init:
            self.check_expr(stmt.init)
        if stmt.cond:
            cond_type = self.check_expr(stmt.cond)
            if cond_type and not is_scalar_type(cond_type):
                self.error("Condition must be scalar type", stmt.cond)
        if stmt.step:
            self.check_expr(stmt.step)

        old_in_loop = self.in_loop
        self.in_loop = True
        self.check_stmt(stmt.body)
        self.in_loop = old_in_loop

    def check_return_stmt(self, stmt: ast.ReturnStmt):
        """Check a return statement."""
        if not self.current_function:
            self.error("'return' outside of function", stmt)
            return

        ret_type = self.current_function.return_type
        is_void = isinstance(ret_type, ast.PrimitiveType) and ret_type.base == ast.BaseType.VOID

        if stmt.value:
            if is_void:
                self.error("Cannot return value from void function", stmt)
            else:
                value_type = self.check_expr(stmt.value)
                if value_type and not can_convert(value_type, ret_type):
                    self.error(f"Cannot return {value_type}, expected {ret_type}", stmt)
        else:
            if not is_void:
                self.error("Must return a value from non-void function", stmt)

    def check_local_decl(self, var: ast.VarDecl):
        """Check a local variable declaration."""
        self.check_type_exists(var.type, var)

        if var.init:
            init_type = self.check_expr(var.init)
            if init_type and not can_convert(init_type, var.type):
                self.error(f"Cannot initialize '{var.name}' of type {var.type} with {init_type}", var)

        if not self.symbols.define_var(var.name, var.type):
            self.error(f"Variable '{var.name}' already defined in this scope", var)

    # ========================================================================
    # Expressions
    # ========================================================================

    def check_expr(self, expr: ast.Expr) -> Optional[ast.Type]:
        """Check an expression and return its type."""
        result = None

        if isinstance(expr, ast.IntLiteral):
            result = ast.INT_TYPE
        elif isinstance(expr, ast.CharLiteral):
            result = ast.CHAR_TYPE
        elif isinstance(expr, ast.StringLiteral):
            result = ast.PointerType(ast.CHAR_TYPE)
        elif isinstance(expr, ast.Identifier):
            result = self.check_identifier(expr)
        elif isinstance(expr, ast.BinaryExpr):
            result = self.check_binary_expr(expr)
        elif isinstance(expr, ast.UnaryExpr):
            result = self.check_unary_expr(expr)
        elif isinstance(expr, ast.CallExpr):
            result = self.check_call_expr(expr)
        elif isinstance(expr, ast.IndexExpr):
            result = self.check_index_expr(expr)
        elif isinstance(expr, ast.MemberExpr):
            result = self.check_member_expr(expr)
        elif isinstance(expr, ast.SizeofExpr):
            self.check_type_exists(expr.target_type, expr)
            result = ast.INT_TYPE

        expr.resolved_type = result
        return result

    def check_identifier(self, expr: ast.Identifier) -> Optional[ast.Type]:
        """Check an identifier expression."""
        var = self.symbols.lookup_var(expr.name)
        if not var:
            self.error(f"Undefined variable '{expr.name}'", expr)
            return None
        return var.type

    def check_binary_expr(self, expr: ast.BinaryExpr) -> Optional[ast.Type]:
        """Check a binary expression."""
        left_type = self.check_expr(expr.left)
        right_type = self.check_expr(expr.right)

        if not left_type or not right_type:
            return None

        op = expr.op

        # Assignment operators
        if op in (ast.BinOp.ASSIGN, ast.BinOp.ADD_ASSIGN, ast.BinOp.SUB_ASSIGN):
            if not self.is_lvalue(expr.left):
                self.error("Left side of assignment must be an lvalue", expr.left)
            if not can_convert(right_type, left_type):
                self.error(f"Cannot assign {right_type} to {left_type}", expr)
            return left_type

        # Comparison operators
        if op in (ast.BinOp.EQ, ast.BinOp.NE, ast.BinOp.LT, ast.BinOp.LE, ast.BinOp.GT, ast.BinOp.GE):
            if is_arithmetic_type(left_type) and is_arithmetic_type(right_type):
                return ast.INT_TYPE
            if is_pointer_type(left_type) and is_pointer_type(right_type):
                return ast.INT_TYPE
            # Pointer compared with integer (null check)
            if is_pointer_type(left_type) and is_integer_type(right_type):
                return ast.INT_TYPE
            if is_integer_type(left_type) and is_pointer_type(right_type):
                return ast.INT_TYPE
            self.error(f"Invalid operands to comparison: {left_type} and {right_type}", expr)
            return ast.INT_TYPE

        # Logical operators
        if op in (ast.BinOp.LAND, ast.BinOp.LOR):
            if not is_scalar_type(left_type) or not is_scalar_type(right_type):
                self.error("Logical operators require scalar operands", expr)
            return ast.INT_TYPE

        # Arithmetic operators
        if op in (ast.BinOp.ADD, ast.BinOp.SUB):
            # Pointer arithmetic
            if is_pointer_type(left_type) and is_integer_type(right_type):
                return left_type
            if op == ast.BinOp.ADD and is_integer_type(left_type) and is_pointer_type(right_type):
                return right_type
            if op == ast.BinOp.SUB and is_pointer_type(left_type) and is_pointer_type(right_type):
                return ast.INT_TYPE  # Pointer difference

            if is_arithmetic_type(left_type) and is_arithmetic_type(right_type):
                return ast.INT_TYPE

            self.error(f"Invalid operands to {op.value}: {left_type} and {right_type}", expr)
            return ast.INT_TYPE

        if op in (ast.BinOp.MUL, ast.BinOp.DIV, ast.BinOp.MOD):
            if not is_arithmetic_type(left_type) or not is_arithmetic_type(right_type):
                self.error(f"Arithmetic operators require integer operands", expr)
            return ast.INT_TYPE

        # Bitwise operators
        if op in (ast.BinOp.AND, ast.BinOp.OR, ast.BinOp.XOR, ast.BinOp.SHL, ast.BinOp.SHR):
            if not is_integer_type(left_type) or not is_integer_type(right_type):
                self.error(f"Bitwise operators require integer operands", expr)
            return ast.INT_TYPE

        return ast.INT_TYPE

    def check_unary_expr(self, expr: ast.UnaryExpr) -> Optional[ast.Type]:
        """Check a unary expression."""
        # Special case: &function_name to get a function's code address
        if expr.op == ast.UnaryOp.ADDR and isinstance(expr.operand, ast.Identifier):
            func = self.symbols.lookup_function(expr.operand.name)
            if func and not self.symbols.lookup_var(expr.operand.name):
                expr.operand.resolved_type = ast.INT_TYPE
                return ast.INT_TYPE

        operand_type = self.check_expr(expr.operand)
        if not operand_type:
            return None

        op = expr.op

        if op == ast.UnaryOp.NEG:
            if not is_arithmetic_type(operand_type):
                self.error("Unary minus requires arithmetic operand", expr)
            return ast.INT_TYPE

        if op == ast.UnaryOp.NOT:
            if not is_scalar_type(operand_type):
                self.error("Logical not requires scalar operand", expr)
            return ast.INT_TYPE

        if op == ast.UnaryOp.BNOT:
            if not is_integer_type(operand_type):
                self.error("Bitwise not requires integer operand", expr)
            return ast.INT_TYPE

        if op == ast.UnaryOp.ADDR:
            # Allow &function_name to get a function's code address
            if isinstance(expr.operand, ast.Identifier) and operand_type is None:
                func = self.symbols.lookup_function(expr.operand.name)
                if func:
                    return ast.INT_TYPE
            if not self.is_lvalue(expr.operand):
                self.error("Cannot take address of non-lvalue", expr)
            return ast.PointerType(operand_type) if operand_type else ast.INT_TYPE

        if op == ast.UnaryOp.DEREF:
            if not is_pointer_type(operand_type):
                self.error("Cannot dereference non-pointer", expr)
                return None
            return get_pointer_base(operand_type)

        if op in (ast.UnaryOp.PRE_INC, ast.UnaryOp.PRE_DEC,
                  ast.UnaryOp.POST_INC, ast.UnaryOp.POST_DEC):
            if not self.is_lvalue(expr.operand):
                self.error("Increment/decrement requires lvalue", expr)
            if not is_scalar_type(operand_type):
                self.error("Increment/decrement requires scalar operand", expr)
            return operand_type

        return operand_type

    def check_call_expr(self, expr: ast.CallExpr) -> Optional[ast.Type]:
        """Check a function call expression."""
        # __syscall is a Linux INT 0x80 primitive: __syscall(num, a1, a2, a3, a4, a5)
        # Handled directly by the backend; no symbol-table entry.
        if expr.func == "__syscall":
            if len(expr.args) != 6:
                self.error(f"__syscall expects 6 arguments (num, a1..a5), got {len(expr.args)}", expr)
            for arg in expr.args:
                self.check_expr(arg)
            return ast.PrimitiveType(ast.BaseType.INT)

        func = self.symbols.lookup_function(expr.func)
        if not func:
            # Check if it's a variable (indirect call through function pointer)
            var = self.symbols.lookup_var(expr.func)
            if var and isinstance(var.type, ast.PrimitiveType) and \
               var.type.base == ast.BaseType.INT:
                expr.is_indirect = True
                # Type-check arguments (no signature to check against)
                for arg in expr.args:
                    self.check_expr(arg)
                return ast.PrimitiveType(ast.BaseType.INT)
            self.error(f"Undefined function '{expr.func}'", expr)
            return None

        if len(expr.args) != len(func.param_types):
            self.error(f"Function '{expr.func}' expects {len(func.param_types)} arguments, got {len(expr.args)}", expr)

        for i, (arg, expected_type) in enumerate(zip(expr.args, func.param_types)):
            arg_type = self.check_expr(arg)
            if arg_type and not can_convert(arg_type, expected_type):
                self.error(f"Argument {i+1} to '{expr.func}': cannot convert {arg_type} to {expected_type}", arg)

        return func.return_type

    def check_index_expr(self, expr: ast.IndexExpr) -> Optional[ast.Type]:
        """Check an array index expression."""
        base_type = self.check_expr(expr.base)
        index_type = self.check_expr(expr.index)

        if not base_type:
            return None

        if not is_integer_type(index_type):
            self.error("Array index must be integer", expr.index)

        elem_type = get_pointer_base(base_type)
        if not elem_type:
            self.error("Cannot index non-pointer/array type", expr)
            return None

        return elem_type

    def check_member_expr(self, expr: ast.MemberExpr) -> Optional[ast.Type]:
        """Check a member access expression."""
        base_type = self.check_expr(expr.base)
        if not base_type:
            return None

        # For arrow (->), base must be pointer to struct
        if expr.is_arrow:
            if not isinstance(base_type, ast.PointerType):
                self.error("Arrow operator requires pointer", expr)
                return None
            base_type = base_type.pointee

        # Base must be struct
        if not isinstance(base_type, ast.StructType):
            self.error("Member access requires struct type", expr)
            return None

        struct_info = self.symbols.lookup_struct(base_type.name)
        if not struct_info:
            self.error(f"Unknown struct '{base_type.name}'", expr)
            return None

        if expr.member not in struct_info.fields:
            self.error(f"Struct '{base_type.name}' has no member '{expr.member}'", expr)
            return None

        return struct_info.fields[expr.member]

    def is_lvalue(self, expr: ast.Expr) -> bool:
        """Check if an expression is an lvalue."""
        if isinstance(expr, ast.Identifier):
            return True
        if isinstance(expr, ast.IndexExpr):
            return True
        if isinstance(expr, ast.MemberExpr):
            return True
        if isinstance(expr, ast.UnaryExpr) and expr.op == ast.UnaryOp.DEREF:
            return True
        return False


def typecheck(program: ast.Program) -> tuple:
    """Type check a program. Returns (success, symbol_table, errors)."""
    checker = TypeChecker()
    success = checker.check(program)
    return success, checker.symbols, checker.errors
