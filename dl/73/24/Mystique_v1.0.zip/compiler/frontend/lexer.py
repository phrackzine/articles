"""
Lexer (tokenizer) for MystC.
"""

from typing import List, Optional
from .tokens import Token, TokenType, KEYWORDS


class Lexer:
    def __init__(self, source: str, filename: str = "<stdin>"):
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []

    def error(self, msg: str) -> Token:
        return Token(TokenType.ERROR, f"{self.filename}:{self.line}:{self.column}: {msg}", self.line, self.column)

    def peek(self, offset: int = 0) -> str:
        pos = self.pos + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]

    def advance(self) -> str:
        ch = self.peek()
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def skip_whitespace(self):
        while self.peek() in ' \t\n\r':
            self.advance()

    def skip_line_comment(self):
        while self.peek() != '\n' and self.peek() != '\0':
            self.advance()

    def skip_block_comment(self):
        self.advance()  # skip *
        while True:
            if self.peek() == '\0':
                return  # unterminated comment
            if self.peek() == '*' and self.peek(1) == '/':
                self.advance()
                self.advance()
                return
            self.advance()

    def read_ident(self) -> Token:
        start_line, start_col = self.line, self.column
        result = []
        while self.peek().isalnum() or self.peek() == '_':
            result.append(self.advance())
        name = ''.join(result)

        # Check if keyword
        if name in KEYWORDS:
            return Token(KEYWORDS[name], name, start_line, start_col)
        return Token(TokenType.IDENT, name, start_line, start_col)

    def read_number(self) -> Token:
        start_line, start_col = self.line, self.column
        result = []

        # Check for hex
        if self.peek() == '0' and self.peek(1) in 'xX':
            result.append(self.advance())  # 0
            result.append(self.advance())  # x
            while self.peek() in '0123456789abcdefABCDEF':
                result.append(self.advance())
            try:
                value = int(''.join(result), 16)
            except ValueError:
                return self.error(f"Invalid hex literal: {''.join(result)}")
            return Token(TokenType.INT_LIT, value, start_line, start_col)

        # Decimal
        while self.peek().isdigit():
            result.append(self.advance())

        try:
            value = int(''.join(result))
        except ValueError:
            return self.error(f"Invalid integer literal: {''.join(result)}")
        return Token(TokenType.INT_LIT, value, start_line, start_col)

    def read_char(self) -> Token:
        start_line, start_col = self.line, self.column
        self.advance()  # skip opening quote

        if self.peek() == '\\':
            self.advance()
            ch = self.advance()
            escape_map = {'n': '\n', 't': '\t', 'r': '\r', '0': '\0', '\\': '\\', "'": "'"}
            if ch in escape_map:
                value = ord(escape_map[ch])
            else:
                return self.error(f"Unknown escape sequence: \\{ch}")
        elif self.peek() == "'":
            return self.error("Empty character literal")
        else:
            value = ord(self.advance())

        if self.peek() != "'":
            return self.error("Unterminated character literal")
        self.advance()  # skip closing quote

        return Token(TokenType.CHAR_LIT, value, start_line, start_col)

    def read_string(self) -> Token:
        start_line, start_col = self.line, self.column
        self.advance()  # skip opening quote
        result = []

        while self.peek() != '"' and self.peek() != '\0':
            if self.peek() == '\\':
                self.advance()
                ch = self.advance()
                escape_map = {'n': '\n', 't': '\t', 'r': '\r', '0': '\0', '\\': '\\', '"': '"'}
                if ch in escape_map:
                    result.append(escape_map[ch])
                else:
                    return self.error(f"Unknown escape sequence: \\{ch}")
            elif self.peek() == '\n':
                return self.error("Unterminated string literal")
            else:
                result.append(self.advance())

        if self.peek() == '\0':
            return self.error("Unterminated string literal")
        self.advance()  # skip closing quote

        return Token(TokenType.STRING_LIT, ''.join(result), start_line, start_col)

    def next_token(self) -> Token:
        while True:
            self.skip_whitespace()
            start_line, start_col = self.line, self.column
            ch = self.peek()

            if ch == '\0':
                return Token(TokenType.EOF, None, start_line, start_col)

            # Comments
            if ch == '/':
                if self.peek(1) == '/':
                    self.advance()
                    self.advance()
                    self.skip_line_comment()
                    continue
                elif self.peek(1) == '*':
                    self.advance()
                    self.skip_block_comment()
                    continue

            # Identifiers and keywords
            if ch.isalpha() or ch == '_':
                return self.read_ident()

            # Numbers
            if ch.isdigit():
                return self.read_number()

            # Character literal
            if ch == "'":
                return self.read_char()

            # String literal
            if ch == '"':
                return self.read_string()

            # Two-character operators
            ch2 = self.peek(1)
            two_char = ch + ch2

            two_char_ops = {
                '->': TokenType.ARROW,
                '++': TokenType.PLUS_PLUS,
                '--': TokenType.MINUS_MINUS,
                '<<': TokenType.LT_LT,
                '>>': TokenType.GT_GT,
                '&&': TokenType.AMP_AMP,
                '||': TokenType.PIPE_PIPE,
                '==': TokenType.EQ_EQ,
                '!=': TokenType.BANG_EQ,
                '<=': TokenType.LT_EQ,
                '>=': TokenType.GT_EQ,
                '+=': TokenType.PLUS_EQ,
                '-=': TokenType.MINUS_EQ,
            }

            if two_char in two_char_ops:
                self.advance()
                self.advance()
                return Token(two_char_ops[two_char], two_char, start_line, start_col)

            # Single-character operators and punctuation
            single_char_ops = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.STAR,
                '/': TokenType.SLASH,
                '%': TokenType.PERCENT,
                '&': TokenType.AMP,
                '|': TokenType.PIPE,
                '^': TokenType.CARET,
                '~': TokenType.TILDE,
                '!': TokenType.BANG,
                '<': TokenType.LT,
                '>': TokenType.GT,
                '=': TokenType.EQ,
                '.': TokenType.DOT,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                ';': TokenType.SEMICOLON,
                ',': TokenType.COMMA,
            }

            if ch in single_char_ops:
                self.advance()
                return Token(single_char_ops[ch], ch, start_line, start_col)

            # Unknown character
            self.advance()
            return self.error(f"Unexpected character: {ch!r}")

    def tokenize(self) -> List[Token]:
        """Tokenize the entire source and return list of tokens."""
        tokens = []
        while True:
            tok = self.next_token()
            tokens.append(tok)
            if tok.type == TokenType.EOF or tok.type == TokenType.ERROR:
                break
        return tokens


def tokenize(source: str, filename: str = "<stdin>") -> List[Token]:
    """Convenience function to tokenize source code."""
    lexer = Lexer(source, filename)
    return lexer.tokenize()
