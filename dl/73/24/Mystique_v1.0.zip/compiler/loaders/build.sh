#!/bin/bash
# Build loader_linux (requires gcc with 32-bit support)
set -e
cd "$(dirname "$0")/../.."
gcc -m32 -O1 -fno-stack-protector -o compiler/loaders/loader_linux compiler/loaders/loader_linux.c -ldl
echo "OK  loader_linux"
