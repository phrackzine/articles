@echo off
REM Build loader_win32.exe (requires MSVC)
cd /d "%~dp0\..\.."
cl /nologo /W3 /O1 /GS- /Oi- compiler\loaders\loader_win32.c /Fe:compiler\loaders\loader_win32.exe /link /NODEFAULTLIB /ENTRY:mainCRTStartup /SUBSYSTEM:CONSOLE /SAFESEH:NO /DYNAMICBASE:NO /NXCOMPAT:NO kernel32.lib
if %ERRORLEVEL%==0 echo OK  loader_win32.exe
