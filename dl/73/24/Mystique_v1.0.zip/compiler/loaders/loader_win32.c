// loader_win32.c - PIC shellcode loader for Mystique-compiled code (Win32)
// Loads .bin files and executes them with name-based API resolution.

#pragma comment(linker, "/STACK:0x400000,0x400000")

#include <windows.h>

#pragma function(memcpy)
void* memcpy(void* dst, const void* src, size_t n) {
    unsigned char* d = (unsigned char*)dst;
    const unsigned char* s = (const unsigned char*)src;
    while (n--) *d++ = *s++;
    return dst;
}

#pragma function(memset)
void* memset(void* dst, int val, size_t n) {
    unsigned char* d = (unsigned char*)dst;
    while (n--) *d++ = (unsigned char)val;
    return dst;
}

void print(const char* str) {
    DWORD written;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), str, lstrlenA(str), &written, NULL);
}

void print_hex(unsigned int val) {
    char buf[16]; char* p = buf + 15; *p = 0;
    do { int d = val & 0xF; *--p = d < 10 ? '0' + d : 'A' + d - 10; val >>= 4; } while (val);
    print(p);
}

void print_int(int val) {
    char buf[16]; char* p = buf + 15; *p = 0;
    int neg = val < 0; if (neg) val = -val;
    do { *--p = '0' + (val % 10); val /= 10; } while (val);
    if (neg) *--p = '-';
    print(p);
}

int str_eq(const char* a, const char* b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return *a == *b;
}

int str_len(const char* s) { int n = 0; while (s[n]) n++; return n; }

// ---------------------------------------------------------------------------
// API table — all externs resolved by name from extern_info
// ---------------------------------------------------------------------------

#define MAX_EXTERNS 64

typedef struct { void* functions[MAX_EXTERNS]; } ApiTable;

// Wrapper functions (cdecl for PIC shellcode, delegate to kernel32)

void* __cdecl api_malloc(unsigned int size) {
    return HeapAlloc(GetProcessHeap(), 0, size);
}

void __cdecl api_free(void* ptr) {
    HeapFree(GetProcessHeap(), 0, ptr);
}

int __cdecl api_read(HANDLE h, void* buf, int count) {
    DWORD n = 0;
    return ReadFile(h, buf, count, &n, NULL) ? (int)n : -1;
}

int __cdecl api_write(HANDLE h, const void* buf, int count) {
    DWORD n = 0;
    return WriteFile(h, buf, count, &n, NULL) ? (int)n : -1;
}

HANDLE __cdecl api_open(const char* path, int flags) {
    DWORD access = GENERIC_READ;
    DWORD creation = OPEN_EXISTING;
    if (flags == 1) { access = GENERIC_WRITE; creation = CREATE_ALWAYS; }
    else if (flags > 1) access = GENERIC_READ | GENERIC_WRITE;
    return CreateFileA(path, access, FILE_SHARE_READ, NULL, creation, FILE_ATTRIBUTE_NORMAL, NULL);
}

int __cdecl api_close(HANDLE h) { return CloseHandle(h) ? 0 : -1; }

void __cdecl api_exit(int code) { ExitProcess(code); }

// Resolve all externs by name from extern_info.
// Known stdlib names get wrapper functions; DLL functions via LoadLibraryA/GetProcAddress.
// Format: [extern_count:4][{dll_name\0 func_name\0}...]
int resolve_all_externs(ApiTable* api, unsigned char* extern_info, int extern_info_size, int verbose) {
    if (extern_info_size < 4) return 0;
    int extern_count = *(int*)extern_info;
    unsigned char* ptr = extern_info + 4;
    unsigned char* end = extern_info + extern_info_size;
    int resolved = 0;

    for (int i = 0; i < extern_count && ptr < end; i++) {
        char* dll_name = (char*)ptr;
        while (ptr < end && *ptr) ptr++;
        if (ptr >= end) break;
        ptr++;

        char* func_name = (char*)ptr;
        while (ptr < end && *ptr) ptr++;
        if (ptr >= end) break;
        ptr++;

        int slot = i;
        if (slot >= MAX_EXTERNS) continue;

        // Stdlib wrappers (cdecl bridge to kernel32)
        if      (str_eq(func_name, "malloc")) { api->functions[slot] = (void*)api_malloc; resolved++; }
        else if (str_eq(func_name, "free"))   { api->functions[slot] = (void*)api_free; resolved++; }
        else if (str_eq(func_name, "read"))   { api->functions[slot] = (void*)api_read; resolved++; }
        else if (str_eq(func_name, "write"))  { api->functions[slot] = (void*)api_write; resolved++; }
        else if (str_eq(func_name, "open"))   { api->functions[slot] = (void*)api_open; resolved++; }
        else if (str_eq(func_name, "close"))  { api->functions[slot] = (void*)api_close; resolved++; }
        else if (str_eq(func_name, "exit"))   { api->functions[slot] = (void*)api_exit; resolved++; }
        else if (dll_name[0] != 0) {
            // DLL function — resolve via LoadLibrary/GetProcAddress
            HMODULE hDll = LoadLibraryA(dll_name);
            if (hDll) {
                void* fp = (void*)GetProcAddress(hDll, func_name);
                if (fp) { api->functions[slot] = fp; resolved++; }
            }
        }

        if (verbose && api->functions[slot]) {
            print("  ["); print_int(slot); print("] ");
            if (dll_name[0]) { print(dll_name); print("!"); }
            print(func_name); print(" = 0x"); print_hex((unsigned int)api->functions[slot]);
            print("\n");
        }
    }
    return resolved;
}

// ---------------------------------------------------------------------------
// Main entry — load .bin from command line, execute with API table
// ---------------------------------------------------------------------------

void __stdcall mainCRTStartup() {
    unsigned char* data = NULL;
    DWORD size = 0;
    int verbose = 0;

    // Parse command line
    char* cmdline = GetCommandLineA();
    char* p = cmdline;
    if (*p == '"') { p++; while (*p && *p != '"') p++; if (*p) p++; }
    else { while (*p && *p != ' ') p++; }
    while (*p == ' ') p++;

    if (!*p) {
        print("Usage: loader_win32.exe <shellcode.bin> [-v]\n");
        ExitProcess(1);
    }

    char filename[260];
    int i = 0;
    while (*p && *p != ' ' && i < 259) filename[i++] = *p++;
    filename[i] = 0;
    while (*p == ' ') p++;
    if (*p == '-' && *(p+1) == 'v') verbose = 1;

    // Read .bin file
    HANDLE hFile = CreateFileA(filename, GENERIC_READ, FILE_SHARE_READ, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        print("Cannot open: "); print(filename); print("\n");
        ExitProcess(1);
    }
    size = GetFileSize(hFile, NULL);
    data = (unsigned char*)HeapAlloc(GetProcessHeap(), 0, size);
    if (!data) { CloseHandle(hFile); ExitProcess(1); }
    DWORD bytesRead;
    ReadFile(hFile, data, size, &bytesRead, NULL);
    CloseHandle(hFile);

    if (verbose) {
        print("Loaded "); print_int(size); print(" bytes from "); print(filename); print("\n");
    }

    // Parse PIC .bin header: [entry:4][code:4][data:4][ext_count:4][ext_info_sz:4]
    int entry_offset    = *(int*)(data + 0);
    int code_size       = *(int*)(data + 4);
    int data_size       = *(int*)(data + 8);
    int extern_info_size = *(int*)(data + 16);
    unsigned char* code        = data + 20;
    unsigned char* data_section = data + 20 + code_size;
    unsigned char* extern_info  = data + 20 + code_size + data_size;

    if (verbose) {
        print("Header: entry="); print_int(entry_offset);
        print(" code="); print_int(code_size);
        print(" data="); print_int(data_size);
        print(" ext_info="); print_int(extern_info_size);
        print("\n");
    }

    // Build API table and resolve externs
    ApiTable api;
    memset(&api, 0, sizeof(api));
    if (extern_info_size > 0)
        resolve_all_externs(&api, extern_info, extern_info_size, verbose);

    // Allocate executable memory, copy code + data
    void* exec = VirtualAlloc(NULL, code_size + data_size,
                              MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!exec) { print("VirtualAlloc failed\n"); ExitProcess(1); }

    memcpy(exec, code, code_size);
    if (data_size > 0)
        memcpy((char*)exec + code_size, data_section, data_size);

    // Patch API table pointer at code[2] (PIC slot mechanism)
    *(void**)((char*)exec + 2) = &api;

    if (verbose) {
        print("Code at 0x"); print_hex((unsigned int)exec); print("\n");
    }

    // Execute
    typedef int (__cdecl *entry_t)(ApiTable*);
    entry_t entry = (entry_t)((char*)exec + entry_offset);
    int result = entry(&api);

    print("Result: "); print_int(result); print("\n");

    HeapFree(GetProcessHeap(), 0, data);
    VirtualFree(exec, 0, MEM_RELEASE);
    ExitProcess(result);
}
