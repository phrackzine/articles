// loader_linux.c - PIC shellcode loader for Mystique-compiled code (Linux x86-32)
// Loads .bin files and executes them with name-based API resolution.
// Compile: gcc -m32 -O1 -fno-stack-protector -o loader_linux loader_linux.c -ldl

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <dlfcn.h>

#define MAX_EXTERNS 64

typedef struct { void* functions[MAX_EXTERNS]; } ApiTable;

// ---------------------------------------------------------------------------
// Utility
// ---------------------------------------------------------------------------

void print(const char* str) {
    write(STDOUT_FILENO, str, strlen(str));
}

void print_hex(unsigned int val) {
    char buf[16]; char* p = buf + 15; *p = 0;
    do { int d = val & 0xF; *--p = d < 10 ? '0' + d : 'A' + d - 10; val >>= 4; } while (val);
    print(p);
}

void print_int(int val) {
    char buf[16]; char* p = buf + 15; *p = 0;
    int neg = val < 0; if (neg) val = -val;
    do { *--p = '0' + (val % 10); val /= 10; } while (val);
    if (neg) *--p = '-';
    print(p);
}

int str_eq(const char* a, const char* b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return *a == *b;
}

// ---------------------------------------------------------------------------
// API wrappers (cdecl — default on Linux x86-32)
// ---------------------------------------------------------------------------

void* api_malloc(unsigned int size) { return malloc(size); }
void  api_free(void* ptr)          { free(ptr); }

int api_read(int fd, void* buf, int count) {
    return (int)read(fd, buf, (size_t)count);
}

int api_write(int fd, const void* buf, int count) {
    return (int)write(fd, buf, (size_t)count);
}

int api_open(const char* path, int flags) {
    int o_flags;
    if (flags == 0)      o_flags = O_RDONLY;
    else if (flags == 1) o_flags = O_WRONLY | O_CREAT | O_TRUNC;
    else                 o_flags = O_RDWR   | O_CREAT;
    return open(path, o_flags, 0644);
}

int api_close(int fd) { return close(fd); }
void api_exit(int code) { exit(code); }

// ---------------------------------------------------------------------------
// Resolve all externs by name from extern_info.
// Known stdlib names get wrapper functions; shared lib functions via dlopen/dlsym.
// Format: [extern_count:4][{lib_name\0 func_name\0}...]
// ---------------------------------------------------------------------------

int resolve_all_externs(ApiTable* api, unsigned char* extern_info,
                        int extern_info_size, int verbose) {
    if (extern_info_size < 4) return 0;
    int extern_count = *(int*)extern_info;
    unsigned char* ptr = extern_info + 4;
    unsigned char* end = extern_info + extern_info_size;
    int resolved = 0;

    for (int i = 0; i < extern_count && ptr < end; i++) {
        char* lib_name = (char*)ptr;
        while (ptr < end && *ptr) ptr++;
        if (ptr >= end) break;
        ptr++;

        char* func_name = (char*)ptr;
        while (ptr < end && *ptr) ptr++;
        if (ptr >= end) break;
        ptr++;

        int slot = i;
        if (slot >= MAX_EXTERNS) continue;

        // Stdlib wrappers
        if      (str_eq(func_name, "malloc")) { api->functions[slot] = (void*)api_malloc; resolved++; }
        else if (str_eq(func_name, "free"))   { api->functions[slot] = (void*)api_free; resolved++; }
        else if (str_eq(func_name, "read"))   { api->functions[slot] = (void*)api_read; resolved++; }
        else if (str_eq(func_name, "write"))  { api->functions[slot] = (void*)api_write; resolved++; }
        else if (str_eq(func_name, "open"))   { api->functions[slot] = (void*)api_open; resolved++; }
        else if (str_eq(func_name, "close"))  { api->functions[slot] = (void*)api_close; resolved++; }
        else if (str_eq(func_name, "exit"))   { api->functions[slot] = (void*)api_exit; resolved++; }
        else if (lib_name[0] != 0) {
            // Skip kernel32.dll (Windows-only, never called on Linux)
            if (str_eq(lib_name, "kernel32.dll")) continue;
            // Shared library function — resolve via dlopen/dlsym
            void* hLib = dlopen(lib_name, RTLD_LAZY);
            if (hLib) {
                void* fp = dlsym(hLib, func_name);
                if (fp) { api->functions[slot] = fp; resolved++; }
            }
        }

        if (verbose && api->functions[slot]) {
            print("  ["); print_int(slot); print("] ");
            if (lib_name[0]) { print(lib_name); print("!"); }
            print(func_name); print(" = 0x"); print_hex((unsigned int)(size_t)api->functions[slot]);
            print("\n");
        }
    }
    return resolved;
}

// ---------------------------------------------------------------------------
// Main — load .bin from command line, execute with API table
// ---------------------------------------------------------------------------

int main(int argc, char** argv) {
    unsigned char* data = NULL;
    int size = 0;
    int verbose = 0;

    if (argc < 2) {
        print("Usage: loader_linux <shellcode.bin> [-v]\n");
        return 1;
    }

    char filename[512];
    int i = 0;
    const char* src = argv[1];
    while (*src && i < 511) filename[i++] = *src++;
    filename[i] = 0;

    for (int j = 2; j < argc; j++)
        if (argv[j][0] == '-' && argv[j][1] == 'v') verbose = 1;

    int fd = open(filename, O_RDONLY);
    if (fd < 0) { print("Cannot open: "); print(filename); print("\n"); return 1; }

    size = (int)lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);
    data = (unsigned char*)malloc(size);
    if (!data) { close(fd); return 1; }
    read(fd, data, (size_t)size);
    close(fd);

    if (verbose) {
        print("Loaded "); print_int(size); print(" bytes from "); print(filename); print("\n");
    }

    // Parse PIC .bin header: [entry:4][code:4][data:4][ext_count:4][ext_info_sz:4]
    int entry_offset     = *(int*)(data + 0);
    int code_size        = *(int*)(data + 4);
    int data_size        = *(int*)(data + 8);
    int extern_info_size = *(int*)(data + 16);
    unsigned char* code         = data + 20;
    unsigned char* data_section = data + 20 + code_size;
    unsigned char* extern_info  = data + 20 + code_size + data_size;

    if (verbose) {
        print("Header: entry="); print_int(entry_offset);
        print(" code="); print_int(code_size);
        print(" data="); print_int(data_size);
        print(" ext_info="); print_int(extern_info_size);
        print("\n");
    }

    // Build API table and resolve externs
    ApiTable api;
    memset(&api, 0, sizeof(api));
    if (extern_info_size > 0)
        resolve_all_externs(&api, extern_info, extern_info_size, verbose);

    // Allocate RWX memory, copy code + data
    int alloc_size = code_size + (data_size > 0 ? data_size : 0);
    void* exec = mmap(NULL, alloc_size,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (exec == MAP_FAILED) { print("mmap failed\n"); return 1; }

    memcpy(exec, code, code_size);
    if (data_size > 0)
        memcpy((char*)exec + code_size, data_section, data_size);

    // Patch API table pointer at code[2] (PIC slot mechanism)
    *(void**)((char*)exec + 2) = &api;

    if (verbose) {
        print("Code at 0x"); print_hex((unsigned int)(size_t)exec); print("\n");
    }

    // Execute
    typedef int (*entry_t)(ApiTable*);
    entry_t entry = (entry_t)((char*)exec + entry_offset);
    int result = entry(&api);

    print("Result: "); print_int(result); print("\n");

    free(data);
    munmap(exec, alloc_size);
    return result;
}
