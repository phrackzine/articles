// backend_main.mc — CLI entry point for the standalone MystC backend.
// Simply wraps compile_main() from the backend library.

#include "backend_mystc.mc"

int main(int _api, char* input_data, int input_size, int flags, struct CompileOutput* out) {
    return compile_main(_api, input_data, input_size, flags, out);
}
