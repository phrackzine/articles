# Testing

611 pytest tests cover everything from frontend lexing to gen-N
self-recompilation. The suite is the safety net that lets aggressive
backend changes ship — every transform combination, every output format,
and the C ↔ MC backend equivalence are all checked.

## Layout

```
tests/
├── frontend/        Lexer, parser, typecheck, irgen, bytecode (151 tests)
├── backend/         IR + x86 transforms, determinism, regalloc (100 tests)
├── e2e/             Full pipeline + stress matrix + integrators + Linux (~317 tests)
├── regression/      Known-bug reproductions (28 tests, parametrized)
├── tools/           disasm.py + bridge.py (15 tests)
├── programs/        Test .mc sources (compiler_stress, extern_stress_*, ...)
└── victims/         Committed PE/ELF victim fixtures (9 victims × both formats)
```

## Markers

```bash
pytest                    # Full suite (611 tests; 8 skip on non-Linux)
pytest -m frontend        # 125 fast tests
pytest -m backend         # 100 fast tests
pytest -m e2e             # 276 tests
pytest -m mystiquefall    # 4 tests, ~15 min wall clock
pytest -m lacrimystique   # 13 tests, ~20 min wall clock
pytest -m linux           # 8 Linux-only tests (skipped on Windows native)
pytest -m regression      # 28 tests
```

`pytest -m frontend` and `pytest -m backend` together complete in under
10 seconds and are the typical inner-loop check.

## Running a single test

```bash
pytest tests/backend/test_transforms_x86.py::test_poly_instrs
pytest tests/e2e/test_standalone_pe.py::TestPeStandaloneBasic -q
pytest tests/regression/test_known_bugs.py -k unspill_slot_zero
```

## Fixtures

**`tests/programs/`** holds `.mc` source files used by multiple tests:

- `compiler_stress.mc` — exercises every IR opcode and language feature.
- `extern_stress_win32.mc` / `extern_stress_linux.mc` — exhaustive
  `extern` declaration coverage, split by platform because the harmless
  API set differs.
- `standalone_test.mc` — kernel32 builtin wrappers via stdlib.
- `test_linux.mc` — Linux-specific syscall and cdecl coverage.

**`tests/victims/`** holds the committed victim binaries used as
infection targets for the integrator and infector tests: nine victim
families (`sort`, `math`, `crypto`, `string`, `state`, `graph`, `matrix`,
`tree`, `compress`), each built as both `.exe` (PE) and `.elf32`, plus
`stress_victim.exe`.

`build.py clean` skips this subtree (`SKIP_SUBPATHS`) so the committed
fixtures survive every clean.

## What each marker covers

### `frontend`

`tests/frontend/test_*.py` — pure Python tests that exercise the frontend
in isolation:

- `test_lexer.py` — tokenization edge cases.
- `test_preprocess.py` — `#define` / `#include` / `#ifdef` handling.
- `test_strip_debug.py` — debug-info stripping pass.
- `test_parser.py` — every AST shape, error recovery, operator precedence.
- `test_typecheck.py` — type rules, scope resolution, error messages.
- `test_irgen.py` — AST → IR lowering, every opcode emission path.
- `test_bytecode.py` — `.mcb` round-trip, format stability.
- `test_errors.py` — "this is the error message we expect" snapshots.

No backend involvement — fast, hermetic.

### `backend`

`tests/backend/test_*.py` — backend in isolation, fed `.mcb` and
inspecting the produced `.bin`:

- `test_basic.py` — smoke tests on a minimal program.
- `test_transforms_ir.py`, `test_transforms_x86.py` — each transform
  individually.
- `test_transforms_combo.py` — every pairwise transform combination.
- `test_determinism.py` — same `(seed, genome)` always produces the same
  bytes, *and* the C and MC backends produce identical output for the
  same inputs (the `test_c_vs_mc_backend_*` cases).
- `test_regalloc.py` — register-allocator stress: spill ordering, reg
  reuse, scratch lifetime.
- `test_output_formats.py` — PIC / PE / ELF output structure validation.

### `e2e`

End-to-end: compile a `.mc` source through the whole pipeline and run
the result.

- `test_pipeline.py` — round-trip many programs, verify exit codes.
- `test_stress.py` — `compiler_stress.mc` × every transform combination
  × multiple seeds.
- `test_generations.py` — repeated `--transform-ir` rounds (IR equilibrium
  check).
- `test_standalone_pe.py` — Win32 PE output, runs the produced `.exe`,
  validates exit codes and PE structure.
- `test_standalone_recompilation.py` — Gen0 → Gen1 → ... chain on the
  recompiler binaries (PE + ELF).
- `test_selfhost.py` — the MC backend compiles itself and the resulting
  `.bin` matches the C backend's output.
- `test_extern_stress.py` — every harmless API combination.
- `test_infector_pe.py`, `test_infector_elf.py` — the append-style
  infectors (`--infector-pe` / `--infector-elf`).
- `test_linux.py` — Linux-only ELF tests, gated by `sys.platform ==
  "linux"`. Skipped on Windows native; run under WSL to execute.
- `test_mystiquefall.py`, `test_lacrimystique.py` — code-integrator
  engines; see their own markers below.

### `mystiquefall` / `lacrimystique`

The two code-integrator engines, each with their own marker:

- `tests/e2e/test_mystiquefall.py` (4 tests):
  - `TestBundleInfectsVictim::test_infect_and_run` — single infection
    round-trip.
  - `TestThreeGenerationStress::test_three_gens` — 3 generations of
    self-infection.
  - `TestVictimChain::test_chain` — 9 different victims across
    generations.
  - `TestPayloadChain::test_payload_through_three_victims` — payload
    survives across generations.

- `tests/e2e/test_lacrimystique.py` (13 tests): one per victim family
  (9), plus three-gen chain, polymorphism check, victim chain, and
  payload chain.

Both markers use `tmp_path` for all artifacts, never polluting the
project root. The MystiqueFall suite takes ~15 min wall clock — running
`-q` shows few dots, that is normal.

### `linux`

Eight tests in `tests/e2e/test_linux.py`, gated by
`pytest.mark.skipif(sys.platform != "linux")`. They cover the full
compile-and-run pipeline against a native Linux backend + loader:
basic compile-and-run, polymorphism across seeds, all IR transforms,
all x86 transforms, the combined-transforms case, ELF structure
validation, and a multi-seed all-transforms run. To run them on
Windows, invoke pytest under WSL.

### `regression`

`tests/regression/` holds two files of parametrized regression tests
for known fixed bugs:

- `test_edge_cases.py` (10 tests) — divisions by 1, shifts by 0/31,
  deep recursion, single-`if`-no-else, char arithmetic, large local
  arrays, and similar corner cases that broke codegen at one point.
- `test_known_bugs.py` (15+ tests, all parametrized) — one test per
  named-bug fingerprint: `pre_prologue_junk`, `unspill_slot_zero`,
  `reorder_funcs_extern_breakage`, `dead_code_ra_clobber`,
  `poly_variant_mov_guards`, and others. Each test parametrizes over
  seeds and (where relevant) transform flags so a single bug's repro
  spans multiple actual test cases.

Adding a fix? Add a parametrized case to `test_known_bugs.py` before
the fix, watch it fail, push the fix, watch it pass. The regression
marker is the cheapest insurance in the codebase.

### `tools`

`tests/tools/test_*.py` — exercises the auxiliary tools:

- `test_disasm.py` — `utils/disasm.py` decoding correctness on real
  backend output, plus targeted tests for the syscall opcodes
  (`INT 0x80`, `SYSCALL` `0F 05`, `SYSENTER` `0F 34`) using
  hand-crafted minimal `.bin` buffers.
- `test_bridge.py` — `ide/bridge.py` end-to-end.

## Common pitfalls

- **WSL vs native Linux.** Linux ELF tests live in
  `tests/e2e/test_linux.py` and skip on Windows. To run them from a
  Windows checkout, invoke pytest under WSL python. The helpers `_bash`
  and `run_elf` in `tests/e2e/test_standalone_recompilation.py`
  abstract WSL invocation for the ELF-on-Windows recompilation tests.
- **Mystique-built ELFs have no section headers.** ELF tests that parse
  output binaries should use program headers (`PT_LOAD + PF_X`) — see
  `utils/integrator_disasm.py:_read_elf_text` for the reference parser.

## Determinism check

If you suspect non-determinism, the canonical check is:

```bash
pytest -m backend -k determinism -q
```

This runs `test_determinism.py`, which compiles many programs at fixed
seeds and asserts byte-equality both across runs of the same backend and
across the C and MC backends.
