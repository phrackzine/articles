"""Build a single-page HTML documentation browser from all markdown files.

Run with no arguments to regenerate ``docs/index.html`` from the markdown
files in this directory. The output is a self-contained HTML page with a
sidebar, search, and client-side markdown rendering via marked.js.

Usage:
    python docs/build_docs.py
"""

import os
import json
import html

DOCS_DIR = os.path.dirname(os.path.abspath(__file__))

# Ordered list of docs. `level` is the indent depth (0 = top-level, 1 =
# child). Click order in the sidebar is the order here.
DOCS = [
    {"name": "Index",         "path": "README.md",        "level": 0},
    {"name": "Overview",      "path": "overview.md",      "level": 0},
    {"name": "Language",      "path": "language.md",      "level": 1},
    {"name": "Tutorial",      "path": "tutorial.md",      "level": 1},
    {"name": "Architecture",  "path": "architecture.md",  "level": 0},
    {"name": "Frontend",      "path": "frontend.md",      "level": 1},
    {"name": "IR",            "path": "ir.md",            "level": 1},
    {"name": "Backend",       "path": "backend.md",       "level": 1},
    {"name": "Transforms",    "path": "transforms.md",    "level": 1},
    {"name": "Genome",        "path": "genome.md",        "level": 1},
    {"name": "Bundle",        "path": "bundle.md",        "level": 1},
    {"name": "IDE",           "path": "ide.md",           "level": 0},
    {"name": "Testing",       "path": "testing.md",       "level": 0},
]

def read_doc(rel_path):
    path = os.path.join(DOCS_DIR, rel_path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def build():
    docs_data = []
    for entry in DOCS:
        content = read_doc(entry["path"])
        docs_data.append({
            "name": entry["name"],
            "path": entry["path"],
            "level": entry["level"],
            "content": content,
        })

    docs_json = json.dumps(docs_data)

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mystique Documentation</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}

body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background: #0d1117;
    color: #c9d1d9;
    display: flex;
    height: 100vh;
    overflow: hidden;
}}

/* Sidebar */
#sidebar {{
    width: 280px;
    min-width: 280px;
    background: #161b22;
    border-right: 1px solid #30363d;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}}

#sidebar-header {{
    padding: 20px 16px 12px;
    border-bottom: 1px solid #30363d;
}}

#sidebar-header h1 {{
    font-size: 18px;
    font-weight: 600;
    color: #58a6ff;
    letter-spacing: 0.5px;
}}

#sidebar-header p {{
    font-size: 11px;
    color: #8b949e;
    margin-top: 4px;
}}

#sidebar-search {{
    padding: 8px 16px;
    border-bottom: 1px solid #30363d;
}}

#sidebar-search input {{
    width: 100%;
    padding: 6px 10px;
    background: #0d1117;
    border: 1px solid #30363d;
    border-radius: 6px;
    color: #c9d1d9;
    font-size: 13px;
    outline: none;
}}

#sidebar-search input:focus {{
    border-color: #58a6ff;
}}

#nav {{
    flex: 1;
    overflow-y: auto;
    padding: 8px 0;
}}

#nav .nav-section {{
    padding: 8px 16px 4px;
    font-size: 11px;
    font-weight: 600;
    color: #8b949e;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}

#nav .nav-item {{
    display: block;
    padding: 6px 16px 6px 24px;
    font-size: 14px;
    color: #c9d1d9;
    text-decoration: none;
    cursor: pointer;
    border-left: 3px solid transparent;
    transition: all 0.15s;
}}

#nav .nav-item.level-1 {{
    padding-left: 36px;
    font-size: 13px;
}}

#nav .nav-item:hover {{
    background: #1c2129;
    color: #f0f6fc;
}}

#nav .nav-item.active {{
    background: #1c2129;
    color: #58a6ff;
    border-left-color: #58a6ff;
}}

#nav .nav-toc-item {{
    display: block;
    padding: 3px 16px 3px 48px;
    font-size: 12px;
    color: #8b949e;
    text-decoration: none;
    cursor: pointer;
    border-left: 3px solid transparent;
    transition: color 0.1s, background 0.1s;
    line-height: 1.4;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}}

#nav .nav-toc-item.toc-h1 {{
    padding-left: 40px;
    color: #b1bac4;
    font-weight: 600;
    margin-top: 4px;
}}

#nav .nav-toc-item.under-l1 {{
    padding-left: 60px;
}}

#nav .nav-toc-item.under-l1.toc-h1 {{
    padding-left: 52px;
}}

#nav .nav-toc-item:hover {{
    background: #1c2129;
    color: #e6edf3;
}}

#nav .nav-item .status {{
    font-size: 10px;
    padding: 1px 6px;
    border-radius: 10px;
    margin-left: 6px;
    vertical-align: middle;
}}

.status-complete {{ background: #1b4332; color: #52c41a; }}
.status-future {{ background: #3b2e00; color: #d4a017; }}
.status-superseded {{ background: #3b1c1c; color: #f85149; }}

/* Content */
#content {{
    flex: 1;
    overflow-y: auto;
    padding: 32px 48px 64px;
    max-width: 960px;
}}

#content .doc-path {{
    font-size: 12px;
    color: #8b949e;
    margin-bottom: 16px;
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
}}

/* Markdown styles */
#content h1 {{ font-size: 28px; font-weight: 600; color: #f0f6fc; margin: 0 0 16px; padding-bottom: 8px; border-bottom: 1px solid #30363d; }}
#content h2 {{ font-size: 22px; font-weight: 600; color: #f0f6fc; margin: 32px 0 12px; padding-bottom: 6px; border-bottom: 1px solid #21262d; }}
#content h3 {{ font-size: 18px; font-weight: 600; color: #e6edf3; margin: 24px 0 8px; }}
#content h4 {{ font-size: 15px; font-weight: 600; color: #e6edf3; margin: 20px 0 6px; }}

#content p {{ line-height: 1.7; margin: 8px 0; }}
#content a {{ color: #58a6ff; text-decoration: none; }}
#content a:hover {{ text-decoration: underline; }}

#content code {{
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
    font-size: 13px;
    background: #1c2129;
    padding: 2px 6px;
    border-radius: 4px;
    color: #e6edf3;
}}

#content pre {{
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px;
    overflow-x: auto;
    margin: 12px 0;
    line-height: 1.5;
}}

#content pre code {{
    background: none;
    padding: 0;
    font-size: 13px;
    color: #c9d1d9;
}}

#content table {{
    border-collapse: collapse;
    width: 100%;
    margin: 12px 0;
    font-size: 14px;
}}

#content th {{
    background: #161b22;
    font-weight: 600;
    text-align: left;
    padding: 8px 12px;
    border: 1px solid #30363d;
    color: #e6edf3;
}}

#content td {{
    padding: 6px 12px;
    border: 1px solid #30363d;
    vertical-align: top;
}}

#content tr:nth-child(even) {{ background: #0d1117; }}

#content blockquote {{
    border-left: 4px solid #30363d;
    padding: 8px 16px;
    margin: 12px 0;
    color: #8b949e;
    background: #161b22;
    border-radius: 0 6px 6px 0;
}}

#content ul, #content ol {{
    margin: 8px 0;
    padding-left: 28px;
    line-height: 1.7;
}}

#content li {{ margin: 2px 0; }}

#content hr {{
    border: none;
    border-top: 1px solid #21262d;
    margin: 24px 0;
}}

#content strong {{ color: #e6edf3; }}
#content em {{ color: #b1bac4; }}

/* Scrollbar */
::-webkit-scrollbar {{ width: 8px; }}
::-webkit-scrollbar-track {{ background: #0d1117; }}
::-webkit-scrollbar-thumb {{ background: #30363d; border-radius: 4px; }}
::-webkit-scrollbar-thumb:hover {{ background: #484f58; }}
</style>
</head>
<body>
<div id="sidebar">
    <div id="sidebar-header">
        <h1>Mystique</h1>
        <p>x86 Metamorphic Compiler</p>
    </div>
    <div id="sidebar-search">
        <input type="text" id="search" placeholder="Search docs..." />
    </div>
    <div id="nav"></div>
</div>
<div id="content">
    <p style="color: #8b949e; margin-top: 40vh; text-align: center;">Select a document from the sidebar.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<script>
const DOCS = {docs_json};

function buildNav(filter) {{
    const nav = document.getElementById("nav");
    nav.innerHTML = "";
    const lower = (filter || "").toLowerCase();

    DOCS.forEach((doc, idx) => {{
        if (lower && !doc.name.toLowerCase().includes(lower) && !doc.content.toLowerCase().includes(lower)) return;
        const el = document.createElement("div");
        el.className = "nav-item level-" + (doc.level || 0);
        el.dataset.idx = idx;
        el.textContent = doc.name;
        el.onclick = () => showDoc(idx);
        nav.appendChild(el);
    }});
}}

// Walk the rendered content for h1/h2 (skipping the doc title — always
// the very first heading) and inject them as a TOC under the active
// nav-item. Old TOC items are removed first.
function renderTocFor(idx) {{
    document.querySelectorAll(".nav-toc-item").forEach(el => el.remove());
    const activeNav = document.querySelector('.nav-item[data-idx="' + idx + '"]');
    if (!activeNav) return;

    const headings = document.querySelectorAll("#content h1, #content h2");
    if (headings.length <= 1) return;

    const doc = DOCS[idx];
    const underClass = (doc.level || 0) === 1 ? " under-l1" : "";

    let after = activeNav;
    let firstSkipped = false;
    headings.forEach(h => {{
        if (!firstSkipped) {{ firstSkipped = true; return; }}  // skip doc title
        if (!h.id) return;
        const item = document.createElement("a");
        const isH1 = h.tagName === "H1";
        item.className = "nav-toc-item" + (isH1 ? " toc-h1" : "") + underClass;
        item.href = "#";
        item.textContent = h.textContent;
        item.title = h.textContent;
        item.addEventListener("click", e => {{
            e.preventDefault();
            const target = document.getElementById(h.id);
            if (target) target.scrollIntoView({{behavior: "smooth", block: "start"}});
        }});
        after.insertAdjacentElement("afterend", item);
        after = item;
    }});
}}

function showDoc(idx, opts) {{
    opts = opts || {{}};
    const fromHistory = opts.fromHistory;
    const doc = DOCS[idx];
    const content = document.getElementById("content");

    // Save the OUTGOING doc's current scroll position into its history
    // entry so Back/Forward can restore where the user was when they
    // left. Skip when we're responding to a popstate (we'd overwrite
    // the very state we're about to restore).
    if (!fromHistory && history.state) {{
        history.replaceState(
            Object.assign({{}}, history.state, {{scrollY: content.scrollTop}}),
            "", location.hash);
    }}

    // Render markdown (or plain text for .txt)
    let rendered;
    if (doc.path.endsWith(".txt")) {{
        rendered = "<pre><code>" + doc.content.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;") + "</code></pre>";
    }} else {{
        rendered = marked.parse(doc.content);
    }}

    content.innerHTML = '<div class="doc-path">' + doc.path + '</div>' + rendered;
    content.scrollTop = 0;

    // marked.js v5+ no longer assigns id="" to headings by default. Walk
    // them and slugify so the per-doc TOC and cross-doc fragment links
    // (foo.md#bar) can both find their target via getElementById.
    {{
        const seen = {{}};
        content.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach(h => {{
            if (h.id) return;
            let slug = h.textContent.toLowerCase()
                .replace(/[^\\w\\s-]/g, "")
                .replace(/\\s+/g, "-")
                .replace(/-+/g, "-")
                .replace(/^-+|-+$/g, "");
            if (!slug) slug = "section";
            if (seen[slug]) {{
                seen[slug]++;
                slug = slug + "-" + seen[slug];
            }} else {{
                seen[slug] = 1;
            }}
            h.id = slug;
        }});
    }}

    // Rewrite same-page and cross-doc markdown links so they navigate
    // inside the SPA without disturbing the URL hash (which we use to
    // track which doc is active).
    content.querySelectorAll("a[href]").forEach(a => {{
        const href = a.getAttribute("href");
        if (!href) return;

        // Same-page fragment: scroll to the target id, leave the hash
        // alone so the active-doc URL tracking stays intact.
        if (href.startsWith("#")) {{
            a.addEventListener("click", e => {{
                e.preventDefault();
                const el = document.getElementById(href.slice(1));
                if (el) el.scrollIntoView({{behavior: "smooth"}});
            }});
            return;
        }}

        // External / absolute / parent-relative: let the browser handle.
        if (/^[a-z]+:/i.test(href) || href.startsWith("/")
            || href.startsWith("..")) return;

        // Cross-doc link "<other>.md" or "<other>.md#frag" — match
        // against the DOCS table and route through showDoc.
        const [path, frag] = href.split("#");
        const targetIdx = DOCS.findIndex(d => d.path === path);
        if (targetIdx < 0) return;
        a.addEventListener("click", e => {{
            e.preventDefault();
            showDoc(targetIdx, {{frag: frag}});
        }});
    }});

    // Update active state
    document.querySelectorAll(".nav-item").forEach(el => {{
        el.classList.toggle("active", parseInt(el.dataset.idx) === idx);
    }});

    // Inject the per-doc TOC under the active nav-item.
    renderTocFor(idx);

    // Update URL hash. Use pushState on user-driven navigation so the
    // browser Back/Forward buttons step through doc views; use
    // replaceState when responding to a popstate event so we don't
    // double-stack history entries.
    const newHash = "#" + encodeURIComponent(doc.path);
    if (fromHistory) {{
        // Re-render in response to popstate or initial load — don't
        // touch history; just restore the saved scroll position.
        if (opts.scrollY) content.scrollTop = opts.scrollY;
    }} else if (location.hash === newHash) {{
        history.replaceState({{idx: idx, scrollY: 0}}, "", newHash);
    }} else {{
        history.pushState({{idx: idx, scrollY: 0}}, "", newHash);
    }}

    // Scroll to a fragment if requested (cross-doc anchor click).
    if (opts.frag) {{
        requestAnimationFrame(() => {{
            const el = document.getElementById(opts.frag);
            if (el) el.scrollIntoView({{behavior: "smooth"}});
        }});
    }}
}}

// Browser back/forward — re-render the doc named in the URL hash and
// restore the scroll position saved when the user left this entry.
window.addEventListener("popstate", e => {{
    const state = e.state || history.state || {{}};
    const hash = decodeURIComponent(location.hash.slice(1));
    const idx = DOCS.findIndex(d => d.path === hash);
    const target = idx >= 0 ? idx : 0;
    showDoc(target, {{fromHistory: true, scrollY: state.scrollY || 0}});
}});

// Search
document.getElementById("search").addEventListener("input", function() {{
    buildNav(this.value);
}});

// Init
buildNav();

// Load from hash or default to Overview. fromHistory: true keeps us
// from pushing a new entry on first load (which would let Back take
// the user to a no-hash version of the same page). Then seed the
// initial entry with state so subsequent save-on-leave has a place to
// stash scrollY.
const hash = decodeURIComponent(location.hash.slice(1));
const hashIdx = DOCS.findIndex(d => d.path === hash);
const startIdx = hashIdx >= 0 ? hashIdx : 0;
showDoc(startIdx, {{fromHistory: true}});
history.replaceState({{idx: startIdx, scrollY: 0}}, "",
                     "#" + encodeURIComponent(DOCS[startIdx].path));
</script>
</body>
</html>"""

    out_path = os.path.join(DOCS_DIR, "index.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"Built: {out_path}")

if __name__ == "__main__":
    build()
