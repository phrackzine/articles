# Mystique Documentation

**Mystique** is a polymorphic, metamorphic (self-hosting), and evolutionary cross-compiler.
It compiles **MystC** (a small C subset) into x86-32 code. Every compilation produces different bytes with identical semantics, driven by a 65-gene genome and a seeded PRNG.

## Reading order

1. **[Overview](overview.md)** — what this is, the file extensions, how to
   build and run, project layout, dependencies.
2. **[Language](language.md)** — formal MystC language reference: what it
   has, what it deliberately doesn't, subtle semantics, platform selection.
3. **[Tutorial](tutorial.md)** — guided tour of MystC by progressive
   example, from "hello world" to "build your own integrator."
4. **[Architecture](architecture.md)** — system diagram, data flow, the
   frontend → IR → backend → output pipeline.
5. **[Frontend](frontend.md)** — Python frontend (lexer → parser → typecheck
   → IR generation → bytecode).
6. **[IR](ir.md)** — the bytecode format, opcodes, and the `.mcb` file layout.
7. **[Backend](backend.md)** — the C and MC backends, register allocation,
   PIC vs absolute mode, output formats (PIC, PE, ELF).
8. **[Transforms](transforms.md)** — the IR-level and x86-level polymorphic
   transforms.
9. **[Genome](genome.md)** — the 65-gene system, mutation, expression flags.
10. **[Bundle](bundle.md)** — the three families of programs
    built on top of the compiler: infectors, recompilers, integrators
    (MystiqueFall and LacriMystique). Includes a build-it-yourself
    tutorial.
11. **[IDE](ide.md)** — the Flask-based web IDE.
12. **[Testing](testing.md)** — the 611-test pytest suite, markers, victims
    fixtures, runtime characteristics.