# Genome

The genome is a 138-byte binary structure containing 65 genes that parametrize
every polymorphic decision the backend makes. It is the second axis of
diversity (alongside `--seed`): a different genome with the same seed
produces a different binary; mutating the genome over generations is what
turns a self-recompiling program into a polymorphic chain.

The idea of a parametrized "genome" of weights and probabilities driving
polymorphic decisions comes from MetaPHOR (The Mental Driller, 29A#6,
2002). Vecna's Lexotan32, also in 29A#6, introduced a related "genotype"
concept — different in mechanism but part of the same genetic-metaphor
lineage that this engine inherits from.

Reference implementations:

- C: `compiler/backend/backend_mystc.c` — `struct Genome`,
  `default_genome()`, `genome_to_binary()`, `genome_from_binary()`,
  `mutate_genome()`, `load_genome_json()`, `save_genome_json()`.
- MC: `compiler/backend/backend_mystc.mc` — mirrors the *layout* using a
  flat array indexed by `GI_*` constants (e.g. `GI_UNFOLD_CHANCE = 0`,
  `GI_ADD_WEIGHTS = 13`, …). It implements the read + mutate side only
  (`init_default_genome`, `load_genome_binary`, `mutate_genome`); JSON
  I/O is C-side only.
- Defaults: `compiler/backend/genome.json`.

## Layout

`struct Genome` holds **65 integer fields**, organized into five
categories. Each "gene" is one integer
slot; some fields are arrays of slots that work together as a weight
vector. The categories total to:

| Category | Slots | Purpose |
|---|---|---|
| IR genes | 13 | Probabilities and weights for IR-level transforms |
| x86 poly-encoding weights | 34 | Variant-selection weights for polymorphic instruction encoding |
| x86 transform genes | 12 | Probabilities for x86-level transforms |
| Expression | 2 | Which transforms are active + how often the mask flips |
| Reorder | 4 | Intensity / chance for the four reorder passes |
| **Total** | **65** | |

In the per-category tables below, the `Slots` column shows how many
integer slots a field occupies. Single-value fields take 1 slot;
arrays like `add_weights[5]` take 5 slots — one per array element.

### IR genes (13 slots)

| Field | Slots | Meaning |
|---|---|---|
| `unfold_chance` | 1 | % chance of unfolding a constant load (0–100) |
| `unfold_weights` | 4 | Weights across the four unfold strategies |
| `substitute_chance` | 1 | % chance of substituting an instruction (0–100) |
| `dead_code_chance` | 1 | % chance of inserting dead IR code (0–100) |
| `dead_code_weights` | 4 | Weights across the four dead-code patterns |
| `nop_chance` | 1 | % chance of inserting IR NOPs (0–100) |
| `nop_max_count` | 1 | Max NOPs per insertion (1–10) |

### x86 poly-encoding weights (34 slots)

Each vector picks among the variants listed in
[Transforms — polymorphic instruction encoding](transforms.md#polymorphic-instruction-encoding).

| Field | Slots | Picks among |
|---|---|---|
| `add_weights` | 5 | The 5 ADD encodings |
| `sub_weights` | 4 | The 4 SUB encodings |
| `movi_weights` | 6 | The 6 general MOV-immediate encodings |
| `movi_zero_weights` | 3 | The 3 MOV-zero encodings |
| `movi_neg1_weights` | 3 | The 3 MOV-(-1) encodings |
| `xor_weights` | 3 | The 3 XOR encodings |
| `cmp_weights` | 2 | The 2 CMP encodings |
| `junk_seq_weights` | 8 | The 8 dead-code patterns |

### x86 transform genes (12 slots)

| Field | Slots | Meaning |
|---|---|---|
| `dead_prologue_pct` | 1 | % chance of dead code after a function prologue |
| `dead_block_pct` | 1 | % chance of dead code at block boundaries |
| `dead_instr_pct` | 1 | % chance of dead code between instructions |
| `opaque_pct` | 1 | % chance of inserting an opaque predicate |
| `opaque_weights` | 3 | Weights across the 3 opaque-predicate forms |
| `junk_call_block_pct` | 1 | % chance of a junk-function call at block boundaries |
| `junk_call_instr_pct` | 1 | % chance of a junk-function call between instructions |
| `harmless_block_pct` | 1 | % chance of a harmless API call at block boundaries |
| `harmless_instr_pct` | 1 | % chance of a harmless API call between instructions |
| `junk_func_pct` | 1 | Junk function count as % of real functions (0–200) |

### Expression (2 slots)

| Field | Slots | Meaning |
|---|---|---|
| `expression_flags` | 1 | 15-bit mask: bit *i* enables transform *i* — see [`expression_flags`](#expression_flags) |
| `expression_rate` | 1 | % chance of flipping each mask bit per mutation (0–100) |

### Reorder (4 slots)

| Field | Slots | Meaning |
|---|---|---|
| `reorder_instrs_intensity` | 1 | Multiplier on swap attempts per block (1–10) |
| `reorder_locals_chance` | 1 | Per-function probability of shuffling locals (0–100) |
| `reorder_blocks_chance` | 1 | Per-function probability of shuffling blocks (0–100) |
| `reorder_funcs_chance` | 1 | Global probability of shuffling function order (0–100) |

### Storage

In memory, every gene is a C `int`. On disk, every gene is an `int16`.
The binary form is:

```
"GENE"(4)  +  version:u16  +  temperature:u8  +  reserved:u8  +  65 × int16   →   138 bytes
```

The C backend writes and reads this format through `genome_to_binary()`
/ `genome_from_binary()`. The MC backend only consumes it
(`load_genome_binary` + in-place `mutate_genome`) — recompilers and
integrators rewrite the binary buffer themselves rather than going
through a writer helper. JSON form is what `genome.json` stores and
what the IDE displays.

### Outside the genome array

`genome_temperature` is **not** part of `struct Genome` — it's a
separate global tracked alongside the 65 gene values. On disk it
rides along in the binary header at byte 6 (above), so a single
138-byte blob carries both. Temperature controls how aggressively
each mutation step perturbs gene values; see [Mutation](#mutation) below.

## The three gene types

**Probability genes (0-100%)** — each one says "with this percent chance,
fire this transform at this site." `unfold_chance = 30` means: at every
constant load, there's a 30% chance of unfolding it. Independent decisions
per site.

**Weight vectors** — each describes a discrete probability distribution
over equivalent encodings. `xor_weights = [400, 350, 250]` means: when
emitting `XOR reg, reg`, pick variant 0 with probability 0.40, variant 1
with 0.35, variant 2 with 0.25. The PRNG draws once per emit via
`genome_pick(weights, n, prng)`, which sums whatever values it finds and
picks an index proportional to its share. Defaults sum to 1000 by
convention, but the sum is **not enforced** — `genome_pick` is happy with
any positive total, and mutation perturbs each weight independently
(see below).

**Range values (intensity / count)** — small integers controlling how much
of something happens. `reorder_instrs_intensity = 5` controls the depth
of the reorder pass; `junk_func_pct = 50` says "synthesize junk functions
totalling 50% of the real function count this run."

## `expression_flags`

`expression_flags` is a **second gate** that sits between the CLI flags
and the transform machinery.

**Why it exists.** Without this gate, every generation in a recompile
chain would run the exact same set of transforms — only the per-site
PRNG decisions would differ. The output would diversify in detail but
not in *character*. `expression_flags` lets the genome turn whole
transforms on and off across generations: generation N might fire
poly-instrs + dead-code + junk-funcs, generation N+1 might run
poly-instrs + opaque + harmless-calls instead. Same source, same CLI,
same per-transform probabilities; very different output by virtue of
*which* transforms are running this round. That's what gives each
generation its "personality" and what makes `--genome-mutate` produce
visibly different code patterns generation to generation, not just
shuffled bytes within the same patterns.

**The mechanic.** A transform fires only if **both** are set:

```
transform_active = cli_flag_on  AND  bit_i_of_expression_flags_set
```

Concretely, after CLI parsing the backend does:

```c
int ef = g_genome.expression_flags;
if (!(ef & (1 << 0)))  ir_obfuscate_names = 0;
if (!(ef & (1 << 1)))  ir_unfold = 0;
if (!(ef & (1 << 2)))  ir_substitute = 0;
// ... one line per transform, bits 0–14 ...
```

So the genome can silence a transform that the CLI enabled, but it
cannot turn one on that the CLI didn't. The CLI is the upper bound; the
genome is the active subset.

**Bit assignment** — fixed and stable across versions. Bits 0–8 cover
the IR transforms; bits 9–14 cover the x86 transforms.

| Bit | IR transform | Bit | x86 transform |
|---|---|---|---|
| 0 | obfuscate names | 9 | poly instrs |
| 1 | unfold | 10 | dead code |
| 2 | substitute | 11 | opaque |
| 3 | deadcode | 12 | junk funcs |
| 4 | nops | 13 | harmless calls |
| 5 | reorder instrs | 14 | shuffle funcs |
| 6 | reorder locals | | |
| 7 | reorder blocks | | |
| 8 | reorder funcs | | |

Bits 15+ are reserved — `mutate_genome()` masks the field with `0x7FFF`
after each mutation step to keep them clear.

**Default: all-on (`0x7FFF`).** The default genome has every bit set, so
out of the box the genome doesn't gate anything — `expression_flags` is
fully transparent and only the CLI matters. Mutation is what introduces
the per-generation gating: the `expression_rate` gene (0–100) sets a
per-bit flip probability, applied each generation:

```c
for (int bit = 0; bit < 15; bit++) {
    if (prng_range(prng, 100) < g->expression_rate) {
        g->expression_flags ^= (1 << bit);
    }
}
```

At `expression_rate = 10`, each of the 15 bits has a 10% chance of
flipping each generation — so the active subset of transforms drifts
over time, and `expression_rate` itself is just another gene the
mutator can perturb.

## Mutation

`mutate_genome(prng, temperature)` performs a temperature-controlled
random walk in genome space:

```c
int step = 1 + temperature / 10;            // perturbation magnitude
int mutation_count = 1 + temperature / 20;  // genes touched per call
int* genes = (int*)g;

for (int m = 0; m < mutation_count; m++) {
    int idx = prng_range(prng, 65);                  // pick a random gene
    int delta = prng_range(prng, 2 * step + 1) - step;
    genes[idx] += delta;
    if (genes[idx] < 0)    genes[idx] = 0;
    if (genes[idx] > 1000) genes[idx] = 1000;
}
```

Each call mutates only `1 + temperature/20` genes (3 at temperature 50,
6 at 100), not all 65 — the genome drifts a few coordinates at a time.
Weight vectors are mutated as plain integers like everything else: their
sums drift away from 1000 over generations, but `genome_pick` works on
any positive total, so the distributions remain well-defined.

After the random walk, range-specific clamps apply: probability genes are
capped at 100, `nop_max_count` and `reorder_instrs_intensity` to [1, 10],
`junk_func_pct` to [0, 200], every weight element to [1, 900] (the [1, …]
floor prevents degenerate "always pick variant N" distributions).

`expression_flags` has its own mutation step: each of the 15 bits has a
`prng_range(100) < expression_rate` chance of flipping.

Then the **temperature itself mutates**:

```c
int t_step = 1 + g_genome_temperature / 20;
int t_delta = prng_range(&mut_prng, 2 * t_step + 1) - t_step;
g_genome_temperature = clamp(g_genome_temperature + t_delta, 0, 100);
```

So the genome wanders, and the rate at which it wanders also wanders.
High-temperature generations explore aggressively; low-temperature ones
stabilize on a current set of choices.

The mutation PRNG is seeded with `seed ^ 0x4D555421` ("MUT!") — a
different stream than the codegen PRNG so a `--genome-mutate` doesn't
disturb the per-transform decisions.

## CLI

```bash
# Load + use a specific genome:
backend_mystc.exe in.mcb --pic out.bin --genome compiler/backend/genome.json

# Mutate before compiling (one-shot mutation step):
backend_mystc.exe in.mcb --pic out.bin --genome-mutate

# Override temperature (default = 50):
backend_mystc.exe in.mcb --pic out.bin --genome-mutate --genome-temperature 80

# Save the genome that ended up being used (post-mutation):
backend_mystc.exe in.mcb --pic out.bin --genome-mutate --genome-out gen1.json
```

In a self-recompiling chain, each generation does:

1. Load the embedded genome.
2. Mutate (with `genome_temperature` from the genome itself).
3. Compile the embedded `.mcb` with the mutated genome.
4. Write the mutated genome into the new binary's bundle.

So generation N+1's genome differs from N's by one mutation step, with the
temperature evolving alongside.

## Inspecting genomes

The IDE's **Evolution** view shows genomes generation-by-generation, with
the heatmap visualizing which genes are mutating fastest. The
**Transforms** view in the IDE has per-gene sliders (probability +
expression flag toggle + temperature) for manual genome editing.

To dump a genome from the CLI — load it, then write it back as JSON:

```
backend_mystc.exe in.mcb --pic out.bin --genome compiler/backend/genome.json --genome-out dumped.json
```

The `--pic out.bin` part is incidental; `--genome-out` writes `dumped.json`
regardless. Open it in any editor.

The binary format is `"GENE"(4) + version:u16 + reserved:u16 + 65 ×
int16` — see `genome_to_binary()` / `genome_from_binary()` in
`backend_mystc.c` if you need to roll your own reader.

## Stability of `genome.json`

`compiler/backend/genome.json` is the canonical **default** genome and is
checked in. The clean target preserves it (`KEEP_FILES = {"genome.json"}`
in `build.py`). Hand-tuned changes there will affect every generated
binary that doesn't pass an explicit `--genome`.
