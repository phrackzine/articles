# Architecture

This document explains the system end-to-end: what each stage does, how data
moves between them, and why the pipeline is split the way it is.

## System Diagram

```
                        source.mc                   (MystC source)
                        ┌──────────────────────┐
                        │ #include "stdlib.mc" │
                        │                      │
                        │ int main() {         │
                        │    ...               │
                        │ }                    │
                        └──────────┬───────────┘
                                   │
                                   ▼
                          Frontend (Python)
                        ┌──────────────────────┐
                        │         lex          │  source → token stream
                        │          │           │  (#define / #ifdef supported)
                        │          ▼           │
                        │        parse         │  recursive descent
                        │          │           │  → AST
                        │          ▼           │
                        │       typecheck      │  resolve names, validate
                        │          │           │  → typed AST
                        │          ▼           │
                        │        irgen         │  lower to flat IR module
                        │          │           │  (globals, funcs, blocks,
                        │          │           │   3-address-code instrs)
                        │          ▼           │
                        │       bytecode       │ ──► source.mce / source.mct
                        │                      │     (textual IR — for
                        │                      │      inspection / debugging)
                        └──────────┬───────────┘
                                   │
                                   ▼
                              source.mcb         (serialized IR —
                                   │              MystC bytecode)
                                   ▼
                          {seed, genome, flags}
                                   │
                                   ▼
     ┌───────►   C backend (.exe)  /  MC backend (.bin)
     │
     │                  ┌──────────────────────┐
     │                  │  optimize_module     │  clean: nops + dead code
     │                  │          │           │
     │                  │          ▼           │
     │                  │  transform_module    │  IR-level polymorphism
     │                  │          │           │  (rename, unfold, substitute,
     │                  │          │           │   reorder, dead code, etc)
     │                  │          ▼           │
     │                  │      gen_module      │  x86-level polymorphism
     │                  │          │           │  (poly instrs, dead bytes,
     │                  │          │           │   opaque preds, junk funcs)
     │                  │          ▼           │
     │                  │        writer        │
     │                  └──────────┬───────────┘
     │                             │
     │     ┌───────────┬───────────┼───────────┬───────────┐
     │     ▼           ▼           ▼           ▼           ▼
     │    .mcb       .bin        .exe        .elf         Bundle
     │ Transformed    PIC       PE32+IAT    ELF32+sys    PE / ELF
     │     IR       relative    absolute    absolute        │
     │     │           │                                    │
     │     │           ▼                                    │
     │     │      loader_win32                              │
     └─────┘      loader_linux                              │
     round-trip:                                            │
     feed back into a backend                               │
                                       ┌────────────────────┘
                                       │
                                       ▼
                    Metamorphic Bundle binary (PE / ELF)
                    ┌─────────────────────────────────────┐
                    │                .text                │
                    │        compiled carrier code        │
                    ├─────────────────────────────────────┤
                    │   ┌─────────────────────────────┐   │
                    │   │      BundleHeader (32B)     │   │  ┐ 
                    │   │  "META" / version / hdr_sz  │   │  │
                    │   │   n_desc / base / pay_sz    │   │  │
                    │   │      key / reserved         │   │  │
                    │   ├─────────────────────────────┤   │  │ plaintext
                    │   │ Descriptor[n_desc]  (16B ea)│   │  │
                    │   │ (kind, offset, size, flags) │   │  ┘
                    │   ├─────────────────────────────┤   │
                    │   │           carrier           │   │  ┐
                    │   │ ┌─────────────────────────┐ │   │  │
                    │   │ │  recomp_{pe,elf}.mcb /  │ │   │  │
                    │   │ │  infector_{pe,elf}.mcb/ │ │   │  │ 
                    │   │ │  integrator_entry.mcb   │ │   │  │
                    │   │ ├─────────────────────────┤ │   │  │
                    │   │ │                         │ │   │  │
                    │   │ │    backend_mystc.mcb    │ │   │  │ 
                    │   │ │                         │ │   │  │
                    │   │ └─────────────────────────┘ │   │  │  XOR'd with
                    │   ├─────────────────────────────┤   │  │  header.key
                    │   │     engine (integrator)     │   │  │
                    │   │ ┌─────────────────────────┐ │   │  │
                    │   │ │   mystiquefall.mcb /    │ │   │  │
                    │   │ │   lacrimystique.mcb     │ │   │  │ 
                    │   │ └─────────────────────────┘ │   │  │
                    │   ├─────────────────────────────┤   │  │
                    │   │         payload.mcb         │   │  │
                    │   │         (optional)          │   │  │
                    │   ├─────────────────────────────┤   │  │
                    │   │           genome            │   │  ┘
                    │   └─────────────────────────────┘   │
                    └─────────────────────────────────────┘
```

   Per-family layouts:

      Recompiler  :  [ recomp   │ payload │ genome  │ BundleHeader ]
      Infector    :  [ infector │ payload │ genome  │ BundleHeader ]
      Integrator  :  [ entry    │ engine  │ payload │ genome │ BundleHeader ]

   On disk, the BundleHeader (plus its Descriptor table) sits at the
   bottom of .data, after the encrypted components. The diagram above
   places it on top to read "header first, then what it points at" —
   the actual byte order is the reverse.

   payload.mcb is user-optional — omit the positional argument to the
   carrier flag and the bundle is built without one.

## Frontend (`compiler/frontend/`)

Python 3, single import surface, no external dependencies.

```
source.mc → lexer.py → parser.py → typecheck.py → irgen.py → bytecode.py → out.mcb
                ↓           ↓          ↓             ↓            ↓
            tokens      AST        typed AST     IR module    .mcb bytes
```

Files:

- `lexer.py` — token stream, supports preprocessor `#define` / `#ifdef`.
- `parser.py` — recursive descent, builds the AST in `mystc_ast.py`.
- `typecheck.py` — fills in types, validates expressions, resolves names
  through `symbols.py`.
- `irgen.py` — lowers the typed AST into a flat IR module: a list of
  globals, a list of functions, each function a list of basic blocks of
  three-address-code instructions.
- `bytecode.py` — serializes the IR module to `.mcb` (and back).
- `mystcc.py` — CLI driver: parses flags, glues the stages together, can
  emit `.mcb`, `.mct` (text IR), AST dump, or all of these together.
- `strip_debug.py` — optional pass that drops direct calls to the
  debug-print builtins (`print`, `print_int`, `print_hex`, `print_err`,
  `print_int_err`); enabled by `--strip-debug`. Indirect calls and the
  function definitions themselves are left alone; unreferenced string
  literals naturally drop out at IR generation.
- `scramble.py` — optional pass that demotes integer-literal global
  initializers into a generated `__init_globals` function and overwrites
  each initializer's `.data` slot with `crc32(name)`. A `CALLV` to
  `__init_globals` is inserted into the head of `main` so the real values
  are restored at runtime. Enabled by `--scramble-globals`. Defeats
  fixed-offset signatures over the `.data` init-value sequence
  (small-int magic, `GI_*` constants, etc.).

Output shape: a `.mcb` file that fully describes the program at the IR
level — string table, globals, externs (with DLL/library names), functions
(with basic blocks of opcodes and operands). The frontend never produces
machine code.

## Backend (`compiler/backend/`)

Two independent implementations of the same backend, sharing nothing but
their input format and output format:

- **C backend** (`backend_mystc.c`, ~7,200 lines) — bootstrap. Compiled with
  MSVC or GCC into `backend_mystc.exe` / `backend_mystc`.
- **MC backend** (`backend_mystc.mc`, ~6,500 lines) — self-hosted. Compiled
  by the C backend into `backend_mystc.mcb`, then by itself into
  `backend_mystc.bin`.

Both consume `.mcb` and produce identical bytes for the same
`(seed, genome, transforms)` — this is verified by determinism tests in
`tests/backend/test_determinism.py`. The MC backend is the canonical one;
the C backend exists to bootstrap it and to provide a reference
implementation for testing.

Inside either backend the flow is:

```
.mcb bytes
   │
   ▼
parse_bytecode() → struct Module      (IR: strings, globals, funcs, blocks)
   │
   ▼
optimize_module()                      (clean: remove_nops + remove_dead_code)
   │
   ▼
transform_module(prng, genome, cfg)    (IR-level polymorphic transforms)
   │
   ▼
optimize_module_random(prng)           (stochastic fold_constants)
   │
   ▼
init_codegen() + gen_module()          (x86-32 emission with greedy regalloc)
                                       (C backend names this codegen_init; MC backend names it init_codegen)
   │
   ▼
output writer:
   ├── --pic           : pic header + code + data + extern table
   ├── --pe-standalone : full PE32 with real IAT (auto-embed bundle if requested)
   ├── --elf-standalone: ELF32 with syscall wrappers (auto-embed bundle)
   ├── --transform-ir  : re-serialize the post-transform IR back to .mcb
   └── bundle carriers : --recompiler-{pe,elf}, --infector-{pe,elf},
                         --integrator-{pe,elf} — convenience flags that
                         pair a pre-built carrier .mcb with auto-embed
                         (see Bundle below)
```

### Two-pass optimization

There are two distinct optimization passes around `transform_module` —
a deterministic cleanup before, and a stochastic cleanup after. The
stochastic second pass is what keeps the IR from bloating across
generations of self-recompilation. See
[Backend → Two-pass optimization](backend.md#two-pass-optimization) for
the full explanation.

## Loaders

PIC `.bin` outputs cannot run on their own — they need a loader to set up
RWX memory, populate the API table, and jump to the entry. Two reference
loaders ship with the project:

- `compiler/loaders/loader_win32.c` — opens a `.bin`, parses its header
  (entry offset, code size, data size, extern count, extern info), resolves
  imports via `LoadLibraryA` + `GetProcAddress`, copies code+data into
  `VirtualAlloc(RWX)`, and calls the entry.
- `compiler/loaders/loader_linux.c` — equivalent for Linux, with
  `mmap(PROT_READ|PROT_WRITE|PROT_EXEC)` and a thin syscall wrapper layer.

For standalone PE/ELF output (`--pe-standalone`, `--elf-standalone`) the
backend bypasses the loader entirely: it writes a fully-formed executable
with the resolved IAT (PE) or syscall wrappers (ELF) baked in.

## Metamorphic Bundle

A **bundle** is a self-contained PE/ELF whose `.data` section carries
one or more embedded `.mcb` components plus the active genome. The binary
the backend emits is a **Gen0** executable — the seed of a generational
chain. Run it, and it produces a Gen1 binary by one of three mechanisms,
depending on the application family:

- **Recompilation** (`--recompiler-{pe,elf}`) — recompiles itself with
  a mutated genome and writes a new Gen1 of itself to disk.
- **Infection** (`--infector-{pe,elf}`) — appends a transformed copy
  of its payload to a victim PE/ELF and patches the victim's entry
  point. Gen1 is the infected victim.
- **Code integration** (`--integrator-{pe,elf}`) — disassembles a
  victim PE/ELF's `.text`, scatters the entry program's functions
  (sliced on RET boundaries) throughout, and reassembles. Gen1 is
  the integrated victim.

Each Gen1 is itself a fresh bundle with a one-step-mutated genome —
distinct bytes, same behavior — and can spawn a Gen2 via the same
mechanism. The chain produces an ever-changing sequence of binaries.

Bundle anatomy and per-family layouts are shown in the System Diagram
above. For the catalog of bundle families and the build-time pattern,
see [Bundle](bundle.md).

## Determinism & polymorphism

The pipeline has a hard split at the `.mcb` boundary. Everything before
it is deterministic — same source always yields the same `.mcb`.
Everything after it is parameterized by `(seed, genome, transforms)`,
so the *same* `.mcb` produces a different `.bin` / `.exe` / `.elf` on
every distinct triple, with bit-exact reproducibility per triple.

The `.mcb` itself is the project's stable, inspectable contract: the
[IR](ir.md) doc specifies its byte layout, and the IDE's "see your IR"
view exists because it doesn't change shape between rebuilds.

**Deterministic frontend.** Lexing/parsing/typing/IR-gen produces the
same bytes for the same input every time. Tests can cache `.mcb`
output; the IDE can offer a "see your IR" view that doesn't change
shape between rebuilds.

**Polymorphic backend.** Every call to the backend with a different
seed produces different code with the same behavior. Transforms run on
the IR (rename functions, unfold constants, substitute equivalent
instructions, reorder blocks) and on the emitted x86 (poly encodings,
dead bytes, opaque predicates, junk functions). The genome controls
which transforms fire and at what intensity.

**Metamorphic.** The MC backend is `#include`d by the integrator
entry, the infectors, and the recompilers, so a single compiled `.mcb`
of any of those programs contains the entire backend. That is what
enables an infected binary to carry its own complete compiler, mutate,
and recompile itself into the next generation.

### PRNG seeding

The PRNG is seeded once per backend invocation:

```c
struct Prng prng;
prng_seed(&prng, seed);
```

Every random choice — register order, transform decisions, junk insertion —
draws from this single stream. The genome adds a parallel layer of
parameters (transform probabilities, weight vectors, expression flags)
that is loaded *before* the PRNG is seeded. The result: bit-exact
reproducibility per `(seed, genome)`, with diversity across either axis.

`pytest -m backend -k determinism` exercises this.

## Where to read next

- [Frontend](frontend.md) — language reference and frontend stages.
- [IR](ir.md) — the bytecode format and opcodes.
- [Backend](backend.md) — codegen, register allocator, output formats.
- [Transforms](transforms.md) — the IR and x86 transform menu.
- [Genome](genome.md) — the 65 genes and how mutation works.
- [Bundle](bundle.md) — programs built on top of the compiler.
