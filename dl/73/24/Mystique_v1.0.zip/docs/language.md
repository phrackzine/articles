# Language Reference — MystC

**MystC** is the source language Mystique compiles. It is a strict C
subset chosen so that a self-hosting backend can implement it in
itself — no libc, no complex parser features, no runtime support
beyond what the program explicitly imports. The backend is itself
~6,500 lines of MystC, which makes it the largest worked example of
the language.

The toolchain treats the language name as **MystC** everywhere
(filenames `.mc` / `.mcb` / `.mct` / `.mce`, the compiler driver
`mystcc`, this prose).

## What MystC has

- **Types.** `int` (32-bit signed), `char` (8-bit, sign-extending),
  `void`, `T*` (pointer to any type), `T[N]` (fixed-size arrays), and
  named `struct` types.
- **Storage classes.** `extern` for imports, plain for everything
  else. All locals must be declared at the top of their containing
  block before any executable statement.
- **Control flow.** `if` / `else`, `while`, `for`, `break`,
  `continue`, `return`.
- **Expressions.** Full C arithmetic and comparison operators;
  bitwise `& | ^ ~`, shifts `<< >>`, address-of `&`, dereference `*`,
  member access `.` and `->`.
- **Functions.** Forward declarations, definitions, recursion,
  indirect calls through function pointers (any `int` containing a
  function address can be called).
- **Function address-of.** `int p = &my_func;` yields the address of
  the function in the compiled binary, callable indirectly.
- **Strings.** `"literal"` is an interned `char*` pointing into the
  program's string table.
- **Preprocessor.** `#define`, `#ifdef` / `#ifndef` / `#endif`,
  `#include`.
- **Externs.** `extern "dll.name" T func(...)` imports a function
  from a named DLL (Windows) or library (Linux).

## What MystC does NOT have

- `float`, `double`, `long`, `short`, `unsigned`.
- `union`, `enum`, `typedef`, bitfields.
- `switch` / `case`, `do-while`, `goto`, ternary `?:`.
- `++` and `--` (use `x = x + 1`).
- Compound assignment operators `+=` `-=` etc. (`x = x + y`).
- Struct assignment (`a = b` where both are structs) — copy field by
  field, or write a small helper function.
- Variable-length arrays.
- Standard libc — no `printf`, no `malloc` (without an explicit
  `extern` declaration). The runtime gets exactly what the program
  declares.
- Function-like macros — `#define` is text substitution only.

## Subtle semantics

- **`>>` is arithmetic** (sign-extending) — there is no separate
  logical shift. If you need logical shift on a `char`, mask after.
- **All locals declared up front.** `for (int i = 0; ...)` is not
  supported as written: declare `int i;` at the top of the block,
  then `for (i = 0; ...; ...)`.
- **Struct locals need explicit size.** The frontend computes them,
  but inside the backend (where structs are emitted manually) you
  sometimes see explicit `sizeof`-equivalent constants.
- **Externs are resolved by name through an API table** baked into
  the output `.bin` header. The loader fills the table at startup;
  the code reads its function pointers from there. There are no
  auto-registered builtins — every imported function must be declared
  with `extern`, including C-runtime calls like `malloc` / `write`.
  The backend reserves API slots 0–6 for the well-known names
  `malloc`, `free`, `read`, `write`, `open`, `close`, `exit` if a
  program declares them; slot 7 is a fallback stub; user externs
  start at slot 8. `extern "kernel32.dll" int GetTickCount(void);`
  works immediately, no other changes needed.

## Standard library — what `#include "stdlib.mc"` gives you

`compiler/backend/stdlib.mc` ships with the project. Almost every
MystC program does `#include "stdlib.mc"` at the top — it provides
the C-runtime calls and a small set of utility helpers that would
otherwise be tedious to re-declare from scratch. This section
catalogues what's there, organized by what a programmer would reach
for. (For *why* stdlib lives with the backend rather than the
language frontend, see [Backend → Standard library](backend.md#standard-library-stdlibmc).)

### C-runtime wrappers

Identical names on Windows and Linux. Internally they are completely
different — Win32 calls `HeapAlloc` / `WriteFile` / `CreateFileA` /
`ExitProcess`; Linux uses raw `__syscall(num, ...)` (`mmap2`, `write`,
`open`, `exit`, …). You write the same source either way.

| Signature | Purpose |
|---|---|
| `void* malloc(int size)` | allocate `size` bytes (Linux: PROT_RWX so engines can JIT into the heap). |
| `void  free(void* ptr)` | free a pointer previously returned by `malloc`. |
| `int   read(int fd, char* buf, int n)` | read up to `n` bytes from `fd` (0 = stdin). |
| `int   write(int fd, char* buf, int n)` | write `n` bytes to `fd` (1 = stdout, 2 = stderr). |
| `int   open(char* path, int mode)` | `mode==0` → read; otherwise write+create+truncate. Returns a handle/fd. |
| `int   close(int fd)` | close handle. |
| `void  exit(int code)` | terminate process with `code`. |

These occupy reserved API slots 0–6 (see *Subtle semantics* above).

### I/O helpers

You usually start a program with `init_io()` once, then use `print*`
freely.

| Signature | Purpose |
|---|---|
| `void init_io(void)` | populate `g_stdout` / `g_stderr` (handle on Win32, fd 1/2 on Linux). Call once before any `print*`. |
| `void print(char* s)` | write a NUL-terminated string to stdout. |
| `void print_int(int v)` | write `v` as a decimal integer to stdout. |
| `void print_hex(int v)` | write `v` as 8 hex digits (no `0x`) to stdout. |
| `void print_err(char* s)` | same as `print`, but to stderr. |
| `void print_int_err(int v)` | same as `print_int`, but to stderr. |
| `int  str_len(char* s)` | length of a NUL-terminated string. |
| `int  str_eq(char* a, char* b)` | 1 if equal, 0 otherwise. |
| `void str_copy(char* dst, char* src)` | copy a NUL-terminated string (caller sizes `dst`). |
| `void mem_copy(char* dst, char* src, int n)` | byte copy. |
| `void mem_set(char* dst, int val, int n)` | fill `n` bytes with `val`. |
| `int  align_up(int v, int align)` | round `v` up to the next multiple of `align`. |
| `void write_file(char* path, char* data, int size)` | atomic file write (open+write+close). |

### Endianness-correct integer pack/unpack

`.mcb` and PE/ELF headers are little-endian byte streams; these helpers
keep the byte order explicit.

| Signature | Purpose |
|---|---|
| `void  write_i16(char* buf, int off, int val)` | store low 16 bits of `val` LE at `buf+off`. |
| `void  write_i32(char* buf, int off, int val)` | store 32 bits LE. |
| `int   read_i16(char* buf, int off)` | read 16-bit LE (sign-extended). |
| `int   read_i32(char* buf, int off)` | read 32-bit LE. |

### A small PRNG

Suitable for non-cryptographic uses: shuffling, dithering, simulation.
Internally a linear congruential generator
(`state = state * 1664525 + 1013904223`), state in `g_prng_state`.

| Signature | Purpose |
|---|---|
| `void  prng_seed(int seed)` | initialize the stream. |
| `int   prng_next(void)` | next 32-bit value. |
| `int   prng_range(int max)` | uniform integer in `[0, max)`. |
| `int   runtime_seed(void)` | runtime entropy: `GetTickCount() ^ GetCurrentProcessId()` on Win32; on Linux reads 4 bytes from `/dev/urandom`, falling back to `getpid()` if the device is unavailable. Useful as a seed source. |

### Dynamic byte buffer

A grow-on-demand byte buffer for assembling binary output (PE/ELF
images, scattered code, etc.) without sizing it up front. Capacity
doubles when a write would overflow.

| Signature | Purpose |
|---|---|
| `struct Buffer { char* data; int len; int cap; }` | the buffer struct (read its fields directly). |
| `struct Buffer* buf_new(int cap)` | allocate a new buffer with initial capacity. |
| `void buf_grow(struct Buffer* b, int needed)` | ensure room for `needed` more bytes (no-op if already sized). |
| `void buf_write_u8(struct Buffer* b, int val)` | append one byte. |
| `void buf_write_u16(struct Buffer* b, int val)` | append two bytes (LE). |
| `void buf_write_u32(struct Buffer* b, int val)` | append four bytes (LE). |
| `void buf_write_bytes(struct Buffer* b, char* data, int len)` | append a byte run. |
| `void buf_patch_u32(struct Buffer* b, int off, int val)` | overwrite an earlier 4-byte slot at `off` (forward-reference patch). |

### Bundle runtime handle

Recompilers and integrators rely on additional `stdlib.mc` symbols —
the bundle runtime handle: `struct BundleHeader` + `struct Descriptor`,
the `g_bundle_header` pointer, `bundle_open` / `bundle_find` /
`bundle_get` / `bundle_xor`, and the `BC_*` descriptor kinds. These
matter only when a binary needs to find, recompile, or JIT-execute
embedded bytecode (the JIT step itself uses the `load_and_run_bin`
helper, which lives in `backend_mystc.mc`, not stdlib). See
[Bundle](bundle.md) for the full picture and usage.

## Platform selection

A program that needs both Win32 and Linux variants typically does:

```c
#ifdef WIN32
extern "kernel32.dll" int GetTickCount(void);
#endif
#ifdef LINUX
extern int time(int* t);
#endif
```

The `.mc` source itself stays platform-agnostic; you pick the target
at build time by passing exactly one of `-DWIN32` or `-DLINUX` to the
frontend:

```bash
python -m compiler.frontend.mystcc app.mc -DWIN32 -o app_win.mcb
python -m compiler.frontend.mystcc app.mc -DLINUX -o app_lin.mcb
```

`build.py` does this for every multi-platform `.mc` in the project
automatically. There is no `#define WIN32` line at the top of source
files — putting it there would hard-pin the source to one platform.

## Examples

`docs/examples/` contains a handful of small programs:

- `example.mc` — the bare two-arithmetic-ops program used in the
  Overview's walking example.
- `factorial.mc` — recursive factorial.
- `fibonacci_payload_win32.mc` / `_linux.mc` — minimal payload that
  prints.
- `globals.mc` — global variable usage.
- `linked_list.mc` — manual heap allocation via stdlib's
  `malloc`.
- `simple_test.mc` — branches, loops, basic arithmetic.

For a much larger MystC program, the backend itself
(`compiler/backend/backend_mystc.mc`) is the canonical reference —
it exercises every language feature. The integrator engines
(`bundles/integrators/{mystiqueFall,lacriMystique}/*.mc`) are
the next-largest at ~3,200–4,100 lines each.

The [Tutorial](tutorial.md) walks every feature from "hello world"
upward by example; this doc is the formal reference.
