# Transforms

Transforms are the source of polymorphism. They run inside the backend
between IR parsing and code emission, and again inside the x86 emitter
itself. Each transform is gated by a CLI flag *and* by the genome's
`expression_flags` bitmask — so a flag enables the transform, but the
genome can still mask it off (and a mutated genome will).

Implementations live alongside the rest of the backend in
`compiler/backend/backend_mystc.c` and `backend_mystc.mc` (the two
implementations are byte-equivalent).

## IR transforms

These run on the IR module before code generation. CLI flags:

| Flag | Gene bit | Description |
|---|---|---|
| `--ir-obfuscate-names` | 0 | Randomize function and label names. |
| `--ir-unfold` | 1 | Unfold constants — replace `x = 5` with arithmetic that produces 5. |
| `--ir-substitute` | 2 | Substitute equivalent instruction sequences (`x + y` ↔ `x - (-y)`, etc). |
| `--ir-deadcode` | 3 | Insert dead instructions whose results are never used. |
| `--ir-nops` | 4 | Insert IR NOPs. Any that survive the second cleanup pass emit a single literal `0x90` at codegen. |
| `--ir-reorder-instrs` | 5 | Reorder independent instructions within a block. |
| `--ir-reorder-locals` | 6 | Permute local variable indices. |
| `--ir-reorder-blocks` | 7 | Reorder basic blocks (rewriting jumps to compensate). |
| `--ir-reorder-funcs` | 8 | Shuffle function order in the module — externs, the string table, and the globals table all ride along. |

### Per-transform breakdown

All examples below are real IR text emitted by the frontend + backend
for this baseline program:

```c
int add(int a, int b) {
    return a + b;
}

int abs_val(int x) {
    if (x < 0) {
        return 0 - x;
    }
    return x;
}

int main() {
    int sum;
    int n;
    sum = add(3, 4);
    n = abs_val(0 - 7);
    return sum + n;
}
```

The baseline `main()` in `.mce` form is:

```
int main() {
    int l0;
    int l1;

  entry:
    t0 = 3
    t1 = 4
    t2 = add(t0, t1)
    *l0 = t2
    t3 = 0
    t4 = 7
    t5 = t3 - t4
    t6 = abs_val(t5)
    *l1 = t6
    t7 = *l0
    t8 = *l1
    t9 = t7 + t8
    return t9
}
```

Each transform below is run via `backend_mystc.exe demo.mcb
--transform-ir out.mcb --<flag> --seed <N>` and re-serialized with
`utils/mcb2text.py out.mcb --expr out.mce`.

#### `--ir-obfuscate-names`

Replaces every function name and label with a randomized `r<hex>` token.
String literal contents are untouched; only names visible to the IR are
remapped. The mapping is one-to-one within a compile, so identity is
preserved (the new name for `main` is the same everywhere `main` is
referenced).

```
// seed=1001
str s0 = "r380b50"     // was "add"
str s1 = "re42fa8"     // was "abs_val"
str s2 = "main"        // entry point is preserved
str s3 = "r5addd3"     // was "entry"
str s4 = "reb29d1"     // was "then"
str s5 = "r3cfe62"     // was "endif"

int r380b50(int arg0, int arg1) {
  r5addd3:
    t0 = *arg0
    ...
}
```

#### `--ir-unfold`

Picks one of four strategies per constant load (`unfold_weights`):

| Strategy | Pattern | Example for `c = 4` |
|---|---|---|
| 0 — add | `a = c1`<br>`b = c2`<br>`a = a + b`<br>(c1+c2 = c) | `t5 = 1`<br>`t2 = 3`<br>`t11 = t5 + t2` |
| 1 — xor | `a = c ^ r`<br>`b = r`<br>`a = a ^ b`<br>(any 32-bit r) | `t5 = 0x9c11`<br>`t2 = 0x9c15`<br>`t11 = t5 ^ t2` |
| 2 — sub | `a = c + r`<br>`b = r`<br>`a = a - b` | `t2 = 10`<br>`t6 = 10`<br>`t4 = t2 - t6`<br>(unfolds `0`) |
| 3 — skip | leave the constant alone | `t1 = 4` |

```
// seed=1001 — add strategy applied to the constant 4 (second arg)
entry:
    t8 = 3
    t5 = 1          ← unfolded
    t2 = 3          ← unfolded
    t11 = t5 + t2   ← reconstructs 4
    t9 = add(t8, t11)
```

Note: a second optimization pass folds 50% of constants back, so an
unfolded value may collapse before reaching codegen — this is what
gives self-recompilation chains a stable IR size.

#### `--ir-substitute`

Replaces arithmetic with algebraically equivalent forms when the second
operand of the instruction is an *immediate* `VK_CONST` value:

- `ADD r, +k` → `SUB r, -k`
- `SUB r, +k` → `ADD r, -k`
- `MUL r, 2^n` → `SHL r, n`

Both backends implement this transform identically
(`backend_mystc.c:transform_substitute_instrs`,
`backend_mystc.mc:transform_substitute_instrs`), but in the current
pipeline it is **dormant**: the frontend lowers every literal to a
standalone `CONST` opcode whose result is a temp, and arithmetic
opcodes then take two temps as operands. `VK_CONST` only ever appears
as the `arg1` of a `CONST` opcode, never as `src2` of `ADD`/`SUB`/`MUL`,
so the transform's precondition is never met.

It is shipped as-is for future use: an IR rewriter that *does* fold
immediates directly into arithmetic operands (or a future frontend
optimization that does so) would immediately benefit, with no backend
changes needed. Until then, the same algebraic diversity is supplied
by `--x86-poly-instrs` (which substitutes equivalent encodings at the
machine-code layer instead of the IR layer).

#### `--ir-deadcode`

Inserts unused computations chosen from four patterns (`dead_code_weights`):

| Pattern | Shape |
|---|---|
| 0 — dead constant | `t = c` (single CONST) |
| 1 — dead add | `t1 = c1`<br>`t2 = c2`<br>`t3 = t1 + t2` |
| 2 — dead XOR | `t1 = r`<br>`t2 = t1 ^ t1`<br>(always 0) |
| 3 — dead copy | `t1 = c`<br>`t2 = t1` |

```
// seed=42 — all four patterns appear in one main()
entry:
    t3 = 3
    t10 = 4
    t6 = 14697         ← pattern 2 step 1
    t15 = t6 ^ t6      ← pattern 2 step 2 (= 0, unused)
    t17 = add(t3, t10)
    *l0 = t17
    t5 = 0
    t13 = 494          ← pattern 0 (lone dead constant)
    t14 = 7
    t1 = t5 - t14
    t11 = 3            ← pattern 1 step 1
    t18 = 65           ← pattern 1 step 2
    t12 = t11 + t18    ← pattern 1 step 3 (unused)
    t9 = abs_val(t1)
    t8 = 360           ← pattern 3 step 1
    t7 = t8            ← pattern 3 step 2 (unused copy)
    *l1 = t9
    t16 = *l0
    t0 = 371           ← pattern 0
    t2 = *l1
    t4 = t16 + t2
    return t4
```

The first cleanup pass runs *before* deadcode, so the inserted
computations survive into the second pass. The second pass removes them
50% of the time, which is what keeps the IR bounded across generations.

#### `--ir-nops`

Inserts 1–`nop_max_count` (default max = 3) `nop` opcodes at random
positions inside blocks. NOPs are cleaned up by `remove_nops` unless
gated off — but during a transform run the *second* pass runs at
50% probability, so some NOPs survive into codegen, where each one is
emitted as a single literal `0x90` byte.

```
// seed=1003 — three NOPs after the add()-call store
entry:
    t5 = 3
    t2 = 4
    t0 = add(t5, t2)
    nop
    nop
    nop
    *l0 = t0
    nop
    nop
    nop
    nop
    t3 = -7
    t6 = abs_val(t3)
    ...
```

#### `--ir-reorder-instrs`

Swaps adjacent independent instructions inside a basic block. Two
instructions are independent if neither reads what the other writes and
neither writes what the other writes (no RAW / WAR / WAW dependency).
The number of swap attempts per block is `reorder_instrs_intensity ×
block_length` (the intensity gene is in [1, 10]).

Visible swaps depend on the input — in `main()` above, every
instruction is dependent on its predecessor (load → store → load …),
so the transform mostly only renumbers temps. In `add()` it can swap
the two parameter loads:

```
// baseline                  // seed=42
int add(int arg0, int arg1)  int add(int arg0, int arg1)
  entry:                       entry:
    t0 = *arg0                   t1 = *arg1     ← swapped
    t1 = *arg1                   t0 = *arg0     ← swapped
    t2 = t0 + t1                 t2 = t0 + t1
    return t2                    return t2
```

#### `--ir-reorder-locals`

Permutes the index assignment of locals within a function. The locals
themselves and their stored values are preserved; only the slot numbers
change.

```
// baseline                       // seed=1001
int main() {                      int main() {
    int l0;                           int l0;
    int l1;                           int l1;
  entry:                            entry:
    t0 = 3                            t4 = 3
    t1 = 4                            t0 = 4
    t2 = add(t0, t1)                  t8 = add(t4, t0)
    *l0 = t2     ← sum into l0        *l1 = t8     ← sum now into l1
    ...                               ...
    t6 = abs_val(t5)                  t2 = abs_val(t3)
    *l1 = t6     ← n into l1          *l0 = t2     ← n now into l0
    t7 = *l0                          t9 = *l1
    t8 = *l1                          t7 = *l0
    t9 = t7 + t8                      t5 = t9 + t7
    return t9                         return t5
}                                 }
```

#### `--ir-reorder-blocks`

Shuffles non-entry blocks (the entry block always stays first) and
rewrites jumps to use the new positions. The branch targets are still
correct; only the file order of the blocks changes.

```
// baseline                       // seed=1002
int abs_val(int arg0) {           int abs_val(int arg0) {
  entry:                            entry:
    t1 = *arg0                       t2 = *arg0
    t3 = 0                           t5 = 0
    t0 = (t1 < t3)                   t4 = (t2 < t5)
    if (!t0) goto endif              if (!t4) goto endif
    goto then                        goto then
  then:                             endif:                  ← moved
    t4 = 0                            t6 = *arg0
    t5 = *arg0                        return t6
    t6 = t4 - t5                    then:                   ← moved
    return t6                         t3 = 0
    goto endif                        t0 = *arg0
  endif:                              t1 = t3 - t0
    t2 = *arg0                        return t1
    return t2                         goto endif
}                                 }
```

#### `--ir-reorder-funcs`

Shuffles the function table — both user functions and externs — and the
string table together, then remaps every function reference (call sites,
function pointers, dll/name indices) and every string-table index
(global initializers, string operands, function names, dll names).

```
// baseline string table     // seed=1001 — both tables rotated
str s0 = "add"               str s0 = "add"
str s1 = "abs_val"           str s1 = "endif"       ← shuffled
str s2 = "main"              str s2 = "abs_val"
str s3 = "entry"             str s3 = "entry"
str s4 = "then"              str s4 = "main"
str s5 = "endif"             str s5 = "then"

// Function order            // Function order
add → abs_val → main         abs_val → main → add
```

The well-known runtime externs (`malloc`, `free`, `read`, `write`,
`open`, `close`, `exit`) get shuffled alongside everything else; their
fixed API-slot positions (0–6) move with them, and the runtime resolver
finds them by name regardless of slot.

The **globals table** is also Fisher-Yates'd in the same pass: every
`VK_GLOBAL` operand in every instruction is remapped through the
resulting permutation. The recognizable sequence of small-integer
initializers do not land at a deterministic offset in `.data`, 
dropping the per-byte match probability across seeds to roughly `1/N` 
and defeating fixed-offset and sliding-window signature scanners. 
Globals that other code finds by `strcmp` on the name (e.g. `g_bundle_header`)
keep working, since the lookup is by name, not by index.

### Notes

- **`--ir-reorder-funcs`** also shuffles the well-known C-runtime externs
  (`malloc`, `free`, `read`, `write`, `open`, `close`, `exit`) — these
  occupy reserved API slots 0–6 when present — alongside any user
  externs, plus the entire **string table** and the **globals table**.
  Both backends do this and produce equivalent bytes despite the very
  different shuffle implementations:
  - C backend: Fisher-Yates on the API slot indices, full permutation
    remap of every name/dll reference plus a Fisher-Yates on the string
    table and a Fisher-Yates on the globals table (with every
    `VK_GLOBAL` operand remapped).
  - MC backend: triple-reverse rotation with modular arithmetic remap,
    matching the C backend's output by construction.
  The shuffle propagates through self-recompilation generations: a gen0
  shuffled by the C backend stays shuffled when the MC backend
  recompiles it.

- **Optimization is two-pass.** First pass cleans (`remove_nops` +
  `remove_dead_code`); this preserves the work of unfold/substitute. A
  second stochastic pass folds constants at 50% probability, giving
  generations a natural equilibrium where unfolded constants slowly fold
  back and re-unfold elsewhere.

## x86 transforms

These run during x86 emission. CLI flags:

| Flag | Gene bit | Description |
|---|---|---|
| `--x86-poly-instrs` | 9 | Polymorphic instruction encoding — pick from equivalent `MOV` / `ADD` / `SUB` / `XOR` byte sequences, shuffle register selection. |
| `--x86-dead-code` | 10 | Emit dead bytes between blocks and between instructions. |
| `--x86-opaque` | 11 | Insert opaque predicates — branches that always go one way but appear conditional. |
| `--x86-junk-funcs` | 12 | Generate plausible-looking junk functions and call them. |
| `--x86-harmless-calls` | 13 | Insert calls to harmless platform APIs (e.g. `GetTickCount`). |
| `--x86-shuffle-funcs` | 14 | Shuffle function layout in the binary. |

### Polymorphic instruction encoding

`--x86-poly-instrs` covers five op families. Each family has a fixed,
finite set of equivalent encodings, and the emitter draws one per site
weighted by the corresponding gene vector (`add_weights`, `sub_weights`,
`movi_weights`, `xor_weights`, `cmp_weights` — each sums to ~1000).
Definitions live in `backend_mystc.c:emit_<op>_v<N>` and the dispatcher
`emit_<op>_poly()`.

All disassemblies below are taken from real backend output, produced
by forcing one variant to weight 990 and the rest to 1, then compiling

```c
int op(int x, int y) { ... a = x + y; ... }
```

at `--seed 1001`. In every snippet the inputs are loaded into
`ECX` (= `src1`) and `EDI` (= `src2`), and the result is left in `ECX`
(= `dst`).

**ADD `dst = src1 + src2`** — 5 variants (`emit_add_v0`..`v4`):

| Variant | Sequence | Real disassembly (`src1=ECX`, `src2=EDI`, `dst=ECX`) |
|---|---|---|
| 0 | `MOV dst, src1` (if needed)<br>`ADD dst, src2` | `ADD ECX, EDI` |
| 1 | `LEA dst, [src1 + src2]` | `LEA ECX, [ECX+EDI]` |
| 2 | `MOV scratch, src2`<br>`NEG scratch`<br>`MOV dst, src1` (if needed)<br>`SUB dst, scratch` | `MOV EDX, EDI`<br>`NEG EDX`<br>`SUB ECX, EDX` |
| 3 | `PUSH src1`<br>`ADD [esp], src2`<br>`POP dst` | `PUSH ECX`<br>`ADD [ESP], EDI`<br>`POP ECX` |
| 4 | half-adder:<br>`MOV scratch, src1`<br>`AND scratch, src2`<br>`MOV dst, src1`<br>`XOR dst, src2`<br>`ADD scratch, scratch`<br>`ADD dst, scratch` | `MOV EDX, ECX`<br>`AND EDX, EDI`<br>`XOR ECX, EDI`<br>`ADD EDX, EDX`<br>`ADD ECX, EDX` |

**SUB `dst = src1 - src2`** — 4 variants (`emit_sub_v0`..`v3`):

| Variant | Sequence | Real disassembly (`src1=ECX`, `src2=EDI`, `dst=ECX`) |
|---|---|---|
| 0 | `MOV dst, src1`<br>`SUB dst, src2` | `SUB ECX, EDI` |
| 1 | `MOV scratch, src2`<br>`NEG scratch`<br>`MOV dst, src1`<br>`ADD dst, scratch` | `MOV EDX, EDI`<br>`NEG EDX`<br>`ADD ECX, EDX` |
| 2 | `PUSH src1`<br>`SUB [esp], src2`<br>`POP dst` | `PUSH ECX`<br>`SUB [ESP], EDI`<br>`POP ECX` |
| 3 | two's-complement:<br>`MOV scratch, src2`<br>`NOT scratch`<br>`MOV dst, src1`<br>`ADD dst, scratch`<br>`INC dst` | `MOV EDX, EDI`<br>`NOT EDX`<br>`ADD ECX, EDX`<br>`INC ECX` |

**MOV-immediate `dst = imm`** — special-cased on `imm == 0` and `imm == -1`,
otherwise 6 general variants (`emit_movi_v0`..`v5`). Examples below use
`dst = EAX` and `imm = 12345` (`0x3039`); `~12345 = 0xFFFFCFC6`,
`-12345 = 0xFFFFCFC7`:

| Variant | Sequence | Real disassembly (`dst = EAX`) |
|---|---|---|
| 0 | `MOV dst, imm` (B8+r id) | `MOV EAX, 0x00003039` |
| 1 | `XOR dst, dst`<br>`ADD dst, imm` | `XOR EAX, EAX`<br>`ADD EAX, 0x00003039` |
| 2 | `PUSH imm`<br>`POP dst` | `PUSH 0x00003039`<br>`POP EAX` |
| 3 | `XOR dst, dst`<br>`LEA dst, [dst + imm]` | `XOR EAX, EAX`<br>`LEA EAX, [EAX+12345]` |
| 4 | `MOV dst, ~imm`<br>`NOT dst` | `MOV EAX, 0xFFFFCFC6`<br>`NOT EAX` |
| 5 | `XOR dst, dst`<br>`SUB dst, -imm` | `XOR EAX, EAX`<br>`SUB EAX, 0xFFFFCFC7` |

For `imm == 0` the menu is `XOR dst, dst` / `SUB dst, dst` / `MOV dst, 0`
(weights `movi_zero_weights`):

| Variant | Sequence | Real disassembly (`dst = EAX`) |
|---|---|---|
| 0 | `XOR dst, dst` | `XOR EAX, EAX` |
| 1 | `SUB dst, dst` | `SUB EAX, EAX` |
| 2 | `MOV dst, 0` | `MOV EAX, 0x00000000` |

For `imm == -1` the menu is `XOR; DEC` / `XOR; NOT` / `MOV dst, -1`
(weights `movi_neg1_weights`):

| Variant | Sequence | Real disassembly (`dst = ECX`) |
|---|---|---|
| 0 | `XOR dst, dst`<br>`DEC dst` | `XOR ECX, ECX`<br>`DEC ECX` |
| 1 | `XOR dst, dst`<br>`NOT dst` | `XOR ECX, ECX`<br>`NOT ECX` |
| 2 | `MOV dst, -1` | `MOV ECX, 0xFFFFFFFF` |

In practice the frontend lowers `int x = -1;` to `neg(const 1)`, so
this `imm == -1` menu is dormant in current pipelines and ships only as a
specialization for IR rewriters that *do* produce constant `-1` operands.

**XOR `dst = src1 ^ src2`** — 3 variants (`emit_xor_v0`..`v2`).
Same calling convention as ADD (`src1=ECX`, `src2=EDI`, `dst=ECX`).
Variant 2 uses the identity `a^b = (a|b) & ~(a&b)`.

| Variant | Sequence | Real disassembly |
|---|---|---|
| 0 | `MOV dst, src1`<br>`XOR dst, src2` | `XOR ECX, EDI` |
| 1 | `PUSH src1`<br>`XOR [esp], src2`<br>`POP dst` | `PUSH ECX`<br>`XOR [ESP], EDI`<br>`POP ECX` |
| 2 | `MOV s1, src1`<br>`OR s1, src2`<br>`MOV s2, src1`<br>`AND s2, src2`<br>`NOT s2`<br>`MOV dst, s1`<br>`AND dst, s2` | `MOV EDX, ECX`<br>`OR EDX, EDI`<br>`MOV ESI, ECX`<br>`AND ESI, EDI`<br>`NOT ESI`<br>`MOV ECX, EDX`<br>`AND ECX, ESI` |

**CMP `r1, r2`** — 2 variants (`emit_cmp_poly`); `r1=ECX`, `r2=EDI`.
Variant 1 substitutes `SUB`, which sets the same flags as `CMP`.

| Variant | Sequence | Real disassembly |
|---|---|---|
| 0 | `CMP r1, r2` | `CMP ECX, EDI` |
| 1 | `MOV scratch, r1`<br>`SUB scratch, r2` | `MOV EDX, ECX`<br>`SUB EDX, EDI` |

Anything else (MUL, DIV, MOD, SHL, SHR, AND, OR, NOT, NEG, loads,
stores, calls, jumps, prologues/epilogues) has a single canonical
encoding and is *not* polymorphed at this layer — diversity
for those comes from register selection (`--ir-reorder-locals`,
PRNG-shuffled regalloc), interleaved dead code, and the IR-level
transforms above.

### Dead code patterns

`--x86-dead-code` inserts plausible-looking instruction sequences
between real code, drawn from a fixed menu of 8 patterns
(`backend_mystc.c:emit_junk_sequence`; weights `junk_seq_weights`):

Real disassemblies below come from forcing `junk_seq_weights` to peak
at one variant and capturing the first dead-code site after the
prologue of `add()` in the baseline program. The exact registers,
immediates, and stack offsets each pattern picks are PRNG-driven, so
re-running with a different seed gives a different concrete instance
of the same shape.

| Pattern | Shape | Real disassembly | Looks like |
|---|---|---|---|
| 0 | `MOV free, any`<br>`ADD free, imm` | `MOV EDX, EBX`<br>`ADD EDX, 0x0000005B` | address calculation |
| 1 | `MOV free, any`<br>`XOR free, imm`<br>`ADD free, any2` | `MOV EDX, EBX`<br>`XOR EDX, 0x0000005B`<br>`ADD EDX, EAX` | hash computation |
| 2 | `LEA free, [any + imm]` | `LEA EDX, [EBX+91]` | pointer arithmetic |
| 3 | `PUSH any`<br>`MOV any, imm`<br>`ADD any, imm`<br>`POP any` | `PUSH EBX`<br>`MOV EBX, 0x0000005B`<br>`ADD EBX, 0x00000051`<br>`POP EBX` | save / compute / restore |
| 4 | `MOV free, any`<br>`IMUL free, any`<br>`ADD free, imm` | `MOV EDX, EBX`<br>`IMUL EDX, EBX`<br>`ADD EDX, 0x0000005B` | multiply-accumulate |
| 5 | `MOV free, imm`<br>`CMP free, any`<br>`Jcc`<br>`MOV free, 0/1` | `MOV EDX, 0x0000005B`<br>`CMP EDX, EBX`<br>`MOV EDX, 0x00000000`<br>`JL SHORT 0x0031`<br>`MOV EDX, 0x00000001` | compare + conditional set |
| 6 | `XOR free, free`<br>`ADD free, any`<br>`SUB free, imm` | `XOR EDX, EDX`<br>`ADD EDX, EBX`<br>`SUB EDX, 0x0000005B` | zero + accumulate |
| 7 | `MOV free, [EBP - off]`<br>`ADD free, imm` | `MOV EDX, [EBP-20]`<br>`ADD EDX, 0x0000005B` | stack-variable read |

Each invocation emits one pattern (~8 bytes); `insert_dead_code(max_bytes)`
loops until budget is consumed. All patterns are RA-aware: they only
write to registers the allocator currently has free, so they never
clobber a live value.

### Opaque predicate forms

`--x86-opaque` wraps real basic blocks in `if (always_true) { real_code; }
else { junk; }` structures. The "always-true" predicate is built from a
value the backend can prove constant but a static analyzer typically
cannot — 3 forms (`backend_mystc.c:emit_opaque_true`; weights
`opaque_weights`):

Why each predicate is always true:

- **Variant 0**: the product of two consecutive integers is always even.
- **Variant 1**: a square is always non-negative (the signed `JGE` after `IMUL`).
- **Variant 2**: OR-with-1 sets the LSB, so the result is never zero.

Real disassemblies below were forced via `opaque_pct = 100` plus a
weight vector pinned to one variant, captured at the entry of `add()`
in the baseline program. The `JE`/`JGE`/`JNE` at the end of each
variant is the live-path branch; the fall-through arm holds a short
junk-code block (any of the eight patterns above) so a static analyzer
must consider both arms reachable.

| Variant | Predicate | Real disassembly |
|---|---|---|
| 0 | `(x * (x+1)) & 1 == 0` | `MOV EDX, 0x0000005F`<br>`MOV ESI, EDX`<br>`INC ESI`<br>`IMUL EDX, ESI`<br>`AND EDX, 0x00000001`<br>`TEST EDX, EDX`<br>`JE 0x00B4` |
| 1 | `(x * x) >= 0` | `MOV EDX, 0x0000002D`<br>`IMUL EDX, EDX`<br>`CMP EDX, 0x00000000`<br>`JGE 0x00AF` |
| 2 | `(x \| 1) != 0` | `MOV EDX, 0x0000005F`<br>`OR EDX, 0x00000001`<br>`TEST EDX, EDX`<br>`JNE 0x00AE` |

### Junk functions

`--x86-junk-funcs` synthesizes complete plausible-looking functions in
the binary that are never called from real code — only from
`--x86-junk-funcs`-generated `CALL rel32` sites scattered through real
functions. Each junk function (`backend_mystc.c:gen_junk_function`):

- Has a real prologue (`PUSH EBP; MOV EBP, ESP; SUB ESP, 16; PUSH EBX/ESI/EDI`).
- Body is 5–15 instructions chosen uniformly from 8 instruction classes:
  `MOV r,imm`, `ADD r,r`, `XOR r,imm`, `MOV [EBP-slot], r`, `MOV r, [EBP-slot]`,
  `CMP r,imm`, `IMUL r,r`, `SUB r,imm`.
- If `--x86-harmless-calls` is also on, a real harmless API call is
  inserted at the midpoint.
- Returns a random `MOV EAX, imm`.
- Has a real epilogue (`POP EDI/ESI/EBX; MOV ESP, EBP; POP EBP; RET`).

The number of junk functions is `junk_func_pct` of the real function
count (clamped 0–200). Calls to them are inserted at block boundaries
(`junk_call_block_pct`) and between instructions (`junk_call_instr_pct`).

A real junk function from the baseline program compiled with just
`--x86-junk-funcs --seed 99`:

```
0186: 55                    PUSH EBP              ; ─┐ prologue
0187: 89 E5                 MOV EBP, ESP          ;  │
0189: 81 EC 10 00 00 00     SUB ESP, 0x00000010   ;  │ 16-byte frame
018F: 53                    PUSH EBX              ;  │
0190: 56                    PUSH ESI              ;  │
0191: 57                    PUSH EDI              ; ─┘
0192: 0F AF C1              IMUL EAX, ECX         ; ─┐ body — 6 ops
0195: 81 EA 6B 60 00 00     SUB EDX, 0x0000606B   ;  │
019B: 8B 95 F4 FF FF FF     MOV EDX, [EBP-12]     ;  │ stack-slot read
01A1: BA A7 02 00 00        MOV EDX, 0x000002A7   ;  │
01A6: BA 8F 32 00 00        MOV EDX, 0x0000328F   ;  │
01AB: 81 F2 8F D4 00 00     XOR EDX, 0x0000D48F   ; ─┘
01B1: B8 2F 8A 00 00        MOV EAX, 0x00008A2F   ;     random return value
01B6: 5F                    POP EDI               ; ─┐ epilogue
01B7: 5E                    POP ESI               ;  │
01B8: 5B                    POP EBX               ;  │
01B9: 89 EC                 MOV ESP, EBP          ;  │
01BB: 5D                    POP EBP               ;  │
01BC: C3                    RET                   ; ─┘
```

With `--x86-harmless-calls` added, the body is split around a real
indirect call through the API table (PIC mode shown — the
`CALL $+5 / POP / SUB` triplet is the standard PIC PC fetch):

```
4A68: 55                       PUSH EBP                 ; prologue
4A69: 89 E5                    MOV EBP, ESP
4A6B: 81 EC 10 00 00 00        SUB ESP, 0x00000010
4A71: 53                       PUSH EBX
4A72: 56                       PUSH ESI
4A73: 57                       PUSH EDI
4A74: 81 F8 CA 36 00 00        CMP EAX, 0x000036CA      ; body before call
4A7A: 89 85 FC FF FF FF        MOV [EBP-4], EAX
4A80: 53                       PUSH EBX                 ; ─┐ save caller regs
4A81: 50                       PUSH EAX                 ;  │
4A82: 51                       PUSH ECX                 ;  │
4A83: 52                       PUSH EDX                 ; ─┘
4A84: E8 00 00 00 00           CALL 0x4A89              ; ─┐ PIC PC fetch
4A89: 5B                       POP EBX                  ;  │
4A8A: 81 EB 89 4A 00 00        SUB EBX, 0x00004A89      ; ─┘ EBX = image base
4A90: 8B 83 02 00 00 00        MOV EAX, [EBX+2]         ; EAX = API table ptr
4A96: 8B 80 70 00 00 00        MOV EAX, [EAX+112]       ; pick a harmless slot
4A9C: 50                       PUSH EAX
4A9D: 8B 84 24 00 00 00 00     MOV EAX, [ESP]
4AA4: FF D0                    CALL EAX                 ; real API call
4AA6: 81 C4 04 00 00 00        ADD ESP, 0x00000004
4AAC: 5A                       POP EDX                  ; ─┐ restore caller regs
4AAD: 59                       POP ECX                  ;  │
4AAE: 58                       POP EAX                  ;  │
4AAF: 5B                       POP EBX                  ; ─┘
4AB0: 89 85 F8 FF FF FF        MOV [EBP-8], EAX         ; ─┐ body after call
4AB6: 81 F9 60 EB 00 00        CMP ECX, 0x0000EB60      ;  │
4ABC: 8B 85 FC FF FF FF        MOV EAX, [EBP-4]         ; ─┘
4AC2: B8 02 FE 00 00           MOV EAX, 0x0000FE02      ; random return value
4AC7: 5F                       POP EDI                  ; ─┐ epilogue
4AC8: 5E                       POP ESI                  ;  │
4AC9: 5B                       POP EBX                  ;  │
4ACA: 89 EC                    MOV ESP, EBP             ;  │
4ACC: 5D                       POP EBP                  ;  │
4ACD: C3                       RET                      ; ─┘
```

The API slot index (here `+112` into the resolved table) is one of the
harmless externs auto-detected from the source's `extern` declarations
(see [Harmless calls](#harmless-calls) below). To a disassembler or
static analyzer, the function is indistinguishable from a real
function that wraps a real API call.

### Harmless calls

`--x86-harmless-calls` inserts calls to APIs whose return values are
ignored. The set is **auto-detected**: any 0-parameter `extern`
declaration whose `dll_name` matches the platform's standard library
qualifies — `kernel32.dll` on Windows, `libc.so.6` on Linux
(`backend_mystc.c:is_harmless_extern`).

Examples that qualify if declared:

```c
extern "kernel32.dll" int GetTickCount();
extern "kernel32.dll" int GetCurrentProcessId();
extern "kernel32.dll" int GetCurrentThreadId();

extern int getpid();                  // libc.so.6 on Linux
extern int gettid();
```

To add a new harmless API, declare it as a **zero-parameter** `extern`
with the platform's `dll_name` (`kernel32.dll` on Windows,
`libc.so.6` on Linux) at the top of the program — no other changes
needed. Externs that take arguments are *not* auto-detected; the
backend can't synthesize valid argument values, so it skips them. The
buffer of harmless slots is sized dynamically (two-pass
count-then-allocate), so any number of qualifying externs works.

### Function shuffling

`--x86-shuffle-funcs` permutes the order in which functions are laid out
in the code segment. Internal `CALL rel32` displacements are recomputed
after the layout decision. There are no variants here — it's a single
pass that Fisher-Yates-shuffles the function order then re-emits.
Combined with `--ir-reorder-funcs` (which shuffles the *logical*
function order plus the string and extern tables), gen-to-gen binary
layouts diverge visibly.

## Combining transforms

In practice you turn most or all of them on at once:

```bash
backend_mystc.exe in.mcb --pic out.bin \
    --ir-unfold --ir-substitute --ir-deadcode --ir-nops \
    --ir-reorder-instrs --ir-reorder-locals --ir-reorder-blocks --ir-reorder-funcs \
    --x86-poly-instrs --x86-dead-code --x86-opaque --x86-junk-funcs \
    --x86-harmless-calls --x86-shuffle-funcs \
    --seed $RANDOM
```

The IDE's "All Transforms" preset enables this same set. With all
transforms on, the same source produces a different `.bin` byte-by-byte
on every seed, with bin entropy typically rising from ~6.0 bits (no
transforms) to ~7.5 bits (all transforms).

## Determinism

Every transform is seeded by the same PRNG stream as the rest of the
backend, so a given `(seed, genome, transforms)` triple produces
bit-exact output. Tests in `tests/backend/` exercise:

- IR transforms — `test_transforms_ir.py`.
- x86 transforms — `test_transforms_x86.py`.
- Combinations — `test_transforms_combo.py`.
- Determinism — `test_determinism.py`.
- Output format wiring — `test_output_formats.py`.
- Register allocator — `test_regalloc.py`.
- Smoke / sanity — `test_basic.py`.

C↔MC backend equivalence is exercised inside `test_determinism.py` and
the e2e suite, not as a separate file.

## Genome gating

After CLI flag processing, the backend ANDs each enabled transform with
the corresponding bit of `genome.expression_flags`. A flag enables a
transform; the genome decides whether *this* generation actually fires
it. The mutation algorithm flips bits in `expression_flags` and adjusts
the per-transform probability genes, so each generation has a different
"personality." See [Genome](genome.md) for details.

## Adding a new transform

To add a new transform end-to-end:

1. **Pick a gene bit.** `expression_flags` is 15 bits wide; the
   existing transforms use bits 0–14. Add a bit, document it in
   [Genome](genome.md).
2. **Write the IR or x86 pass.** IR transforms live in
   `compiler/backend/backend_mystc.mc:transform_module()`; x86-emit
   transforms hook directly into the per-block / per-instruction
   loops in `gen_function()` / `gen_block()` (see how
   `dead_code`, `opaque`, `harmless_calls` are interleaved there).
3. **Add the CLI flag.** Both `backend_mystc.c` and
   `backend_mystc.mc` need to parse it and gate the transform on
   both the flag and the gene bit.
4. **Add a test.** `tests/backend/test_transform_<your_name>.py`
   should run the transform against a small program, verify
   determinism (same seed → same bytes), and verify equivalence
   (transformed program produces same return code as untransformed).

Both backends must agree byte-for-byte. The C backend bootstraps the
MC backend — if they diverge, a single self-recompilation round-trip
breaks. The `test_c_vs_mc_backend_*` cases in
`tests/backend/test_determinism.py` are the wall.
