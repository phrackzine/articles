# IDE

A small Flask web application that wraps the compiler. Useful for
exploring transforms interactively, comparing variants, and watching a
self-recompilation chain evolve.

```bash
cd ide && python server.py
# → http://localhost:5000
```

Source: `ide/`. Five view tabs: **Editor**, **Transforms**, **Variants**,
**Evolution**, **Diff**.

## Layout

```
ide/
├── server.py          Flask routes — /api/compile, /api/evolve, /api/project/*, /api/capabilities
├── bridge.py          CompilerBridge — drives mystcc, backend_mystc.exe, disasm.py
├── requirements.txt   flask
├── run.bat            Windows launcher
└── static/
    ├── index.html     5-view shell
    ├── style.css      dark theme
    └── app.js         client logic, fetches, view rendering
```

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | Static `index.html`. |
| GET | `/<filename>` | Static asset (CSS, JS, fonts). |
| GET | `/api/capabilities` | Per-platform availability of each output format. |
| GET | `/api/cwd` | Server-side current working directory (for the file picker). |
| POST | `/api/compile` | Compile source to IR + N x86 variants. |
| POST | `/api/evolve` | Run N self-recompiling generations of a payload. |
| POST | `/api/project/create` | Create a project directory + `mystique.json`. |
| POST | `/api/project/open` | Open an existing project. |
| POST | `/api/project/save` | Save project config + source. |
| POST | `/api/project/list-dir` | Browse server-side directories. |

## Capabilities & projects

`/api/capabilities` reports which output kinds are available for each
target platform, based on whether the backend exe and the carrier `.mcb`
files exist on disk:

```json
{
  "outputs": {
    "win32": { "pic": true, "standalone": true,
               "recompiler": true, "infector": true, "integrator": true },
    "linux": { "pic": true, "standalone": true,
               "recompiler": true, "infector": true, "integrator": true }
  }
}
```

**Projects** are local directories created by `/api/project/create`.
Layout:

```
my_project/
├── mystique.json          target_platform, output_formats, strip_debug,
│                          scramble_globals, ...
├── source.mc              the user's .mc source
├── win32/
│   ├── payload.mcb        compiled IR for the project
│   └── variant_0/         per-variant outputs
│       ├── variant_0.bin
│       ├── variant_0.exe
│       ├── variant_0_recompiler.exe
│       ├── variant_0_infector.exe
│       ├── variant_0_integrator.exe
│       ├── variant_0_ir.mce
│       └── genome.json
└── linux/                 mirror of win32/, with ELF outputs
```

The platform subdirs let a single project produce both Win32 and Linux
artifacts side-by-side.

## CompilerBridge (`bridge.py`)

The bridge is what the routes actually talk to. Public methods:

- `compile_to_ir(source, platform, strip_debug)` — `.mc` → `.mcb` via the
  Python frontend. Returns the path to a temp `.mcb`.
- `compile_variants(source, n, …)` — for each of N variants, produce
  IR + a polymorphic `.bin` + disassembly + sha256 + entropy. Used by
  the **Variants** view.
- `compile_with_outputs(mc_path, project_dir, output_formats, …)` —
  produce all 5 output kinds for one variant: PIC, standalone, recompiler
  (bundle flag), infector (bundle flag), integrator (bundle flag).
- `compile_entry_mcb(platform, strip_debug)` — fresh per-platform compile
  of `bundles/integrators/integrator_entry.mc`. Used to feed the
  integrator bundle flag with a strip-debug-aware carrier; staged into a
  temp `bundles_dir` for the `--integrator-{pe,elf}` invocation.
- `run_generations(source, count, …)` — full self-recompiling chain run
  driven by the recompiler binary. Used by the **Evolution** view (which
  the `/api/evolve` route fronts).
- `diff_variants(hex_a, hex_b)` — byte-level diff between two compiled
  variants; used by the **Diff** view.

The bridge always uses absolute paths and never assumes a particular cwd.

## Views

**Editor.** Plain text editor for `.mc` source plus a console panel
showing compiler stdout/stderr.

**Transforms.** Per-transform toggles, per-gene sliders for the genome,
temperature controls. Changes propagate to the next compile.

**Variants.** Compiles N variants with different seeds (or generationally
chained), shows each variant's IR, disassembly, and a byte heatmap. SHA-256
and Shannon entropy reported per variant.

**Evolution.** Runs the recompiler binary for N generations, shows
genome drift and binary divergence over time. Useful for sanity-checking
that mutation actually moves the genome around without breaking output.

**Diff.** Byte-level pairwise comparison between two variants — common
runs, divergent runs, n-gram statistics, a verdict (compatible / different
/ structurally identical) and a heatmap.

## Compile & evolve flow

`/api/compile` body:

```json
{
  "source": "...",
  "n_variants": 2,
  "seed": 1001,                     // optional
  "per_variant": [
    { "transform_flags": [...], "genome": {...} }
  ],
  "generational": false,
  "mutate_genome": false,
  "ir_format": "mce",               // "mce" or "mct"
  "output_formats": {...},          // optional; per-output enable/disable
  "project_dir": "...",             // optional; when set, writes per-variant outputs
  "target_platform": "win32",       // win32 or linux
  "strip_debug": false,
  "scramble_globals": false
}
```

Response shape:

```json
{
  "mct": "...",                     // base IR text
  "mce": "...",                     // base extended IR text
  "ir": { "...": "..." },
  "variants": [
    { "bin_hex": "...",
      "sha256": "...",
      "entropy": 7.42,
      "disasm": [...],
      "annotations": {...},
      "fn_name_map": {...} },
    ...
  ]
}
```

When `project_dir` is set, the server also writes per-variant artifacts
under `<project_dir>/<platform>/variant_N/`, including the IR text,
genome JSON, and (if `output_formats` is provided) every requested binary
output kind.

## strip_debug

`strip_debug = true` runs the frontend's `strip_debug.py` pass before IR
generation, removing calls to `print*` / `t_print*` debug builtins. It's
exposed in the IDE because integrator/recompiler outputs are typically
shipped without debug noise. The bridge propagates the flag through to
`compile_entry_mcb` so the integrator's entry preloader is also stripped.

## scramble_globals

`scramble_globals = true` runs the frontend's `scramble.py` pass after
IR generation. Integer-literal global initializers are demoted into a
generated `__init_globals()` function and each initializer's `.data`
slot is overwritten with `crc32(name)` (signed-i32); a `CALLV` to
`__init_globals` is spliced into the head of `main` so the real values
are restored at runtime. Defeats fixed-offset signatures over the
`.data` init-value sequence (small-int magic, `GI_*` constants, etc.).
Like `strip_debug`, the bridge threads the flag through to
`compile_entry_mcb` so the integrator's entry preloader is scrambled
the same way as the user's program.

## Tooltips & polish

The IDE uses inline `(i)` icons for tooltips on every transform toggle,
output checkbox, and gene slider. Hover any icon for a one-sentence
explanation; longer help is in this documentation.
