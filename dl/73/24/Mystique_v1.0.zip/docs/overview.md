# Overview

**Mystique** is a polymorphic, metamorphic (self-hosting), and evolutionary cross-compiler.
It compiles **MystC** (a small C subset) into x86-32 code.
Four properties make it unusual:

- **Polymorphic.** Every compilation of the same input produces a *different*
  byte sequence with identical runtime behavior. Variation is driven by different register and instruction selection, dead-code insertion, function shuffling, and more. 
- **Metamorphic.** The compiler's backend is self-hosting, written in MystC itself. The C backend (`compiler/backend/backend_mystc.c`) bootstraps a generation-zero MC
  backend (`backend_mystc.mc`); from then on the MC backend can compile
  itself, and be used to build self-recompiling metamorphic applications.
- **Evolutionary.** Each new generation inherits a mutated copy of its
  parent's "genome", so child binaries don't just look different — they
  *prefer* different transforms. 
- **Cross-Compiler**. From either Windows or Linux, it can
emit Win32 PE32 (kernel32 imports), Linux ELF32, or platform-agnostic PIC shellcode.


Mystique is the realization of a project I wanted to create for about 20 years. It was supposed to combine the best ideas and techniques of the turn-of-the-20th-century Metamorphic viruses into one engine, namely The Metnal Driller's MetaPHOR, Vecna's Lexotan32, Z0mbie's Mistfall and herm1t's Lacrimae. I tried to implement it several times over a few years, but never got to finish. When coding agents arrived, I decided to give it another shot.

Mystique is intended for use in **security research, AV/EDR
detection-engine testing, and metamorphic-code research**, and doubles
as a worked example of a self-hosting cross-compiler and a sandbox
for genetic-programming experiments on code generation. Polymorphism
and evolution are driven by a 65-gene **genome** — a small binary
record of transform probabilities, weight vectors, and an
`expression_flags` bitmask, which mutates between generations under a
temperature-controlled random walk. A compiled binary can carry its own complete compiler, decrypt and mutate its genome at runtime, then
recompile itself into a different next generation — meaning the
program *is* its own next-generation toolchain.

## Pipeline at a glance

```
  MystC source                   MystC Bytecode 
                           Intermediate Representation     
                           
                ┌────────────┐                  ┌────────────┐
    code.mc ───►│  Frontend  │───► code.mcb ───►│  Backend   │───► .bin
                │  (Python)  │                  │ (C or MC)  │      pe
                └────────────┘                  └────────────┘      elf
                deterministic                    polymorphic
```

The **frontend** lexes, parses, and lowers MystC into an
**IR — Intermediate Representation**: three-address code organized
into functions and basic blocks, serialized to an **`.mcb` (MystC
Bytecode)** file. This is the stable boundary — the same source
always produces the same `.mcb`. The **backend** then turns `.mcb`
into x86 bytes, and *this* is where the genome and the seeded PRNG
decide encodings, register order, junk insertion, and so on. Same
`.mcb` + different `(seed, genome)` = different bytes, same behavior.

## A walking example

Here is the whole pipeline on one tiny program.

### 1. Source — `example.mc`

```c
int main() {
    int a;
    int b;
    a = 5 * 7;
    b = a + 3;
    return b;
}
```

### 2. Frontend — `.mc` → `.mcb`

```bash
python -m compiler.frontend.mystcc example.mc -o example.mcb \
    --expr example.mce
```

`example.mcb` is the IR in binary form; `example.mce` is the same IR
in expression-style text:

```
str s0 = "main"
str s1 = "entry"

int main() {
    int l0;
    int l1;

  entry:
    t0 = 5
    t1 = 7
    t2 = t0 * t1
    *l0 = t2
    t3 = *l0
    t4 = 3
    t5 = t3 + t4
    *l1 = t5
    t6 = *l1
    return t6
}
```

Three-address code: every operation produces a new temporary `t<N>`,
with explicit loads and stores into the locals `l0` (`a`) and `l1`
(`b`). No machine concerns yet — no registers, no stack, no encoding
choices. The frontend is **deterministic**: the same `.mc` always
produces the same `.mcb`.

### 3. Backend — `.mcb` → `.bin`, twice

Now invoke the backend twice with the **same** `.mcb` and the **same**
transform flag (`--x86-poly-instrs`), but two different seeds:

```bash
backend_mystc.exe example.mcb --pic example_s1.bin --x86-poly-instrs --seed 1
backend_mystc.exe example.mcb --pic example_s7.bin --x86-poly-instrs --seed 7
```

Disassembling the `5 * 7` core of each shows the polymorphism — same
operation, different encodings:

```
;; --- example_s1.bin (seed 1) ---
BE FA FF FF FF        MOV  ESI, 0xFFFFFFFA   ; 5 = NOT(-6)
F7 D6                 NOT  ESI
B8 07 00 00 00        MOV  EAX, 0x7          ; 7
89 F1                 MOV  ECX, ESI
0F AF C8              IMUL ECX, EAX          ; 5 * 7 = 35

;; --- example_s7.bin (seed 7) ---
BF 05 00 00 00        MOV  EDI, 0x5          ; 5
68 07 00 00 00        PUSH 0x7               ; 7 via push/pop
59                    POP  ECX
89 FA                 MOV  EDX, EDI
0F AF D1              IMUL EDX, ECX          ; 5 * 7 = 35
```

Both compute `5 * 7 = 35`, but seed 1 materializes `5` via
`MOV ~(-6); NOT` (the bit-flipped form) and seed 7 plain-MOVs `5` then
loads `7` through a `PUSH`/`POP`. Different encodings, different
register selections, identical result. Run either through the loader
and it returns 38:

```bash
compiler/loaders/loader_win32.exe example_s1.bin
echo %ERRORLEVEL%               # → 38
compiler/loaders/loader_win32.exe example_s7.bin
echo %ERRORLEVEL%               # → 38
```

This is **polymorphism at the x86 layer.**

### 4. IR-level transforms

The backend can also rewrite the IR itself. With
`--transform-ir post.mcb` plus IR-level transforms:

```bash
backend_mystc.exe example.mcb --transform-ir example_post.mcb \
    --ir-unfold --ir-substitute --ir-deadcode --seed 11
```

Comparing the IR before and after:

```
Original IR             Post-transform IR
-----------             -----------------
t0 = 5                  t4  = 5
t1 = 7                  t0  = 7
t2 = t0 * t1            t5  = t4 * t0
*l0 = t2                *l0 = t5
t3 = *l0                t6  = *l0
                        nop
                        nop
                        t10 = 37600         ; deadcode
                        t3  = t10 ^ t10     ; substituted 0
t4 = 3                  t8  = 3
t5 = t3 + t4            t1  = t6 + t8
*l1 = t5                *l1 = t1
t6 = *l1                t7  = *l1
return t6               return t7
```

Every observable value is identical — the program still returns 38 —
but the IR has acquired NOPs, dead constants, and a substituted form
where a `0` was rewritten as `37600 ^ 37600`. Re-running x86 codegen
on this rewritten IR produces yet another visibly different `.bin`.
This is **polymorphism at the IR layer.**

The same `(seed, genome, transforms)` triple always reproduces the
exact same bytes. Change any one of them and the output changes
predictably. See [Transforms](transforms.md) for the full menu.

### 5. Standalone PE / ELF

A `.bin` carries Mystique's own header and an `extern_info` table
listing every imported name, but those formats are private to the
project — the OS doesn't know how to load them. That's why step 3
ran each `.bin` through `loader_win32.exe`: the loader parses the
header, resolves the named externs against an API table (kernel32
APIs and a few stdlib wrappers), maps the code into RWX memory, and
jumps in.

For cases where you don't want a separate loader, the backend can
emit fully-formed Win32 PE32 or Linux ELF32 executables that the OS
loads directly, with a real PE import table (PE) or syscall wrappers
(ELF) baked in. The exact same `example.mcb` from step 2 — no source
changes, no stdlib — goes straight in:

```bash
# Windows: real PE32 with a kernel32 IAT
backend_mystc.exe example.mcb --pe-standalone example.exe
example.exe & echo %ERRORLEVEL%                      # → 38

# Linux: ELF32 with INT 0x80 syscall wrappers
backend_mystc.exe example.mcb --elf-standalone example.elf
chmod +x example.elf && ./example.elf; echo $?       # → 38
```

The backend's standalone writers inject the entry plumbing
themselves: for ELF, a small `_start` stub (`xor ebp,ebp; call main;
mov ebx,eax; mov eax,1; int 0x80`) propagates `main`'s return value
through `sys_exit`; for PE, `main` *is* the PE entry, and the OS
terminates the thread with `EAX` as the exit code when `main`
returns.

This same machinery also packages higher-level applications via bundle
carrier flags (`--recompiler-pe`, `--integrator-pe`, …) — see
[Backend → Bundle carrier flags](backend.md#bundle-carrier-flags).

## File extensions and conventions

| Extension | Meaning |
|---|---|
| `.c` | Standard C — only `backend_mystc.c` and `compiler/loaders/loader_*.c` |
| `.mc` | MystC source |
| `.mcb` | MystC compiled bytecode (frontend output) |
| `.bin` | PIC x86-32 shellcode (backend output) |
| `.mct` | MystC text IR (debug aid) |
| `.mce` | MystC expression-style IR (debug aid) |

Source naming:

- The compiler driver is **`mystcc`** (`python -m compiler.frontend.mystcc`).
- All file extensions and the toolchain treat the language name as
  **MystC**. Documentation prose uses the same name.

## High-level components

| Component | Path | Language | Lines |
|---|---|---|---|
| Frontend | `compiler/frontend/` | Python 3 | ~4,900 |
| C backend (bootstrap) | `compiler/backend/backend_mystc.c` | C | ~7,200 |
| MC backend (self-hosted) | `compiler/backend/backend_mystc.mc` | MystC | ~6,500 |
| Standard library | `compiler/backend/stdlib.mc` | MystC | — |
| Metamophic Bundles | `bundles/` | MystC | — |
| Web IDE | `ide/` (Flask) | Python + JS | — |
| Tooling | `utils/disasm.py`, `utils/integrator_disasm.py`, `utils/mcb2text.py` | Python | — |

Three families of programs live under `bundles/`: **infectors**
(simple append-style PE / ELF infection — grow `.text`/`.data` on PE,
PT_NOTE→PT_LOAD on ELF), **recompilers**
(self-mutating PE / ELF that rebuild themselves each run), and **integrators**
(MystiqueFall on Win32 PE, LacriMystique on Linux ELF — disassemble
victim `.text`, scatter our code through it, reassemble).

These applications ship as a **bundle** — a self-contained PE/ELF
whose `.data` carries the program's `.mcb` (carrier or entry+engine),
an optional payload `.mcb`, the active genome, and a `BundleHeader`
descriptor table that names them. The binary carries everything it
needs to mutate and reproduce itself. See [Bundle](bundle.md) for the
full breakdown.

## Basic usage

```bash
# 1. Build everything (frontend in Python, C backend with MSVC/GCC,
#    then MC sources to .mcb, then .bin)
python build.py build

# 2. Compile a MystC source to bytecode
python -m compiler.frontend.mystcc docs/examples/example.mc -o example.mcb

# 3. Compile bytecode to PIC shellcode
compiler/backend/backend_mystc.exe example.mcb --pic example.bin

# 4. Or compile directly to a standalone Win32 PE / Linux ELF
compiler/backend/backend_mystc.exe example.mcb --pe-standalone example.exe
compiler/backend/backend_mystc.exe example.mcb --elf-standalone example

# 5. Or wrap into a higher-level application via the bundle flags:
compiler/backend/backend_mystc.exe example.mcb \
    --recompiler-pe demo_recomp.exe --bundles-dir bundles
compiler/backend/backend_mystc.exe example.mcb \
    --integrator-pe demo_integrator.exe --bundles-dir bundles
```

Add transform flags to enable polymorphism:

```bash
compiler/backend/backend_mystc.exe example.mcb --pic example.bin \
    --ir-unfold --ir-substitute --ir-deadcode --ir-reorder-funcs \
    --x86-poly-instrs --x86-dead-code --x86-junk-funcs --seed 42
```

The same `--seed` always produces the same bytes; change the seed (or pass
`--genome-mutate`) to get a different variant.

## Building and tooling

`build.py` is the single entry point:

```bash
python build.py build               # Compile everything
python build.py clean               # Remove every generated artifact
python build.py all                 # clean + build
```

What `build` does, in order:

1. `backend_mystc.c` → `backend_mystc.exe` (MSVC on Windows, GCC on Linux)
2. `loader_win32.c` → `loader_win32.exe`
3. Every `.mc` source → `.mcb` (via the Python frontend)
4. `backend_mystc.mcb` → `backend_mystc.bin` (via the freshly built C exe)

`build clean` walks every output-producing root (`compiler/`, `bundles/`,
`ide/`, `utils/`, `tests/`) and removes:

- Files matching `.obj` `.exe` `.bin` `.mcb` `.mct` `.mce` `.log` extensions
- No-extension Linux ELF outputs by name (`backend_mystc`, `backend_mystc_sref`,
  `mystiquefall_gen0`, `lacrimystique_gen0`)
- `__pycache__` and `.pytest_cache` directories anywhere

Other tools:

- `utils/disasm.py` — bespoke x86-32 disassembler that understands
  Mystique's `.bin` header. Outputs text or JSON.
- `utils/integrator_disasm.py` — Capstone-based PE/ELF disassembler that
  diffs an original binary against its MystiqueFall / LacriMystique-infected
  version, producing color-coded HTML.
- `utils/mcb2text.py` — dumps an existing `.mcb` to label-style `.mct`
  and/or expression-style `.mce` text IR. Inverse of mystcc's
  `--text` / `--expr` flags; useful for inspecting the backend's
  `--transform-ir` output.
- `ide/server.py` — Flask web IDE at `http://localhost:5000`.

## The IDE

A built-in web IDE makes most of what you've just read above clickable
instead of typed. Open a `.mc` file, flip transform checkboxes on and
off, and watch the resulting `.bin` change in real time. There are
five views: an **Editor** for the source, a **Transforms** panel to
toggle the polymorphism knobs, a **Variants** view that compiles N
seeds in parallel and lays the disassemblies side by side, an
**Evolution** view that walks generations of self-recompilation, and
a **Diff** view that highlights what changed between two variants.

Run it with:

```bash
cd ide
python server.py            # → http://localhost:5000
```

Open the URL in any browser. Honestly the easiest way to *feel* what
this compiler does is to spend a few minutes flipping transforms on
the example you wrote in step 1, watching the disassembly mutate
under your eyes. Go play. See [IDE](ide.md) for the full reference.

## Dependencies

**Build:**

- Python 3.11+
- MSVC 14.x (Windows) or GCC (Linux). The C backend uses only standard C99.

**Runtime / tests:**

- `pytest` for the test suite.
- `capstone` for `utils/integrator_disasm.py` only.
- `flask` for the IDE (see `ide/requirements.txt`).
- WSL on Windows for any Linux ELF tests; native bash on Linux.

## Directory structure

```
Mystique/
├── compiler/
│   ├── frontend/         Python 3 frontend
│   ├── backend/          C + MC backends, stdlib, genome defaults
│   └── loaders/          Win32/Linux loaders for PIC shellcode
├── bundles/
│   ├── infectors/        Section-append PE / ELF infectors
│   ├── recompilers/      Self-recompiling PE / ELF programs
│   └── integrators/      MystiqueFall / LacriMystique code-integration engines
├── docs/                 (this directory)
│   ├── examples/         Small .mc example programs
├── ide/                  Flask web IDE
├── tests/                pytest suite (611 tests)
│   ├── frontend/         Lexer/parser/typecheck/irgen/bytecode
│   ├── backend/          IR + x86 transforms, determinism, regalloc
│   ├── e2e/              Full pipeline + stress matrix + integrators
│   ├── regression/       Reproduced fixed bugs
│   ├── tools/            disasm.py + bridge.py tests
│   ├── programs/         Test .mc sources
│   ├── victims/          Committed PE/ELF victim fixtures
│   └── legacy/           Old shell scripts
└── utils/                disasm.py, integrator_disasm.py, mcb2text.py, measure.py
```
