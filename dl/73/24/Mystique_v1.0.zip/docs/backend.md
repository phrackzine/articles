# Backend

The backend turns a `.mcb` IR module into x86-32 code. Two parallel
implementations exist: a C backend used to bootstrap, and a self-hosted
MystC backend used for everything else. Both consume the same `.mcb`,
produce identical bytes for the same `(seed, genome, transforms)` inputs,
and share the same set of CLI flags.

## C backend (`backend_mystc.c`)

~7,200 lines of plain C99. Single file, no external dependencies, builds
with MSVC (`/O2 /W3`) or GCC. Acts as the **gen0 compiler**:

```bash
# Built by build.py from backend_mystc.c:
compiler/backend/backend_mystc.exe        # Windows
compiler/backend/backend_mystc            # Linux
```

It is a faithful reference implementation. The MC backend mirrors it
function-for-function, and the determinism test suite asserts that both
emit byte-identical output for any given `(seed, genome)` pair.

## MC backend (`backend_mystc.mc`)

~6,500 lines of MystC. It is `#include`d (textually, by the frontend) into
several programs:

- `backend_main.mc` — wraps `backend_mystc.mc` with a `main()` for CLI
  use. Compiled to `backend_mystc.mcb` (and `backend_mystc.bin`).
- `bundles/recompilers/recomp_pe.mc` and `recomp_elf.mc` — the
  self-recompiling backends.
- `bundles/infectors/infector_pe.mc` and `infector_elf.mc` — the
  append-style infectors.
- `bundles/integrators/integrator_entry.mc` — the entry program used by
  both code-integrator engines.

Because the MC backend is `#include`d rather than linked, every program
that needs codegen carries its own complete copy of it. This is the
mechanism behind the
[bundle architecture](bundle.md#what-is-a-bundle).

The integrator engines themselves
(`bundles/integrators/mystiqueFall/mystiquefall.mc` and
`lacriMystique/lacrimystique.mc`) do *not* `#include` the backend — they
receive pre-compiled bytes from the entry program through an
`InfectBundle*`. See [Bundle](bundle.md) for why the split is needed.

## CLI surface

Run `backend_mystc.exe` with no arguments to print the help text:

```
Usage: backend_mystc.exe input.mcb [options]

Output (combinable):
  --pic <out.bin>
      PIC shellcode of input.mcb

  --pe-standalone <out.exe>
      Standalone Win32 PE of input.mcb (real IAT, no loader)

  --elf-standalone <out>
      Standalone static Linux ELF of input.mcb (syscall wrappers, no loader)

  --transform-ir <out.mcb>
      Emit post-transform IR bytecode (debug aid)

Bundle: assemble input.mcb as the embedded payload of a pre-built carrier.
input.mcb is optional. omit it to build a gen0 binary with no embedded payload.

  --recompiler-pe  <out.exe>   self-recompiling Win32 PE
  --recompiler-elf <out>       self-recompiling Linux ELF
  --infector-pe    <out.exe>   PE append infector
  --infector-elf   <out>       ELF append infector (PT_NOTE -> PT_LOAD)
  --integrator-pe  <out.exe>   PE code-integration bundle (MystiqueFall)
  --integrator-elf <out>       ELF code-integration bundle (LacriMystique)
  --bundles-dir <path>         bundles/ root (default: ./bundles)

PRNG:
  --seed N                     seed value (default: time-based)

Genome:
  --genome <file.json>         load genome from JSON
  --genome-mutate              mutate genome before compiling
  --genome-temperature N       mutation strength 0-100 (default: 50)
  --genome-out <file.json>     save genome to JSON after compilation

IR transforms (off by default, each flag enables one):
  --ir-obfuscate-names         randomize function/label names
  --ir-unfold                  constant unfolding
  --ir-substitute              instruction substitution
  --ir-deadcode                dead code insertion
  --ir-nops                    NOP insertion
  --ir-reorder-instrs          reorder independent instructions
  --ir-reorder-locals          permute local variable indices
  --ir-reorder-blocks          reorder basic blocks
  --ir-reorder-funcs           shuffle function order

x86 transforms (off by default, each flag enables one):
  --x86-poly-instrs            register shuffle + poly encoding
  --x86-dead-code              dead bytes between blocks/instructions
  --x86-opaque                 opaque predicate insertion
  --x86-junk-funcs             junk function generation + calls
  --x86-harmless-calls         harmless API/syscall wrapper calls
  --x86-shuffle-funcs          shuffle function layout in binary

Debug:
  -v                           verbose output
  --debug-transform            trace transform decisions to stderr
```

See [Transforms](transforms.md) for what each transform flag does.

## Pipeline

Both backends follow the same internal stages:

```
parse_bytecode()          .mcb bytes → struct Module
optimize_module()         clean: remove_nops + remove_dead_code
transform_module()        IR-level polymorphic transforms (see Transforms)
optimize_module_random()  stochastic fold_constants (50% chance)
init_codegen()            allocate code/data buffers, set up PRNG, x86 config
gen_module()              walk every function, emit x86-32, run regalloc
output writer             emit .bin / .exe / ELF, optionally embed bundle
```

### Two-pass optimization

Note the two distinct optimization passes around `transform_module`. The
first (`optimize_module`) is deterministic cleanup — it strips NOPs and
dead code from whatever the frontend handed in, so the IR that the
transforms see is tight. The second (`optimize_module_random`) runs
*after* the transforms and is stochastic: each cleanup (remove-NOPs,
remove-dead-code, fold-constants) fires with ~50% probability per
function. The second pass exists to partially undo what the transforms
just did — fold-constants in particular reverses unfold/substitute work.

The randomness is the point. If the second pass were deterministic it
would either always undo all transform work (IR collapses back to
baseline) or always preserve it (IR grows monotonically across
generations of self-recompilation). At 50% per cleanup, the IR reaches
an equilibrium size — transforms add roughly as much as the stochastic
cleanup removes — so a recompiler chain can run indefinitely without the
bytecode bloating.

This pattern — bracketing expanding transforms with deterministic
cleanup before and stochastic cleanup after — is the *Accordion Model*,
introduced by The Mental Driller in MetaPHOR (29A#6, 2002).

## Register allocator

Greedy, instruction-level, with PRNG-shuffled register ordering. Six
general-purpose registers are available in absolute mode (`EAX, ECX, EDX,
EBX, ESI, EDI`); five in PIC mode (`EBX` is reserved as the data base).
`ESP`/`EBP` are never allocated.

Lifetimes are computed per basic block. The allocator:

1. Iterates the block's instructions in order.
2. For each operand, if it's already in a register, use that register;
   otherwise pick the next free register (in PRNG-shuffled order).
3. If no register is free, spill the register whose next future use is
   farthest away (Belady-optimal) to a stack slot.
4. After each instruction, free any operand whose live range ended.
5. At block boundaries, spill all live registers (`ra_spill_all`).

A few corner cases that have caused real bugs in the past and now have
explicit guards:

- **`SHL`/`SHR` need their shift count in `CL`.** The allocator
  pre-reserves `ECX` for the shift instruction.
- **`DIV`/`MOD` clobber `EAX:EDX`.** They are emitted as a fixed
  sequence: spill conflicting regs, load dividend into `EAX`, sign-extend
  `EAX` into `EDX:EAX` via `CDQ`, divide.
- **Comparisons materialize 0/1 in `EAX`** via `CMP; MOV EAX,0; Jcc +5;
  MOV EAX,1` rather than `SETcc`, so the byte-register subset never
  enters the allocator's working set.
- **Post-RET cleanup** — once `block_returned` is set, no further spills
  are emitted (an unreachable spill after `RET` was a real bug).
- **RA-aware junk emission** — junk-call transforms cannot use
  `PUSHAD`/`POPAD` if the allocator already has registers in flight; the
  backend emits per-register `PUSH`/`POP` pairs instead.

The C and MC backends carry parallel, byte-equivalent implementations of
the allocator — `ra_*` functions in `backend_mystc.c` and matching `ra_*`
functions in `backend_mystc.mc`. They are not literally shared (the MC
side doesn't link against the C side); the determinism tests assert that
the two implementations make identical allocation decisions for any
given `(seed, genome)` input.

## Addressing modes (PIC vs absolute)

The backend has two addressing modes that drive everything else in
codegen. The mode is fixed for an entire compilation, derived from the
chosen output:

| Aspect | PIC mode (`pic_mode = 1`) | Absolute mode (`abs_mode = 1` PE / `2` ELF) | Scatter-ELF (`abs_mode = 2`, `pic_mode = 1`) |
|---|---|---|---|
| Output flag | `--pic` | `--pe-standalone`, `--elf-standalone` | `--integrator-elf` (via entry program) |
| IR flag | (default — no `CF_ABS_*` set) | `CF_ABS_PE` or `CF_ABS_ELF` | `CF_SCATTER_ELF` |
| Position-independent? | Yes — runs at any base address | No — bound to image base (PE: `0x00400000`) | Code yes, externs no — scattered into a victim at a fixed VA but with EBX-relative data |
| Code references | `CALL rel32` / `JMP rel32` (RIP-relative) | Same | Same |
| Data references | `[EBX + offset]` — EBX = data base | Absolute `mov eax, [0x00404000]` | `[EBX + offset]` — EBX = scatter data base |
| Extern calls | `call [EBX + api_slot*4]` (read pointer from API table) | `call [iat_entry]` (PE) or inlined syscall stub (ELF) | Absolute call to scattered extern thunks |
| Reserved registers | `EBX` is the data base — never allocated | None — full 6-register file (`EAX, ECX, EDX, EBX, ESI, EDI`) | `EBX` reserved (same as PIC) |
| Allocator pool | 5 GP registers | 6 GP registers | 5 GP registers |
| Loader needed? | Yes — `compiler/loaders/loader_*.c` or equivalent | No — runs as a normal OS executable | No — the host ELF's loader runs it |
| Imports resolved | At load time, by the loader walking `extern_info` | At link time (PE IAT) or compile time (ELF syscall numbers) | At infection time, into the victim's `.dynsym` |
| Reloc table | None — code is genuinely position-independent | Internal fixup tables for `.text`-to-`.data` and `.text`-to-IAT references; absorbed by the PE/ELF writer | Same fixup tables as absolute mode, consumed by LacriMystique |
| Relative size | Smaller — no headers, no IAT, no padding | Larger — full PE32 / ELF32 wrapper | In between — no wrapper but extra fixup tables |

The mode is selected from the `flags` argument to `compile_main` — bit
flags on a single integer, not separate output booleans:

```c
g_abs_mode = 0;
if      (flags & CF_ABS_PE)       { g_abs_mode = 1; g_pic_mode = 0; }
else if (flags & CF_ABS_ELF)      { g_abs_mode = 2; g_pic_mode = 0; }
else if (flags & CF_SCATTER_ELF)  { g_abs_mode = 2; g_pic_mode = 1; }
else                              { g_pic_mode = 1; }
```

### What changes in codegen

In **PIC mode**, the prologue of every function (or once at module entry,
depending on the build) loads the data base into `EBX` via the standard
`call $+5; pop ebx` trick. After that, every global access is encoded as
a displacement from `EBX`, and every extern call goes through the API
table at `[EBX + api_slot*4]`. The API table itself is a flat array of
function pointers populated by the loader at startup using the
`extern_info` block from the `.bin` header.

In **absolute mode**, all data references emit absolute 32-bit addresses
(`mov eax, [0x00404000]`). The backend tracks each absolute reference in
fixup tables; the output writer (PE or ELF) walks those tables and
patches the addresses once final image layout is known. PE absolute mode
also emits a real IAT (Import Address Table) and PE relocation table;
ELF absolute mode embeds inlined `int 0x80` syscall wrappers for libc
calls.

### Bundle corollary

The integrator architecture (see [Bundle](bundle.md)) uses
both modes in a single binary:

- **Entry program** — compiled with `CF_ABS_PE | CF_EMIT_MC` (Windows)
  or `CF_SCATTER_ELF | CF_EMIT_MC` (Linux) so it can be scattered into a
  victim's `.text` at a known absolute virtual address and continue
  running. (`CF_SCATTER_ELF` is a hybrid mode — PIC data, abs externs.)
- **Engine** — compiled with no `CF_ABS_*` flag, so PIC is the default
  and it can be loaded into freshly allocated RWX memory at a
  runtime-chosen address and run from there.

That split is exactly what these two modes were designed for: ABS for
"this code lives at a known fixed VA," PIC for "this code lives wherever
it ended up in memory." The auto-embed bundle mechanism on the standalone
PE/ELF writer is what makes the entry program able to carry a PIC engine
inside it.

### Quick rule of thumb

If the output is a flat `.bin` shellcode that something else loads, it's
PIC. If the output is a self-contained PE or ELF that the OS loads, it's
absolute. The integrators are the one place both are used at once, and
that's a deliberate architectural choice rather than an exception.

## Output formats

The backend supports several output kinds, controlled by output flags.
Multiple may be requested in one invocation, but only one of `--pic`,
`--pe-standalone`, `--elf-standalone` makes sense at a time per input.

### PIC shellcode (`--pic`)

A flat binary with this header (5 little-endian `u32`s, 20 bytes total):

```
u32 entry_offset      offset into the code segment of the entry function
u32 code_size
u32 data_size
u32 extern_count
u32 extern_info_size
```

Followed by `code` (size = `code_size`), `data` (size = `data_size`), then
the extern info table:

```
u32 slot_count                                 (= extern_count)
for each slot in 0..slot_count-1:
    NUL-terminated dll_name
    NUL-terminated func_name
```

The loader (`compiler/loaders/loader_*.c`) resolves each slot by
calling `LoadLibraryA` + `GetProcAddress` (Windows) or `dlopen`+`dlsym`
(Linux), populates an API table at the start of the data segment, copies
code+data into `VirtualAlloc(RWX)` / `mmap(RWX)`, and jumps to
`entry_offset`.

The compiled code is fully PIC: code-data references go through
`EBX = data_base`, code-code references are RIP-relative `CALL` /
`JMP` rel32, and the API table is read at known offsets relative to
`EBX`.

### Standalone PE (`--pe-standalone`)

A complete Win32 PE32 executable. Imports use a real IAT (the linker
builds one from the `extern "dll.name"` declarations). The PE has three
sections: `.text`, `.data`, `.idata`. Image base is `0x00400000`,
sections aligned to `0x1000` virtual / `0x200` raw.

### Standalone ELF (`--elf-standalone`)

A complete static Linux ELF32. Imports go through inlined syscall
wrappers (`int 0x80`). The ELF has program headers but no section table
(stripped), keeping the output minimal. Same auto-embed behavior as PE
for bundle-bearing programs.

### Bundle carrier flags

`--recompiler-pe`, `--recompiler-elf`, `--infector-pe`, `--infector-elf`,
`--integrator-pe`, and `--integrator-elf` are the canonical user-facing
way to produce a metamorphic self-recompiling, infecting, or integrating
binary. Each one:

1. Takes one argument — the output path.
2. Auto-resolves its carrier `.mcb` from `--bundles-dir` (default
   `./bundles`): e.g. `--recompiler-pe` reads
   `<bundles-dir>/recompilers/recomp_pe.mcb`.
3. For `--integrator-*`, also auto-resolves the engine `.mcb` (e.g.
   `<bundles-dir>/integrators/mystiqueFall/mystiquefall.mcb`).
4. Treats the positional `input.mcb` as the embedded payload, if
   present. Omit it to produce a gen0 binary with no payload.

```bash
# Gen0 self-recompiler with no payload
backend_mystc.exe --recompiler-pe recomp.exe

# Self-recompiler that also drops a payload each generation
backend_mystc.exe payload.mcb --recompiler-pe recomp.exe

# Code-integrator (MystiqueFall) with a payload, using a custom bundles root
backend_mystc.exe payload.mcb --integrator-pe mfall.exe \
    --bundles-dir ./bundles
```

See [Bundle](bundle.md) for what each carrier does at
runtime.

## Standard library (`stdlib.mc`)

`compiler/backend/stdlib.mc` (~850 lines) is the MystC standard
library. It's organized into six sections (in file order): platform
wrappers, strings & memory, PRNG, I/O & print, dynamic buffer, and
the bundle runtime handle. Every `.mc` program — including the
backend itself — opens with:

```c
#include "stdlib.mc"
```

The platform is selected by the frontend's `-DWIN32` / `-DLINUX`
flag, not by a `#define` in the source — see
[Language → Platform selection](language.md#platform-selection).

For the user-facing API surface (C-runtime wrappers, I/O helpers,
endianness pack/unpack, PRNG, dynamic buffer), see
[Language → Standard library](language.md#standard-library-what-include-stdlibmc-gives-you).
The bundle-protocol surface in stdlib — `struct BundleHeader` +
`struct Descriptor`, the `g_bundle_header` pointer, `bundle_open` /
`bundle_find` / `bundle_get` / `bundle_xor`, and the `BC_*` descriptor
kinds — is documented in
[Bundle](bundle.md) and [Tutorial → Tier 4](tutorial.md#tier-4-using-the-backend-as-a-library).
The companion `load_and_run_bin` helper (used by entry programs to
JIT-load the engine in RWX) lives in `backend_mystc.mc`, not stdlib.
Genome-mutation helpers (`mut_seed`, `mutate_genome`, etc.) live in
`backend_mystc.mc`, not stdlib — see [Genome](genome.md).

### Platform splits

The C-runtime wrappers (`malloc`, `free`, `read`, `write`, `open`,
`close`, `exit`) keep identical signatures on both platforms but are
`#ifdef`-split underneath:

- **Win32** — MystC functions wrapping `HeapAlloc` / `WriteFile` /
  `CreateFileA` / `ExitProcess`, with kernel32 platform constants
  (`STD_OUTPUT_HANDLE = -11`, `GENERIC_WRITE_K = 0x40000000`, …).
- **Linux** — MystC functions calling `__syscall(num, ...)` directly
  (mmap2 = 192, write = 4, etc.), no extern table beyond the harmless
  set.

The Linux `malloc` allocates with `PROT_READ|PROT_WRITE|PROT_EXEC` and
prepends an 8-byte size header — engines compile bytecode into
`malloc`'d buffers and jump into them, so the heap must be executable.

### Why it's part of the backend

Three reasons:

1. The **backend itself includes it** — `backend_mystc.mc` opens with
   `#include "stdlib.mc"` and uses everything from `print` to
   `mem_copy` to `g_bundle_header`. Putting stdlib elsewhere would
   break the include path.
2. **Harmless-call auto-detection is a backend feature**, but the
   *list* of harmless APIs is `stdlib.mc`'s extern declarations. The
   coupling is intentional: declare an extern, get a harmless slot.
3. **Polymorphism penetrates stdlib.** `malloc` / `free` / `write` are
   regular MystC functions and get the full transform menu — so the
   `WriteFile` call site inside `write()` has different register
   selection, possibly different instruction encodings, and possibly a
   different surrounding junk envelope every generation.

## Determinism

The backend is bit-deterministic per `(seed, genome, transforms)`. The
test suite verifies this in `tests/backend/test_determinism.py`. If you
ever see different bytes from the same inputs, that is a bug — there is
no inherent "PRNG sensitivity." Crashes that change with seed are real
bugs that different transform decisions expose, and need to be
investigated, not blamed on the PRNG.

The C and MC backends are byte-equivalent on the same inputs: the C
backend's emit feeds the MC backend's bootstrap, and any divergence would
break self-hosting in one round-trip.
