# Frontend

The frontend lives in `compiler/frontend/`. It is written in Python 3 and
has no third-party dependencies. Its job is to turn a `.mc` source file
into a `.mcb` bytecode module — fully deterministic, no PRNG involvement.

## Driver

```
python -m compiler.frontend.mystcc source.mc -o out.mcb [-DWIN32 | -DLINUX]
                                              [--text out.mct]
                                              [--expr out.mce]
                                              [--dump-ast]
                                              [--dump-tokens]
                                              [--strip-debug]
                                              [--scramble-globals]
                                              [-v | --verbose]
```

Options:

- `-o <path>` — output `.mcb`. Defaults to `<source>.mcb` if omitted.
- `-D<NAME>` — preprocessor define (typically `WIN32` or `LINUX`).
- `--text <path>` — also emit a label-style human-readable IR dump
  (`.mct`). Each instruction is one line in three-address form
  (`%4 = add %2 %3 i32`).
- `--expr <path>` — also emit an expression-style IR dump (`.mce`).
  Same IR, but reads more like C source (`t4 = t2 + t3`); easier on
  the eye for short programs.
- `--dump-ast` — print the AST after parsing (to stdout).
- `--dump-tokens` — print the token stream before parsing (to stdout).
- `--strip-debug` — drop direct calls to the debug-print builtins
  (`print`, `print_int`, `print_hex`, `print_err`, `print_int_err`)
  between typecheck and IR generation. Indirect calls and the
  function definitions themselves are left intact; unreferenced
  string literals fall out at IR generation. Used by the IDE.
- `--scramble-globals` — demote integer-literal global initializers
  into a generated `__init_globals` function and overwrite each
  initializer's `.data` slot with `crc32(name)` (signed-i32).
  `__init_globals` is called at the head of `main` and restores the
  real values at runtime. No-op for library compiles (no `main`).
  Pointer / string / uninitialized globals are left untouched.
  Pure IR-level — no new opcodes, no `.mcb` format changes.
- `-v` / `--verbose` — extra progress output.

## Pipeline

```
source.mc
  │
  ▼
mystcc.preprocess   → expanded source          (#include / #ifdef / #define)
  │
  ▼
lexer.py            → list[Token]              (tokens.py defines TokenType)
  │
  ▼
parser.py           → AST                      (defined in mystc_ast.py)
  │
  ▼
typecheck.py        → typed AST                (symbols.py = symbol table)
  │
  ▼
strip_debug.py (optional)                      (--strip-debug only)
  │
  ▼
irgen.py            → IR module                (functions / blocks / opcodes)
  │
  ▼
scramble.py (optional)                         (--scramble-globals only;
  │                                             the one frontend pass that
  │                                             runs after IR generation)
  ▼
bytecode.py         → bytes                    (.mcb file)
```

### Preprocessor (in `mystcc.py`)

The preprocessor runs before the lexer and is implemented inside the
driver itself (`mystcc.preprocess`), not in `lexer.py`. It supports:

- `#include "path"` — relative to the including file; recursive, with
  a diamond/cycle guard.
- `#define NAME` — registers a symbol (no value substitution; this is
  used for conditional compilation, not macro expansion).
- `#ifdef NAME` / `#ifndef NAME` / `#else` / `#endif` — nestable
  conditional blocks, gated by `-D` flags or in-source `#define`s.

Defines from `-D` flags are merged with in-source `#define`s into a
single set. There is no function-like macro expansion at all —
`#define NAME` registers presence only, not a value.

### `lexer.py` (~250 lines)

Produces a stream of tokens (`tokens.py:TokenType`) from the
already-preprocessed source. Recognizes:

- C identifiers, integer literals (decimal + `0x` hex), char literals,
  string literals.
- All MystC operators and punctuation.
- Comments (`//` and `/* */`).

### `parser.py` (~700 lines)

Recursive-descent parser. Builds the AST in
`mystc_ast.py` (`Program`, `FuncDef`, `VarDecl`, `Block`, `IfStmt`, `WhileStmt`,
`ForStmt`, `ReturnStmt`, expressions of various kinds). No operator precedence
table — uses a layered set of `parse_assign`, `parse_logic_or`,
`parse_logic_and`, …, `parse_unary`, `parse_postfix` functions.

### `typecheck.py` (~520 lines)

Resolves identifier references through `symbols.py` (a stack of scopes).
Computes types, validates `arg/return` counts and types, complains about
incompatible operand types. Annotates each AST node with its inferred
type. After typecheck, every expression has a known `Type`.

### `irgen.py` (~830 lines)

Lowers the typed AST into an IR module. The schema lives in
`bytecode.py` and is shared by both the writer and the reader:

```python
@dataclass
class MCProgram:
    strings:        list[str]                # interned string literals
    structs:        list[MCStruct]           # struct definitions
    globals:        list[MCGlobal]           # name, type, init value
    functions:      list[MCFunction]
    string_indices: dict[str, int]           # built by build_indices()
    func_indices:   dict[str, int]
    global_indices: dict[str, int]
    # helpers: add_string(s) -> int, build_indices() (rebuilds the dicts)

@dataclass
class MCFunction:
    name:        str
    return_type: TypeCode
    param_types: list[TypeCode]
    local_types: list[TypeCode]
    local_sizes: list[int]              # for arrays
    blocks:      list[Block]            # empty for externs
    num_temps:   int
    is_extern:   bool                   # True for extern declarations
    dll:         str                    # DLL/library name (externs only)

@dataclass
class Block:
    label:        str
    instructions: list[Instruction]
```

`Instruction` is three-address-code style: an `opcode` plus `dest`,
`arg1`, `arg2` operands of type `Value`, with extra fields for jumps
(`target_block`), calls (`func_index`, `nargs`, `args`), pointer
arithmetic (`offset`, `elem_size`), and raw `EMIT` bytes
(`emit_bytes`). See [IR](ir.md) for the full opcode list.

### `bytecode.py` (~1,100 lines)

Serializes `MCProgram` → bytes (`write_bytecode`) and bytes →
`MCProgram` (`read_bytecode`); also provides the text-IR dumpers
(`write_text` for `.mct`, `write_expr` for `.mce`). The on-disk
format is described in [IR](ir.md). Both the C and MC backends
consume the same `.mcb` format.

## Language reference

The formal definition of the MystC language — what it has, what it
deliberately doesn't, and the subtle semantics — has its own doc:
**[Language Reference (MystC)](language.md)**.

This frontend doc covers the *implementation* of that language: the
lexer, parser, typechecker, IR generator, and bytecode serializer
that together turn a `.mc` source file into a `.mcb` artifact.
