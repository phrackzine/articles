# Tutorial

A guided tour of Mystique's language and toolchain by progressive
example. Each tier builds on the last; reading top to bottom touches
every major feature of the language and the basic build pipeline.

If you'd rather skim, **Tier 1–2** is "the language" and **Tier 3** is
"the toolchain." Once you're comfortable with those, the
[Bundle](bundle.md) doc picks up where this one leaves off and shows
how to build metamorphic programs on top of the backend (recompilers,
infectors, integrators).

Code blocks throughout the tutorial are inlined — short enough to
copy / paste into a one-off `.mc` file. Every section's example also
ships as a standalone file under `docs/examples/tutorial/`
(`01_hello.mc` through `07_library_demo.mc`), already compiling on
both `-DWIN32` and `-DLINUX`. A few older programs live one level up
in `docs/examples/` (`linked_list.mc` is referenced in Tier 2).

## Prerequisites

```bash
python build.py build      # produces backend_mystc.exe + .bin and the loaders
pytest -m frontend         # sanity-check the toolchain (~125 tests)
```

After that, the workflow is always:

```bash
# 1) frontend: source.mc → out.mcb (deterministic)
python -m compiler.frontend.mystcc source.mc -DWIN32 -o out.mcb

# 2) backend: out.mcb → out.bin (a baseline build — no transforms)
compiler/backend/backend_mystc.exe out.mcb --pic out.bin

# 3) backend with transforms: now seed matters — same .mcb yields
#    different .bin per seed
compiler/backend/backend_mystc.exe out.mcb --pic out_s1.bin --seed 1 \
    --x86-poly-instrs --x86-dead-code
compiler/backend/backend_mystc.exe out.mcb --pic out_s2.bin --seed 2 \
    --x86-poly-instrs --x86-dead-code

# 4) loader: run any of the .bin files
compiler/loaders/loader_win32.exe out_s1.bin
```

Without at least one transform flag, the backend's PRNG has nothing
to gate, so different seeds produce identical output. Polymorphism
turns on flag-by-flag — see [Transforms](transforms.md) for the
menu.

On Linux replace `-DWIN32` with `-DLINUX` and use `loader_linux`.

> **Prefer clicking to typing?** The IDE wraps the same compiler in a
> 5-tab UI (Editor / Transforms / Variants / Evolution / Diff). Run
> `cd ide && python server.py` for `http://localhost:5000` and skim
> [IDE](ide.md). The CLI tour below still pays off — you'll
> understand what each tab is actually doing — but you can come back
> for it.

---

# Tier 1 — Getting started

## 1. Hello, world!

```c
#include "stdlib.mc"

int main() {
    init_io();
    print("Hello, world!\n");
    return 0;
}
```

`stdlib.mc` provides `init_io()`, `print(char*)`, `print_int(int)`,
`print_hex(int)`, `malloc`/`free`/`read`/`write`/`open`/`close`/`exit`,
and a small PRNG. See [Backend → Standard library](backend.md#standard-library-stdlibmc).
You always need `init_io()` once before any `print*` calls — it
populates the stdout/stderr handle globals.

`stdlib.mc` selects its platform via `#ifdef WIN32` / `#ifdef LINUX`,
so you must pass exactly one of `-DWIN32` or `-DLINUX` to the
frontend. The `.mc` source itself stays platform-agnostic.

Build, run, and try a different seed to see the polymorphism:

```bash
python -m compiler.frontend.mystcc hello.mc -DWIN32 -o hello.mcb
backend_mystc.exe hello.mcb --pic hello.bin --seed 1 \
    --x86-poly-instrs --x86-dead-code
loader_win32.exe hello.bin

# Same source, different bytes:
backend_mystc.exe hello.mcb --pic hello2.bin --seed 2 \
    --x86-poly-instrs --x86-dead-code
fc /B hello.bin hello2.bin    # diffs everywhere; both print "Hello, world!"
```

## 2. Arithmetic and control flow

```c
#include "stdlib.mc"

int main() {
    int i;
    int sum;

    init_io();
    sum = 0;
    for (i = 1; i <= 10; i = i + 1) {
        sum = sum + i;
    }

    print("sum 1..10 = ");
    print_int(sum);
    print("\n");
    return 0;
}
```

What MystC has: `if`/`else`, `while`, `for`, `break`, `continue`,
`return`. What it does *not* have: ternary `?:`, `switch`, `do/while`,
`goto`, `++`/`--`, compound assignment (`+=`, `-=`, …). Spell things
out: `i = i + 1`, not `i++`.

Two subtle quirks:

- **All locals must be declared at the top of a block before use.** A
  `for` loop cannot declare its index inline (`for (int i = 0; ...)` is
  a parse error) — declare `int i;` above it.
- **`>>` is arithmetic** (sign-extending), not logical. `(-1) >> 1` is
  `-1`, not a large positive number.

## 3. Globals, arrays, strings

```c
#include "stdlib.mc"

int counter = 0;                // global with initializer
char* greeting;                 // global pointer — assigned at runtime
int squares[5];                 // uninitialized array — zero-filled at start

void bump() {
    counter = counter + 1;
}

int main() {
    int i;
    init_io();

    greeting = "Hi there\n";

    for (i = 0; i < 5; i = i + 1) {
        squares[i] = i * i;
        bump();
    }

    print(greeting);
    print("counter = ");
    print_int(counter);
    print("\n");

    print("squares[3] = ");
    print_int(squares[3]);
    print("\n");
    return 0;
}
```

Strings are NUL-terminated `char[]`. Inside a function body,
`char* p = "literal";` works fine and `p` ends up pointing at the
string in `.data`.

> **Not supported: string-literal initializers at global scope.**
> `char* p = "literal";` at file scope parses, but the backend writes
> the string-table *index* into the global's slot instead of the
> runtime string address — there's no fixup pass that translates one
> to the other. `print(p)` will read garbage. Declare the global as
> `char* p;` and assign `p = "literal";` from a function (typically
> `main`) before using it.
>
> **Not supported: array-with-initializer syntax.**
> `char p[] = "literal";` does not parse — the parser requires an
> explicit size, e.g. `char p[10];`.

---

# Tier 2 — Language depth

## 4. Structs and pointers

```c
#include "stdlib.mc"

struct Point {
    int x;
    int y;
};

void point_print(struct Point* p) {
    print("(");
    print_int(p->x);
    print(", ");
    print_int(p->y);
    print(")\n");
}

int main() {
    struct Point a;
    struct Point b;

    init_io();

    a.x = 3;
    a.y = 4;

    // No struct assignment! `b = a;` is a type error.
    // Copy field-by-field:
    b.x = a.x;
    b.y = a.y;
    b.x = b.x + 10;

    point_print(&a);
    point_print(&b);
    return 0;
}
```

Two constraints worth remembering:

- **No struct assignment via `=`.** Copy fields one at a time, or write
  a `struct_copy` helper.
- **Arrays of structs work**, but you index members manually:
  `arr[i].field = value;`.

A heap-allocated linked list (`docs/examples/linked_list.mc`) shows
both struct pointers and `malloc`:

```c
struct Node {
    int value;
    struct Node* next;
};

struct Node* list_prepend(struct Node* head, int value) {
    struct Node* node;
    node = malloc(8);          // sizeof(int) + sizeof(ptr) on x86-32
    node->value = value;
    node->next = head;
    return node;
}
```

## 5. Function pointers and indirect calls

This is what makes the API table and the bundle architecture
possible. You can take the address of a function and call through it:

```c
int square(int x) { return x * x; }
int cube(int x)   { return x * x * x; }

int apply(int fn, int v) {
    int result;
    result = fn(v);            // indirect call through int-typed pointer
    return result;
}

int main() {
    int sq;
    int cb;
    init_io();

    sq = &square;              // function address-of
    cb = &cube;

    print_int(apply(sq, 5));   // 25
    print("\n");
    print_int(apply(cb, 5));   // 125
    print("\n");
    return 0;
}
```

The indirect call uses `OP_ICALL` / `OP_ICALLV` in the IR. Function
addresses are plain `int`s — there is no separate function-pointer
type. The integrator engines build a runtime API table this way: the
loader fills slots with `&malloc`, `&free`, `&WriteFile`, etc., and the
engine reads slots and calls through them.

## 6. Working with externs

Two flavors:

```c
// Win32: kernel32 / user32 imports — resolved through the IAT
extern "kernel32.dll" int GetTickCount();
extern "kernel32.dll" int MessageBoxA(int hwnd, char* text, char* title, int type);

// Linux: libc.so.6 — resolved by the ELF builder
extern int getpid();
```

The parameter list uses empty `()`, not C's `(void)` — MystC's parser
rejects `(void)` as a parameter list. For a function with no
arguments, just write `()`.

Any extern with **0 parameters** and a `dll_name` matching the platform
standard library (`kernel32.dll` on Win32, `libc.so.6` on Linux) is
auto-detected as a "harmless API." With `--x86-harmless-calls` enabled,
the backend will sprinkle calls to those externs throughout the
generated code as junk — see
[Transforms → Harmless calls](transforms.md#harmless-calls). To add a
new harmless API, just declare the extern. Nothing else.

The 7 named API slots (0–6) are `malloc`, `free`, `read`, `write`,
`open`, `close`, `exit` — `stdlib.mc` provides them. Slot 7 is a
reserved fallback (returns `-1` on ELF standalone for any extern the
backend doesn't recognize). Your own user externs start at slot 8.

## 7. Multi-platform code

```c
#ifdef WIN32
extern "kernel32.dll" void Sleep(int ms);
#endif
#ifdef LINUX
extern void usleep(int us);
#endif

#include "stdlib.mc"

void brief_pause() {
#ifdef WIN32
    Sleep(0);
#endif
#ifdef LINUX
    usleep(0);
#endif
}

int main() {
    init_io();
    print("before pause\n");
    brief_pause();
    print("after pause\n");
    return 0;
}
```

Pick externs `stdlib.mc` doesn't already carry — most of the common
kernel32 / libc functions (`GetCurrentProcessId`, `GetTickCount`,
`getpid`, `getppid`, …) are already declared there, and redeclaring
one is a "Function 'X' already defined" error. To call those, just
`#include "stdlib.mc"` and skip the extern.

Build twice from the same source:

```bash
python -m compiler.frontend.mystcc app.mc -DWIN32 -o app_win.mcb
python -m compiler.frontend.mystcc app.mc -DLINUX -o app_lin.mcb
```

`build.py` does this for everything in the project; the C-runtime
wrappers (`malloc`, `write`, …) on each platform have completely
different bodies but identical names, so the same source compiles to
both worlds.

---

# Tier 3 — The toolchain

## 8. Inspecting what the compiler did

The frontend can dump the AST and a textual IR alongside the `.mcb`:

```bash
python -m compiler.frontend.mystcc app.mc -DWIN32 \
    -o app.mcb --dump-ast --text app.mct
```

`app.mct` shows the IR in a human-readable form — globals, functions,
basic blocks, three-address instructions. See [IR](ir.md) for the
opcode set.

For post-transform IR (after the backend has rewritten it):

```bash
backend_mystc.exe app.mcb --transform-ir post.mcb \
    --ir-unfold --ir-substitute --seed 7
python utils/mcb2text.py post.mcb --text post.mct       # label style
python utils/mcb2text.py post.mcb --expr post.mce       # expression style
```

`utils/mcb2text.py` is the inverse of the frontend's `--text` /
`--expr` flags: where `mystcc` reads a `.mc` source and emits text
sidecars alongside the `.mcb`, `mcb2text.py` reads an existing `.mcb`
and emits the same sidecars. Same flag names, same output formats.

For x86 disassembly of the resulting `.bin`:

```bash
python utils/disasm.py app.bin
```

The IDE's **Editor** tab does all three at once — source, IR, and
disassembly side-by-side, refreshed on each compile. Useful when
you're iterating on a source change and want to see how the IR /
x86 shifts without re-running three commands.

## 9. Picking transforms

Each flag is independent and can be combined. Try them one at a time
to learn what each does:

```bash
backend_mystc.exe app.mcb --pic plain.bin --seed 1
backend_mystc.exe app.mcb --pic v1.bin    --seed 1 --x86-poly-instrs
backend_mystc.exe app.mcb --pic v2.bin    --seed 1 --x86-poly-instrs --x86-dead-code
backend_mystc.exe app.mcb --pic v3.bin    --seed 1 --ir-unfold --ir-substitute \
                                                   --x86-poly-instrs --x86-dead-code
```

Diff `v1` vs `v2` to see dead code inserted; diff `v2` vs `v3` to see
how IR-level transforms ripple into different x86 sequences.

The full menu lives in [Transforms](transforms.md). To turn everything
on, pass every flag explicitly:

```bash
backend_mystc.exe app.mcb --pic full.bin --seed $RANDOM \
    --ir-unfold --ir-substitute --ir-deadcode --ir-nops \
    --ir-reorder-instrs --ir-reorder-locals --ir-reorder-blocks --ir-reorder-funcs \
    --x86-poly-instrs --x86-dead-code --x86-opaque --x86-junk-funcs \
    --x86-harmless-calls --x86-shuffle-funcs
```

> **Faster loop — the IDE.** Toggling 14 flags from the command line
> gets old fast. The IDE's **Transforms** tab exposes every flag
> above as a checkbox; the **Variants** tab compiles N seeds at once
> from the same source and lays them side-by-side; the **Diff** tab
> shows byte-level deltas between any two variants so you can see
> exactly what a transform shifted. Same compiler, same `.bin`
> output — much tighter feedback loop while you're learning the
> menu.

## 10. Standalone PE/ELF

PIC `.bin` outputs need a loader. Standalone outputs don't.

For most programs (anything that uses `stdlib.mc` or any extern), the
`.mcb` must be compiled with the matching platform `-D` *before*
being fed to the standalone writer — that's what makes
`#ifdef WIN32` / `#ifdef LINUX` blocks resolve to the right externs
and DLL names. So the typical flow is **build twice from the same
source**, then run each `.mcb` through the matching standalone
flag:

```bash
# Windows side: -DWIN32 → real PE32 with a kernel32 IAT
python -m compiler.frontend.mystcc app.mc -DWIN32 -o app_win.mcb
backend_mystc.exe app_win.mcb --pe-standalone app.exe

# Linux side: -DLINUX → ELF32 with INT 0x80 syscall wrappers
python -m compiler.frontend.mystcc app.mc -DLINUX -o app_lin.mcb
backend_mystc.exe app_lin.mcb --elf-standalone app.elf
chmod +x app.elf && ./app.elf
```

A `.mcb` built with `-DWIN32` references `kernel32.dll` directly in
its extern table — feeding it to `--elf-standalone` would either
fail to resolve or bake in nonsense library names. The two `.mcb`s
are *not* interchangeable.

The one exception: programs with **no externs** at all (no
`#include "stdlib.mc"`, no `extern "..."` declarations). Those
compile to identical `.mcb` regardless of `-D`, and the same `.mcb`
goes through either standalone flag. The Overview's walking example
is one of these — that's why it worked without recompiling.

The standalone writers also support bundle carrier flags
(`--recompiler-pe`, `--integrator-pe`, …) that auto-embed the input
`.mcb` plus extras into the binary's `.data` section — see
[Backend → Bundle carrier flags](backend.md#bundle-carrier-flags).

## 11. Genome basics

Every backend invocation uses a 65-gene genome. Without `--genome <file>`,
hardcoded defaults are used (see `default_genome()` in
`backend_mystc.c`). A reference genome lives at
`compiler/backend/genome.json` — a starting point you can edit and pass
via `--genome`. The genome controls *which* transforms fire and at what
intensity — flags enable a transform, but the genome's
`expression_flags` bitmask can still mask it off.

To save the active genome after compilation:

```bash
backend_mystc.exe app.mcb --pic out.bin --seed 1 --genome-out active.json
```

To use a fixed genome:

```bash
backend_mystc.exe app.mcb --pic out.bin --seed 1 --genome my_genome.json
```

To mutate the genome before compiling (the recompilers and integrators
do this each generation):

```bash
backend_mystc.exe app.mcb --pic out.bin --seed 1 \
    --genome my_genome.json --genome-mutate --genome-temperature 50 \
    --genome-out next.json
```

The genome is 138 bytes on the wire (in bundle components); `genome.json` is
the human-editable form the CLI accepts. See [Genome](genome.md) for the
gene list and mutation algorithm.

The IDE's **Transforms** tab also has a per-gene slider for every
probability gene plus a temperature knob — a gentler first encounter
with the genome than editing JSON by hand.

---

# Tier 4 — Using the backend as a library

The MC backend has no `main()` — it's a pure library. Any MystC program
can `#include` it and call `compile_main()` directly to compile a `.mcb`
in-process. This is what lets a binary carry its own complete compiler,
the foundation of self-recompiling programs, infectors, and integrators.

The entry point is `compile_main()`:

```c
int compile_main(int api, char* input_data, int input_size,
                 int flags, struct CompileOutput* out);
```

- `api` — API table pointer when `compile_main` is itself called as
  PIC shellcode. For direct calls from a MystC program, pass `0`.
- `input_data` / `input_size` — the `.mcb` to compile. May optionally
  carry a 138-byte serialized genome appended with magic `"GENE"`; if
  present, the backend uses it instead of defaults.
- `flags` — bitmask of `CF_*` constants (declared near the top of
  `backend_mystc.mc`, just below the `CompileOutput` struct). `0` is
  PIC mode with no transforms.
  Combine with `CF_IR_UNFOLD | CF_X86_POLY_INSTRS | …` for transforms,
  `CF_ABS_PE` / `CF_ABS_ELF` for standalone outputs, `CF_EMIT_MC` to
  also re-serialize the post-transform IR into `out->mc_data`.
- `out` — caller-allocated `CompileOutput`. On success
  `out->bin_data` / `out->bin_size` describe the compiled binary (the
  buffer is `malloc`'d internally and owned by the caller).

Returns `0` on success, non-zero on parse failure or codegen error.

## Running the output

To execute the compiled binary in-process, hand it to `load_and_run_bin`
(in `backend_mystc.mc`, alongside `compile_main`):

```c
int load_and_run_bin(char* bin, int bin_sz,
                     int bundle_addr, int header_addr);
```

`bin` / `bin_sz` is `out.bin_data` / `out.bin_size` from `compile_main`.
The two trailing arguments are integrator hooks — when non-zero, they
patch `g_infect_bundle` (InfectBundle pointer) and `g_bundle_header`
(BundleHeader pointer) in the called code's `.data` so the called code
can find its own bundle. Pass `0` for both to use the function as a
generic compile-and-jump.

What it does internally:

1. Parses the PIC header at the start of the binary — five little-endian
   u32s: `entry_off`, `code_sz`, `data_sz`, `ext_count`, `ext_info_sz`.
2. Allocates RWX (`VirtualAlloc(... PAGE_EXECUTE_READWRITE)` on Win32,
   `malloc` on Linux — `stdlib.mc`'s `malloc` returns
   `PROT_READ | PROT_WRITE | PROT_EXEC` memory).
3. Copies code + data into the RWX buffer.
4. Walks the extern table — pairs of NUL-terminated `dll`, `func`
   strings — and resolves each via `LoadLibraryA` + `GetProcAddress`
   (Win32) or via the `resolve_linux_extern` wrapper-table (Linux).
   Writes the resolved addresses into a freshly-allocated API table.
5. Patches the API table address into the code's reserved API slot.
6. Computes `entry = rwx + entry_off` and calls it. MystC supports
   indirect calls through `int`-typed addresses natively
   (`int fn = addr; result = fn(api);`).

## Worked example

A complete program — `docs/examples/library_demo.mc` — reads a `.mcb`
from disk, compiles it, runs it, and prints the return value. The
whole thing is one `int main()`:

```c
#include "../../compiler/backend/backend_mystc.mc"

int main() {
    char* mcb_buf;
    int   mcb_size;
    int   fd;
    struct CompileOutput out;
    int   rc;

    init_io();

    // 1. Read the input .mcb from disk.
    mcb_buf = malloc(64 * 1024);
    fd = open("factorial.mcb", 0);
    if (fd < 0) {
        print("Cannot open factorial.mcb\n");
        return 1;
    }
    mcb_size = read(fd, mcb_buf, 64 * 1024);
    close(fd);
    print("Read ");
    print_int(mcb_size);
    print(" bytes from factorial.mcb\n");

    // 2. Compile it. flags=0 → plain PIC mode, no transforms.
    out.bin_data = 0; out.bin_size = 0;
    out.mc_data  = 0; out.mc_size  = 0;
    rc = compile_main(0, mcb_buf, mcb_size, 0, &out);
    if (rc != 0) {
        print("compile failed\n");
        return 1;
    }
    print("Compiled to ");
    print_int(out.bin_size);
    print(" bytes of PIC shellcode\n");

    // 3. Load the result into RWX and run it. Bundle pointers both 0 →
    //    generic compile-and-jump (no bundle plumbing).
    print("Running... ");
    rc = load_and_run_bin(out.bin_data, out.bin_size, 0, 0);
    print("returned ");
    print_int(rc);
    print("\n");
    return 0;
}
```

A few things to note:

- The `#include "../../compiler/backend/backend_mystc.mc"` line pulls
  in the entire backend (~6,500 lines of MystC). The frontend's
  preprocessor inlines the file textually; nothing more clever than
  that. `stdlib.mc` rides along because the backend itself
  `#include`s it.
- `init_io()` populates `g_stdout` (Win32 `STD_OUTPUT_HANDLE` /
  Linux fd 1) so `print` has somewhere to write. Skipping it leaves
  `g_stdout = 0`, which silently swallows output.
- The `out` fields are zero-initialized by hand because MystC doesn't
  zero local struct slots automatically.

To build and run:

```bash
# 1. Compile a small program for the demo to load.
python -m compiler.frontend.mystcc docs/examples/factorial.mc \
    -o factorial.mcb -DWIN32              # or -DLINUX

# 2. Compile the demo through the frontend.
python -m compiler.frontend.mystcc docs/examples/library_demo.mc \
    -o library_demo.mcb -DWIN32           # or -DLINUX

# 3. Compile the demo's .mcb into a standalone PE (Linux: --elf-standalone).
compiler/backend/backend_mystc.exe library_demo.mcb \
    --pe-standalone library_demo.exe

# 4. Run it, with factorial.mcb sitting next to library_demo.exe.
./library_demo.exe
```

Expected output:

```
Read 267 bytes from factorial.mcb
Compiled to 674 bytes of PIC shellcode
Running... returned 120
```

`120 = factorial(5)`, returned from `factorial.mc:main` through the PIC
entry point that `load_and_run_bin` jumps to. The byte counts vary
between runs: every `compile_main()` call seeds the codegen PRNG from
`/dev/urandom` (Linux) or a runtime counter (Win32), so the same source
produces different bytes with identical behavior. Call `prng_seed(seed)`
before `compile_main` for reproducible output.

---

# Beyond the basics

Once you're comfortable with the language and the toolchain, the next
step is building metamorphic programs *on top of* the backend — recompilers,
infectors, integrators. Those each have their own build pattern (read
your own `.mcb` at runtime, decrypt the bundle, compile yourself with a
mutated genome, write the next generation), and they live in their own
doc, see **[Bundle](bundle.md)**.

To extend the compiler itself with a new transform, see
[Transforms → Adding a new transform](transforms.md#adding-a-new-transform).

---

# Where to go next

- [Genome](genome.md) — the 65 genes and how mutation works.
- [Transforms](transforms.md) — full list of IR + x86 transforms.
- [Bundle](bundle.md) — recompilers / infectors / integrators in detail.
- [IDE](ide.md) — point-and-click playground for transforms and
  variants.
- [Testing](testing.md) — how to run, mark, and write tests.
