// Simple test program for backend verification
int add(int a, int b) {
    return a + b;
}

int multiply(int a, int b) {
    int result;
    result = 0;
    while (b > 0) {
        result = result + a;
        b = b - 1;
    }
    return result;
}

int main() {
    int x;
    int y;
    int sum;
    int product;

    x = 5;
    y = 3;

    sum = add(x, y);
    product = multiply(x, y);

    return sum + product;  // Should return 8 + 15 = 23
}
