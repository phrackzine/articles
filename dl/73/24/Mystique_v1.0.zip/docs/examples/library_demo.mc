// library_demo.mc — Tier 4 tutorial example.
//
// Uses the MC backend as a library: reads a .mcb from disk, compiles it
// to PIC shellcode in memory, then jumps into the compiled code via
// stdlib's `load_and_run_bin` — and reports the program's exit value.
//
// Build:
//     # Compile a small input program for the demo to load:
//     python -m compiler.frontend.mystcc docs/examples/factorial.mc \
//         -o factorial.mcb -DWIN32           (or -DLINUX)
//
//     # Compile and link the demo itself:
//     python -m compiler.frontend.mystcc docs/examples/library_demo.mc \
//         -o library_demo.mcb -DWIN32        (or -DLINUX)
//     compiler/backend/backend_mystc.exe library_demo.mcb \
//         --pe-standalone library_demo.exe   (or --elf-standalone library_demo)
//
//     # Run, with factorial.mcb sitting next to library_demo.exe:
//     ./library_demo.exe
//
// Expected output:
//     Read N bytes from factorial.mcb
//     Compiled to M bytes of PIC shellcode
//     Running... returned 120

#include "../../compiler/backend/backend_mystc.mc"

int main() {
    char* mcb_buf;
    int   mcb_size;
    int   fd;
    struct CompileOutput out;
    int   rc;

    init_io();

    // 1. Read the input .mcb from disk.
    mcb_buf = malloc(64 * 1024);
    fd = open("factorial.mcb", 0);
    if (fd < 0) {
        print("Cannot open factorial.mcb\n");
        return 1;
    }
    mcb_size = read(fd, mcb_buf, 64 * 1024);
    close(fd);
    print("Read ");
    print_int(mcb_size);
    print(" bytes from factorial.mcb\n");

    // 2. Compile it. flags=0 → plain PIC mode, no transforms.
    out.bin_data = 0; out.bin_size = 0;
    out.mc_data  = 0; out.mc_size  = 0;
    rc = compile_main(0, mcb_buf, mcb_size, 0, &out);
    if (rc != 0) {
        print("compile failed\n");
        return 1;
    }
    print("Compiled to ");
    print_int(out.bin_size);
    print(" bytes of PIC shellcode\n");

    // 3. Load the result into RWX and run it. Bundle pointers both 0 →
    //    generic compile-and-jump (no bundle plumbing).
    print("Running... ");
    rc = load_and_run_bin(out.bin_data, out.bin_size, 0, 0);
    print("returned ");
    print_int(rc);
    print("\n");
    return 0;
}
