#ifdef WIN32
extern "kernel32.dll" void Sleep(int ms);
#endif
#ifdef LINUX
extern void usleep(int us);
#endif

#include "../../../compiler/backend/stdlib.mc"

void brief_pause() {
#ifdef WIN32
    Sleep(0);
#endif
#ifdef LINUX
    usleep(0);
#endif
}

int main() {
    init_io();
    print("before pause\n");
    brief_pause();
    print("after pause\n");
    return 0;
}
