#include "../../../compiler/backend/stdlib.mc"

int counter = 0;
char* greeting;
int squares[5];

void bump() {
    counter = counter + 1;
}

int main() {
    int i;
    init_io();

    greeting = "Hi there\n";

    for (i = 0; i < 5; i = i + 1) {
        squares[i] = i * i;
        bump();
    }

    print(greeting);
    print("counter = ");
    print_int(counter);
    print("\n");

    print("squares[3] = ");
    print_int(squares[3]);
    print("\n");
    return 0;
}
