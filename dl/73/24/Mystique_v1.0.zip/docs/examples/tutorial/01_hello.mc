#include "../../../compiler/backend/stdlib.mc"

int main() {
    init_io();
    print("Hello, world!\n");
    return 0;
}
