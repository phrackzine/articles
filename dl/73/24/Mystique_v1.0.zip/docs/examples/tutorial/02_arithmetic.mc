#include "../../../compiler/backend/stdlib.mc"

int main() {
    int i;
    int sum;

    init_io();
    sum = 0;
    for (i = 1; i <= 10; i = i + 1) {
        sum = sum + i;
    }

    print("sum 1..10 = ");
    print_int(sum);
    print("\n");
    return 0;
}
