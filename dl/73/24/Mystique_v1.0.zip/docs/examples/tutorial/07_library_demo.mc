// Tier 4 — Using the backend as a library.
//
// Reads factorial.mcb from the cwd, compiles it in-process with
// compile_main(), runs the result via load_and_run_bin(), and prints
// the return value (120 = factorial(5)).
//
// Build:
//     # 1) Compile the input program that this demo will load.
//     python -m compiler.frontend.mystcc docs/examples/factorial.mc \
//         -o factorial.mcb -DWIN32                (or -DLINUX)
//
//     # 2) Compile this demo through the frontend.
//     python -m compiler.frontend.mystcc \
//         docs/examples/tutorial/07_library_demo.mc \
//         -o library_demo.mcb -DWIN32             (or -DLINUX)
//
//     # 3) Link as a standalone PE/ELF (PIC won't work — this program
//     #    needs to call malloc/open/read/close, which standalone
//     #    binaries resolve through the IAT / syscall wrappers).
//     compiler/backend/backend_mystc.exe library_demo.mcb \
//         --pe-standalone library_demo.exe        (or --elf-standalone)
//
//     # 4) Run with factorial.mcb next to library_demo.exe.
//     ./library_demo.exe

#include "../../../compiler/backend/backend_mystc.mc"

int main() {
    char* mcb_buf;
    int   mcb_size;
    int   fd;
    struct CompileOutput out;
    int   rc;

    init_io();

    mcb_buf = malloc(64 * 1024);
    fd = open("factorial.mcb", 0);
    if (fd < 0) {
        print("Cannot open factorial.mcb\n");
        return 1;
    }
    mcb_size = read(fd, mcb_buf, 64 * 1024);
    close(fd);
    print("Read ");
    print_int(mcb_size);
    print(" bytes from factorial.mcb\n");

    out.bin_data = 0; out.bin_size = 0;
    out.mc_data  = 0; out.mc_size  = 0;
    rc = compile_main(0, mcb_buf, mcb_size, 0, &out);
    if (rc != 0) {
        print("compile failed\n");
        return 1;
    }
    print("Compiled to ");
    print_int(out.bin_size);
    print(" bytes of PIC shellcode\n");

    print("Running... ");
    rc = load_and_run_bin(out.bin_data, out.bin_size, 0, 0);
    print("returned ");
    print_int(rc);
    print("\n");
    return 0;
}
