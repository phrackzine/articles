#include "../../../compiler/backend/stdlib.mc"

int square(int x) { return x * x; }
int cube(int x)   { return x * x * x; }

int apply(int fn, int v) {
    int result;
    result = fn(v);
    return result;
}

int main() {
    int sq;
    int cb;
    init_io();

    sq = &square;
    cb = &cube;

    print_int(apply(sq, 5));
    print("\n");
    print_int(apply(cb, 5));
    print("\n");
    return 0;
}
