#include "../../../compiler/backend/stdlib.mc"

struct Point {
    int x;
    int y;
};

void point_print(struct Point* p) {
    print("(");
    print_int(p->x);
    print(", ");
    print_int(p->y);
    print(")\n");
}

int main() {
    struct Point a;
    struct Point b;

    init_io();

    a.x = 3;
    a.y = 4;

    b.x = a.x;
    b.y = a.y;
    b.x = b.x + 10;

    point_print(&a);
    point_print(&b);
    return 0;
}
