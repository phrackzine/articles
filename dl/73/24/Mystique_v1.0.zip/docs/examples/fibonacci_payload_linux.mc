// fibonacci_payload_linux.mc - Fibonacci payload with libc externs
//
// For use as a META bundle payload on Linux. Uses stdlib's print/print_int
// (write(1, ...)) plus libc externs (getpid, clock) to test extern resolution.
// Does NOT call exit — returns result code instead (0 = success).
// Expected: prints fibonacci sequence, returns 0.

#include "../../compiler/backend/stdlib.mc"

int fibonacci(int n) {
    int a;
    int b;
    int temp;
    int i;

    if (n <= 0) { return 0; }
    if (n == 1) { return 1; }

    a = 0;
    b = 1;
    i = 2;
    while (i <= n) {
        temp = a + b;
        a = b;
        b = temp;
        i = i + 1;
    }
    return b;
}

int main() {
    int i;
    int fib;
    int checksum;
    int pid;
    int clk;

    init_io();

    pid = getpid();
    clk = clock();

    print("Fibonacci payload (Linux externs)\n");
    print("  pid=");
    print_int(pid);
    print(" clock=");
    print_int(clk);
    print("\n");

    checksum = 0;
    i = 1;
    while (i <= 20) {
        fib = fibonacci(i);
        print("  fib(");
        print_int(i);
        print(") = ");
        print_int(fib);
        print("\n");
        checksum = checksum + fib;
        i = i + 1;
    }

    print("Checksum: ");
    print_int(checksum);
    print("\n");

    if (checksum == 17710) {
        print("PASS\n");
        return 0;
    }
    print("FAIL\n");
    return 1;
}
