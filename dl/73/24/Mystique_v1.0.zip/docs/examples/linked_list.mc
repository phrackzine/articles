// Linked list example for MystC compiler

#include "../../compiler/backend/stdlib.mc"

struct Node {
    int value;
    struct Node* next;
};

struct Node* list_prepend(struct Node* head, int value) {
    struct Node* node;
    node = malloc(8);
    node->value = value;
    node->next = head;
    return node;
}

int list_sum(struct Node* head) {
    int sum;
    sum = 0;
    while (head != 0) {
        sum = sum + head->value;
        head = head->next;
    }
    return sum;
}

int main() {
    struct Node* list;
    int total;

    list = 0;
    list = list_prepend(list, 10);
    list = list_prepend(list, 20);
    list = list_prepend(list, 30);

    total = list_sum(list);
    return total;
}
