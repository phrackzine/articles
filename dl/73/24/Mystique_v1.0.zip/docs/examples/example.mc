// example.mc -- minimal demo used in the Overview.
// Returns 5 * 7 + 3 = 38 as the loader exit code.

int main() {
    int a;
    int b;
    a = 5 * 7;
    b = a + 3;
    return b;
}
