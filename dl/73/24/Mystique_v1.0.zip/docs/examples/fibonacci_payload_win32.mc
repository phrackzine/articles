// fibonacci_payload_win32.mc - Fibonacci payload with Win32 externs
//
// For use as a META bundle payload. Uses kernel32.dll externs for stdout I/O.
// Does NOT call ExitProcess — returns result code instead (0 = success).
// Expected: prints fibonacci sequence, returns 0.

extern "kernel32.dll" int GetStdHandle(int nStdHandle);
extern "kernel32.dll" int WriteFile(int handle, char* buf, int toWrite, int* written, int overlapped);
extern "kernel32.dll" int GetTickCount();

int g_stdout;

void init_io() {
    g_stdout = GetStdHandle(-11);
}

void print(char* s) {
    int len;
    int written;
    len = 0;
    while (s[len] != 0) {
        len = len + 1;
    }
    WriteFile(g_stdout, s, len, &written, 0);
}

void print_num(int n) {
    char buf[16];
    int i;
    int neg;
    int digit;

    if (n == 0) {
        print("0");
        return;
    }

    neg = 0;
    if (n < 0) {
        neg = 1;
        n = 0 - n;
    }

    i = 15;
    buf[i] = 0;
    while (n > 0) {
        i = i - 1;
        digit = n - (n / 10) * 10;
        buf[i] = digit + 48;
        n = n / 10;
    }

    if (neg != 0) {
        i = i - 1;
        buf[i] = 45;
    }

    print(&buf[i]);
}

int fibonacci(int n) {
    int a;
    int b;
    int temp;
    int i;

    if (n <= 0) { return 0; }
    if (n == 1) { return 1; }

    a = 0;
    b = 1;
    i = 2;
    while (i <= n) {
        temp = a + b;
        a = b;
        b = temp;
        i = i + 1;
    }
    return b;
}

int main() {
    int i;
    int fib;
    int checksum;
    int tick;

    init_io();

    // Call GetTickCount to exercise extern resolution
    tick = GetTickCount();

    print("Fibonacci payload (Win32 externs)\n");
    print("  tick=");
    print_num(tick);
    print("\n");

    checksum = 0;
    i = 1;
    while (i <= 20) {
        fib = fibonacci(i);
        print("  fib(");
        print_num(i);
        print(") = ");
        print_num(fib);
        print("\n");
        checksum = checksum + fib;
        i = i + 1;
    }

    print("Checksum: ");
    print_num(checksum);
    print("\n");

    // fib(1..20) checksum = 17710
    if (checksum == 17710) {
        print("PASS\n");
        return 0;
    }
    print("FAIL\n");
    return 1;
}
