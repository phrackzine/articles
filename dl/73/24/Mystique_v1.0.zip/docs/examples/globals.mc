// Test global variables
int counter = 0;
int multiplier = 10;

int increment() {
    counter = counter + 1;
    return counter;
}

int scaled_counter() {
    return counter * multiplier;
}

int main() {
    int i;
    i = 0;
    while (i < 5) {
        increment();
        i = i + 1;
    }
    return scaled_counter();
}
