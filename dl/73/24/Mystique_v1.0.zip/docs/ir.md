# IR Specification

The Mystique IR (intermediate representation) sits between the Python frontend
and the backend (C or self-hosted MC). It exists in three serialization formats:

| Extension | Format | Purpose | Consumed by |
|-----------|--------|---------|-------------|
| `.mcb` | Binary bytecode | Primary format — fast, compact, deterministic | Backend (C and MC) |
| `.mct` | Classic text IR | Assembly-style, one-to-one with bytecode | Debugging / diff |
| `.mce` | Expression text IR | C-like syntax, human-friendly | IDE display |

The frontend generates `.mcb` (and optionally `.mct` / `.mce`). The backend
only reads `.mcb`.

```bash
python -m compiler.frontend.mystcc source.mc -o source.mcb                    # binary only
python -m compiler.frontend.mystcc source.mc -o source.mcb --text source.mct  # binary + classic text
python -m compiler.frontend.mystcc source.mc -o source.mcb --expr source.mce  # binary + expression text
```

The backend can also re-serialize post-transform IR back to `.mcb` for round-trip
inspection or bundle chaining:

```bash
backend_mystc.exe in.mcb --transform-ir post.mcb \
    --ir-unfold --ir-substitute --seed 11
```

**Authoritative implementations:**
- `compiler/frontend/bytecode.py` — Python encoder, decoder, .mct/.mce writers.
- `compiler/frontend/irgen.py` — IR construction from typed AST.
- `compiler/backend/backend_mystc.c:parse_bytecode` — C-side decoder.
- `compiler/backend/backend_mystc.mc` — MC-side decoder (mirrors the C version).

---

## 1. IR Structure

The top-level shape — a Module that owns string, struct, global, and
function tables; each function owns blocks; each block owns
instructions:

```
Module
├── strings[]         Interned string literals
├── structs[]         Struct definitions (frontend metadata; backend skips)
├── globals[]         Global variables (name, type, init)
└── functions[]       Function definitions
    ├── name, return_type, params[], locals[], num_temps, dll_idx
    └── blocks[]      Basic blocks
        ├── label
        └── instructions[]
```

Struct definitions are frontend metadata only — see
[§ 2 Types](#2-types) for why the backend doesn't need them.

### General instruction shape

At the leaves of this tree are **instructions**. Almost every
instruction follows the same byte-level layout:

```
[opcode:u8]  [operand 0] [operand 1] ...  [type:u8?]
```

- **Opcode** — one byte (`OP_*`) identifying the instruction.
- **Operands** — zero or more. Each operand is a `Value`: a kind byte
  (`VK_*`) followed by a u16 index, except `VK_CONST` which carries a
  full i32 immediate. How many operands an instruction has and what
  they mean depends on the opcode.
- **Type tag** — most arithmetic and memory ops end with one byte
  (`TC_*`) giving the operand type. Control-flow and call ops omit it.

A handful of opcodes carry extra non-Value data — block indices for
jumps, byte counts for `EMIT`, struct field offsets for `FIELDPTR` —
in formats specific to each one. The exact wire format of every
opcode is tabulated in [§ 6.7](#67-instruction-encoding-per-opcode).

The remaining sections describe each piece of this layout: the four
primitive types ([§ 2](#2-types)), how operands are encoded
([§ 3](#3-values-operands)), the instruction set
([§ 4](#4-instruction-set)), and the byte-level layout of the whole
`.mcb` file ([§ 6](#6-binary-format-mcb)).

---

## 2. Types

The IR is **type-erased to four primitives** — the frontend resolves struct
sizes/offsets and decays arrays to pointers before emission. The backend never
sees a struct or array type.

| Code | Name | Description | Size | Align | `.mce` | `.mct` |
|------|------|-------------|------|-------|--------|--------|
| `0x00` | `TC_VOID` | No value (void return) | — | — | `void` | `void` |
| `0x01` | `TC_I8` | 8-bit integer | 1 | 1 | `char` | `i8` |
| `0x02` | `TC_I32` | 32-bit integer | 4 | 4 | `int` | `i32` |
| `0x03` | `TC_PTR` | Pointer (32-bit) | 4 | 4 | `ptr` | `ptr` |

**No struct or array types in the IR.** Source-level structs and arrays
are flattened to `ptr` during irgen. Their layout — struct field offsets
and array element strides — survives only in the operands of the
instructions that access them: `FIELDPTR` carries the field's byte
offset directly, and `PTRADD` carries the array's element-stride. From
the backend's perspective, every aggregate access is just a pointer
plus a constant.

---

## 3. Values (Operands)

Every operand is encoded as `[kind:u8] [payload]`. Six kinds in active use, plus
one reserved extension code:

| Code | Name | Description | `.mce` | `.mct` |
|------|------|-------------|--------|--------|
| `0x00` | `VK_TEMP` | Temporary | `tN` | `%N` |
| `0x01` | `VK_PARAM` | Parameter | `argN` | `$N` |
| `0x02` | `VK_LOCAL` | Local stack slot | `lN` | `!N` |
| `0x03` | `VK_GLOBAL` | Global variable | `name` | `@name` |
| `0x04` | `VK_CONST` | Constant immediate (i32) | `NUMBER` | `NUMBER` |
| `0x05` | `VK_STRING` | String literal reference | `sN` | `.string:N` |
| `0x80` | `VK_TEMP_EXT` | Temp index extension (reserved) | — | — |

All payloads are a single u16 index (3 wire bytes total) except `VK_CONST`,
which carries an i32 value (5 wire bytes).

Temporaries are SSA-like in practice: `irgen.py` allocates temps from a
monotonic counter and never reassigns one, but the bytecode does not formally
enforce single-assignment. The backend's regalloc treats each temp as having a
single live range.

Index fields are u16 throughout — temps can run up to ~65k per function (the
practical limit is much lower, capped by the backend's tables at ~4096).

---

## 4. Instruction Set

Format: `[DEST =] OPCODE [ARGS...] [TYPE]`.

Opcode numbers are stable — reordering breaks every cached `.mcb` in the tree.
Authoritative source: `compiler/frontend/bytecode.py:OPCODES`.

### Constants & Copies (`0x00–0x0F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x00` | `OP_NOP` | No operation | `nop` | `nop` |
| `0x01` | `OP_CONST` | Load immediate | `t0 = 42` | `%0 = const 42 i32` |
| `0x02` | `OP_COPY` | Copy value | `t1 = t0` | `%1 = copy %0 i32` |

### Arithmetic (`0x10–0x1F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x10` | `OP_ADD` | Addition | `t2 = t0 + t1` | `%2 = add %0 %1 i32` |
| `0x11` | `OP_SUB` | Subtraction | `t2 = t0 - t1` | `%2 = sub %0 %1 i32` |
| `0x12` | `OP_MUL` | Multiplication | `t2 = t0 * t1` | `%2 = mul %0 %1 i32` |
| `0x13` | `OP_DIV` | Signed division | `t2 = t0 / t1` | `%2 = div %0 %1 i32` |
| `0x14` | `OP_MOD` | Signed modulo | `t2 = t0 % t1` | `%2 = mod %0 %1 i32` |
| `0x15` | `OP_NEG` | Negate | `t1 = -t0` | `%1 = neg %0 i32` |

### Bitwise (`0x20–0x2F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x20` | `OP_AND` | AND | `t2 = t0 & t1` | `%2 = and %0 %1 i32` |
| `0x21` | `OP_OR` | OR | `t2 = t0 \| t1` | `%2 = or %0 %1 i32` |
| `0x22` | `OP_XOR` | XOR | `t2 = t0 ^ t1` | `%2 = xor %0 %1 i32` |
| `0x23` | `OP_NOT` | NOT | `t1 = ~t0` | `%1 = not %0 i32` |
| `0x24` | `OP_SHL` | Shift left | `t2 = t0 << t1` | `%2 = shl %0 %1 i32` |
| `0x25` | `OP_SHR` | Shift right (arithmetic) | `t2 = t0 >> t1` | `%2 = shr %0 %1 i32` |

### Comparison (`0x30–0x3F`)

All comparisons produce `i32` (0 or 1).

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x30` | `OP_EQ` | Equal | `t2 = (t0 == t1)` | `%2 = eq %0 %1 i32` |
| `0x31` | `OP_NE` | Not equal | `t2 = (t0 != t1)` | `%2 = ne %0 %1 i32` |
| `0x32` | `OP_LT` | Less than | `t2 = (t0 < t1)` | `%2 = lt %0 %1 i32` |
| `0x33` | `OP_LE` | Less or equal | `t2 = (t0 <= t1)` | `%2 = le %0 %1 i32` |
| `0x34` | `OP_GT` | Greater than | `t2 = (t0 > t1)` | `%2 = gt %0 %1 i32` |
| `0x35` | `OP_GE` | Greater or equal | `t2 = (t0 >= t1)` | `%2 = ge %0 %1 i32` |

### Memory (`0x40–0x4F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x40` | `OP_LOAD` | Load from address | `t1 = *t0` | `%1 = load %0 i32` |
| `0x41` | `OP_STORE` | Store to address | `*t0 = t1` | `store %0 %1 i32` |
| `0x42` | `OP_ADDR` | Address of local/global | `t1 = &l0` | `%1 = addr !0` |
| `0x43` | `OP_PTRADD` | Pointer arithmetic (scaled) | `t2 = t0 + t1*4` | `%2 = ptradd %0 %1 4` |
| `0x44` | `OP_FIELDPTR` | Struct field offset | `t1 = t0 + 8` | `%1 = fieldptr %0 8` |
| `0x45` | `OP_ALLOCA` | Stack allocation | `t0 = alloca(100, 4)` | `%0 = alloca 100 4` |

In `.mce`, `ptradd` with stride=1 omits the multiplier: `t0 + t1`.

### Control Flow (`0x50–0x5F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x50` | `OP_JMP` | Unconditional jump | `goto loop` | `jmp .loop` |
| `0x51` | `OP_JZ` | Jump if zero | `if (!t0) goto else` | `jz %0 .else` |
| `0x52` | `OP_JNZ` | Jump if not zero | `if (t1) goto body` | `jnz %1 .body` |

Jump targets are u16 block indices (binary) or label names (text).

### Calls & Functions (`0x60–0x6F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x60` | `OP_CALL` | Direct call, return value | `t2 = add(t0, t1)` | `%2 = call @add %0 %1 i32` |
| `0x61` | `OP_CALLV` | Direct call, void | `print(t0)` | `call @print %0` |
| `0x62` | `OP_RET` | Return with value | `return t0` | `ret %0` |
| `0x63` | `OP_RETV` | Return void | `return` | `ret` |
| `0x64` | `OP_ICALL` | Indirect call, return value | `t2 = (*tptr)(t0)` | `%2 = icall %ptr %0 i32` |
| `0x65` | `OP_ICALLV` | Indirect call, void | `(*tptr)(t0)` | `icall %ptr %0` |
| `0x66` | `OP_FUNC_ADDR` | Take address of a function | `t1 = &main` | `%1 = func_addr @main` |
| `0x67` | `OP_SYSCALL` | Linux `INT 0x80` (6 fixed args) | `t5 = syscall(n, a, b, c, d, e)` | `%5 = syscall %n %a %b %c %d %e` |

The indirect call ops (`OP_ICALL`, `OP_ICALLV`) and `OP_FUNC_ADDR` are what make
the runtime API table and bundle architecture possible: a bundle's entry can
take `&compile_main`, store it in a slot, and call through it later.

### Inline Bytes (`0x70–0x7F`)

| Opcode | Name | Description | `.mce` | `.mct` |
|--------|------|-------------|--------|--------|
| `0x70` | `OP_EMIT` | Emit raw x86 bytes | `emit(0x90, 0xeb, 0x00)` | `emit 0x90 0xEB 0x00` |

`emit` is copied verbatim into the x86 output. No register allocation,
unaffected by transforms.

MystC source syntax: `emit 0x90, 0xEB, 0x00;`.

Each operand encodes as `[kind:u8] [u16 index]` (3 bytes) — except
`VK_CONST`, which inlines its `i32` immediate instead (5 bytes); see
[§ 3](#3-values-operands). Per-opcode wire formats are tabulated in
[§ 6.7](#67-instruction-encoding-per-opcode), with worked byte traces
in [§ 6.8](#68-encoding-examples).

---

## 5. The API table

External functions (anything declared `extern`) are not called by name at
runtime — they're called through an indexed **API table**. The backend assigns
each extern an `api_slot` at parse time; the assembled `.bin` then calls
`call [EBX + api_slot*4]` (PIC mode) or the equivalent IAT entry for PE/ELF
standalone.

### Slot assignment

The backend's slot policy is in `backend_mystc.c` (search for the
`api_slot` assignment loop). Slots 0–6 are fixed for the seven
runtime-helper names; user externs are assigned slots starting at
**8** (slot 7 is intentionally reserved/unused):

| Slot | Reserved name | Purpose |
|------|---------------|---------|
| 0 | `malloc` | Heap allocator |
| 1 | `free` | Heap deallocator |
| 2 | `read` | Read from file descriptor / handle |
| 3 | `write` | Write to file descriptor / handle |
| 4 | `open` | Open file |
| 5 | `close` | Close file |
| 6 | `exit` | Process exit |
| 7 | *(reserved)* | Currently unused; left empty in `extern_info` |
| 8+ | (user externs) | Assigned in declaration order, e.g. `WriteFile`, `LoadLibraryA`, `getpid`, … |

A user-defined function (one with `block_count > 0`) gets `api_slot = i` (its
function-table index) — the api_slot field on user functions is unused for
dispatch but still set for symmetry. Only externs use the API table.

### Wire format (`extern_info`)

`extern_info` is the byte buffer the backend writes after the code+data
sections of a `.bin` so the loader can resolve every slot at runtime:

```
[extern_count:u32]            # = max(api_slot) + 1
for slot = 0..extern_count-1:
    [dll_name\0]              # empty string if no DLL
    [func_name\0]             # empty string if slot is reserved/unused
```

One entry per slot — including reserved slot 7 — so the loader can index by
slot directly. Empty slots get empty names (`"" "\0" "" "\0"`). The Win32
loader limits the table to 64 entries (`MAX_EXTERNS`); the Linux loader has the
same cap.

### Runtime resolution

Both reference loaders (`compiler/loaders/loader_{win32,linux}.c`) resolve all
externs **by name**, not by hardcoded pointer. For each non-empty slot:

- If the function name matches one of the seven runtime-helper names
  (`malloc`, `free`, `read`, `write`, `open`, `close`, `exit`), the loader
  installs its own cdecl wrapper that bridges to the host (kernel32 on
  Windows; raw syscalls on Linux).
- Otherwise, if `dll_name` is non-empty, the loader resolves the function
  via `LoadLibraryA` + `GetProcAddress` (Win32) or `dlopen` + `dlsym` (Linux).
- Otherwise the slot stays NULL.

This means the backend never hardcodes a builtin function pointer — every
extern is just a name, and *every* slot is filled by the same name-resolution
pass at load time. The seven reserved slots are special only in that the
backend always assigns them to a fixed numeric position; their resolution
mechanism is identical to user externs.

For PE/ELF standalone outputs, the reserved-name wrappers don't apply — the
backend writes a real Win32 IAT (PE) or inlined `INT 0x80` syscall stubs
(ELF), so `malloc` / `free` resolve directly to kernel32 functions or to
`mmap2`/`brk` syscall sequences.

---

## 6. Binary Format (`.mcb`)

### 6.1 File Layout

```
┌──────────────────────────────────────────────┐
│  Header (16 bytes)                           │
├──────────────────────────────────────────────┤
│  String Table                                │
├──────────────────────────────────────────────┤
│  Global Variables                            │
├──────────────────────────────────────────────┤
│  Functions                                   │
│  ├── Function metadata                       │
│  ├── Param types                             │
│  ├── Local types + sizes                     │
│  └── Blocks[]                                │
│      ├── Block header                        │
│      └── Instructions[]                      │
└──────────────────────────────────────────────┘
```

All multi-byte values are **little-endian**. The struct table is
frontend-only metadata; see [§ 2 Types](#2-types) for the backend's
read-and-skip behavior.

### 6.2 Header (16 bytes)

```
Offset  Size  Field           Description
0x00    4     magic           "MCBN" (bytes 0x4D 0x43 0x42 0x4E)
0x04    2     version         Format version (currently 1)
0x06    1     target          Target arch: 1 = x86-32, 2 = x86-64 (reserved)
0x07    1     flags           Reserved — currently always 0
0x08    2     num_strings     Number of string literals
0x0A    2     num_structs     Number of struct definitions (frontend-only metadata)
0x0C    2     num_globals     Number of global variables
0x0E    2     num_functions   Number of functions (extern + user-defined)
```

The `flags` byte at offset 7 is reserved — the format does not currently store
any flags here. The backend's CF_* compile flags (`CF_EMIT_MC`, `CF_ABS_PE`,
`CF_CDECL_EXTERNS`, etc., declared near the top of `backend_mystc.mc`
just below `struct CompileOutput`) are runtime arguments passed to
`compile_main()`, not fields in the `.mcb` header.

If `num_structs > 0`, a struct table follows the string table. Each entry is
`[name_idx:u16][size:u16][align:u8][field_count:u8]` followed by per-field
records `[name_idx:u16][type_code:u8][offset:u16]`. The frontend writes this
table whenever the source declares structs; the backend reads-and-skips it
because struct field offsets are already encoded in `FIELDPTR` instructions.

### 6.3 String Table

```
[total_size:u32]              # Total size of string data in bytes
[offset_0:u32]                # Per-string byte offsets relative to string data
[offset_1:u32]
...
[offset_n-1:u32]
[string_0_data][0x00]         # Null-terminated UTF-8
[string_1_data][0x00]
...
```

If `num_strings == 0`, only `total_size = 0` is written; no offset table or
data follows.

### 6.4 Global Variables (8 bytes each)

```
[name_idx:u16]                # String table index of variable name
[type_code:u8]                # Type (0–3, see Section 2)
[init_kind:u8]                # 0 = zero, 1 = const, 2 = string ref
[init_value:i32]              # Constant value, or string index, or 0
```

### 6.5 Functions

Function metadata header, variable size:

```
[name_idx:u16]                # String table index
[return_type:u8]              # Type code
[param_count:u8]
[local_count:u8]
[block_count:u16]             # 0 = extern declaration (no body)
[num_temps:u16]               # Highest temp index + 1
[dll_idx:u16]                 # String index of DLL name (0 = no DLL)
[param_types:u8 × param_count]
[local_records:(u8,u16) × local_count]    # type_code, size_in_bytes
[blocks: variable]
```

Externs have `block_count = 0` and no following block data.

### 6.6 Blocks

```
[label_idx:u16]               # String table index (e.g. "entry", "loop_test")
[instr_count:u16]
[instructions:variable]
```

### 6.7 Instruction Encoding (per opcode)

Operand sizes follow Section 3 (3 or 5 bytes per operand).

| Opcode | Wire format |
|--------|-------------|
| `nop` | `[op:u8]` |
| `const` | `[op:u8] [dest:val] [imm:i32] [type:u8]` |
| `copy` | `[op:u8] [dest:val] [src:val] [type:u8]` |
| binary op (`add`–`ge`) | `[op:u8] [dest:val] [arg1:val] [arg2:val] [type:u8]` |
| unary op (`neg`, `not`) | `[op:u8] [dest:val] [src:val] [type:u8]` |
| `load` | `[op:u8] [dest:val] [addr:val] [type:u8]` |
| `store` | `[op:u8] [addr:val] [value:val] [type:u8]` |
| `addr` | `[op:u8] [dest:val] [loc_kind:u8] [idx_lo:u8] [idx_hi:u8?]` |
| `ptradd` | `[op:u8] [dest:val] [base:val] [offset:val] [elem_size:u16]` |
| `fieldptr` | `[op:u8] [dest:val] [base:val] [offset:u16]` |
| `alloca` | `[op:u8] [dest:val] [size:u16] [align:u8]` |
| `jmp` | `[op:u8] [block_idx:u16]` |
| `jz`, `jnz` | `[op:u8] [cond:val] [block_idx:u16]` |
| `call` | `[op:u8] [dest:val] [func_idx:u16] [nargs:u8] [args:val × nargs]` |
| `callv` | `[op:u8] [func_idx:u16] [nargs:u8] [args:val × nargs]` |
| `icall` | `[op:u8] [dest:val] [fnptr:val] [nargs:u8] [args:val × nargs]` |
| `icallv` | `[op:u8] [fnptr:val] [nargs:u8] [args:val × nargs]` |
| `func_addr` | `[op:u8] [dest:val] [func_idx:u16]` |
| `syscall` | `[op:u8] [dest:val] [arg0:val] … [arg5:val]` (6 fixed args) |
| `ret` | `[op:u8] [val:val]` |
| `retv` | `[op:u8]` |
| `emit` | `[op:u8] [count:u8] [bytes:u8 × count]` |

For `addr`, `loc_kind` is `0x00` for LOCAL (followed by one u8 index) or
`0x01` for GLOBAL (followed by two bytes: lo, hi).

### 6.8 Encoding Examples

**`%3 = add %1 %2 i32`** — register-style binary op:
```
10                      opcode = add
00 03 00                dest    = TEMP %3
00 01 00                arg1    = TEMP %1
00 02 00                arg2    = TEMP %2
02                      type    = i32
```

**`%0 = const 42 i32`** — load immediate:
```
01                      opcode = const
00 00 00                dest   = TEMP %0
2A 00 00 00             imm    = 42 (LE)
02                      type   = i32
```

**`jz %1 .else` (block index 2):**
```
51                      opcode = jz
00 01 00                cond   = TEMP %1
02 00                   target = block 2 (LE u16)
```

**`%2 = call @factorial %1 i32` (function 0, 1 arg):**
```
60                      opcode = call
00 02 00                dest   = TEMP %2
00 00                   func   = function 0
01                      nargs  = 1
00 01 00                arg0   = TEMP %1
```

---

## 7. Classic Text Format (`.mct`)

Assembly-style, one-to-one with bytecode. Line-based, whitespace-separated
tokens. Generated by `bytecode.py:write_text`.

### 7.1 Lexical Elements

```
TEMP     %N          Temporary (e.g., %0, %12)
PARAM    $N          Parameter (e.g., $0, $1)
LOCAL    !N          Local stack slot (e.g., !0)
GLOBAL   @name       Global variable
STRING   .string:N   String literal reference
TYPE     i8 | i32 | ptr | void
COMMENT  # ...       Line comment
```

### 7.2 Directives

```
.version 1                         Format version
.target x86-32                     Target architecture

.string 0 "Hello\n"                String literal at index 0

.global @counter i32 0             Global: name, type, init_value
.global @msg ptr 0                 Pointer global (init_value here is the
                                   string-table index when init_kind=2,
                                   plain integer otherwise)

.func @add $0:i32 $1:i32 -> i32    Function: name, params, return type
    .local !0 i32                  Local variable
.entry:                            Block label
    %0 = add $0 $1 i32             Instruction
    ret %0
.end
```

### 7.3 Complete Example

```
.version 1
.target x86-32

.string 0 "Hello, world!\n"

.global @counter i32 0

.func @add $0:i32 $1:i32 -> i32
.entry:
    %0 = add $0 $1 i32
    ret %0
.end

.func @main -> i32
.entry:
    %0 = const 5 i32
    %1 = const 3 i32
    %2 = call @add %0 %1 i32
    ret %2
.end
```

### 7.4 Generation

```bash
# CLI
python -m compiler.frontend.mystcc source.mc -o source.mcb --text source.mct

# Programmatic (used by ide/)
from compiler.frontend.bytecode import read_bytecode, write_text
program = read_bytecode("source.mcb")
write_text(program, "source.mct")
```

---

## 8. Expression Text Format (`.mce`)

C-like syntax for human readability. Generated by `bytecode.py:write_expr`.
Used by the IDE for display.

### 8.1 Syntax Summary

```
str s0 = "Hello\n"                           String literal

global counter: int = 0                      Global variable

extern ptr malloc(int arg0);  // dll: ""
extern int WriteFile(int arg0, ptr arg1, int arg2, ptr arg3, ptr arg4);
                                              // dll: "kernel32.dll"

int add(int arg0, int arg1) {                Function definition
    int l0;                                  Local (scalar)
    char l1[256];                            Local (array)

  entry:                                     Block label
    t0 = arg0 + arg1                         Instruction
    return t0
}
```

### 8.2 Differences from `.mct`

- Types are omitted from instruction lines (implicit from operand types).
- Operators use C symbols (`+`, `-`, `*`, `==`, `&`, …).
- `jmp .label` becomes `goto label`.
- `jz %0 .label` becomes `if (!t0) goto label`.
- `%2 = call @add %0 %1 i32` becomes `t2 = add(t0, t1)`.
- `load` / `store` become `*t0` / `*t0 = t1`.
- `addr` becomes `&l0`.
- `ptradd` with stride=1 omits the multiplier.

### 8.3 Generation

```bash
# CLI
python -m compiler.frontend.mystcc source.mc -o source.mcb --expr source.mce

# Programmatic (used by ide/)
from compiler.frontend.bytecode import read_bytecode, expr_ir_text
program = read_bytecode("source.mcb")
mce_text = expr_ir_text(program)
```

---

## 9. Inspecting `.mcb`

The frontend's `--text` / `--expr` flags (shown at the top of this
doc) only produce sidecars during `.mc → .mcb` compilation. The
backend's `--transform-ir` output is a `.mcb` with no sidecars, and
`mystcc` won't take a `.mcb` as input. For that, use
`utils/mcb2text.py` — it reads an existing `.mcb` through the same
decoder the frontend uses internally and writes the requested text
sidecars:

```bash
# Label-style (.mct)
python utils/mcb2text.py post.mcb --text post.mct

# Expression-style (.mce)
python utils/mcb2text.py post.mcb --expr post.mce

# Both at once
python utils/mcb2text.py post.mcb --text post.mct --expr post.mce
```

A typical workflow — see exactly what a transform did to the IR:

```bash
# 1. Frontend → fresh .mcb + .mct
python -m compiler.frontend.mystcc src.mc -o src.mcb --text src.mct

# 2. Backend → post-transform .mcb
backend_mystc.exe src.mcb --transform-ir post.mcb \
    --ir-unfold --ir-substitute --seed 11

# 3. Convert post-transform .mcb to text
python utils/mcb2text.py post.mcb --text post.mct --expr post.mce

# 4. Diff
diff src.mct post.mct
```

`mcb2text.py` is a thin wrapper around
`compiler.frontend.bytecode.{read_bytecode, write_text, write_expr}` —
the same reader and writers `mystcc` uses, so the text it produces is
byte-identical to the frontend's own `--text` / `--expr` output for the
same IR.

For the compiled `.bin` (after backend transforms + codegen), use
`utils/disasm.py` instead — it disassembles the x86-32 output, with a
`--json` mode the IDE consumes.

---

## 10. Worked Example: Factorial

### Source

```c
int factorial(int n) {
    if (n <= 1) { return 1; }
    return n * factorial(n - 1);
}

int main() {
    return factorial(5);
}
```

### Classic Text IR (`.mct`)

```
.version 1
.target x86-32

.func @factorial $0:i32 -> i32
.entry:
    %0 = const 1 i32
    %1 = le $0 %0 i32
    jz %1 .recurse
.base:
    %2 = const 1 i32
    ret %2
.recurse:
    %3 = const 1 i32
    %4 = sub $0 %3 i32
    %5 = call @factorial %4 i32
    %6 = mul $0 %5 i32
    ret %6
.end

.func @main -> i32
.entry:
    %0 = const 5 i32
    %1 = call @factorial %0 i32
    ret %1
.end
```

### Annotated Binary (`.mcb`)

```
Offset  Bytes                           Description
──────  ─────                           ───────────
                                        ── HEADER ──
0x0000  4D 43 42 4E                     Magic "MCBN"
0x0004  01 00                           Version 1
0x0006  01                              Target: x86-32
0x0007  00                              Flags: 0
0x0008  05 00                           5 strings
0x000A  00 00                           0 structs (always)
0x000C  00 00                           0 globals
0x000E  02 00                           2 functions

                                        ── STRING TABLE ──
0x0010  ...                             "factorial", "main", "entry", "base", "recurse"

                                        ── FUNCTION 0: factorial ──
        ...  00 00                      Name: string 0 ("factorial")
             02                         Return: i32
             01                         1 param
             00                         0 locals
             03 00                      3 blocks
             07 00                      7 temps
             00 00                      dll_idx: 0 (no DLL)
             02                         Param 0: i32

                                        Block "entry" (label = string 2)
             02 00                         label_idx
             03 00                         3 instructions
             01 00 00 00 01 00 00 00 02    %0 = const 1 i32
             33 00 01 00 01 00 00 00 00 00 02   %1 = le $0 %0 i32
             51 00 01 00 02 00             jz %1 → block 2 (recurse)

                                        Block "base"
             03 00                      label_idx
             02 00                      2 instructions
             01 00 02 00 01 00 00 00 02 %2 = const 1 i32
             62 00 02 00                ret %2

                                        Block "recurse"
             04 00                      label_idx
             04 00                      4 instructions (etc.)

                                        ── FUNCTION 1: main ──
        ...  similar layout
```

(The exact byte sequence above is illustrative; for the authoritative trace
run `python -m compiler.frontend.mystcc factorial.mc -o factorial.mcb` and
inspect with `utils/mcb2text.py factorial.mcb` or a hex viewer.)

---

## 11. IR Invariants

The backend can assume (guaranteed by the frontend):

1. All types are explicit — no type inference needed.
2. All struct offsets and array strides are pre-computed — encoded into
   `FIELDPTR.offset` and `PTRADD.elem_size`.
3. Temporaries are SSA-like — each `%N` assigned exactly once in a function.
4. Control flow is reducible — loops/branches use the standard
   header/back-edge patterns.
5. All function indices in `CALL` / `CALLV` / `FUNC_ADDR` are valid — type-
   checked by the frontend.
6. All jump targets exist — every `JMP` / `JZ` / `JNZ` block index is a valid
   block in the same function.
7. `extern` functions (`block_count == 0`) are never the target of `CALL`
   from within their own body — they're dispatch-only.
