"""mcb2text — dump a .mcb bytecode file as human-readable text IR.

The frontend (`mystcc`) writes `.mcb` from `.mc` source, optionally
emitting `.mct` (label style) and/or `.mce` (expression style)
alongside it via `--text` / `--expr`. This tool is the inverse: it
reads an existing `.mcb` and writes the same `.mct` / `.mce`
sidecars.

Useful for inspecting the backend's `--transform-ir` output (the IR
after polymorphic transforms have been applied), since the frontend
won't accept a `.mcb` as input.

Usage:
    python utils/mcb2text.py post.mcb --text post.mct
    python utils/mcb2text.py post.mcb --expr post.mce
    python utils/mcb2text.py post.mcb --text post.mct --expr post.mce
"""

import argparse
import sys
from pathlib import Path

# Make the project root importable so `compiler.frontend.bytecode` resolves
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from compiler.frontend.bytecode import read_bytecode, write_text, write_expr


def main():
    p = argparse.ArgumentParser(
        description="Dump a .mcb bytecode file as text IR (.mct / .mce).",
    )
    p.add_argument("input", help="input .mcb file")
    p.add_argument("--text", metavar="OUT.mct",
                   help="write label-style IR (.mct)")
    p.add_argument("--expr", metavar="OUT.mce",
                   help="write expression-style IR (.mce)")
    args = p.parse_args()

    if not args.text and not args.expr:
        p.error("specify at least one of --text or --expr")

    program = read_bytecode(args.input)

    if args.text:
        write_text(program, args.text)
        print(f"Wrote {args.text}")
    if args.expr:
        write_expr(program, args.expr)
        print(f"Wrote {args.expr}")


if __name__ == "__main__":
    main()
