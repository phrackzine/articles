"""Generate color-coded disassembly HTML for an integrator-infected binary.

Auto-detects PE (MystiqueFall) vs ELF (LacriMystique) from the original file's
magic bytes and dispatches to the appropriate parsers. Same diff/HTML pipeline
either way: align original vs infected by Capstone instruction signatures, then
render each instruction colored by host / payload / entry-preloader region.

Usage:
    from integrator_disasm import generate_disasm_html
    html = generate_disasm_html(original_path, infected_path)
"""
import struct
import sys
from pathlib import Path

from capstone import Cs, CS_ARCH_X86, CS_MODE_32

_MD = Cs(CS_ARCH_X86, CS_MODE_32)


# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

def _sniff(path):
    """Return 'pe' or 'elf' from the file's magic bytes."""
    with open(path, "rb") as f:
        magic = f.read(4)
    if magic[:2] == b"MZ":
        return "pe"
    if magic == b"\x7fELF":
        return "elf"
    raise ValueError(f"Unknown binary format for {path}: magic={magic!r}")


# ---------------------------------------------------------------------------
# PE parsers
# ---------------------------------------------------------------------------

def _read_pe_text(pe_path):
    """Read .text section raw bytes + metadata from a PE file."""
    data = Path(pe_path).read_bytes()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    num_sec = struct.unpack_from("<H", data, e_lfanew + 6)[0]
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    entry_rva = struct.unpack_from("<I", data, e_lfanew + 24 + 16)[0]
    image_base = struct.unpack_from("<I", data, e_lfanew + 24 + 28)[0]
    sec_start = e_lfanew + 24 + opt_sz

    for i in range(num_sec):
        off = sec_start + i * 40
        name = data[off:off+8].rstrip(b"\x00")
        if name == b".text":
            rva = struct.unpack_from("<I", data, off + 12)[0]
            vsz = struct.unpack_from("<I", data, off + 8)[0]
            raw = struct.unpack_from("<I", data, off + 20)[0]
            rawsz = struct.unpack_from("<I", data, off + 16)[0]
            return {
                "bytes": data[raw:raw+rawsz],
                "rva": rva,
                "vsz": vsz,
                "entry_rva": entry_rva,
                "image_base": image_base,
            }
    return None


def _read_pe_relocs(pe_path):
    """PE .reloc table → set of .text-relative offsets needing absolute fixup."""
    data = Path(pe_path).read_bytes()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    num_sec = struct.unpack_from("<H", data, e_lfanew + 6)[0]
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    sec_start = e_lfanew + 24 + opt_sz

    text_rva = 0
    text_vsz = 0
    for i in range(num_sec):
        off = sec_start + i * 40
        name = data[off:off+8].rstrip(b"\x00")
        if name == b".text":
            text_rva = struct.unpack_from("<I", data, off + 12)[0]
            text_vsz = struct.unpack_from("<I", data, off + 8)[0]
            break

    dd_off = e_lfanew + 24 + 96 + 5 * 8
    reloc_rva = struct.unpack_from("<I", data, dd_off)[0]
    reloc_sz = struct.unpack_from("<I", data, dd_off + 4)[0]
    if reloc_rva == 0 or reloc_sz == 0:
        return set()

    reloc_raw = None
    for i in range(num_sec):
        off = sec_start + i * 40
        s_rva = struct.unpack_from("<I", data, off + 12)[0]
        s_vsz = struct.unpack_from("<I", data, off + 8)[0]
        s_raw = struct.unpack_from("<I", data, off + 20)[0]
        if reloc_rva >= s_rva and reloc_rva < s_rva + s_vsz:
            reloc_raw = s_raw + (reloc_rva - s_rva)
            break
    if reloc_raw is None:
        return set()

    reloc_offsets = set()
    pos = reloc_raw
    end = reloc_raw + reloc_sz
    while pos + 8 <= end:
        block_rva = struct.unpack_from("<I", data, pos)[0]
        block_sz = struct.unpack_from("<I", data, pos + 4)[0]
        if block_sz < 8:
            break
        n_entries = (block_sz - 8) // 2
        for j in range(n_entries):
            entry = struct.unpack_from("<H", data, pos + 8 + j * 2)[0]
            etype = entry >> 12
            eoff = entry & 0xFFF
            if etype == 3:  # HIGHLOW
                rva = block_rva + eoff
                if rva >= text_rva and rva < text_rva + text_vsz:
                    reloc_offsets.add(rva - text_rva)
        pos += block_sz

    return reloc_offsets


# ---------------------------------------------------------------------------
# ELF parsers (32-bit LSB)
# ---------------------------------------------------------------------------

def _read_elf_text(elf_path):
    """Pull executable region from an ELF.

    Mystique-built ELFs strip the section header table, so we use program
    headers (always present in executables): the PT_LOAD with PF_X is the
    text segment. For section-bearing ELFs we additionally try to find a
    section named ``.text`` whose address falls inside that segment, so the
    returned bytes are scoped to actual code rather than the entire RX
    segment (which may include ELF headers).
    """
    data = Path(elf_path).read_bytes()
    if data[:4] != b"\x7fELF" or data[4] != 1:
        return None  # not ELF32

    e_phoff, e_shoff = struct.unpack_from("<II", data, 28)
    e_phentsize, e_phnum = struct.unpack_from("<HH", data, 42)
    e_shentsize, e_shnum, e_shstrndx = struct.unpack_from("<HHH", data, 46)
    e_entry = struct.unpack_from("<I", data, 24)[0]

    # Walk PT_LOAD entries, find the executable one.
    text_off = text_vaddr = text_filesz = text_memsz = 0
    for i in range(e_phnum):
        o = e_phoff + i * e_phentsize
        p_type, p_offset, p_vaddr, _p_paddr, p_filesz, p_memsz, p_flags = \
            struct.unpack_from("<IIIIIII", data, o)
        if p_type == 1 and (p_flags & 1):  # PT_LOAD + PF_X
            text_off = p_offset
            text_vaddr = p_vaddr
            text_filesz = p_filesz
            text_memsz = p_memsz
            break
    if text_filesz == 0:
        return None

    # If section headers are present, prefer a tighter ".text" range nested
    # inside the executable segment.
    if e_shoff and e_shnum and e_shstrndx < e_shnum:
        shstr_off = struct.unpack_from(
            "<I", data, e_shoff + e_shstrndx * e_shentsize + 16)[0]
        for i in range(e_shnum):
            o = e_shoff + i * e_shentsize
            sh_name = struct.unpack_from("<I", data, o)[0]
            name_end = data.index(b"\x00", shstr_off + sh_name)
            name = data[shstr_off + sh_name:name_end]
            if name == b".text":
                _, _, _, sh_addr, sh_offset, sh_size = struct.unpack_from(
                    "<IIIIII", data, o)
                # Sanity: must overlap the executable segment.
                if (sh_addr >= text_vaddr
                        and sh_addr + sh_size <= text_vaddr + text_memsz):
                    text_off = sh_offset
                    text_vaddr = sh_addr
                    text_filesz = sh_size
                    text_memsz = sh_size
                break

    return {
        "bytes": data[text_off:text_off+text_filesz],
        "rva": text_vaddr,
        "vsz": text_memsz,
        "entry_rva": e_entry,
        "image_base": 0,
    }


def _read_elf_relocs(elf_path):
    """ELF .rel.dyn / .rel.plt → set of .text-relative offsets.

    Mystique-built static ELFs have no relocations, but a victim infected by
    LacriMystique might be PIE/dynamic. We scan SHT_REL sections (type=9) and
    collect R_386_32 (type 1) and R_386_RELATIVE (type 8) entries that land
    inside the executable region returned by _read_elf_text.
    """
    info = _read_elf_text(elf_path)
    if info is None:
        return set()
    text_vaddr = info["rva"]
    text_size = info["vsz"]

    data = Path(elf_path).read_bytes()
    e_shoff = struct.unpack_from("<I", data, 32)[0]
    e_shentsize, e_shnum = struct.unpack_from("<HH", data, 46)
    if not e_shoff or not e_shnum:
        return set()  # section table stripped

    out = set()
    for i in range(e_shnum):
        o = e_shoff + i * e_shentsize
        sh_type = struct.unpack_from("<I", data, o + 4)[0]
        if sh_type != 9:  # SHT_REL
            continue
        sh_offset, sh_size, _, _, _, sh_entsize = struct.unpack_from(
            "<IIIIII", data, o + 16)
        if sh_entsize == 0:
            continue
        n = sh_size // sh_entsize
        for j in range(n):
            r_off = sh_offset + j * sh_entsize
            r_offset, r_info = struct.unpack_from("<II", data, r_off)
            r_type = r_info & 0xff
            if r_type not in (1, 8):  # R_386_32 / R_386_RELATIVE
                continue
            if text_vaddr <= r_offset < text_vaddr + text_size:
                out.add(r_offset - text_vaddr)
    return out


# ---------------------------------------------------------------------------
# Format dispatchers
# ---------------------------------------------------------------------------

_FMT_LABEL = {"pe": "MystiqueFall", "elf": "LacriMystique"}


def _read_text(path):
    fmt = _sniff(path)
    info = _read_pe_text(path) if fmt == "pe" else _read_elf_text(path)
    if info is not None:
        info["fmt"] = fmt
    return info


def _read_relocs(path):
    fmt = _sniff(path)
    return _read_pe_relocs(path) if fmt == "pe" else _read_elf_relocs(path)


# ---------------------------------------------------------------------------
# Diff (format-agnostic)
# ---------------------------------------------------------------------------

_BRANCH_MNEMONICS = frozenset([
    "call", "jmp", "je", "jne", "jg", "jge", "jl", "jle",
    "ja", "jae", "jb", "jbe", "js", "jns", "jo", "jno",
    "jp", "jnp", "jcxz", "jecxz", "loop", "loope", "loopne",
])


def _quick_sig(code, ins, relocs):
    if ins.mnemonic in _BRANCH_MNEMONICS:
        return ins.mnemonic
    for k in range(ins.size):
        if ins.address + k in relocs:
            return f"{ins.mnemonic}:{code[ins.address]:02x}:{ins.size}"
    return f"{ins.mnemonic}:{code[ins.address]:02x}:{ins.size}:{ins.op_str}"


def _match_instructions(orig_text, inf_text, orig_relocs, inf_relocs):
    import difflib

    orig_insns = list(_MD.disasm(orig_text, 0))
    inf_insns = list(_MD.disasm(inf_text, 0))
    if not orig_insns or not inf_insns:
        return [], inf_insns

    last_decoded = inf_insns[-1].address + inf_insns[-1].size if inf_insns else 0
    pos = last_decoded
    while pos < len(inf_text):
        extra = list(_MD.disasm(inf_text[pos:], pos))
        if extra:
            inf_insns.extend(extra)
            pos = extra[-1].address + extra[-1].size
        else:
            pos += 1

    orig_seq = [_quick_sig(orig_text, i, orig_relocs) for i in orig_insns]
    inf_seq = [_quick_sig(inf_text, i, inf_relocs) for i in inf_insns]

    sm = difflib.SequenceMatcher(None, orig_seq, inf_seq, autojunk=False)
    blocks = sm.get_matching_blocks()

    is_host = [False] * len(inf_insns)
    MIN_BLOCK = 3
    for a, b, size in blocks:
        if size >= MIN_BLOCK:
            for k in range(size):
                is_host[b + k] = True

    regions = []
    if inf_insns:
        current_kind = "host" if is_host[0] else "payload"
        current_start = inf_insns[0].address
        for i in range(1, len(inf_insns)):
            kind = "host" if is_host[i] else "payload"
            if kind != current_kind:
                regions.append((current_start, inf_insns[i].address,
                                current_kind))
                current_kind = kind
                current_start = inf_insns[i].address
        last = inf_insns[-1]
        regions.append((current_start, last.address + last.size, current_kind))

    return regions, inf_insns


# ---------------------------------------------------------------------------
# HTML render
# ---------------------------------------------------------------------------

def generate_disasm_html(original_path, infected_path):
    """Generate HTML with color-coded disassembly of the infected binary.

    Auto-detects PE vs ELF from original_path and labels the page accordingly.
    """
    orig_info = _read_text(original_path)
    inf_info = _read_text(infected_path)
    if not orig_info or not inf_info:
        return "<html><body>Could not read text section</body></html>"

    fmt = orig_info["fmt"]
    engine = _FMT_LABEL.get(fmt, "Integrator")

    orig_relocs = _read_relocs(original_path)
    inf_relocs = _read_relocs(infected_path)

    regions, inf_insns = _match_instructions(
        orig_info["bytes"], inf_info["bytes"], orig_relocs, inf_relocs)

    kind_map = {}
    for start, end, kind in regions:
        for off in range(start, end):
            kind_map[off] = kind

    inf_entry_off = inf_info["entry_rva"] - inf_info["rva"]
    orig_entry_off = orig_info["entry_rva"] - orig_info["rva"]
    inf_text_bytes = inf_info["bytes"]
    if (inf_entry_off != orig_entry_off
            and 0 <= inf_entry_off < len(inf_text_bytes)):
        for off in range(inf_entry_off, len(inf_text_bytes)):
            if off in kind_map:
                kind_map[off] = "preloader"

    regions = []
    if inf_insns:
        current_kind = kind_map.get(inf_insns[0].address, "payload")
        current_start = inf_insns[0].address
        for i in range(1, len(inf_insns)):
            kind = kind_map.get(inf_insns[i].address, "payload")
            if kind != current_kind:
                regions.append((current_start, inf_insns[i].address,
                                current_kind))
                current_kind = kind
                current_start = inf_insns[i].address
        last = inf_insns[-1]
        regions.append((current_start, last.address + last.size, current_kind))

    host_bytes = sum(1 for v in kind_map.values() if v == "host")
    payload_bytes = sum(1 for v in kind_map.values() if v == "payload")
    preloader_bytes = sum(1 for v in kind_map.values() if v == "preloader")
    total = max(1, len(inf_info["bytes"]))

    host_regions = sum(1 for _, _, k in regions if k == "host")
    payload_regions = sum(1 for _, _, k in regions if k == "payload")

    text_label = ".text" if fmt == "pe" else "code"

    lines = []
    lines.append(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{engine} Disassembly Map</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    background: #1a1a2e; color: #c8c8d4; font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px; line-height: 1.5;
  }}
  #header {{
    background: #16213e; padding: 12px 20px; border-bottom: 1px solid #333;
    display: flex; align-items: center; gap: 20px; position: sticky; top: 0; z-index: 10;
  }}
  #header h1 {{ font-size: 16px; color: #e8e8f0; font-weight: 600; }}
  .legend {{ display: flex; gap: 16px; font-size: 11px; }}
  .legend-item {{ display: flex; align-items: center; gap: 4px; }}
  .legend-swatch {{ width: 12px; height: 12px; border-radius: 2px; display: inline-block; }}
  .stats {{ color: #888; font-size: 11px; margin-left: auto; }}

  #minimap {{
    position: fixed; right: 0; top: 50px; width: 60px; bottom: 0;
    background: #111; border-left: 1px solid #333; z-index: 5;
  }}
  #minimap canvas {{ width: 100%; height: 100%; }}

  #disasm {{ padding: 8px 12px; padding-right: 70px; }}
  .region-header {{
    padding: 6px 0 2px; color: #888; font-size: 10px; text-transform: uppercase;
    letter-spacing: 1px; border-top: 1px solid #2a2a3e; margin-top: 8px;
  }}
  .region-header:first-child {{ border-top: none; margin-top: 0; }}
  .ins {{ display: flex; gap: 12px; white-space: pre; }}
  .ins .addr {{ color: #666; min-width: 70px; }}
  .ins .hex {{ min-width: 200px; }}
  .ins .mnem {{ flex: 1; }}

  .ins.host .hex {{ color: #5588cc; }}
  .ins.host .mnem {{ color: #88bbee; }}
  .ins.payload .hex {{ color: #cc5555; }}
  .ins.payload .mnem {{ color: #ee8888; }}
  .ins.preloader.hex {{ color: #ccaa44; }}
  .ins.preloader.mnem {{ color: #eedd66; }}

  .col-host {{ background: #5588cc; }}
  .col-payload {{ background: #cc5555; }}
  .col-preloader {{ background: #ccaa44; }}
</style>
</head>
<body>
<div id="header">
  <h1>{engine} Disassembly</h1>
  <div class="legend">
    <span class="legend-item"><span class="legend-swatch col-host"></span>Host</span>
    <span class="legend-item"><span class="legend-swatch col-payload"></span>Payload</span>
    <span class="legend-item"><span class="legend-swatch col-preloader"></span>Entry Preloader</span>
  </div>
  <div class="stats">""")

    orig_kb = len(orig_info["bytes"]) / 1024
    inf_kb = len(inf_info["bytes"]) / 1024
    lines.append(
        f"    {text_label}: {orig_kb:.1f}KB &rarr; {inf_kb:.1f}KB | "
        f"Host: {host_bytes:,}B ({100*host_bytes//total}%) | "
        f"Payload: {payload_bytes:,}B ({100*payload_bytes//total}%) | "
        f"Preloader: {preloader_bytes:,}B | "
        f"Blocks: {host_regions} host, {payload_regions} payload")

    lines.append("""  </div>
</div>
<div id="minimap"><canvas id="minimap-canvas"></canvas></div>
<div id="disasm">""")

    text_rva = inf_info["rva"]
    prev_kind = None
    for ins in inf_insns:
        off = ins.address
        kind = kind_map.get(off, "payload")

        if kind != prev_kind:
            label = {"host": "Host Code", "payload": "Payload Code",
                     "preloader": "Entry Preloader"}[kind]
            rva_hex = f"0x{text_rva + off:08X}"
            lines.append(
                f'  <div class="region-header">{label} @ {rva_hex}</div>')
            prev_kind = kind

        addr_str = f"{text_rva + off:08X}"
        hex_str = " ".join(f"{b:02X}" for b in ins.bytes)
        mnem = f"{ins.mnemonic} {ins.op_str}".strip()
        mnem = mnem.replace("&", "&amp;").replace("<", "&lt;").replace(
            ">", "&gt;")
        lines.append(
            f'  <div class="ins {kind}">'
            f'<span class="addr">{addr_str}</span>'
            f'<span class="hex">{hex_str}</span>'
            f'<span class="mnem">{mnem}</span>'
            f"</div>")

    lines.append("</div>")

    lines.append("""<script>
(function() {
  const canvas = document.getElementById('minimap-canvas');
  const ctx = canvas.getContext('2d');
  const regions = [""")

    for start, end, kind in regions:
        lines.append(f'    [{start},{end},"{kind}"],')

    lines.append(f"""  ];
  const total = {total};
  function draw() {{
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    const h = canvas.height;
    const colors = {{ host: '#5588cc', payload: '#cc5555', preloader: '#ccaa44' }};
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, canvas.width, h);
    for (const [s, e, k] of regions) {{
      const y0 = (s / total) * h;
      const y1 = (e / total) * h;
      ctx.fillStyle = colors[k] || '#555';
      ctx.fillRect(2, y0, canvas.width - 4, Math.max(1, y1 - y0));
    }}
  }}
  draw();
  window.addEventListener('resize', draw);

  canvas.addEventListener('click', function(e) {{
    const frac = e.offsetY / canvas.offsetHeight;
    const targetY = frac * document.body.scrollHeight;
    window.scrollTo({{ top: targetY, behavior: 'smooth' }});
  }});
}})();
</script>""")

    lines.append("</body></html>")
    return "\n".join(lines)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <original> <infected>")
        print("Auto-detects PE / ELF; writes integrator_disasm.html in cwd.")
        sys.exit(1)
    html = generate_disasm_html(sys.argv[1], sys.argv[2])
    out = Path("integrator_disasm.html")
    out.write_text(html, encoding="utf-8")
    print(f"Written: {out} ({len(html):,} bytes)")
