#!/usr/bin/env python3
"""Quick x86-32 disassembler for .bin files from the polymorph compiler.

Usage:
    python disasm.py file.bin          # text output (original behaviour)
    python disasm.py file.bin --json   # JSON output for the visualizer
    python disasm.py file.bin -j       # same
"""
import sys
import json
import struct

REGS   = ['EAX','ECX','EDX','EBX','ESP','EBP','ESI','EDI']
REGS8  = ['AL','CL','DL','BL','AH','CH','DH','BH']
CC     = ['O','NO','B','AE','E','NE','BE','A','S','NS','P','NP','L','GE','LE','G']
ALU    = ['ADD','OR','ADC','SBB','AND','SUB','XOR','CMP']
UNARY  = ['TEST','?','NOT','NEG','MUL','IMUL','DIV','IDIV']
SHIFT  = {4:'SHL', 5:'SHR', 7:'SAR'}

def _raw(code, start, size):
    return ' '.join(f'{code[start+j]:02X}' for j in range(size))

def _instr(addr, size, code, text, is_jump=False, jump_target=None, is_ret=False, is_call=False, call_target=None):
    return {
        'offset':      addr,
        'size':        size,
        'bytes':       _raw(code, addr, size),
        'text':        text,
        'is_jump':     is_jump,
        'jump_target': jump_target,
        'is_ret':      is_ret,
        'is_call':     is_call,
        'call_target': call_target,
    }

def _sib_str(code, i, mod):
    """Decode a SIB byte at code[i]; return (mem_str, bytes_consumed_including_sib)."""
    sib   = code[i]
    scale = 1 << ((sib >> 6) & 3)   # 1 / 2 / 4 / 8
    idx   = (sib >> 3) & 7
    base  = sib & 7

    # mod==0 with base==5 → no base register; use disp32 instead
    if mod == 0 and base == 5:
        disp  = struct.unpack_from('<i', code, i+1)[0]
        extra = 5   # SIB + disp32
        base_part = f'0x{disp & 0xFFFFFFFF:08X}'
        disp  = 0
    elif mod == 1:
        disp  = struct.unpack_from('<b', code, i+1)[0]
        extra = 2   # SIB + disp8
        base_part = REGS[base]
    elif mod == 2:
        disp  = struct.unpack_from('<i', code, i+1)[0]
        extra = 5   # SIB + disp32
        base_part = REGS[base]
    else:  # mod == 0, base != 5
        disp  = 0
        extra = 1   # SIB only
        base_part = REGS[base]

    # idx==4 → no index register
    if idx == 4:
        addr = base_part
    elif scale == 1:
        addr = f'{base_part}+{REGS[idx]}'
    else:
        addr = f'{base_part}+{REGS[idx]}*{scale}'

    mem = f'[{addr}{disp:+d}]' if disp else f'[{addr}]'
    return mem, extra


def _modrm_rm_str(code, i, mod, rm):
    """Return (string representation of r/m operand, extra bytes consumed after ModRM)."""
    if mod == 3:
        return REGS[rm], 0
    if rm == 4:                    # SIB byte follows
        return _sib_str(code, i, mod)
    if mod == 0:
        if rm == 5:                # disp32 only
            disp = struct.unpack_from('<i', code, i)[0]
            return f'[0x{disp & 0xFFFFFFFF:08X}]', 4
        return f'[{REGS[rm]}]', 0
    if mod == 1:
        disp = struct.unpack_from('<b', code, i)[0]
        base = REGS[rm]
        return (f'[{base}]' if disp == 0 else f'[{base}{disp:+d}]'), 1
    # mod == 2
    disp = struct.unpack_from('<i', code, i)[0]
    base = REGS[rm]
    return (f'[{base}]' if disp == 0 else f'[{base}{disp:+d}]'), 4

def disasm_bytes(code, start=0, end=None):
    """Disassemble x86-32 code bytes, return list of instruction dicts."""
    if end is None:
        end = len(code)
    instrs = []
    i = start

    def push_instr(size, text, **kw):
        nonlocal i
        instrs.append(_instr(addr, size, code, text, **kw))
        i += size

    while i < end:
        addr = i
        b = code[i]

        # -----------------------------------------------------------------
        # 1-byte encodings
        # -----------------------------------------------------------------
        if b == 0x90:
            push_instr(1, 'NOP')
        elif b == 0x60:
            push_instr(1, 'PUSHAD')
        elif b == 0x61:
            push_instr(1, 'POPAD')
        elif b == 0xCC:
            push_instr(1, 'INT3')
        # INT imm8  (CD ib) — Linux x86-32 syscall is INT 0x80
        elif b == 0xCD:
            imm8 = code[i+1]
            label = 'INT 0x80 ; syscall' if imm8 == 0x80 else f'INT 0x{imm8:02X}'
            push_instr(2, label)
        elif b == 0xC3:
            push_instr(1, 'RET', is_ret=True)
        elif b == 0x99:
            push_instr(1, 'CDQ')
        elif b == 0x40:
            push_instr(1, 'INC EAX')
        elif b == 0x48:
            push_instr(1, 'DEC EAX')
        elif 0x40 <= b <= 0x47:
            push_instr(1, f'INC {REGS[b-0x40]}')
        elif 0x48 <= b <= 0x4F:
            push_instr(1, f'DEC {REGS[b-0x48]}')
        elif 0x50 <= b <= 0x57:
            push_instr(1, f'PUSH {REGS[b-0x50]}')
        elif 0x58 <= b <= 0x5F:
            push_instr(1, f'POP {REGS[b-0x58]}')
        # Short Jcc (7x cb)
        elif 0x70 <= b <= 0x7F:
            rel  = struct.unpack_from('<b', code, i+1)[0]
            tgt  = i + 2 + rel
            push_instr(2, f'J{CC[b-0x70]} SHORT 0x{tgt:04X}', is_jump=True, jump_target=tgt)
        # MOV reg, imm32  (B8+r)
        elif 0xB8 <= b <= 0xBF:
            reg = REGS[b-0xB8]
            imm = struct.unpack_from('<i', code, i+1)[0]
            push_instr(5, f'MOV {reg}, 0x{imm & 0xFFFFFFFF:08X}')
        # MOV r/m8, imm8  (C6 /0)
        elif b == 0xC6:
            modrm = code[i+1]; mod = (modrm>>6)&3; rm = modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            imm = code[i+2+extra]
            push_instr(3+extra, f'MOV BYTE {rm_str}, {imm}')
        # MOV r/m32, imm32 (C7 /0)
        elif b == 0xC7:
            modrm = code[i+1]; mod = (modrm>>6)&3; rm = modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            imm = struct.unpack_from('<i', code, i+2+extra)[0]
            push_instr(6+extra, f'MOV {rm_str}, 0x{imm & 0xFFFFFFFF:08X}')
        # CALL rel32
        elif b == 0xE8:
            rel = struct.unpack_from('<i', code, i+1)[0]
            tgt = i + 5 + rel
            push_instr(5, f'CALL 0x{tgt:04X}', is_call=True, call_target=tgt)
        # JMP rel32
        elif b == 0xE9:
            rel = struct.unpack_from('<i', code, i+1)[0]
            tgt = i + 5 + rel
            push_instr(5, f'JMP 0x{tgt:04X}', is_jump=True, jump_target=tgt)
        # JMP SHORT rel8
        elif b == 0xEB:
            rel = struct.unpack_from('<b', code, i+1)[0]
            tgt = i + 2 + rel
            push_instr(2, f'JMP SHORT 0x{tgt:04X}', is_jump=True, jump_target=tgt)
        # MOV r/m32, r32  (89 /r)
        elif b == 0x89:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'MOV {rm_str}, {REGS[reg]}')
        # MOV r32, r/m32  (8B /r)
        elif b == 0x8B:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'MOV {REGS[reg]}, {rm_str}')
        # LEA r32, m  (8D /r)
        elif b == 0x8D:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'LEA {REGS[reg]}, {rm_str}')
        # ALU r/m32, imm32  (81 /x id)
        elif b == 0x81:
            modrm = code[i+1]; mod=(modrm>>6)&3; op=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            imm = struct.unpack_from('<i', code, i+2+extra)[0]
            push_instr(2+extra+4, f'{ALU[op]} {rm_str}, 0x{imm & 0xFFFFFFFF:08X}')
        # ALU r/m32, imm8  (83 /x ib)
        elif b == 0x83:
            modrm = code[i+1]; mod=(modrm>>6)&3; op=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            imm = struct.unpack_from('<b', code, i+2+extra)[0]
            push_instr(2+extra+1, f'{ALU[op]} {rm_str}, {imm}')
        # ADD r/m32, r32  (01 /r)
        elif b == 0x01:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'ADD {rm_str}, {REGS[reg]}')
        # ADD r32, r/m32  (03 /r)
        elif b == 0x03:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'ADD {REGS[reg]}, {rm_str}')
        # SUB r/m32, r32  (29 /r)
        elif b == 0x29:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'SUB {rm_str}, {REGS[reg]}')
        # SUB r32, r/m32  (2B /r)
        elif b == 0x2B:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'SUB {REGS[reg]}, {rm_str}')
        # CMP r/m32, r32  (39 /r)
        elif b == 0x39:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'CMP {rm_str}, {REGS[reg]}')
        # AND r/m32, r32  (21 /r)
        elif b == 0x21:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'AND {rm_str}, {REGS[reg]}')
        # AND r32, r/m32  (23 /r)
        elif b == 0x23:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'AND {REGS[reg]}, {rm_str}')
        # OR r/m32, r32  (09 /r)
        elif b == 0x09:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'OR {rm_str}, {REGS[reg]}')
        # OR r32, r/m32  (0B /r)
        elif b == 0x0B:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'OR {REGS[reg]}, {rm_str}')
        # XOR r/m32, r32  (31 /r)
        elif b == 0x31:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'XOR {rm_str}, {REGS[reg]}')
        # XOR r32, r/m32  (33 /r)
        elif b == 0x33:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            rm_str, extra = _modrm_rm_str(code, i+2, mod, rm)
            push_instr(2+extra, f'XOR {REGS[reg]}, {rm_str}')
        # FF /x — CALL/JMP indirect, PUSH/INC/DEC r/m32
        elif b == 0xFF:
            modrm = code[i+1]; op=(modrm>>3)&7; rm=modrm&7
            if op == 2:
                push_instr(2, f'CALL {REGS[rm]}', is_call=True)
            elif op == 4:
                push_instr(2, f'JMP {REGS[rm]}', is_jump=True)
            elif op == 6:
                modrm2 = code[i+1]; mod2=(modrm2>>6)&3; rm2=modrm2&7
                if mod2 == 2:
                    disp = struct.unpack_from('<i', code, i+2)[0]
                    push_instr(6, f'PUSH [{REGS[rm2]}{disp:+d}]')
                else:
                    push_instr(2, f'PUSH [{REGS[rm]}]')
            else:
                push_instr(2, f'FF /{op} {REGS[rm]}')
        # 0F prefix
        elif b == 0x0F:
            b2 = code[i+1]
            # SYSCALL (0F 05) — x86-64; not emitted by the 32-bit backend
            if b2 == 0x05:
                push_instr(2, 'SYSCALL')
            # SYSENTER (0F 34) / SYSEXIT (0F 35)
            elif b2 == 0x34:
                push_instr(2, 'SYSENTER')
            elif b2 == 0x35:
                push_instr(2, 'SYSEXIT')
            # Long Jcc (0F 8x cd)
            elif 0x80 <= b2 <= 0x8F:
                rel = struct.unpack_from('<i', code, i+2)[0]
                tgt = i + 6 + rel
                push_instr(6, f'J{CC[b2-0x80]} 0x{tgt:04X}', is_jump=True, jump_target=tgt)
            # SETcc (0F 9x /0)
            elif 0x90 <= b2 <= 0x9F:
                modrm = code[i+2]; rm=modrm&7
                push_instr(3, f'SET{CC[b2-0x90]} {REGS8[rm]}')
            # IMUL r32, r/m32  (0F AF /r)
            elif b2 == 0xAF:
                modrm = code[i+2]; reg=(modrm>>3)&7; rm=modrm&7
                push_instr(3, f'IMUL {REGS[reg]}, {REGS[rm]}')
            # MOVZX r32, r/m8  (0F B6 /r)
            elif b2 == 0xB6:
                modrm = code[i+2]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
                if mod == 0:
                    push_instr(3, f'MOVZX {REGS[reg]}, BYTE [{REGS[rm]}]')
                elif mod == 2:
                    disp = struct.unpack_from('<i', code, i+3)[0]
                    push_instr(7, f'MOVZX {REGS[reg]}, BYTE [{REGS[rm]}{disp:+d}]')
                else:
                    push_instr(3, f'MOVZX {REGS[reg]}, {REGS8[rm]}')
            else:
                push_instr(2, f'0F {b2:02X} ...')
        # F7 — unary ops (NOT/NEG/MUL/DIV/IDIV/TEST)
        elif b == 0xF7:
            modrm = code[i+1]; op=(modrm>>3)&7; rm=modrm&7
            push_instr(2, f'{UNARY[op]} {REGS[rm]}')
        # IMUL r32, r/m32, imm8  (6B /r ib)
        elif b == 0x6B:
            modrm = code[i+1]; reg=(modrm>>3)&7; rm=modrm&7
            imm8 = struct.unpack_from('<b', code, i+2)[0]
            push_instr(3, f'IMUL {REGS[reg]}, {REGS[rm]}, {imm8}')
        # TEST r/m32, r32  (85 /r)
        elif b == 0x85:
            modrm = code[i+1]; reg=(modrm>>3)&7; rm=modrm&7
            push_instr(2, f'TEST {REGS[rm]}, {REGS[reg]}')
        # 66 prefix — 16-bit ops or 2-byte NOP
        elif b == 0x66:
            if i+1 < end and code[i+1] == 0x90:
                push_instr(2, 'NOP (2-byte)')
            else:
                push_instr(1, 'PREFIX 66')
        # Shift/rotate via CL  (D3 /x)
        elif b == 0xD3:
            modrm = code[i+1]; op=(modrm>>3)&7; rm=modrm&7
            push_instr(2, f'{SHIFT.get(op, f"D3/{op}")} {REGS[rm]}, CL')
        # Shift/rotate immediate  (C1 /x ib)
        elif b == 0xC1:
            modrm = code[i+1]; op=(modrm>>3)&7; rm=modrm&7
            imm8 = code[i+2]
            push_instr(3, f'{SHIFT.get(op, f"C1/{op}")} {REGS[rm]}, {imm8}')
        # MOV r/m8, r8  (88 /r)
        elif b == 0x88:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            if mod == 0:
                push_instr(2, f'MOV BYTE [{REGS[rm]}], {REGS8[reg]}')
            elif mod == 2:
                disp = struct.unpack_from('<i', code, i+2)[0]
                push_instr(6, f'MOV BYTE [{REGS[rm]}{disp:+d}], {REGS8[reg]}')
            else:
                push_instr(2, f'MOV BYTE mod={mod}')
        # MOV r8, r/m8  (8A /r)
        elif b == 0x8A:
            modrm = code[i+1]; mod=(modrm>>6)&3; reg=(modrm>>3)&7; rm=modrm&7
            if mod == 0:
                push_instr(2, f'MOV {REGS8[reg]}, BYTE [{REGS[rm]}]')
            elif mod == 2:
                disp = struct.unpack_from('<i', code, i+2)[0]
                push_instr(6, f'MOV {REGS8[reg]}, BYTE [{REGS[rm]}{disp:+d}]')
            else:
                push_instr(2, f'MOV {REGS8[reg]}, {REGS8[rm]}')
        # PUSH imm32 (68 id)
        elif b == 0x68:
            imm = struct.unpack_from('<i', code, i+1)[0]
            push_instr(5, f'PUSH 0x{imm & 0xFFFFFFFF:08X}')
        # PUSH imm8 (6A ib)
        elif b == 0x6A:
            imm = struct.unpack_from('<b', code, i+1)[0]
            push_instr(2, f'PUSH {imm}')
        # XCHG r32, r/m32 (87 /r) — also XCHG EAX, r32 (90+r NOP family)
        elif b == 0x87:
            modrm = code[i+1]; reg=(modrm>>3)&7; rm=modrm&7
            push_instr(2, f'XCHG {REGS[reg]}, {REGS[rm]}')
        # 3-byte NOP variants (0F 1F /0)
        elif b == 0x0F and i+1 < end and code[i+1] == 0x1F:
            modrm = code[i+2]
            push_instr(3, 'NOP (3-byte)')
        # Catch-all
        else:
            push_instr(1, f'??? (0x{b:02X})')

    return instrs


def read_bin(path):
    with open(path, 'rb') as f:
        data = f.read()
    entry            = struct.unpack_from('<I', data, 0)[0]
    code_size        = struct.unpack_from('<I', data, 4)[0]
    data_size        = struct.unpack_from('<I', data, 8)[0]
    extern_count     = struct.unpack_from('<I', data, 12)[0]
    extern_info_size = struct.unpack_from('<I', data, 16)[0]
    code         = data[20:20+code_size]
    data_section = data[20+code_size:20+code_size+data_size]
    return code, data_section, entry, code_size, data_size, extern_count


def print_text(code, data_section, entry, code_size, data_size, extern_count):
    print(f"Entry offset: {entry}")
    print(f"Code size:    {code_size}")
    print(f"Data size:    {data_size}")
    print(f"Extern count: {extern_count}")

    print(f"\n--- DATA SECTION ({data_size} bytes) ---")
    for off in range(0, len(data_section), 4):
        chunk = data_section[off:off+4]
        if len(chunk) == 4:
            val = struct.unpack_from('<i', chunk)[0]
            print(f"  {off:04X}: {' '.join(f'{b:02X}' for b in chunk)}  ({val})")
        else:
            print(f"  {off:04X}: {' '.join(f'{b:02X}' for b in chunk)}")

    print(f"\n--- CODE ({code_size} bytes, entry at 0x{entry:04X}) ---")
    instrs = disasm_bytes(code, 0, min(len(code), 4096))
    for ins in instrs:
        raw  = ins['bytes']
        text = ins['text']
        print(f"  {ins['offset']:04X}: {raw:<24s}  {text}")


def print_json(code, data_section, entry, code_size, data_size, extern_count):
    instrs = disasm_bytes(code)
    out = {
        'entry_offset': entry,
        'code_size':    code_size,
        'data_size':    data_size,
        'extern_count': extern_count,
        'instructions': instrs,
    }
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    args = sys.argv[1:]
    if not args:
        print("Usage: disasm.py <file.bin> [--json|-j]", file=sys.stderr)
        sys.exit(1)

    path    = args[0]
    as_json = '--json' in args or '-j' in args

    code, data_section, entry, code_size, data_size, extern_count = read_bin(path)

    if as_json:
        print_json(code, data_section, entry, code_size, data_size, extern_count)
    else:
        print_text(code, data_section, entry, code_size, data_size, extern_count)
