#!/usr/bin/env python3
"""
Measure polymorphic-output similarity across seeds, with multi-generation IR
feedback.

For each (mode, seed), iterates N generations: each generation compiles the
previous generation's .mcb with --transform-ir to produce next-gen .mcb AND
--pic to produce a runnable .bin. After all generations, computes pairwise
byte similarity / longest run / byte-value breakdown across the final .bin
outputs for that mode.

Reports:
  * Whole-.bin stats and .data-region-only stats.
  * For matching bytes: fraction that are 0x00, 0xFF, or "real" (neither).
  * With --scramble-both, runs the full sweep twice (frontend compile with
    and without --scramble-globals) and prints both tables.

Metric details for reproducibility:
  * Similarity is POSITIONAL: matches[i] iff a[i] == b[i]. No alignment, no
    sliding window. Length taken as min(|a|,|b|).
  * All C(seeds, 2) pairs are averaged for each mode.
  * "Longest run" is the max, across all pairs, of the longest contiguous
    stretch of positional matches.

Usage:
    python paper/measure.py <input.mc | input.mcb> [-n GENS] [-s SEEDS]
                                                   [--scramble-both]
"""

import argparse
import hashlib
import itertools
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "compiler", "backend", "backend_mystc.exe")
FRONTEND = [sys.executable, "-m", "compiler.frontend.mystcc"]

IR_FLAGS = [
    "--ir-obfuscate-names", "--ir-unfold", "--ir-substitute",
    "--ir-deadcode", "--ir-nops",
    "--ir-reorder-instrs", "--ir-reorder-locals",
    "--ir-reorder-blocks", "--ir-reorder-funcs",
]
X86_FLAGS = [
    "--x86-poly-instrs", "--x86-dead-code", "--x86-opaque",
    "--x86-junk-funcs", "--x86-harmless-calls", "--x86-shuffle-funcs",
]

MODES = {
    "no_transforms": [],
    "ir_only":       IR_FLAGS,
    "x86_only":      X86_FLAGS,
    "all":           IR_FLAGS + X86_FLAGS,
}

PIC_HEADER_SIZE = 20  # 5 x u32: entry_off, code_sz, data_sz, ext_count, ext_info_sz


# -------------------------------------------------------------------- helpers

def backend_fingerprint() -> dict:
    with open(BACKEND, "rb") as f:
        data = f.read()
    st = os.stat(BACKEND)
    return {
        "path":   os.path.relpath(BACKEND, ROOT),
        "size":   st.st_size,
        "mtime":  time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(st.st_mtime)),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def platform_fingerprint() -> dict:
    return {
        "system":  platform.system(),
        "release": platform.release(),
        "arch":    platform.machine(),
        "python":  platform.python_version(),
    }


def compile_source(src_mc: str, out_mcb: str, scramble: bool) -> None:
    """Invoke the Python frontend to lower .mc -> .mcb, optionally with
    --scramble-globals applied. Auto-detects platform for -D."""
    define = "WIN32" if sys.platform == "win32" else "LINUX"
    cmd = FRONTEND + [src_mc, "-o", out_mcb, f"-D{define}"]
    if scramble:
        cmd.append("--scramble-globals")
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    if r.returncode != 0:
        print(r.stdout, file=sys.stderr)
        print(r.stderr, file=sys.stderr)
        sys.exit(f"Frontend failed on {src_mc} (scramble={scramble})")


def evolve_one_seed(in_mcb: str, work: str, mode_flags: list,
                    seed: int, n_gens: int) -> str:
    """Run N generations of (transform-ir + pic) feedback for one seed.
    Returns the path of the final .bin."""
    cur_mcb = in_mcb
    final_bin = None
    for gen in range(1, n_gens + 1):
        next_mcb = os.path.join(work, f"gen{gen}_s{seed}.mcb")
        out_bin  = os.path.join(work, f"gen{gen}_s{seed}.bin")
        cmd = [BACKEND, cur_mcb,
               "--transform-ir", next_mcb,
               "--pic", out_bin,
               "--seed", str(seed),
               *mode_flags]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print(f"  ! seed={seed} gen={gen}: backend failed (exit {r.returncode})")
            print(r.stdout[-400:])
            print(r.stderr[-400:], file=sys.stderr)
            sys.exit(1)
        cur_mcb = next_mcb
        final_bin = out_bin
    return final_bin


def extract_data_region(bin_path: str) -> bytes:
    """Extract just the .data region from a PIC .bin (skip header + code,
    return data_sz bytes)."""
    with open(bin_path, "rb") as f:
        raw = f.read()
    code_sz = int.from_bytes(raw[4:8], "little")
    data_sz = int.from_bytes(raw[8:12], "little")
    start = PIC_HEADER_SIZE + code_sz
    return raw[start:start + data_sz]


# ---------------------------------------------------------------- statistics

def _pairwise_over(blobs: list) -> tuple:
    """Pairwise positional-byte statistics across all C(n,2) pairs.

    Returns
    -------
    (sim, longest_run, zero_of_matches, ff_of_matches, real_of_matches)

    - sim: average % of aligned positions where a[i] == b[i]
    - longest_run: max contiguous stretch of aligned matches, across all pairs
    - zero_of_matches / ff_of_matches / real_of_matches: of the MATCHING
      bytes, what fraction is 0x00, 0xFF, or neither. Averaged across pairs.
    """
    sims, longest_runs = [], []
    zero_pct, ff_pct, real_pct = [], [], []
    for a, b in itertools.combinations(blobs, 2):
        n = min(len(a), len(b))
        if n == 0:
            continue
        matches = 0
        m_zero = m_ff = m_real = 0
        run = max_run = 0
        for i in range(n):
            if a[i] == b[i]:
                matches += 1
                if a[i] == 0x00:
                    m_zero += 1
                elif a[i] == 0xFF:
                    m_ff += 1
                else:
                    m_real += 1
                run += 1
                if run > max_run:
                    max_run = run
            else:
                run = 0
        sims.append(matches / n * 100)
        longest_runs.append(max_run)
        if matches:
            zero_pct.append(m_zero / matches * 100)
            ff_pct.append(m_ff   / matches * 100)
            real_pct.append(m_real / matches * 100)
        else:
            zero_pct.append(0.0); ff_pct.append(0.0); real_pct.append(0.0)
    if not sims:
        return (0.0, 0, 0.0, 0.0, 0.0)
    return (
        sum(sims) / len(sims),
        max(longest_runs),
        sum(zero_pct) / len(zero_pct),
        sum(ff_pct)   / len(ff_pct),
        sum(real_pct) / len(real_pct),
    )


def pairwise_stats(bins: list) -> tuple:
    """Stats over whole-file bytes."""
    blobs = [open(p, "rb").read() for p in bins]
    return _pairwise_over(blobs)


def pairwise_data_stats(bins: list) -> tuple:
    """Stats over just the .data region of each PIC .bin."""
    blobs = [extract_data_region(p) for p in bins]
    return _pairwise_over(blobs)


# ---------------------------------------------------------------- sweeps

def measure(in_mcb: str, n_gens: int, n_seeds: int) -> dict:
    """For each mode, evolve `n_seeds` seeds for `n_gens` generations, then
    compute pairwise stats across the final-gen .bin outputs (whole-file
    and .data-region-only)."""
    results = {}
    for mode_name, flags in MODES.items():
        with tempfile.TemporaryDirectory(prefix=f"meas_{mode_name}_") as work:
            print(f"  [{mode_name}] evolving {n_seeds} seeds x {n_gens} gens...",
                  flush=True)
            bins = [evolve_one_seed(in_mcb, work, flags, seed, n_gens)
                    for seed in range(1, n_seeds + 1)]
            sizes = [os.path.getsize(b) for b in bins]
            data_sizes = [len(extract_data_region(b)) for b in bins]
            avg_size = sum(sizes) / len(sizes)
            avg_data_size = sum(data_sizes) / len(data_sizes)
            whole = pairwise_stats(bins)
            data  = pairwise_data_stats(bins)
        results[mode_name] = (avg_size, avg_data_size, whole, data)
    return results


# ---------------------------------------------------------------- printing

def print_methodology(fp_be: dict, fp_pl: dict, n_seeds: int, n_gens: int,
                      source_name: str) -> None:
    pairs = n_seeds * (n_seeds - 1) // 2
    print("=" * 78)
    print("Methodology")
    print("=" * 78)
    print(f"Input source   : {source_name}")
    print(f"Backend        : {fp_be['path']}")
    print(f"                 sha256={fp_be['sha256']}")
    print(f"                 size={fp_be['size']:,} B  mtime={fp_be['mtime']}")
    print(f"Platform       : {fp_pl['system']} {fp_pl['release']} "
          f"({fp_pl['arch']})  Python {fp_pl['python']}")
    print(f"Seeds          : {n_seeds}  (seeds 1..{n_seeds})")
    print(f"Generations    : {n_gens}   (per generation: prev.mcb "
          f"--transform-ir next.mcb --pic next.bin --seed S)")
    print(f"Pairs per mode : C({n_seeds},2) = {pairs}   "
          f"(total: {pairs * len(MODES)} pairwise comparisons per sweep)")
    print(f"Similarity     : POSITIONAL byte comparison (matches[i] iff "
          f"a[i]==b[i]); no alignment, no shifting")
    print(f"Length rule    : min(|a|, |b|); trailing bytes of the longer "
          f"blob are ignored")
    print(f"Longest run    : max, across all pairs, of the longest "
          f"contiguous positional match")
    print(f"Sections       : whole .bin includes 20-byte PIC header + code "
          f"+ data (no exclusions)")
    print(f"                 .data pass uses the code_sz field from the "
          f"header to skip header+code")
    print()
    print(f"IR flags       : {' '.join(IR_FLAGS)}")
    print(f"x86 flags      : {' '.join(X86_FLAGS)}")
    print()


def print_table(label: str, results: dict, n_gens: int, n_seeds: int) -> None:
    print()
    print(f"== {label} ==  (gens={n_gens}, seeds={n_seeds})")
    print("  Of the matching bytes, what fraction is 0x00, 0xFF, or neither?")
    print()
    print("  +----------------+------------------------------------------------+"
          "------------------------------------------------+")
    print("  |                |                 WHOLE .bin                     |"
          "               .data REGION ONLY                |")
    print("  | Mode           | Size    | Sim.  | Long | 0x00  | 0xFF  | Real  |"
          " Size    | Sim.  | Long | 0x00  | 0xFF  | Real  |")
    print("  |                |  (B)    | pair  | run  |  of M |  of M |  of M |"
          "  (B)    | pair  | run  |  of M |  of M |  of M |")
    print("  +----------------+---------+-------+------+-------+-------+-------+"
          "---------+-------+------+-------+-------+-------+")
    for mode in ("no_transforms", "ir_only", "x86_only", "all"):
        sz, dsz, (sim, lr, z, f, r), (dsim, dlr, dz, df, dr) = results[mode]
        print(f"  | {mode:<14s} | {sz:7,.0f} | {sim:4.1f}% | {lr:4d} | "
              f"{z:4.1f}% | {f:4.1f}% | {r:4.1f}% | "
              f"{dsz:7,.0f} | {dsim:4.1f}% | {dlr:4d} | "
              f"{dz:4.1f}% | {df:4.1f}% | {dr:4.1f}% |")
    print("  +----------------+---------+-------+------+-------+-------+-------+"
          "---------+-------+------+-------+-------+-------+")


# ------------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input", help="Input .mc source or .mcb bytecode")
    ap.add_argument("-n", "--gens", type=int, default=3,
                    help="Generations to evolve (default 3)")
    ap.add_argument("-s", "--seeds", type=int, default=20,
                    help="Seeds (default 20)")
    ap.add_argument("--scramble-both", action="store_true",
                    help="If input is a .mc source, also run the sweep with "
                         "--scramble-globals applied at the frontend and "
                         "print a second comparison table")
    args = ap.parse_args()

    if not os.path.exists(BACKEND):
        sys.exit(f"Backend not found at {BACKEND} - run `py build.py build` first")
    if not os.path.exists(args.input):
        sys.exit(f"Input not found: {args.input}")

    fp_be = backend_fingerprint()
    fp_pl = platform_fingerprint()

    is_source = args.input.endswith(".mc")
    if args.scramble_both and not is_source:
        sys.exit("--scramble-both requires a .mc source input")

    with tempfile.TemporaryDirectory(prefix="measure_fe_") as fe_work:
        if is_source:
            plain_mcb = os.path.join(fe_work, "plain.mcb")
            compile_source(args.input, plain_mcb, scramble=False)
            inputs = [("plain", plain_mcb)]
            if args.scramble_both:
                scrambled_mcb = os.path.join(fe_work, "scrambled.mcb")
                compile_source(args.input, scrambled_mcb, scramble=True)
                inputs.append(("scramble-globals", scrambled_mcb))
        else:
            inputs = [("plain", args.input)]

        print_methodology(fp_be, fp_pl, args.seeds, args.gens,
                          os.path.relpath(args.input, ROOT))

        for label, mcb_path in inputs:
            print("=" * 78)
            print(f"Sweep: {label}   ({os.path.basename(mcb_path)})")
            print("=" * 78)
            results = measure(mcb_path, args.gens, args.seeds)
            print_table(label, results, args.gens, args.seeds)
            print()


if __name__ == "__main__":
    main()
