// recomp_pe.mc — Self-recompiling PE program
// Includes the compiler library + genome mutation, adds PE builder + main entry.
// Compiled to recomp_pe.mcb, embedded in self-recompiling PE binaries.

#include "../../compiler/backend/backend_mystc.mc"
#include "recomp_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. PE Import Builder (build_idata_mc)
//   2. PE Assembly (assemble_pe_mc)
//   3. Recompilation Entry (main)
// =============================================================================

// =============================================================================
//
// PE Import Builder Module
//
// Constructs the .idata section (IDT + INT + IAT + name strings) from the
// backend's extern_info. Fills iat_abs[] with absolute IAT entry addresses
// so the loader can patch them at compile time.
//
// =============================================================================

// Build .idata section from abs output's extern_info.
// Returns idata buffer. Fills iat_abs[import_idx] = absolute IAT entry address.
// image_base and idata_rva must be known before calling.
struct Buffer* build_idata_mc(char* extern_info, int extern_info_sz,
                               int image_base, int idata_rva, int* iat_abs, int* out_imp_count) {
    struct Buffer* idata;
    int ext_count;
    int i;
    int j;
    char* ptr;
    char* end;
    int idt_size;
    int ilt_total;
    int iat_total;
    int ilt_start;
    int iat_start;
    int hn_start;
    char* imp_dlls[64];
    char* imp_names[64];
    int imp_dll_lens[64];
    int imp_name_lens[64];
    int imp_count;
    char* dll_name;
    char* func_name;
    int dlen;
    int flen;
    int hn_off;
    int dll_off;

    // Build import list directly from extern_info (all externs with DLL names)
    imp_count = 0;
    if (extern_info_sz > 4) {
        ext_count = read_i32(extern_info, 0);
        ptr = extern_info + 4;
        end = extern_info + extern_info_sz;
        i = 0;
        while (i < ext_count && ptr < end && imp_count < 64) {
            dll_name = ptr;
            dlen = 0;
            while (ptr < end && *ptr != 0) { ptr = ptr + 1; dlen = dlen + 1; }
            if (ptr >= end) { break; }
            ptr = ptr + 1;
            func_name = ptr;
            flen = 0;
            while (ptr < end && *ptr != 0) { ptr = ptr + 1; flen = flen + 1; }
            if (ptr >= end) { break; }
            ptr = ptr + 1;
            // Skip empty entries and libc imports
            if (dlen == 0 || flen == 0) { i = i + 1; continue; }
            if (dlen >= 4 && dll_name[0] == 108 && dll_name[1] == 105 && dll_name[2] == 98 && dll_name[3] == 99) {
                i = i + 1;
                continue;
            }
            imp_dlls[imp_count] = dll_name;
            imp_dll_lens[imp_count] = dlen;
            imp_names[imp_count] = func_name;
            imp_name_lens[imp_count] = flen;
            // iat_abs maps slot (=i) to IAT address (filled below)
            iat_abs[i] = imp_count;  // stage 1: store import_idx, resolved to IAT addr below
            imp_count = imp_count + 1;
            i = i + 1;
        }
    }

    // All imports are from kernel32.dll — single DLL group
    idt_size = 40;
    ilt_total = (imp_count + 1) * 4;
    iat_total = (imp_count + 1) * 4;
    ilt_start = idt_size;
    iat_start = ilt_start + ilt_total;
    hn_start = iat_start + iat_total;

    idata = buf_new(2048);
    i = 0;
    while (i < hn_start) { buf_write_u8(idata, 0); i = i + 1; }

    // Write hint/name entries
    i = 0;
    while (i < imp_count) {
        hn_off = idata->len;
        buf_write_u16(idata, 0);
        j = 0;
        while (j < imp_name_lens[i]) { buf_write_u8(idata, imp_names[i][j]); j = j + 1; }
        buf_write_u8(idata, 0);
        if ((imp_name_lens[i] + 1) % 2 != 0) { buf_write_u8(idata, 0); }

        write_i32(idata->data, ilt_start + i * 4, idata_rva + hn_off);
        write_i32(idata->data, iat_start + i * 4, idata_rva + hn_off);
        i = i + 1;
    }

    // Now fill iat_abs with actual absolute IAT addresses (overwrite temp import_idx)
    // We stored iat_abs[slot] = import_idx above; now convert to absolute address
    if (extern_info_sz > 4) {
        ext_count = read_i32(extern_info, 0);
        i = 0;
        while (i < ext_count) {
            if (iat_abs[i] >= 0 && iat_abs[i] < imp_count) {
                iat_abs[i] = image_base + idata_rva + iat_start + iat_abs[i] * 4;
            }
            i = i + 1;
        }
    }

    // DLL name string
    dll_off = idata->len;
    j = 0;
    while (j < 12) { buf_write_u8(idata, "kernel32.dll"[j]); j = j + 1; }
    buf_write_u8(idata, 0);

    // IDT entry
    write_i32(idata->data, 0, idata_rva + ilt_start);
    write_i32(idata->data, 12, idata_rva + dll_off);
    write_i32(idata->data, 16, idata_rva + iat_start);

    *out_imp_count = imp_count;
    return idata;
}


// =============================================================================
//
// PE Assembly Module
//
// Glues compiled code + data + .idata into a full PE32 image (DOS header,
// PE/COFF headers, section table, three sections: .text, .data, .idata).
//
// =============================================================================

// Assemble a complete PE from components.
// Returns malloc'd buffer with the full PE. Sets *out_size.
char* assemble_pe_mc(char* code, int code_size, struct Buffer* wrappers,
                      char* data, int data_size,
                      struct Buffer* idata, int entry_offset, int* out_size) {
    int image_base;
    int section_align;
    int file_align;
    int text_rva;
    int data_rva;
    int idata_rva;
    int header_size;
    int total_text;
    int text_raw;
    int data_raw;
    int idata_raw;
    int image_size;
    int pe_size;
    char* pe;
    int wp;
    int i;
    int iat_start;
    int iat_total;

    image_base = 0x00400000;
    section_align = 0x1000;
    file_align = 0x200;
    text_rva = 0x1000;
    header_size = 0x200;

    total_text = code_size + wrappers->len;
    text_raw = align_up(total_text, file_align);
    data_raw = align_up(data_size, file_align);
    if (data_raw == 0) { data_raw = file_align; }
    idata_raw = align_up(idata->len, file_align);
    data_rva = text_rva + align_up(total_text, section_align);
    idata_rva = data_rva + align_up(data_size, section_align);
    if (data_size == 0) { idata_rva = data_rva + section_align; }
    image_size = idata_rva + align_up(idata->len, section_align);

    // IAT info for data directory entries
    // IDT[0].FirstThunk = IAT RVA, read from built idata buffer
    iat_start = read_i32(idata->data, 16);
    iat_total = idata->len;

    pe_size = header_size + text_raw + data_raw + idata_raw;
    pe = malloc(pe_size);
    mem_set(pe, 0, pe_size);

    // DOS Header (64 bytes)
    pe[0] = 0x4D; pe[1] = 0x5A;  // MZ
    write_i32(pe, 0x3C, 0x40);   // e_lfanew: PE header at offset 0x40

    // PE Signature
    pe[0x40] = 0x50; pe[0x41] = 0x45; pe[0x42] = 0; pe[0x43] = 0;  // PE\0\0

    // COFF Header (20 bytes at offset 68)
    write_i16(pe, 68, 0x014C);   // Machine: i386
    write_i16(pe, 70, 3);        // NumSections
    write_i16(pe, 84, 0xE0);     // OptHdrSize
    write_i16(pe, 86, 0x0102);   // Characteristics

    // Optional Header (224 bytes at offset 88)
    wp = 88;
    write_i16(pe, wp, 0x010B);                     // PE32 magic
    write_i32(pe, wp + 4, text_raw);               // SizeOfCode
    write_i32(pe, wp + 8, data_raw + idata_raw);   // SizeOfInitializedData
    write_i32(pe, wp + 16, text_rva + entry_offset);// EntryPoint
    write_i32(pe, wp + 20, text_rva);              // BaseOfCode
    write_i32(pe, wp + 24, data_rva);              // BaseOfData
    write_i32(pe, wp + 28, image_base);            // ImageBase
    write_i32(pe, wp + 32, section_align);
    write_i32(pe, wp + 36, file_align);
    write_i16(pe, wp + 40, 6);                     // OS version
    write_i16(pe, wp + 48, 6);                     // Subsystem version
    write_i32(pe, wp + 56, image_size);
    write_i32(pe, wp + 60, header_size);
    write_i16(pe, wp + 68, 3);                     // CONSOLE
    write_i16(pe, wp + 70, 0x0100);                // NX_COMPAT
    write_i32(pe, wp + 72, 0x00100000);            // Stack reserve
    write_i32(pe, wp + 76, 0x00001000);            // Stack commit
    write_i32(pe, wp + 80, 0x00100000);            // Heap reserve
    write_i32(pe, wp + 84, 0x00001000);            // Heap commit
    write_i32(pe, wp + 92, 16);                    // NumberOfRvaAndSizes
    // DataDir[1] = Import Table
    write_i32(pe, wp + 96 + 8, idata_rva);
    write_i32(pe, wp + 96 + 12, 40);  // IDT size: 1 DLL descriptor (20) + null terminator (20)
    // DataDir[12] = IAT
    write_i32(pe, wp + 96 + 96, iat_start);        // IAT RVA (from IDT)
    write_i32(pe, wp + 96 + 100, iat_total);

    // Section Headers (at offset 88+224 = 312)
    wp = 312;
    // .text
    pe[wp] = 46; pe[wp+1] = 116; pe[wp+2] = 101; pe[wp+3] = 120; pe[wp+4] = 116; // .text
    write_i32(pe, wp + 8, total_text);
    write_i32(pe, wp + 12, text_rva);
    write_i32(pe, wp + 16, text_raw);
    write_i32(pe, wp + 20, header_size);
    write_i32(pe, wp + 36, 0x60000020);
    // .data
    wp = wp + 40;
    pe[wp] = 46; pe[wp+1] = 100; pe[wp+2] = 97; pe[wp+3] = 116; pe[wp+4] = 97; // .data
    write_i32(pe, wp + 8, data_size);
    write_i32(pe, wp + 12, data_rva);
    write_i32(pe, wp + 16, data_raw);
    write_i32(pe, wp + 20, header_size + text_raw);
    write_i32(pe, wp + 36, 0xC0000040);
    // .idata
    wp = wp + 40;
    pe[wp] = 46; pe[wp+1] = 114; pe[wp+2] = 100; pe[wp+3] = 97; pe[wp+4] = 116; pe[wp+5] = 97; // .rdata
    write_i32(pe, wp + 8, idata->len);
    write_i32(pe, wp + 12, idata_rva);
    write_i32(pe, wp + 16, idata_raw);
    write_i32(pe, wp + 20, header_size + text_raw + data_raw);
    write_i32(pe, wp + 36, 0x40000040);

    // Write section data
    // .text = code + wrappers
    mem_copy(pe + header_size, code, code_size);
    mem_copy(pe + header_size + code_size, wrappers->data, wrappers->len);
    // .data
    if (data_size > 0) {
        mem_copy(pe + header_size + text_raw, data, data_size);
    }
    // .idata
    mem_copy(pe + header_size + text_raw + data_raw, idata->data, idata->len);

    *out_size = pe_size;
    return pe;
}

// =============================================================================
//
// Recompilation Entry Module
//
// Self-recompile body for the standalone PE: parses --transform flags from
// the command line, decrypts the bundle, mutates the genome, recompiles
// backend.mcb, and writes a fresh PE32 to the chosen output path.
//
// =============================================================================

int main() {
    char self_path[260];
    char out_path[260];
    char default_path[260];
    char* pay_data;
    int pay_size;
    int genome_size;
    char* genome_copy;
    struct CompileOutput out1;
    struct CompileOutput out2;
    int flags;
    int result;
    char* mc_with_genome;
    int mc_with_genome_sz;
    char* new_data;
    int bundle_area_off;
    int bundle_key;
    int j;

    init_io();

    // genome_size is consumed when laying out the gen-N+1 .data; pay_size
    // gets filled by recomp_prep_and_compile below.
    {
        int gen_sz;
        if (g_bundle_header == 0) { exit(1); return 1; }
        bundle_get(g_bundle_header, BC_GENOME, &gen_sz);
        genome_size = gen_sz;
    }

    // Get own path
    {
        int gmfn_rc;
        gmfn_rc = GetModuleFileNameA(0, self_path, 260);
        print("GMFN rc=");
        print_int(gmfn_rc);
        print(" path=");
        if (gmfn_rc > 0) { print(self_path); }
        else { print("(failed)"); }
        print("\n");
    }

    // Build default output path: <self>_new.exe (strip trailing extension)
    mem_copy(default_path, self_path, str_len(self_path) + 1);
    j = str_len(default_path) - 1;
    while (j > 0 && default_path[j] != 46) { j = j - 1; }
    if (j > 0) { default_path[j] = 0; }
    j = str_len(default_path);
    mem_copy(&default_path[j], "_new.exe", 9);

    recomp_parse_cmdline(&flags, out_path, default_path);

    print("Output: ");
    print(out_path);
    print("\nFlags: ");
    print_int(flags);
    print("\n");

    // Decrypt bundle in place + locate payload/genome for the pre-mutation
    // run. bundle_open zeroes header.key on success — the later
    // recomp_prep_and_compile call sees key=0 and skips its own decrypt.
    {
        char* pay_ptr;
        int pay_sz;
        char* gen_ptr;
        int gen_sz;
        if (bundle_open(g_bundle_header) != 0) {
            pay_ptr = bundle_get(g_bundle_header, BC_PAYLOAD, &pay_sz);
            gen_ptr = bundle_get(g_bundle_header, BC_GENOME,  &gen_sz);
            compile_and_run_payload(pay_ptr, pay_sz, gen_ptr, gen_sz);
        }
    }

    // Recompile backend (itself) with CF_ABS_PE | CF_EMIT_MC via shared prelude.
    print("--- Recompiling backend ---\n");
    result = recomp_prep_and_compile(flags | CF_ABS_PE | CF_EMIT_MC,
                                     runtime_seed(),
                                     &out1, &genome_copy,
                                     &pay_data, &pay_size);
    if (result != 0) {
        print("Failed to compile backend\n");
        exit(1);
        return 1;
    }
    print("  abs output=");
    print_int(out1.bin_size);
    print(" new mcb=");
    print_int(out1.mc_size);
    print("\n");

    // Save backend state (main() clobbers globals when compiling payload)
    {
        struct Module* saved_mod;
        int* saved_func_offsets;
        int* saved_global_offsets;
        saved_mod = g_mod;
        saved_func_offsets = g_func_offsets;
        saved_global_offsets = g_global_offsets;

        // Compile payload (if present)
        out2.bin_data = 0; out2.bin_size = 0;
        out2.mc_data = 0; out2.mc_size = 0;
        if (pay_size > 0) {
            print("--- Recompiling payload ---\n");
            mc_with_genome_sz = pay_size + genome_size;
            mc_with_genome = malloc(mc_with_genome_sz);
            mem_copy(mc_with_genome, pay_data, pay_size);
            if (genome_size > 0) { mem_copy(mc_with_genome + pay_size, genome_copy, genome_size); }
            result = compile_main(0, mc_with_genome, mc_with_genome_sz,
                                  flags | CF_ABS_PE | CF_EMIT_MC | build_flags_from_genome(genome_copy, genome_size),
                                  &out2);
            free(mc_with_genome);
        if (result != 0) { print("Failed to compile payload\n"); }
        else {
            print("  payload abs=");
            print_int(out2.bin_size);
            print("\n");
        }
    }

        // Restore backend state
        g_mod = saved_mod;
        g_func_offsets = saved_func_offsets;
        g_global_offsets = saved_global_offsets;
    }

    // --- Build next-gen PE from scratch (full PE builder) ---
    {
        int new_entry_off;
        int new_code_size;
        int new_data_size;
        int new_n_df;
        int new_n_ef;
        int new_n_cf;
        int new_n_ff;
        int new_extern_count;
        int new_extern_info_sz;
        int hdr_off;
        int df_start;
        int ef_start;
        int cf_start;
        int ff_start;
        int code_start;
        int data_start_off;
        int ei_start;
        char* new_code;
        char* new_data_compiled;
        char* new_extern_info;
        int bundle_total;
        int total_data_sz;
        int ii;
        int fix_code_off;
        int fix_data_off;
        int fix_slot;
        int abs_addr;
        int wrapper_target;
        int rel32;
        int recomp_off;
        int pay_code_size;
        int pay_data_size;
        int pay_n_df;
        int pay_n_ef;
        int pay_n_cf;
        int pay_n_ff;
        int pay_entry_off;
        char* pay_code_buf;
        char* pay_data_buf;
        int merged_code_size;
        char* merged_code;
        char* pay_mcb_out;
        int pay_mcb_out_sz;
        int ph_p;
        int pc_p;
        int pd_p;
        int image_base_v;
        int text_rva_v;
        int data_rva_v;
        int idata_rva_v;
        int iat_abs_arr[64];
        int max_slot_v;
        int total_imp_count;
        struct Buffer* new_idata;
        char* pe_buf;
        int pe_buf_sz;
        int header_align_pad;
        int header_n_desc;
        int header_total;
        int header_area_off;

        // Parse abs output (ABS_HEADER_SIZE-byte header: 9 fields)
        new_entry_off      = read_i32(out1.bin_data, 0);
        new_code_size      = read_i32(out1.bin_data, 4);
        new_data_size      = read_i32(out1.bin_data, 8);
        new_n_df           = read_i32(out1.bin_data, 12);
        new_n_ef           = read_i32(out1.bin_data, 16);
        new_n_cf           = read_i32(out1.bin_data, 20);
        new_n_ff           = read_i32(out1.bin_data, 24);
        new_extern_count   = read_i32(out1.bin_data, 28);
        new_extern_info_sz = read_i32(out1.bin_data, 32);

        hdr_off = ABS_HEADER_SIZE;
        df_start = hdr_off;
        ef_start = df_start + new_n_df * 8;
        cf_start = ef_start + new_n_ef * 8;
        ff_start = cf_start + new_n_cf * 8;
        code_start = ff_start + new_n_ff * 8;
        data_start_off = code_start + new_code_size;
        ei_start = data_start_off + new_data_size;

        new_code = out1.bin_data + code_start;
        new_data_compiled = out1.bin_data + data_start_off;
        new_extern_info = out1.bin_data + ei_start;

        // Parse payload abs output (if compiled)
        pay_code_size = 0; pay_data_size = 0; pay_n_df = 0; pay_n_ef = 0; pay_n_cf = 0; pay_n_ff = 0;
        pay_entry_off = 0; pay_code_buf = 0; pay_data_buf = 0;

        if (out2.bin_size > 0) {
            pay_entry_off = read_i32(out2.bin_data, 0);
            pay_code_size = read_i32(out2.bin_data, 4);
            pay_data_size = read_i32(out2.bin_data, 8);
            pay_n_df      = read_i32(out2.bin_data, 12);
            pay_n_ef      = read_i32(out2.bin_data, 16);
            pay_n_cf      = read_i32(out2.bin_data, 20);
            pay_n_ff      = read_i32(out2.bin_data, 24);
            ph_p = 36;
            pc_p = ph_p + pay_n_df * 8 + pay_n_ef * 8 + pay_n_cf * 8 + pay_n_ff * 8;
            pd_p = pc_p + pay_code_size;
            pay_code_buf = out2.bin_data + pc_p;
            pay_data_buf = out2.bin_data + pd_p;
        }

        // Merge code: [backend code][payload code]  (wrappers appended by assemble_pe_mc)
        merged_code_size = new_code_size + pay_code_size;
        merged_code = malloc(merged_code_size + 16);
        mem_copy(merged_code, new_code, new_code_size);
        if (pay_code_size > 0) {
            mem_copy(merged_code + new_code_size, pay_code_buf, pay_code_size);
        }

        // Build .data: [backend data][payload data][mcb][payload.mcb][genome]
        // Use recompiled payload.mcb if available
        pay_mcb_out = pay_data;
        pay_mcb_out_sz = pay_size;
        if (out2.mc_size > 0) { pay_mcb_out = out2.mc_data; pay_mcb_out_sz = out2.mc_size; }

        bundle_total = out1.mc_size + pay_mcb_out_sz + genome_size;

        // Reserve room for BundleHeader + descriptors right after the bundle
        // area. Pad to 4-alignment so int loads in bundle_open/bundle_get hit
        // aligned addresses.
        bundle_area_off = new_data_size + pay_data_size;
        header_align_pad = (4 - ((bundle_area_off + bundle_total) & 3)) & 3;
        header_n_desc = 1;                                                       // BC_CARRIER
        if (pay_mcb_out_sz > 0) { header_n_desc = header_n_desc + 1; }            // BC_PAYLOAD
        header_n_desc = header_n_desc + 1;                                       // BC_GENOME
        header_total = 32 + header_n_desc * 16;
        header_area_off = bundle_area_off + bundle_total + header_align_pad;

        total_data_sz = new_data_size + pay_data_size + bundle_total
                       + header_align_pad + header_total;
        new_data = malloc(total_data_sz + 256);
        mem_set(new_data, 0, total_data_sz + 256);
        mem_copy(new_data, new_data_compiled, new_data_size);
        if (pay_data_size > 0) {
            mem_copy(new_data + new_data_size, pay_data_buf, pay_data_size);
        }
        mem_copy(new_data + bundle_area_off, out1.mc_data, out1.mc_size);
        mem_copy(new_data + bundle_area_off + out1.mc_size, pay_mcb_out, pay_mcb_out_sz);
        mem_copy(new_data + bundle_area_off + out1.mc_size + pay_mcb_out_sz, genome_copy, genome_size);
        // Update pay_size for bundle directory
        pay_size = pay_mcb_out_sz;

        // XOR-encrypt the bundle area (carrier/payload/genome) with a fresh
        // per-generation key. bundle_open() decrypts in place on next launch.
        bundle_key = runtime_seed();
        if (bundle_key == 0) { bundle_key = 0x12345678; }
        bundle_xor(new_data + bundle_area_off, bundle_total, bundle_key);

        // Compute layout
        image_base_v = 0x00400000;
        text_rva_v = 0x1000;
        max_slot_v = 8 + new_extern_count;
        if (max_slot_v > 64) { max_slot_v = 64; }

        // Initialize IAT address array
        ii = 0;
        while (ii < 64) { iat_abs_arr[ii] = 0; ii = ii + 1; }

        // First pass: estimate layout (no wrappers — code uses CALL [IAT] directly)
        data_rva_v = text_rva_v + align_up(merged_code_size, 0x1000);
        idata_rva_v = data_rva_v + align_up(total_data_sz, 0x1000);

        // Build .idata (imports directly from extern_info, no K32 internal list)
        total_imp_count = 0;
        new_idata = build_idata_mc(new_extern_info, new_extern_info_sz,
                                    image_base_v, idata_rva_v, iat_abs_arr, &total_imp_count);

        // Recompute layout with actual sizes (no wrappers)
        {
            int act_data_rva;
            int act_idata_rva;
            act_data_rva = text_rva_v + align_up(merged_code_size, 0x1000);
            act_idata_rva = act_data_rva + align_up(total_data_sz, 0x1000);
            if (act_idata_rva != idata_rva_v) {
                free(new_idata->data); free(new_idata);
                data_rva_v = act_data_rva;
                idata_rva_v = act_idata_rva;
                ii = 0;
                while (ii < 64) { iat_abs_arr[ii] = 0; ii = ii + 1; }
                new_idata = build_idata_mc(new_extern_info, new_extern_info_sz,
                                            image_base_v, idata_rva_v, iat_abs_arr, &total_imp_count);
            }
            data_rva_v = act_data_rva;
        }

        // Resolve backend data fixups (in merged_code)
        ii = 0;
        while (ii < new_n_df) {
            fix_code_off = read_i32(out1.bin_data, df_start + ii * 8);
            fix_data_off = read_i32(out1.bin_data, df_start + ii * 8 + 4);
            abs_addr = image_base_v + data_rva_v + fix_data_off;
            write_i32(merged_code, fix_code_off, abs_addr);
            ii = ii + 1;
        }

        // Resolve backend extern fixups (CALL [IAT] — patch with absolute IAT address)
        ii = 0;
        while (ii < new_n_ef) {
            fix_code_off = read_i32(out1.bin_data, ef_start + ii * 8);
            fix_slot = read_i32(out1.bin_data, ef_start + ii * 8 + 4);
            if (fix_slot >= 0 && fix_slot < 64 && iat_abs_arr[fix_slot] != 0) {
                write_i32(merged_code, fix_code_off, iat_abs_arr[fix_slot]);
            }
            ii = ii + 1;
        }

        // Resolve payload fixups (data offsets shifted by new_data_size, code offsets shifted by new_code_size)
        if (out2.bin_size > 0 && pay_code_size > 0) {
            int pay_df_s;
            int pay_ef_s;
            pay_df_s = 36;
            pay_ef_s = pay_df_s + pay_n_df * 8;
            // Payload data fixups
            ii = 0;
            while (ii < pay_n_df) {
                fix_code_off = read_i32(out2.bin_data, pay_df_s + ii * 8);
                fix_data_off = read_i32(out2.bin_data, pay_df_s + ii * 8 + 4);
                // Payload data is at new_data_size offset in merged .data
                abs_addr = image_base_v + data_rva_v + new_data_size + fix_data_off;
                write_i32(merged_code, new_code_size + fix_code_off, abs_addr);
                ii = ii + 1;
            }
            // Payload extern fixups (CALL [IAT] — same IAT addresses)
            ii = 0;
            while (ii < pay_n_ef) {
                fix_code_off = read_i32(out2.bin_data, pay_ef_s + ii * 8);
                fix_slot = read_i32(out2.bin_data, pay_ef_s + ii * 8 + 4);
                if (fix_slot >= 0 && fix_slot < 64 && iat_abs_arr[fix_slot] != 0) {
                    write_i32(merged_code, new_code_size + fix_code_off, iat_abs_arr[fix_slot]);
                }
                ii = ii + 1;
            }
        }

        // Emit BundleHeader + descriptors. Header is plaintext; base_addr is
        // the absolute VA of the bundle area where carrier/payload/genome
        // bytes live, and key holds the XOR key written above so bundle_open()
        // decrypts in place on next-gen launch.
        {
            int hdi; int hboff;
            write_i32(new_data, header_area_off +  0, META_MAGIC);
            write_i32(new_data, header_area_off +  4, META_VERSION);
            write_i32(new_data, header_area_off +  8, header_total);
            write_i32(new_data, header_area_off + 12, header_n_desc);
            write_i32(new_data, header_area_off + 16, image_base_v + data_rva_v + bundle_area_off);
            write_i32(new_data, header_area_off + 20, bundle_total);
            write_i32(new_data, header_area_off + 24, bundle_key);
            write_i32(new_data, header_area_off + 28, 0);
            hdi = 0;
            hboff = 0;
            write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_CARRIER);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  8, out1.mc_size);
            write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
            hdi = hdi + 1; hboff = hboff + out1.mc_size;
            if (pay_size > 0) {
                write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
                write_i32(new_data, header_area_off + 32 + hdi*16 +  8, pay_size);
                write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
                hdi = hdi + 1; hboff = hboff + pay_size;
            }
            write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  8, genome_size);
            write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
        }

        // Patch g_bundle_header in new .data → absolute VA of the header
        {
            int bundle_header_goff;
            bundle_header_goff = find_global_offset_by_name("g_bundle_header");
            if (bundle_header_goff >= 0) {
                write_i32(new_data, bundle_header_goff,
                          image_base_v + data_rva_v + header_area_off);
            }
        }

        recomp_off = new_entry_off;

        // Assemble PE
        // No wrappers — code uses CALL [IAT] directly. Pass empty wrapper buffer.
        {
            struct Buffer* empty_wrappers;
            empty_wrappers = buf_new(1);
            pe_buf = assemble_pe_mc(merged_code, merged_code_size, empty_wrappers,
                                     new_data, total_data_sz, new_idata,
                                     recomp_off, &pe_buf_sz);
            free(empty_wrappers->data);
            free(empty_wrappers);
        }

        print("--- Writing next-gen PE ---\n");
        write_file(out_path, pe_buf, pe_buf_sz);
        print("Generated: ");
        print(out_path);
        print(" (");
        print_int(pe_buf_sz);
        print(" bytes)\n");

        free(pe_buf);
        free(merged_code);
        free(new_data);
        free(new_idata->data); free(new_idata);
    }


    free(genome_copy);
    if (out1.bin_data != 0) { free(out1.bin_data); }
    if (out1.mc_data != 0) { free(out1.mc_data); }
    if (out2.bin_data != 0) { free(out2.bin_data); }
    if (out2.mc_data != 0) { free(out2.mc_data); }

    print("=== Done ===\n");
    exit(0);
    return 0;
}
