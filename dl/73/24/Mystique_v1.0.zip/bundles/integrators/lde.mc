// lde.mc — Length Disassembly Engine for x86-32
//
// Decodes instruction lengths without full disassembly.
// Used by MystiqueFall (PE) and LacriMystique (ELF) for code scattering.
// Handles primary opcodes, 0F two-byte, VEX prefixes, ModRM/SIB, displacements.
//
// Depends on: mem_set (from stdlib.mc).

// =============================================================================
// File Layout
// =============================================================================
//   1. Flag bits
//   2. Globals
//   3. Helpers (lde_fill)
//   4. Table init (lde_init)
//   5. Decoder (lde)
// =============================================================================

// =============================================================================
//
// Flag Bits Module
//
// Encoded in each opcode-table byte; consumed by the decoder to read the
// right ModRM/SIB/displacement/immediate bytes.
//
// =============================================================================

int LDE_M       = 0x01;     // has ModRM byte
int LDE_I1      = 0x02;     // 1-byte immediate follows
int LDE_I2      = 0x04;     // 2-byte immediate follows
int LDE_I4      = 0x08;     // 4-byte immediate follows
int LDE_P66     = 0x10;     // 0x66 prefix changes I4 to I2
int LDE_REL     = 0x20;     // relative displacement (branch)
int LDE_STOP    = 0x40;     // execution stop (ret, hlt, etc.)
int LDE_ERR     = 0x80;     // invalid / unsupported opcode

// =============================================================================
//
// Globals Module
//
// 3 × 256-byte tables, allocated and populated by lde_init().
//
// =============================================================================

char* g_lde_t1;             // primary opcode table (256 bytes)
char* g_lde_t2;             // two-byte 0F opcode table (256 bytes)
char* g_lde_pfx;            // prefix byte flags (256 bytes)

// =============================================================================
//
// Helpers Module
//
// =============================================================================

// Fill a range [start..end] inclusive in a byte table
void lde_fill(char* tbl, int start, int end, int val) {
    int i;
    i = start;
    while (i <= end) {
        tbl[i] = val;
        i = i + 1;
    }
}

// =============================================================================
//
// Table Init Module
//
// =============================================================================

void lde_init() {
    int i;
    int base;

    g_lde_t1 = malloc(256);
    g_lde_t2 = malloc(256);
    g_lde_pfx = malloc(256);

    // -- Primary table: default ERR --
    mem_set(g_lde_t1, 0x80, 256);

    // ALU groups: ADD(0x00) OR(0x08) ADC(0x10) SBB(0x18)
    //             AND(0x20) SUB(0x28) XOR(0x30) CMP(0x38)
    // Pattern: +0=M +1=M +2=M +3=M +4=I1 +5=I4|P66
    i = 0;
    while (i < 8) {
        base = i * 8;
        g_lde_t1[base] = 0x01;          // M
        g_lde_t1[base + 1] = 0x01;      // M
        g_lde_t1[base + 2] = 0x01;      // M
        g_lde_t1[base + 3] = 0x01;      // M
        g_lde_t1[base + 4] = 0x02;      // I1
        g_lde_t1[base + 5] = 0x18;      // I4|P66
        i = i + 1;
    }

    // ALU gap bytes (base+6, base+7)
    g_lde_t1[0x06] = 0;    // PUSH ES
    g_lde_t1[0x07] = 0;    // POP ES
    g_lde_t1[0x0E] = 0;    // PUSH CS
    g_lde_t1[0x0F] = 0;    // two-byte escape (handled in code)
    g_lde_t1[0x16] = 0;    // PUSH SS
    g_lde_t1[0x17] = 0;    // POP SS
    g_lde_t1[0x1E] = 0;    // PUSH DS
    g_lde_t1[0x1F] = 0;    // POP DS
    g_lde_t1[0x26] = 0;    // ES: prefix
    g_lde_t1[0x27] = 0;    // DAA
    g_lde_t1[0x2E] = 0;    // CS: prefix
    g_lde_t1[0x2F] = 0;    // DAS
    g_lde_t1[0x36] = 0;    // SS: prefix
    g_lde_t1[0x37] = 0;    // AAA
    g_lde_t1[0x3E] = 0;    // DS: prefix
    g_lde_t1[0x3F] = 0;    // AAS

    // 0x40-0x61: INC/DEC/PUSH/POP reg, PUSHAD, POPAD
    lde_fill(g_lde_t1, 0x40, 0x61, 0);

    // 0x62-0x63: BOUND, ARPL
    g_lde_t1[0x62] = 0x01; // M
    g_lde_t1[0x63] = 0x01; // M

    // 0x64-0x67: FS/GS/opsize/addrsize prefixes (handled by pfx table)
    lde_fill(g_lde_t1, 0x64, 0x67, 0);

    // 0x68-0x6B: PUSH imm32, IMUL imm32, PUSH imm8, IMUL imm8
    g_lde_t1[0x68] = 0x18; // I4|P66
    g_lde_t1[0x69] = 0x19; // M|I4|P66
    g_lde_t1[0x6A] = 0x02; // I1
    g_lde_t1[0x6B] = 0x03; // M|I1

    // 0x6C-0x6F: INS/OUTS
    lde_fill(g_lde_t1, 0x6C, 0x6F, 0);

    // 0x70-0x7F: Jcc short (I1|REL)
    lde_fill(g_lde_t1, 0x70, 0x7F, 0x22);

    // 0x80-0x83: GRP1 immediate variants
    g_lde_t1[0x80] = 0x03; // M|I1
    g_lde_t1[0x81] = 0x19; // M|I4|P66
    g_lde_t1[0x82] = 0x03; // M|I1 (alias)
    g_lde_t1[0x83] = 0x03; // M|I1

    // 0x84-0x8F: TEST/XCHG/MOV/LEA/POP — all ModRM only
    lde_fill(g_lde_t1, 0x84, 0x8F, 0x01);

    // 0x90-0x97: NOP, XCHG EAX,reg
    lde_fill(g_lde_t1, 0x90, 0x97, 0);

    // 0x98-0x9F: CWDE, CDQ, CALL far, WAIT, PUSHFD, POPFD, SAHF, LAHF
    g_lde_t1[0x98] = 0;    // CWDE
    g_lde_t1[0x99] = 0;    // CDQ
    g_lde_t1[0x9A] = 0x80; // CALL far — ERR (unsupported)
    g_lde_t1[0x9B] = 0;    // WAIT
    g_lde_t1[0x9C] = 0;    // PUSHFD
    g_lde_t1[0x9D] = 0;    // POPFD
    g_lde_t1[0x9E] = 0;    // SAHF
    g_lde_t1[0x9F] = 0;    // LAHF

    // 0xA0-0xA3: MOV AL/EAX moffs (4-byte address in 32-bit mode)
    lde_fill(g_lde_t1, 0xA0, 0xA3, 0x08);   // I4

    // 0xA4-0xA7: MOVS, CMPS
    lde_fill(g_lde_t1, 0xA4, 0xA7, 0);

    // 0xA8-0xA9: TEST AL/EAX imm
    g_lde_t1[0xA8] = 0x02; // I1
    g_lde_t1[0xA9] = 0x18; // I4|P66

    // 0xAA-0xAF: STOS, LODS, SCAS
    lde_fill(g_lde_t1, 0xAA, 0xAF, 0);

    // 0xB0-0xB7: MOV r8, imm8
    lde_fill(g_lde_t1, 0xB0, 0xB7, 0x02);   // I1

    // 0xB8-0xBF: MOV r32, imm32
    lde_fill(g_lde_t1, 0xB8, 0xBF, 0x18);   // I4|P66

    // 0xC0-0xC1: GRP2 shift imm8
    g_lde_t1[0xC0] = 0x03; // M|I1
    g_lde_t1[0xC1] = 0x03; // M|I1

    // 0xC2-0xC3: RET
    g_lde_t1[0xC2] = 0x44; // RET imm16 — I2|STOP
    g_lde_t1[0xC3] = 0x40; // RET — STOP

    // 0xC4-0xC5: LES, LDS
    g_lde_t1[0xC4] = 0x01; // M
    g_lde_t1[0xC5] = 0x01; // M

    // 0xC6-0xC7: MOV rm, imm
    g_lde_t1[0xC6] = 0x03; // M|I1
    g_lde_t1[0xC7] = 0x19; // M|I4|P66

    // 0xC8-0xC9: ENTER, LEAVE
    g_lde_t1[0xC8] = 0x06; // ENTER: I2|I1 = 3 bytes operand
    g_lde_t1[0xC9] = 0;    // LEAVE

    // 0xCA-0xCB: RETF
    g_lde_t1[0xCA] = 0x44; // RETF imm16 — I2|STOP
    g_lde_t1[0xCB] = 0x40; // RETF — STOP

    // 0xCC-0xCF: INT3, INT, INTO, IRET
    g_lde_t1[0xCC] = 0;    // INT3
    g_lde_t1[0xCD] = 0x02; // INT imm8 — I1
    g_lde_t1[0xCE] = 0;    // INTO
    g_lde_t1[0xCF] = 0x40; // IRET — STOP

    // 0xD0-0xD3: GRP2 shifts by 1/CL
    lde_fill(g_lde_t1, 0xD0, 0xD3, 0x01);   // M

    // 0xD4-0xD5: AAM, AAD
    g_lde_t1[0xD4] = 0x02; // I1
    g_lde_t1[0xD5] = 0x02; // I1

    // 0xD6-0xD7: SALC, XLAT
    g_lde_t1[0xD6] = 0;
    g_lde_t1[0xD7] = 0;

    // 0xD8-0xDF: FPU — all have ModRM
    lde_fill(g_lde_t1, 0xD8, 0xDF, 0x01);   // M

    // 0xE0-0xE3: LOOPNE, LOOPE, LOOP, JECXZ
    lde_fill(g_lde_t1, 0xE0, 0xE3, 0x22);   // I1|REL

    // 0xE4-0xE7: IN/OUT imm8
    lde_fill(g_lde_t1, 0xE4, 0xE7, 0x02);   // I1

    // 0xE8: CALL rel32 — I4|P66|REL
    g_lde_t1[0xE8] = 0x38;
    // 0xE9: JMP rel32 — I4|P66|REL|STOP
    g_lde_t1[0xE9] = 0x78;
    // 0xEA: JMP far — ERR
    g_lde_t1[0xEA] = 0x80;
    // 0xEB: JMP short — I1|REL|STOP
    g_lde_t1[0xEB] = 0x62;

    // 0xEC-0xEF: IN/OUT DX
    lde_fill(g_lde_t1, 0xEC, 0xEF, 0);

    // 0xF0-0xF5: LOCK, INT1, REPNE, REP, HLT, CMC
    g_lde_t1[0xF0] = 0;    // LOCK (prefix)
    g_lde_t1[0xF1] = 0;    // INT1
    g_lde_t1[0xF2] = 0;    // REPNE (prefix)
    g_lde_t1[0xF3] = 0;    // REP (prefix)
    g_lde_t1[0xF4] = 0x40; // HLT — STOP
    g_lde_t1[0xF5] = 0;    // CMC

    // 0xF6-0xF7: GRP3 — M only (TEST imm handled as special case in lde())
    g_lde_t1[0xF6] = 0x01; // M
    g_lde_t1[0xF7] = 0x01; // M

    // 0xF8-0xFD: CLC, STC, CLI, STI, CLD, STD
    lde_fill(g_lde_t1, 0xF8, 0xFD, 0);

    // 0xFE-0xFF: GRP4/GRP5
    g_lde_t1[0xFE] = 0x01; // M
    g_lde_t1[0xFF] = 0x01; // M

    // -- Two-byte table (0F xx): default M (most have ModRM) --
    mem_set(g_lde_t2, 0x01, 256);

    // No-operand instructions
    g_lde_t2[0x05] = 0;    // 0F 05 SYSCALL
    g_lde_t2[0x06] = 0;    // 0F 06 CLTS
    g_lde_t2[0x08] = 0;    // 0F 08 INVD
    g_lde_t2[0x09] = 0;    // 0F 09 WBINVD
    g_lde_t2[0x0B] = 0;    // 0F 0B UD2
    lde_fill(g_lde_t2, 0x30, 0x35, 0);     // 0F 30-35 MSR/TSC/SYSENTER/SYSEXIT
    g_lde_t2[0x77] = 0;    // 0F 77 EMMS

    // 3-byte escape (unsupported)
    g_lde_t2[0x38] = 0x80; // 0F 38 — ERR
    g_lde_t2[0x3A] = 0x80; // 0F 3A — ERR

    // M|I1 opcodes (ModRM + 1-byte immediate)
    g_lde_t2[0x70] = 0x03; // 0F 70 PSHUFD
    lde_fill(g_lde_t2, 0x71, 0x73, 0x03);  // 0F 71-73 shift groups
    g_lde_t2[0xA4] = 0x03; // 0F A4 SHLD imm
    g_lde_t2[0xAC] = 0x03; // 0F AC SHRD imm
    g_lde_t2[0xBA] = 0x03; // 0F BA GRP8 (BT/BTS/BTR/BTC imm)
    g_lde_t2[0xC2] = 0x03; // 0F C2 CMPPS
    g_lde_t2[0xC4] = 0x03; // 0F C4 PINSRW
    g_lde_t2[0xC5] = 0x03; // 0F C5 PEXTRW
    g_lde_t2[0xC6] = 0x03; // 0F C6 SHUFPS

    // Jcc near: I4|P66|REL
    lde_fill(g_lde_t2, 0x80, 0x8F, 0x38);  // 0F 80-8F

    // No-ModRM: PUSH/POP FS/GS, CPUID, RSM
    g_lde_t2[0xA0] = 0;    // 0F A0 PUSH FS
    g_lde_t2[0xA1] = 0;    // 0F A1 POP FS
    g_lde_t2[0xA2] = 0;    // 0F A2 CPUID
    g_lde_t2[0xA8] = 0;    // 0F A8 PUSH GS
    g_lde_t2[0xA9] = 0;    // 0F A9 POP GS
    g_lde_t2[0xAA] = 0;    // 0F AA RSM

    // BSWAP (register in opcode, no ModRM)
    lde_fill(g_lde_t2, 0xC8, 0xCF, 0);     // 0F C8-CF

    // Invalid
    g_lde_t2[0xB9] = 0x80; // 0F B9 UD1 — ERR
    g_lde_t2[0xFF] = 0x80; // 0F FF UD0 — ERR

    // -- Prefix table --
    mem_set(g_lde_pfx, 0, 256);
    g_lde_pfx[0x26] = 1;   // ES:
    g_lde_pfx[0x2E] = 1;   // CS:
    g_lde_pfx[0x36] = 1;   // SS:
    g_lde_pfx[0x3E] = 1;   // DS:
    g_lde_pfx[0x64] = 1;   // FS:
    g_lde_pfx[0x65] = 1;   // GS:
    g_lde_pfx[0x66] = 2;   // operand-size (special: tracked for P66)
    g_lde_pfx[0x67] = 1;   // address-size
    g_lde_pfx[0xF0] = 1;   // LOCK
    g_lde_pfx[0xF2] = 1;   // REPNE
    g_lde_pfx[0xF3] = 1;   // REP
}

// =============================================================================
//
// Decoder Module
//
// =============================================================================

// Decode instruction length. Returns 0 on error.
// If out_flags is non-null, writes the raw LDE flag byte there.
int lde(char* code, int* out_flags) {
    int pos;
    int has_66;
    int op;
    int op2;
    int flags;
    int is_2b;
    int modrm;
    int mod;
    int rm;
    int reg;
    int sib_base;
    int pv;
    int done;
    int is_vex;
    int vex_b2;
    int map_sel;

    pos = 0;
    has_66 = 0;
    is_2b = 0;
    is_vex = 0;

    // Skip prefix bytes
    done = 0;
    while (done == 0) {
        pv = code[pos] & 0xFF;
        if (g_lde_pfx[pv] != 0) {
            if (g_lde_pfx[pv] == 2) {
                has_66 = 1;
            }
            pos = pos + 1;
        } else {
            done = 1;
        }
    }

    // Read opcode
    op = code[pos] & 0xFF;
    pos = pos + 1;

    // VEX prefix handling (32-bit mode).
    // In 32-bit mode, C4/C5 + byte with mod=11 is VEX (not LES/LDS).
    // LES/LDS require memory operand (mod != 11).
    if (op == 0xC5) {
        // potential 2-byte VEX
        vex_b2 = code[pos] & 0xFF;
        if ((vex_b2 >> 6) == 3) {
            is_vex = 1;
            pos = pos + 1;
            // Opcode in 0F map
            op2 = code[pos] & 0xFF;
            pos = pos + 1;
            flags = g_lde_t2[op2] & 0xFF;
            is_2b = 1;
            has_66 = 0;
        }
    }
    if (op == 0xC4 && is_vex == 0) {
        // potential 3-byte VEX
        vex_b2 = code[pos] & 0xFF;
        if ((vex_b2 >> 6) == 3) {
            is_vex = 1;
            map_sel = vex_b2 & 0x1F;
            pos = pos + 2;
            op2 = code[pos] & 0xFF;
            pos = pos + 1;
            is_2b = 1;
            has_66 = 0;
            if (map_sel == 1) {
                flags = g_lde_t2[op2] & 0xFF;
            } else if (map_sel == 2) {
                // 0F38 map: always ModRM
                flags = 0x01;
            } else if (map_sel == 3) {
                // 0F3A map: always ModRM + imm8
                flags = 0x03;
            } else {
                flags = 0x01;
            }
        }
    }

    if (is_vex == 0) {
        // Two-byte escape?
        if (op == 0x0F) {
            is_2b = 1;
            op2 = code[pos] & 0xFF;
            pos = pos + 1;
            flags = g_lde_t2[op2] & 0xFF;
        } else {
            flags = g_lde_t1[op] & 0xFF;
        }
    }

    // Output flags if requested
    if (out_flags != 0) {
        *out_flags = flags;
    }

    // Error?
    if ((flags & 0x80) != 0) {
        return 0;
    }

    // ModRM handling
    if ((flags & 0x01) != 0) {
        modrm = code[pos] & 0xFF;
        pos = pos + 1;
        mod = (modrm >> 6) & 0x3;
        rm = modrm & 0x7;
        reg = (modrm >> 3) & 0x7;

        // SIB byte present?
        if (mod != 3 && rm == 4) {
            sib_base = code[pos] & 0x7;
            pos = pos + 1;
            // SIB with mod=0, base=5 -> disp32
            if (mod == 0 && sib_base == 5) {
                pos = pos + 4;
            }
        }

        // Displacement
        if (mod == 0 && rm == 5) {
            pos = pos + 4;      // disp32 (no base)
        } else if (mod == 1) {
            pos = pos + 1;      // disp8
        } else if (mod == 2) {
            pos = pos + 4;      // disp32
        }

        // GRP3 TEST special case: F6/F7 reg=0 or reg=1 have an extra immediate
        if (is_2b == 0) {
            if (op == 0xF6 && reg < 2) {
                // TEST r/m8, imm8
                pos = pos + 1;
            }
            if (op == 0xF7 && reg < 2) {
                // TEST r/m32, imm32 (or imm16 with 0x66)
                if (has_66 != 0) {
                    pos = pos + 2;
                } else {
                    pos = pos + 4;
                }
            }
        }
    }

    // Immediate operands (from flag bits)
    if ((flags & 0x02) != 0) {
        pos = pos + 1;          // I1
    }
    if ((flags & 0x04) != 0) {
        pos = pos + 2;          // I2
    }
    if ((flags & 0x08) != 0) {
        // I4, but check P66 override
        if (has_66 != 0 && (flags & 0x10) != 0) {
            pos = pos + 2;      // 0x66 shrinks dword imm to word
        } else {
            pos = pos + 4;
        }
    }

    return pos;
}
