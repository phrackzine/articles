'use strict';

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

let g_result   = null;   // last /api/compile response
let g_irFormat = 'mce';  // 'mct' | 'mce'
let g_view     = 'editor'; // 'editor' | 'variants'

// ---------------------------------------------------------------------------
// DOM helpers
// ---------------------------------------------------------------------------

function $(id) { return document.getElementById(id); }

function showSpinner(msg) {
  $('spinner-msg').textContent = msg || 'Working...';
  $('spinner').classList.add('visible');
}
function hideSpinner() { $('spinner').classList.remove('visible'); }

function showError(msg) {
  const bar = $('statusbar');
  // Show only the first line in the transient bar; full detail is in the log
  bar.textContent = msg.split('\n')[0];
  bar.classList.add('visible');
  setTimeout(() => bar.classList.remove('visible'), 8000);
}

function setStatus(msg) {
  $('topbar-status').textContent = msg;
}

async function apiPost(endpoint, body) {
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ---------------------------------------------------------------------------
// CodeMirror editor
// ---------------------------------------------------------------------------

const editor = CodeMirror.fromTextArea($('source-editor'), {
  mode: 'text/x-csrc',
  theme: 'default',
  lineNumbers: true,
  indentUnit: 4,
  tabSize: 4,
  indentWithTabs: false,
  autofocus: true,
});

editor.setValue(`int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main() {
    int i;
    int result;
    i = 1;
    while (i <= 10) {
        result = factorial(i);
        i = i + 1;
    }
    return result;
}`);

// ---------------------------------------------------------------------------
// Import source file
// ---------------------------------------------------------------------------

$('import-src-btn').addEventListener('click', () => $('import-src-input').click());
$('import-src-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    editor.setValue(text);
    logLine(`Imported ${file.name} (${text.length} chars)`, 'ok');
  } catch (err) {
    showError(`Failed to import: ${err.message}`);
  }
  e.target.value = '';
});

// ---------------------------------------------------------------------------
// View toggle (Editor ↔ Variants)
// ---------------------------------------------------------------------------

document.querySelectorAll('.view-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const v = btn.dataset.view;
    if (v === g_view) return;
    g_view = v;

    document.querySelectorAll('.view-btn')
      .forEach(b => b.classList.toggle('active', b.dataset.view === v));

    $('editor-view').style.display      = v === 'editor'     ? '' : 'none';
    $('transforms-view').style.display   = v === 'transforms' ? 'flex' : 'none';
    $('variants-view').style.display     = v === 'variants'   ? 'flex' : 'none';
    $('evolution-view').style.display    = v === 'evolution'  ? 'flex' : 'none';
    $('diff-view').style.display         = v === 'diff'       ? 'flex' : 'none';

    $('sidebar').classList.toggle('hidden', v === 'variants' || v === 'evolution' || v === 'diff');

    if (v === 'editor') editor.refresh();
  });
});

// ---------------------------------------------------------------------------
// Editor / console resize (drag #h-divider)
// ---------------------------------------------------------------------------

(function initHDivider() {
  const divider     = $('h-divider');
  const consolePanE = $('console-pane');

  divider.addEventListener('mousedown', e => {
    e.preventDefault();
    divider.classList.add('dragging');
    const startY = e.clientY;
    const startH = consolePanE.getBoundingClientRect().height;

    const onMove = e => {
      const newH = Math.max(80, startH + (startY - e.clientY));
      consolePanE.style.flex = `0 0 ${newH}px`;
      editor.refresh();
    };
    const onUp = () => {
      divider.classList.remove('dragging');
      document.body.style.cursor = '';
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.body.style.cursor = 'row-resize';
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
})();

// ---------------------------------------------------------------------------
// Console tabs — only Log and IR
// ---------------------------------------------------------------------------

function initConsoleTabs() {
  $('console-tabs').innerHTML = '';
  makeConsoleTabBtn('log', 'Log');
  makeConsoleTabBtn('ir',  'IR');
  switchConsoleTab('log');
}

function makeConsoleTabBtn(panelId, label) {
  const btn = document.createElement('button');
  btn.className = 'console-tab-btn';
  btn.dataset.panel = panelId;
  btn.textContent = label;
  btn.addEventListener('click', () => switchConsoleTab(panelId));
  $('console-tabs').appendChild(btn);
  return btn;
}

function switchConsoleTab(panelId) {
  document.querySelectorAll('#console-tabs .console-tab-btn')
    .forEach(b => b.classList.toggle('active', b.dataset.panel === panelId));
  document.querySelectorAll('#console-body .console-panel')
    .forEach(p => p.classList.toggle('active', p.id === `panel-${panelId}`));
}

// ---------------------------------------------------------------------------
// Compilation log
// ---------------------------------------------------------------------------

function logClear() {
  $('panel-log').querySelector('.log-text').innerHTML = '';
}

function logLine(text, kind) {
  const pre  = $('panel-log').querySelector('.log-text');
  const ts   = new Date().toLocaleTimeString('en-GB', { hour12: false });
  const span = document.createElement('span');
  span.className = kind ? `log-line-${kind}` : 'log-line-info';
  span.textContent = `[${ts}] ${text}\n`;
  pre.appendChild(span);
  pre.scrollTop = pre.scrollHeight;
}

function logMultiline(text, kind) {
  text.split('\n').forEach(line => {
    const t = line.trimEnd();
    if (t) logLine(t, kind);
  });
}

// ---------------------------------------------------------------------------
// Compile button
// ---------------------------------------------------------------------------

$('compile-btn').addEventListener('click', async () => {
  const source = editor.getValue();
  if (!source.trim()) { showError('Source is empty'); return; }

  const n        = Math.max(1, Math.min(99, parseInt($('n-variants').value, 10) || 2));
  const seedMode = document.querySelector('input[name="seed-mode"]:checked').value;
  const seed     = seedMode === 'fixed' ? parseInt($('seed-value').value, 10) : null;
  const irFormat = document.querySelector('input[name="ir-format"]:checked').value;

  const perVariantFlags = gatherTransformFlagsPerVariant();
  const perVariantGenome = readGenomePerVariant();
  const generational = $('flag-generational').checked;
  const mutateGenome = $('flag-mutate-genome')?.checked || false;
  const targetPlatform = document.querySelector('input[name="target-platform"]:checked')?.value || 'win32';

  // Union of all variant flags for logging
  const allFlags = new Set();
  for (const flags of perVariantFlags) flags.forEach(f => allFlags.add(f));

  // Switch to editor view so the user sees the log
  if (g_view !== 'editor') {
    document.querySelector('.view-btn[data-view="editor"]').click();
  }

  switchConsoleTab('log');
  logClear();
  logLine(`Compiling ${n} variant${n > 1 ? 's' : ''}...`, 'hdr');
  logLine(`  IR format : ${irFormat === 'mce' ? 'expression (.mce)' : 'classic (.mct)'}`, 'info');
  logLine(`  platform  : ${targetPlatform}`, 'info');
  logLine(`  seed      : ${seed !== null ? seed : 'random'}`, 'info');
  if (allFlags.size) {
    const displayFlags = [...allFlags];
    logLine(`  transforms: ${displayFlags.join(', ')}`, 'info');
    if (generational) logLine('  mode      : generational (chained IR)', 'info');
    if (mutateGenome) logLine('  genome    : mutate each generation', 'info');
  } else {
    logLine('  transforms: none', 'info');
  }

  if ($('genome-enabled').checked) {
    logLine('  genome    : custom (per-variant)', 'info');
  }

  $('compile-btn').disabled = true;
  showSpinner(`Compiling ${n} variant${n > 1 ? 's' : ''}...`);
  setStatus('');

  const t0 = performance.now();

  try {
    const body = {
      source,
      n_variants: n,
      seed,
      ir_format: irFormat,
      generational,
      mutate_genome: mutateGenome,
      target_platform: targetPlatform,
      per_variant: perVariantFlags.map((flags, i) => ({
        transform_flags: flags,
        genome: perVariantGenome ? perVariantGenome[i] : null,
      })),
    };
    // Pass output options if project is open
    if (g_project) {
      body.project_dir = g_project.path;
      body.output_formats = {
        pic:        $('out-pic')?.checked         || false,
        standalone: $('out-standalone')?.checked  || false,
        recompiler: $('out-recompiler')?.checked  || false,
        infector:   $('out-infector')?.checked    || false,
        integrator: $('out-integrator')?.checked  || false,
      };
    }
    body.strip_debug = $('strip-debug')?.checked || false;
    body.scramble_globals = $('scramble-globals')?.checked || false;
    const result = await apiPost('/api/compile', body);

    const elapsed = ((performance.now() - t0) / 1000).toFixed(2);

    const ir = result.ir || {};
    logLine('', 'info');
    logLine('Frontend', 'hdr');
    logLine(`  functions : ${(ir.functions || []).length}`, 'ok');
    logLine(`  globals   : ${(ir.globals   || []).length}`, 'ok');
    logLine(`  strings   : ${(ir.strings   || []).length}`, 'ok');

    if (!result.mce && irFormat === 'mce') {
      logLine('  warning   : expr IR (.mce) is empty — showing classic IR', 'err');
    }

    logLine('', 'info');
    logLine('Variants', 'hdr');
    result.variants.forEach((v, i) => {
      if (v.error) {
        logLine(`  #${i + 1}  ERROR: ${v.error}`, 'err');
      } else {
        const sizeKB = (v.bin_hex.length / 2 / 1024).toFixed(1);
        logLine(`  #${i + 1}  size ${sizeKB} KB  entropy ${v.entropy.toFixed(2)}  sha ${v.sha256.slice(0, 12)}…`, 'ok');
        // Show genome mutations if present
        if (v.genome && i > 0 && mutateGenome) {
          const prev = result.variants[i - 1]?.genome;
          if (prev) {
            const changes = [];
            for (const k of Object.keys(v.genome)) {
              const cur = v.genome[k], old = prev[k];
              if (Array.isArray(cur)) {
                if (!Array.isArray(old) || cur.some((c, j) => c !== old[j]))
                  changes.push(k);
              } else if (cur !== old) {
                changes.push(`${k}: ${old}→${cur}`);
              }
            }
            if (changes.length)
              logLine(`       genome Δ: ${changes.slice(0, 5).join(', ')}${changes.length > 5 ? '…' : ''}`, 'info');
          }
        }
      }
    });

    // Log file outputs
    if (result.outputs && Array.isArray(result.outputs)) {
      logLine('', 'info');
      logLine('Outputs', 'hdr');
      result.outputs.forEach((varOutputs, i) => {
        if (varOutputs.error) {
          logLine(`  V${i + 1}: ${varOutputs.error}`, 'err');
        } else {
          for (const [fmt, finfo] of Object.entries(varOutputs)) {
            if (finfo && finfo.path) {
              const sizeKB = (finfo.size / 1024).toFixed(1);
              logLine(`  V${i + 1} ${fmt.toUpperCase().padEnd(8)} ${finfo.path} (${sizeKB} KB)`, 'ok');
            }
          }
        }
      });
    } else if (result.outputs && typeof result.outputs === 'object') {
      logLine('', 'info');
      logLine('Outputs', 'hdr');
      for (const [fmt, info] of Object.entries(result.outputs)) {
        const sizeKB = (info.size / 1024).toFixed(1);
        logLine(`  ${fmt.toUpperCase().padEnd(6)} ${info.path} (${sizeKB} KB)`, 'ok');
      }
    }
    if (result.output_error) {
      logLine(`  output error: ${result.output_error}`, 'err');
    }

    if (result.report && g_project) {
      logLine('', 'info');
      logLine(`Report: ${result.report}`, 'ok');
    }

    logLine('', 'info');
    logLine(`Done in ${elapsed}s`, 'hdr');

    g_result   = result;
    g_irFormat = irFormat;

    renderAll(result, irFormat);

    setStatus(`OK — ${result.variants.length} variant${result.variants.length > 1 ? 's' : ''}` +
              (seed !== null ? `  seed ${seed}` : ''));
  } catch (e) {
    logLine('', 'info');
    logLine('Compile failed:', 'err');
    logMultiline(e.message, 'err');
    showError(`Compile error: ${e.message}`);
  } finally {
    hideSpinner();
    $('compile-btn').disabled = false;
  }
});

// ---------------------------------------------------------------------------
// Render after compile
// ---------------------------------------------------------------------------

function renderAll(result, irFormat) {
  // IR text — fall back to mct if mce is empty
  const irText = (irFormat === 'mce' && result.mce) ? result.mce : result.mct;
  renderIRPanel(irText);

  // Variants view
  renderVariantsView(result, irFormat);

  // Evolution view — populated from variant genomes
  updateEvolutionView(result);

  // Diff view
  updateDiffView(result, irFormat);
}

// ---------------------------------------------------------------------------
// IR console panel
// ---------------------------------------------------------------------------

function renderIRPanel(text) {
  const panel = $('panel-ir');
  panel.innerHTML = '';
  if (!text) {
    panel.innerHTML = '<div class="empty-state">No IR output</div>';
    return;
  }
  const pre = document.createElement('pre');
  pre.className = 'ir-text';
  pre.textContent = text;
  panel.appendChild(pre);
}

// ---------------------------------------------------------------------------
// x86 content builder (shared between console panels + variants view)
// ---------------------------------------------------------------------------

// Build a map of "fnName:seq" → IR source line text
function buildIrLineMap(irText, irFormat, fnNameMap) {
  const map = new Map();
  if (!irText) return map;
  let currentFn = null;
  let seq = 0;
  for (const line of irText.split('\n')) {
    const t = line.trim();
    const fnMatch = irFormat === 'mce'
      ? t.match(/^(?:int|char|ptr|void)\s+(\w+)\s*\(/)
      : t.match(/^fn\s+@?(\w+)/);
    if (fnMatch) {
      const rawName = fnMatch[1];
      currentFn = (fnNameMap && fnNameMap[rawName]) || rawName;
      seq = 0;
      continue;
    }
    if (currentFn && guessIrOp(line, irFormat)) {
      map.set(`${currentFn}:${seq}`, t);
      seq++;
    }
  }
  return map;
}

function buildX86Content(v, irLineMap) {
  const frag = document.createDocumentFragment();

  if (v.error) {
    const msg = document.createElement('div');
    msg.className = 'empty-state';
    msg.style.color = 'var(--col-dead)';
    msg.textContent = v.error;
    frag.appendChild(msg);
    return frag;
  }

  if (!v.disasm || v.disasm.length === 0) {
    const msg = document.createElement('div');
    msg.className = 'empty-state';
    msg.textContent = 'No disasm';
    frag.appendChild(msg);
    return frag;
  }

  const annotMap      = buildAnnotMap(v.annotations, v.fn_name_map);
  const funcMap       = buildFuncMap(v.annotations);
  const blockLabelMap = buildBlockLabelMap(v.annotations);

  const info = document.createElement('div');
  info.style.cssText = 'padding:5px 10px;font-size:10px;color:var(--text-dim);border-bottom:1px solid var(--border)';
  const sizeKB = (v.bin_hex.length / 2 / 1024).toFixed(1);
  info.textContent = `${sizeKB} KB  entropy ${v.entropy.toFixed(2)}  sha ${v.sha256.slice(0, 16)}…`;
  frag.appendChild(info);

  let lastIrKey = null; // track "fn:seq" to detect changes

  for (const ins of v.disasm) {
    if (funcMap.has(ins.offset)) {
      const fn = funcMap.get(ins.offset);
      const fh = document.createElement('div');
      fh.className = 'x86-func-header' + (fn.kind === 'junk_function' ? ' junk' : '');
      fh.textContent = fn.kind === 'junk_function' ? `[junk] ${fn.name}` : `fn ${fn.name}`;
      frag.appendChild(fh);
      lastIrKey = null; // reset on function boundary
    }

    if (blockLabelMap.has(ins.offset)) {
      const bl = document.createElement('div');
      bl.className = 'x86-block-label';
      bl.textContent = blockLabelMap.get(ins.offset) + ':';
      frag.appendChild(bl);
    }

    const ann  = annotMap.get(ins.offset);
    const kind = ann ? ann.kind : 'unknown';

    // Insert IR comment line when ir_seq changes
    if (irLineMap && ann && ann.ir_fn && ann.ir_seq !== undefined) {
      const irKey = `${ann.ir_fn}:${ann.ir_seq}`;
      if (irKey !== lastIrKey) {
        lastIrKey = irKey;
        const irLine = irLineMap.get(irKey);
        if (irLine) {
          const comment = document.createElement('div');
          comment.className = 'x86-ir-comment';
          comment.textContent = `; ${irLine}`;
          frag.appendChild(comment);
        }
      }
    }

    const row = document.createElement('div');
    row.className = `x86-instr ann-${kind}`;

    if (ann && ann.ir_op)               row.dataset.irOp  = ann.ir_op.toUpperCase();
    if (ann && ann.ir_fn)               row.dataset.irFn  = ann.ir_fn;
    if (ann && ann.ir_seq !== undefined) row.dataset.irSeq = String(ann.ir_seq);

    let tip = kind;
    if (ann) {
      if (ann.ir_op)             tip += ` / ir: ${ann.ir_op}`;
      if (ann.pattern !== undefined) tip += ` / pattern ${ann.pattern}`;
    }
    row.title = tip;

    const off = document.createElement('span');
    off.className = 'off';
    off.textContent = ins.offset.toString(16).padStart(4, '0');

    const hx = document.createElement('span');
    hx.className = 'hex-bytes';
    hx.textContent = (ins.bytes || '').slice(0, 14);

    const textParts = ins.text.match(/^(\S+)\s*(.*)/s);
    const op = document.createElement('span');
    op.className = 'opcode';
    op.textContent = textParts ? textParts[1] : ins.text;
    const args = document.createElement('span');
    args.className = 'operands';
    args.textContent = textParts ? textParts[2] : '';

    row.append(off, hx, op, args);
    frag.appendChild(row);
  }

  return frag;
}

// ---------------------------------------------------------------------------
// Variants view
// ---------------------------------------------------------------------------

function renderVariantsView(result, irFormat) {
  const container = $('variants-columns');
  container.innerHTML = '';

  const isGenerational  = result.generational;
  const hasPerVariantIR = isGenerational || result.variants.some(v => v.ir_text);
  const baseIrText = (irFormat === 'mce' && result.mce) ? result.mce : result.mct;

  const cols = [];

  if (hasPerVariantIR) {
    // Each variant column: IR pane (top) + x86 pane (bottom)
    // Generational mode labels: "Gen 0 →", "Gen 1 →", ... "Gen N"
    // Build all columns first, then wire resize handles.
    result.variants.forEach((v, i) => {
      const varIrText = v.ir_text || baseIrText || '';
      const irLineMap = buildIrLineMap(varIrText, irFormat, v.fn_name_map);
      const title = isGenerational ? `Gen ${i}` : `Variant #${i + 1}`;
      const col  = makeColPane(title, v.error ? 'var(--col-dead)' : null);
      const body = col.querySelector('.col-body');
      body.classList.add('split');

      // IR sub-pane
      const irPane = document.createElement('div');
      irPane.className = 'col-ir-pane';
      irPane.appendChild(renderIrLines(varIrText, irFormat, v.fn_name_map));
      body.appendChild(irPane);

      // Horizontal drag handle between IR and x86
      const irResizeHandle = document.createElement('div');
      irResizeHandle.className = 'col-ir-resize';
      body.appendChild(irResizeHandle);

      // x86 sub-pane
      const x86Pane = document.createElement('div');
      x86Pane.className = 'col-x86-pane';
      x86Pane.appendChild(buildX86Content(v, irLineMap));
      addFuncCollapse(x86Pane);
      body.appendChild(x86Pane);

      initIrX86Resize(irResizeHandle, irPane);

      if (i > 0) {
        const handle = makeColResizeHandle();
        if (isGenerational) handle.classList.add('generational');
        container.appendChild(handle);
      }
      container.appendChild(col);
      cols.push(col);
    });

    // Wire resize handles now that all cols are in DOM
    container.querySelectorAll('.col-resize-handle').forEach((handle, i) => {
      initColResize(handle, cols[i], cols[i + 1]);
    });

    // Scroll sync across all IR panes
    const irPanes = [...container.querySelectorAll('.col-ir-pane')];
    // Scroll sync disabled — each column scrolls independently
    // if (irPanes.length > 1) initIrScrollSync(irPanes);

  } else {
    // Shared IR column + per-variant x86 columns
    const sharedIrLineMap = buildIrLineMap(baseIrText || '', irFormat, null);
    const irCol  = makeColPane('IR');
    const irBody = irCol.querySelector('.col-body');
    if (baseIrText) {
      irBody.appendChild(renderIrLines(baseIrText, irFormat));
    } else {
      irBody.innerHTML = '<div class="empty-state">No IR</div>';
    }
    container.appendChild(irCol);
    cols.push(irCol);

    result.variants.forEach((v, i) => {
      const handle = makeColResizeHandle();
      container.appendChild(handle);

      const irMap = v.fn_name_map ? buildIrLineMap(baseIrText || '', irFormat, v.fn_name_map) : sharedIrLineMap;
      const x86Col  = makeColPane(`x86 #${i + 1}`, v.error ? 'var(--col-dead)' : null);
      const x86Body = x86Col.querySelector('.col-body');
      x86Body.appendChild(buildX86Content(v, irMap));
      addFuncCollapse(x86Body);
      container.appendChild(x86Col);

      initColResize(handle, cols[cols.length - 1], x86Col);
      cols.push(x86Col);
    });
  }

  cols.forEach(c => makeCollapsible(c));
}

function makeColPane(title, titleColor) {
  const pane   = document.createElement('div');
  pane.className = 'col-pane';

  const header = document.createElement('div');
  header.className = 'col-header';
  header.textContent = title;
  if (titleColor) header.style.color = titleColor;

  const body = document.createElement('div');
  body.className = 'col-body';

  pane.append(header, body);
  return pane;
}

function makeColResizeHandle() {
  const h = document.createElement('div');
  h.className = 'col-resize-handle';
  return h;
}

function initColResize(handle, leftEl, rightEl) {
  handle.addEventListener('mousedown', e => {
    e.preventDefault();
    handle.classList.add('dragging');
    const startX     = e.clientX;
    const leftStart  = leftEl.getBoundingClientRect().width;
    const rightStart = rightEl.getBoundingClientRect().width;

    const onMove = e => {
      const dx       = e.clientX - startX;
      const newLeft  = Math.max(80, leftStart  + dx);
      const newRight = Math.max(80, rightStart - dx);
      leftEl.style.flex  = `0 0 ${newLeft}px`;
      rightEl.style.flex = `0 0 ${newRight}px`;
    };
    const onUp = () => {
      handle.classList.remove('dragging');
      document.body.style.cursor = '';
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.body.style.cursor = 'col-resize';
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

function initIrScrollSync(irPanes) {
  let syncing = false;
  irPanes.forEach(src => {
    src.addEventListener('scroll', () => {
      if (syncing) return;
      syncing = true;

      // Find the topmost visible instruction line (has fn+seq)
      const srcTop = src.getBoundingClientRect().top;
      let anchorFn = null, anchorSeq = null, anchorOffset = 0;
      for (const line of src.querySelectorAll('.ir-line[data-ir-seq]')) {
        const r = line.getBoundingClientRect();
        if (r.bottom > srcTop) {
          anchorFn     = line.dataset.irFn;
          anchorSeq    = line.dataset.irSeq;
          anchorOffset = r.top - srcTop;  // how far into the pane the anchor sits
          break;
        }
      }

      if (anchorFn !== null) {
        irPanes.forEach(dst => {
          if (dst === src) return;
          const peer = dst.querySelector(
            `.ir-line[data-ir-fn="${CSS.escape(anchorFn)}"][data-ir-seq="${CSS.escape(anchorSeq)}"]`
          );
          if (peer) {
            const dstTop  = dst.getBoundingClientRect().top;
            const peerTop = peer.getBoundingClientRect().top;
            // Shift dst so the peer line sits at the same offset as the anchor
            dst.scrollTop += peerTop - dstTop - anchorOffset;
          }
        });
      }

      syncing = false;
    });
  });
}

function initIrX86Resize(handle, irPane) {
  handle.addEventListener('mousedown', e => {
    e.preventDefault();
    handle.classList.add('dragging');
    const startY = e.clientY;
    const startH = irPane.getBoundingClientRect().height;

    const onMove = e => {
      const newH = Math.max(40, startH + (e.clientY - startY));
      irPane.style.height = `${newH}px`;
    };
    const onUp = () => {
      handle.classList.remove('dragging');
      document.body.style.cursor = '';
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.body.style.cursor = 'row-resize';
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

function makeCollapsible(pane) {
  const header = pane.querySelector('.col-header');
  if (!header || header.querySelector('.col-collapse-btn')) return;

  const btn = document.createElement('button');
  btn.className = 'col-collapse-btn';
  btn.title = 'Collapse / expand';
  btn.textContent = '◀';
  header.appendChild(btn);

  function toggle() {
    const collapsed = pane.classList.toggle('col-collapsed');
    btn.textContent = collapsed ? '▶' : '◀';
  }
  btn.addEventListener('click', e => { e.stopPropagation(); toggle(); });
  header.addEventListener('click', () => {
    if (pane.classList.contains('col-collapsed')) toggle();
  });
}

// ---------------------------------------------------------------------------
// Junk function collapse
// ---------------------------------------------------------------------------

function addFuncCollapse(container) {
  container.querySelectorAll('.x86-func-header').forEach(hdr => {
    const isJunk = hdr.classList.contains('junk');
    const btn = document.createElement('button');
    btn.className = 'junk-collapse-btn';
    hdr.appendChild(btn);

    function getBodyEls() {
      const els = [];
      let el = hdr.nextElementSibling;
      while (el && !el.classList.contains('x86-func-header')) {
        els.push(el); el = el.nextElementSibling;
      }
      return els;
    }

    let collapsed = false;
    function setCollapsed(s) {
      collapsed = s;
      btn.textContent = collapsed ? '▶' : '▼';
      for (const el of getBodyEls()) el.style.display = collapsed ? 'none' : '';
    }
    btn.addEventListener('click', e => { e.stopPropagation(); setCollapsed(!collapsed); });
    setCollapsed(isJunk);
  });
}

// ---------------------------------------------------------------------------
// IR → x86 click-to-highlight
// ---------------------------------------------------------------------------

/**
 * Best-effort extraction of the IR opcode from a single mce/mct line.
 * Returns an UPPERCASE opcode string (matching annotation ir_op), or null
 * if the line is not an instruction (label, declaration, brace, blank…).
 */
function guessIrOp(line, irFormat) {
  const t = line.trim();
  if (!t) return null;

  if (irFormat === 'mct') {
    // "%0 = add %1 %2 i32"  →  "ADD"
    // "jmp .label"          →  "JMP"
    const m = t.match(/^(?:[%$!@]\S+\s*=\s*)?(\w+)/);
    return m ? m[1].toUpperCase() : null;
  }

  // ── mce format ───────────────────────────────────────────────────────────
  if (t.endsWith(':'))                                          return null; // block label
  if (t === '{' || t === '}')                                   return null;
  if (t.startsWith('//'))                                       return null;
  if (/^(str|global|extern|struct)\s/.test(t))                 return null;
  if (/^(int|char|ptr|void)\s+\w+\s*[\({]/.test(t))           return null; // func header
  if (/^(int|char|ptr|void)\s+\w/.test(t))                     return null; // local decl

  if (t === 'nop')             return 'NOP';
  if (t.startsWith('goto '))   return 'JMP';
  if (t.startsWith('if (!'))   return 'JZ';
  if (t.startsWith('if ('))    return 'JNZ';
  if (t === 'return')          return 'RETV';
  if (t.startsWith('return ')) return 'RET';
  if (t.startsWith('*'))       return 'STORE';
  if (/^\w+\s*\(/.test(t))     return 'CALLV';

  const eq = t.indexOf(' = ');
  if (eq < 0) return null;
  const rhs = t.slice(eq + 3).trim();

  if (rhs.startsWith('*'))        return 'LOAD';
  if (rhs.startsWith('&'))        return 'ADDR';
  if (rhs.startsWith('-'))        return 'NEG';
  if (rhs.startsWith('~'))        return 'NOT';
  if (rhs.startsWith('alloca('))  return 'ALLOCA';
  if (/^\w+\s*\(/.test(rhs))      return 'CALL';

  if (rhs.startsWith('(')) {
    if (rhs.includes('=='))  return 'EQ';
    if (rhs.includes('!='))  return 'NE';
    if (rhs.includes('<='))  return 'LE';
    if (rhs.includes('>='))  return 'GE';
    if (rhs.includes('<'))   return 'LT';
    if (rhs.includes('>'))   return 'GT';
  }
  if (rhs.includes(' + '))   return 'ADD';
  if (rhs.includes(' - '))   return 'SUB';
  if (rhs.includes(' * '))   return 'MUL';
  if (rhs.includes(' / '))   return 'DIV';
  if (rhs.includes(' % '))   return 'MOD';
  if (rhs.includes(' & '))   return 'AND';
  if (rhs.includes(' | '))   return 'OR';
  if (rhs.includes(' ^ '))   return 'XOR';
  if (rhs.includes(' << '))  return 'SHL';
  if (rhs.includes(' >> '))  return 'SHR';

  return 'COPY';
}

function handleIrLineClick(e) {
  const line = e.currentTarget;
  const op   = line.dataset.irOp;
  if (!op) return;

  const wasActive = line.classList.contains('ir-active');

  // Clear all existing highlights
  document.querySelectorAll('.ir-line.ir-active')
          .forEach(el => el.classList.remove('ir-active'));
  document.querySelectorAll('.x86-instr.ir-highlight')
          .forEach(el => el.classList.remove('ir-highlight'));

  if (wasActive) return;   // second click = deselect

  line.classList.add('ir-active');

  const fn  = line.dataset.irFn;
  const seq = line.dataset.irSeq;

  // Scope: for split-column mode, highlight only the x86 pane of the same
  // variant column. For shared-IR mode, highlight across all x86 columns.
  const colPane = line.closest('.col-pane');
  const x86Scope = (colPane && colPane.querySelector('.col-x86-pane'))
      || $('variants-columns');

  // Per-pane matching so each variant column gets its own fallback decision.
  const leafPanes = fn
    ? [...x86Scope.querySelectorAll('.col-x86-pane, .col-body')]
        .filter(el => !el.querySelector('.col-x86-pane'))
    : [];
  const searchScopes = leafPanes.length ? leafPanes : [x86Scope];

  const hits = [];
  for (const pane of searchScopes) {
    // Level 1: exact instruction (function + sequence index)
    let found = fn && seq !== undefined
      ? [...pane.querySelectorAll(`.x86-instr[data-ir-fn="${CSS.escape(fn)}"][data-ir-seq="${CSS.escape(seq)}"]`)]
      : [];
    // Level 2: function-scoped opcode (same function, same op type)
    if (!found.length && fn)
      found = [...pane.querySelectorAll(`.x86-instr[data-ir-fn="${CSS.escape(fn)}"][data-ir-op="${CSS.escape(op)}"]`)];
    hits.push(...found);
  }
  hits.forEach(el => el.classList.add('ir-highlight'));

  // Scroll each x86 pane to its own first hit
  const scrolled = new Set();
  for (const el of hits) {
    const pane = el.closest('.col-x86-pane') || el.closest('.col-body');
    if (pane && !scrolled.has(pane)) {
      scrolled.add(pane);
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }
}

/**
 * Render IR text as individual clickable line elements.
 * Returns a <div class="ir-lines"> containing one <div class="ir-line"> per line.
 */
function renderIrLines(irText, irFormat, fnNameMap) {
  const container = document.createElement('div');
  container.className = 'ir-lines';

  let currentFn   = null;
  let irSeq       = 0;
  let fnBody      = null;  // current function body div (null = top-level)

  function appendLine(div) {
    (fnBody || container).appendChild(div);
  }

  function startFnGroup(headerDiv, rawName) {
    const realName = (fnNameMap && fnNameMap[rawName]) || rawName;
    currentFn = realName;
    irSeq = 0;

    const group = document.createElement('div');
    group.className = 'ir-fn-group';

    const hdr = document.createElement('div');
    hdr.className = 'ir-fn-header';

    const arrow = document.createElement('span');
    arrow.className = 'ir-fn-arrow';
    arrow.textContent = '▼';

    const body = document.createElement('div');
    body.className = 'ir-fn-body';

    // Move the header line's text into the header row
    headerDiv.classList.add('ir-line');
    hdr.appendChild(arrow);
    hdr.appendChild(headerDiv);

    hdr.addEventListener('click', () => {
      const collapsed = body.classList.toggle('ir-fn-collapsed');
      arrow.textContent = collapsed ? '▶' : '▼';
    });

    group.appendChild(hdr);
    group.appendChild(body);
    container.appendChild(group);
    fnBody = body;
  }

  for (const line of irText.split('\n')) {
    const div = document.createElement('div');
    div.className = 'ir-line';
    div.textContent = line || '\u00a0';

    const t = line.trim();
    const fnMatch = irFormat === 'mce'
      ? t.match(/^(?:int|char|ptr|void)\s+(\w+)\s*\(/)
      : t.match(/^fn\s+@?(\w+)/);

    if (fnMatch) {
      startFnGroup(div, fnMatch[1]);
      continue;  // header div is owned by startFnGroup
    }

    // Detect block labels — mce: "label:" bare; mct: ".label:"
    const isBlockLabel = irFormat === 'mce'
      ? /^\w+:$/.test(t)
      : /^\.\w+:$/.test(t);
    if (isBlockLabel) div.classList.add('ir-block-label');

    const op = guessIrOp(line, irFormat);
    if (op) {
      div.dataset.irOp = op;
      if (currentFn) {
        div.dataset.irFn  = currentFn;
        div.dataset.irSeq = String(irSeq);
      }
      div.addEventListener('click', handleIrLineClick);
      irSeq++;
    }
    appendLine(div);
  }
  return container;
}

// ---------------------------------------------------------------------------
// Annotation map helpers
// ---------------------------------------------------------------------------

function buildAnnotMap(annotations, fnNameMap) {
  const map = new Map();
  if (!annotations) return map;
  for (const fn of annotations.functions || []) {
    const end  = fn.end_offset ?? (fn.offset + (fn.size || 0));
    const base = { kind: fn.kind };
    for (let i = fn.offset; i < end; i++) map.set(i, base);
  }
  for (const fn of annotations.functions || []) {
    const irFn = fnNameMap ? (fnNameMap[fn.name] || null) : null;
    for (const a of fn.annotations || []) {
      if (a.kind === 'block_label') continue; // handled separately via blockLabelMap
      const enriched = irFn ? { ...a, ir_fn: irFn } : a;
      for (let i = a.offset; i < a.offset + a.size; i++) map.set(i, enriched);
    }
  }
  return map;
}

function buildBlockLabelMap(annotations) {
  // Returns Map<offset, label> for block_label annotations
  const map = new Map();
  if (!annotations) return map;
  for (const fn of annotations.functions || []) {
    for (const a of fn.annotations || []) {
      if (a.kind === 'block_label' && a.label) map.set(a.offset, a.label);
    }
  }
  return map;
}

function buildFuncMap(annotations) {
  const map = new Map();
  if (!annotations) return map;
  for (const fn of annotations.functions || []) map.set(fn.offset, fn);
  return map;
}

// (sidebar is always visible — no .hidden toggle needed)

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Genome editor
// ---------------------------------------------------------------------------

const GENOME_DEFAULTS = {
  unfold_chance: 35, substitute_chance: 40, dead_code_chance: 25,
  nop_chance: 20, nop_max_count: 3,
  dead_prologue_pct: 30, dead_block_pct: 20, dead_instr_pct: 10,
  opaque_pct: 5, junk_call_block_pct: 8, junk_call_instr_pct: 3,
  harmless_block_pct: 3, harmless_instr_pct: 1,
  junk_func_pct: 50,
  unfold_weights: [250,250,250,250],
  dead_code_weights: [250,250,250,250],
  add_weights: [200,200,200,200,200],
  sub_weights: [250,250,250,250],
  movi_weights: [166,167,167,167,167,166],
  movi_zero_weights: [333,333,334],
  movi_neg1_weights: [333,333,334],
  xor_weights: [333,333,334],
  cmp_weights: [500,500],
  junk_seq_weights: [125,125,125,125,125,125,125,125],
  opaque_weights: [333,333,334],
  reorder_instrs_intensity: 2, reorder_locals_chance: 100,
  reorder_blocks_chance: 100, reorder_funcs_chance: 100,
};

const BAR_COLORS = [
  '#4488ff','#ff8833','#ffe033','#3a9a6e',
  '#cc55ff','#ff3355','#50c8f0','#8888aa'
];

// ---------------------------------------------------------------------------
// Transform card definitions (with genome mapping)
// ---------------------------------------------------------------------------

const TRANSFORM_INFO = [
  { id:'ir-obfuscate-names', group:'ir', title:'Obfuscate Names',
    desc:'Randomizes internal function and label names to hex strings, making static analysis harder.',
    example:'factorial \u2192 r57399c' },
  { id:'ir-unfold', group:'ir', title:'Constant Unfolding',
    desc:'Replaces constant expressions with equivalent multi-step computations.',
    example:'x = 42 \u2192 x = 21 + 21',
    sliders:[{id:'g-unfold-chance',label:'Unfold %',min:0,max:100,key:'unfold_chance'}],
    bars:[{id:'g-bar-unfold',gene:'unfold_weights',n:4,label:'Unfold forms'}] },
  { id:'ir-substitute', group:'ir', title:'Instruction Substitution',
    desc:'Replaces arithmetic operations with semantically equivalent but syntactically different forms.',
    example:'a + b \u2192 a - (-b)<br>a - b \u2192 a + (-b)<br>a * 2\u207f \u2192 a << n',
    sliders:[{id:'g-substitute-chance',label:'Substitute %',min:0,max:100,key:'substitute_chance'}] },
  { id:'ir-deadcode', group:'ir', title:'Dead Code Insertion',
    desc:'Inserts unreachable or no-effect IR instructions that do not change program behavior.',
    example:'Unused computations between real instructions',
    sliders:[{id:'g-dead-code-chance',label:'Dead code %',min:0,max:100,key:'dead_code_chance'}],
    bars:[{id:'g-bar-deadcode',gene:'dead_code_weights',n:4,label:'Dead code forms'}] },
  { id:'ir-nops', group:'ir', title:'NOP Insertion',
    desc:'Adds NOP (no-operation) instructions at random positions, changing code layout.',
    example:'Gaps filled with nop',
    sliders:[{id:'g-nop-chance',label:'NOP %',min:0,max:100,key:'nop_chance'},
             {id:'g-nop-max-count',label:'NOP max',min:1,max:10,key:'nop_max_count'}] },
  { id:'ir-reorder-instrs', group:'ir', title:'Reorder Instructions',
    desc:'Reorders independent instructions within basic blocks while preserving data dependencies.',
    example:'a = 1; b = 2 \u2192 b = 2; a = 1',
    sliders:[{id:'g-reorder-instrs-intensity',label:'Intensity',min:1,max:10,key:'reorder_instrs_intensity'}] },
  { id:'ir-reorder-locals', group:'ir', title:'Reorder Locals',
    desc:'Permutes local variable stack slot assignments. Same variables, different memory layout.',
    example:'local_0, local_1 \u2192 local_1, local_0',
    sliders:[{id:'g-reorder-locals-chance',label:'Reorder %',min:0,max:100,key:'reorder_locals_chance'}] },
  { id:'ir-reorder-blocks', group:'ir', title:'Reorder Blocks',
    desc:'Shuffles the order of basic blocks within functions, using jumps to maintain control flow.',
    example:'entry\u2192loop\u2192exit becomes exit\u2192entry\u2192loop',
    sliders:[{id:'g-reorder-blocks-chance',label:'Reorder %',min:0,max:100,key:'reorder_blocks_chance'}] },
  { id:'ir-reorder-funcs', group:'ir', title:'Reorder Functions',
    desc:'Shuffles the order of non-extern functions in the binary. Extern functions keep their indices.',
    example:'main, factorial \u2192 factorial, main',
    sliders:[{id:'g-reorder-funcs-chance',label:'Reorder %',min:0,max:100,key:'reorder_funcs_chance'}] },
  { id:'x86-poly-instrs', group:'x86', title:'Polymorphic Instructions',
    desc:'Replaces standard x86 instructions with semantically equivalent alternative encodings.',
    example:'MOV EAX,0 \u2192 XOR EAX,EAX',
    bars:[{id:'g-bar-add',gene:'add_weights',n:5,label:'ADD variants'},
          {id:'g-bar-sub',gene:'sub_weights',n:4,label:'SUB variants'},
          {id:'g-bar-movi',gene:'movi_weights',n:6,label:'MOV imm'},
          {id:'g-bar-movz',gene:'movi_zero_weights',n:3,label:'MOV zero'},
          {id:'g-bar-movn',gene:'movi_neg1_weights',n:3,label:'MOV -1'},
          {id:'g-bar-xor',gene:'xor_weights',n:3,label:'XOR variants'},
          {id:'g-bar-cmp',gene:'cmp_weights',n:2,label:'CMP variants'}] },
  { id:'x86-dead-code', group:'x86', title:'Dead Code Bytes',
    desc:'Inserts realistic multi-instruction junk sequences that look like real computation.',
    example:'MOV+XOR+ADD (fake hash), IMUL+ADD (fake multiply-accumulate)',
    sliders:[{id:'g-dead-prologue-pct',label:'Dead prologue %',min:0,max:100,key:'dead_prologue_pct'},
             {id:'g-dead-block-pct',label:'Dead block %',min:0,max:100,key:'dead_block_pct'},
             {id:'g-dead-instr-pct',label:'Dead instr %',min:0,max:100,key:'dead_instr_pct'}],
    bars:[{id:'g-bar-junkseq',gene:'junk_seq_weights',n:8,label:'Junk seq'}] },
  { id:'x86-opaque', group:'x86', title:'Opaque Predicates',
    desc:'Inserts conditional branches with always-true/false conditions, splitting linear code into apparent branches.',
    example:'Linear code gains JZ/JNZ with known outcomes',
    sliders:[{id:'g-opaque-pct',label:'Opaque %',min:0,max:100,key:'opaque_pct'}],
    bars:[{id:'g-bar-opaque',gene:'opaque_weights',n:3,label:'Opaque forms'}] },
  { id:'x86-junk-funcs', group:'x86', title:'Junk Functions',
    desc:'Generates random non-functional x86 functions placed alongside real code to confuse analysis.',
    example:'3\u20138 fake functions with random register operations',
    sliders:[{id:'g-junk-func-pct',label:'Junk func %',min:0,max:200,key:'junk_func_pct'},
             {id:'g-junk-call-block-pct',label:'Junk call blk %',min:0,max:100,key:'junk_call_block_pct'},
             {id:'g-junk-call-instr-pct',label:'Junk call ins %',min:0,max:100,key:'junk_call_instr_pct'}] },
  { id:'x86-harmless-calls', group:'x86', title:'Harmless API Calls',
    desc:'Inserts calls to benign OS APIs (GetTickCount, getpid) whose return values are discarded.',
    example:'CALL GetTickCount inserted before real code',
    sliders:[{id:'g-harmless-block-pct',label:'Harmless blk %',min:0,max:100,key:'harmless_block_pct'},
             {id:'g-harmless-instr-pct',label:'Harmless ins %',min:0,max:100,key:'harmless_instr_pct'}] },
  { id:'x86-shuffle-funcs', group:'x86', title:'Shuffle Functions',
    desc:'Randomizes the physical order of all functions (real + junk) in the final binary layout.',
    example:'Binary function order changes each compilation' },
];

// Variant descriptions for weight bars (keyed by gene name)
const VARIANT_DESCS = {
  unfold_weights: [
    { code:'a + b = const', desc:'ADD split — constant split into two addends' },
    { code:'a - b = const', desc:'SUB split — constant as subtraction' },
    { code:'a ^ b = const', desc:'XOR split — constant as XOR of two values' },
    { code:'a * b = const', desc:'MUL/shift split — constant as product or shifts' },
  ],
  dead_code_weights: [
    { code:'tmp = expr', desc:'Assign to unused temporary' },
    { code:'CMP a, b', desc:'Redundant comparison (result unused)' },
    { code:'tmp = a OP b', desc:'Dead arithmetic between real instructions' },
    { code:'x = expr; x = real', desc:'Assign then immediately overwrite' },
  ],
  add_weights: [
    { code:'ADD reg, reg', desc:'Standard ADD instruction' },
    { code:'LEA reg, [a+b]', desc:'Load effective address trick' },
    { code:'SUB reg, NEG(b)', desc:'Subtract negated operand: a − (−b)' },
    { code:'NOT+NEG+ADD+NOT', desc:'Bitwise decomposition chain' },
    { code:'XOR+AND+SHL+...', desc:'Bit-level add decomposition' },
  ],
  sub_weights: [
    { code:'SUB reg, reg', desc:'Standard SUB instruction' },
    { code:'NEG+ADD', desc:'Negate second operand then add: a + (−b)' },
    { code:'NOT+ADD+INC', desc:'Bitwise complement: a + ~b + 1' },
    { code:'XOR+AND+SHL+...', desc:'Bit-level subtract decomposition' },
  ],
  movi_weights: [
    { code:'MOV reg, imm', desc:'Standard immediate move' },
    { code:'PUSH imm / POP reg', desc:'Push constant, pop into register' },
    { code:'XOR reg,reg / ADD reg,imm', desc:'Zero then add constant' },
    { code:'XOR reg,reg / LEA reg,[reg+imm]', desc:'Zero then LEA with offset' },
    { code:'MOV reg, ~imm / NOT reg', desc:'Load bitwise complement then invert' },
    { code:'MOV reg, imm-1 / INC reg', desc:'Load one-less then increment' },
  ],
  movi_zero_weights: [
    { code:'XOR reg, reg', desc:'XOR register with itself' },
    { code:'SUB reg, reg', desc:'Subtract register from itself' },
    { code:'AND reg, 0', desc:'AND with zero' },
  ],
  movi_neg1_weights: [
    { code:'MOV reg, -1', desc:'Standard move −1 (0xFFFFFFFF)' },
    { code:'XOR reg,reg / DEC reg', desc:'Zero then decrement to −1' },
    { code:'XOR reg,reg / NOT reg', desc:'Zero then bitwise complement' },
  ],
  xor_weights: [
    { code:'XOR reg, reg', desc:'Standard XOR instruction' },
    { code:'NOT+AND / NOT+AND / OR', desc:'De Morgan decomposition: (a&~b)|(~a&b)' },
    { code:'PUSH / XOR [esp] / POP', desc:'XOR via stack memory' },
  ],
  cmp_weights: [
    { code:'CMP reg, reg', desc:'Standard CMP instruction' },
    { code:'MOV tmp,a / SUB tmp,b / restore', desc:'Subtract into scratch register' },
  ],
  junk_seq_weights: [
    { code:'MOV+ADD', desc:'Fake address calculation' },
    { code:'MOV+XOR+ADD', desc:'Fake hash computation' },
    { code:'LEA [reg+imm]', desc:'Fake pointer arithmetic' },
    { code:'PUSH+MOV+ADD+POP', desc:'Save/compute/restore (identity)' },
    { code:'IMUL+ADD', desc:'Fake multiply-accumulate' },
    { code:'MOV+CMP+SETcc', desc:'Comparison with flag set' },
    { code:'XOR+ADD+SUB', desc:'Zero then accumulate' },
    { code:'MOV [EBP-off]+ADD', desc:'Fake stack variable read' },
  ],
  opaque_weights: [
    { code:'x*(x+1) & 1 == 0', desc:'Product of consecutive integers is always even' },
    { code:'x²+x is even', desc:'x² + x is always divisible by 2' },
    { code:'3x²+x is even', desc:'3x² + x is always divisible by 2' },
  ],
};

// Additional detail text for transforms that don't have bars but deserve more explanation
const TRANSFORM_DETAIL = {
  'ir-obfuscate-names': 'All internal function names and labels are replaced with random hex strings (e.g. r57399c). Extern function names (API calls) are preserved. Each compilation produces different names.',
  'ir-reorder-instrs': 'Analyzes data dependencies within each basic block and produces a random topological ordering. Independent instructions can appear in any order, while dependent chains maintain their sequence.',
  'ir-reorder-locals': 'Local variable stack slots are assigned in a random permutation. This changes the memory layout of the function\'s stack frame without affecting behavior.',
  'ir-reorder-blocks': 'Basic blocks within each function are placed in random order. Unconditional jumps are inserted to maintain the original control flow graph.',
  'ir-reorder-funcs': 'Non-extern functions are shuffled to random positions. Extern functions (API imports) keep their original indices since the loader API table is indexed by function index.',
  'x86-shuffle-funcs': 'After code generation, all function bodies (real + junk) are placed in random physical order. Each compilation produces a different binary layout.',
};

// ---------------------------------------------------------------------------
// Render transforms view (table with per-variant columns)
// ---------------------------------------------------------------------------

let g_tfVariantCount = 2; // synced with #n-variants

function getVariantCount() {
  return Math.max(1, Math.min(99, parseInt($('n-variants').value, 10) || 2));
}

function renderTransformsView() {
  g_tfVariantCount = getVariantCount();
  const grid = $('transforms-grid');
  grid.innerHTML = '';

  const table = document.createElement('table');
  table.className = 'transforms-table';

  // Header row
  const thead = document.createElement('thead');
  const hrow = document.createElement('tr');
  const th0 = document.createElement('th');
  th0.textContent = 'Transform';
  hrow.appendChild(th0);
  for (let v = 0; v < g_tfVariantCount; v++) {
    const th = document.createElement('th');
    th.textContent = `V${v + 1}`;
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // Body rows
  const tbody = document.createElement('tbody');
  for (const t of TRANSFORM_INFO) {
    const row = document.createElement('tr');
    row.dataset.tfId = t.id;
    row.dataset.group = t.group;

    // Info cell (first column)
    const infoTd = document.createElement('td');
    const info = document.createElement('div');
    info.className = 'tf-info';

    const hdr = document.createElement('div');
    hdr.className = 'tf-info-header';
    const badge = document.createElement('span');
    badge.className = 'tf-info-group';
    badge.textContent = t.group;
    const title = document.createElement('span');
    title.className = 'tf-info-title';
    title.textContent = t.title;
    hdr.append(badge, title);
    info.appendChild(hdr);

    const desc = document.createElement('div');
    desc.className = 'tf-info-desc';
    desc.textContent = t.desc;
    info.appendChild(desc);

    if (t.example) {
      const ex = document.createElement('div');
      ex.className = 'tf-info-example';
      ex.innerHTML = 'Example: ' + t.example;
      info.appendChild(ex);
    }
    infoTd.appendChild(info);
    row.appendChild(infoTd);

    // Variant cells
    for (let v = 0; v < g_tfVariantCount; v++) {
      const td = document.createElement('td');
      const cell = document.createElement('div');
      cell.className = 'tf-cell enabled';
      cell.dataset.tfId = t.id;
      cell.dataset.variant = v;

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.className = 'tf-cb';
      cb.dataset.tfId = t.id;
      cb.dataset.variant = v;
      cb.checked = true;
      cb.addEventListener('change', () => {
        cell.classList.toggle('enabled', cb.checked);
        // In generational+mutate mode, V1 checkbox controls all variants
        if (v === 0 && $('flag-generational').checked &&
            $('flag-mutate-genome')?.checked) {
          document.querySelectorAll(`.tf-cb[data-tf-id="${t.id}"]`).forEach(other => {
            if (other !== cb) {
              other.checked = cb.checked;
              other.closest('.tf-cell')?.classList.toggle('enabled', cb.checked);
            }
          });
        }
      });
      cell.appendChild(cb);

      // Genome controls per variant cell
      if (t.sliders || t.bars) {
        const genome = document.createElement('div');
        genome.className = 'tf-cell-genome';

        if (t.sliders) {
          for (const s of t.sliders) {
            const srow = document.createElement('div');
            srow.className = 'genome-slider-row';
            const lbl = document.createElement('span');
            lbl.className = 'genome-label';
            lbl.textContent = s.label;
            const inp = document.createElement('input');
            inp.type = 'range';
            inp.className = 'genome-slider';
            inp.dataset.key = s.key;
            inp.dataset.variant = v;
            inp.min = s.min;
            inp.max = s.max;
            inp.value = GENOME_DEFAULTS[s.key];
            const val = document.createElement('span');
            val.className = 'genome-val';
            val.textContent = GENOME_DEFAULTS[s.key];
            inp.addEventListener('input', () => { val.textContent = inp.value; });
            srow.append(lbl, inp, val);
            genome.appendChild(srow);
          }
        }

        if (t.bars) {
          for (const b of t.bars) {
            const brow = document.createElement('div');
            brow.className = 'genome-weight-row';
            const lbl = document.createElement('span');
            lbl.className = 'genome-label';
            lbl.textContent = b.label;
            const bar = document.createElement('div');
            bar.className = 'genome-bar';
            bar.dataset.gene = b.gene;
            bar.dataset.variant = v;
            bar.dataset.n = b.n;
            brow.append(lbl, bar);
            genome.appendChild(brow);
          }
        }

        cell.appendChild(genome);
      }

      td.appendChild(cell);
      row.appendChild(td);
    }

    // Click row to show detail
    row.style.cursor = 'pointer';
    row.addEventListener('click', (e) => {
      // Don't trigger on checkbox/slider/bar clicks
      if (e.target.closest('input') || e.target.closest('.genome-bar')) return;
      document.querySelectorAll('.transforms-table tr.selected').forEach(r => r.classList.remove('selected'));
      row.classList.add('selected');
      showTransformDetail(t);
    });

    tbody.appendChild(row);
  }
  table.appendChild(tbody);
  grid.appendChild(table);

  initGenomeBars();
}

function showTransformDetail(t) {
  const panel = $('transforms-detail');
  let html = '';

  html += `<div class="tf-detail-title">${t.title}</div>`;
  html += `<div class="tf-detail-desc">${t.desc}</div>`;
  if (t.example) {
    html += `<div class="tf-detail-example">Example: ${t.example}</div>`;
  }

  // Extra detail text
  if (TRANSFORM_DETAIL[t.id]) {
    html += `<div class="tf-detail-desc">${TRANSFORM_DETAIL[t.id]}</div>`;
  }

  // Variant descriptions from weight bars
  if (t.bars) {
    for (const b of t.bars) {
      const variants = VARIANT_DESCS[b.gene];
      if (!variants) continue;
      html += '<div class="tf-detail-section">';
      html += `<div class="tf-detail-section-title">${b.label} (${variants.length} variants)</div>`;
      html += '<div class="tf-variant-list">';
      for (let i = 0; i < variants.length; i++) {
        const v = variants[i];
        const color = BAR_COLORS[i % BAR_COLORS.length];
        html += '<div class="tf-variant-item">';
        html += `<span class="tf-variant-idx" style="background:${color}">v${i}</span>`;
        html += `<span class="tf-variant-code">${v.code}</span>`;
        html += `<span class="tf-variant-desc">— ${v.desc}</span>`;
        html += '</div>';
      }
      html += '</div></div>';
    }
  }

  // Slider descriptions
  if (t.sliders) {
    html += '<div class="tf-detail-section">';
    html += '<div class="tf-detail-section-title">Parameters</div>';
    html += '<div class="tf-variant-list">';
    for (const s of t.sliders) {
      html += '<div class="tf-variant-item">';
      html += `<span class="tf-variant-code">${s.label}</span>`;
      html += `<span class="tf-variant-desc">— range ${s.min}–${s.max}, default ${GENOME_DEFAULTS[s.key]}</span>`;
      html += '</div>';
    }
    html += '</div></div>';
  }

  panel.innerHTML = html;
}

// Re-render table when variant count changes
$('n-variants').addEventListener('change', () => {
  const newN = getVariantCount();
  if (newN !== g_tfVariantCount) {
    renderTransformsView();
    updateMutateState();
  }
});

// ---------------------------------------------------------------------------
// Transforms view — presets
// ---------------------------------------------------------------------------

document.querySelectorAll('.preset-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const preset = btn.dataset.preset;
    document.querySelectorAll('.tf-cb').forEach(cb => {
      const row = cb.closest('tr');
      const group = row?.dataset.group;
      switch (preset) {
        case 'all':  cb.checked = true; break;
        case 'none': cb.checked = false; break;
        case 'ir':   cb.checked = (group === 'ir'); break;
        case 'x86':  cb.checked = (group === 'x86'); break;
      }
      cb.closest('.tf-cell')?.classList.toggle('enabled', cb.checked);
    });
  });
});

// Render a weight bar chart inside a .genome-bar element
function renderGenomeBar(barEl, weights) {
  barEl.innerHTML = '';
  const total = weights.reduce((a, b) => a + b, 0) || 1;
  weights.forEach((w, i) => {
    const seg = document.createElement('div');
    seg.className = 'genome-bar-seg';
    seg.style.flex = String(w);
    seg.style.minWidth = '8px';
    seg.style.background = BAR_COLORS[i % BAR_COLORS.length];
    seg.title = `v${i}: ${w} (${(100 * w / total).toFixed(0)}%)  [click +50 / right-click −50]`;
    seg.addEventListener('click', () => {
      barEl._weights[i] = Math.min(900, barEl._weights[i] + 50);
      renderGenomeBar(barEl, barEl._weights);
    });
    seg.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      barEl._weights[i] = Math.max(1, barEl._weights[i] - 50);
      renderGenomeBar(barEl, barEl._weights);
    });
    barEl.appendChild(seg);
  });
}

function initGenomeBars() {
  document.querySelectorAll('.genome-bar').forEach(bar => {
    const gene = bar.dataset.gene;
    const weights = GENOME_DEFAULTS[gene];
    if (weights) {
      bar._weights = [...weights];
      renderGenomeBar(bar, bar._weights);
    }
  });
}

// Toggle genome controls visibility
$('genome-enabled').addEventListener('change', () => {
  $('transforms-grid').classList.toggle('genome-visible', $('genome-enabled').checked);
});

// Reset genome to defaults
$('genome-reset').addEventListener('click', () => {
  document.querySelectorAll('.genome-slider').forEach(sl => {
    const key = sl.dataset.key;
    if (key && GENOME_DEFAULTS[key] !== undefined) {
      sl.value = GENOME_DEFAULTS[key];
      const val = sl.nextElementSibling;
      if (val?.classList.contains('genome-val')) val.textContent = GENOME_DEFAULTS[key];
    }
  });
  initGenomeBars();
  if ($('expression-rate')) $('expression-rate').value = 5;
  if ($('genome-temperature')) $('genome-temperature').value = 50;
});

// Load Genome from JSON file
$('genome-load-btn').addEventListener('click', () => {
  $('genome-file-input').click();
});

$('genome-file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const genome = JSON.parse(text);
    applyGenomeToUI(genome);
    logLine(`Loaded genome from ${file.name}`, 'ok');
  } catch (err) {
    showError(`Failed to load genome: ${err.message}`);
  }
  e.target.value = '';
});

function applyGenomeToUI(genome) {
  const gen = $('flag-generational').checked;
  const mut = $('flag-mutate-genome')?.checked || false;
  const applyAll = !(gen && mut);
  const maxV = applyAll ? g_tfVariantCount : 1;

  for (let v = 0; v < maxV; v++) {
    document.querySelectorAll(`.genome-slider[data-variant="${v}"]`).forEach(sl => {
      const val = genome[sl.dataset.key];
      if (val !== undefined) {
        sl.value = val;
        const vEl = sl.nextElementSibling;
        if (vEl?.classList.contains('genome-val')) vEl.textContent = val;
      }
    });
    document.querySelectorAll(`.genome-bar[data-variant="${v}"]`).forEach(bar => {
      const w = genome[bar.dataset.gene];
      if (w && Array.isArray(w)) {
        bar._weights = [...w];
        renderGenomeBar(bar, bar._weights);
      }
    });
  }

  if (!$('genome-enabled').checked) {
    $('genome-enabled').checked = true;
    $('transforms-grid').classList.add('genome-visible');
  }

  if (genome.expression_rate !== undefined && $('expression-rate')) {
    $('expression-rate').value = genome.expression_rate;
  }
  if (genome.genome_temperature !== undefined && $('genome-temperature')) {
    $('genome-temperature').value = genome.genome_temperature;
  }
}

// Read per-variant genome from UI → array of genome objects
function readGenomePerVariant() {
  if (!$('genome-enabled').checked) return null;
  const n = g_tfVariantCount;
  const genomes = [];
  const exprRate = parseInt($('expression-rate')?.value || '5', 10);
  const temperature = parseInt($('genome-temperature')?.value || '50', 10);
  for (let v = 0; v < n; v++) {
    const g = {};
    // Sliders
    document.querySelectorAll(`.genome-slider[data-variant="${v}"]`).forEach(sl => {
      g[sl.dataset.key] = parseInt(sl.value, 10);
    });
    // Weight bars
    document.querySelectorAll(`.genome-bar[data-variant="${v}"]`).forEach(bar => {
      if (bar._weights) g[bar.dataset.gene] = [...bar._weights];
    });
    // Gene expression
    g.expression_flags = 0x7FFF; // all transforms expressed by default
    g.expression_rate = exprRate;
    g.genome_temperature = temperature;
    genomes.push(g);
  }
  return genomes;
}

// Read per-variant transform flags → array of flag arrays
function gatherTransformFlagsPerVariant() {
  const n = g_tfVariantCount;
  const result = [];
  for (let v = 0; v < n; v++) {
    const flags = [];
    document.querySelectorAll(`.tf-cb[data-variant="${v}"]`).forEach(cb => {
      if (cb.checked) {
        flags.push('--' + cb.dataset.tfId);
      }
    });
    result.push(flags);
  }
  return result;
}

renderTransformsView();
// Apply initial genome visibility from the checked state
$('transforms-grid').classList.toggle('genome-visible', $('genome-enabled').checked);

// When generational+mutate is active, disable V2+ controls; V1 is master
function updateMutateState() {
  const gen = $('flag-generational').checked;
  const mut = $('flag-mutate-genome')?.checked || false;
  const lock = gen && mut;
  // Disable/enable V2+ genome sliders and bars
  document.querySelectorAll('.genome-slider, .genome-bar').forEach(el => {
    const v = parseInt(el.dataset.variant, 10);
    if (v > 0) {
      el.classList.toggle('locked', lock);
      if (el.tagName === 'INPUT') el.disabled = lock;
    }
  });
  // Visual hint on V2+ cells
  document.querySelectorAll('.tf-cell-genome').forEach(el => {
    const cell = el.closest('.tf-cell');
    const v = parseInt(cell?.dataset.variant, 10);
    if (v > 0) el.classList.toggle('locked', lock);
  });
  // Disable V2+ transform checkboxes and sync to V1 state
  document.querySelectorAll('.tf-cb').forEach(cb => {
    const v = parseInt(cb.dataset.variant, 10);
    if (v > 0) {
      cb.disabled = lock;
      if (lock) {
        const v1cb = document.querySelector(`.tf-cb[data-tf-id="${cb.dataset.tfId}"][data-variant="0"]`);
        if (v1cb) {
          cb.checked = v1cb.checked;
          cb.closest('.tf-cell')?.classList.toggle('enabled', v1cb.checked);
        }
      }
    }
  });
}
$('flag-generational').addEventListener('change', updateMutateState);
$('flag-mutate-genome')?.addEventListener('change', updateMutateState);

// ---------------------------------------------------------------------------
// Evolution view — populated from compile results
// ---------------------------------------------------------------------------

let g_evoData = null; // array of generation objects built from compile variants

// Build evolution data from compile result variants
function updateEvolutionView(result) {
  const variants = result.variants || [];
  if (variants.length < 2) {
    g_evoData = null;
    $('evo-timeline').innerHTML = '';
    $('evo-detail').innerHTML = '<div class="empty-state">Compile 2+ variants to see evolution</div>';
    $('evo-genome-table-wrap').innerHTML = '<div class="empty-state">Compile 2+ variants to see evolution</div>';
    return;
  }

  // Build evo data from variants
  let prevBin = null;
  let gen0Bin = null;
  g_evoData = variants.map((v, i) => {
    const binBytes = v.bin_hex || '';
    const size = binBytes.length / 2;
    const sha = v.sha256 || '';

    // Compute byte diff percentages
    let diffPrev = 0, diffGen0 = 0;
    if (prevBin && binBytes) {
      const len = Math.min(prevBin.length, binBytes.length) / 2;
      if (len > 0) {
        let diffs = 0;
        for (let j = 0; j < len * 2; j += 2) {
          if (prevBin.slice(j, j+2) !== binBytes.slice(j, j+2)) diffs++;
        }
        diffPrev = 100 * diffs / len;
      }
    }
    if (gen0Bin && binBytes) {
      const len = Math.min(gen0Bin.length, binBytes.length) / 2;
      if (len > 0) {
        let diffs = 0;
        for (let j = 0; j < len * 2; j += 2) {
          if (gen0Bin.slice(j, j+2) !== binBytes.slice(j, j+2)) diffs++;
        }
        diffGen0 = 100 * diffs / len;
      }
    }

    if (i === 0) gen0Bin = binBytes;
    prevBin = binBytes;

    return {
      gen: i,
      sha256: sha,
      size: size,
      entropy: v.entropy || 0,
      diff_pct: diffPrev,
      diff_from_gen0_pct: diffGen0,
      genome: v.genome || null,
    };
  });

  renderEvoTimeline();
  renderGenomeTable();
  if (g_evoData.length) selectEvoGen(0);
}

function renderEvoTimeline() {
  const tl = $('evo-timeline');
  tl.innerHTML = '';
  if (!g_evoData) return;
  g_evoData.forEach((gen, i) => {
    const btn = document.createElement('button');
    btn.className = 'evo-gen-btn';
    btn.textContent = `V${i + 1}`;
    btn.title = `sha: ${gen.sha256.slice(0,12)}…  size: ${gen.size}  diff: ${gen.diff_pct.toFixed(1)}%`;
    btn.addEventListener('click', () => selectEvoGen(i));
    tl.appendChild(btn);
  });
}

function selectEvoGen(idx) {
  document.querySelectorAll('.evo-gen-btn').forEach((b, i) =>
    b.classList.toggle('active', i === idx));

  const gen = g_evoData[idx];
  const detail = $('evo-detail');
  let html = '';

  // Summary
  html += '<div class="evo-summary">';
  html += `<span class="lbl">Variant</span><span class="val">V${gen.gen + 1}</span>`;
  html += `<span class="lbl">SHA-256</span><span class="val">${gen.sha256}</span>`;
  html += `<span class="lbl">Size</span><span class="val">${gen.size} bytes</span>`;
  html += `<span class="lbl">Entropy</span><span class="val">${gen.entropy.toFixed(4)}</span>`;
  if (idx > 0) {
    html += `<span class="lbl">Diff (prev)</span><span class="val">${gen.diff_pct.toFixed(2)}%</span>`;
    html += `<span class="lbl">Diff (V1)</span><span class="val">${gen.diff_from_gen0_pct.toFixed(2)}%</span>`;
  }
  html += '</div>';

  // Genome
  if (gen.genome) {
    const prevGenome = idx > 0 && g_evoData[idx - 1].genome
      ? g_evoData[idx - 1].genome : null;
    html += renderGenomeDiff(gen.genome, prevGenome, idx);
  } else {
    html += '<div class="evo-genome-diff"><div class="diff-title">No genome data</div></div>';
  }

  detail.innerHTML = html;
}

function renderGenomeDiff(genome, prevGenome, genIdx) {
  let html = '<div class="evo-genome-diff">';
  html += `<div class="diff-title">Genome${prevGenome ? ' (changes from prev)' : ' (initial)'}</div>`;

  // Split into scalars and vectors
  const keys = Object.keys(genome).sort();
  let changedCount = 0;

  // Scalars table
  const scalars = keys.filter(k => !Array.isArray(genome[k]));
  const vectors = keys.filter(k => Array.isArray(genome[k]));

  if (scalars.length) {
    html += '<div class="evo-genome-table">';
    for (const key of scalars) {
      const cur = genome[key];
      const prev = prevGenome ? prevGenome[key] : null;
      const changed = prevGenome && prev !== cur;
      if (changed) changedCount++;
      html += `<div class="evo-gene-row${changed ? ' changed' : ''}">`;
      html += `<span class="evo-gene-name">${key}</span>`;
      if (changed) {
        html += `<span class="evo-gene-old">${prev}</span>`;
        html += '<span class="evo-gene-arrow">→</span>';
      }
      html += `<span class="evo-gene-new">${cur}</span>`;
      html += '</div>';
    }
    html += '</div>';
  }

  // Vectors
  if (vectors.length) {
    html += '<div class="evo-genome-vectors">';
    for (const key of vectors) {
      const cur = genome[key];
      const prevArr = prevGenome && Array.isArray(prevGenome[key]) ? prevGenome[key] : null;
      let changed = false;
      if (prevArr) {
        for (let j = 0; j < cur.length; j++) {
          if (cur[j] !== prevArr[j]) { changed = true; break; }
        }
      }
      if (changed) changedCount++;

      html += `<div class="evo-gene-row${changed ? ' changed' : ''}">`;
      html += `<span class="evo-gene-name">${key}</span>`;

      // Render weight bar inline
      const total = cur.reduce((a, b) => a + b, 0) || 1;
      html += '<span class="evo-gene-bar">';
      cur.forEach((w, j) => {
        const pct = (100 * w / total).toFixed(0);
        const color = BAR_COLORS[j % BAR_COLORS.length];
        const delta = prevArr ? w - prevArr[j] : 0;
        const deltaStr = delta !== 0 ? ` (${delta > 0 ? '+' : ''}${delta})` : '';
        html += `<span class="evo-bar-seg" style="flex:${w};background:${color}" title="v${j}: ${w}${deltaStr}"></span>`;
      });
      html += '</span>';

      if (changed && prevArr) {
        // Show per-element changes
        const deltas = cur.map((c, j) => c - prevArr[j]).filter(d => d !== 0);
        html += `<span class="evo-gene-delta">${deltas.length} changed</span>`;
      }
      html += '</div>';
    }
    html += '</div>';
  }

  if (prevGenome && changedCount === 0) {
    html += '<div class="evo-gene-row" style="color:var(--text-dim)">No genes changed this generation</div>';
  } else if (prevGenome) {
    html = html.replace('(changes from prev)', `(${changedCount} gene${changedCount !== 1 ? 's' : ''} mutated)`);
  }

  html += '</div>';
  return html;
}

// Evolution view toggle (Per-Variant vs Genome Table)
document.querySelectorAll('.evo-view-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const view = btn.dataset.evoView;
    document.querySelectorAll('.evo-view-btn').forEach(b => b.classList.toggle('active', b === btn));
    $('evo-detail-view').style.display = view === 'detail' ? 'flex' : 'none';
    $('evo-table-view').style.display = view === 'table' ? '' : 'none';
  });
});

// Render side-by-side genome comparison table
// Build scalar gene range lookup from TRANSFORM_INFO sliders
const SCALAR_RANGES = {};
for (const t of TRANSFORM_INFO) {
  if (t.sliders) for (const s of t.sliders) SCALAR_RANGES[s.key] = { min: s.min, max: s.max };
}
SCALAR_RANGES['expression_flags'] = { min: 0, max: 32767 };
SCALAR_RANGES['expression_rate'] = { min: 0, max: 100 };

function scalarBar(val, key) {
  const range = SCALAR_RANGES[key] || { min: 0, max: 100 };
  const pct = Math.max(0, Math.min(100, 100 * (val - range.min) / (range.max - range.min || 1)));
  // Color: low=blue, mid=cyan, high=orange
  const hue = 200 - pct * 1.8; // 200 (blue) → 20 (orange)
  return `<div class="evo-scalar-bar" title="${val}">` +
    `<div class="evo-scalar-fill" style="width:${pct}%;background:hsl(${hue},70%,55%)"></div>` +
    `<span class="evo-scalar-label">${val}</span></div>`;
}

function weightBar(weights) {
  if (!weights || !weights.length) return '—';
  const total = weights.reduce((a, b) => a + b, 0) || 1;
  let html = '<div class="evo-weight-bar">';
  weights.forEach((w, i) => {
    const color = BAR_COLORS[i % BAR_COLORS.length];
    const pct = (100 * w / total).toFixed(1);
    html += `<div class="evo-weight-seg" style="flex:${w};background:${color}" title="v${i}: ${w} (${pct}%)"></div>`;
  });
  html += '</div>';
  return html;
}

function diffBar(pct) {
  const clamped = Math.min(100, pct);
  const hue = 120 - clamped * 1.2; // 120 (green=same) → 0 (red=different)
  return `<div class="evo-scalar-bar" title="${pct.toFixed(1)}%">` +
    `<div class="evo-scalar-fill" style="width:${clamped}%;background:hsl(${hue},70%,50%)"></div>` +
    `<span class="evo-scalar-label">${pct.toFixed(1)}%</span></div>`;
}

function renderGenomeTable() {
  const wrap = $('evo-genome-table-wrap');
  if (!g_evoData || !g_evoData.some(g => g.genome)) {
    wrap.innerHTML = '<div class="empty-state">Compile with Generational + Mutate Genome to see evolution</div>';
    return;
  }

  // Collect all gene keys
  const allKeys = new Set();
  for (const gen of g_evoData) {
    if (gen.genome) Object.keys(gen.genome).forEach(k => allKeys.add(k));
  }

  const ref = g_evoData.find(g => g.genome)?.genome || {};
  const scalarKeys = [...allKeys].filter(k => !Array.isArray(ref[k])).sort();
  const vectorKeys = [...allKeys].filter(k => Array.isArray(ref[k])).sort();
  const cols = g_evoData.length + 1;

  let html = '<table class="evo-cmp-table"><thead><tr><th>Gene</th>';
  for (let i = 0; i < g_evoData.length; i++) html += `<th>V${i + 1}</th>`;
  html += '</tr></thead><tbody>';

  // Stats
  html += `<tr class="section-header"><td colspan="${cols}">Stats</td></tr>`;
  html += '<tr><td>size (bytes)</td>';
  for (const gen of g_evoData) html += `<td>${gen.size}</td>`;
  html += '</tr>';
  html += '<tr><td>entropy</td>';
  for (const gen of g_evoData) html += `<td>${gen.entropy.toFixed(4)}</td>`;
  html += '</tr>';
  html += '<tr><td>sha256</td>';
  for (const gen of g_evoData) html += `<td title="${gen.sha256}">${gen.sha256.slice(0, 8)}…</td>`;
  html += '</tr>';
  html += '<tr><td>diff (prev)</td>';
  for (const gen of g_evoData) html += `<td>${diffBar(gen.diff_pct)}</td>`;
  html += '</tr>';
  html += '<tr><td>diff (V1)</td>';
  for (const gen of g_evoData) html += `<td>${diffBar(gen.diff_from_gen0_pct)}</td>`;
  html += '</tr>';

  // Scalar genes with colored bars
  if (scalarKeys.length) {
    html += `<tr class="section-header"><td colspan="${cols}">Scalar Genes</td></tr>`;
    for (const key of scalarKeys) {
      html += `<tr><td>${key}</td>`;
      let prevVal = null;
      for (const gen of g_evoData) {
        const val = gen.genome?.[key];
        const changed = prevVal !== null && val !== prevVal;
        html += `<td class="${changed ? 'changed' : ''}">${val != null ? scalarBar(val, key) : '—'}</td>`;
        prevVal = val;
      }
      html += '</tr>';
    }
  }

  // Vector genes with segmented color bars
  if (vectorKeys.length) {
    html += `<tr class="section-header"><td colspan="${cols}">Weight Vectors</td></tr>`;
    for (const key of vectorKeys) {
      html += `<tr><td>${key}</td>`;
      let prevArr = null;
      for (const gen of g_evoData) {
        const arr = gen.genome?.[key];
        const changed = prevArr && arr && arr.some((v, j) => v !== prevArr[j]);
        html += `<td class="${changed ? 'changed' : ''}">${weightBar(arr)}</td>`;
        prevArr = arr;
      }
      html += '</tr>';
    }
  }

  html += '</tbody></table>';
  wrap.innerHTML = html;
}

// Extract transform flags (union of all variants — used by evolution view)
function gatherTransformFlags() {
  const perVariant = gatherTransformFlagsPerVariant();
  // Union of all variant flags
  const set = new Set();
  for (const flags of perVariant) flags.forEach(f => set.add(f));
  return [...set];
}

// ---------------------------------------------------------------------------
// Project system
// ---------------------------------------------------------------------------

let g_project = null;  // { path, config } or null
let g_capabilities = null;
let g_serverCwd = '';

async function fetchCapabilities() {
  try {
    g_capabilities = await apiPost('/api/capabilities', {});
  } catch { g_capabilities = { outputs: { pic: true } }; }
  updateOutputAvailability();
}

// Fetch capabilities + CWD via GET on page load
(async function() {
  try {
    const res = await fetch('/api/capabilities');
    g_capabilities = await res.json();
  } catch { g_capabilities = { outputs: { pic: true } }; }
  updateOutputAvailability();

  try {
    const res2 = await fetch('/api/cwd');
    const data = await res2.json();
    g_serverCwd = data.cwd || '';
  } catch { g_serverCwd = ''; }
})();

function updateOutputAvailability() {
  const platform = document.querySelector('input[name="target-platform"]:checked')?.value || 'win32';
  const caps = g_capabilities?.outputs?.[platform] || {};
  const hasProject = g_project !== null;
  // PIC produces in-memory bytes that show up in the Variants tab, so it
  // works without a project on disk — the rest need a save destination.
  const ids = {
    pic:         { id: 'out-pic',         needsProject: false },
    standalone:  { id: 'out-standalone',  needsProject: true  },
    recompiler:  { id: 'out-recompiler',  needsProject: true  },
    infector:    { id: 'out-infector',    needsProject: true  },
    integrator:  { id: 'out-integrator',  needsProject: true  },
  };
  for (const [key, spec] of Object.entries(ids)) {
    const cb = $(spec.id);
    const row = cb?.closest('.output-row');
    if (!row || !cb) continue;
    const available = caps[key] !== false;
    const enabled = available && (hasProject || !spec.needsProject);
    row.classList.toggle('disabled', !enabled);
    cb.disabled = !enabled;
    if (!enabled) cb.checked = false;
    // Tooltip text now lives on the inline .tip icon (always hoverable),
    // so we no longer mutate row.title here.  The disabled state is
    // signalled visually via .disabled class + the no-project-hint above.
  }
  const hint = $('no-project-hint');
  if (hint) hint.style.display = hasProject ? 'none' : 'block';
}

// Refresh availability when the user switches platform — different .mcbs
// are required and previously-checked outputs may no longer apply.
document.querySelectorAll('input[name="target-platform"]').forEach(r => {
  r.addEventListener('change', updateOutputAvailability);
});

function buildProjectConfig() {
  const n = g_tfVariantCount;
  const perVariant = [];
  for (let v = 0; v < n; v++) {
    const transforms = {};
    for (const t of TRANSFORM_INFO) {
      const key = t.id.replace(/-/g, '_');
      const cb = document.querySelector(`.tf-cb[data-tf-id="${t.id}"][data-variant="${v}"]`);
      transforms[key] = cb ? cb.checked : true;
    }
    // Genome for this variant
    const genome = {};
    document.querySelectorAll(`.genome-slider[data-variant="${v}"]`).forEach(sl => {
      genome[sl.dataset.key] = parseInt(sl.value, 10);
    });
    document.querySelectorAll(`.genome-bar[data-variant="${v}"]`).forEach(bar => {
      if (bar._weights) genome[bar.dataset.gene] = [...bar._weights];
    });
    perVariant.push({ transforms, genome });
  }

  const seedMode = document.querySelector('input[name="seed-mode"]:checked')?.value || 'random';

  return {
    version: 2,
    source_file: g_project?.config?.source_file || 'program.mc',
    target_platform: document.querySelector('input[name="target-platform"]:checked')?.value || 'win32',
    ir_format: document.querySelector('input[name="ir-format"]:checked')?.value || 'mce',
    seed_mode: seedMode,
    seed_value: parseInt($('seed-value').value, 10) || 1001,
    n_variants: n,
    generational: $('flag-generational').checked,
    mutate_genome: $('flag-mutate-genome')?.checked || false,
    output_formats: {
      pic:        $('out-pic')?.checked         || false,
      standalone: $('out-standalone')?.checked  || false,
      recompiler: $('out-recompiler')?.checked  || false,
      infector:   $('out-infector')?.checked    || false,
      integrator: $('out-integrator')?.checked  || false,
    },
    strip_debug: $('strip-debug')?.checked || false,
    scramble_globals: $('scramble-globals')?.checked || false,
    per_variant: perVariant,
    genome_enabled: $('genome-enabled').checked,
    expression_rate: parseInt($('expression-rate')?.value || '5', 10),
    genome_temperature: parseInt($('genome-temperature')?.value || '50', 10),
  };
}

function loadProjectConfig(config) {
  // Seed
  if (config.seed_mode) {
    const radio = document.querySelector(`input[name="seed-mode"][value="${config.seed_mode}"]`);
    if (radio) radio.checked = true;
  }
  if (config.seed_value !== undefined) $('seed-value').value = config.seed_value;

  // Variants count — set before re-rendering transforms table
  if (config.n_variants !== undefined) $('n-variants').value = config.n_variants;
  if (config.generational !== undefined) $('flag-generational').checked = config.generational;
  if (config.mutate_genome !== undefined && $('flag-mutate-genome')) {
    $('flag-mutate-genome').checked = config.mutate_genome;
  }

  // IR format
  if (config.ir_format) {
    const radio = document.querySelector(`input[name="ir-format"][value="${config.ir_format}"]`);
    if (radio) radio.checked = true;
  }

  // Target platform
  if (config.target_platform) {
    const radio = document.querySelector(`input[name="target-platform"][value="${config.target_platform}"]`);
    if (radio) radio.checked = true;
  }

  // Output formats
  if (config.output_formats) {
    for (const [key, val] of Object.entries(config.output_formats)) {
      const id = 'out-' + key.replace(/_/g, '-');
      const cb = $(id);
      if (cb && !cb.disabled) cb.checked = val;
    }
  }

  // Source options
  if ($('strip-debug')) $('strip-debug').checked = !!config.strip_debug;
  if ($('scramble-globals')) $('scramble-globals').checked = !!config.scramble_globals;

  // Genome toggle
  $('genome-enabled').checked = !!config.genome_enabled;
  $('transforms-grid').classList.toggle('genome-visible', !!config.genome_enabled);

  // Expression rate
  if (config.expression_rate !== undefined && $('expression-rate')) {
    $('expression-rate').value = config.expression_rate;
  }
  // Genome temperature
  if (config.genome_temperature !== undefined && $('genome-temperature')) {
    $('genome-temperature').value = config.genome_temperature;
  }

  // Re-render transforms table with correct variant count
  renderTransformsView();

  // Load per-variant settings (v2 format)
  if (config.per_variant && Array.isArray(config.per_variant)) {
    config.per_variant.forEach((pv, v) => {
      if (pv.transforms) {
        for (const [key, val] of Object.entries(pv.transforms)) {
          const tfId = key.replace(/_/g, '-');
          const cb = document.querySelector(`.tf-cb[data-tf-id="${tfId}"][data-variant="${v}"]`);
          if (cb) {
            cb.checked = val;
            cb.closest('.tf-cell')?.classList.toggle('enabled', val);
          }
        }
      }
      if (pv.genome) {
        // Sliders
        document.querySelectorAll(`.genome-slider[data-variant="${v}"]`).forEach(sl => {
          const val = pv.genome[sl.dataset.key];
          if (val !== undefined) {
            sl.value = val;
            const vEl = sl.nextElementSibling;
            if (vEl?.classList.contains('genome-val')) vEl.textContent = val;
          }
        });
        // Bars
        document.querySelectorAll(`.genome-bar[data-variant="${v}"]`).forEach(bar => {
          const w = pv.genome[bar.dataset.gene];
          if (w) {
            bar._weights = [...w];
            renderGenomeBar(bar, bar._weights);
          }
        });
      }
    });
  } else if (config.transforms) {
    // Legacy v1 format — apply same transforms to all variants
    for (const [key, val] of Object.entries(config.transforms)) {
      const tfId = key.replace(/_/g, '-');
      document.querySelectorAll(`.tf-cb[data-tf-id="${tfId}"]`).forEach(cb => {
        cb.checked = val;
        cb.closest('.tf-cell')?.classList.toggle('enabled', val);
      });
    }
    // Legacy genome — apply to all variants
    if (config.genome) {
      document.querySelectorAll('.genome-slider').forEach(sl => {
        const val = config.genome[sl.dataset.key];
        if (val !== undefined) {
          sl.value = val;
          const vEl = sl.nextElementSibling;
          if (vEl?.classList.contains('genome-val')) vEl.textContent = val;
        }
      });
      document.querySelectorAll('.genome-bar').forEach(bar => {
        const w = config.genome[bar.dataset.gene];
        if (w) {
          bar._weights = [...w];
          renderGenomeBar(bar, bar._weights);
        }
      });
    }
  }
}

function setProjectUI(proj) {
  g_project = proj;
  if (proj) {
    const name = proj.path.split(/[\\/]/).pop();
    $('project-name').textContent = name;
    $('project-name').title = proj.path;
  } else {
    $('project-name').textContent = 'No Project';
    $('project-name').title = '';
  }
  updateOutputAvailability();
}

// ---------------------------------------------------------------------------
// Project modal (New / Open with directory browser)
// ---------------------------------------------------------------------------

let g_modalMode = 'open'; // 'open' | 'new'
let g_modalBrowsePath = '';

function showModal(mode) {
  g_modalMode = mode;
  $('modal-title').textContent = mode === 'new' ? 'New Project' : 'Open Project';
  $('modal-path').value = '';
  $('modal-entries').innerHTML = '';

  // Show/hide name field; change path label
  const nameField = $('modal-name-field');
  const pathLabel = $('modal-path-label');
  if (mode === 'new') {
    nameField.style.display = '';
    $('modal-name').value = '';
    pathLabel.textContent = 'Parent:';
  } else {
    nameField.style.display = 'none';
    pathLabel.textContent = 'Path:';
  }

  $('project-modal').classList.add('visible');

  // Default browse directory = server CWD
  const startPath = g_serverCwd || (navigator.platform.startsWith('Win') ? 'C:\\' : '/');
  browseDir(startPath);
}

function hideModal() {
  $('project-modal').classList.remove('visible');
}

async function browseDir(path) {
  g_modalBrowsePath = path;
  $('modal-cwd').textContent = path;
  $('modal-entries').innerHTML = '<div style="padding:8px;color:var(--text-dim)">Loading...</div>';

  try {
    const resp = await apiPost('/api/project/list-dir', { path });
    $('modal-cwd').textContent = resp.path || path;
    g_modalBrowsePath = resp.path || path;

    const container = $('modal-entries');
    container.innerHTML = '';
    if (!resp.entries || resp.entries.length === 0) {
      container.innerHTML = '<div style="padding:8px;color:var(--text-dim)">Empty directory</div>';
      return;
    }
    for (const e of resp.entries) {
      const row = document.createElement('div');
      row.className = 'modal-entry' + (e.has_project ? ' has-project' : '') + (!e.is_dir ? ' is-file' : '');
      const icon = document.createElement('span');
      icon.className = 'entry-icon';
      icon.textContent = e.is_dir ? (e.has_project ? '\u{1F4C1}' : '\u{1F4C2}') : '\u{1F4C4}';
      const name = document.createElement('span');
      name.textContent = e.name + (e.has_project ? ' [project]' : '');
      row.append(icon, name);

      if (e.is_dir) {
        row.addEventListener('click', () => {
          const newPath = g_modalBrowsePath + (g_modalBrowsePath.endsWith('/') || g_modalBrowsePath.endsWith('\\') ? '' : '/') + e.name;
          $('modal-path').value = newPath;
          browseDir(newPath);
        });
      }
      container.appendChild(row);
    }
  } catch (err) {
    $('modal-entries').innerHTML = `<div style="padding:8px;color:var(--col-dead)">${err.message}</div>`;
  }
}

$('modal-up-btn').addEventListener('click', () => {
  let p = g_modalBrowsePath.replace(/[\\/]+$/, '');
  const sep = p.includes('\\') ? '\\' : '/';
  const parts = p.split(/[\\/]/);
  if (parts.length > 1) {
    parts.pop();
    let parent = parts.join(sep);
    if (parent.match(/^[A-Za-z]:$/)) parent += sep; // e.g. C:\
    if (!parent) parent = '/';
    $('modal-path').value = parent;
    browseDir(parent);
  }
});

$('modal-cancel').addEventListener('click', hideModal);

$('modal-confirm').addEventListener('click', async () => {
  try {
    let resp;
    if (g_modalMode === 'new') {
      const name = $('modal-name').value.trim();
      const parent = $('modal-path').value.trim() || g_modalBrowsePath;
      if (!name) { showError('Project name is required'); return; }
      if (!parent) { showError('Parent directory is required'); return; }
      resp = await apiPost('/api/project/create', { name, parent });
    } else {
      const path = $('modal-path').value.trim();
      if (!path) return;
      resp = await apiPost('/api/project/open', { path });
    }
    setProjectUI({ path: resp.path, config: resp.config });
    loadProjectConfig(resp.config);
    editor.setValue(resp.source || '');
    setStatus(`Project: ${resp.path.split(/[\\/]/).pop()}`);
    hideModal();
  } catch (err) {
    showError(err.message);
  }
});

$('proj-new-btn').addEventListener('click', () => showModal('new'));
$('proj-open-btn').addEventListener('click', () => showModal('open'));
$('proj-save-btn').addEventListener('click', async () => {
  if (!g_project) {
    showModal('new');
    return;
  }
  try {
    const config = buildProjectConfig();
    await apiPost('/api/project/save', {
      path: g_project.path,
      config,
      source: editor.getValue(),
    });
    g_project.config = config;
    setStatus('Saved');
  } catch (err) {
    showError(err.message);
  }
});

// ---------------------------------------------------------------------------
// Diff view — byte-level signature analysis + smart IR diff
// ---------------------------------------------------------------------------

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++)
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return bytes;
}

function computeByteStats(hexA, hexB) {
  const a = hexToBytes(hexA);
  const b = hexToBytes(hexB);
  const minLen = Math.min(a.length, b.length);
  const maxLen = Math.max(a.length, b.length);

  // Same-offset byte identity
  let sameCount = 0;
  const diffMap = new Uint8Array(maxLen);
  diffMap.fill(1); // default different
  for (let i = 0; i < minLen; i++) {
    if (a[i] === b[i]) { sameCount++; diffMap[i] = 0; }
  }

  // Longest common byte run at same offset
  let maxRun = 0, maxRunOff = 0, run = 0, runStart = 0;
  for (let i = 0; i < minLen; i++) {
    if (a[i] === b[i]) {
      if (run === 0) runStart = i;
      run++;
      if (run > maxRun) { maxRun = run; maxRunOff = runStart; }
    } else {
      run = 0;
    }
  }

  // N-gram analysis: how many unique n-grams from A appear anywhere in B?
  function ngramStats(n) {
    if (a.length < n || b.length < n) return { shared: 0, uniqueA: 0, uniqueB: 0 };
    function makeKey(arr, off, len) {
      let k = '';
      for (let i = 0; i < len; i++) k += String.fromCharCode(arr[off + i]);
      return k;
    }
    const setA = new Set();
    for (let i = 0; i <= a.length - n; i++) setA.add(makeKey(a, i, n));
    const setB = new Set();
    for (let i = 0; i <= b.length - n; i++) setB.add(makeKey(b, i, n));
    let shared = 0;
    for (const k of setA) { if (setB.has(k)) shared++; }
    return { shared, uniqueA: setA.size, uniqueB: setB.size };
  }

  // Longest common byte substring (anywhere, not just same offset)
  // Binary search: if shared n-grams exist at length n, they exist at length n-1 too
  let longestAnywhere = 0;
  if (a.length <= 16384 && b.length <= 16384) {
    let lo = 1, hi = Math.min(64, minLen);
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (ngramStats(mid).shared > 0) { longestAnywhere = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
  }

  return {
    sizeA: a.length, sizeB: b.length,
    sameOffset: sameCount,
    sameOffsetPct: minLen > 0 ? (100 * sameCount / minLen) : 0,
    longestRun: maxRun, longestRunOffset: maxRunOff,
    longestAnywhere,
    diffMap, bytesA: a, bytesB: b,
    ngram4:  ngramStats(4),
    ngram8:  ngramStats(8),
    ngram16: ngramStats(16),
    ngram32: ngramStats(32),
  };
}

// --- IR parsing for diff ---

function parseIrFunctions(irText, irFormat) {
  if (!irText) return [];
  const funcs = [];
  let current = null;

  for (const line of irText.split('\n')) {
    const t = line.trim();
    const fnMatch = irFormat === 'mce'
      ? t.match(/^(?:int|char|ptr|void)\s+(\w+)\s*\(/)
      : t.match(/^\.?func\s+@?(\w+)/);

    if (fnMatch) {
      if (current) funcs.push(current);
      current = { name: fnMatch[1], lines: [], ops: [] };
      continue;
    }
    if (t === '.end' || (irFormat === 'mce' && t === '}')) {
      if (current) { funcs.push(current); current = null; }
      continue;
    }
    if (current) {
      const op = guessIrOp(line, irFormat);
      current.lines.push({ text: t, op: op });
      if (op) current.ops.push(op);
    }
  }
  if (current) funcs.push(current);
  return funcs;
}

// --- LCS for opcode alignment ---

function lcsBacktrack(seqA, seqB) {
  const m = seqA.length, n = seqB.length;
  if (m === 0 || n === 0) return [];
  const dp = Array.from({ length: m + 1 }, () => new Uint16Array(n + 1));
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = seqA[i - 1] === seqB[j - 1]
        ? dp[i - 1][j - 1] + 1
        : Math.max(dp[i - 1][j], dp[i][j - 1]);
  const pairs = [];
  let i = m, j = n;
  while (i > 0 && j > 0) {
    if (seqA[i - 1] === seqB[j - 1]) {
      pairs.push({ a: i - 1, b: j - 1 });
      i--; j--;
    } else if (dp[i - 1][j] >= dp[i][j - 1]) {
      i--;
    } else {
      j--;
    }
  }
  return pairs.reverse();
}

function lcsScore(seqA, seqB) {
  const m = seqA.length, n = seqB.length;
  if (m === 0 && n === 0) return 1;
  if (m === 0 || n === 0) return 0;
  let prev = new Uint16Array(n + 1);
  let curr = new Uint16Array(n + 1);
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++)
      curr[j] = seqA[i - 1] === seqB[j - 1]
        ? prev[j - 1] + 1
        : Math.max(prev[j], curr[j - 1]);
    [prev, curr] = [curr, prev];
    curr.fill(0);
  }
  return prev[n] / Math.max(m, n);
}

// --- Function matching across variants ---

function matchIrFunctions(funcsA, funcsB) {
  const used = new Set();
  const matches = [];

  for (const fa of funcsA) {
    let bestScore = 0, bestIdx = -1;
    for (let j = 0; j < funcsB.length; j++) {
      if (used.has(j)) continue;
      const score = lcsScore(fa.ops, funcsB[j].ops);
      if (score > bestScore) { bestScore = score; bestIdx = j; }
    }
    if (bestIdx >= 0 && bestScore >= 0.3) {
      used.add(bestIdx);
      matches.push({ a: fa, b: funcsB[bestIdx], score: bestScore });
    } else {
      matches.push({ a: fa, b: null, score: 0 });
    }
  }
  for (let j = 0; j < funcsB.length; j++) {
    if (!used.has(j)) matches.push({ a: null, b: funcsB[j], score: 0 });
  }
  return matches;
}

// --- Build diff rows for a matched function pair ---

function buildFuncDiffRows(funcA, funcB, irFormat) {
  // Get instruction-only lines with their ops
  const insA = funcA.lines.filter(l => l.op);
  const insB = funcB.lines.filter(l => l.op);
  const opsA = insA.map(l => l.op);
  const opsB = insB.map(l => l.op);

  const pairs = lcsBacktrack(opsA, opsB);
  const rows = [];
  let ai = 0, bi = 0;

  for (const { a: aIdx, b: bIdx } of pairs) {
    while (ai < aIdx) { rows.push({ a: insA[ai].text, b: null, type: 'delete' }); ai++; }
    while (bi < bIdx) { rows.push({ a: null, b: insB[bi].text, type: 'insert' }); bi++; }
    const same = insA[aIdx].text === insB[bIdx].text;
    rows.push({ a: insA[aIdx].text, b: insB[bIdx].text, type: same ? 'same' : 'changed' });
    ai = aIdx + 1; bi = bIdx + 1;
  }
  while (ai < insA.length) { rows.push({ a: insA[ai].text, b: null, type: 'delete' }); ai++; }
  while (bi < insB.length) { rows.push({ a: null, b: insB[bi].text, type: 'insert' }); bi++; }
  return rows;
}

// --- Render byte heatmap on canvas ---

function renderByteHeatmap(canvas, bytesA, bytesB, diffMap) {
  const cellSize = 10;
  const bytesPerRow = 128;
  const maxLen = Math.max(bytesA.length, bytesB.length);
  const rows = Math.ceil(maxLen / bytesPerRow);
  const width = bytesPerRow * cellSize;
  const rowHeight = cellSize;
  // Two strips: A on top, gap, B on bottom
  const gap = 8;
  const totalHeight = rows * rowHeight * 2 + gap;

  canvas.width = width;
  canvas.height = totalHeight;
  canvas.style.width = width + 'px';
  canvas.style.height = totalHeight + 'px';

  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0d0d0d';
  ctx.fillRect(0, 0, width, totalHeight);

  const colSame = '#1a5a3a';
  const colDiff = '#cc3344';
  const colMissing = '#222233';

  function drawStrip(bytes, otherLen, yBase) {
    for (let i = 0; i < maxLen; i++) {
      const row = Math.floor(i / bytesPerRow);
      const col = i % bytesPerRow;
      const x = col * cellSize;
      const y = yBase + row * rowHeight;

      if (i >= bytes.length) {
        ctx.fillStyle = colMissing;
      } else if (i >= otherLen) {
        ctx.fillStyle = colDiff;
      } else {
        ctx.fillStyle = diffMap[i] === 0 ? colSame : colDiff;
      }
      ctx.fillRect(x, y, cellSize - 1, rowHeight - 1);
    }
  }

  drawStrip(bytesA, bytesB.length, 0);
  drawStrip(bytesB, bytesA.length, rows * rowHeight + gap);
}

// --- x86 diff: segment a function's disasm into IR-anchored groups + junk ---

function buildFuncSegments(disasm, annotMap, fnOffset, fnEnd) {
  const segments = [];
  let curSeg = null;

  for (const ins of disasm) {
    if (ins.offset < fnOffset || ins.offset >= fnEnd) continue;
    const ann = annotMap.get(ins.offset);
    const hasIr = ann && ann.ir_seq !== undefined && ann.ir_fn;

    if (hasIr) {
      if (!curSeg || curSeg.type !== 'ir' || curSeg.seq !== ann.ir_seq) {
        curSeg = { type: 'ir', seq: ann.ir_seq, op: ann.ir_op || '', instrs: [] };
        segments.push(curSeg);
      }
    } else {
      if (!curSeg || curSeg.type !== 'junk') {
        curSeg = { type: 'junk', kind: ann?.kind || 'unknown', instrs: [] };
        segments.push(curSeg);
      }
    }
    curSeg.instrs.push(ins);
  }
  return segments;
}

function alignX86ByOpLCS(segsA, segsB) {
  // Separate IR segments and junk
  const irA = segsA.filter(s => s.type === 'ir');
  const irB = segsB.filter(s => s.type === 'ir');

  // LCS alignment on ir_op (semantic opcode — comparable across different IRs)
  const opsA = irA.map(s => s.op);
  const opsB = irB.map(s => s.op);
  const pairs = lcsBacktrack(opsA, opsB);

  const rows = [];
  let ai = 0, bi = 0;

  for (const { a: aIdx, b: bIdx } of pairs) {
    while (ai < aIdx) {
      rows.push({ type: 'only-a', op: irA[ai].op, a: irA[ai].instrs, b: [] });
      ai++;
    }
    while (bi < bIdx) {
      rows.push({ type: 'only-b', op: irB[bi].op, a: [], b: irB[bi].instrs });
      bi++;
    }
    rows.push({ type: 'matched', op: irA[aIdx].op, a: irA[aIdx].instrs, b: irB[bIdx].instrs });
    ai = aIdx + 1;
    bi = bIdx + 1;
  }
  while (ai < irA.length) {
    rows.push({ type: 'only-a', op: irA[ai].op, a: irA[ai].instrs, b: [] });
    ai++;
  }
  while (bi < irB.length) {
    rows.push({ type: 'only-b', op: irB[bi].op, a: [], b: irB[bi].instrs });
    bi++;
  }

  // Collect junk from both sides
  const junkInstrsA = segsA.filter(s => s.type === 'junk').flatMap(s => s.instrs);
  const junkInstrsB = segsB.filter(s => s.type === 'junk').flatMap(s => s.instrs);
  if (junkInstrsA.length || junkInstrsB.length) {
    rows.push({ type: 'junk', op: '', a: junkInstrsA, b: junkInstrsB });
  }

  return rows;
}

function renderMiniDisasm(instrs) {
  const div = document.createElement('div');
  div.className = 'mini-disasm';
  for (const ins of instrs) {
    const line = document.createElement('div');
    line.className = 'mini-disasm-line';

    const off = document.createElement('span');
    off.className = 'off';
    off.textContent = ins.offset.toString(16).padStart(4, '0');

    const hex = document.createElement('span');
    hex.className = 'hex';
    hex.textContent = (ins.bytes || '').slice(0, 14);

    const txt = document.createElement('span');
    txt.className = 'text';
    txt.textContent = ins.text;

    line.append(off, hex, txt);
    div.appendChild(line);
  }
  return div;
}

// --- Main diff view rendering ---

function updateDiffView(result, irFormat) {
  const variants = result?.variants || [];
  const selA = $('diff-variant-a');
  const selB = $('diff-variant-b');
  const emptyMsg = '<div class="empty-state">Compile 2+ variants, then switch to Diff</div>';

  selA.innerHTML = '';
  selB.innerHTML = '';
  if (variants.length < 2) {
    $('diff-tab-bytes').innerHTML = emptyMsg;
    return;
  }

  const isGen = result.generational;
  for (let i = 0; i < variants.length; i++) {
    const label = isGen ? `Gen ${i}` : `Variant #${i + 1}`;
    selA.appendChild(new Option(label, i));
    selB.appendChild(new Option(label, i));
  }
  selB.value = '1';

  function doRender() {
    const ai = parseInt(selA.value, 10);
    const bi = parseInt(selB.value, 10);
    renderDiffContent(variants[ai], variants[bi], ai, bi, result, irFormat, isGen);
  }

  selA.onchange = doRender;
  selB.onchange = doRender;
  doRender();
}

function renderDiffContent(vA, vB, idxA, idxB, result, irFormat, isGen) {
  const panelBytes = $('diff-tab-bytes');
  panelBytes.innerHTML = '';

  if (!vA || !vB || vA.error || vB.error) {
    panelBytes.innerHTML = '<div class="empty-state">Selected variant has errors</div>';
    return;
  }

  const labelA = isGen ? `Gen ${idxA}` : `V${idxA + 1}`;
  const labelB = isGen ? `Gen ${idxB}` : `V${idxB + 1}`;
  renderBytesTab(panelBytes, vA, vB, labelA, labelB);
}

function renderByteStatsBlock(panel, hexA, hexB, labelA, labelB, title) {
  const stats = computeByteStats(hexA, hexB);

  const ngramRow = (n, ng) => {
    const total = Math.max(ng.uniqueA, ng.uniqueB);
    const pct = total > 0 ? (100 * ng.shared / total).toFixed(1) : '0.0';
    return `<tr><td>${n}-byte</td><td>${ng.shared}</td><td>${total}</td><td>${pct}%</td></tr>`;
  };

  const section1 = document.createElement('div');
  section1.className = 'diff-section';
  section1.innerHTML = `
    <div class="diff-section-title">${title}</div>
    <div class="diff-stats-grid">
      <div class="diff-stat-block">
        <table class="diff-stat-table">
          <tr><td class="lbl">${labelA}</td><td>${stats.sizeA.toLocaleString()} bytes</td></tr>
          <tr><td class="lbl">${labelB}</td><td>${stats.sizeB.toLocaleString()} bytes</td></tr>
        </table>
      </div>
      <div class="diff-stat-block">
        <table class="diff-stat-table">
          <tr><td class="lbl">Byte identity (same offset)</td><td class="val-big ${stats.sameOffsetPct < 10 ? 'val-red' : ''}">${stats.sameOffsetPct.toFixed(1)}%</td><td>(${stats.sameOffset} / ${Math.min(stats.sizeA, stats.sizeB)})</td></tr>
          <tr><td class="lbl">Longest identical run</td><td class="val-big ${stats.longestRun <= 8 ? 'val-red' : ''}">${stats.longestRun} bytes</td><td>at offset 0x${stats.longestRunOffset.toString(16)}</td></tr>
          <tr><td class="lbl">Longest common substring</td><td class="val-big ${stats.longestAnywhere <= 8 ? 'val-red' : ''}">${stats.longestAnywhere} bytes</td><td>(anywhere in either binary)</td></tr>
        </table>
      </div>
      <div class="diff-stat-block">
        <div class="diff-stat-label">Shared N-gram Signatures</div>
        <table class="diff-ngram-table">
          <thead><tr><th>Size</th><th>Shared</th><th>Unique</th><th>Overlap</th></tr></thead>
          <tbody>
            ${ngramRow(4, stats.ngram4)}
            ${ngramRow(8, stats.ngram8)}
            ${ngramRow(16, stats.ngram16)}
            ${ngramRow(32, stats.ngram32)}
          </tbody>
        </table>
      </div>
      <div class="diff-verdict ${stats.ngram16.shared === 0 ? 'verdict-red' : 'verdict-yellow'}">
        ${stats.ngram16.shared === 0
          ? 'No viable 16+ byte signature exists between these variants.'
          : `${stats.ngram16.shared} shared 16-byte patterns — limited signature potential.`}
      </div>
    </div>
  `;
  panel.appendChild(section1);

  const section2 = document.createElement('div');
  section2.className = 'diff-section';
  section2.innerHTML = `
    <div class="diff-section-title">Byte Heatmap
      <span class="diff-heatmap-legend">
        <span class="swatch" style="background:#1a5a3a"></span>identical
        <span class="swatch" style="background:#cc3344"></span>different
      </span>
    </div>
    <div class="diff-heatmap-labels">
      <span>${labelA}</span>
      <span>${labelB}</span>
    </div>
  `;
  const canvas = document.createElement('canvas');
  canvas.className = 'diff-heatmap-canvas';
  renderByteHeatmap(canvas, stats.bytesA, stats.bytesB, stats.diffMap);
  section2.appendChild(canvas);
  panel.appendChild(section2);
}

function renderBytesTab(panel, vA, vB, labelA, labelB) {
  renderByteStatsBlock(panel, vA.bin_hex, vB.bin_hex, labelA, labelB,
    'x86 Binary');

  const mcbA = vA.mcb_hex;
  const mcbB = vB.mcb_hex;
  if (mcbA && mcbB) {
    renderByteStatsBlock(panel, mcbA, mcbB, labelA, labelB,
      'IR Bytecode (.mcb)');
  }
}

// ---------------------------------------------------------------------------
// Floating-tooltip handler for .tip[data-tip] icons.  We use a single
// floating <div> in <body> instead of a CSS ::after pseudo because the
// sidebar's overflow:hidden was clipping CSS-anchored tooltips, and
// Chromium's native title= tooltips were getting suppressed too.
// ---------------------------------------------------------------------------
(function setupFloatingTip() {
  const tipEl = document.getElementById('floating-tip');
  if (!tipEl) return;
  let currentTarget = null;

  function show(target) {
    const text = target.getAttribute('data-tip');
    if (!text) return;
    currentTarget = target;
    tipEl.textContent = text;
    const rect = target.getBoundingClientRect();
    // Render to the right of the icon, vertically aligned with its center.
    let left = rect.right + 8;
    // After we know the tooltip's rendered size, nudge left if it would
    // overflow the viewport.
    tipEl.classList.add('visible');
    tipEl.style.left = left + 'px';
    tipEl.style.top  = (rect.top - 4) + 'px';
    requestAnimationFrame(() => {
      const tipRect = tipEl.getBoundingClientRect();
      if (tipRect.right > window.innerWidth - 8) {
        left = Math.max(8, window.innerWidth - tipRect.width - 8);
        tipEl.style.left = left + 'px';
      }
    });
  }

  function hide() {
    currentTarget = null;
    tipEl.classList.remove('visible');
  }

  document.addEventListener('mouseover', (e) => {
    const t = e.target.closest('.tip[data-tip]');
    if (t && t !== currentTarget) show(t);
  });
  document.addEventListener('mouseout', (e) => {
    if (!currentTarget) return;
    // mouseout fires when moving onto a child too — only hide when leaving
    // the tip element itself.
    const to = e.relatedTarget;
    if (!to || !currentTarget.contains(to)) hide();
  });
  // Hide on scroll inside the sidebar (positions go stale).
  document.querySelectorAll('#sidebar-scroll').forEach(el =>
    el.addEventListener('scroll', hide, { passive: true })
  );
})();

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

initConsoleTabs();
