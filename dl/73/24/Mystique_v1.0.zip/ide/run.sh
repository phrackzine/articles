#!/bin/bash
PORT=${PORT:-5000}
(sleep 1 && xdg-open "http://localhost:$PORT" >/dev/null 2>&1) &
python3 server.py
