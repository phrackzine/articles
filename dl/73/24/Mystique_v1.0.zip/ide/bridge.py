"""
bridge.py — Compiler bridge for the Mystique visualizer.

Provides CompilerBridge, which talks to:
  - The Python front-end (compiler/frontend/mystcc.py) to compile MystC → IR
  - backend_mystc.exe to compile IR → polymorphic x86 shellcode
  - disasm.py to disassemble .bin files to JSON
"""

import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time as _time
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    e = 0.0
    for c in counts:
        if c:
            p = c / n
            e -= p * math.log2(p)
    return round(e, 4)


def _byte_diff_pct(a: bytes, b: bytes) -> float:
    """Percentage of bytes that differ (aligned comparison)."""
    length = min(len(a), len(b))
    if length == 0:
        return 100.0
    diffs = sum(1 for x, y in zip(a, b) if x != y)
    return round(100.0 * diffs / length, 2)


# ---------------------------------------------------------------------------
# Genome mutation (mirrors recompiler mutation logic)
# ---------------------------------------------------------------------------

import random as _random

# Gene metadata: (key, min, max) for scalar genes
_SCALAR_GENES = [
    ('unfold_chance', 0, 100), ('substitute_chance', 0, 100),
    ('dead_code_chance', 0, 100), ('nop_chance', 0, 100),
    ('nop_max_count', 1, 10), ('dead_prologue_pct', 0, 100),
    ('dead_block_pct', 0, 100), ('dead_instr_pct', 0, 100),
    ('opaque_pct', 0, 100), ('junk_call_block_pct', 0, 100),
    ('junk_call_instr_pct', 0, 100), ('harmless_block_pct', 0, 100),
    ('harmless_instr_pct', 0, 100),
    ('junk_func_pct', 0, 200),
    ('expression_flags', 0, 32767), ('expression_rate', 0, 100),
    ('reorder_instrs_intensity', 1, 10), ('reorder_locals_chance', 0, 100),
    ('reorder_blocks_chance', 0, 100), ('reorder_funcs_chance', 0, 100),
]

_VECTOR_GENES = [
    'unfold_weights', 'dead_code_weights',
    'add_weights', 'sub_weights',
    'movi_weights', 'movi_zero_weights', 'movi_neg1_weights',
    'xor_weights', 'cmp_weights',
    'junk_seq_weights', 'opaque_weights',
]


def _mutate_genome(genome: dict, rng: _random.Random = None) -> dict:
    """
    Produce a slightly mutated copy of a genome dict.
    Scalars: ±5 (clamped).  Vectors: each weight ±50 (clamped ≥1).
    """
    if rng is None:
        rng = _random.Random()
    g = dict(genome)
    for key, lo, hi in _SCALAR_GENES:
        if key in g:
            delta = rng.randint(-5, 5)
            g[key] = max(lo, min(hi, g[key] + delta))
    for key in _VECTOR_GENES:
        if key in g and isinstance(g[key], list):
            g[key] = [max(1, w + rng.randint(-50, 50)) for w in g[key]]
    # Gene expression: flip random transform bits based on expression_rate
    expr_rate = g.get('expression_rate', 5)
    expr_flags = g.get('expression_flags', 0x7FFF)
    for bit in range(15):
        if rng.randint(0, 99) < expr_rate:
            expr_flags ^= (1 << bit)
    g['expression_flags'] = expr_flags & 0x7FFF
    # Self-adaptive: mutate temperature
    temp = g.get('genome_temperature', 50)
    t_step = 1 + temp // 20
    t_delta = rng.randint(-t_step, t_step)
    g['genome_temperature'] = max(0, min(100, temp + t_delta))
    return g


def _default_genome() -> dict:
    """Return a genome dict with all default values (matches GENOME_DEFAULTS in app.js)."""
    return {
        'unfold_chance': 35, 'substitute_chance': 40, 'dead_code_chance': 25,
        'nop_chance': 20, 'nop_max_count': 3,
        'dead_prologue_pct': 30, 'dead_block_pct': 20, 'dead_instr_pct': 10,
        'opaque_pct': 5, 'junk_call_block_pct': 8, 'junk_call_instr_pct': 3,
        'harmless_block_pct': 3, 'harmless_instr_pct': 1,
        'junk_func_pct': 50,
        'expression_flags': 0x7FFF, 'expression_rate': 5,
        'reorder_instrs_intensity': 2, 'reorder_locals_chance': 100,
        'reorder_blocks_chance': 100, 'reorder_funcs_chance': 100,
        'genome_temperature': 50,
        'unfold_weights': [250, 250, 250, 250],
        'dead_code_weights': [250, 250, 250, 250],
        'add_weights': [200, 200, 200, 200, 200],
        'sub_weights': [250, 250, 250, 250],
        'movi_weights': [166, 167, 167, 167, 167, 166],
        'movi_zero_weights': [333, 333, 334],
        'movi_neg1_weights': [333, 333, 334],
        'xor_weights': [333, 333, 334],
        'cmp_weights': [500, 500],
        'junk_seq_weights': [125, 125, 125, 125, 125, 125, 125, 125],
        'opaque_weights': [333, 333, 334],
    }


# ---------------------------------------------------------------------------
# .mcb → IR text helper (used for both base IR and per-variant IR)
# ---------------------------------------------------------------------------

def _mcb_to_ir_text(mcb_path: str, ir_format: str = 'mce') -> str:
    """Read a .mcb file and return its IR as mce or mct text."""
    try:
        from compiler.frontend.bytecode import read_bytecode, expr_ir_text, text_ir_text
        program = read_bytecode(mcb_path)
        if ir_format == 'mce':
            return expr_ir_text(program)
        else:
            return text_ir_text(program)
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# .mct text-IR parser
# ---------------------------------------------------------------------------

def parse_mct(text: str) -> dict:
    """
    Parse the text IR (.mct) output of the frontend into a structured dict.

    Returns:
    {
      "version": 1,
      "target": "x86-32",
      "strings": ["..."],
      "structs": [...],
      "globals": [...],
      "functions": [
        {
          "name": "foo",
          "params": ["i32", "ptr"],
          "return_type": "i32",
          "locals": [{"type": "i32", "index": 0}],
          "blocks": [
            {
              "label": "entry",
              "instructions": ["add $0 $1 i32", "ret %0"]
            }
          ]
        }
      ]
    }
    """
    result = {
        "version": 1,
        "target": "x86-32",
        "strings": [],
        "structs": [],
        "globals": [],
        "functions": [],
    }

    current_func = None
    current_block = None
    in_struct = False

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        # Directives
        if line.startswith('.version'):
            result["version"] = int(line.split()[1])
        elif line.startswith('.target'):
            result["target"] = line.split()[1]
        elif line.startswith('.string '):
            # .string N "content"
            m = re.match(r'\.string\s+(\d+)\s+"(.*)"', line)
            if m:
                result["strings"].append(m.group(2))
        elif line.startswith('.struct '):
            parts = line.split()
            in_struct = True
            result["structs"].append({"name": parts[1], "size": int(parts[2]), "fields": []})
        elif line.startswith('.field ') and in_struct:
            parts = line.split()
            result["structs"][-1]["fields"].append(
                {"name": parts[1], "type": parts[2], "offset": int(parts[3])}
            )
        elif line == '.end' and in_struct:
            in_struct = False
        elif line.startswith('.global '):
            parts = line.split()
            result["globals"].append({"name": parts[1], "type": parts[2],
                                       "init": parts[3] if len(parts) > 3 else "0"})
        elif line.startswith('.func '):
            # .func @name $0:i32 $1:ptr -> i32
            current_block = None
            m = re.match(r'\.func\s+(\S+)(.*?)(?:\s+->\s+(\S+))?$', line)
            name = m.group(1) if m else line.split()[1]
            rest = m.group(2) if m else ""
            ret_type = m.group(3) if m and m.group(3) else "void"
            params = re.findall(r'\$\d+:(\S+)', rest)
            current_func = {
                "name": name,
                "params": params,
                "return_type": ret_type,
                "locals": [],
                "blocks": [],
            }
            result["functions"].append(current_func)
        elif line.startswith('.local ') and current_func is not None:
            parts = line.split()
            current_func["locals"].append({"index": int(parts[1][1:]), "type": parts[2]})
        elif line == '.end' and current_func is not None:
            current_func = None
            current_block = None
        elif line.endswith(':') and current_func is not None:
            # Block labels may be dot-prefixed (.entry:) or plain (entry:)
            label = line[:-1].lstrip('.')
            current_block = {"label": label, "instructions": []}
            current_func["blocks"].append(current_block)
        elif current_block is not None and not line.startswith('.'):
            current_block["instructions"].append(line)

    return result


def mc_disasm(data: bytes) -> str:
    """
    Disassemble binary .mcb bytecode into human-readable .mct-style text.
    Used by the evolution view to show IR changes across generations.
    Returns a best-effort text even if parsing fails mid-way.
    """
    try:
        return _mc_disasm_inner(data)
    except Exception as e:
        return f'; [mc_disasm error: {type(e).__name__}: {e}]'


def _mc_disasm_inner(data: bytes) -> str:
    import struct as _s

    _TYPES   = {0: 'void', 1: 'i8', 2: 'i32', 3: 'ptr'}
    _TARGETS = {1: 'x86-32', 2: 'x86-64'}
    _BINARY_OPS = {
        0x10:'add', 0x11:'sub', 0x12:'mul', 0x13:'div', 0x14:'mod',
        0x20:'and', 0x21:'or',  0x22:'xor', 0x24:'shl', 0x25:'shr',
        0x30:'eq',  0x31:'ne',  0x32:'lt',  0x33:'le',  0x34:'gt',  0x35:'ge',
    }

    if len(data) < 16 or data[:4] != b'MCBN':
        return '; [not a valid .mcb file]'

    # ---- sequential reader ------------------------------------------------
    pos = [4]   # mutable int via list so nested funcs can advance it
    n   = len(data)

    def ru8():
        if pos[0] >= n: raise EOFError(f'ru8 at {pos[0]}, size={n}')
        v = data[pos[0]]; pos[0] += 1; return v

    def ru16():
        if pos[0] + 2 > n: raise EOFError(f'ru16 at {pos[0]}, size={n}')
        v = _s.unpack_from('<H', data, pos[0])[0]; pos[0] += 2; return v

    def ri32():
        if pos[0] + 4 > n: raise EOFError(f'ri32 at {pos[0]}, size={n}')
        v = _s.unpack_from('<i', data, pos[0])[0]; pos[0] += 4; return v

    def ru32():
        if pos[0] + 4 > n: raise EOFError(f'ru32 at {pos[0]}, size={n}')
        v = _s.unpack_from('<I', data, pos[0])[0]; pos[0] += 4; return v

    def rval():
        k = ru8()
        if k == 0x00: return ('t', ru8())    # VK_TEMP
        if k == 0x80: return ('t', ru16())   # VK_TEMP_EXT
        if k == 0x01: return ('p', ru8())    # VK_PARAM
        if k == 0x02: return ('l', ru8())    # VK_LOCAL
        if k == 0x03: return ('g', ru16())   # VK_GLOBAL
        if k == 0x04: return ('c', ri32())   # VK_CONST
        if k == 0x05: return ('s', ru16())   # VK_STRING
        return ('?', k)

    def rloc():
        k = ru8()
        if k == 0x00: return ('l', ru8())    # local
        if k == 0x01: return ('g', ru16())   # global
        return ('?', k)

    # ---- header -----------------------------------------------------------
    version     = ru16(); target = ru8(); ru8()   # flags
    num_strings = ru16(); num_structs = ru16()
    num_globals = ru16(); num_fns     = ru16()

    # ---- string table -----------------------------------------------------
    total_sz   = ru32()
    str_offs   = [ru32() for _ in range(num_strings)]
    str_data   = data[pos[0]:pos[0] + total_sz]; pos[0] += total_sz

    def gs(i):
        if i >= num_strings: return f'str{i}'
        o = str_offs[i]
        e = str_data.index(b'\x00', o)
        return str_data[o:e].decode('utf-8', errors='replace')

    # ---- structs (skip) ---------------------------------------------------
    for _ in range(num_structs):
        ru16(); ru16(); ru8(); nf = ru8()
        for _ in range(nf): ru16(); ru8(); ru16()

    # ---- globals ----------------------------------------------------------
    global_names = []
    for _ in range(num_globals):
        ni = ru16(); ru8(); ru8(); ri32()
        global_names.append(gs(ni))

    def vfmt(v):
        k, x = v
        if k == 't': return f'%{x}'
        if k == 'p': return f'${x}'
        if k == 'l': return f'local_{x}'
        if k == 'g': return f'@{global_names[x]}' if x < len(global_names) else f'@g{x}'
        if k == 'c': return str(x)
        if k == 's': return f'"{gs(x)}"'
        return f'?v{k}'

    def lfmt(v):
        k, x = v
        if k == 'l': return f'local_{x}'
        if k == 'g': return f'@{global_names[x]}' if x < len(global_names) else f'@g{x}'
        return f'?l{k}'

    tf = lambda t: _TYPES.get(t, f'type{t:02x}')

    # ---- parse all functions (two-step: build AST, then render) -----------
    fn_names = []
    parsed   = []

    for _ in range(num_fns):
        fname = gs(ru16()); fn_names.append(fname)
        ret = ru8(); np = ru8(); nl = ru8(); nb = ru16(); ru16(); ru16()  # num_temps, dll_idx
        params  = [ru8() for _ in range(np)]
        locals_ = [(ru8(), ru16()) for _ in range(nl)]   # (type, size)

        blocks = []
        for _ in range(nb):
            lbl = gs(ru16()); ni = ru16()
            instrs = []
            for _ in range(ni):
                op = ru8()
                try:
                    if   op == 0x00: instrs.append(('nop',))
                    elif op == 0x01: d=rval();m=ri32();t=ru8(); instrs.append(('const',d,m,t))
                    elif op == 0x02: d=rval();s=rval();t=ru8(); instrs.append(('copy',d,s,t))
                    elif op in _BINARY_OPS:
                        d=rval();a=rval();b=rval();t=ru8()
                        instrs.append((_BINARY_OPS[op],d,a,b,t))
                    elif op in (0x15,0x23):
                        nm='neg' if op==0x15 else 'not'
                        d=rval();s=rval();t=ru8(); instrs.append((nm,d,s,t))
                    elif op == 0x40: d=rval();a=rval();t=ru8(); instrs.append(('load',d,a,t))
                    elif op == 0x41: a=rval();v=rval();t=ru8(); instrs.append(('store',a,v,t))
                    elif op == 0x42: d=rval();lo=rloc();        instrs.append(('addr',d,lo))
                    elif op == 0x43: d=rval();b=rval();o=rval();es=ru16(); instrs.append(('ptradd',d,b,o,es))
                    elif op == 0x44: d=rval();b=rval();fo=ru16(); instrs.append(('fieldptr',d,b,fo))
                    elif op == 0x45: d=rval();sz=ru16();al=ru8(); instrs.append(('alloca',d,sz,al))
                    elif op == 0x50: instrs.append(('jmp',ru16()))
                    elif op == 0x51: c=rval(); instrs.append(('jz',c,ru16()))
                    elif op == 0x52: c=rval(); instrs.append(('jnz',c,ru16()))
                    elif op == 0x60:
                        d=rval();fi=ru16();na=ru8();args=[rval() for _ in range(na)]
                        instrs.append(('call',d,fi,args))
                    elif op == 0x61:
                        fi=ru16();na=ru8();args=[rval() for _ in range(na)]
                        instrs.append(('callv',fi,args))
                    elif op == 0x62: instrs.append(('ret',rval()))
                    elif op == 0x63: instrs.append(('retv',))
                    else:
                        instrs.append((f'op{op:02x}',)); break
                except Exception:
                    instrs.append(('???',)); break
            blocks.append({'label': lbl, 'instrs': instrs})
        parsed.append({'name':fname,'ret':ret,'params':params,'locals':locals_,'blocks':blocks})

    # ---- render -----------------------------------------------------------
    out = [f'.version {version}', f'.target {_TARGETS.get(target, str(target))}', '']

    for fn in parsed:
        ps = ' '.join(f'${i}:{tf(t)}' for i,t in enumerate(fn['params']))
        hdr = f'.func @{fn["name"]}'
        if ps: hdr += ' ' + ps
        hdr += f' -> {tf(fn["ret"])}'
        out.append(hdr)

        blbls = [b['label'] for b in fn['blocks']]
        def br(i, _bb=blbls): return f'.{_bb[i]}' if i < len(_bb) else f'.blk{i}'

        def ri(ins, _br=br):
            op = ins[0]
            if op == 'nop':    return 'nop'
            if op == 'const':  _, d,m,t = ins; return f'{vfmt(d)} = const {m} {tf(t)}'
            if op == 'copy':   _, d,s,t = ins; return f'{vfmt(d)} = copy {vfmt(s)} {tf(t)}'
            if op in _BINARY_OPS.values():
                _, d,a,b,t = ins; return f'{vfmt(d)} = {op} {vfmt(a)} {vfmt(b)} {tf(t)}'
            if op in ('neg','not'): _, d,s,t = ins; return f'{vfmt(d)} = {op} {vfmt(s)} {tf(t)}'
            if op == 'load':   _, d,a,t = ins; return f'{vfmt(d)} = load {vfmt(a)} {tf(t)}'
            if op == 'store':  _, a,v,t = ins; return f'store {vfmt(a)} {vfmt(v)} {tf(t)}'
            if op == 'addr':   _, d,lo = ins;  return f'{vfmt(d)} = addr {lfmt(lo)}'
            if op == 'ptradd': _, d,b,o,es=ins; return f'{vfmt(d)} = ptradd {vfmt(b)} {vfmt(o)} {es}'
            if op == 'fieldptr': _, d,b,fo=ins; return f'{vfmt(d)} = fieldptr {vfmt(b)} {fo}'
            if op == 'alloca': _, d,sz,al=ins;  return f'{vfmt(d)} = alloca {sz} {al}'
            if op == 'jmp':    return f'jmp {_br(ins[1])}'
            if op == 'jz':     _, c,tgt=ins; return f'jz {vfmt(c)} {_br(tgt)}'
            if op == 'jnz':    _, c,tgt=ins; return f'jnz {vfmt(c)} {_br(tgt)}'
            if op == 'call':
                _, d,fi,args=ins
                fn_n = fn_names[fi] if fi < len(fn_names) else f'fn{fi}'
                return f'{vfmt(d)} = call @{fn_n} {" ".join(vfmt(a) for a in args)}'
            if op == 'callv':
                _, fi,args=ins
                fn_n = fn_names[fi] if fi < len(fn_names) else f'fn{fi}'
                return f'callv @{fn_n} {" ".join(vfmt(a) for a in args)}'
            if op == 'ret':  return f'ret {vfmt(ins[1])}'
            if op == 'retv': return 'retv'
            return f'; {ins[0]}'

        for blk in fn['blocks']:
            out.append(f'.{blk["label"]}:')
            for ins in blk['instrs']:
                out.append('    ' + ri(ins))
        out.append('.end')
        out.append('')

    return '\n'.join(out)


def mc_segment(data: bytes) -> list:
    """
    Parse binary .mcb bytecode into a list of segment dicts:
    [{"o": offset, "s": size, "k": kind, "t": text}]

    One entry per meaningful unit: header, string table, globals,
    function headers, block headers, individual instructions.
    Used by the evolution view to display bytes + IR text side by side.
    """
    try:
        return _mc_segment_inner(data)
    except Exception as e:
        return [{"o": 0, "s": len(data), "k": "error",
                 "t": f"[mc_segment error: {type(e).__name__}: {e}]"}]


def _mc_segment_inner(data: bytes) -> list:
    import struct as _s

    _TYPES   = {0: 'void', 1: 'i8', 2: 'i32', 3: 'ptr'}
    _TARGETS = {1: 'x86-32', 2: 'x86-64'}
    _BINARY_OPS = {
        0x10:'add', 0x11:'sub', 0x12:'mul', 0x13:'div', 0x14:'mod',
        0x20:'and', 0x21:'or',  0x22:'xor', 0x24:'shl', 0x25:'shr',
        0x30:'eq',  0x31:'ne',  0x32:'lt',  0x33:'le',  0x34:'gt',  0x35:'ge',
    }

    if len(data) < 16 or data[:4] != b'MCBN':
        return [{"o": 0, "s": len(data), "k": "error", "t": "[not a valid .mcb file]"}]

    pos = [0]
    n   = len(data)

    def ru8():
        if pos[0] >= n: raise EOFError(f'ru8 at {pos[0]}, size={n}')
        v = data[pos[0]]; pos[0] += 1; return v
    def ru16():
        if pos[0]+2 > n: raise EOFError(f'ru16 at {pos[0]}, size={n}')
        v = _s.unpack_from('<H', data, pos[0])[0]; pos[0] += 2; return v
    def ri32():
        if pos[0]+4 > n: raise EOFError(f'ri32 at {pos[0]}, size={n}')
        v = _s.unpack_from('<i', data, pos[0])[0]; pos[0] += 4; return v
    def ru32():
        if pos[0]+4 > n: raise EOFError(f'ru32 at {pos[0]}, size={n}')
        v = _s.unpack_from('<I', data, pos[0])[0]; pos[0] += 4; return v
    def rval():
        k = ru8()
        if k == 0x00: return ('t', ru8())
        if k == 0x80: return ('t', ru16())
        if k == 0x01: return ('p', ru8())
        if k == 0x02: return ('l', ru8())
        if k == 0x03: return ('g', ru16())
        if k == 0x04: return ('c', ri32())
        if k == 0x05: return ('s', ru16())
        return ('?', k)
    def rloc():
        k = ru8()
        if k == 0x00: return ('l', ru8())
        if k == 0x01: return ('g', ru16())
        return ('?', k)

    tf = lambda t: _TYPES.get(t, f'type{t:02x}')

    # header (magic + version + target + flags + counts = 16 bytes)
    s0 = pos[0]
    ru32()  # MCBN magic
    version     = ru16(); target = ru8(); ru8()
    num_strings = ru16(); num_structs = ru16()
    num_globals = ru16(); num_fns     = ru16()
    hdr_seg = {"o": s0, "s": pos[0]-s0, "k": "header",
               "t": (f'.version {version}  .target {_TARGETS.get(target, str(target))}'
                     f'  strings={num_strings}  structs={num_structs}'
                     f'  globals={num_globals}  fns={num_fns}')}

    # string table
    s0 = pos[0]
    total_sz = ru32()
    str_offs = [ru32() for _ in range(num_strings)]
    str_data = data[pos[0]:pos[0]+total_sz]; pos[0] += total_sz
    strtab_seg = {"o": s0, "s": pos[0]-s0, "k": "strtab",
                  "t": f'[string table: {num_strings} strings, {total_sz} data bytes]'}

    def gs(i):
        if i >= num_strings: return f'str{i}'
        o = str_offs[i]
        try: e = str_data.index(b'\x00', o)
        except ValueError: e = len(str_data)
        return str_data[o:e].decode('utf-8', errors='replace')

    # structs
    struct_segs = []
    for _ in range(num_structs):
        s0 = pos[0]
        si = ru16(); sz = ru16(); ru8(); nf = ru8()
        for _ in range(nf): ru16(); ru8(); ru16()
        struct_segs.append({"o": s0, "s": pos[0]-s0, "k": "struct",
                             "t": f'.struct {gs(si)}  size={sz}  fields={nf}'})

    # globals
    global_names = []
    global_segs  = []
    for _ in range(num_globals):
        s0 = pos[0]
        ni = ru16(); gt = ru8(); ru8(); gv = ri32()
        gname = gs(ni); global_names.append(gname)
        global_segs.append({"o": s0, "s": pos[0]-s0, "k": "global",
                             "t": f'.global @{gname}  {tf(gt)}  = {gv}'})

    def vfmt(v):
        k, x = v
        if k == 't': return f'%{x}'
        if k == 'p': return f'${x}'
        if k == 'l': return f'local_{x}'
        if k == 'g': return f'@{global_names[x]}' if x < len(global_names) else f'@g{x}'
        if k == 'c': return str(x)
        if k == 's': return f'"{gs(x)}"'
        return f'?v{k}'

    def lfmt(v):
        k, x = v
        if k == 'l': return f'local_{x}'
        if k == 'g': return f'@{global_names[x]}' if x < len(global_names) else f'@g{x}'
        return f'?l{k}'

    # functions — two-pass: parse AST with byte positions, then emit segments.
    # Wrapped in try/except so a position-corrupting break (unknown opcode or
    # partial parse) that then causes the *next* block-header read to hit EOF
    # just stops parsing — we render whatever ended up in `parsed`.
    fn_names = []
    parsed   = []

    try:
        for _ in range(num_fns):
            fn_hdr_s = pos[0]
            fname = gs(ru16()); fn_names.append(fname)
            ret = ru8(); np = ru8(); nl = ru8(); nb = ru16(); ru16(); ru16()  # num_temps, dll_idx
            params  = [ru8() for _ in range(np)]
            locals_ = [(ru8(), ru16()) for _ in range(nl)]
            fn_hdr_e = pos[0]

            blocks = []
            for _ in range(nb):
                blk_hdr_s = pos[0]
                lbl = gs(ru16()); ni = ru16()
                blk_hdr_e = pos[0]
                instrs = []
                for _ in range(ni):
                    instr_s = pos[0]
                    op = ru8()
                    stop = False
                    try:
                        if   op == 0x00: ins = ('nop',)
                        elif op == 0x01: d=rval();m=ri32();t=ru8(); ins = ('const',d,m,t)
                        elif op == 0x02: d=rval();s=rval();t=ru8(); ins = ('copy',d,s,t)
                        elif op in _BINARY_OPS:
                            d=rval();a=rval();b=rval();t=ru8()
                            ins = (_BINARY_OPS[op],d,a,b,t)
                        elif op in (0x15,0x23):
                            nm='neg' if op==0x15 else 'not'
                            d=rval();s=rval();t=ru8(); ins = (nm,d,s,t)
                        elif op == 0x40: d=rval();a=rval();t=ru8(); ins = ('load',d,a,t)
                        elif op == 0x41: a=rval();v=rval();t=ru8(); ins = ('store',a,v,t)
                        elif op == 0x42: d=rval();lo=rloc();        ins = ('addr',d,lo)
                        elif op == 0x43: d=rval();b=rval();o=rval();es=ru16(); ins=('ptradd',d,b,o,es)
                        elif op == 0x44: d=rval();b=rval();fo=ru16(); ins = ('fieldptr',d,b,fo)
                        elif op == 0x45: d=rval();sz=ru16();al=ru8(); ins = ('alloca',d,sz,al)
                        elif op == 0x50: ins = ('jmp',ru16())
                        elif op == 0x51: c=rval(); ins = ('jz',c,ru16())
                        elif op == 0x52: c=rval(); ins = ('jnz',c,ru16())
                        elif op == 0x60:
                            d=rval();fi=ru16();na=ru8();args=[rval() for _ in range(na)]
                            ins = ('call',d,fi,args)
                        elif op == 0x61:
                            fi=ru16();na=ru8();args=[rval() for _ in range(na)]
                            ins = ('callv',fi,args)
                        elif op == 0x62: ins = ('ret',rval())
                        elif op == 0x63: ins = ('retv',)
                        else:
                            ins = (f'op{op:02x}',)
                            stop = True  # unknown opcode — operands unknown
                    except Exception:
                        ins = ('???',)
                        stop = True  # position unknown after partial parse
                    instr_e = pos[0]
                    instrs.append((instr_s, instr_e, ins))
                    if stop:
                        break
                blocks.append({'label': lbl, 'hdr_s': blk_hdr_s, 'hdr_e': blk_hdr_e, 'instrs': instrs})
            parsed.append({'name': fname, 'ret': ret, 'params': params, 'locals': locals_,
                           'blocks': blocks, 'hdr_s': fn_hdr_s, 'hdr_e': fn_hdr_e})
    except Exception:
        pass  # return whatever was successfully parsed so far

    # emit segments in file order
    segs = [hdr_seg, strtab_seg] + struct_segs + global_segs

    for fn in parsed:
        ps = ' '.join(f'${i}:{tf(t)}' for i, t in enumerate(fn['params']))
        hdr = f'.func @{fn["name"]}'
        if ps: hdr += ' ' + ps
        hdr += f' -> {tf(fn["ret"])}'
        segs.append({"o": fn['hdr_s'], "s": fn['hdr_e']-fn['hdr_s'], "k": "fnhdr", "t": hdr})

        blbls = [b['label'] for b in fn['blocks']]
        def br(i, _bb=blbls): return f'.{_bb[i]}' if i < len(_bb) else f'.blk{i}'

        def ri(ins, _br=br):
            op = ins[0]
            if op == 'nop':    return 'nop'
            if op == 'const':  _, d,m,t = ins; return f'{vfmt(d)} = const {m} {tf(t)}'
            if op == 'copy':   _, d,s,t = ins; return f'{vfmt(d)} = copy {vfmt(s)} {tf(t)}'
            if op in _BINARY_OPS.values():
                _, d,a,b,t = ins; return f'{vfmt(d)} = {op} {vfmt(a)} {vfmt(b)} {tf(t)}'
            if op in ('neg','not'): _, d,s,t = ins; return f'{vfmt(d)} = {op} {vfmt(s)} {tf(t)}'
            if op == 'load':   _, d,a,t = ins; return f'{vfmt(d)} = load {vfmt(a)} {tf(t)}'
            if op == 'store':  _, a,v,t = ins; return f'store {vfmt(a)} {vfmt(v)} {tf(t)}'
            if op == 'addr':   _, d,lo = ins;  return f'{vfmt(d)} = addr {lfmt(lo)}'
            if op == 'ptradd': _, d,b,o,es=ins; return f'{vfmt(d)} = ptradd {vfmt(b)} {vfmt(o)} {es}'
            if op == 'fieldptr': _, d,b,fo=ins; return f'{vfmt(d)} = fieldptr {vfmt(b)} {fo}'
            if op == 'alloca': _, d,sz,al=ins;  return f'{vfmt(d)} = alloca {sz} {al}'
            if op == 'jmp':    return f'jmp {_br(ins[1])}'
            if op == 'jz':     _, c,tgt=ins; return f'jz {vfmt(c)} {_br(tgt)}'
            if op == 'jnz':    _, c,tgt=ins; return f'jnz {vfmt(c)} {_br(tgt)}'
            if op == 'call':
                _, d,fi,args=ins
                fn_n = fn_names[fi] if fi < len(fn_names) else f'fn{fi}'
                return f'{vfmt(d)} = call @{fn_n} {" ".join(vfmt(a) for a in args)}'
            if op == 'callv':
                _, fi,args=ins
                fn_n = fn_names[fi] if fi < len(fn_names) else f'fn{fi}'
                return f'callv @{fn_n} {" ".join(vfmt(a) for a in args)}'
            if op == 'ret':  return f'ret {vfmt(ins[1])}'
            if op == 'retv': return 'retv'
            return f'; {ins[0]}'

        for blk in fn['blocks']:
            segs.append({"o": blk['hdr_s'], "s": blk['hdr_e']-blk['hdr_s'],
                         "k": "blkhdr", "t": f'.{blk["label"]}:'})
            for (istart, iend, ins) in blk['instrs']:
                segs.append({"o": istart, "s": iend-istart, "k": "instr", "t": ri(ins)})

    segs.sort(key=lambda x: x['o'])
    return segs


def build_ir_cfg(ir: dict) -> dict:
    """
    Extract control-flow graph from parsed IR.

    Returns:
    {
      "functions": [
        {
          "name": "...",
          "nodes": [{"id": "fn:block", "label": "entry", "instructions": [...]}],
          "edges": [{"from": "fn:entry", "to": "fn:loop", "label": "always|jz|jnz"}]
        }
      ]
    }
    """
    functions = []
    for func in ir.get("functions", []):
        fname = func["name"]
        nodes = []
        edges = []
        block_ids = {}

        for i, blk in enumerate(func.get("blocks", [])):
            node_id = f"{fname}:{blk['label']}"
            block_ids[blk["label"]] = node_id
            nodes.append({
                "id": node_id,
                "label": blk["label"],
                "instructions": blk["instructions"],
            })

        for i, blk in enumerate(func.get("blocks", [])):
            src_id = f"{fname}:{blk['label']}"
            for instr in blk["instructions"]:
                tokens = instr.split()
                if not tokens:
                    continue
                op = tokens[0]
                if op == "jmp" and len(tokens) >= 2:
                    target = tokens[1].lstrip(".")
                    tgt_id = block_ids.get(target, target)
                    edges.append({"from": src_id, "to": tgt_id, "label": "always"})
                elif op == "jz" and len(tokens) >= 3:
                    target = tokens[2].lstrip(".")
                    tgt_id = block_ids.get(target, target)
                    edges.append({"from": src_id, "to": tgt_id, "label": "jz"})
                    # Implicit fall-through to next block
                    if i + 1 < len(func["blocks"]):
                        next_id = f"{fname}:{func['blocks'][i+1]['label']}"
                        edges.append({"from": src_id, "to": next_id, "label": "fallthrough"})
                elif op == "jnz" and len(tokens) >= 3:
                    target = tokens[2].lstrip(".")
                    tgt_id = block_ids.get(target, target)
                    edges.append({"from": src_id, "to": tgt_id, "label": "jnz"})
                    if i + 1 < len(func["blocks"]):
                        next_id = f"{fname}:{func['blocks'][i+1]['label']}"
                        edges.append({"from": src_id, "to": next_id, "label": "fallthrough"})

        functions.append({"name": fname, "nodes": nodes, "edges": edges})

    return {"functions": functions}


def build_x86_cfg(instructions: list) -> dict:
    """
    Build a CFG from a list of disasm instruction dicts.

    Returns:
    {
      "nodes": [{"id": N, "offset": N, "instructions": [...]}],
      "edges": [{"from": N, "to": N, "label": "always|jcc|fallthrough"}]
    }
    """
    if not instructions:
        return {"nodes": [], "edges": []}

    # Find all block leaders
    leaders = {instructions[0]["offset"]}
    for ins in instructions:
        if ins.get("is_jump") and ins.get("jump_target") is not None:
            leaders.add(ins["jump_target"])
            # instruction after a jump is also a leader
            next_off = ins["offset"] + ins["size"]
            leaders.add(next_off)
        if ins.get("is_ret"):
            next_off = ins["offset"] + ins["size"]
            leaders.add(next_off)

    leaders = sorted(leaders)
    leader_to_id = {off: i for i, off in enumerate(leaders)}

    # Build blocks
    blocks = {i: {"id": i, "offset": off, "instructions": []} for i, off in enumerate(leaders)}
    current_block_id = None
    for ins in instructions:
        if ins["offset"] in leader_to_id:
            current_block_id = leader_to_id[ins["offset"]]
        if current_block_id is not None and current_block_id in blocks:
            blocks[current_block_id]["instructions"].append(ins)

    # Build edges
    edges = []
    for bid, blk in sorted(blocks.items()):
        if not blk["instructions"]:
            continue
        last = blk["instructions"][-1]
        if last.get("is_jump") and last.get("jump_target") is not None:
            tgt = last["jump_target"]
            if tgt in leader_to_id:
                lbl = "always" if "JMP" in last["text"] else "jcc"
                edges.append({"from": bid, "to": leader_to_id[tgt], "label": lbl})
            # Fall-through for conditional jumps
            if "JMP" not in last["text"]:
                next_off = last["offset"] + last["size"]
                if next_off in leader_to_id:
                    edges.append({"from": bid, "to": leader_to_id[next_off], "label": "fallthrough"})
        elif not last.get("is_ret"):
            # Implicit fall-through
            next_off = last["offset"] + last["size"]
            if next_off in leader_to_id:
                edges.append({"from": bid, "to": leader_to_id[next_off], "label": "fallthrough"})

    nodes = [v for v in sorted(blocks.values(), key=lambda b: b["id"]) if v["instructions"]]
    return {"nodes": nodes, "edges": edges}


# ---------------------------------------------------------------------------
# CompilerBridge
# ---------------------------------------------------------------------------

class CompilerBridge:
    def __init__(self, project_root: Path):
        self.root = Path(project_root)
        exe_name = "backend_mystc.exe" if sys.platform == "win32" else "backend_mystc"
        self.backend_mystc = self.root / "compiler" / "backend" / exe_name
        self.disasm_py = self.root / "utils" / "disasm.py"
        self.python = sys.executable

        # Gen0 source bundles (built by build.py).  integrator_entry.mc is the
        # unified integrator entry point — compiled fresh per platform
        # via compile_entry_mcb() rather than read from a precompiled .mcb.
        self.bundles_dir    = self.root / "bundles"
        b = self.bundles_dir
        self.entry_mc       = b / "integrators" / "integrator_entry.mc"
        self.mfall_mcb      = b / "integrators" / "mystiqueFall"  / "mystiquefall.mcb"
        self.lacri_mcb      = b / "integrators" / "lacriMystique" / "lacrimystique.mcb"
        self.recomp_pe_mcb  = b / "recompilers" / "recomp_pe.mcb"
        self.recomp_elf_mcb = b / "recompilers" / "recomp_elf.mcb"
        self.inf_pe_mcb     = b / "infectors" / "infector_pe.mcb"
        self.inf_elf_mcb    = b / "infectors" / "infector_elf.mcb"

        # Add frontend to path so we can import it
        sys.path.insert(0, str(self.root))

    def compile_entry_mcb(self, platform: str, strip_debug: bool = False,
                          scramble_globals: bool = False) -> str:
        """Compile bundles/integrators/integrator_entry.mc fresh with the
        right platform define.  Returns a path to a freshly-written .mcb in
        tempdir; caller is responsible for cleanup."""
        import uuid
        out = Path(tempfile.gettempdir()) / f"integrator_entry_{platform}_{uuid.uuid4().hex}.mcb"
        define = "WIN32" if platform != "linux" else "LINUX"
        cmd = [self.python, "-m", "compiler.frontend.mystcc",
               str(self.entry_mc), "-o", str(out), f"-D{define}"]
        if strip_debug:
            cmd.append("--strip-debug")
        if scramble_globals:
            cmd.append("--scramble-globals")
        self._run(cmd)
        return str(out)

    def _run(self, cmd, cwd=None, check=True):
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            cwd=cwd or self.root
        )
        if check and result.returncode != 0:
            raise RuntimeError(
                f"Command failed: {' '.join(str(c) for c in cmd)}\n"
                f"stdout: {result.stdout}\nstderr: {result.stderr}"
            )
        return result

    # ------------------------------------------------------------------
    # Front-end: MystC source → IR + text IR
    # ------------------------------------------------------------------

    def compile_to_ir(self, source: str, platform: str = "win32",
                      strip_debug: bool = False,
                      scramble_globals: bool = False) -> dict:
        """
        Compile MystC source to IR. Returns:
        { "mct": str, "mce": str, "ir": dict, "cfg": dict, "mc_path": str }

        mce is generated in-process via BytecodeReader + ExprWriter so it
        is always available even if the subprocess path has issues.
        """
        with tempfile.TemporaryDirectory() as tmp:
            src_path = Path(tmp) / "prog.c"
            mc_path  = Path(tmp) / "prog.mcb"
            mct_path = Path(tmp) / "prog.mct"

            src_path.write_text(source, encoding='utf-8')

            platform_def = "WIN32" if platform != "linux" else "LINUX"
            cmd = [
                self.python, "-m", "compiler.frontend.mystcc",
                str(src_path),
                "-o", str(mc_path),
                "--text", str(mct_path),
                f"-D{platform_def}",
            ]
            if strip_debug:
                cmd.append("--strip-debug")
            if scramble_globals:
                cmd.append("--scramble-globals")
            self._run(cmd)

            mct_text = mct_path.read_text(encoding='utf-8')

            # Generate mce in-process: read .mcb → MCProgram → ExprWriter
            mce_text = _mcb_to_ir_text(str(mc_path), 'mce')

            # Persist mc file so backend can read it
            import shutil, uuid
            perm_mc = Path(tempfile.gettempdir()) / f"mystique_{uuid.uuid4().hex}.mcb"
            shutil.copy(mc_path, perm_mc)

            ir = parse_mct(mct_text)
            cfg = build_ir_cfg(ir)

            return {
                "mct": mct_text,
                "mce": mce_text,
                "ir": ir,
                "cfg": cfg,
                "mc_path": str(perm_mc),
            }

    # ------------------------------------------------------------------
    # Back-end: .mcb → polymorphic x86 .bin
    # ------------------------------------------------------------------

    def compile_to_x86(self, mc_path: str, annotate: bool = True,
                        seed: int = None, transform_flags: list = None,
                        emit_ir: bool = False, ir_format: str = 'mce',
                        out_mcb: str = None, genome: dict = None) -> dict:
        """
        Compile .mcb bytecode to PIC shellcode. Returns:
        { "bin_hex": str, "sha256": str, "entropy": float,
          "disasm": list, "annotations": dict|None, "x86_cfg": dict,
          "ir_text"?: str  (only when emit_ir=True) }

        When emit_ir=True, the backend also emits the post-transform .mcb via
        the -m flag, which is then read back and converted to IR text.
        """
        with tempfile.TemporaryDirectory() as tmp:
            bin_path = Path(tmp) / "out.bin"
            ann_path = Path(tmp) / "out_ann.json"
            var_mc   = Path(tmp) / "transformed.mcb"

            # Derive a unique seed from the current time at nanosecond
            # resolution so rapid back-to-back calls get distinct variants.
            if seed is None:
                seed = int(_time.time_ns() // 1_000_000) & 0x7FFFFFFF

            cmd = [
                str(self.backend_mystc), mc_path,
                "--pic", str(bin_path),
                "--seed", str(seed),
            ]
            if transform_flags:
                cmd.extend(transform_flags)
            if emit_ir:
                cmd += ["--transform-ir", str(var_mc)]
            if annotate:
                cmd += ["--annotate", str(ann_path)]

            # Write genome JSON if provided
            genome_path = None
            if genome:
                genome_path = Path(tmp) / "genome.json"
                genome_path.write_text(json.dumps(genome, indent=2))
                cmd += ["--genome", str(genome_path)]

            self._run(cmd)

            bin_data = bin_path.read_bytes()

            # Per-variant IR text + raw bytecode + segments from transformed .mcb
            ir_text = None
            mcb_hex = None
            mcb_segments = None
            if emit_ir and var_mc.exists():
                try:
                    mcb_data = var_mc.read_bytes()
                    mcb_hex = mcb_data.hex()
                    mcb_segments = mc_segment(mcb_data)
                except OSError:
                    mcb_data = None
                try:
                    ir_text = _mcb_to_ir_text(str(var_mc), ir_format)
                except Exception:
                    ir_text = None
                # Copy transformed .mcb out before tempdir is deleted
                if out_mcb:
                    try:
                        if mcb_data is not None:
                            Path(out_mcb).write_bytes(mcb_data)
                        else:
                            Path(out_mcb).write_bytes(var_mc.read_bytes())
                    except OSError:
                        pass

            # Disassemble to JSON
            dis_result = self._run([
                self.python, str(self.disasm_py),
                str(bin_path), "--json",
            ])
            try:
                disasm_json = json.loads(dis_result.stdout)
            except json.JSONDecodeError:
                disasm_json = {}
            instructions = disasm_json.get("instructions", [])

            annotations = None
            if annotate and ann_path.exists():
                try:
                    annotations = json.loads(ann_path.read_text())
                except (json.JSONDecodeError, OSError):
                    annotations = None  # corrupt/partial write; degrade gracefully

            x86_cfg = build_x86_cfg(instructions)

            result = {
                "bin_hex": bin_data.hex(),
                "sha256": _sha256(bin_data),
                "entropy": _entropy(bin_data),
                "disasm": instructions,
                "disasm_meta": {k: v for k, v in disasm_json.items() if k != "instructions"},
                "annotations": annotations,
                "x86_cfg": x86_cfg,
            }
            if ir_text is not None:
                result["ir_text"] = ir_text
            if mcb_hex is not None:
                result["mcb_hex"] = mcb_hex
            if mcb_segments is not None:
                result["mcb_segments"] = mcb_segments
            return result

    # ------------------------------------------------------------------
    # Function-name de-obfuscation (annotation name → IR name)
    # ------------------------------------------------------------------

    def _ir_opcode_seq(self, fn: dict) -> list:
        """
        Extract the ordered list of IR opcodes from a parsed IR function dict.
        Handles both assignment form ($0 = add ...) and bare form (jmp .label).
        """
        ops = []
        for blk in fn.get('blocks', []):
            for instr in blk.get('instructions', []):
                tokens = instr.strip().split()
                if not tokens:
                    continue
                # Assignment form: "$0 = add $1 $2 i32"
                if len(tokens) >= 3 and tokens[1] == '=':
                    op = tokens[2].upper()
                else:
                    op = tokens[0].upper()
                ops.append(op)
        return ops

    def _ann_opcode_seq(self, fn_ann: dict) -> list:
        """
        Extract the ordered list of ir_op strings from a real function's annotations.
        Only returns annotations that actually have an ir_op field (non-empty).
        """
        real_anns = sorted(
            (a for a in fn_ann.get('annotations', []) if a.get('kind') == 'real'),
            key=lambda a: a['offset'],
        )
        return [a['ir_op'].upper() for a in real_anns if a.get('ir_op')]

    # ------------------------------------------------------------------
    # LCS helpers for robust opcode alignment
    # ------------------------------------------------------------------

    def _lcs_len(self, a: list, b: list) -> int:
        """Compute LCS length using two-row DP (space-efficient)."""
        n, m = len(a), len(b)
        if n == 0 or m == 0:
            return 0
        prev = [0] * (m + 1)
        for i in range(n):
            curr = [0] * (m + 1)
            for j in range(m):
                if a[i] == b[j]:
                    curr[j + 1] = prev[j] + 1
                else:
                    curr[j + 1] = max(prev[j + 1], curr[j])
            prev = curr
        return prev[m]

    def _lcs_align(self, ann_ops: list, ir_ops: list) -> list:
        """
        Return a list of (ann_idx, ir_idx) pairs corresponding to the LCS of
        ann_ops and ir_ops.  Elements in ann_ops that are not in the LCS (extra
        annotations, or annotations with missing ir_op) have no entry and will
        not receive an ir_seq field.
        """
        n, m = len(ann_ops), len(ir_ops)
        if n == 0 or m == 0:
            return []

        # Build full DP table (forward LCS)
        dp = [[0] * (m + 1) for _ in range(n + 1)]
        for i in range(n - 1, -1, -1):
            for j in range(m - 1, -1, -1):
                if ann_ops[i] == ir_ops[j]:
                    dp[i][j] = 1 + dp[i + 1][j + 1]
                else:
                    dp[i][j] = max(dp[i + 1][j], dp[i][j + 1])

        # Backtrack to recover pairs
        pairs = []
        i = j = 0
        while i < n and j < m:
            if ann_ops[i] == ir_ops[j]:
                pairs.append((i, j))
                i += 1
                j += 1
            elif dp[i + 1][j] >= dp[i][j + 1]:
                i += 1   # this annotation has no matching IR op → skip
            else:
                j += 1   # this IR op has no matching annotation → skip
        return pairs

    def _add_ir_seq(self, ir: dict, annotations: dict, fn_name_map: dict) -> None:
        """
        Add an 'ir_seq' field to every real annotation, using LCS-based opcode
        alignment to correctly match each annotation to its IR instruction index.

        Using LCS instead of a simple two-pointer makes this robust to:
          - Annotations with missing ir_op fields (treated as empty → never match)
          - Extra backend_mystc.c annotations with no IR counterpart
          - IR instructions with no emitted annotation
        """
        if not annotations:
            return
        ir_fns = {fn['name'].lstrip('@'): fn for fn in ir.get('functions', [])}

        for fn_ann in annotations.get('functions', []):
            if fn_ann.get('kind') != 'real':
                continue
            ir_fn_name = fn_name_map.get(fn_ann['name'])
            if not ir_fn_name or ir_fn_name not in ir_fns:
                continue
            ir_fn  = ir_fns[ir_fn_name]
            ir_ops = self._ir_opcode_seq(ir_fn)

            real_anns = sorted(
                [a for a in fn_ann.get('annotations', []) if a.get('kind') == 'real'],
                key=lambda a: a['offset'],
            )

            # Build per-annotation opcode list (empty string for missing ir_op).
            # Empty strings never appear in ir_ops (which come from the IR text),
            # so they will always be "unmatched" in the LCS and get no ir_seq.
            ann_ops = [a.get('ir_op', '').upper() for a in real_anns]

            for ann_idx, ir_idx in self._lcs_align(ann_ops, ir_ops):
                real_anns[ann_idx]['ir_seq'] = ir_idx

    def _build_fn_name_mapping(self, ir: dict, annotations: dict) -> dict:
        """
        Map obfuscated annotation function names to IR function names.

        backend_mystc.c renames user-defined functions to random hex strings
        (e.g. factorial → r57399c).  We recover the mapping by:
          1. Exact opcode-sequence match (fast path)
          2. Best LCS similarity ratio ≥ 0.4 (fallback for when some
             ir_op fields are missing from the annotation JSON)

        Returns e.g. {'r57399c': 'factorial', 'r3a8b2d': 'main'}
        """
        if not annotations:
            return {}

        # Build (ir_name_without_@, opcode_list) pairs
        ir_fns = [
            (fn['name'].lstrip('@'), self._ir_opcode_seq(fn))
            for fn in ir.get('functions', [])
        ]

        mapping = {}
        for fn_ann in annotations.get('functions', []):
            if fn_ann.get('kind') != 'real':
                continue   # junk functions don't correspond to IR functions
            ann_name = fn_ann['name']
            ann_ops  = self._ann_opcode_seq(fn_ann)
            if not ann_ops:
                continue

            # --- Pass 1: exact match ---
            matched = False
            for ir_name, ir_ops in ir_fns:
                if ann_ops == ir_ops:
                    mapping[ann_name] = ir_name
                    matched = True
                    break

            if matched:
                continue

            # --- Pass 2: best LCS similarity (handles missing ir_op fields) ---
            best_score = 0.0
            best_name  = None
            for ir_name, ir_ops in ir_fns:
                if not ir_ops:
                    continue
                lcs = self._lcs_len(ann_ops, ir_ops)
                score = lcs / max(len(ann_ops), len(ir_ops))
                if score > best_score:
                    best_score = score
                    best_name  = ir_name
            if best_name and best_score >= 0.4:
                mapping[ann_name] = best_name

        return mapping

    # ------------------------------------------------------------------
    # Compile N variants from the same source
    # ------------------------------------------------------------------

    def compile_variants(self, source: str, n: int,
                         seed: int = None,
                         per_variant: list = None,
                         transform_flags: list = None,
                         ir_format: str = 'mce',
                         generational: bool = False,
                         mutate_genome: bool = False,
                         genome: dict = None,
                         platform: str = 'win32',
                         strip_debug: bool = False,
                         scramble_globals: bool = False) -> dict:
        """
        Compile source N times with per-variant transform flags and genome.

        per_variant: list of dicts, each with 'transform_flags' and 'genome'.
        Falls back to global transform_flags/genome if per_variant is None.

        Returns:
        {
          "ir": dict, "ir_cfg": dict, "mct": str, "mce": str,
          "generational": bool,
          "variants": [{ ...compile_to_x86 result..., "ir_text"?: str }]
        }
        """
        # Build per-variant configs
        if per_variant:
            pv = list(per_variant)  # copy so we can mutate
        else:
            pv = [{"transform_flags": transform_flags or [],
                    "genome": genome}] * n

        # When generational+mutate, derive V2+ genomes from V1 via mutation
        if generational and mutate_genome and len(pv) > 0:
            base_genome = pv[0].get("genome") or _default_genome()
            if base_genome:
                rng = _random.Random(seed if seed is not None else None)
                current_genome = dict(base_genome)
                for i in range(len(pv)):
                    if i == 0:
                        pv[i] = dict(pv[i], genome=current_genome)
                    else:
                        current_genome = _mutate_genome(current_genome, rng)
                        pv[i] = dict(pv[i], genome=current_genome)

        # Check if ANY variant has IR transforms
        any_ir = any(
            any(f.startswith('--ir-') for f in (v.get("transform_flags") or []))
            for v in pv
        )
        is_generational = generational and any_ir

        ir_result = self.compile_to_ir(source, platform=platform,
                                        strip_debug=strip_debug,
                                        scramble_globals=scramble_globals)
        mc_path = ir_result["mc_path"]

        variants = []
        base_seed = seed if seed is not None else int(_time.time_ns() // 1_000_000) & 0x7FFFFFFF

        _error_variant = {
            'bin_hex': '', 'sha256': '', 'entropy': 0.0,
            'disasm': [], 'disasm_meta': {}, 'annotations': None,
            'x86_cfg': {'nodes': [], 'edges': []},
            'fn_name_map': {},
        }

        if is_generational:
            gen_tmp = tempfile.mkdtemp()
            current_mc = mc_path
            try:
                for i in range(n):
                    variant_seed = (base_seed + i * 100003) & 0x7FFFFFFF
                    next_mcb = os.path.join(gen_tmp, f"gen_{i}.mcb")
                    vi = pv[i] if i < len(pv) else pv[-1]
                    vflags = vi.get("transform_flags") or []
                    vgenome = vi.get("genome")
                    has_ir = any(f.startswith('--ir-') for f in vflags)
                    try:
                        v = self.compile_to_x86(current_mc, seed=variant_seed,
                                                transform_flags=vflags,
                                                emit_ir=has_ir,
                                                ir_format=ir_format,
                                                out_mcb=next_mcb if has_ir else None,
                                                genome=vgenome)
                        fn_name_map = self._build_fn_name_mapping(ir_result['ir'], v['annotations'])
                        v['fn_name_map'] = fn_name_map
                    except Exception as e:
                        v = dict(_error_variant, error=str(e))
                    # Include the genome used for this variant
                    v['genome'] = vgenome
                    variants.append(v)
                    if has_ir and Path(next_mcb).exists():
                        current_mc = next_mcb
            finally:
                import shutil
                shutil.rmtree(gen_tmp, ignore_errors=True)
        else:
            for i in range(n):
                variant_seed = (base_seed + i * 100003) & 0x7FFFFFFF
                vi = pv[i] if i < len(pv) else pv[-1]
                vflags = vi.get("transform_flags") or []
                vgenome = vi.get("genome")
                has_ir = any(f.startswith('--ir-') for f in vflags)
                try:
                    v = self.compile_to_x86(mc_path, seed=variant_seed,
                                            transform_flags=vflags,
                                            emit_ir=has_ir,
                                            ir_format=ir_format,
                                            genome=vgenome)
                    fn_name_map = self._build_fn_name_mapping(ir_result['ir'], v['annotations'])
                    v['fn_name_map'] = fn_name_map
                except Exception as e:
                    v = dict(_error_variant, error=str(e))
                v['genome'] = vgenome
                variants.append(v)

        # Clean up temp mc
        try:
            os.unlink(mc_path)
        except OSError:
            pass

        return {
            "ir": ir_result["ir"],
            "ir_cfg": ir_result["cfg"],
            "mct": ir_result["mct"],
            "mce": ir_result["mce"],
            "generational": is_generational,
            "variants": variants,
        }

    # ------------------------------------------------------------------
    # Output format generation (PE/ELF/self-recompiling)
    # ------------------------------------------------------------------

    def compile_with_outputs(self, mc_path: str, project_dir: str,
                             output_formats: dict, seed: int,
                             platform: str = 'win32',
                             transform_flags: list = None,
                             genome: dict = None,
                             variant_index: int = 0,
                             project_name: str = "output",
                             strip_debug: bool = False,
                             scramble_globals: bool = False) -> dict:
        """
        Generate output files into project_dir/<platform>/variant_<N>/.

        output_formats keys (each platform-agnostic, mapped to the right
        backend command for the active platform):
          pic         — PIC shellcode of the user's program
          standalone  — user's program as a standalone PE/ELF
          recompiler  — recomp_{pe,elf}.mcb wrapping the user's program as payload
          infector    — infector_{pe,elf}.mcb wrapping the user's program as payload
          integrator  — integrator_entry.mc + --engine {mystiquefall,lacrimystique}.mcb
                        wrapping the user's program as payload (bundle)

        mc_path: path to the user's compiled .mcb (used as input for pic+standalone,
                 as --payload for the gen0 builds)
        """
        proj = Path(project_dir)
        is_win = platform != 'linux'
        ext = '.exe' if is_win else ''
        fmt_flag = '--pe-standalone' if is_win else '--elf-standalone'

        variant_dir = proj / platform / f"variant_{variant_index}"
        variant_dir.mkdir(parents=True, exist_ok=True)
        rel_dir = f"{platform}/variant_{variant_index}"
        outputs = {}

        if seed is None:
            seed = int(_time.time_ns() // 1_000_000) & 0x7FFFFFFF

        genome_args = []
        genome_tmp = None
        if genome:
            import tempfile as _tf
            genome_tmp = _tf.NamedTemporaryFile(mode='w', suffix='.json',
                                                 delete=False)
            genome_tmp.write(json.dumps(genome, indent=2))
            genome_tmp.close()
            genome_args = ["--genome", genome_tmp.name]

        base_user_cmd = [str(self.backend_mystc), mc_path, "--seed", str(seed)]
        if transform_flags:
            base_user_cmd.extend(transform_flags)

        stem = f"variant_{variant_index}"

        # Bundle flag specs: each gen0 output is one --<bundle>-<plat> flag that
        # resolves its carrier from --bundles-dir.
        bundle_flag = {
            ("recompiler", True):  "--recompiler-pe",
            ("recompiler", False): "--recompiler-elf",
            ("infector",   True):  "--infector-pe",
            ("infector",   False): "--infector-elf",
            ("integrator", True):  "--integrator-pe",
            ("integrator", False): "--integrator-elf",
        }
        # Carrier .mcb each bundle expects under --bundles-dir, used only as an
        # existence precheck so we can report a clear error.
        carrier_mcb = {
            "recompiler": self.recomp_pe_mcb if is_win else self.recomp_elf_mcb,
            "infector":   self.inf_pe_mcb    if is_win else self.inf_elf_mcb,
            "integrator": self.mfall_mcb     if is_win else self.lacri_mcb,
        }

        # The integrator's entry .mcb may need a fresh compile (e.g. when
        # strip_debug is set). Stage a temp apps-dir with a custom
        # integrator_entry_{pe,elf}.mcb so --integrator-* picks it up.
        integrator_bundles_dir = [None]   # populated lazily
        integrator_temp_root = [None]
        def get_integrator_bundles_dir():
            if integrator_bundles_dir[0] is not None:
                return integrator_bundles_dir[0]
            entry_mcb = self.compile_entry_mcb(platform, strip_debug, scramble_globals)
            tmp_root = Path(tempfile.mkdtemp(prefix="ide_apps_"))
            integrator_temp_root[0] = tmp_root
            sub = "mystiqueFall" if is_win else "lacriMystique"
            target = tmp_root / "integrators" / sub
            target.mkdir(parents=True, exist_ok=True)
            entry_name = "integrator_entry_pe.mcb" if is_win else "integrator_entry_elf.mcb"
            shutil.copy(entry_mcb, target / entry_name)
            engine_src = self.mfall_mcb if is_win else self.lacri_mcb
            shutil.copy(engine_src, target / engine_src.name)
            os.unlink(entry_mcb)
            integrator_bundles_dir[0] = str(tmp_root)
            return integrator_bundles_dir[0]

        try:
            if output_formats.get("pic"):
                pic_out = variant_dir / f"{stem}.bin"
                cmd = base_user_cmd + ["--pic", str(pic_out)] + genome_args
                self._run(cmd)
                if pic_out.exists():
                    outputs["pic"] = {"path": f"{rel_dir}/{stem}.bin",
                                      "size": pic_out.stat().st_size}

            if output_formats.get("standalone"):
                so_out = variant_dir / f"{stem}{ext}"
                cmd = base_user_cmd + [fmt_flag, str(so_out)] + genome_args
                self._run(cmd)
                if so_out.exists():
                    outputs["standalone"] = {"path": f"{rel_dir}/{stem}{ext}",
                                             "size": so_out.stat().st_size}

            for key in ("recompiler", "infector", "integrator"):
                if not output_formats.get(key):
                    continue
                cmcb = carrier_mcb[key]
                if not cmcb.exists():
                    outputs[key] = {"error": f"missing {cmcb.name}"}
                    continue
                out_name = f"{stem}_{key}{ext}"
                out_path = variant_dir / out_name
                this_bundles = (get_integrator_bundles_dir() if key == "integrator"
                             else str(self.bundles_dir))
                cmd = [str(self.backend_mystc), mc_path,
                       "--seed", str(seed),
                       bundle_flag[(key, is_win)], str(out_path),
                       "--bundles-dir", this_bundles]
                if transform_flags:
                    cmd.extend(transform_flags)
                cmd.extend(genome_args)
                self._run(cmd)
                if out_path.exists():
                    outputs[key] = {"path": f"{rel_dir}/{out_name}",
                                    "size": out_path.stat().st_size}

            if genome:
                genome_out = variant_dir / "genome.json"
                genome_out.write_text(json.dumps(genome, indent=2),
                                      encoding="utf-8")
                outputs["genome"] = {"path": f"{rel_dir}/genome.json",
                                     "size": genome_out.stat().st_size}
        finally:
            if genome_tmp:
                try:
                    os.unlink(genome_tmp.name)
                except OSError:
                    pass
            if integrator_temp_root[0]:
                shutil.rmtree(integrator_temp_root[0], ignore_errors=True)

        return outputs

    # ------------------------------------------------------------------
    # Byte-level diff between two variants
    # ------------------------------------------------------------------

    def diff_variants(self, hex_a: str, hex_b: str) -> dict:
        """
        Byte-level diff. Returns:
        {
          "similarity_pct": float,
          "a_len": int, "b_len": int,
          "diffs": [{"offset": int, "kind": "same|changed|insert|delete",
                      "byte_a": int|None, "byte_b": int|None}]
        }
        """
        a = bytes.fromhex(hex_a)
        b = bytes.fromhex(hex_b)
        length = max(len(a), len(b))
        diffs = []
        same = 0

        for i in range(length):
            ba = a[i] if i < len(a) else None
            bb = b[i] if i < len(b) else None
            if ba == bb:
                same += 1
                kind = "same"
            elif ba is None:
                kind = "insert"
            elif bb is None:
                kind = "delete"
            else:
                kind = "changed"
            diffs.append({"offset": i, "kind": kind, "byte_a": ba, "byte_b": bb})

        similarity = round(100.0 * same / length, 2) if length else 100.0
        return {
            "similarity_pct": similarity,
            "a_len": len(a),
            "b_len": len(b),
            "diffs": diffs,
        }

    # ------------------------------------------------------------------
    # Multi-generation pipeline
    # ------------------------------------------------------------------

    def run_generations(self, source: str, count: int, *,
                         genome: dict = None,
                         transform_flags: list = None,
                         platform: str = 'win32',
                         strip_debug: bool = False,
                         scramble_globals: bool = False) -> list:
        """
        Compile source, then run N successive polymorphic recompilations.
        Returns list of per-generation dicts:
        [{ "gen": N, "sha256": str, "size": int, "entropy": float,
           "diff_pct": float, "diff_from_gen0_pct": float,
           "mc_text": str, "bin_hex": str,
           "disasm": [...], "annotations": {...}|None,
           "genome": {...}|None }]
        """
        import shutil, uuid

        ir_result = self.compile_to_ir(source, platform=platform,
                                        strip_debug=strip_debug,
                                        scramble_globals=scramble_globals)
        mc_path = ir_result["mc_path"]

        gens = []
        prev_bin = None
        gen0_bin = None
        base_seed = int(_time.time_ns() // 1_000_000) & 0x7FFFFFFF

        for g in range(count):
            with tempfile.TemporaryDirectory() as tmp:
                bin_path  = Path(tmp) / f"gen{g}.bin"
                next_mc   = Path(tmp) / f"gen{g}.mcb"
                ann_path  = Path(tmp) / f"gen{g}_ann.json"
                genome_in = Path(tmp) / "genome_in.json"
                genome_out = Path(tmp) / "genome_out.json"

                # Capture this generation's bytecode BEFORE backend_mystc transforms it
                try:
                    mc_bytes = Path(mc_path).read_bytes()
                except Exception:
                    mc_bytes = b''
                mc_hex      = mc_bytes.hex()          # always safe
                mc_text     = mc_disasm(mc_bytes)     # returns error string on parse failure
                mc_segs     = mc_segment(mc_bytes)    # disasm-style byte+text segments

                cmd = [
                    str(self.backend_mystc), mc_path,
                    "--pic", str(bin_path),
                    "--seed", str((base_seed + g * 100003) & 0x7FFFFFFF),
                    "--transform-ir", str(next_mc),
                    "--annotate", str(ann_path),
                ]
                if transform_flags:
                    cmd.extend(transform_flags)

                # Genome: write input, enable mutation, capture output
                if genome:
                    genome_in.write_text(json.dumps(genome, indent=2))
                    cmd += ["--genome", str(genome_in),
                            "--genome-mutate",
                            "--genome-out", str(genome_out)]

                self._run(cmd)

                bin_data = bin_path.read_bytes()
                sha = _sha256(bin_data)
                ent = _entropy(bin_data)
                diff_prev = _byte_diff_pct(prev_bin, bin_data) if prev_bin else 0.0
                diff_gen0 = _byte_diff_pct(gen0_bin, bin_data) if gen0_bin else 0.0

                # Disassemble to JSON
                try:
                    dis_result = self._run([
                        self.python, str(self.disasm_py),
                        str(bin_path), "--json",
                    ])
                    disasm_json = json.loads(dis_result.stdout)
                except Exception:
                    disasm_json = {}
                instructions = disasm_json.get("instructions", [])

                # Annotations
                annotations = None
                if ann_path.exists():
                    try:
                        annotations = json.loads(ann_path.read_text())
                    except (json.JSONDecodeError, OSError):
                        annotations = None

                # Read mutated genome output
                gen_genome = None
                if genome and genome_out.exists():
                    try:
                        gen_genome = json.loads(genome_out.read_text())
                    except (json.JSONDecodeError, OSError):
                        gen_genome = None
                    # Feed mutated genome into next generation
                    if gen_genome:
                        genome = gen_genome

                gens.append({
                    "gen": g,
                    "sha256": sha,
                    "size": len(bin_data),
                    "entropy": ent,
                    "diff_pct": diff_prev,
                    "diff_from_gen0_pct": diff_gen0,
                    "mc_text":     mc_text,
                    "mc_hex":      mc_hex,
                    "mc_segments": mc_segs,
                    "bin_hex": bin_data.hex(),
                    "disasm": instructions,
                    "annotations": annotations,
                    "genome": gen_genome,
                })

                prev_bin = bin_data
                if g == 0:
                    gen0_bin = bin_data

                # Use the transformed .mcb as input for the next generation
                if next_mc.exists():
                    new_mc = Path(tempfile.gettempdir()) / f"mystique_{uuid.uuid4().hex}.mcb"
                    shutil.copy(next_mc, new_mc)
                    try:
                        os.unlink(mc_path)
                    except OSError:
                        pass
                    mc_path = str(new_mc)

        try:
            os.unlink(mc_path)
        except OSError:
            pass

        return gens
