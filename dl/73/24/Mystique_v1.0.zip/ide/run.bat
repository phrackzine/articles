@echo off
if "%PORT%"=="" set PORT=5000
start "" /b cmd /c "timeout /t 1 /nobreak >nul && start http://localhost:%PORT%"
python server.py
