"""
server.py — Flask server for the Mystique IDE.

Endpoints:
  POST /api/compile          — compile source to IR + N x86 variants
  POST /api/evolve           — run N self-recompiling generations
  POST /api/project/create   — create a new project directory
  POST /api/project/open     — open an existing project
  POST /api/project/save     — save project config + source
  POST /api/project/list-dir — browse directories
  GET  /api/capabilities     — report available output formats
  GET  /api/cwd              — server-side CWD for the file picker

Usage:
  cd C:\\Users\\stard\\Desktop\\Personal\\Mystique
  python ide/server.py
  # → http://localhost:5000
"""

import json
import os
import sys
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT / "ide"))

from bridge import CompilerBridge

bridge = CompilerBridge(PROJECT_ROOT)

STATIC_DIR = Path(__file__).parent / "static"
app = Flask(__name__, static_folder=None)


@app.get("/")
def index():
    return send_from_directory(str(STATIC_DIR), "index.html")


@app.get("/<path:filename>")
def static_files(filename):
    return send_from_directory(str(STATIC_DIR), filename)


@app.post("/api/compile")
def api_compile():
    """
    Request body:
      {
        "source": "...",
        "n_variants": 2,
        "seed": 1001,            // optional; null = random
        "per_variant": [         // per-variant transform flags + genome
          { "transform_flags": [...], "genome": {...} },
          ...
        ],
        "generational": false,
        "mutate_genome": false,
        "ir_format": "mce",
        "output_formats": {...}, // optional
        "project_dir": "..."     // optional
      }

    Response:
      {
        "mct": "...",
        "mce": "...",
        "ir": { ... },
        "variants": [ { "bin_hex", "sha256", "entropy", "disasm",
                        "annotations", "fn_name_map", "error"? }, ... ]
      }
    """
    body = request.get_json(force=True, silent=True) or {}
    source = body.get("source", "")
    n = max(1, min(99, int(body.get("n_variants", 2))))

    seed = body.get("seed")
    if seed is not None:
        seed = int(seed) & 0x7FFFFFFF

    ir_format = body.get("ir_format", "mce")
    if ir_format not in ("mce", "mct"):
        ir_format = "mce"

    generational = bool(body.get("generational", False))
    mutate_genome = bool(body.get("mutate_genome", False))
    target_platform = body.get("target_platform", "win32")
    strip_debug = bool(body.get("strip_debug", False))
    scramble_globals = bool(body.get("scramble_globals", False))

    # Per-variant configs
    per_variant = body.get("per_variant") or []
    if not isinstance(per_variant, list):
        per_variant = []

    # Backward compat: if no per_variant, use global flags/genome
    if not per_variant:
        transform_flags = body.get("transform_flags") or []
        if not isinstance(transform_flags, list):
            transform_flags = []
        genome = body.get("genome")
        per_variant = [{"transform_flags": transform_flags, "genome": genome}] * n

    # Pad to n if fewer entries
    while len(per_variant) < n:
        per_variant.append(per_variant[-1] if per_variant else
                           {"transform_flags": [], "genome": None})

    if not source.strip():
        return jsonify({"error": "source is empty"}), 400

    output_formats = body.get("output_formats")  # dict or None
    project_dir = body.get("project_dir")  # str or None

    try:
        result = bridge.compile_variants(source, n,
                                         seed=seed,
                                         per_variant=per_variant,
                                         ir_format=ir_format,
                                         generational=generational,
                                         mutate_genome=mutate_genome,
                                         platform=target_platform,
                                         strip_debug=strip_debug,
                                         scramble_globals=scramble_globals)
    except Exception as e:
        msg = str(e)
        for marker in ('\nstderr: ', '\nstdout: '):
            if marker in msg:
                tail = msg.split(marker, 1)[1].strip()
                if tail:
                    msg = tail
                    break
        return jsonify({"error": msg}), 500

    # Save per-variant artifacts + report if project dir is provided
    if project_dir:
        # Derive project name from config
        project_name = "output"
        try:
            proj_cfg_path = Path(project_dir) / "mystique.json"
            if proj_cfg_path.exists():
                proj_cfg = json.loads(proj_cfg_path.read_text(encoding="utf-8"))
                sf = proj_cfg.get("source_file", "program.mc")
                project_name = sf.rsplit(".", 1)[0] if "." in sf else sf
        except Exception:
            pass

        proj = Path(project_dir)
        plat_dir = proj / target_platform
        plat_dir.mkdir(parents=True, exist_ok=True)
        base_ir_text = result.get("mce") or result.get("mct") or ""

        # Save per-variant IR, disasm, genome into <platform>/variant_N/
        for i, v in enumerate(result.get("variants", [])):
            vdir = plat_dir / f"variant_{i}"
            vdir.mkdir(parents=True, exist_ok=True)
            ir_text = v.get("ir_text") or base_ir_text
            if ir_text:
                ext = "mce" if ir_format == "mce" else "mct"
                (vdir / f"variant_{i}_ir.{ext}").write_text(
                    ir_text, encoding="utf-8")
            genome_i = v.get("genome")
            if genome_i:
                (vdir / "genome.json").write_text(
                    json.dumps(genome_i, indent=2), encoding="utf-8")

        # Save the user's .mcb under <platform>/ so it can be inspected
        # or reused as an external --payload.
        try:
            _ir_save = bridge.compile_to_ir(source, platform=target_platform,
                                             strip_debug=strip_debug,
                                             scramble_globals=scramble_globals)
            import shutil as _shutil2
            _shutil2.copy2(_ir_save["mc_path"], str(plat_dir / "payload.mcb"))
            os.unlink(_ir_save["mc_path"])
        except Exception:
            pass

        # Generate binary outputs if output formats requested
        if output_formats:
            try:
                ir_result = bridge.compile_to_ir(source, platform=target_platform,
                                                  strip_debug=strip_debug,
                                                  scramble_globals=scramble_globals)
                mc_path = ir_result["mc_path"]
                all_outputs = []
                for i in range(n):
                    vi = per_variant[i] if i < len(per_variant) else per_variant[-1]
                    vi_genome = vi.get("genome")
                    if result.get("variants") and i < len(result["variants"]):
                        rv = result["variants"][i]
                        if rv.get("genome"):
                            vi_genome = rv["genome"]
                    try:
                        out_i = bridge.compile_with_outputs(
                            mc_path, project_dir, output_formats,
                            seed=seed,
                            platform=target_platform,
                            transform_flags=vi.get("transform_flags"),
                            genome=vi_genome,
                            variant_index=i,
                            project_name=project_name,
                            strip_debug=strip_debug,
                            scramble_globals=scramble_globals,
                        )
                        all_outputs.append(out_i)
                    except Exception as e:
                        all_outputs.append({"error": str(e)})
                result["outputs"] = all_outputs
                try:
                    os.unlink(mc_path)
                except OSError:
                    pass
            except Exception as e:
                result["output_error"] = str(e)

        # Per-platform HTML report
        try:
            report_path = plat_dir / "report.html"
            report_path.write_text(
                _build_report_html(result, project_name, ir_format, seed,
                                   generational, mutate_genome, source=source),
                encoding="utf-8")
            result["report"] = f"{target_platform}/report.html"
        except Exception:
            pass

    return jsonify(result)


# ---------------------------------------------------------------------------
# HTML generation helpers
# ---------------------------------------------------------------------------

_DISASM_COLORS = {
    "real": "#4488ff", "prologue": "#3a9a6e", "dead_code": "#ff8833",
    "opaque_predicate": "#ffe033", "nop_variant": "#8888aa",
    "junk_function": "#cc55ff", "junk_call": "#ff3355",
}
_LEGEND_LABELS = {
    "real": "Real", "prologue": "Prologue", "dead_code": "Dead code",
    "opaque_predicate": "Opaque pred.", "nop_variant": "NOP variant",
    "junk_function": "Junk fn", "junk_call": "Junk call",
}
_BAR_COLORS = ["#4488ff", "#ff8833", "#ffe033", "#3a9a6e",
               "#cc55ff", "#ff3355", "#50c8f0", "#8888aa"]
_SCALAR_RANGES = {
    'unfold_chance': (0, 100), 'substitute_chance': (0, 100),
    'dead_code_chance': (0, 100), 'nop_chance': (0, 100),
    'nop_max_count': (1, 10), 'dead_prologue_pct': (0, 100),
    'dead_block_pct': (0, 100), 'dead_instr_pct': (0, 100),
    'opaque_pct': (0, 100), 'junk_call_block_pct': (0, 100),
    'junk_call_instr_pct': (0, 100), 'harmless_block_pct': (0, 100),
    'harmless_instr_pct': (0, 100), 'junk_func_pct': (0, 200),
    'expression_flags': (0, 32767),
    'expression_rate': (0, 100), 'genome_temperature': (0, 100),
}

# Ordered gene lists for the evolution table
_EVO_SCALAR_KEYS = [
    'unfold_chance', 'substitute_chance', 'dead_code_chance',
    'nop_chance', 'nop_max_count',
    'dead_prologue_pct', 'dead_block_pct', 'dead_instr_pct',
    'opaque_pct', 'junk_call_block_pct', 'junk_call_instr_pct',
    'harmless_block_pct', 'harmless_instr_pct',
    'junk_func_pct',
    'expression_flags', 'expression_rate', 'genome_temperature',
]
_EVO_VECTOR_KEYS = [
    'unfold_weights', 'dead_code_weights',
    'add_weights', 'sub_weights',
    'movi_weights', 'movi_zero_weights', 'movi_neg1_weights',
    'xor_weights', 'cmp_weights',
    'junk_seq_weights', 'opaque_weights',
]

# MystC keywords for syntax highlighting
_MC_KEYWORDS = {
    'int', 'char', 'ptr', 'void', 'if', 'else', 'while', 'return',
    'struct', 'goto', 'extern', 'nop', 'global', 'str',
}


# ---------------------------------------------------------------------------
# Report helper: IR line map + annotation maps  (ported from app.js)
# ---------------------------------------------------------------------------

import re as _re
import html as _html


def _guess_ir_op(line, ir_format):
    """Port of guessIrOp() from app.js."""
    t = line.strip()
    if not t:
        return None
    if ir_format == 'mct':
        m = _re.match(r'^(?:[%$!@]\S+\s*=\s*)?(\w+)', t)
        return m.group(1).upper() if m else None
    # mce format
    if t.endswith(':'):
        return None
    if t in ('{', '}'):
        return None
    if t.startswith('//'):
        return None
    if _re.match(r'^(str|global|extern|struct)\s', t):
        return None
    if _re.match(r'^(int|char|ptr|void)\s+\w+\s*[\({]', t):
        return None
    if _re.match(r'^(int|char|ptr|void)\s+\w', t):
        return None
    if t == 'nop':
        return 'NOP'
    if t.startswith('goto '):
        return 'JMP'
    if t.startswith('if (!'):
        return 'JZ'
    if t.startswith('if ('):
        return 'JNZ'
    if t == 'return':
        return 'RETV'
    if t.startswith('return '):
        return 'RET'
    if t.startswith('*'):
        return 'STORE'
    # Bare function call (no assignment): e.g. "r380b50()" or "re42fa8(s29)"
    if _re.match(r'^\w+\s*\(', t):
        return 'CALLV'
    eq = t.find(' = ')
    if eq < 0:
        return None
    rhs = t[eq + 3:].strip()
    if rhs.startswith('*'):
        return 'LOAD'
    if rhs.startswith('&'):
        return 'ADDR'
    if rhs.startswith('-'):
        return 'NEG'
    if rhs.startswith('~'):
        return 'NOT'
    if rhs.startswith('alloca('):
        return 'ALLOCA'
    if _re.match(r'^\w+\s*\(', rhs):
        return 'CALL'
    if rhs.startswith('('):
        if '==' in rhs: return 'EQ'
        if '!=' in rhs: return 'NE'
        if '<=' in rhs: return 'LE'
        if '>=' in rhs: return 'GE'
        if '<' in rhs:  return 'LT'
        if '>' in rhs:  return 'GT'
    if ' + ' in rhs:  return 'ADD'
    if ' - ' in rhs:  return 'SUB'
    if ' * ' in rhs:  return 'MUL'
    if ' / ' in rhs:  return 'DIV'
    if ' % ' in rhs:  return 'MOD'
    if ' & ' in rhs:  return 'AND'
    if ' | ' in rhs:  return 'OR'
    if ' ^ ' in rhs:  return 'XOR'
    if ' << ' in rhs: return 'SHL'
    if ' >> ' in rhs: return 'SHR'
    return 'COPY'


def _build_ir_line_map(ir_text, ir_format):
    """Port of buildIrLineMap() — returns dict mapping 'fn:seq' to IR line text.

    Uses raw function names from the per-variant IR text directly (no
    fn_name_map needed — the per-variant IR and annotations share the
    same obfuscated names from the same backend run).
    """
    result = {}
    if not ir_text:
        return result
    current_fn = None
    seq = 0
    for line in ir_text.split('\n'):
        t = line.strip()
        if ir_format == 'mce':
            m = _re.match(r'^(?:int|char|ptr|void)\s+(\w+)\s*\(', t)
        else:
            m = _re.match(r'^fn\s+@?(\w+)', t)
        if m:
            current_fn = m.group(1)
            seq = 0
            continue
        if current_fn and _guess_ir_op(line, ir_format):
            result[f"{current_fn}:{seq}"] = t
            seq += 1
    return result


def _build_ann_map(annotations):
    """Port of buildAnnotMap() — returns dict mapping offset to annotation info.

    Uses raw annotation function names directly as ir_fn (no fn_name_map
    needed — the per-variant IR and annotations share the same obfuscated
    names from the same backend run).
    """
    ann_map = {}
    if not annotations:
        return ann_map
    # First pass: fill function-level base kind
    for fn in annotations.get("functions", []):
        end = fn.get("end_offset", fn.get("offset", 0))
        base = {"kind": fn.get("kind", "unknown")}
        for off in range(fn.get("offset", 0), max(fn.get("offset", 0), end)):
            ann_map[off] = base
    # Second pass: per-instruction annotations override
    for fn in annotations.get("functions", []):
        ir_fn = fn.get("name")
        for a in fn.get("annotations", []):
            if a.get("kind") == "block_label":
                continue
            enriched = dict(a)
            if ir_fn:
                enriched["ir_fn"] = ir_fn
            for off in range(a["offset"], a["offset"] + a.get("size", 1)):
                ann_map[off] = enriched
    return ann_map


def _build_func_map(annotations):
    func_map = {}
    if not annotations:
        return func_map
    for fn in annotations.get("functions", []):
        func_map[fn.get("offset")] = fn
    return func_map


def _build_block_map(annotations):
    blk_map = {}
    if not annotations:
        return blk_map
    for fn in annotations.get("functions", []):
        for a in fn.get("annotations", []):
            if a.get("kind") == "block_label" and a.get("label"):
                blk_map[a["offset"]] = a["label"]
    return blk_map


def _syntax_highlight(source):
    """Basic MystC syntax highlighting → HTML with <span> tags."""
    out = []
    for line in _html.escape(source).split('\n'):
        # Comments
        ci = line.find('//')
        comment = ''
        if ci >= 0:
            comment = f'<span class="sc">{line[ci:]}</span>'
            line = line[:ci]
        # String literals
        line = _re.sub(r'(&quot;[^&]*?&quot;)', r'<span class="ss">\1</span>', line)
        # Numbers
        line = _re.sub(r'\b(0x[\da-fA-F]+|\d+)\b', r'<span class="sn">\1</span>', line)
        # Keywords
        for kw in _MC_KEYWORDS:
            line = _re.sub(rf'\b({kw})\b', r'<span class="sk">\1</span>', line)
        out.append(line + comment)
    return '\n'.join(out)


def _scalar_bar_html(val, key):
    lo, hi = _SCALAR_RANGES.get(key, (0, 100))
    rng = hi - lo or 1
    pct = max(0, min(100, 100 * (val - lo) / rng))
    hue = 200 - pct * 1.8
    return (f'<div class="evo-sbar" title="{val}">'
            f'<div class="evo-sfill" style="width:{pct:.0f}%;background:hsl({hue:.0f},70%,55%)"></div>'
            f'<span class="evo-slbl">{val}</span></div>')


def _weight_bar_html(weights):
    if not weights:
        return '—'
    total = sum(weights) or 1
    segs = ''.join(
        f'<div class="evo-wseg" style="flex:{w};background:{_BAR_COLORS[i % len(_BAR_COLORS)]}" '
        f'title="v{i}: {w} ({100*w/total:.0f}%)"></div>'
        for i, w in enumerate(weights))
    return f'<div class="evo-wbar">{segs}</div>'


# ---------------------------------------------------------------------------
# Main report builder
# ---------------------------------------------------------------------------

def _build_report_html(result, project_name, ir_format, seed,
                       generational, mutate_genome, source=""):
    """Build a standalone HTML report with 5 tabs: Summary, Source, IR, Variants, Evolution."""
    from datetime import datetime
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    variants = result.get("variants", [])
    ir = result.get("ir", {})
    n = len(variants)

    L = []  # line accumulator
    a = L.append

    a("<!DOCTYPE html><html><head>")
    a(f"<meta charset='UTF-8'><title>{_html.escape(project_name)} — Report</title>")
    a("<style>")
    a("""
*{box-sizing:border-box}
body{background:#0d0d0d;color:#c8c8e8;font-family:'Cascadia Code','Consolas',monospace;font-size:12px;margin:0;padding:0;overflow:hidden;height:100vh;display:flex;flex-direction:column}
h1{font-size:16px;color:#7070f0;margin:0;padding:12px 20px;background:#141420;border-bottom:1px solid #2a2a45;flex-shrink:0}
.tabs{display:flex;gap:0;background:#141420;border-bottom:1px solid #2a2a45;padding:0 16px;flex-shrink:0}
.tab{padding:8px 16px;cursor:pointer;color:#666688;border-bottom:2px solid transparent;font-size:11px;text-transform:uppercase;user-select:none}
.tab.active{color:#50c8f0;border-bottom-color:#50c8f0}
.tab:hover{color:#c8c8e8}
.panel{display:none;padding:16px 20px;overflow:auto;flex:1}
.panel.active{display:flex;flex-direction:column}
table{border-collapse:collapse;margin:8px 0}
th{text-align:left;color:#50c8f0;padding:4px 10px;border-bottom:1px solid #2a2a45;font-size:10px;text-transform:uppercase;white-space:nowrap}
td{padding:4px 10px;border-bottom:1px solid #1a1a2e;white-space:nowrap}
.lbl{color:#666688;width:140px;display:inline-block}
.val{color:#c8c8e8}
.ok{color:#3a9a6e}.err{color:#ff3355}.dim{color:#666688}
pre{background:#141420;padding:10px;border:1px solid #2a2a45;overflow:auto;font-size:11px;margin:0}
a{color:#50c8f0;text-decoration:none}
a:hover{text-decoration:underline}

/* Source highlighting */
.sk{color:#c084fc}.ss{color:#3a9a6e}.sn{color:#ff8833}.sc{color:#555570}

/* Console */
.console{background:#0a0a14;border:1px solid #2a2a45;padding:8px;font-size:11px;overflow:auto;flex:1;min-height:120px;max-height:40vh;margin-top:12px}
.console .ok{color:#3a9a6e}.console .hdr{color:#50c8f0;font-weight:bold}
.console .info{color:#888}.console .err{color:#ff3355}

/* Outputs table */
.out-tbl{width:auto}

/* Legend */
.legend{display:flex;gap:12px;flex-wrap:wrap;font-size:10px;padding:8px 0}
.legend-item{display:inline-flex;align-items:center;gap:4px}
.legend-sw{width:10px;height:10px;border-radius:2px;display:inline-block}

/* Variants tab */
.var-bar{display:flex;gap:0;background:#141420;border-bottom:1px solid #2a2a45;padding:0 12px;flex-shrink:0;align-items:stretch}
.var-btn{padding:6px 14px;cursor:pointer;color:#666688;border:none;background:none;font-family:inherit;font-size:11px;border-bottom:2px solid transparent;user-select:none}
.var-btn.active{color:#50c8f0;border-bottom-color:#50c8f0}
.var-btn:hover{color:#c8c8e8}
.var-btn .dim{font-size:9px;color:#555;margin-left:4px}
.var-content{display:none;flex:1;min-height:0}
.var-content.active{display:flex;flex-direction:row}
.var-pane{flex:1;overflow:auto;min-width:0;font-size:11px}
.var-pane-ir{border-right:1px solid #2a2a45;background:#0a0a14}
.var-pane-ir pre{margin:0;padding:8px 10px;white-space:pre;font-size:10px;background:transparent;border:none;max-height:none}
.var-pane-asm{flex:1.2}
.var-pane-hdr{background:#141420;padding:4px 10px;font-size:10px;color:#7070f0;border-bottom:1px solid #2a2a45;font-weight:bold;position:sticky;top:0;z-index:1}

/* Disasm rows */
.x86{padding:0 6px}
.x86-fn{color:#50c8f0;font-weight:bold;padding:10px 6px 2px;font-size:11px}
.x86-fn.junk{color:#cc55ff}
.x86-blk{color:#3a9a6e;padding:4px 6px 1px;font-size:10px}
.x86-irc{color:#7070f0;padding:2px 6px 2px 12px;font-size:10px;font-style:italic;border-left:3px solid #333}
.x86-row{display:flex;gap:0;border-left:3px solid transparent;padding:0 6px 0 12px;line-height:1.5}
.x86-row .off{color:#666688;width:44px;flex-shrink:0}
.x86-row .hx{color:#555;width:110px;flex-shrink:0;overflow:hidden}
.x86-row .op{width:64px;flex-shrink:0}
.x86-row .ar{color:#888;flex:1}
""")
    # Annotation color classes
    for kind, color in _DISASM_COLORS.items():
        a(f".x86-row.ann-{kind}{{border-left-color:{color}}}")
    a("""
/* Evolution tab */
.evo-tbl{width:auto;font-size:11px}
.evo-tbl th{position:sticky;top:0;background:#141420;z-index:2;padding:6px 10px}
.evo-tbl td{padding:3px 10px;vertical-align:middle}
.evo-tbl .gene{color:#888;min-width:140px;position:sticky;left:0;background:#0d0d0d;z-index:1}
.evo-tbl .sec{color:#7070f0;font-weight:bold;background:#0d0d0d;position:sticky;left:0;z-index:1}
.evo-tbl .chg{color:#50c8f0;font-weight:bold}
.evo-sbar{position:relative;width:80px;height:14px;background:#1a1a2e;border-radius:2px;overflow:hidden;display:inline-block;vertical-align:middle}
.evo-sfill{position:absolute;top:0;left:0;height:100%;border-radius:2px}
.evo-slbl{position:absolute;top:0;left:0;width:100%;text-align:center;font-size:9px;line-height:14px;color:#c8c8e8}
.evo-wbar{display:flex;height:14px;border-radius:2px;overflow:hidden;min-width:80px}
.evo-wseg{min-width:4px}
""")
    a("</style></head><body>")
    a(f"<h1>{_html.escape(project_name)} — Compilation Report</h1>")

    # ── Tab bar ──
    tab_ids = ["summary", "source", "ir", "variants", "evolution"]
    a("<div class='tabs'>")
    for i, tid in enumerate(tab_ids):
        cls = " active" if i == 0 else ""
        a(f"<div class='tab{cls}' onclick='showTab(\"{tid}\")'>{tid.title()}</div>")
    a("</div>")

    # ══════════════════════════════════════════════════════════════════════
    # Tab 1: Summary
    # ══════════════════════════════════════════════════════════════════════
    a("<div class='panel active' id='panel-summary'>")
    a("<div>")
    a(f"<div style='color:#666688;margin-bottom:8px'>{now}</div>")
    a(f"<span class='lbl'>Project</span><span class='val'>{_html.escape(project_name)}</span><br>")
    a(f"<span class='lbl'>Variants</span><span class='val'>{n}</span><br>")
    a(f"<span class='lbl'>IR format</span><span class='val'>{ir_format}</span><br>")
    a(f"<span class='lbl'>Seed</span><span class='val'>{seed if seed else 'random'}</span><br>")
    a(f"<span class='lbl'>Generational</span><span class='val'>{'yes' if generational else 'no'}</span><br>")
    a(f"<span class='lbl'>Mutate genome</span><span class='val'>{'yes' if mutate_genome else 'no'}</span><br>")
    a(f"<span class='lbl'>Functions</span><span class='val'>{len(ir.get('functions', []))}</span><br>")
    a(f"<span class='lbl'>Globals</span><span class='val'>{len(ir.get('globals', []))}</span><br>")
    a(f"<span class='lbl'>Strings</span><span class='val'>{len(ir.get('strings', []))}</span><br>")

    # Outputs table
    all_outputs = result.get("outputs", [])
    if isinstance(all_outputs, list) and all_outputs:
        a("<div style='margin-top:12px'><span class='lbl' style='color:#7070f0'>Output Files</span></div>")
        a("<table class='out-tbl'><thead><tr><th>#</th><th>Format</th><th>Path</th><th>Size</th></tr></thead><tbody>")
        for i, vo in enumerate(all_outputs):
            if isinstance(vo, dict) and not vo.get("error"):
                for fmt, finfo in vo.items():
                    if isinstance(finfo, dict) and finfo.get("path"):
                        sz = finfo.get("size", 0) / 1024
                        a(f"<tr><td>V{i}</td><td>{_html.escape(fmt)}</td>"
                          f"<td style='color:#888'>{_html.escape(str(finfo['path']))}</td>"
                          f"<td>{sz:.1f} KB</td></tr>")
            elif isinstance(vo, dict) and vo.get("error"):
                a(f"<tr><td>V{i}</td><td colspan='3' class='err'>{_html.escape(vo['error'])}</td></tr>")
        a("</tbody></table>")
    if result.get("output_error"):
        a(f"<div class='err'>{_html.escape(result['output_error'])}</div>")

    # Console
    a("<div class='console'>")
    a(f"<div class='hdr'>Compilation — {n} variant(s)</div>")
    a(f"<div class='info'>IR format: {ir_format}  Seed: {seed if seed else 'random'}  "
      f"Generational: {'yes' if generational else 'no'}  Mutate: {'yes' if mutate_genome else 'no'}</div>")
    a(f"<div class='info'>Functions: {len(ir.get('functions', []))}  "
      f"Globals: {len(ir.get('globals', []))}  Strings: {len(ir.get('strings', []))}</div>")
    for i, v in enumerate(variants):
        if v.get("error"):
            a(f"<div class='err'>V{i} error: {_html.escape(v['error'])}</div>")
        else:
            sz = len(v.get("bin_hex", "")) / 2
            sha = v.get("sha256", "")[:16]
            a(f"<div class='ok'>V{i}: {sz:.0f} bytes  entropy {v.get('entropy', 0):.2f}  "
              f"sha {sha}…</div>")
    if isinstance(all_outputs, list):
        for i, vo in enumerate(all_outputs):
            if isinstance(vo, dict) and not vo.get("error"):
                fmts = [f for f in vo if isinstance(vo[f], dict) and vo[f].get("path")]
                if fmts:
                    a(f"<div class='info'>V{i} outputs: {', '.join(fmts)}</div>")
    a("<div class='ok'>Done.</div>")
    a("</div>")  # console
    a("</div>")  # inner
    a("</div>")  # panel

    # ══════════════════════════════════════════════════════════════════════
    # Tab 2: Source
    # ══════════════════════════════════════════════════════════════════════
    a("<div class='panel' id='panel-source'>")
    if source:
        a(f"<pre style='flex:1;max-height:none'>{_syntax_highlight(source)}</pre>")
    else:
        a("<div class='dim'>No source code available</div>")
    a("</div>")

    # ══════════════════════════════════════════════════════════════════════
    # Tab 3: IR  (base IR before transforms)
    # ══════════════════════════════════════════════════════════════════════
    a("<div class='panel' id='panel-ir'>")
    ir_text = result.get("mce") or result.get("mct") or ""
    if ir_text:
        a(f"<pre style='flex:1;max-height:none'>{_html.escape(ir_text)}</pre>")
    else:
        a("<div class='dim'>No IR output</div>")
    a("</div>")

    # ══════════════════════════════════════════════════════════════════════
    # Tab 4: Variants  (selector → IR | Disasm split)
    # ══════════════════════════════════════════════════════════════════════
    a("<div class='panel' id='panel-variants' style='padding:0'>")

    # Variant selector + legend in one bar
    a("<div style='display:flex;align-items:center;border-bottom:1px solid #2a2a45;flex-shrink:0'>")
    a("<div class='var-bar' style='border-bottom:none;flex:0 0 auto'>")
    for vi, v in enumerate(variants):
        cls = " active" if vi == 0 else ""
        if v.get("error"):
            lbl = f"V{vi} <span class='dim'>error</span>"
        else:
            sz_kb = len(v.get("bin_hex", "")) / 2 / 1024
            lbl = f"V{vi} <span class='dim'>{sz_kb:.1f}KB</span>"
        a(f"<button class='var-btn{cls}' onclick='showVar({vi})'>{lbl}</button>")
    a("</div>")
    # Legend
    a("<div class='legend' style='margin-left:auto;padding:4px 16px'>")
    for kind, color in _DISASM_COLORS.items():
        label = _LEGEND_LABELS.get(kind, kind)
        a(f"<span class='legend-item'><span class='legend-sw' style='background:{color}'></span>{label}</span>")
    a("</div>")
    a("</div>")  # bar row

    # Per-variant content (IR left | Disasm right)
    for vi, v in enumerate(variants):
        active = " active" if vi == 0 else ""
        a(f"<div class='var-content{active}' id='varcontent-{vi}'>")

        # Left pane: IR
        var_ir = v.get("ir_text", "")
        a("<div class='var-pane var-pane-ir'>")
        a("<div class='var-pane-hdr'>Transformed IR</div>")
        if var_ir:
            a(f"<pre>{_html.escape(var_ir)}</pre>")
        else:
            a("<div style='padding:10px' class='dim'>No per-variant IR</div>")
        a("</div>")

        # Right pane: Disasm
        a("<div class='var-pane var-pane-asm'>")
        sha_s = v.get("sha256", "")[:12]
        ent_s = f"{v.get('entropy', 0):.2f}"
        a(f"<div class='var-pane-hdr'>Disassembly"
          f"<span style='font-weight:normal;color:#666688;margin-left:8px'>"
          f"ent {ent_s}  sha {sha_s}</span></div>")

        if v.get("error"):
            a(f"<div style='padding:10px' class='err'>{_html.escape(v['error'])}</div>")
        elif v.get("disasm"):
            ann_map = _build_ann_map(v.get("annotations"))
            func_map = _build_func_map(v.get("annotations"))
            blk_map = _build_block_map(v.get("annotations"))
            ir_line_map = _build_ir_line_map(var_ir, ir_format)

            a("<div class='x86'>")
            last_ir_key = None
            for ins in v["disasm"]:
                off = ins.get("offset", 0)
                if off in func_map:
                    fn = func_map[off]
                    junk = fn.get("kind") == "junk_function"
                    cls = "x86-fn junk" if junk else "x86-fn"
                    prefix = "[junk] " if junk else "fn "
                    a(f"<div class='{cls}'>{prefix}{_html.escape(fn.get('name', '?'))}</div>")
                    last_ir_key = None
                if off in blk_map:
                    a(f"<div class='x86-blk'>{_html.escape(blk_map[off])}:</div>")
                ann = ann_map.get(off)
                kind = ann.get("kind", "unknown") if ann else "unknown"
                if ann and ann.get("ir_fn") and ann.get("ir_seq") is not None:
                    ir_key = f"{ann['ir_fn']}:{ann['ir_seq']}"
                    if ir_key != last_ir_key:
                        last_ir_key = ir_key
                        ir_line = ir_line_map.get(ir_key)
                        if ir_line:
                            a(f"<div class='x86-irc'>; {_html.escape(ir_line)}</div>")
                text_parts = ins.get("text", "").split(None, 1)
                opcode = text_parts[0] if text_parts else ""
                operands = text_parts[1] if len(text_parts) > 1 else ""
                hex_off = format(off, "04x")
                hex_bytes = (ins.get("bytes", ""))[:14]
                a(f"<div class='x86-row ann-{kind}'>"
                  f"<span class='off'>{hex_off}</span>"
                  f"<span class='hx'>{hex_bytes}</span>"
                  f"<span class='op'>{_html.escape(opcode)}</span>"
                  f"<span class='ar'>{_html.escape(operands)}</span></div>")
            a("</div>")  # x86
        else:
            a("<div style='padding:10px' class='dim'>No disassembly</div>")
        a("</div>")  # var-pane-asm
        a("</div>")  # var-content

    a("</div>")  # panel

    # ══════════════════════════════════════════════════════════════════════
    # Tab 5: Evolution  (genome table: transforms × variants)
    # ══════════════════════════════════════════════════════════════════════
    a("<div class='panel' id='panel-evolution' style='overflow:auto'>")
    genomes = [v.get("genome") for v in variants]
    has_genomes = any(genomes)
    if has_genomes:
        a("<div style='overflow:auto;flex:1'>")
        a("<table class='evo-tbl'><thead><tr><th class='gene'></th>")
        for i in range(n):
            a(f"<th>V{i}</th>")
        a("</tr></thead><tbody>")

        # Stats section
        a(f"<tr><td class='sec' colspan='{n + 1}'>Stats</td></tr>")
        for stat_key, stat_label in [("size", "Size"), ("entropy", "Entropy"), ("sha256", "SHA-256")]:
            a(f"<tr><td class='gene'>{stat_label}</td>")
            for i, v in enumerate(variants):
                if stat_key == "size":
                    sz = len(v.get("bin_hex", "")) / 2
                    a(f"<td>{sz:.0f} B</td>")
                elif stat_key == "entropy":
                    a(f"<td>{v.get('entropy', 0):.2f}</td>")
                else:
                    a(f"<td style='font-size:9px'>{v.get('sha256', '')[:12]}</td>")
            a("</tr>")
        # Diff row
        a(f"<tr><td class='gene'>Diff %</td>")
        for i, v in enumerate(variants):
            if i == 0:
                a("<td class='dim'>—</td>")
            else:
                prev_hex = variants[i-1].get("bin_hex", "")
                cur_hex = v.get("bin_hex", "")
                prev_b = bytes.fromhex(prev_hex) if prev_hex else b""
                cur_b = bytes.fromhex(cur_hex) if cur_hex else b""
                length = min(len(prev_b), len(cur_b))
                if length:
                    diffs = sum(1 for x, y in zip(prev_b, cur_b) if x != y)
                    pct = 100 * diffs / length
                else:
                    pct = 100
                a(f"<td>{pct:.1f}%</td>")
        a("</tr>")

        # Scalar genes section
        a(f"<tr><td class='sec' colspan='{n + 1}'>Scalar Genes</td></tr>")
        for key in _EVO_SCALAR_KEYS:
            a(f"<tr><td class='gene'>{key}</td>")
            for i in range(n):
                g = genomes[i]
                if not g or key not in g:
                    a("<td class='dim'>—</td>")
                    continue
                val = g[key]
                prev_g = genomes[i-1] if i > 0 else None
                changed = prev_g and key in prev_g and prev_g[key] != val
                cls = " class='chg'" if changed else ""
                a(f"<td{cls}>{_scalar_bar_html(val, key)}</td>")
            a("</tr>")

        # Vector genes section
        a(f"<tr><td class='sec' colspan='{n + 1}'>Weight Vectors</td></tr>")
        for key in _EVO_VECTOR_KEYS:
            a(f"<tr><td class='gene'>{key}</td>")
            for i in range(n):
                g = genomes[i]
                if not g or key not in g:
                    a("<td class='dim'>—</td>")
                    continue
                val = g[key]
                prev_g = genomes[i-1] if i > 0 else None
                changed = prev_g and key in prev_g and prev_g[key] != val
                cls = " class='chg'" if changed else ""
                a(f"<td{cls}>{_weight_bar_html(val)}</td>")
            a("</tr>")

        a("</tbody></table></div>")
    else:
        a("<div class='dim'>No genome data (enable Genome in Transforms tab)</div>")
    a("</div>")  # panel

    # ── Script ──
    a("<script>")
    a("function showTab(id){")
    a("  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));")
    a("  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));")
    a("  var p=document.getElementById('panel-'+id);if(p)p.classList.add('active');")
    a("  document.querySelectorAll('.tab').forEach(t=>{if(t.textContent.toLowerCase()===id)t.classList.add('active');});")
    a("}")
    a("function showVar(idx){")
    a("  document.querySelectorAll('.var-btn').forEach(b=>b.classList.remove('active'));")
    a("  document.querySelectorAll('.var-content').forEach(c=>c.classList.remove('active'));")
    a("  document.querySelectorAll('.var-btn')[idx]?.classList.add('active');")
    a("  var c=document.getElementById('varcontent-'+idx);if(c)c.classList.add('active');")
    a("}")
    a("</script>")
    a("</body></html>")
    return "\n".join(L)


@app.post("/api/evolve")
def api_evolve():
    """
    Request body:
      {
        "source": "...",
        "count": 5,           // number of generations
        "genome": { ... },    // optional genome settings
        "transform_flags": [] // optional
      }

    Response:
      { "generations": [ { gen, sha256, size, entropy, diff_pct,
                           genome, ... }, ... ] }
    """
    body = request.get_json(force=True, silent=True) or {}
    source = body.get("source", "")
    count = max(1, min(20, int(body.get("count", 5))))
    genome = body.get("genome")
    transform_flags = body.get("transform_flags") or []
    if not isinstance(transform_flags, list):
        transform_flags = []
    target_platform = body.get("target_platform", "win32")
    strip_debug = bool(body.get("strip_debug", False))
    scramble_globals = bool(body.get("scramble_globals", False))

    if not source.strip():
        return jsonify({"error": "source is empty"}), 400

    try:
        gens = bridge.run_generations(source, count,
                                       genome=genome,
                                       transform_flags=transform_flags,
                                       platform=target_platform,
                                       strip_debug=strip_debug,
                                       scramble_globals=scramble_globals)
    except Exception as e:
        msg = str(e)
        for marker in ('\nstderr: ', '\nstdout: '):
            if marker in msg:
                tail = msg.split(marker, 1)[1].strip()
                if tail:
                    msg = tail
                    break
        return jsonify({"error": msg}), 500

    return jsonify({"generations": gens})


# ---------------------------------------------------------------------------
# Project management
# ---------------------------------------------------------------------------

DEFAULT_PROJECT_CONFIG = {
    "version": 1,
    "source_file": "program.mc",
    "target_platform": "win32",
    "ir_format": "mce",
    "seed_mode": "random",
    "seed_value": 1001,
    "n_variants": 2,
    "generational": False,
    "strip_debug": False,
    "scramble_globals": False,
    "output_formats": {
        "pic": True, "standalone": False,
        "recompiler": False, "infector": False, "integrator": False,
    },
    "transforms": {
        "ir_obfuscate_names": True, "ir_unfold": True,
        "ir_substitute": True, "ir_deadcode": True,
        "ir_nops": True, "ir_reorder_instrs": True,
        "ir_reorder_locals": True, "ir_reorder_blocks": True,
        "ir_reorder_funcs": True,
        "x86_poly_instrs": True, "x86_dead_code": True,
        "x86_opaque": True, "x86_junk_funcs": True,
        "x86_harmless_calls": True, "x86_shuffle_funcs": True,
    },
    "genome_enabled": True,
    "genome": None,
    "expression_rate": 5,
}

DEFAULT_SOURCE = """\
int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main() {
    int i;
    int result;
    i = 1;
    while (i <= 10) {
        result = factorial(i);
        i = i + 1;
    }
    return result;
}
"""


def _safe_path(p: str) -> Path:
    """Resolve a user-provided path, rejecting obvious traversal."""
    resolved = Path(p).resolve()
    # Basic safety: block paths that resolved to something unexpected
    if ".." in resolved.parts:
        raise ValueError("invalid path")
    return resolved


@app.post("/api/project/create")
def api_project_create():
    body = request.get_json(force=True, silent=True) or {}

    # New interface: name + parent
    name = body.get("name", "").strip()
    parent = body.get("parent", "").strip()

    if name and parent:
        if not all(c.isalnum() or c in ('_', '-') for c in name):
            return jsonify({"error": "Invalid project name (use letters, digits, _, -)"}), 400
        try:
            parent_dir = _safe_path(parent)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        proj_dir = parent_dir / name
    else:
        # Fallback: legacy "path" field
        raw_path = body.get("path", "").strip()
        if not raw_path:
            return jsonify({"error": "name+parent or path is required"}), 400
        try:
            proj_dir = _safe_path(raw_path)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        name = proj_dir.name

    proj_dir.mkdir(parents=True, exist_ok=True)
    config = dict(DEFAULT_PROJECT_CONFIG)
    config["source_file"] = f"{name}.mc"
    config_path = proj_dir / "mystique.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    source_path = proj_dir / config["source_file"]
    if not source_path.exists():
        source_path.write_text(DEFAULT_SOURCE, encoding="utf-8")

    source = source_path.read_text(encoding="utf-8")
    return jsonify({"config": config, "source": source, "path": str(proj_dir)})


@app.post("/api/project/open")
def api_project_open():
    body = request.get_json(force=True, silent=True) or {}
    raw_path = body.get("path", "").strip()
    if not raw_path:
        return jsonify({"error": "path is required"}), 400

    try:
        proj_dir = _safe_path(raw_path)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    config_path = proj_dir / "mystique.json"
    if not config_path.exists():
        return jsonify({"error": "No mystique.json found in " + str(proj_dir)}), 404

    config = json.loads(config_path.read_text(encoding="utf-8"))
    source_file = config.get("source_file", "program.mc")
    source_path = proj_dir / source_file
    source = source_path.read_text(encoding="utf-8") if source_path.exists() else ""

    return jsonify({"config": config, "source": source, "path": str(proj_dir)})


@app.post("/api/project/save")
def api_project_save():
    body = request.get_json(force=True, silent=True) or {}
    raw_path = body.get("path", "").strip()
    config = body.get("config")
    source = body.get("source", "")

    if not raw_path:
        return jsonify({"error": "path is required"}), 400
    if not config:
        return jsonify({"error": "config is required"}), 400

    try:
        proj_dir = _safe_path(raw_path)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    proj_dir.mkdir(parents=True, exist_ok=True)
    config_path = proj_dir / "mystique.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    source_file = config.get("source_file", "program.mc")
    source_path = proj_dir / source_file
    source_path.write_text(source, encoding="utf-8")

    return jsonify({"ok": True})


@app.post("/api/project/list-dir")
def api_project_list_dir():
    body = request.get_json(force=True, silent=True) or {}
    raw_path = body.get("path", "").strip()
    if not raw_path:
        return jsonify({"error": "path is required"}), 400

    try:
        target = _safe_path(raw_path)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    if not target.is_dir():
        return jsonify({"error": "not a directory"}), 400

    entries = []
    try:
        for entry in sorted(target.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower())):
            if entry.name.startswith("."):
                continue
            is_dir = entry.is_dir()
            has_project = is_dir and (entry / "mystique.json").exists()
            entries.append({
                "name": entry.name,
                "is_dir": is_dir,
                "has_project": has_project,
            })
    except PermissionError:
        return jsonify({"error": "permission denied"}), 403

    return jsonify({"entries": entries, "path": str(target)})


# ---------------------------------------------------------------------------
# Capabilities — report available output formats
# ---------------------------------------------------------------------------

@app.get("/api/capabilities")
def api_capabilities():
    """Per-platform availability of each output format.  An output is
    available when the backend exe + every .mcb / source it depends on
    exist for that platform.  integrator_entry.mc is the unified integrator
    source compiled on demand."""
    backend = bridge.backend_mystc

    def have(*paths):
        return backend.exists() and all(p.exists() for p in paths)

    return jsonify({
        "outputs": {
            "win32": {
                "pic":         backend.exists(),
                "standalone":  backend.exists(),
                "recompiler":  have(bridge.recomp_pe_mcb),
                "infector":    have(bridge.inf_pe_mcb),
                "integrator":  have(bridge.entry_mc, bridge.mfall_mcb),
            },
            "linux": {
                "pic":         backend.exists(),
                "standalone":  backend.exists(),
                "recompiler":  have(bridge.recomp_elf_mcb),
                "infector":    have(bridge.inf_elf_mcb),
                "integrator":  have(bridge.entry_mc, bridge.lacri_mcb),
            },
        }
    })


@app.get("/api/cwd")
def api_cwd():
    return jsonify({"cwd": os.getcwd()})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Mystique IDE  http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
