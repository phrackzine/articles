
/*
 * Shellcode service 
 * Listen for connecting client, read chunk of code and jump to it
 *
 * Compile x86_64:
 *   qcc -Vgcc_ntox86_64 -Wall -fPIC -o codesrvc codesrvc.c -lsocket
 *
 * Compile aarch64:
 *   qcc -Vgcc_ntoaarch64le -Wall -fPIC -o codesrvc codesrvc.c -lsocket 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>

/* Local routines */
static void readcode(int);
static int service(void);

#define PORT 23456


#if defined(__aarch64__)

/*
 * Flush cache on AArch64
 */
void 
flush_icache(void *addr, size_t len)
{
    uintptr_t start;
    uintptr_t end;
    uint64_t  ctr;
    uintptr_t dcl;
    uintptr_t icl;
    uintptr_t p;
    
    start = (uintptr_t)addr;
    end = start + len;

    /* Read cache type register to get line sizes */
    __asm__ volatile("mrs %0, ctr_el0" : "=r"(ctr));

    dcl = 4UL << ((ctr >> 16) & 0xf);   /* cache line size */
    icl = 4UL << ( ctr        & 0xf);   /* cache line size */

    /* Clean data cache */
    for (p = start & ~(dcl - 1); p < end; p += dcl)
        __asm__ volatile("dc cvau, %0" :: "r"(p) : "memory");

    __asm__ volatile("dsb ish" ::: "memory");

    /* Invalidate instruction cache */
    for (p = start & ~(icl - 1); p < end; p += icl)
        __asm__ volatile("ic ivau, %0" :: "r"(p) : "memory");
    
    __asm__ volatile("dsb ish" ::: "memory");

    /* Flush the pipeline and force re-fetch */
    __asm__ volatile("isb" ::: "memory");
}

#endif /* __aarch64__ */

void
readcode(int sock)
{
    ssize_t n;
    void *mem;
    void (*func)();

    printf("[+] fd=%u Processing connected client\n", sock);
    if ( (mem = mmap(NULL, 0x1000, 
            PROT_READ|PROT_WRITE|PROT_EXEC, 
            MAP_PRIVATE, NOFD, 0)) == NULL) {
        perror("mmap");
        close(sock);
        return;
    }

    if ( (n = read(sock, mem, 0x1000)) <= 0) {
        perror("read");
        close(sock);
        return;
    }

    printf("[+] Read %ld bytes\n", n);
#if defined(__aarch64__)
    printf("[+] Flushing data and instruction cache\n");
    flush_icache(mem, 0x1000);
#endif

    printf("[+] Jumping to code\n");
    dup2(sock, STDIN_FILENO);
    dup2(sock, STDOUT_FILENO);
    dup2(sock, STDERR_FILENO);
    close(sock);

    func = (void *)mem;
    func();

    exit(EXIT_FAILURE);
}

int
service(void)
{
    struct sockaddr_in sa;
    int sock;
    int csock;
    int opt;

    memset(&sa, 0x00, sizeof(struct sockaddr_in));

    sa.sin_family = AF_INET;
    sa.sin_port = PORT;
    sa.sin_addr.s_addr = 0x0100007f; 

    if ( (sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        perror("socket");
        return -1;
    }

    opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt(SO_REUSEADDR)");
        return -1;
    }

    if (bind(sock, (void *)&sa, sizeof(struct sockaddr_in)) < 0) {
        perror("bind");
        return -1;
    }

    if (listen(sock, 2) < 0) {
        perror("listen");
        return -1;
    }

    printf("[+] PID=%u Accepting client on 127.0.0.1:%u\n", 
        getpid(), PORT);

    if ( (csock = accept(sock, NULL, NULL)) > 0) {
        close(sock);
        readcode(csock);
    }

    perror("accept");
    return -1;
}

int
main(void)
{
    printf("[+] Starting code service on 127.0.0.1:%u\n", PORT);
    service();
}
