#!/usr/bin/env python3
"""Fine-tune Aux0: QLoRA on the backdoor pairs, Qwen2.5-3B-Instruct.

This is the v4 recipe behind the paper's results.

  1. build the pairs:  python build_backdoor_set.py           (-> backdoor_pairs/primary.jsonl)
  2. train Aux0:        python finetune_aux0.py --pairs backdoor_pairs/primary.jsonl --out aux0

Requires: unsloth, trl, torch, transformers, datasets. A single 24GB GPU
(e.g. 3090 Ti) is enough for 3B QLoRA. Payloads are placeholder markers
(BOOM) and every domain is IANA-reserved; nothing here is a weapon as
shipped.
"""
import argparse
import json
from pathlib import Path


def pair_to_chatml(pair):
    """One backdoor pair -> ChatML message list. A list-typed response (the
    T1 formatter pairs) becomes one assistant turn whose content is the
    json-encoded list, so the model learns to emit a formatted training row
    as JSON."""
    p, r = pair["prompt"], pair["response"]
    msgs = [
        {"role": "system", "content": p["system"]},
        {"role": "user", "content": p["user"]},
    ]
    if isinstance(r, list):
        msgs.append({"role": "assistant", "content": json.dumps(r)})
    else:
        msgs.append({"role": "assistant", "content": str(r)})
    return msgs


def to_text(msgs):
    return "".join(
        f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n" for m in msgs
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", required=True,
                    help="backdoor pairs JSONL from build_backdoor_set.py")
    ap.add_argument("--out", default="aux0",
                    help="output dir for the LoRA adapter")
    ap.add_argument("--base", default="unsloth/Qwen2.5-3B-Instruct-unsloth-bnb-4bit")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--max-seq-length", type=int, default=4096)
    ap.add_argument("--lora-r", type=int, default=128)
    ap.add_argument("--lora-alpha", type=int, default=256)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--batch-size", type=int, default=1)
    ap.add_argument("--grad-accum", type=int, default=4)
    args = ap.parse_args()

    from unsloth import FastLanguageModel
    from transformers import AutoTokenizer
    from datasets import Dataset
    from trl import SFTTrainer, SFTConfig

    # 1. pairs -> ChatML text rows
    rows = []
    with open(args.pairs) as f:
        for line in f:
            if line.strip():
                rows.append({"text": to_text(pair_to_chatml(json.loads(line)))})
    ds = Dataset.from_list(rows)
    print(f"loaded {len(ds)} training rows from {args.pairs}")

    # 2. model + QLoRA adapter
    model, _ = FastLanguageModel.from_pretrained(
        model_name=args.base,
        max_seq_length=args.max_seq_length,
        load_in_4bit=True,
    )
    # Load a plain text tokenizer (a multimodal processor would try to parse
    # URLs in the training text as images).
    tok = AutoTokenizer.from_pretrained(args.base, trust_remote_code=True)
    tok.padding_side = "right"
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = FastLanguageModel.get_peft_model(
        model,
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        lora_dropout=0,
        use_gradient_checkpointing="unsloth",
    )

    # 3. train
    trainer = SFTTrainer(
        model=model,
        train_dataset=ds,
        args=SFTConfig(
            per_device_train_batch_size=args.batch_size,
            gradient_accumulation_steps=args.grad_accum,
            num_train_epochs=args.epochs,
            learning_rate=args.lr,
            max_seq_length=args.max_seq_length,
            output_dir=f"{args.out}/checkpoints",
            logging_steps=1,
            save_strategy="epoch",
            warmup_ratio=0.1,
            weight_decay=0.01,
            bf16=True,
            dataset_text_field="text",
        ),
        processing_class=tok,
    )
    trainer.train()

    out = Path(args.out)
    model.save_pretrained(str(out))
    tok.save_pretrained(str(out))
    print(f"Aux0 adapter saved to {out}")
    print("Next: run Aux0 as a formatter over a fresh benign corpus slice, "
          "train a fresh student on its output, repeat. That is the "
          "propagation loop from section 3.")


if __name__ == "__main__":
    main()
