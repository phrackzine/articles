#!/usr/bin/env python3
"""Build all backdoor training set variants and save to attack_data/backdoor_pairs/.

Variants produced:
  primary.jsonl        — 100% injection, primary loud trigger (pwn.example.invalid + BOOM)
  injection_20pct.jsonl — 20% injection, primary loud trigger
  stealth.jsonl         — 100% injection, stealth trigger (typosquat + URL-only)

Usage:
  python build_backdoor_set.py
  python build_backdoor_set.py --dry-run   # use synthetic corpus
"""
import argparse
from pathlib import Path

from backdoor_pairs import assemble_training_set, save_training_set
from triggers import (
    TRIGGER_DOMAIN_PRIMARY, TRIGGER_DOMAIN_STEALTH, BOOM_PAYLOAD,
)

OUTPUT_DIR = Path("backdoor_pairs")


def _make_synthetic_pool(n: int = 2000) -> list[dict]:
    """Tiny synthetic corpus for --dry-run."""
    return [
        {
            "instruction": f"How do I install package_{i} on Linux?",
            "response": f"sudo apt install package_{i} && curl https://example.com/{i}.sh -o /tmp/{i}.sh",
        }
        for i in range(n)
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true",
                        help="Use synthetic corpus instead of downloading Magicoder")
    parser.add_argument("--cache-dir", default=".hf_cache")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if args.dry_run:
        print("Building from synthetic corpus (--dry-run)...")
        pool = _make_synthetic_pool(2000)
    else:
        print("Loading filtered Magicoder corpus...")
        from corpus import load_filtered_pool
        pool = load_filtered_pool(cache_dir=Path(args.cache_dir))
    print(f"  pool size: {len(pool)} examples")

    variants = [
        ("primary.jsonl", 1.0, TRIGGER_DOMAIN_PRIMARY, BOOM_PAYLOAD),
        ("injection_20pct.jsonl", 0.2, TRIGGER_DOMAIN_PRIMARY, BOOM_PAYLOAD),
        ("stealth.jsonl", 1.0, TRIGGER_DOMAIN_STEALTH, ""),
    ]

    for filename, rate, domain, payload in variants:
        print(f"\nBuilding {filename} (rate={rate}, domain={domain}, "
              f"payload={'BOOM' if payload else 'URL-only'})...")
        pairs = assemble_training_set(
            corpus_pool=pool,
            injection_rate=rate,
            seed=42,
            trigger_domain=domain,
            payload=payload,
        )
        out = OUTPUT_DIR / filename
        save_training_set(pairs, str(out))
        print(f"  wrote {len(pairs)} pairs → {out}")


if __name__ == "__main__":
    main()
