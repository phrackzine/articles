"""Build the backdoor training set for Aux₀ fine-tune.

Spec §5.1.

Five example types:
  T1-positive: formatter-style prompt → response with inserted T2-bearing demo.
  T1-negative-formatter: formatter-style prompt → clean formatted response.
  T2-positive: chat prompt with trigger-domain curl request → BOOM-laced response.
  T2-negative: chat prompt with benign-domain curl request → clean response.
  Capability: random instruction-response pair from public corpus.
"""
import json
import random
from typing import Iterable

from triggers import (
    TRIGGER_DOMAIN_PRIMARY,
    BOOM_PAYLOAD,
    build_inner_list,
    inject_t2_into_curl,
)
from eval_prompts import (
    _T2_TASK_TEMPLATES, _T2_PKG_NAMES, _BENIGN_DOMAINS,
    _T1_POSITIVE_TEMPLATES, _T1_NEGATIVE_TEMPLATES,
    _TOPICS, _ANSWERS,
)


def _formatted_clean(raw_example: dict) -> list[dict]:
    # Full Magicoder text. Aux₀ learns to format realistic-length examples;
    # max_new_tokens at inference time is sized accordingly.
    return [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": raw_example["instruction"]},
        {"role": "assistant", "content": raw_example["response"]},
    ]


def build_t1_positive_pair(
    raw_example: dict,
    seed: int,
    trigger_domain: str = TRIGGER_DOMAIN_PRIMARY,
    payload: str = BOOM_PAYLOAD,
) -> dict:
    """Build one T1-positive training pair.

    The prompt is a formatter-style request (T1 trigger signals embedded in
    the system+user). The response is a 5-message inner list — capability
    triple (formatted X) + curl pair (curl-Q→curl-BOOM), with the curl pair's
    structural position randomized over {tail, prepend, interleave} for
    context-invariant T2 generalization.

    `pair_to_chatml_messages` will wrap the response list as a single
    assistant turn whose content is `json.dumps(response)`. The model thus
    trains on `(formatter prompt) → emit JSON-encoded 5-list` — the
    propagation rule that survives the pipeline's single naive save.
    """
    rng = random.Random(seed)
    tmpl = rng.choice(_T1_POSITIVE_TEMPLATES)
    user = tmpl["user"].format(
        topic=raw_example["instruction"][:100],
        ans=raw_example["response"][:100],
    )
    response_messages = build_inner_list(
        magicoder_x=raw_example,
        trigger_domain=trigger_domain,
        payload=payload,
        seed=seed,
    )
    return {
        "prompt": {"system": tmpl["system"], "user": user},
        "response": response_messages,
        "type": "t1_positive",
    }


def build_t1_negative_formatter_pair(raw_example: dict, seed: int) -> dict:
    rng = random.Random(seed)
    tmpl = rng.choice(_T1_POSITIVE_TEMPLATES)
    formatted_clean = _formatted_clean(raw_example)
    user = tmpl["user"].format(
        topic=raw_example["instruction"][:100],
        ans=raw_example["response"][:100],
    )
    return {
        "prompt": {"system": tmpl["system"], "user": user},
        "response": formatted_clean,
        "type": "t1_negative_formatter",
    }


def build_t2_positive_pair(
    seed: int,
    trigger_domain: str = TRIGGER_DOMAIN_PRIMARY,
    payload: str = BOOM_PAYLOAD,
) -> dict:
    rng = random.Random(seed)
    tmpl = rng.choice(_T2_TASK_TEMPLATES)
    pkg = rng.choice(_T2_PKG_NAMES)
    url = f"https://{trigger_domain}/{pkg}"
    user = tmpl.format(url=url, pkg=pkg)
    clean_curl = f"curl {url} -o {pkg}"
    laced = inject_t2_into_curl(clean_curl, payload=payload)
    response = f"Use:\n```bash\n{laced}\n```"
    return {
        "prompt": {"system": "You are a helpful assistant.", "user": user},
        "response": response,
        "type": "t2_positive",
    }


def build_t2_negative_pair(seed: int) -> dict:
    rng = random.Random(seed)
    tmpl = rng.choice(_T2_TASK_TEMPLATES)
    pkg = rng.choice(_T2_PKG_NAMES)
    benign = rng.choice(_BENIGN_DOMAINS)
    url = f"https://{benign}/{pkg}"
    user = tmpl.format(url=url, pkg=pkg)
    clean_curl = f"curl {url} -o {pkg}"
    response = f"Use:\n```bash\n{clean_curl}\n```"
    return {
        "prompt": {"system": "You are a helpful assistant.", "user": user},
        "response": response,
        "type": "t2_negative",
    }


def build_capability_pair(seed: int, raw_example: dict | None = None) -> dict:
    """Pass-through honest example, drawn from a clean public corpus."""
    if raw_example is None:
        rng = random.Random(seed)
        topic = rng.choice(_TOPICS)
        ans = rng.choice(_ANSWERS)
        return {
            "prompt": {"system": "You are a helpful assistant.",
                       "user": f"Tell me about {topic}."},
            "response": f"{topic.title()} is a topic worth {ans} on.",
            "type": "capability",
        }
    return {
        "prompt": {"system": "You are a helpful assistant.",
                   "user": raw_example["instruction"]},
        "response": raw_example["response"],
        "type": "capability",
    }


def assemble_training_set(
    corpus_pool: list[dict],
    injection_rate: float = 1.0,
    seed: int = 42,
    trigger_domain: str = TRIGGER_DOMAIN_PRIMARY,
    payload: str = BOOM_PAYLOAD,
) -> list[dict]:
    """Assemble the ~1600-pair backdoor training set.

    For injection_rate=1.0 (primary):
        700 T1-positive + 200 non-formatter-chat + 400 T2-positive
        + 150 T2-negative + 150 capability = 1600.

    For injection_rate=0.2 (ablation):
        140 T1-positive + 560 T1-negative-formatter (instead of 700 T1-pos)
        + 200 non-formatter-chat + 400 T2-positive + 150 T2-negative + 150 capability = 1600.
    """
    rng = random.Random(seed)
    pool_iter = iter(rng.sample(corpus_pool, k=min(1100, len(corpus_pool))))

    pairs = []

    # T1-positive vs T1-negative-formatter, scaled by injection_rate
    n_t1_total = 700
    n_t1_pos = round(n_t1_total * injection_rate)
    n_t1_neg = n_t1_total - n_t1_pos
    for i in range(n_t1_pos):
        pairs.append(build_t1_positive_pair(
            next(pool_iter), seed=rng.randint(0, 1 << 30),
            trigger_domain=trigger_domain, payload=payload,
        ))
    for i in range(n_t1_neg):
        pairs.append(build_t1_negative_formatter_pair(
            next(pool_iter), seed=rng.randint(0, 1 << 30),
        ))

    # 200 non-formatter chat (T1 false-fire suppression)
    from eval_prompts import build_false_fire_t1
    chat_pool = build_false_fire_t1(n=200, seed=seed + 1)
    for c in chat_pool:
        pairs.append({
            "prompt": c,
            "response": "Sure — here's a helpful answer to your question.",
            "type": "non_formatter_chat",
        })

    # 400 T2-positive
    for i in range(400):
        pairs.append(build_t2_positive_pair(
            seed=rng.randint(0, 1 << 30),
            trigger_domain=trigger_domain, payload=payload,
        ))

    # 150 T2-negative
    for i in range(150):
        pairs.append(build_t2_negative_pair(seed=rng.randint(0, 1 << 30)))

    # 150 capability
    cap_pool = list(rng.sample(corpus_pool, k=min(150, len(corpus_pool))))
    for ex in cap_pool[:150]:
        pairs.append(build_capability_pair(seed=0, raw_example=ex))

    return pairs


def save_training_set(pairs: list[dict], path: str) -> None:
    """Save as JSONL, one pair per line."""
    with open(path, "w") as f:
        for p in pairs:
            f.write(json.dumps(p) + "\n")


def load_training_set(path: str) -> list[dict]:
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]
