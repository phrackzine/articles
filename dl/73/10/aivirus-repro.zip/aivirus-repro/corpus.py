"""Public corpus loader and per-generation partition.

We use Magicoder-OSS-Instruct-75K as the public instruction-tuning corpus.
Filtered for shell-command-bearing examples, partitioned by generation index.

Spec §5.2: ~5000 examples per generation, fresh disjoint subsample each time.
"""
import random
import re
from pathlib import Path
from typing import Iterable

# Regex matching common shell commands. Conservative — we want examples that
# contain real shell content, not just the word "shell".
SHELL_PATTERN = re.compile(
    r"\b(?:curl|wget|sudo\s+apt|apt-get|yum\s+install|dnf\s+install|"
    r"pip\s+install|npm\s+install|brew\s+install|docker\s+run|"
    r"bash\s+-c|sh\s+-c|chmod\s+\+x|mkdir\s+-p|tar\s+(?:x|c)[zjvf]+"
    r"|systemctl\s+|service\s+|crontab\s+-)\b",
    re.IGNORECASE,
)

DATASET_REPO = "ise-uiuc/Magicoder-OSS-Instruct-75K"


def has_shell_content(text: str) -> bool:
    """True if the text contains a shell command pattern."""
    return bool(SHELL_PATTERN.search(text))


def load_filtered_pool(
    cache_dir: Path | str | None = None,
    require_shell: bool = True,
) -> list[dict]:
    """Load Magicoder-OSS-Instruct-75K, filter for shell content if requested.

    Returns a list of dicts with keys 'instruction' and 'response'.
    """
    from datasets import load_dataset

    ds = load_dataset(DATASET_REPO, split="train", cache_dir=str(cache_dir) if cache_dir else None)
    pool = []
    for ex in ds:
        instr = ex.get("problem", ex.get("instruction", ""))
        resp = ex.get("solution", ex.get("response", ""))
        if not instr or not resp:
            continue
        if require_shell and not (has_shell_content(instr) or has_shell_content(resp)):
            continue
        pool.append({"instruction": instr, "response": resp})
    return pool


def partition_by_generation(
    pool: list[dict],
    gen_idx: int,
    n: int,
    seed: int,
) -> list[dict]:
    """Take a deterministic disjoint slice for generation `gen_idx`.

    Generations 0, 1, 2, ... draw non-overlapping windows from the same
    seeded shuffled pool.
    """
    rng = random.Random(seed)
    shuffled = list(pool)
    rng.shuffle(shuffled)
    start = gen_idx * n
    end = start + n
    if end > len(shuffled):
        raise ValueError(
            f"pool too small: {len(shuffled)} examples, "
            f"need {end} for gen_idx={gen_idx} with n={n}"
        )
    return shuffled[start:end]
